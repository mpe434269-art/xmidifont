# StyleGrooveMidi's – proyecto Android Studio

## Cómo compilar el APK
**Opción A – Android Studio (PC):** abre esta carpeta (File ▸ Open), espera el Gradle Sync y pulsa
*Build ▸ Build APK(s)*. El APK queda en `app/build/outputs/apk/debug/`.

**Opción B – solo con el móvil (GitHub Actions):** sube esta carpeta a un repositorio nuevo de GitHub.
En la pestaña *Actions* se ejecuta solo `Build APK` (archivo `.github/workflows/build.yml`) y al terminar
descargas el APK en *Artifacts ▸ XMidi-debug-apk*.

## Qué cambió
- Tema negro + dorado en toda la app (barra superior, listas, guitarra, piano, metrónomo, diálogos).
- Pantalla de ritmos rediseñada (`res/layout/drums.xml`, `voice_panel.xml`, `Drums.java`, `widgets/KeyPad.java`).
- LEDs: naranja = sección actual, azul = disponible, parpadeo al compás en Fill In / Intro / Ending / Break.
- Icono de batería azul/naranja alternando por pulso mientras suena el ritmo.
- BREAK nuevo, AUTO FILL IN y FADE IN/OUT como en el Yamaha, TEMPO BPM y VOLUME STY.
- VOICE RIGHT 1 / 2 (dos instrumentos a la vez; toca el panel para cambiar instrumento, sf2, volumen y reverb).
- HARMONY / ARPEGGIO (toque = on/off, mantener pulsado = elegir tipo).
- Icono nuevo y nombre "StyleGrooveMidi's".
- Archivos de lógica tocados: `StyleEngine.java`, `Synth.java`, `Chords.java`, `RightHand.java` (nuevo), `PianoBoard.java` (arreglo de un error del decompilador).
