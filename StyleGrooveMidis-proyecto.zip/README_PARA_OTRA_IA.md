# StyleGrooveMidi's - codigo fuente actual

Proyecto Gradle (AGP 8.5.2, Gradle 8.7, JDK 21, compileSdk 34, minSdk 24, namespace `net.duceng.xsynth`).
Originado de una app descompilada con jadx: algunas clases conservan estilo de codigo descompilado.
Las librerias nativas (fluidsynth, oboe, xsynth) estan precompiladas en `app/src/main/jniLibs` (sin fuentes C).

## Estructura util
- `app/src/main/java/net/duceng/xsynth/` : `Synth` (sintetizador, volumenes por rol, reverb/chorus, compresor de velocidades,
  reproductor MIDI), `XSynth` (JNI), `SoundStudio` (ecualizador/limitador de Android + adaptacion por estilo).
- `.../net/duceng/midi/` : lectura de MIDI y estilos Yamaha SFF (`StyFile`, `StySection`, CASM/CSEG/Ctb2).
- `.../net/duceng/xmidi/Drums.java` : pantalla de ritmos (pads, acordes, barra rapida, registros, pre-armado, stop-chord).
- `.../xmidi/util/StyleEngine.java` : motor de estilos (secciones, fills, cambio de acorde, resync de notas sostenidas).
- `.../xmidi/ExtraTools.java` : menu FUNC (tempo, mezcla, EQ/compresor, canales, registros, biblioteca).
- `.../xmidi/SoundfontSetup.java` : pantalla de primera vez para importar soundfonts SX700 y Tyros 4.
- `app/src/main/res/layout/drums.xml` : layout de la pantalla de ritmos.

## Funciones agregadas
Reproductor MIDI reescrito, pre-armado de Intro/Ending/Break/Fill, cambio de fill/break en vivo, correccion de bancos,
reverb de piano, asistente de soundfonts (SX700 principal + Tyros 4 segundo), subida de volumen, menu FUNC con 50+ extras,
barra rapida (TAP, perilla de tempo, TRANSPOSE, ACMP, REG 1-4), acorde Bajo+Cuerdas con ACMP y ritmo parado,
registros (tocar = cargar, mantener 3 s = guardar), cambio de estilo en vivo, ecualizador/compresor/limitador,
cambios de acorde sin cortes en instrumentos sostenidos.

## Pendiente
Soporte de estilos Casio (.ac7) y Korg (.sty KORF): formatos propietarios sin documentacion, no implementado.

## Compilar
`./gradlew assembleDebug` (o el workflow de GitHub Actions incluido). No se probo en dispositivo.
