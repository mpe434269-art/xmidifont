package net.duceng.midi;

import android.util.Log;
import android.util.SparseArray;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;
import net.duceng.xmidi.util.Chords;

/* JADX INFO: loaded from: classes7.dex */
public class StySection {
    public static final byte Bass = 10;
    public static final byte Chord1 = 11;
    public static final byte Chord2 = 12;
    public static final byte Pad = 13;
    public static final byte Phrase1 = 14;
    public static final byte Phrase2 = 15;
    public static final byte RhythmMain = 9;
    public static final byte RhythmSub = 8;
    private String name;
    private static final byte[] SCALE_MAJOR = {0, 2, 4, 5, 7, 9, 11};
    private static final byte[] SCALE_DORIAN = {0, 2, 3, 5, 7, 9, 10};
    private static final byte[] SCALE_MIXO = {0, 2, 4, 5, 7, 9, 10};
    private static final byte[] SCALE_MELMIN = {0, 2, 3, 5, 7, 9, 11};
    private static final byte[] SCALE_HARMIN = {0, 2, 3, 5, 7, 8, 11};
    private ArrayList<MidiEvent> events = new ArrayList<>();
    private SparseArray<StyControl> controls = new SparseArray<>();
    private ArrayList<TreeSet<EventChannel>> bars = new ArrayList<>();

    static boolean xmPlays(EventChannel eventChannel, StyControl styControl, Chords.Chord chord) {
        int i;
        if (eventChannel.type != 9 || eventChannel.value2 <= 0 || styControl == null || chord == null) {
            return true;
        }
        byte[] bArr = styControl.noteMute;
        int i2 = ((bArr[0] & Phrase2) << 8) | (bArr[1] & 255);
        if (i2 != 0 && i2 != 4095 && ((i2 >> chord.root) & 1) == 0) {
            return false;
        }
        byte[] bArr2 = styControl.chordMute;
        int i3 = ((bArr2[1] & 255) << 24) | ((bArr2[2] & 255) << 16) | ((bArr2[3] & 255) << 8) | (bArr2[4] & 255);
        if ((i3 & 1073741823) == 0) {
            return true;
        }
        int i4 = chord.id / 12;
        if (i4 == 2) {
            i = 804782080;
        } else {
            i = i4 == 0 ? 268435711 : 524032;
        }
        return (i3 & i) != 0;
    }

    protected StySection(String n) {
        this.name = n;
    }

    public String getName() {
        return this.name;
    }

    protected ArrayList<MidiEvent> getEvents() {
        return this.events;
    }

    protected SparseArray<StyControl> getControls() {
        return this.controls;
    }

    protected void setControls(SparseArray<StyControl> sc) {
        this.controls = sc;
    }

    public int getLastTick() {
        return this.events.get(this.events.size() - 1).tick;
    }

    protected void init(StyFile sf) {
        byte b;
        byte b2;
        int res = sf.getResolution();
        int barTick = sf.getBarTicks();
        int maxTick = 0;
        for (MidiEvent e : this.events) {
            if ((e instanceof EventChannel) && e.tick > maxTick) {
                maxTick = e.tick;
            }
        }
        int nBars = Math.max(1, ((maxTick + barTick) - 1) / barTick);
        ArrayList<ArrayList<EventChannel>> i_bars = new ArrayList<>();
        for (int i = 0; i < nBars; i++) {
            i_bars.add(new ArrayList<>());
        }
        Iterator<MidiEvent> it = this.events.iterator();
        while (true) {
            b = 9;
            b2 = 8;
            if (!it.hasNext()) {
                break;
            }
            MidiEvent e2 = it.next();
            if (e2 instanceof EventChannel) {
                EventChannel ec = (EventChannel) e2;
                boolean isOff = ec.type == 8 || (ec.type == 9 && ec.value2 == 0);
                int i2 = ec.tick;
                int bi = isOff ? Math.max(0, (i2 - 1) / barTick) : i2 / barTick;
                if (bi > nBars - 1) {
                    bi = nBars - 1;
                }
                ec.tick = Math.max(0, Math.min(barTick - 1, ec.tick - (bi * barTick)));
                i_bars.get(bi).add(ec);
            }
        }
        int idxBar = 0;
        while (idxBar < i_bars.size()) {
            ArrayList<EventChannel> barNow = i_bars.get(idxBar);
            TreeSet<EventChannel> nbar = new TreeSet<>();
            int idxNow = 0;
            while (idxNow < barNow.size()) {
                EventChannel on = barNow.get(idxNow);
                if (on.type != b || on.value2 <= 0) {
                    res = res;
                } else {
                    boolean find = false;
                    int idxFind = idxNow + 1;
                    while (idxFind < barNow.size()) {
                        EventChannel off = barNow.get(idxFind);
                        if ((off.type != b2 && (off.type != 9 || off.value2 != 0)) || off.channel != on.channel || off.value1 != on.value1) {
                            idxFind++;
                            b2 = 8;
                        } else {
                            if (off.tick - on.tick < res / 16) {
                                off.tick = Math.min(barTick - 1, (on.tick + (res / 8)) - 1);
                            }
                            find = true;
                            off.type = (byte) 8;
                            nbar.add(on);
                            nbar.add(off);
                            barNow.remove(idxFind);
                            barNow.remove(idxNow);
                            idxNow--;
                            break;
                        }
                    }
                    if (find) {
                        res = res;
                    } else {
                        EventChannel ecoff = new EventChannel(barTick - 1, (byte) 8, on.channel, on.value1, (byte) 0);
                        ecoff.carry = (byte) 1;
                        if (idxBar < i_bars.size() - 1) {
                            EventChannel econ = new EventChannel(0, (byte) 9, on.channel, on.value1, on.value2);
                            econ.carry = (byte) 2;
                            i_bars.get(idxBar + 1).add(0, econ);
                        }
                        nbar.add(on);
                        barNow.remove(idxNow);
                        idxNow--;
                        nbar.add(ecoff);
                    }
                }
                idxNow++;
                res = res;
                b = 9;
                b2 = 8;
            }
            int res2 = res;
            for (EventChannel rest : barNow) {
                if (rest.type != 9 && rest.type != 8) {
                    nbar.add(rest);
                }
            }
            this.bars.add(nbar);
            idxBar++;
            res = res2;
            b = 9;
            b2 = 8;
        }
        Log.i("XMidi", "Section:" + this.name + " bars: " + this.bars.size());
    }

    public int sizeBars() {
        return this.bars.size();
    }

    public ArrayList<EventChannel> getEvents(int idx) {
        return getEvents(idx, null);
    }

    public static boolean isRhythmChannel(int ch) {
        return ch == 8 || ch == 9;
    }

    public int getRetriggerRule(int channel) {
        StyControl sc = this.controls.get(channel);
        if (sc == null) {
            return 1;
        }
        return sc.retriggerRule;
    }

    public int getBarTicks(StyFile sf) {
        return sf.getBarTicks();
    }

    private static boolean contains(byte[] a, int v) {
        for (byte b : a) {
            if (b == v) {
                return true;
            }
        }
        return false;
    }

    private static byte[] scaleFor(int ntt, boolean minorFamily, boolean dominant) {
        if (!minorFamily) {
            return dominant ? SCALE_MIXO : SCALE_MAJOR;
        }
        if (ntt == 4) {
            return SCALE_MELMIN;
        }
        return ntt == 5 ? SCALE_HARMIN : SCALE_DORIAN;
    }

    private static boolean sourceIsMinor(int chordType) {
        return chordType >= 8 && chordType <= 18;
    }

    private static boolean sourceIsDominant(int chordType) {
        return chordType >= 19 && chordType <= 27;
    }

    /* JADX WARN: Code duplicated, block: B:102:0x00f1 */
    /* JADX WARN: Code duplicated, block: B:104:0x00ec */
    /* JADX WARN: Code duplicated, block: B:72:0x00c5 */
    /* JADX WARN: Code duplicated, block: B:75:0x00e6 */
    /* JADX WARN: Code duplicated, block: B:77:0x00ea */
    /* JADX WARN: Code duplicated, block: B:80:0x00f3 */
    static int transposeNote(int note, StyControl sc, Chords.Chord chord) {
        int idx;
        byte[] srcScale;
        byte[] tgtScale;
        int deg;
        int srcChordIdx;
        boolean chordTable;
        int i;
        byte srcChordIdx2 = (sc.chord < 0 || sc.chord >= Chords.CBASES.length) ? (byte) 2 : sc.chord;
        byte[] srcTones = Chords.CBASES[srcChordIdx2];
        byte[] bArr = chord.chords != null ? chord.chords : Chords.CBASES[0];
        boolean tgtMinor = chord.id / 12 == 1 || chord.id / 12 == 3;
        boolean tgtDominant = chord.id / 12 == 2;
        int srcRoot = sc.root & 255;
        if (srcRoot > 11) {
            srcRoot = 0;
        }
        byte tgtRoot = chord.root;
        int shift = (((tgtRoot - srcRoot) % 12) + 12) % 12;
        if (sc.noteRule == 1) {
            if (shift > 6) {
                shift -= 12;
            }
        } else if (shift > sc.highkey) {
            shift -= 12;
        }
        int delta = 0;
        if (sc.noteTable != 0) {
            int rel = (((note - srcRoot) % 12) + 12) % 12;
            int idx2 = -1;
            int i2 = 0;
            while (true) {
                if (i2 >= srcTones.length) {
                    idx = idx2;
                    break;
                }
                if (srcTones[i2] % 12 == rel && (idx2 < 0 || srcTones[i2] < 12)) {
                    idx2 = i2;
                    if (srcTones[i2] < 12) {
                        idx = idx2;
                        break;
                    }
                }
                i2++;
            }
            boolean chordTable2 = sc.noteTable == 2 || sc.noteTable == 3;
            if (idx >= 0) {
                if (chordTable2) {
                    i = 1;
                } else {
                    i = 1;
                    if (sc.noteTable < 1) {
                        srcScale = scaleFor(1, sourceIsMinor(srcChordIdx2), sourceIsDominant(srcChordIdx2));
                        tgtScale = scaleFor(sc.noteTable, tgtMinor, tgtDominant);
                        deg = -1;
                        srcChordIdx = 0;
                        while (true) {
                            chordTable = chordTable2;
                            if (srcChordIdx < srcScale.length) {
                                break;
                                break;
                            }
                            if (srcScale[srcChordIdx] <= rel) {
                                deg = srcChordIdx;
                            }
                            srcChordIdx++;
                            chordTable2 = chordTable;
                        }
                        if (deg >= 0) {
                            delta = tgtScale[deg] - srcScale[deg];
                        }
                    }
                }
                int i3 = bArr[Math.min(idx, bArr.length - i)];
                if (idx >= bArr.length) {
                    i3 += 12;
                }
                byte s = srcTones[idx];
                delta = i3 - s;
                while (delta > 6) {
                    delta -= 12;
                }
                while (delta < -6) {
                    delta += 12;
                }
            } else {
                srcScale = scaleFor(1, sourceIsMinor(srcChordIdx2), sourceIsDominant(srcChordIdx2));
                tgtScale = scaleFor(sc.noteTable, tgtMinor, tgtDominant);
                deg = -1;
                srcChordIdx = 0;
                while (true) {
                    chordTable = chordTable2;
                    if (srcChordIdx < srcScale.length) {
                        break;
                    }
                    if (srcScale[srcChordIdx] <= rel) {
                        deg = srcChordIdx;
                    }
                    srcChordIdx++;
                    chordTable2 = chordTable;
                }
                if (deg >= 0) {
                    delta = tgtScale[deg] - srcScale[deg];
                }
            }
        }
        int out = note + shift + delta;
        int lo = sc.lowLimit & 255;
        int hi = sc.highLimit & 255;
        if (hi > 127) {
            hi = 127;
        }
        if (hi >= lo + 11) {
            while (out > hi) {
                out -= 12;
            }
            while (out < lo) {
                out += 12;
            }
        }
        return Math.max(0, Math.min(127, out));
    }

    private static boolean isSetupEvent(EventChannel e) {
        return (e.type == 11 || e.type == 12) && e.tick <= 2;
    }

    public ArrayList<EventChannel> getSetupEvents() {
        StyControl sc;
        ArrayList<EventChannel> banks = new ArrayList<>();
        ArrayList<EventChannel> progs = new ArrayList<>();
        ArrayList<EventChannel> ctrls = new ArrayList<>();
        if (this.bars.isEmpty()) {
            return banks;
        }
        for (EventChannel e : this.bars.get(0)) {
            if (isSetupEvent(e) && (sc = this.controls.get(e.channel)) != null) {
                if (isRhythmChannel(e.channel) || sc.destination == 9) {
                    if (e.type == 12 && e.channel == 9) {
                        EventChannel d = e.clone();
                        d.channel = (byte) 9;
                        progs.add(d);
                    }
                } else {
                    EventChannel ec = e.clone();
                    ec.channel = sc.destination;
                    if (e.type == 12) {
                        progs.add(ec);
                    } else if (e.value1 == 0 || e.value1 == 32) {
                        if (e.value1 != 0 || e.value2 != 127) {
                            banks.add(ec);
                        }
                    } else {
                        ctrls.add(ec);
                    }
                }
            }
        }
        banks.addAll(progs);
        banks.addAll(ctrls);
        return banks;
    }

    public ArrayList<EventChannel> getEvents(int idx, Chords.Chord chord) {
        if (idx > this.bars.size() - 1 || idx < 0) {
            idx = 0;
        }
        ArrayList<EventChannel> bar = new ArrayList<>();
        if (this.bars.isEmpty()) {
            return bar;
        }
        for (EventChannel e : this.bars.get(idx)) {
            StyControl sc = this.controls.get(e.channel);
            if (sc != null && (idx != 0 || !isSetupEvent(e))) {
                if (isRhythmChannel(e.channel) || sc.destination == 9) {
                    if (e.type == 8 || e.type == 9) {
                        EventChannel ec = e.clone();
                        ec.channel = (byte) 9;
                        bar.add(ec);
                    }
                } else if (chord != null && xmPlays(e, sc, chord)) {
                    EventChannel ec2 = e.clone();
                    ec2.channel = sc.destination;
                    if (e.type == 8 || e.type == 9) {
                        ec2.value1 = (byte) transposeNote(e.value1, sc, chord);
                    }
                    bar.add(ec2);
                }
            }
        }
        Collections.sort(bar, new Comparator<EventChannel>() { // from class: net.duceng.midi.StySection.1
            @Override // java.util.Comparator
            public int compare(EventChannel x, EventChannel y) {
                int i = 1;
                if (x.tick != y.tick) {
                    return x.tick < y.tick ? -1 : 1;
                }
                int rx = (x.type == 8 || (x.type == 9 && x.value2 == 0)) ? 0 : 1;
                if (y.type == 8 || (y.type == 9 && y.value2 == 0)) {
                    i = 0;
                }
                int ry = i;
                return rx - ry;
            }
        });
        return bar;
    }
}
