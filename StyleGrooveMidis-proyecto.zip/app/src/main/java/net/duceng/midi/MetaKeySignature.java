package net.duceng.midi;

/* JADX INFO: loaded from: classes7.dex */
public class MetaKeySignature extends EventMeta {
    public static final byte SCALE_MAJOR = 0;
    public static final byte SCALE_MINOR = 1;

    public MetaKeySignature() {
        super(0, 0, (short) 89, new byte[2]);
    }

    protected MetaKeySignature(int t, int d, byte[] v) {
        super(t, d, (short) 89, v);
    }

    public byte getKey() {
        return this.value[0];
    }

    public void setKey(byte k) {
        this.value[0] = k;
    }

    public byte getScale() {
        return this.value[1];
    }

    public void setScale(byte s) {
        this.value[1] = s;
    }
}
