package net.duceng.midi;

/* JADX INFO: loaded from: classes7.dex */
public class MetaTempo extends EventMeta {
    public static final int DEFAULT_BPM = 120;
    public static final int DEFAULT_MPQN = 500000;
    private int bpm;
    private int mpqn;

    public MetaTempo() {
        super(0, 0, (short) 81, MidiUtil.intToBytes(DEFAULT_MPQN, 3));
        this.bpm = DEFAULT_BPM;
        this.mpqn = DEFAULT_MPQN;
    }

    protected MetaTempo(int t, int d, byte[] v) {
        super(t, d, (short) 81, v);
        this.mpqn = MidiUtil.bytesToInt(this.value, 0, 3);
        this.bpm = 60000000 / this.mpqn;
    }

    public int getMpqn() {
        return this.mpqn;
    }

    public void setMpqn(int m) {
        this.mpqn = m;
        this.bpm = 60000000 / this.mpqn;
        byte[] buffer = MidiUtil.intToBytes(this.mpqn, 3);
        for (int i = 0; i < 3; i++) {
            this.value[i] = buffer[i];
        }
    }

    public int getBpm() {
        return this.bpm;
    }

    public void setBpm(int b) {
        setMpqn(60000000 / b);
    }
}
