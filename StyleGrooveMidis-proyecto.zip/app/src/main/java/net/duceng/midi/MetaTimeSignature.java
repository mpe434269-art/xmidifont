package net.duceng.midi;

/* JADX INFO: loaded from: classes7.dex */
public class MetaTimeSignature extends EventMeta {
    public static final byte DEFAULT_DENOMINATOR = 2;
    public static final byte DEFAULT_DIVISION = 8;
    public static final byte DEFAULT_METER = 24;
    public static final byte DEFAULT_NUMERATOR = 4;

    public MetaTimeSignature() {
        super(0, 0, (short) 88, new byte[4]);
        this.value[0] = 4;
        this.value[1] = 2;
        this.value[2] = DEFAULT_METER;
        this.value[3] = 8;
    }

    protected MetaTimeSignature(int t, int d, byte[] v) {
        super(t, d, (short) 88, v);
    }

    public byte getNumerator() {
        return this.value[0];
    }

    public void setNumerator(byte n) {
        this.value[0] = n;
    }

    public byte getDenominator() {
        return this.value[1];
    }

    public void setDenominator(byte d) {
        this.value[1] = d;
    }

    public byte getMeter() {
        return this.value[2];
    }

    public byte getDivision() {
        return this.value[3];
    }
}
