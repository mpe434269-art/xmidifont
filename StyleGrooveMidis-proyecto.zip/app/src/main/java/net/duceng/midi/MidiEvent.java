package net.duceng.midi;

import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/* JADX INFO: loaded from: classes7.dex */
public abstract class MidiEvent implements Comparable<MidiEvent> {
    private static int lastId = -1;
    protected int delta;
    protected int tick;

    public MidiEvent(int t, int d) {
        this.tick = t;
        this.delta = d;
    }

    public int getTick() {
        return this.tick;
    }

    public void setTick(int t) {
        this.tick = t;
    }

    public int getDelta() {
        return this.delta;
    }

    public void setDelta(int d) {
        this.delta = d;
    }

    protected int getSize() {
        return MidiUtil.vintToBytes(this.delta).length;
    }

    public void write(OutputStream out) throws IOException {
        out.write(MidiUtil.vintToBytes(this.delta));
    }

    public static final MidiEvent parse(int tick, int delta, InputStream in) throws IOException {
        byte v2;
        in.mark(1);
        int id = in.read();
        if (id <= 127 && lastId >= 128) {
            in.reset();
            id = lastId;
        }
        if (id >= 128 && id <= 239) {
            byte type = (byte) (id >> 4);
            byte channel = (byte) (id & 15);
            byte v1 = (byte) in.read();
            if (type != 12 && type != 13) {
                byte v3 = (byte) in.read();
                v2 = v3;
            } else {
                v2 = 0;
            }
            lastId = id;
            return new EventChannel(tick, delta, type, channel, v1, v2);
        }
        if (id == 255) {
            short type2 = (short) in.read();
            int size = MidiUtil.readVInt(in);
            byte[] buff = new byte[size];
            MidiUtil.readFully(in, buff);
            lastId = id;
            if (type2 == 81) {
                return new MetaTempo(tick, delta, buff);
            }
            if (type2 == 89) {
                return new MetaKeySignature(tick, delta, buff);
            }
            if (type2 == 88) {
                return new MetaTimeSignature(tick, delta, buff);
            }
            return new EventMeta(tick, delta, type2, buff);
        }
        if (id == 240 || id == 247) {
            int size2 = MidiUtil.readVInt(in);
            byte[] buff2 = new byte[size2];
            MidiUtil.readFully(in, buff2);
            lastId = id;
            return new EventSystemExecusive(tick, delta, (short) id, buff2);
        }
        Log.i("MidiEvent", "Unable to read event, skipping: " + id);
        return null;
    }

    public String toString() {
        return this.tick + " (" + this.delta + "): " + getClass().getSimpleName();
    }
}
