package net.duceng.midi;

import java.io.IOException;
import java.io.InputStream;

/* JADX INFO: loaded from: classes7.dex */
public class MidiUtil {
    private static final String HEX = "0123456789ABCDEF";

    public static int ticksToMs(int ticks, int mpqn, int resolution) {
        return (int) (((((long) ticks) * ((long) mpqn)) / 1000) / ((long) resolution));
    }

    public static int msToTicks(int ms, int mpqn, int resolution) {
        return (int) (((((long) ms) * 1000) * ((long) resolution)) / ((long) mpqn));
    }

    public static int bpmToMpqn(int bpm) {
        return 60000000 / bpm;
    }

    public static int mpqnToBpm(int mpqn) {
        return 60000000 / mpqn;
    }

    public static byte[] intToBytes(int val) {
        byte[] buff = {(byte) ((val >> 24) & 255), (byte) ((val >> 16) & 255), (byte) ((val >> 8) & 255), (byte) (val & 255)};
        return buff;
    }

    public static byte[] vintToBytes(int val) {
        byte b1 = (byte) ((val >> 21) & 127);
        byte b2 = (byte) ((val >> 14) & 127);
        byte b3 = (byte) ((val >> 7) & 127);
        byte b4 = (byte) (val & 127);
        if (b1 > 0) {
            byte[] buff = {(byte) (b1 | 128), (byte) (b2 | 128), (byte) (b3 | 128), b4};
            return buff;
        }
        if (b2 > 0) {
            byte[] buff2 = {(byte) (b2 | 128), (byte) (b3 | 128), b4};
            return buff2;
        }
        if (b3 > 0) {
            byte[] buff3 = {(byte) (b3 | 128), b4};
            return buff3;
        }
        byte[] buff4 = {b4};
        return buff4;
    }

    public static int bytesToInt(byte[] buff, int off, int len) {
        int num = 0;
        int shift = 0;
        for (int i = (off + len) - 1; i >= off; i--) {
            num += (buff[i] & 255) << shift;
            shift += 8;
        }
        return num;
    }

    public static int readFully(InputStream in, byte[] buf) throws IOException {
        int n;
        int off = 0;
        while (off < buf.length && (n = in.read(buf, off, buf.length - off)) > 0) {
            off += n;
        }
        return off;
    }

    public static String readString(InputStream in, int size) throws IOException {
        byte[] buffer = new byte[size];
        in.read(buffer);
        return new String(buffer);
    }

    public static int readInt(InputStream in) throws IOException {
        int byte1 = in.read();
        int byte2 = in.read();
        int byte3 = in.read();
        int byte4 = in.read();
        return (byte1 << 24) | (byte2 << 16) | (byte3 << 8) | byte4;
    }

    public static int readVInt(InputStream in) throws IOException {
        int[] ints = new int[4];
        int mSizeInBytes = 1;
        int mValue = 0;
        int shift = 0;
        int b = in.read();
        while (mSizeInBytes <= 4) {
            boolean variable = (b & 128) > 0;
            if (!variable) {
                ints[mSizeInBytes - 1] = b & 127;
                break;
            }
            ints[mSizeInBytes - 1] = b & 127;
            b = in.read();
            mSizeInBytes++;
        }
        for (int i = 1; i < mSizeInBytes; i++) {
            shift += 7;
        }
        byte[] mBytes = new byte[mSizeInBytes];
        for (int i2 = 0; i2 < mSizeInBytes; i2++) {
            mBytes[i2] = (byte) ints[i2];
            mValue += ints[i2] << shift;
            shift -= 7;
        }
        return mValue;
    }

    public static byte[] intToBytes(int val, int byteCount) {
        byte[] buffer = new byte[byteCount];
        int[] ints = new int[byteCount];
        for (int i = 0; i < byteCount; i++) {
            ints[i] = val & 255;
            buffer[(byteCount - i) - 1] = (byte) ints[i];
            val >>= 8;
            if (val == 0) {
                break;
            }
        }
        return buffer;
    }

    public static boolean bytesEqual(byte[] buf1, byte[] buf2, int off, int len) {
        for (int i = off; i < off + len; i++) {
            if (i >= buf1.length || i >= buf2.length || buf1[i] != buf2[i]) {
                return false;
            }
        }
        return true;
    }

    public static byte[] extractBytes(byte[] buffer, int off, int len) {
        byte[] ret = new byte[len];
        for (int i = 0; i < len; i++) {
            ret[i] = buffer[off + i];
        }
        return ret;
    }

    public static String byteToHex(byte b) {
        int high = (b & 240) >> 4;
        int low = b & StySection.Phrase2;
        return new StringBuilder().append(HEX.charAt(high)).append(HEX.charAt(low)).toString();
    }

    public static String bytesToHex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte b2 : b) {
            sb.append(byteToHex(b2)).append(" ");
        }
        return sb.toString();
    }
}
