package net.duceng.midi;

/* JADX INFO: loaded from: classes7.dex */
public class StyControl {
    protected static final byte Bass = 3;
    protected static final byte Bypass = 0;
    protected static final byte Chord = 2;
    private static StyControl DEFAULT = null;
    protected static final byte HarmonicMinor = 5;
    protected static final byte MelodicMinor = 4;
    protected static final byte Melody = 1;
    protected static final byte RootFix = 1;
    protected static final byte RootTran = 0;
    protected byte chord;
    protected byte[] chordMute;
    protected byte destination;
    protected byte editable;
    protected byte highLimit;
    protected byte highkey;
    protected byte lowLimit;
    protected String name;
    protected byte[] noteMute;
    protected byte noteRule;
    protected byte noteTable;
    protected byte ntt;
    protected byte retriggerRule;
    protected byte root;
    protected byte source;

    public StyControl(byte[] data) {
        this(data, false);
    }

    /**
     * @param v2 true para la tabla "Ctb2" (SFF2): tiene dos bytes extra (rango de la fuente)
     *           antes de NTR/NTT, y el bit 7 de NTT es un indicador de bajo.
     */
    public StyControl(byte[] data, boolean v2) {
        this.noteMute = new byte[2];
        this.chordMute = new byte[5];
        this.source = data[0];
        this.name = new String(data, 1, 8);
        this.destination = data[9];
        this.editable = data[10];
        System.arraycopy(data, 11, this.noteMute, 0, this.noteMute.length);
        System.arraycopy(data, 13, this.chordMute, 0, this.chordMute.length);
        this.root = data[18];
        this.chord = data[19];
        if (v2 && data.length >= 28) {
            this.noteRule = data[22];
            this.noteTable = (byte) (data[23] & 0x7F);
            this.highkey = data[24];
            this.lowLimit = data[25];
            this.highLimit = data[26];
            this.retriggerRule = data[27];
        } else {
            this.noteRule = data[20];
            this.noteTable = data[21];
            this.highkey = data[22];
            this.lowLimit = data[23];
            this.highLimit = data[24];
            this.retriggerRule = data[25];
        }
    }

    public static StyControl defaultFor(int ch) {
        byte[] d = new byte[27];
        d[0] = (byte) ch;
        byte[] nm = ("Ch" + ch + "     ").getBytes();
        System.arraycopy(nm, 0, d, 1, 8);
        d[9] = (byte) ch;
        d[10] = 1;
        d[11] = StySection.Phrase2;
        d[12] = -1;
        d[18] = 0;
        int i = 2;
        d[19] = 2;
        boolean rhythm = ch == 8 || ch == 9;
        d[20] = (byte) (rhythm ? 1 : 0);
        if (rhythm) {
            i = 0;
        } else if (ch == 10) {
            i = 3;
        } else if (ch == 14 || ch == 15) {
            i = 1;
        }
        d[21] = (byte) i;
        d[22] = (byte) (rhythm ? 6 : 7);
        d[23] = (byte) (ch == 10 ? 28 : 0);
        d[24] = 127;
        d[25] = 1;
        return new StyControl(d);
    }

    private StyControl() {
        this.noteMute = new byte[2];
        this.chordMute = new byte[5];
        this.source = (byte) -1;
        this.destination = (byte) -1;
        this.name = "DEFAULT";
        this.root = (byte) 0;
        this.chord = (byte) 2;
        this.noteRule = (byte) -1;
        this.noteTable = (byte) -1;
        this.highkey = (byte) 11;
        this.lowLimit = (byte) 0;
        this.highLimit = (byte) 127;
        this.retriggerRule = (byte) -1;
    }

    protected static StyControl getDefault() {
        if (DEFAULT == null) {
            DEFAULT = new StyControl();
        }
        return DEFAULT;
    }
}
