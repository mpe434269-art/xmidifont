package net.duceng.midi;

import android.util.Log;
import android.util.SparseArray;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;
import net.duceng.xsynth.XSynth;

/* JADX INFO: loaded from: classes7.dex */
public class StyFile {
    public static final String HEAD = "MThd";
    private int count;
    private String identifier;
    private int resolution;
    private MetaTempo tempo;
    private MetaTimeSignature timeSignature;
    private StyTrack track;
    private int type;
    private ArrayList<MidiEvent> head = new ArrayList<>();
    private ArrayList<MidiEvent> sint = new ArrayList<>();
    private Map<String, StySection> sections = new TreeMap(new CompratorSection(null));

    private static class CompratorSection implements Comparator<String> {
        private CompratorSection() {
        }

        CompratorSection(CompratorSection compratorSection) {
            this();
        }

        @Override // java.util.Comparator
        public int compare(String lhs, String rhs) {
            if (lhs.matches("Main.*")) {
                if (rhs.matches("Main.*")) {
                    return lhs.compareTo(rhs);
                }
                return 1;
            }
            if (lhs.matches("Intro.*")) {
                if (rhs.matches("Intro.*")) {
                    return lhs.compareTo(rhs);
                }
                rhs.matches("Ending.*");
                return -1;
            }
            if (lhs.matches("Ending.*")) {
                if (rhs.matches("Ending.*")) {
                    return lhs.compareTo(rhs);
                }
                return !rhs.matches("Intro.*") ? -1 : 1;
            }
            if (lhs.matches("Fill In.*")) {
                if (rhs.matches("Main.*")) {
                    return -1;
                }
                if (rhs.matches("Intro.*")) {
                    return 1;
                }
                return lhs.compareTo(rhs);
            }
            return lhs.compareTo(rhs);
        }
    }

    private static int u32(byte[] b, int p) {
        return ((b[p] & 255) << 24) | ((b[p + 1] & 255) << 16) | ((b[p + 2] & 255) << 8) | (b[p + 3] & 255);
    }

    private static String ascii(byte[] b, int p, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n && p + i < b.length; i++) {
            sb.append((char) (b[p + i] & 255));
        }
        return sb.toString();
    }

    private static String cleanName(String raw) {
        return raw.replace("\u0000", "").trim();
    }

    private static boolean isSectionName(String m) {
        return m.matches("Main.*") || m.matches("Intro.*") || m.matches("Fill In.*") || m.matches("Ending.*") || m.matches("Break.*");
    }

    private static byte[] readAll(InputStream is) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[32768];
        while (true) {
            int n = is.read(buf);
            if (n > 0) {
                bo.write(buf, 0, n);
            } else {
                return bo.toByteArray();
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:106:0x01e6 */
    /* JADX WARN: Code duplicated, block: B:107:0x019f */
    /* JADX WARN: Code duplicated, block: B:115:0x01e3 */
    /* JADX WARN: Code duplicated, block: B:66:0x018f */
    /* JADX WARN: Code duplicated, block: B:71:0x01b1 */
    /* JADX WARN: Code duplicated, block: B:73:0x01bb */
    /* JADX WARN: Code duplicated, block: B:74:0x01c7 */
    /* JADX WARN: Code duplicated, block: B:79:0x01d4 */
    /* JADX WARN: Code duplicated, block: B:81:0x01d8 */
    /* JADX WARN: Code duplicated, block: B:88:0x0241 */
    public StyFile(InputStream is) throws IOException {
        int chunkStart;
        ArrayList<MidiEvent> list;
        this.identifier = null;
        byte[] all = XSynth.adaptSafe(readAll(is));
        if (all.length < 22 || !ascii(all, 0, 4).equals("MThd")) {
            throw new RuntimeException("File identifier not MThd. Exiting");
        }
        short s = 6;
        int headLen = Math.max(6, u32(all, 4));
        this.type = MidiUtil.bytesToInt(all, 8, 2);
        this.count = MidiUtil.bytesToInt(all, 10, 2);
        this.resolution = MidiUtil.bytesToInt(all, 12, 2);
        if (this.type > 1 || this.count < 1 || this.resolution <= 0) {
            throw new RuntimeException("This File is not YAMAHA sty. Exiting");
        }
        int trackPos2 = headLen + 8;
        ByteArrayInputStream in2 = new ByteArrayInputStream(all, trackPos2, all.length - trackPos2);
        this.track = new StyTrack(in2);
        int parsedEnd = all.length - in2.available();
        int declaredEnd = this.track.getSize() + trackPos2 + 8;
        if (declaredEnd >= parsedEnd && declaredEnd + 8 <= all.length && ascii(all, declaredEnd, 4).matches("[A-Za-z0-9 ]{4}")) {
            chunkStart = declaredEnd;
        } else {
            chunkStart = parsedEnd;
        }
        int tick = 0;
        ArrayList<MidiEvent> list2 = null;
        for (MidiEvent e2 : this.track.events) {
            if ((e2 instanceof EventMeta) && ((EventMeta) e2).type == s) {
                String mark = cleanName(new String(((EventMeta) e2).value));
                if (mark.matches("SFF.*")) {
                    this.identifier = mark;
                    list = this.head;
                } else if (mark.equals("SInt")) {
                    list = this.sint;
                } else if (isSectionName(mark)) {
                    StySection s2 = new StySection(mark);
                    this.sections.put(mark, s2);
                    list = s2.getEvents();
                } else {
                    list = null;
                }
                tick = 0;
                list2 = list;
            } else if (list2 != null) {
                tick += e2.delta;
                e2.tick = tick;
                list2.add(e2);
            }
            s = 6;
        }
        int p = chunkStart;
        while (p + 8 <= all.length) {
            try {
                String chunkTag = ascii(all, p, 4);
                int size = u32(all, p + 4);
                if (size < 0) {
                    break;
                }
                if (((long) (p + 8)) + ((long) size) > ((long) all.length)) {
                    size = all.length - (p + 8);
                }
                if (chunkTag.equals("CASM")) {
                    parseCasm(all, p + 8, p + 8 + size);
                }
                p += size + 8;
            } catch (RuntimeException ex) {
                Log.i("XMidi", "CASM ilegible, se usan tablas por defecto: " + ex);
                break;
            }
        }
        for (StySection ss : this.sections.values()) {
            if (ss.getControls().size() == 0) {
                boolean[] usedCh = new boolean[16];
                for (MidiEvent ev : ss.getEvents()) {
                    if (ev instanceof EventChannel) {
                        usedCh[((EventChannel) ev).channel & StySection.Phrase2] = true;
                    }
                }
                for (int c = 8; c < 16; c++) {
                    if (usedCh[c]) {
                        ss.getControls().put(c, StyControl.defaultFor(c));
                    }
                }
            }
        }
        Log.i("XMidi", "Load StyFile, resolution:" + getResolution() + " tempo:" + getTempo().getBpm() + " identifier:" + this.identifier + " sections:" + this.sections.size());
        for (StySection ss3 : this.sections.values()) {
            ss3.init(this);
        }
    }

    private void parseCasm(byte[] b, int start, int end) {
        int p = start;
        while (p + 8 <= end) {
            String tag = ascii(b, p, 4);
            int size = u32(b, p + 4);
            int bodyEnd = (size < 0 || (((long) p) + 8) + ((long) size) > ((long) end)) ? end : p + 8 + size;
            if (tag.equals("CSEG")) {
                parseCseg(b, p + 8, bodyEnd);
            }
            p = bodyEnd;
        }
    }

    private void parseCseg(byte[] b, int start, int end) {
        ArrayList<String> names = new ArrayList<>();
        ArrayList<byte[]> ctabs = new ArrayList<>();
        ArrayList<byte[]> ctb2s = new ArrayList<>();
        ArrayList<byte[]> cntts = new ArrayList<>();
        int q = start;
        while (true) {
            if (q + 8 > end) {
                break;
            }
            String tag = ascii(b, q, 4);
            int size = u32(b, q + 4);
            int bodyEnd = (size < 0 || (((long) q) + 8) + ((long) size) > ((long) end)) ? end : q + 8 + size;
            byte[] data = Arrays.copyOfRange(b, q + 8, bodyEnd);
            if (tag.equals("Sdec")) {
                for (String str : ascii(data, 0, data.length).split(",")) {
                    String cn = cleanName(str);
                    if (cn.length() > 0) {
                        names.add(cn);
                    }
                }
            } else if (tag.equals("Ctab") && data.length >= 26) {
                ctabs.add(Arrays.copyOf(data, Math.max(27, data.length)));
            } else if (tag.equals("Ctb2") && data.length >= 26) {
                ctb2s.add(Arrays.copyOf(data, Math.max(28, data.length)));
            } else if (tag.equals("Cntt") && data.length >= 2) {
                cntts.add(data);
            }
            q = bodyEnd;
        }
        ArrayList<StySection> targets = new ArrayList<>();
        for (String n : names) {
            if (this.sections.containsKey(n)) {
                targets.add(this.sections.get(n));
            }
        }
        if (targets.isEmpty()) {
            return;
        }
        SparseArray<StyControl> map = new SparseArray<>();
        for (byte[] t : ctabs) {
            StyControl sc = new StyControl(t);
            map.put(sc.source, sc);
        }
        for (byte[] t2 : ctb2s) {
            StyControl sc2 = new StyControl(t2, true);
            if (map.indexOfKey(sc2.source) < 0) {
                map.put(sc2.source, sc2);
            }
        }
        for (byte[] c : cntts) {
            if (map.indexOfKey(c[0]) >= 0) {
                map.get(c[0]).ntt = c[1];
            }
        }
        for (StySection s : targets) {
            for (int i = 0; i < map.size(); i++) {
                s.getControls().put(map.keyAt(i), map.valueAt(i));
            }
        }
    }

    public int getBarTicks() {
        MetaTimeSignature ts = getTimeSignature();
        int num = Math.max(1, (int) ts.getNumerator());
        int den = 1 << Math.max(0, Math.min(6, (int) ts.getDenominator()));
        return Math.max(1, ((this.resolution * 4) * num) / den);
    }

    public int getBeatTicks() {
        int den = 1 << Math.max(0, Math.min(6, (int) getTimeSignature().getDenominator()));
        return Math.max(1, (this.resolution * 4) / den);
    }

    public int getType() {
        return this.type;
    }

    public int getCount() {
        return this.count;
    }

    public int getResolution() {
        return this.resolution;
    }

    public MetaTempo getTempo() {
        if (this.tempo != null) {
            return this.tempo;
        }
        for (MidiEvent e : this.track.getEvents()) {
            if (e instanceof MetaTempo) {
                this.tempo = (MetaTempo) e;
                return this.tempo;
            }
        }
        this.tempo = new MetaTempo();
        return this.tempo;
    }

    public MetaTimeSignature getTimeSignature() {
        if (this.timeSignature != null) {
            return this.timeSignature;
        }
        for (MidiEvent e : this.track.getEvents()) {
            if (e instanceof MetaTimeSignature) {
                this.timeSignature = (MetaTimeSignature) e;
                return this.timeSignature;
            }
        }
        this.timeSignature = new MetaTimeSignature();
        return this.timeSignature;
    }

    public StyTrack getTrack() {
        return this.track;
    }

    public String getIdentifier() {
        return this.identifier;
    }

    public ArrayList<MidiEvent> getHead() {
        return this.head;
    }

    public ArrayList<MidiEvent> getSint() {
        return this.sint;
    }

    public Map<String, StySection> getSections() {
        return this.sections;
    }

    public StySection getSection(String key) {
        return this.sections.get(key);
    }

    public boolean containsSection(String key) {
        return this.sections.containsKey(key);
    }
}
