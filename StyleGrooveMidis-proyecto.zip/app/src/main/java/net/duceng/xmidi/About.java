package net.duceng.xmidi;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import net.duceng.xmidi.util.AdapterAbout;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes3.dex */
public class About extends Base {
    @Override // net.duceng.xmidi.Base, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.about);
        this.title.setText(R.string.about);
        ListView list = (ListView) findViewById(R.id.about_list);
        AdapterAbout adapter = new AdapterAbout(this);
        list.setAdapter((ListAdapter) adapter);
        LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.action_about, (ViewGroup) null);
        while (layout.getChildCount() > 0) {
            View child = layout.getChildAt(0);
            layout.removeView(child);
            this.listBottom.add(child);
            child.setOnClickListener(this.actionClickListener);
        }
    }

    @Override // net.duceng.xmidi.Base
    protected void onActionClick(View v) {
        super.onActionClick(v);
    }
}
