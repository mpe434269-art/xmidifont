package net.duceng.xmidi;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import net.duceng.midi.MidiFile;
import net.duceng.xmidi.ui.DialogExplorer;
import net.duceng.xmidi.ui.DialogMidi;
import net.duceng.xmidi.ui.DialogTrack;
import net.duceng.xmidi.ui.XDialog;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes3.dex */
public abstract class BaseApp extends Base {
    private DialogExplorer dialogFile;
    protected String[] drums;
    protected String[] instruments;
    protected Synth synth;

    @Override // net.duceng.xmidi.Base, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.synth = Synth.getInstance();
        this.instruments = getResources().getStringArray(R.array.preset_instruments);
        this.drums = getResources().getStringArray(R.array.preset_drums);
        LinearLayout linearLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.menu_fixed, (ViewGroup) null);
        while (linearLayout.getChildCount() > 0) {
            View childAt = linearLayout.getChildAt(0);
            linearLayout.removeView(childAt);
            this.listMore.add(childAt);
            childAt.setOnClickListener(this.menuClickListener);
        }
        LinearLayout linearLayout2 = (LinearLayout) getLayoutInflater().inflate(R.layout.action_top, (ViewGroup) null);
        while (linearLayout2.getChildCount() > 0) {
            View childAt2 = linearLayout2.getChildAt(0);
            linearLayout2.removeView(childAt2);
            this.listTop.add(childAt2);
            childAt2.setOnClickListener(this.actionClickListener);
            if (childAt2.getId() == R.id.act_play) {
                childAt2.setOnLongClickListener(new View.OnLongClickListener() { // from class: net.duceng.xmidi.BaseApp.1
                    @Override // android.view.View.OnLongClickListener
                    public boolean onLongClick(View v) {
                        BaseApp.this.synth.stop();
                        ImageButton ibMidi = (ImageButton) BaseApp.this.findViewById(R.id.act_play);
                        ibMidi.getDrawable().setLevel(0);
                        return true;
                    }
                });
            }
        }
        LinearLayout linearLayout3 = (LinearLayout) getLayoutInflater().inflate(R.layout.action_bottom, (ViewGroup) null);
        while (linearLayout3.getChildCount() > 0) {
            View childAt3 = linearLayout3.getChildAt(0);
            linearLayout3.removeView(childAt3);
            this.listBottom.add(childAt3);
            childAt3.setOnClickListener(this.actionClickListener);
            if (childAt3.getId() == R.id.act_beat) {
                ((ImageButton) childAt3).getDrawable().setLevel(this.synth.isBeating() ? 1 : 0);
                childAt3.setOnLongClickListener(new View.OnLongClickListener() { // from class: net.duceng.xmidi.BaseApp.2
                    private DialogMidi dialogSynth;

                    @Override // android.view.View.OnLongClickListener
                    public boolean onLongClick(View v) {
                        if (this.dialogSynth == null) {
                            this.dialogSynth = new DialogMidi(BaseApp.this, BaseApp.this.synth);
                        }
                        this.dialogSynth.show();
                        return true;
                    }
                });
            } else if (childAt3.getId() == R.id.act_record) {
                View.OnLongClickListener onLongClickListener = new View.OnLongClickListener() { // from class: net.duceng.xmidi.BaseApp.3
                    private EditText et;
                    private XDialog save;

                    @Override // android.view.View.OnLongClickListener
                    public boolean onLongClick(View v) {
                        if (this.save == null) {
                            this.save = new XDialog(BaseApp.this);
                            this.et = new EditText(BaseApp.this);
                            final EditText etFinal = this.et;
                            this.save.setTitle(R.string.save);
                            this.save.setContentView(this.et);
                            this.save.getWapper().setPadding(12, 12, 12, 12);
                            this.save.addButton(R.string.save, new View.OnClickListener() { // from class: net.duceng.xmidi.BaseApp.3.1
                                @Override // android.view.View.OnClickListener
                                public void onClick(View v2) {
                                    BaseApp.this.saveFile(etFinal.getText().toString());
                                }
                            });
                            this.save.addButton(R.string.discard, new View.OnClickListener() { // from class: net.duceng.xmidi.BaseApp.3.2
                                @Override // android.view.View.OnClickListener
                                public void onClick(View v2) {
                                    BaseApp.this.synth.getRecordTrack().getEvents().clear();
                                }
                            });
                            this.save.addButton(R.string.cancel, null);
                        }
                        Date d = new Date();
                        SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss", Locale.US);
                        this.et.setText(String.valueOf(sdf.format(d)) + ".mid");
                        this.save.show();
                        return true;
                    }
                };
                childAt3.setOnLongClickListener(onLongClickListener);
                childAt3.setTag(onLongClickListener);
            }
        }
        this.title.setBackgroundResource(R.drawable.bg_spinner);
        this.title.setPadding(4, 0, 8, 0);
        this.title.setClickable(true);
        this.title.setOnClickListener(this.actionClickListener);
        this.title.setOnLongClickListener(new View.OnLongClickListener() { // from class: net.duceng.xmidi.BaseApp.4
            private DialogTrack dialogTrack;

            @Override // android.view.View.OnLongClickListener
            public boolean onLongClick(View v) {
                if (BaseApp.this.synth.getFile() != null) {
                    if (this.dialogTrack == null) {
                        this.dialogTrack = new DialogTrack(BaseApp.this, BaseApp.this.synth);
                        this.dialogTrack.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: net.duceng.xmidi.BaseApp.4.1
                            @Override // android.content.DialogInterface.OnDismissListener
                            public void onDismiss(DialogInterface dialog) {
                                BaseApp.this.onTrackChanged();
                            }
                        });
                    }
                    this.dialogTrack.show();
                    return true;
                }
                return true;
            }
        });
    }

    @Override // net.duceng.xmidi.Base, android.app.Activity
    protected void onStart() {
        this.title.setTag(this.title.getText());
        if (this.synth.getFile() != null) {
            onMidiChanged(this.synth.getFile());
        }
        super.onStart();
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        this.synth.stop();
        this.synth.setBeating(false);
        this.synth.freeInstance();
        System.gc();
        super.onDestroy();
    }

    @Override // android.app.Activity
    public boolean onPrepareOptionsMenu(Menu menu) {
        showMenu();
        return false;
    }

    @Override // net.duceng.xmidi.Base
    protected void onActionClick(View view) {
        switch (view.getId()) {
            case R.id.act_beat /* 2130968578 */:
                this.synth.setBeating(true ^ this.synth.isBeating());
                ((ImageButton) findViewById(R.id.act_beat)).getDrawable().setLevel(this.synth.isBeating() ? 1 : 0);
                break;
            case R.id.act_drums /* 2130968579 */:
                finish();
                startActivity(new Intent(this, (Class<?>) Drums.class));
                break;
            case R.id.act_guitar /* 2130968581 */:
                finish();
                startActivity(new Intent(this, (Class<?>) Guitar.class));
                break;
            case R.id.act_keyboard /* 2130968582 */:
                finish();
                startActivity(new Intent(this, (Class<?>) Keyboard.class));
                break;
            case R.id.act_metronome /* 2130968583 */:
                finish();
                startActivity(new Intent(this, (Class<?>) Metronome.class));
                break;
            case R.id.act_play /* 2130968584 */:
                if (this.synth.isPlaying()) {
                    this.synth.pause();
                } else {
                    this.synth.play();
                }
                ((ImageButton) findViewById(R.id.act_play)).getDrawable().setLevel(this.synth.isPlaying() ? 1 : 2);
                break;
            case R.id.act_record /* 2130968585 */:
                this.synth.setRecording(true ^ this.synth.isRecording());
                ImageButton imageButton = (ImageButton) findViewById(R.id.act_record);
                imageButton.getDrawable().setLevel(this.synth.isRecording() ? 1 : 0);
                if (!this.synth.isRecording()) {
                    ((View.OnLongClickListener) imageButton.getTag()).onLongClick(imageButton);
                }
                break;
            case R.id.title /* 2130968769 */:
                showMidi();
                break;
            default:
                super.onActionClick(view);
                break;
        }
    }

    public void saveFile(String fileName) {
        File f = new File(String.valueOf(Synth.PATH_RECORD) + "/" + fileName);
        MidiFile mf = this.synth.getMidiFile();
        if (this.synth.getRecordTrack() != null) {
            mf.addTrack(this.synth.getRecordTrack());
        }
        try {
            FileOutputStream fos = new FileOutputStream(f);
            mf.write(fos);
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected String getPresetName(int ch) {
        int p = this.synth.getPreset(ch);
        boolean isdrum = this.synth.getBank(ch) == Synth.DRUMS_BANK;
        if (getResources().getConfiguration().orientation == 1) {
            return String.valueOf(ch) + ":" + (isdrum ? this.drums[p / 8] : this.instruments[p]);
        }
        return String.valueOf(ch) + ":" + (isdrum ? String.valueOf(p) + "X" : Integer.valueOf(p));
    }

    private void showMidi() {
        if (this.dialogFile == null) {
            this.dialogFile = new DialogExplorer(this, this.synth);
            this.dialogFile.setOnSelectListener(new DialogExplorer.OnSelectListener() { // from class: net.duceng.xmidi.BaseApp.5
                @Override // net.duceng.xmidi.ui.DialogExplorer.OnSelectListener
                public void onSelect(File f) {
                    BaseApp.this.onMidiChanged(f);
                    BaseApp.this.dialogFile.dismiss();
                }
            });
        }
        this.dialogFile.show();
    }

    protected void onMidiChanged(File f) {
        if (this.synth.getFile() == null || !this.synth.getFile().equals(f)) {
            this.synth.setFile(f);
        }
        if (f != null && f.exists()) {
            this.title.setText(f.getName());
        } else if (this.title.getTag() != null) {
            this.title.setText((String) this.title.getTag());
        }
    }

    protected void onTrackChanged() {
    }
}
