package net.duceng.xmidi;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import net.duceng.midi.EventChannel;
import net.duceng.midi.MidiEvent;
import net.duceng.midi.StyFile;
import net.duceng.xmidi.ui.DialogChannel;
import net.duceng.xmidi.ui.DialogChord;
import net.duceng.xmidi.ui.DialogPercussion;
import net.duceng.xmidi.ui.DialogPreset;
import net.duceng.xmidi.ui.DialogSty;
import net.duceng.xmidi.ui.DialogTonality;
import net.duceng.xmidi.util.Chords;
import net.duceng.xmidi.util.Importer;
import net.duceng.xmidi.util.MyArray;
import net.duceng.xmidi.util.RightHand;
import net.duceng.xmidi.util.StyleEngine;
import net.duceng.xmidi.widgets.KeyPad;
import net.duceng.xmidi.widgets.PianoBoard;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;
import java.util.concurrent.ThreadFactory;

/**
 * Pantalla de ritmos (estilos .STY) con el panel de un teclado Yamaha SX600:
 * INTRO / MAIN / BREAK / ENDING con LEDs (naranja = sección actual, azul = disponible,
 * parpadeo al compás durante Fill In / Intro / Ending / Break), AUTO FILL IN, FADE IN/OUT,
 * VOICE RIGHT 1 y 2, SUSTAIN y HARMONY / ARPEGGIO.
 */
public class Drums extends BaseApp {
    private static final String PREF_CHORDS = "drums_chords18";
    private static final String PREF_STY = "drums_sty_path";
    private static final String PREF_TONALITY = "drums_tonality";
    private static final String PREF_VOICE1 = "drums_voice1_on";
    private static final String PREF_VOICE2 = "drums_voice2_on";
    private static final String PREF_HARM_TYPE = "drums_harmony_type";
    private static final String PREF_AUTO_FILL = "drums_auto_fill";
    private static final String PREF_STYLE_VOL = "drums_style_vol";
    private static final String PREF_HARM_ON = "drums_harmony_on";
    private static final String PREF_ARMED = "drums_armed";
    private static final String PREF_CHORD_SEL = "drums_chord_selected";
    private static final String PREF_VOICE_STATE = "drums_voice_state_";

    private static final int COLOR_ORANGE = 0xFFFFA21A;
    private static final int COLOR_BLUE = 0xFF29B6F6;
    private static final int COLOR_GOLD = 0xFFC9A55C;

    private static final String BREAK = "BREAK";
    private static final String[] INTRO = {"Intro A", "Intro B", "Intro C"};
    private static final String[] MAIN = {"Main A", "Main B", "Main C", "Main D"};
    private static final String[] ENDING = {"Ending A", "Ending B", "Ending C"};
    private static final String[] ROMAN = {"I", "II", "III"};
    private static final String[] LETTER = {"A", "B", "C", "D"};

    private static byte NOTE_BASE = (byte) 27;
    private static byte NOTE_CHAN = (byte) 9;
    private static String STY_DEFAULT = "Sample4.sty";
    private int[] notes15 = {9, 10, 11, 14, 16, 18, 20, 21, 23, 15, 17, 19, 22, 24, 26};

    // ---- vistas
    private ImageButton bAuto;
    private Button bKeyboard;
    private ImageButton bLock;
    private Button bPreset;
    private Button bSustain;
    private Button btnFile;
    private ImageButton btnPlay;
    private Button btnTonality;
    private ImageView drumIcon;
    private DialogChannel channDialog;
    private DialogChord dialogChordRef;
    private DialogPercussion dialogPercRef;
    private DialogSty dialogStyRef;
    private DialogTonality dialogTonalityRef;
    private DialogPreset keyboardPreset;
    private DialogPreset rhythmPreset;
    private final DialogPreset[] voiceDialogs = new DialogPreset[2];
    private final TextView[] voiceNames = new TextView[2];
    private final TextView[] voiceVols = new TextView[2];
    private final ImageView[] voiceToggles = new ImageView[2];
    private SeekBar seekTempo;
    private SeekBar seekStyleVol;
    private TextView tempoValue;
    private TextView styleVolValue;
    private View divh;
    private View divv;
    private LinearLayout layoutKeys;
    private LinearLayout layoutManual;
    private LinearLayout layoutTop;
    private PianoBoard piano;
    private Button drumLongBtn;
    private Button chordLongBtn;
    private final LinearLayout[] layoutBtns = new LinearLayout[5];
    private final Button[] btnChords = new Button[18];
    private final Button[] btnDrums = new Button[15];
    private final HashMap<String, KeyPad> padByName = new HashMap<String, KeyPad>();
    private KeyPad padAutoFill;
    private KeyPad padFade;
    private KeyPad padSustain;
    private KeyPad padHarmony;
    private Drawable sustainBg;

    // ---- motor / datos
    private StyleEngine engine;
    private StyFile styFile;
    private Chords.Chord chord;
    private final Chords gChords = new Chords();
    private RightHand rightHand;
    private Handler handler;
    private String[] percussions;

    // ---- estado
    private volatile boolean destroyed = false;
    private volatile boolean playing = false;
    private boolean auto = true;
    private boolean startedBySynth = false;
    private boolean sustainOn = false;
    private boolean metroOn = false;
    private boolean sectionTouched = false;
    private boolean autoFill = true;
    private boolean updatingUi = false;
    private int tonalityIndex = 0;
    private ArrayList<EventChannel> baseApplied = new ArrayList<EventChannel>();

    // ---- LEDs / parpadeo al compás
    private String armed = "Main A";   // sección elegida mientras el ritmo está parado
    private String curSec = null;      // sección que suena
    private String nextSec = null;     // sección que viene (parpadea)
    private String lastMainUi = null;
    private boolean breakFlag = false;
    private boolean blinkOn = false;
    /** Seccion pre-armada antes del play: "Intro X", "Ending X", BREAK o "FILL" (remate del MAIN elegido). */
    private String preStart = null;
    private final Runnable preBlink = new Runnable() {
        @Override
        public void run() {
            if (Drums.this.destroyed || Drums.this.preStart == null || Drums.this.playing) {
                return;
            }
            Drums.this.blinkOn = !Drums.this.blinkOn;
            Drums.this.refreshLeds();
            int mpqn = Drums.this.synth.getMidiFile().getTempo().getMpqn();
            Drums.this.handler.postDelayed(this, Math.max(120, (mpqn > 0 ? mpqn : 500000) / 2000));
        }
    };

    // ---- fade
    private float userGain = 1.0f;
    private float fadeGain = 1.0f;
    private boolean fadeArmed = false;
    private boolean fading = false;
    private boolean fadeIn = true;
    private long fadeStart = 0L;
    private int fadeDur = 3000;

    private final Runnable blinkOff = new Runnable() {
        @Override
        public void run() {
            Drums.this.blinkOn = false;
            Drums.this.refreshLeds();
        }
    };

    private final Runnable fadeTick = new Runnable() {
        @Override
        public void run() {
            if (Drums.this.destroyed || !Drums.this.fading) {
                return;
            }
            long el = SystemClock.uptimeMillis() - Drums.this.fadeStart;
            float t = Math.min(1.0f, el / (float) Drums.this.fadeDur);
            Drums.this.fadeGain = Drums.this.fadeIn ? t : 1.0f - t;
            Drums.this.applyStyleGain();
            Drums.this.padFade.setLed(((el / 200) % 2 == 0) ? KeyPad.LED_BLUE : KeyPad.LED_OFF);
            if (t >= 1.0f) {
                Drums.this.finishFade();
            } else {
                Drums.this.handler.postDelayed(this, 40L);
            }
        }
    };

    private final PianoBoard.PianoBoardListener keyListener = new PianoBoard.PianoBoardListener() {
        @Override
        public void onKeysChanged(int note, int val) {
            if (Drums.this.destroyed) {
                return;
            }
            if (val > 0) {
                Drums.this.rightHand.noteOn(note, val);
            } else {
                Drums.this.rightHand.noteOff(note);
            }
        }
    };

    private final View.OnTouchListener chordTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if ((event.getAction() & 255) == 0) {
                Drums.this.chordSelect((Button) v);
            }
            return false;
        }
    };

    private final View.OnLongClickListener chordLongClickListener = new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            Drums.this.chordLongBtn = (Button) v;
            if (Drums.this.dialogChordRef == null) {
                Drums.this.dialogChordRef = new DialogChord(Drums.this, Drums.this.gChords);
                Drums.this.dialogChordRef.setOnSelectListener(new DialogChord.OnSelectListener() {
                    @Override
                    public boolean onSelect(int idx) {
                        Chords.Chord c = Drums.this.gChords.getChord(idx);
                        Drums.this.chordLongBtn.setText(c.name);
                        Drums.this.chordLongBtn.setTag(c);
                        Drums.this.saveChords();
                        if (Drums.this.chordLongBtn.isSelected()) {
                            Drums.this.chord = c;
                            if (Drums.this.engine != null) {
                                Drums.this.engine.setChord(c);
                            }
                            Drums.this.applyHarmonyChord();
                        }
                        Drums.this.dialogChordRef.dismiss();
                        return true;
                    }
                });
            }
            Drums.this.dialogChordRef.show();
            return true;
        }
    };

    private final View.OnTouchListener drumTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            int action = event.getAction() & 255;
            if (action == 0) {
                Drums.this.synth.noteOn(((Integer) v.getTag()).byteValue(), (byte) 100);
                return false;
            }
            if (action == 1) {
                Drums.this.synth.noteOff(((Integer) v.getTag()).byteValue());
            }
            return false;
        }
    };

    private final View.OnLongClickListener drumLongClickListener = new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            Drums.this.drumLongBtn = (Button) v;
            if (Drums.this.dialogPercRef == null) {
                Drums.this.dialogPercRef = new DialogPercussion(Drums.this, Drums.this.percussions);
                Drums.this.dialogPercRef.setOnSelectListener(new DialogPercussion.OnSelectListener() {
                    @Override
                    public boolean onSelect(int idx) {
                        Drums.this.drumLongBtn.setText(Drums.this.percussions[idx]);
                        Drums.this.drumLongBtn.setTag(Integer.valueOf(Drums.NOTE_BASE + idx));
                        Drums.this.dialogPercRef.dismiss();
                        return true;
                    }
                });
            }
            Drums.this.dialogPercRef.show();
            return true;
        }
    };

    // =====================================================================
    //  Ciclo de vida
    // =====================================================================
    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drums);
        this.synth.setStyleMix(true);
        this.rightHand = new RightHand(this.synth);
        this.title.setText(R.string.drums);
        this.bPreset = this.title;
        this.title.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (Drums.this.rhythmPreset == null) {
                    Drums.this.rhythmPreset = new DialogPreset(Drums.this, Drums.this.synth);
                    Drums.this.rhythmPreset.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            Drums.this.bPreset.setText(Drums.this.getPresetName(Drums.this.synth.getRecordChan()));
                        }
                    });
                }
                Drums.this.rhythmPreset.setChannel(Drums.this.synth.getRecordChan());
                Drums.this.rhythmPreset.show();
                return true;
            }
        });
        for (int i = 0; i < this.listMore.size(); i++) {
            if (this.listMore.get(i).getId() == R.id.act_drums) {
                ((Button) this.listMore.get(i)).setBackgroundResource(R.color.focused);
                this.listMore.get(i).setVisibility(8);
                this.listMore.get(i + 1).setVisibility(8);
                break;
            }
        }
        LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.action_drums, (ViewGroup) null);
        while (layout.getChildCount() > 0) {
            View child = layout.getChildAt(0);
            layout.removeView(child);
            this.listBottom.add(child);
            child.setOnClickListener(this.actionClickListener);
            if (child.getId() == R.id.drums_keyboard) {
                this.bKeyboard = (Button) child;
            } else if (child.getId() == R.id.drums_sustain) {
                this.bSustain = (Button) child;
                if (child.getBackground() != null && child.getBackground().getConstantState() != null) {
                    this.sustainBg = child.getBackground().getConstantState().newDrawable();
                }
            } else if (child.getId() == R.id.drums_lock) {
                this.bLock = (ImageButton) child;
            } else if (child.getId() == R.id.drums_auto) {
                this.bAuto = (ImageButton) child;
            }
        }
        this.handler = new Handler();
        this.layoutTop = (LinearLayout) findViewById(R.id.drums_layout_top);
        this.layoutManual = (LinearLayout) findViewById(R.id.drums_layout_manual);
        this.layoutKeys = (LinearLayout) findViewById(R.id.drums_layout_keys);
        this.piano = (PianoBoard) findViewById(R.id.drums_piano);
        this.divh = findViewById(R.id.drums_divider_h0);
        this.divv = findViewById(R.id.drums_divider_v0);
        this.layoutBtns[0] = (LinearLayout) findViewById(R.id.drums_layout_btns0);
        this.layoutBtns[1] = (LinearLayout) findViewById(R.id.drums_layout_btns1);
        this.layoutBtns[2] = (LinearLayout) findViewById(R.id.drums_layout_btns2);
        this.layoutBtns[3] = (LinearLayout) findViewById(R.id.drums_layout_btns3);
        this.layoutBtns[4] = (LinearLayout) findViewById(R.id.drums_layout_btns4);
        this.drumIcon = (ImageView) findViewById(R.id.drums_icon);
        this.drumIcon.setColorFilter(COLOR_GOLD, PorterDuff.Mode.SRC_IN);
        this.percussions = getResources().getStringArray(R.array.preset_percussions);

        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        this.autoFill = pref.getBoolean(PREF_AUTO_FILL, true);
        this.rightHand.setVoiceEnabled(1, pref.getBoolean(PREF_VOICE1, true));
        this.rightHand.setVoiceEnabled(2, pref.getBoolean(PREF_VOICE2, false));
        this.rightHand.setType(pref.getInt(PREF_HARM_TYPE, 0));

        setupStyleHeader();
        setupChordButtons();
        setupDrumPads();
        setupSectionPads();
        setupVoicePanels();
        setupSliders();

        String savedSty = pref.getString(PREF_STY, null);
        if (savedSty != null && new File(savedSty).isFile()) {
            loadStyFile(new File(savedSty));
        }
        if (this.styFile == null) {
            loadStyFile(new File(String.valueOf(Synth.PATH_STY) + "/" + STY_DEFAULT));
        }
        restoreChords();
        restoreSession(pref);
        for (int i = 0; i < this.notes15.length; i++) {
            this.btnDrums[i].setText(this.percussions[this.notes15[i]]);
            this.btnDrums[i].setTag(Integer.valueOf(this.notes15[i] + NOTE_BASE));
        }
        this.synth.setBeatListener(new Synth.BeatListener() {
            @Override // net.duceng.xsynth.Synth.BeatListener
            public void onBeating(long ticks) {
                StyleEngine en = Drums.this.engine;
                if (en == null || !Drums.this.auto || !Drums.this.sectionTouched) {
                    return;
                }
                if (en.isRunning()) {
                    en.sync();
                } else if (Drums.this.synth.isPlaying()) {
                    Drums.this.startedBySynth = true;
                    Drums.this.handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Drums.this.play();
                        }
                    });
                }
            }
        });
        setupKeyboard();
        applyStyleGain();
        updateToggleLeds();
        updateVoiceUi();
        refreshLeds();
    }

    @Override // net.duceng.xmidi.BaseApp
    protected void onMidiChanged(File f) {
        this.bPreset.setText(getPresetName(this.synth.getRecordChan()));
    }

    @Override // android.app.Activity
    protected void onPause() {
        saveSession();
        if (this.piano != null) {
            this.piano.releaseAll();
        }
        if (this.rightHand != null) {
            this.rightHand.releaseAll();
        }
        super.onPause();
    }

    @Override // net.duceng.xmidi.BaseApp, android.app.Activity
    protected void onDestroy() {
        this.destroyed = true;
        this.playing = false;
        this.handler.removeCallbacks(this.fadeTick);
        this.handler.removeCallbacks(this.blinkOff);
        this.handler.removeCallbacks(this.preBlink);
        this.synth.setBeatListener(null);
        this.synth.setStyleGain(1.0f);
        this.rightHand.releaseAll();
        if (this.engine != null) {
            this.engine.stopAndWait(500L);
        }
        super.onDestroy();
    }

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base, android.app.Activity
    protected void onStart() {
        this.synth.setRecordChan(NOTE_CHAN);
        this.synth.setStyleMix(true);
        this.metroOn = this.synth.isBeating();
        this.bPreset.setText(getPresetName(this.synth.getRecordChan()));
        updateKeyboardUi();
        updateVoiceUi();
        syncTempoUi();
        super.onStart();
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 4101 || resultCode != -1 || data == null || data.getData() == null) {
            return;
        }
        Importer.importAsync(this, data.getData(), new File(Synth.PATH_STY), new String[]{"sty"}, "sty", new Importer.Callback() {
            @Override // net.duceng.xmidi.util.Importer.Callback
            public void onResult(File dest, boolean originalRemoved, String error) {
                if (error != null || dest == null) {
                    Toast.makeText(Drums.this, error != null ? error : "No se pudo importar el estilo.", 1).show();
                } else {
                    Toast.makeText(Drums.this, "Estilo importado: " + dest.getName() + (originalRemoved ? " (movido a la carpeta de estilos de la app)" : " (copiado; el original no se pudo borrar)"), 1).show();
                    Drums.this.loadStyFile(dest);
                }
            }
        });
    }

    // =====================================================================
    //  Construcción de la interfaz
    // =====================================================================
    private void setupStyleHeader() {
        this.btnFile = (Button) findViewById(R.id.drums_styfile);
        this.btnFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Drums.this.dialogStyRef == null) {
                    Drums.this.dialogStyRef = new DialogSty(Drums.this);
                    Drums.this.dialogStyRef.setOnSelectListener(new DialogSty.OnSelectListener() {
                        @Override
                        public void onSelect(File f) {
                            Drums.this.loadStyFile(f);
                            for (int i = 0; i < Drums.this.btnChords.length; i++) {
                                Drums.this.btnChords[i].setSelected(false);
                            }
                            Drums.this.chord = null;
                            if (Drums.this.engine != null) {
                                Drums.this.engine.setChord(null);
                            }
                            Drums.this.applyHarmonyChord();
                            Drums.this.dialogStyRef.dismiss();
                        }
                    });
                }
                Drums.this.dialogStyRef.show();
            }
        });
        this.btnPlay = (ImageButton) findViewById(R.id.drums_play);
        this.btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Drums.this.playing) {
                    Drums.this.play();
                } else {
                    Drums.this.stop();
                }
            }
        });
        this.btnTonality = (Button) findViewById(R.id.drums_tonality);
        this.btnTonality.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Drums.this.dialogTonalityRef == null) {
                    Drums.this.dialogTonalityRef = new DialogTonality(Drums.this, Drums.this.gChords);
                    Drums.this.dialogTonalityRef.setOnSelectListener(new DialogTonality.OnSelectListener() {
                        @Override
                        public boolean onSelect(int id) {
                            Chords.Chord[] chords = Drums.this.gChords.getGChords18(id);
                            for (int i = 0; i < chords.length; i++) {
                                Drums.this.btnChords[i].setText(chords[i].name);
                                Drums.this.btnChords[i].setTag(chords[i]);
                            }
                            Drums.this.btnTonality.setText(chords[0].name);
                            Drums.this.tonalityIndex = id;
                            Drums.this.saveChords();
                            for (int i = 0; i < Drums.this.btnChords.length; i++) {
                                if (Drums.this.btnChords[i].isSelected()) {
                                    Drums.this.chord = (Chords.Chord) Drums.this.btnChords[i].getTag();
                                    if (Drums.this.engine != null) {
                                        Drums.this.engine.setChord(Drums.this.chord);
                                    }
                                }
                            }
                            Drums.this.applyHarmonyChord();
                            Drums.this.dialogTonalityRef.dismiss();
                            return true;
                        }
                    });
                }
                Drums.this.dialogTonalityRef.show();
            }
        });
    }

    private void setupChordButtons() {
        int[] rows = {R.id.drums_layout_chord0, R.id.drums_layout_chord1, R.id.drums_layout_chord2};
        int idx = 0;
        for (int r = 0; r < rows.length; r++) {
            LinearLayout row = (LinearLayout) findViewById(rows[r]);
            for (int k = 0; k < row.getChildCount() && idx < this.btnChords.length; k++) {
                this.btnChords[idx] = (Button) row.getChildAt(k);
                this.btnChords[idx].setOnTouchListener(this.chordTouchListener);
                this.btnChords[idx].setOnLongClickListener(this.chordLongClickListener);
                idx++;
            }
        }
    }

    private void setupDrumPads() {
        int idx = 0;
        for (int i = 0; i < this.layoutBtns.length; i++) {
            for (int k = 0; k < this.layoutBtns[i].getChildCount() && idx < this.btnDrums.length; k++) {
                this.btnDrums[idx] = (Button) this.layoutBtns[i].getChildAt(k);
                this.btnDrums[idx].setOnTouchListener(this.drumTouchListener);
                this.btnDrums[idx].setOnLongClickListener(this.drumLongClickListener);
                idx++;
            }
        }
    }

    private KeyPad addPad(int containerId, String label, float labelSp) {
        LinearLayout parent = (LinearLayout) findViewById(containerId);
        KeyPad k = new KeyPad(this);
        k.setLabel(label);
        k.setLabelSize(labelSp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.0f);
        int m = dpTopx(2);
        lp.setMargins(m, m, m, m);
        parent.addView(k, lp);
        return k;
    }

    private void bindSection(KeyPad k, final String name) {
        this.padByName.put(name, k);
        k.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if ((event.getAction() & 255) == 0) {
                    if (BREAK.equals(name)) {
                        Drums.this.onBreakPad();
                    } else {
                        Drums.this.onSectionPad(name);
                    }
                }
                return false;
            }
        });
    }

    private void setupSectionPads() {
        for (int i = 0; i < INTRO.length; i++) {
            bindSection(addPad(R.id.drums_pads_intro, ROMAN[i], 14), INTRO[i]);
        }
        for (int i = 0; i < MAIN.length; i++) {
            bindSection(addPad(R.id.drums_pads_main, LETTER[i], 15), MAIN[i]);
        }
        bindSection(addPad(R.id.drums_pads_break, "| |", 14), BREAK);
        for (int i = 0; i < ENDING.length; i++) {
            bindSection(addPad(R.id.drums_pads_ending, ROMAN[i], 14), ENDING[i]);
        }

        this.padAutoFill = addPad(R.id.drums_pads_autofill, "", 10);
        this.padAutoFill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drums.this.autoFill = !Drums.this.autoFill;
                PreferenceManager.getDefaultSharedPreferences(Drums.this).edit().putBoolean(PREF_AUTO_FILL, Drums.this.autoFill).apply();
                if (Drums.this.engine != null) {
                    Drums.this.engine.setAutoFill(Drums.this.autoFill);
                }
                Drums.this.updateToggleLeds();
            }
        });
        this.padFade = addPad(R.id.drums_pads_fade, "", 10);
        this.padFade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drums.this.onFadePad();
            }
        });

        this.padSustain = addPad(R.id.drums_pads_effect, "SUSTAIN", 8);
        this.padSustain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drums.this.applySustain(!Drums.this.sustainOn);
            }
        });
        this.padHarmony = addPad(R.id.drums_pads_effect, "HARMONY\nARPEGGIO", 7);
        this.padHarmony.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean on = !Drums.this.rightHand.isEnabled();
                Drums.this.rightHand.setEnabled(on);
                Drums.this.applyHarmonyChord();
                Drums.this.updateToggleLeds();
                if (on) {
                    Toast.makeText(Drums.this, Drums.this.rightHand.getTypeName() + "  (mantén pulsado para cambiar)", 0).show();
                }
            }
        });
        this.padHarmony.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Drums.this.chooseHarmony();
                return true;
            }
        });
    }

    private void setupVoicePanels() {
        setupVoice(1, findViewById(R.id.drums_voice1));
        setupVoice(2, findViewById(R.id.drums_voice2));
    }

    private void setupVoice(final int voice, View panel) {
        TextView t = (TextView) panel.findViewById(R.id.voice_title);
        t.setText("VOICE RIGHT " + voice);
        this.voiceNames[voice - 1] = (TextView) panel.findViewById(R.id.voice_name);
        this.voiceVols[voice - 1] = (TextView) panel.findViewById(R.id.voice_vol);
        this.voiceToggles[voice - 1] = (ImageView) panel.findViewById(R.id.voice_toggle);
        panel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Drums.this.openVoiceDialog(voice);
            }
        });
        this.voiceToggles[voice - 1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean on = !Drums.this.rightHand.isVoiceEnabled(voice);
                Drums.this.rightHand.setVoiceEnabled(voice, on);
                PreferenceManager.getDefaultSharedPreferences(Drums.this).edit().putBoolean(voice == 1 ? PREF_VOICE1 : PREF_VOICE2, on).apply();
                Drums.this.updateVoiceUi();
            }
        });
    }

    private void setupSliders() {
        this.seekTempo = (SeekBar) findViewById(R.id.drums_tempo);
        this.tempoValue = (TextView) findViewById(R.id.drums_tempo_value);
        this.seekStyleVol = (SeekBar) findViewById(R.id.drums_stylevol);
        this.styleVolValue = (TextView) findViewById(R.id.drums_stylevol_value);
        this.seekTempo.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int bpm = progress + 40;
                Drums.this.tempoValue.setText(String.valueOf(bpm));
                if (fromUser && !Drums.this.updatingUi) {
                    Drums.this.synth.getMidiFile().getTempo().setMpqn(60000000 / bpm);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        this.seekStyleVol.setProgress(100);
        this.styleVolValue.setText("100");
        this.seekStyleVol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                Drums.this.styleVolValue.setText(String.valueOf(progress));
                Drums.this.userGain = progress / 100.0f;
                Drums.this.applyStyleGain();
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
    }

    // =====================================================================
    //  Teclado / voces
    // =====================================================================
    private void setupKeyboard() {
        this.piano.setPianoBoardListener(this.keyListener);
        this.piano.setVisibleWhiteKeys(14);
        this.piano.setScroll(60);
        updateKeyboardUi();
        applyKeysVisibility();
    }

    private void applySustain(boolean on) {
        this.sustainOn = on;
        int v = on ? 127 : 0;
        this.synth.setSustain(RightHand.VOICE1_CHAN, v);
        this.synth.setSustain(RightHand.VOICE2_CHAN, v);
        if (!on) {
            this.synth.keysOff(RightHand.VOICE1_CHAN);
            this.synth.keysOff(RightHand.VOICE2_CHAN);
        }
        updateKeyboardUi();
    }

    private void updateKeyboardUi() {
        if (this.bKeyboard != null) {
            this.bKeyboard.setText(getPresetName(0));
        }
        this.sustainOn = this.synth.getSustain(0) >= 64;
        if (this.bSustain != null) {
            if (this.sustainOn) {
                this.bSustain.setBackgroundResource(R.color.focused);
            } else if (this.sustainBg != null) {
                this.bSustain.setBackground(this.sustainBg);
            }
        }
        if (this.padSustain != null) {
            this.padSustain.setLed(this.sustainOn ? KeyPad.LED_BLUE : KeyPad.LED_OFF);
        }
    }

    private String voicePresetName(int chan) {
        int p = this.synth.getPreset(chan);
        if (this.synth.getBank(chan) == Synth.DRUMS_BANK) {
            int i = Math.max(0, Math.min(this.drums.length - 1, p / 8));
            return this.drums[i];
        }
        int i2 = Math.max(0, Math.min(this.instruments.length - 1, p));
        return this.instruments[i2];
    }

    private void updateVoiceUi() {
        for (int v = 1; v <= 2; v++) {
            int chan = v == 1 ? RightHand.VOICE1_CHAN : RightHand.VOICE2_CHAN;
            if (this.voiceNames[v - 1] == null) {
                continue;
            }
            this.voiceNames[v - 1].setText(voicePresetName(chan));
            int d = this.synth.getBaseVolume(chan) - 100;
            this.voiceVols[v - 1].setText("VOL: " + (d > 0 ? "+" : "") + d);
            this.voiceToggles[v - 1].setImageLevel(this.rightHand.isVoiceEnabled(v) ? 1 : 0);
        }
    }

    private void openVoiceDialog(final int voice) {
        int chan = voice == 1 ? RightHand.VOICE1_CHAN : RightHand.VOICE2_CHAN;
        DialogPreset d = this.voiceDialogs[voice - 1];
        if (d == null) {
            d = new DialogPreset(this, this.synth);
            d.setAbsoluteVolume(true);
            d.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    Drums.this.saveSession();
                    Drums.this.updateVoiceUi();
                    Drums.this.updateKeyboardUi();
                }
            });
            this.voiceDialogs[voice - 1] = d;
        }
        d.setChannel(chan);
        d.show();
    }

    private void chooseHarmony() {
        new AlertDialog.Builder(this)
                .setTitle("HARMONY / ARPEGGIO")
                .setItems(RightHand.TYPE_NAMES, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Drums.this.rightHand.setType(which);
                        Drums.this.rightHand.setEnabled(true);
                        Drums.this.applyHarmonyChord();
                        PreferenceManager.getDefaultSharedPreferences(Drums.this).edit().putInt(PREF_HARM_TYPE, which).apply();
                        Drums.this.updateToggleLeds();
                    }
                })
                .setNegativeButton("OFF", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Drums.this.rightHand.setEnabled(false);
                        Drums.this.updateToggleLeds();
                    }
                })
                .show();
    }

    private void applyHarmonyChord() {
        Chords.Chord c = this.chord;
        if (c == null) {
            c = this.gChords.getChord(Math.max(0, Math.min(11, this.tonalityIndex)));
        }
        this.rightHand.setChord(c);
    }

    private void applyKeysVisibility() {
        if (this.layoutKeys == null || this.layoutManual == null || this.layoutTop == null) {
            return;
        }
        if (this.auto) {
            this.layoutTop.setVisibility(0);
            this.layoutKeys.setVisibility(0);
            this.layoutManual.setVisibility(8);
            this.divh.setVisibility(0);
        } else {
            this.piano.releaseAll();
            this.rightHand.releaseAll();
            this.layoutTop.setVisibility(8);
            this.layoutKeys.setVisibility(8);
            this.layoutManual.setVisibility(0);
            this.divh.setVisibility(8);
        }
        this.divv.setVisibility(8);
        if (this.bLock != null) {
            this.bLock.setEnabled(this.auto);
        }
        if (this.bSustain != null) {
            this.bSustain.setEnabled(this.auto);
        }
        if (this.bKeyboard != null) {
            this.bKeyboard.setEnabled(this.auto);
        }
    }

    // =====================================================================
    //  Sesion: voces, ritmo, acordes y ajustes se conservan al salir
    // =====================================================================
    private void saveSession() {
        if (this.destroyed || this.rightHand == null || this.synth == null) {
            return;
        }
        SharedPreferences.Editor ed = PreferenceManager.getDefaultSharedPreferences(this).edit();
        for (int v = 1; v <= 2; v++) {
            int chan = v == 1 ? RightHand.VOICE1_CHAN : RightHand.VOICE2_CHAN;
            String k = PREF_VOICE_STATE + v + "_";
            File sf = null;
            try {
                sf = this.synth.getSFonts().get(this.synth.getSFont(chan));
            } catch (RuntimeException ignored) {
                sf = null;
            }
            ed.putString(k + "sf", sf != null ? sf.getName() : "");
            ed.putInt(k + "bank", this.synth.getBank(chan));
            ed.putInt(k + "preset", this.synth.getPreset(chan));
            ed.putInt(k + "vol", this.synth.getBaseVolume(chan));
            ed.putInt(k + "rev", this.synth.getReverb(chan));
            ed.putInt(k + "cho", this.synth.getChorus(chan));
            ed.putBoolean(k + "saved", true);
        }
        ed.putBoolean(PREF_VOICE1, this.rightHand.isVoiceEnabled(1));
        ed.putBoolean(PREF_VOICE2, this.rightHand.isVoiceEnabled(2));
        ed.putBoolean(PREF_HARM_ON, this.rightHand.isEnabled());
        ed.putInt(PREF_HARM_TYPE, this.rightHand.getType());
        ed.putBoolean(PREF_AUTO_FILL, this.autoFill);
        ed.putInt(PREF_STYLE_VOL, Math.round(this.userGain * 100.0f));
        if (this.armed != null) {
            ed.putString(PREF_ARMED, this.armed);
        }
        int sel = -1;
        for (int i = 0; i < this.btnChords.length; i++) {
            if (this.btnChords[i].isSelected()) {
                sel = i;
            }
        }
        ed.putInt(PREF_CHORD_SEL, sel);
        ed.apply();
        saveChords();
    }

    private void restoreSession(SharedPreferences pref) {
        // voces
        for (int v = 1; v <= 2; v++) {
            int chan = v == 1 ? RightHand.VOICE1_CHAN : RightHand.VOICE2_CHAN;
            String k = PREF_VOICE_STATE + v + "_";
            if (!pref.getBoolean(k + "saved", false)) {
                continue;
            }
            try {
                int sfId = -1;
                String sfName = pref.getString(k + "sf", "");
                MyArray<File> fonts = this.synth.getSFonts();
                for (int i = 0; i < fonts.size(); i++) {
                    if (fonts.valueAt(i) != null && fonts.valueAt(i).getName().equals(sfName)) {
                        sfId = fonts.keyAt(i);
                        break;
                    }
                }
                int bank = pref.getInt(k + "bank", 0);
                int preset = pref.getInt(k + "preset", 0);
                if (sfId >= 0) {
                    this.synth.setProgram(chan, sfId, bank, preset);
                } else {
                    this.synth.setBank(chan, bank);
                    this.synth.setPreset(chan, preset);
                }
                this.synth.setKeyVolume(chan, pref.getInt(k + "vol", 100));
                this.synth.setReverb(chan, pref.getInt(k + "rev", 40));
                this.synth.setChorus(chan, pref.getInt(k + "cho", 0));
            } catch (RuntimeException e) {
                e.printStackTrace();
            }
        }
        // mano derecha
        this.rightHand.setEnabled(pref.getBoolean(PREF_HARM_ON, false));
        // volumen del estilo
        int vol = Math.max(0, Math.min(200, pref.getInt(PREF_STYLE_VOL, 100)));
        this.seekStyleVol.setProgress(vol);
        // seccion elegida
        String savedArmed = pref.getString(PREF_ARMED, null);
        if (savedArmed != null && this.styFile != null && this.styFile.containsSection(savedArmed)
                && !savedArmed.startsWith("Ending")) {
            this.armed = savedArmed;
            this.lastMainUi = savedArmed.startsWith("Main") ? savedArmed : this.lastMainUi;
        }
        // acorde seleccionado
        int sel = pref.getInt(PREF_CHORD_SEL, -1);
        if (sel >= 0 && sel < this.btnChords.length && !this.btnChords[sel].isSelected()) {
            chordSelect(this.btnChords[sel]);
        }
    }

    // =====================================================================
    //  Acordes
    // =====================================================================
    private void saveChords() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.btnChords.length; i++) {
            Chords.Chord c = (Chords.Chord) this.btnChords[i].getTag();
            if (c == null) {
                return;
            }
            if (i > 0) {
                sb.append(',');
            }
            sb.append(c.id);
        }
        PreferenceManager.getDefaultSharedPreferences(this).edit().putString(PREF_CHORDS, sb.toString()).putInt(PREF_TONALITY, this.tonalityIndex).apply();
    }

    private void restoreChords() {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        this.tonalityIndex = Math.max(0, Math.min(11, pref.getInt(PREF_TONALITY, 0)));
        Chords.Chord[] chords = this.gChords.getGChords18(this.tonalityIndex);
        String saved = pref.getString(PREF_CHORDS, null);
        if (saved != null) {
            String[] parts = saved.split(",");
            if (parts.length == this.btnChords.length) {
                try {
                    Chords.Chord[] restored = new Chords.Chord[parts.length];
                    for (int i = 0; i < parts.length; i++) {
                        int id = Integer.parseInt(parts[i].trim());
                        if (id < 0 || id > 47) {
                            throw new NumberFormatException("acorde fuera de rango");
                        }
                        restored[i] = this.gChords.getChord(id);
                    }
                    chords = restored;
                } catch (RuntimeException e) {
                    chords = this.gChords.getGChords18(this.tonalityIndex);
                }
            }
        }
        for (int i2 = 0; i2 < chords.length && i2 < this.btnChords.length; i2++) {
            this.btnChords[i2].setText(chords[i2].name);
            this.btnChords[i2].setTag(chords[i2]);
        }
        this.btnTonality.setText(this.gChords.getGChords18(this.tonalityIndex)[0].name);
        applyHarmonyChord();
    }

    public void chordSelect(Button b) {
        if (b.isSelected()) {
            b.setSelected(false);
            this.chord = null;
        } else {
            for (int i = 0; i < this.btnChords.length; i++) {
                this.btnChords[i].setSelected(false);
            }
            b.setSelected(true);
            this.chord = (Chords.Chord) b.getTag();
        }
        if (this.engine != null) {
            this.engine.setChord(this.chord);
        }
        applyHarmonyChord();
    }

    // =====================================================================
    //  Estilo (.STY)
    // =====================================================================
    public void loadStyFile(File f) {
        try {
            FileInputStream in = new FileInputStream(f);
            try {
                StyFile sf = new StyFile(in);
                in.close();
                if (this.engine != null) {
                    this.engine.stop();
                }
                this.styFile = sf;
                this.sectionTouched = false;
                PreferenceManager.getDefaultSharedPreferences(this).edit().putString(PREF_STY, f.getAbsolutePath()).apply();
                this.btnFile.setText(f.getName());
                this.synth.getMidiFile().getTempo().setMpqn(this.styFile.getTempo().getMpqn());
                applyStyleSetup();
                String firstMain = null;
                for (String key : sf.getSections().keySet()) {
                    if (key.startsWith("Main")) {
                        firstMain = key;
                        break;
                    }
                }
                this.armed = sf.containsSection("Main A") ? "Main A" : firstMain;
                this.preStart = null;
                this.handler.removeCallbacks(this.preBlink);
                this.curSec = null;
                this.nextSec = null;
                this.lastMainUi = this.armed;
                this.breakFlag = false;
                buildEngine();
                syncTempoUi();
                applyStyleGain();
                refreshLeds();
            } catch (Throwable th) {
                in.close();
                throw th;
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    private void applyStyleSetup() {
        this.synth.setStyleMix(true);
        this.synth.clearOverrides(8, 15);
        this.synth.resetChannels(8, 15);
        this.baseApplied = new ArrayList<EventChannel>();
        ArrayList<EventChannel> init = new ArrayList<EventChannel>();
        for (MidiEvent e : this.styFile.getHead()) {
            if ((e instanceof EventChannel) && ((EventChannel) e).getChannel() >= 8) {
                init.add((EventChannel) e);
            }
        }
        for (MidiEvent e2 : this.styFile.getSint()) {
            if ((e2 instanceof EventChannel) && ((EventChannel) e2).getChannel() >= 8) {
                init.add((EventChannel) e2);
            }
        }
        for (EventChannel e3 : init) {
            int ch = e3.getChannel();
            if (ch != 8 && ch != 9 && e3.getType() == 11 && ((e3.getValue1() == 0 && e3.getValue2() != 127) || e3.getValue1() == 32)) {
                this.synth.execEvent(e3);
                this.baseApplied.add(e3);
            }
        }
        for (EventChannel e4 : init) {
            int ch2 = e4.getChannel();
            if (ch2 != 8 && ch2 != 9 && e4.getType() == 12) {
                this.synth.execEvent(e4);
                this.baseApplied.add(e4);
            }
        }
        for (EventChannel e5 : init) {
            int ch3 = e5.getChannel();
            if (ch3 != 8 && e5.getType() == 11 && e5.getValue1() != 0 && e5.getValue1() != 32) {
                this.synth.execEvent(e5);
                this.baseApplied.add(e5);
            }
        }
    }

    private void buildEngine() {
        if (this.engine != null) {
            this.engine.stop();
        }
        this.engine = new StyleEngine(this.styFile, new StyleEngine.Sink() {
            @Override // net.duceng.xmidi.util.StyleEngine.Sink
            public void send(EventChannel e) {
                if (Drums.this.destroyed) {
                    return;
                }
                Drums.this.synth.execEvent(e);
            }

            @Override // net.duceng.xmidi.util.StyleEngine.Sink
            public void silence() {
                if (Drums.this.destroyed) {
                    return;
                }
                Drums.this.synth.silenceChannels(8, 15);
            }
        }, new StyleEngine.Host() {
            @Override // net.duceng.xmidi.util.StyleEngine.Host
            public int mpqn() {
                return Drums.this.synth.getMidiFile().getTempo().getMpqn();
            }
        }, new ThreadFactory() {
            @Override // java.util.concurrent.ThreadFactory
            public Thread newThread(final Runnable r) {
                return new Thread(new Runnable() {
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            Process.setThreadPriority(-16);
                        } catch (Throwable th) {
                        }
                        r.run();
                    }
                }, "XMidi-StyleEngine");
            }
        });
        this.engine.setListener(new StyleEngine.Listener() {
            @Override // net.duceng.xmidi.util.StyleEngine.Listener
            public void onBeat(final int beat) {
                if (Drums.this.destroyed) {
                    return;
                }
                Drums.this.handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Drums.this.onBeatUi(beat);
                    }
                });
            }

            @Override // net.duceng.xmidi.util.StyleEngine.Listener
            public void onNext(final String dest) {
                Drums.this.handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Drums.this.nextSec = dest;
                        Drums.this.refreshLeds();
                    }
                });
            }

            @Override // net.duceng.xmidi.util.StyleEngine.Listener
            public void onSection(final String name) {
                Drums.this.handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Drums.this.onSectionUi(name);
                    }
                });
            }

            @Override // net.duceng.xmidi.util.StyleEngine.Listener
            public void onStopped() {
                Drums.this.playing = false;
                Drums.this.handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (Drums.this.metroOn && !Drums.this.destroyed) {
                            Drums.this.synth.setBeating(true);
                        }
                        Drums.this.btnFile.setEnabled(true);
                        Drums.this.btnTonality.setEnabled(true);
                        Drums.this.btnPlay.getDrawable().setLevel(0);
                        Drums.this.resetPlaybackUi();
                    }
                });
            }
        });
        this.engine.setBaseSetup(this.baseApplied);
        this.engine.setAutoFill(this.autoFill);
        applyMetronome();
        this.engine.setChord(this.chord);
    }

    // =====================================================================
    //  LEDs sincronizados con el compás
    // =====================================================================
    private static boolean isMainName(String n) {
        return n != null && n.startsWith("Main");
    }

    private boolean isAvailable(String name) {
        if (this.styFile == null) {
            return false;
        }
        if (BREAK.equals(name)) {
            return this.engine != null && this.engine.hasBreak();
        }
        return this.styFile.containsSection(name);
    }

    /** Main que seguirá a una intro cuando el usuario no eligió otro. */
    private String mainAfterIntro(String intro) {
        String m = "Main " + intro.charAt(intro.length() - 1);
        if (this.styFile != null && this.styFile.containsSection(m)) {
            return m;
        }
        if (this.styFile != null && this.styFile.containsSection("Main A")) {
            return "Main A";
        }
        return this.lastMainUi;
    }

    private void refreshLeds() {
        if (this.padByName.isEmpty()) {
            return;
        }
        String steady = null;
        String blink = null;
        String cur = this.curSec;
        if (this.playing && cur != null) {
            if (isMainName(cur)) {
                steady = cur;
                if (this.nextSec != null && !this.nextSec.equals(cur)) {
                    blink = this.nextSec;
                }
            } else if (cur.startsWith("Fill In") || cur.startsWith("Break")) {
                if (this.breakFlag) {
                    blink = BREAK;
                    steady = this.nextSec != null ? this.nextSec : this.lastMainUi;
                } else {
                    blink = this.nextSec != null ? this.nextSec : this.lastMainUi;
                }
            } else {
                blink = cur;
                if (cur.startsWith("Intro")) {
                    steady = this.nextSec != null ? this.nextSec : mainAfterIntro(cur);
                }
            }
        } else if (this.preStart != null) {
            blink = "FILL".equals(this.preStart) ? armedMain() : this.preStart;
            steady = armedMain();
        } else {
            steady = this.armed;
        }
        for (Map.Entry<String, KeyPad> en : this.padByName.entrySet()) {
            String name = en.getKey();
            KeyPad pad = en.getValue();
            boolean available = isAvailable(name);
            if (pad.isEnabled() != available) {
                pad.setEnabled(available);
            }
            if (!available) {
                continue;
            }
            int led;
            if (name.equals(blink)) {
                led = this.blinkOn ? KeyPad.LED_ORANGE : KeyPad.LED_OFF;
            } else if (name.equals(steady)) {
                led = KeyPad.LED_ORANGE;
            } else {
                led = KeyPad.LED_BLUE;
            }
            pad.setLed(led);
        }
    }

    private void updateToggleLeds() {
        if (this.padAutoFill == null) {
            return;
        }
        this.padAutoFill.setLed(this.autoFill ? KeyPad.LED_BLUE : KeyPad.LED_OFF);
        if (!this.fading) {
            this.padFade.setLed(this.fadeArmed ? KeyPad.LED_BLUE : KeyPad.LED_OFF);
        }
        this.padSustain.setLed(this.sustainOn ? KeyPad.LED_BLUE : KeyPad.LED_OFF);
        this.padHarmony.setLed(this.rightHand.isEnabled() ? KeyPad.LED_BLUE : KeyPad.LED_OFF);
    }

    /** Cada pulso: LED naranja encendido (medio pulso) y la batería alterna naranja / azul. */
    private void onBeatUi(int beat) {
        if (this.destroyed || !this.playing) {
            return;
        }
        this.blinkOn = true;
        this.drumIcon.setColorFilter((beat % 2 == 0) ? COLOR_ORANGE : COLOR_BLUE, PorterDuff.Mode.SRC_IN);
        refreshLeds();
        int half = 200;
        if (this.engine != null) {
            half = Math.max(60, this.engine.beatMillis() / 2);
        }
        this.handler.removeCallbacks(this.blinkOff);
        this.handler.postDelayed(this.blinkOff, half);
    }

    private void onSectionUi(String name) {
        this.curSec = name;
        if (isMainName(name)) {
            this.lastMainUi = name;
            this.armed = name;
            this.breakFlag = false;
        }
        refreshLeds();
    }

    private void resetPlaybackUi() {
        this.curSec = null;
        this.nextSec = null;
        this.breakFlag = false;
        this.blinkOn = false;
        this.handler.removeCallbacks(this.blinkOff);
        this.drumIcon.setColorFilter(COLOR_GOLD, PorterDuff.Mode.SRC_IN);
        refreshLeds();
    }

    // =====================================================================
    //  Botones de sección (INTRO / MAIN / BREAK / ENDING)
    // =====================================================================
    private void onSectionPad(String name) {
        if (this.destroyed || this.styFile == null || !this.styFile.containsSection(name)) {
            return;
        }
        this.sectionTouched = true;
        if (this.engine != null && this.engine.isRunning()) {
            this.engine.requestSection(name);
            return;
        }
        // Parado: pre-armar la seccion con la que empezara el ritmo (parpadea; pulsar otra vez = cancelar)
        String main = armedMain();
        if (name.startsWith("Main")) {
            if (name.equals(main)) {
                if (this.engine != null && this.engine.fillSectionFor(main) == null) {
                    return;
                }
                this.preStart = "FILL".equals(this.preStart) ? null : "FILL";
            } else {
                this.armed = name;
                this.lastMainUi = name;
                if ("FILL".equals(this.preStart)) {
                    this.preStart = null;
                }
            }
        } else {
            this.preStart = name.equals(this.preStart) ? null : name;
            if (name.startsWith("Main")) {
                this.armed = name;
            }
        }
        startPreBlink();
    }

    /** MAIN elegido (el que sonara tras la intro / remate). */
    private String armedMain() {
        if (this.armed != null && this.armed.startsWith("Main")) {
            return this.armed;
        }
        if (this.lastMainUi != null) {
            return this.lastMainUi;
        }
        return this.styFile != null && this.styFile.containsSection("Main A") ? "Main A" : this.armed;
    }

    private void startPreBlink() {
        this.handler.removeCallbacks(this.preBlink);
        if (this.preStart != null && !this.playing) {
            this.blinkOn = true;
            this.handler.post(this.preBlink);
        } else {
            this.blinkOn = false;
            refreshLeds();
        }
    }

    private void onBreakPad() {
        if (this.destroyed || this.engine == null || !this.engine.hasBreak()) {
            return;
        }
        if (!this.engine.isRunning()) {
            this.sectionTouched = true;
            this.preStart = BREAK.equals(this.preStart) ? null : BREAK;
            startPreBlink();
            return;
        }
        if (this.curSec == null || this.curSec.startsWith("Ending") || this.curSec.startsWith("Fill In") || this.curSec.startsWith("Break")) {
            return;
        }
        this.sectionTouched = true;
        this.breakFlag = true;
        this.engine.requestBreak();
    }

    // =====================================================================
    //  FADE IN / OUT
    // =====================================================================
    private void applyStyleGain() {
        this.synth.setStyleGain(this.userGain * this.fadeGain);
    }

    private void onFadePad() {
        if (this.fading) {
            return;
        }
        if (this.playing && this.engine != null && this.engine.isRunning()) {
            startFade(false);
        } else {
            this.fadeArmed = !this.fadeArmed;
            updateToggleLeds();
        }
    }

    private void startFade(boolean in) {
        this.fadeIn = in;
        this.fading = true;
        this.fadeStart = SystemClock.uptimeMillis();
        this.fadeDur = this.engine != null ? Math.max(1500, this.engine.barMillis() * 2) : 3000;
        this.fadeGain = in ? 0.0f : 1.0f;
        applyStyleGain();
        this.handler.removeCallbacks(this.fadeTick);
        this.handler.post(this.fadeTick);
    }

    private void finishFade() {
        this.fading = false;
        this.fadeArmed = false;
        if (!this.fadeIn) {
            stop();
            // devolvemos el volumen cuando ya no suena nada
            this.handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Drums.this.fadeGain = 1.0f;
                    Drums.this.applyStyleGain();
                }
            }, 500L);
        } else {
            this.fadeGain = 1.0f;
            applyStyleGain();
        }
        updateToggleLeds();
    }

    // =====================================================================
    //  Tempo / metrónomo
    // =====================================================================
    private void syncTempoUi() {
        if (this.seekTempo == null) {
            return;
        }
        int mpqn = this.synth.getMidiFile().getTempo().getMpqn();
        if (mpqn <= 0) {
            mpqn = 500000;
        }
        int bpm = Math.max(40, Math.min(240, Math.round(60000000.0f / mpqn)));
        this.updatingUi = true;
        this.seekTempo.setProgress(bpm - 40);
        this.tempoValue.setText(String.valueOf(bpm));
        this.updatingUi = false;
    }

    private void applyMetronome() {
        if (this.engine != null) {
            this.engine.setMetronome(this.metroOn, this.synth.getBeatNote1(), this.synth.getBeatNote2(), this.synth.getBeatVelocity());
        }
    }

    private void updateBeatIcon() {
        ImageButton imageButton = (ImageButton) findViewById(R.id.act_beat);
        if (imageButton != null) {
            imageButton.getDrawable().setLevel(this.metroOn ? 1 : 0);
        }
    }

    // =====================================================================
    //  Acciones de la barra superior
    // =====================================================================
    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base
    protected void onActionClick(View view) {
        switch (view.getId()) {
            case R.id.act_beat /* metrónomo */:
                if (this.engine != null && this.engine.isRunning()) {
                    this.metroOn = !this.metroOn;
                    applyMetronome();
                    updateBeatIcon();
                    return;
                }
                break;
            case R.id.act_play /* play del archivo MIDI */:
                if (this.synth.isPlaying()) {
                    this.btnFile.setEnabled(true);
                    this.btnTonality.setEnabled(true);
                    this.btnPlay.setEnabled(true);
                } else {
                    this.btnFile.setEnabled(false);
                    this.btnTonality.setEnabled(false);
                    this.btnPlay.setEnabled(false);
                }
                if (this.auto && !this.sectionTouched && this.styFile != null) {
                    this.sectionTouched = true;
                    this.armed = this.styFile.containsSection("Intro A") ? "Intro A" : "Main A";
                    refreshLeds();
                }
                break;
            case R.id.drums_auto /* M / A */:
                this.auto = !this.auto;
                applyKeysVisibility();
                this.bAuto.getDrawable().setLevel(this.auto ? 1 : 0);
                return;
            case R.id.drums_keyboard:
                if (this.keyboardPreset == null) {
                    this.keyboardPreset = new DialogPreset(this, this.synth);
                    this.keyboardPreset.setAbsoluteVolume(true);
                    this.keyboardPreset.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            Drums.this.updateKeyboardUi();
                            Drums.this.updateVoiceUi();
                        }
                    });
                }
                this.keyboardPreset.setChannel(0);
                this.keyboardPreset.show();
                return;
            case R.id.drums_lock:
                this.piano.setLocked(!this.piano.isLocked());
                this.bLock.getDrawable().setLevel(this.piano.isLocked() ? 1 : 0);
                return;
            case R.id.drums_sustain:
                applySustain(!this.sustainOn);
                return;
            case R.id.title:
                if (this.channDialog == null) {
                    this.channDialog = new DialogChannel(this, this.synth);
                    this.channDialog.setOnSelectListener(new DialogChannel.OnSelectListener() {
                        @Override // net.duceng.xmidi.ui.DialogChannel.OnSelectListener
                        public void onSelect(int chan, int preset, String instrument) {
                            Drums.this.synth.setRecordChan((byte) chan);
                            Drums.this.bPreset.setText(Drums.this.getPresetName(chan));
                            Drums.this.channDialog.dismiss();
                        }
                    });
                }
                this.channDialog.show();
                return;
        }
        super.onActionClick(view);
        if (view.getId() == R.id.act_beat) {
            this.metroOn = this.synth.isBeating();
        }
        if (view.getId() == R.id.act_play && !this.synth.isPlaying() && this.startedBySynth && this.engine != null) {
            this.engine.stop();
            this.startedBySynth = false;
        }
    }

    // =====================================================================
    //  Reproducción del estilo
    // =====================================================================
    public void play() {
        if (this.styFile == null || this.engine == null || this.engine.isRunning()) {
            return;
        }
        this.btnFile.setEnabled(false);
        this.btnTonality.setEnabled(false);
        this.btnPlay.getDrawable().setLevel(3);
        String name = this.armed;
        String after = null;
        if (this.preStart != null) {
            String main = armedMain();
            if ("FILL".equals(this.preStart)) {
                name = this.engine.fillSectionFor(main);
                after = main;
            } else if (BREAK.equals(this.preStart)) {
                name = this.engine.breakSection();
                after = main;
            } else if (this.preStart.startsWith("Intro")) {
                name = this.preStart;
                after = main;
            } else {
                name = this.preStart;
            }
            this.preStart = null;
            this.handler.removeCallbacks(this.preBlink);
            this.blinkOn = false;
        }
        if (name == null || !this.styFile.containsSection(name)) {
            name = this.styFile.containsSection("Main A") ? "Main A" : "Intro A";
            after = null;
        } else if (name.startsWith("Ending") && this.armed != null && this.armed.equals(name)) {
            name = this.styFile.containsSection("Main A") ? "Main A" : "Intro A";
        }
        this.sectionTouched = true;
        this.curSec = null;
        this.nextSec = null;
        this.breakFlag = false;
        this.playing = true;
        if (this.synth.isBeating()) {
            this.synth.setBeating(false);
            this.metroOn = true;
        }
        applyMetronome();
        updateBeatIcon();
        this.engine.setChord(this.chord);
        this.engine.setAutoFill(this.autoFill);
        boolean doFadeIn = this.fadeArmed;
        if (doFadeIn) {
            this.fadeGain = 0.0f;
            applyStyleGain();
        }
        this.engine.start(name, after);
        if (doFadeIn) {
            startFade(true);
        }
    }

    public void stop() {
        this.startedBySynth = false;
        if (this.engine != null) {
            this.engine.stop();
        }
        this.playing = false;
        this.synth.silenceChannels(8, 15);
        if (this.metroOn) {
            this.synth.setBeating(true);
        }
        if (this.fading && this.fadeIn) {
            this.fading = false;
            this.handler.removeCallbacks(this.fadeTick);
            this.fadeGain = 1.0f;
            applyStyleGain();
            updateToggleLeds();
        }
        this.handler.post(new Runnable() {
            @Override
            public void run() {
                Drums.this.btnFile.setEnabled(true);
                Drums.this.btnTonality.setEnabled(true);
                Drums.this.btnPlay.getDrawable().setLevel(0);
                Drums.this.resetPlaybackUi();
            }
        });
    }
}
