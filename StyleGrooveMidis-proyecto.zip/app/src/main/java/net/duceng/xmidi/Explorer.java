package net.duceng.xmidi;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.io.File;
import net.duceng.xmidi.ui.DialogFile;
import net.duceng.xmidi.util.AdapterExplorer;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes3.dex */
public class Explorer extends Base {
    private AdapterExplorer fileAdapter;
    private ListView listv;
    protected Synth synth;
    private boolean startedUp = false;
    private boolean askedAccess = false;

    @Override // net.duceng.xmidi.Base, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Synth.configurePaths(this);
        this.synth = Synth.getInstance();
        setTop(true);
        setContentView(R.layout.explorer);
        LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.menu_fixed, (ViewGroup) null);
        while (layout.getChildCount() > 0) {
            View child = layout.getChildAt(0);
            layout.removeView(child);
            this.listMore.add(child);
            child.setOnClickListener(this.menuClickListener);
        }
        LinearLayout mainLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.action_explorer, (ViewGroup) null);
        while (mainLayout.getChildCount() > 0) {
            View child2 = mainLayout.getChildAt(0);
            mainLayout.removeView(child2);
            this.listBottom.add(child2);
            child2.setOnClickListener(this.actionClickListener);
        }
        this.listv = (ListView) findViewById(R.id.explorer_list);
        this.listv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.Explorer.1
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View view, int position, long id) {
                File f = Explorer.this.fileAdapter.getItem(position);
                if (f.isDirectory() && f.canExecute()) {
                    Explorer.this.fileAdapter.setCurrentPath(f);
                } else if (f.isFile() && f.canRead()) {
                    Intent intent = new Intent(Explorer.this, (Class<?>) Keyboard.class);
                    intent.putExtra("file", f);
                    Explorer.this.startActivity(intent);
                }
            }
        });
        this.listv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { // from class: net.duceng.xmidi.Explorer.2
            private DialogFile df;

            @Override // android.widget.AdapterView.OnItemLongClickListener
            public boolean onItemLongClick(AdapterView<?> av, View view, int position, long id) {
                if (this.df == null) {
                    this.df = new DialogFile(Explorer.this, Explorer.this.fileAdapter);
                }
                this.df.setFile(Explorer.this.fileAdapter.getItem(position));
                this.df.show();
                return true;
            }
        });
    }

    @Override // net.duceng.xmidi.Base, android.app.Activity
    protected void onResume() {
        super.onResume();
        if (this.startedUp) {
            return;
        }
        Synth.configurePaths(this);
        if (!Synth.hasSharedStorageAccess(this) && !this.askedAccess) {
            this.askedAccess = true;
            requestStorageAccess();
        } else {
            this.startedUp = true;
            startUp();
            offerSoundfonts();
        }
    }

    /** Primera vez: ofrece descargar los soundfonts Yamaha SX700 y Tyros 4 si faltan. */
    private void offerSoundfonts() {
        try {
            final android.content.SharedPreferences sp = android.preference.PreferenceManager.getDefaultSharedPreferences(this);
            if (sp.getBoolean(SoundfontSetup.PREF_DECLINED, false)) {
                return;
            }
            boolean[] have = SoundfontSetup.present(this);
            if (have[0] && have[1]) {
                return;
            }
            new android.app.AlertDialog.Builder(this)
                .setTitle("Soundfonts Yamaha")
                .setMessage("\u00bfQuieres descargar los soundfonts Yamaha SX700 y Yamaha Tyros 4 para una mejor calidad de ritmos?\n\nRecomendado para mejor experiencia.")
                .setCancelable(false)
                .setPositiveButton("S\u00ed", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        startActivity(new Intent(Explorer.this, SoundfontSetup.class));
                    }
                })
                .setNegativeButton("No", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        sp.edit().putBoolean(SoundfontSetup.PREF_DECLINED, true).apply();
                    }
                })
                .show();
        } catch (Exception e) {
        }
    }

    private void requestStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Intent i = new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION", Uri.parse("package:" + getPackageName()));
                startActivity(i);
                return;
            } catch (Exception e) {
                startActivity(new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"));
                return;
            }
        }
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, 1);
        }
    }

    private void startUp() {
        boolean synth_init = Synth.isInitialized(this);
        if (synth_init) {
            this.synth.init(this);
            this.fileAdapter = new AdapterExplorer(this, new File(Synth.PATH_MIDI));
            this.listv.setAdapter((ListAdapter) this.fileAdapter);
        } else {
            final ProgressDialog progress = new ProgressDialog(this);
            progress.setMessage(getString(R.string.process_init));
            progress.show();
            final Handler handler = new Handler(new Handler.Callback() { // from class: net.duceng.xmidi.Explorer.3
                @Override // android.os.Handler.Callback
                public boolean handleMessage(Message msg) {
                    Explorer.this.fileAdapter = new AdapterExplorer(Explorer.this, new File(Synth.PATH_MIDI));
                    Explorer.this.listv.setAdapter((ListAdapter) Explorer.this.fileAdapter);
                    progress.dismiss();
                    return true;
                }
            });
            Thread t = new Thread(new Runnable() { // from class: net.duceng.xmidi.Explorer.4
                @Override // java.lang.Runnable
                public void run() {
                    Explorer.this.synth.init(Explorer.this);
                    Message msg = handler.obtainMessage();
                    msg.sendToTarget();
                }
            });
            t.start();
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        this.synth.freeInstance();
        super.onDestroy();
    }

    @Override // net.duceng.xmidi.Base, android.app.Activity
    protected void onStart() {
        if (this.synth.getFile() != null) {
            this.title.setText(this.synth.getFile().getName());
        } else {
            this.title.setText(R.string.app_name);
        }
        super.onStart();
    }

    @Override // android.app.Activity
    public boolean onPrepareOptionsMenu(Menu menu) {
        showMenu();
        return false;
    }

    @Override // net.duceng.xmidi.Base
    protected void onActionClick(View v) {
        switch (v.getId()) {
            case R.id.explorer_drums /* 2130968686 */:
                Intent intent3 = new Intent(this, (Class<?>) Drums.class);
                startActivity(intent3);
                break;
            case R.id.explorer_guitar /* 2130968687 */:
                Intent intent2 = new Intent(this, (Class<?>) Guitar.class);
                startActivity(intent2);
                break;
            case R.id.explorer_keyboard /* 2130968688 */:
                Intent intent = new Intent(this, (Class<?>) Keyboard.class);
                startActivity(intent);
                break;
            case R.id.explorer_list /* 2130968689 */:
            default:
                super.onActionClick(v);
                break;
            case R.id.explorer_metronome /* 2130968690 */:
                Intent intent4 = new Intent(this, (Class<?>) Metronome.class);
                startActivity(intent4);
                break;
        }
    }
}
