package net.duceng.xmidi;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.util.ArrayList;
import java.util.Map;
import net.duceng.xsynth.Synth;
import org.json.JSONArray;

/**
 * Panel "Extras" de la pantalla de ritmos: funciones nuevas inspiradas en los teclados Yamaha.
 * 1 Tap tempo, 2 Tempo +/-, 3 Tempo del estilo, 4 Bloqueo de tempo, 5 Transposicion,
 * 6 Volumen general, 7 Reverb general, 8 Chorus general, 9 Mezclador por canal (on/off),
 * 10 Panico, 11 Cuenta previa, 12 Temporizador de apagado, 13 Teclas de volumen = tempo,
 * 14 Vibracion en pads, 15 Animacion de pads, 16 Destello en el tiempo 1, 17 Pantalla siempre encendida,
 * 18 Brillo, 19 Recientes, 20 Favoritos, 21 Info del estilo, 22 Guardar registro (8),
 * 23 Recuperar registro (8), 24 Restablecer extras, 25 Borrar listas.
 */
public class ExtraTools {
    public static final String K_HAPTIC = "x_haptic";
    public static final String K_ANIM = "x_anim";
    public static final String K_COUNTIN = "x_countin";
    public static final String K_VOLKEYS = "x_volkeys";
    public static final String K_KEEPON = "x_keepon";
    public static final String K_BRIGHT = "x_bright";
    public static final String K_FLASH = "x_flash";
    public static final String K_TEMPOLOCK = "x_tempolock";
    private static final String K_RECENTS = "x_recents";
    private static final String K_FAVS = "x_favs";
    private static final Handler H = new Handler();
    private static Runnable sleepTask = null;

    public interface Host {
        int getBpm();
        void setBpm(int bpm);
        void resetTempo();
        File currentStyle();
        void loadStyle(File f);
        void saveNow();
        void restoreNow();
        void panic();
        void muteChanged(int chan);
        void applyScreen();
        void transpose(int delta);
        String styleInfo();
        void stopAll();
        void randomSection();
        void setAutoVariation(int bars);
        int getAutoVariation();
    }

    private static final long SESSION_START = System.currentTimeMillis();
    private static Runnable rampTask = null;

    /** Cancela temporizador y rampa de tempo (al cerrar la pantalla). */
    public static void cancelTimers() {
        if (sleepTask != null) {
            H.removeCallbacks(sleepTask);
            sleepTask = null;
        }
        if (rampTask != null) {
            H.removeCallbacks(rampTask);
            rampTask = null;
        }
    }

    private final Activity act;
    private final Synth synth;
    private final Host host;
    private final SharedPreferences pref;
    private final ArrayList<Long> taps = new ArrayList<>();
    private AlertDialog dialog;
    private LinearLayout box;

    public ExtraTools(Activity act, Synth synth, Host host) {
        this.act = act;
        this.synth = synth;
        this.host = host;
        this.pref = PreferenceManager.getDefaultSharedPreferences(act);
    }

    // ---------- listas de estilos (recientes / favoritos) ----------
    private static ArrayList<String> readList(SharedPreferences p, String key) {
        ArrayList<String> out = new ArrayList<>();
        try {
            JSONArray ja = new JSONArray(p.getString(key, "[]"));
            for (int i = 0; i < ja.length(); i++) {
                out.add(ja.getString(i));
            }
        } catch (Exception e) {
        }
        return out;
    }

    private static void writeList(SharedPreferences p, String key, ArrayList<String> l) {
        p.edit().putString(key, new JSONArray(l).toString()).apply();
    }

    /** Llamado por Drums cada vez que se carga un estilo. */
    public static void pushRecent(android.content.Context c, File f) {
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(c);
        ArrayList<String> l = readList(p, K_RECENTS);
        l.remove(f.getAbsolutePath());
        l.add(0, f.getAbsolutePath());
        while (l.size() > 15) {
            l.remove(l.size() - 1);
        }
        writeList(p, K_RECENTS, l);
    }

    // ---------- UI ----------
    public void show() {
        float d = this.act.getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this.act);
        sv.setBackgroundColor(0xff12161a);
        this.box = new LinearLayout(this.act);
        this.box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (14 * d);
        this.box.setPadding(pad, pad, pad, pad);
        sv.addView(this.box);

        TextView intro = text("Men\u00fa FUNC: aqu\u00ed est\u00e1n las funciones avanzadas del teclado (tempo, mezcla, ambiente, estilos y registros). Los botones m\u00e1s usados tambi\u00e9n est\u00e1n en la barra de abajo de la pantalla.");
        intro.setTextColor(0xff9a9a9a);
        this.box.addView(intro);
        this.box.addView(text("Sesi\u00f3n: " + ((System.currentTimeMillis() - SESSION_START) / 60000) + " min tocando"));
        header("Tempo");
        final TextView bpmLabel = text("");
        updateBpm(bpmLabel);
        row(button("Tap tempo", new Runnable() {
            public void run() {
                tap();
                updateBpm(bpmLabel);
            }
        }), button("-5", delta(-5, bpmLabel)), button("-1", delta(-1, bpmLabel)), button("+1", delta(1, bpmLabel)), button("+5", delta(5, bpmLabel)));
        this.box.addView(bpmLabel);
        row(button("Tempo del estilo", new Runnable() {
            public void run() {
                host.resetTempo();
                updateBpm(bpmLabel);
            }
        }));
        toggle("Bloquear tempo al cambiar de estilo", K_TEMPOLOCK, false);
        row(button("Tempos por g\u00e9nero", new Runnable() {
            public void run() {
                genreTempo(bpmLabel);
            }
        }), button("Acelerar +20", ramp(20, bpmLabel)), button("Frenar -20", ramp(-20, bpmLabel)));

        header("Tonalidad");
        row(button("Transponer -1", new Runnable() {
            public void run() {
                host.transpose(-1);
            }
        }), button("Transponer +1", new Runnable() {
            public void run() {
                host.transpose(1);
            }
        }));

        header("Mezcla general");
        int g = this.pref.getInt(Settings.SYNTH_GAIN, 3);
        slider("Volumen general", 10, g, new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) {
                if (u) {
                    synth.setGain(p / 10.0f);
                    pref.edit().putInt(Settings.SYNTH_GAIN, p).apply();
                }
            }
            public void onStartTrackingTouch(SeekBar b) {
            }
            public void onStopTrackingTouch(SeekBar b) {
            }
        });
        slider("Reverb general", 127, Math.max(0, synth.getReverb(0)), new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) {
                if (u) {
                    for (int c = 0; c < 16; c++) {
                        synth.setReverb(c, p);
                    }
                }
            }
            public void onStartTrackingTouch(SeekBar b) {
            }
            public void onStopTrackingTouch(SeekBar b) {
            }
        });
        slider("Chorus general", 127, Math.max(0, synth.getChorus(0)), new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) {
                if (u) {
                    for (int c = 0; c < 16; c++) {
                        synth.setChorus(c, p);
                    }
                }
            }
            public void onStartTrackingTouch(SeekBar b) {
            }
            public void onStopTrackingTouch(SeekBar b) {
            }
        });

        header("Canales del estilo (como el CHANNEL ON/OFF Yamaha)");
        channel("Bateria", 8, 9);
        channel("Bajo", 10);
        channel("Acordes", 11, 12);
        channel("Pad", 13);
        channel("Frases", 14, 15);
        row(button("PANICO (silenciar todo)", new Runnable() {
            public void run() {
                host.panic();
            }
        }));

        header("Mezcla r\u00e1pida");
        row(button("Solo bater\u00eda", mix(true, false, false)), button("Bater\u00eda+bajo", mix(true, true, false)));
        row(button("Sin bater\u00eda", mix(false, true, true)), button("Todo activo", mix(true, true, true)));
        header("Ambiente (reverb)");
        row(button("Seco", room(0.1, 0.9, 10.0, 0.05)), button("Sala", room(0.4, 0.5, 40.0, 0.4)));
        row(button("Sal\u00f3n", room(0.75, 0.35, 70.0, 0.7)), button("Estadio", room(1.05, 0.15, 100.0, 1.0)));

        header("Interpretacion");
        row(button("Secci\u00f3n aleatoria", new Runnable() {
            public void run() {
                host.randomSection();
            }
        }), button("Auto-variaci\u00f3n", new Runnable() {
            public void run() {
                autoVariation();
            }
        }));
        toggle("Cuenta previa de 4 tiempos al dar play", K_COUNTIN, false);
        toggle("Teclas de volumen cambian el tempo", K_VOLKEYS, false);
        toggle("Vibracion al tocar los pads", K_HAPTIC, false);
        toggle("Animacion al pulsar los pads", K_ANIM, true);
        toggle("Destello en el tiempo 1", K_FLASH, false);
        row(button("Temporizador de apagado", new Runnable() {
            public void run() {
                sleepTimer();
            }
        }));

        header("Pantalla");
        toggle("Mantener pantalla encendida", K_KEEPON, false);
        slider("Brillo (0 = automatico)", 100, this.pref.getInt(K_BRIGHT, 0), new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) {
                if (u) {
                    pref.edit().putInt(K_BRIGHT, p).apply();
                    host.applyScreen();
                }
            }
            public void onStartTrackingTouch(SeekBar b) {
            }
            public void onStopTrackingTouch(SeekBar b) {
            }
        });

        header("Biblioteca de estilos");
        row(button("Recientes", new Runnable() {
            public void run() {
                pickStyle("Estilos recientes", readList(pref, K_RECENTS));
            }
        }), button("Favoritos", new Runnable() {
            public void run() {
                pickStyle("Estilos favoritos", readList(pref, K_FAVS));
            }
        }), button("★ Favorito", new Runnable() {
            public void run() {
                toggleFav();
            }
        }));
        row(button("Info del estilo", new Runnable() {
            public void run() {
                new AlertDialog.Builder(act).setTitle("Estilo").setMessage(host.styleInfo()).setPositiveButton("OK", null).show();
            }
        }));

        row(button("Buscar estilo", new Runnable() {
            public void run() {
                searchStyle();
            }
        }), button("\u25c0 Anterior", new Runnable() {
            public void run() {
                stepStyle(-1);
            }
        }), button("Siguiente \u25b6", new Runnable() {
            public void run() {
                stepStyle(1);
            }
        }), button("Aleatorio", new Runnable() {
            public void run() {
                stepStyle(0);
            }
        }));

        header("Registros (memoria de registro)");
        LinearLayout saveRow = new LinearLayout(this.act);
        LinearLayout loadRow = new LinearLayout(this.act);
        for (int i = 1; i <= 8; i++) {
            final int n = i;
            saveRow.addView(small("G" + i, new Runnable() {
                public void run() {
                    saveReg(n);
                }
            }));
            loadRow.addView(small(hasReg(i) ? "R" + i + "●" : "R" + i, new Runnable() {
                public void run() {
                    loadReg(n);
                }
            }));
        }
        this.box.addView(text("Guardar (G) / Recuperar (R)"));
        this.box.addView(saveRow);
        this.box.addView(loadRow);

        row(button("Copia de registros", new Runnable() {
            public void run() {
                backupRegs();
            }
        }), button("Restaurar copia", new Runnable() {
            public void run() {
                restoreRegs();
            }
        }));

        header("Mantenimiento");
        row(button("Restablecer extras", new Runnable() {
            public void run() {
                pref.edit().remove(K_HAPTIC).remove(K_ANIM).remove(K_COUNTIN).remove(K_VOLKEYS).remove(K_KEEPON)
                    .remove(K_BRIGHT).remove(K_FLASH).remove(K_TEMPOLOCK).apply();
                host.applyScreen();
                toast("Extras restablecidos");
                dialog.dismiss();
            }
        }), button("Borrar listas", new Runnable() {
            public void run() {
                pref.edit().remove(K_RECENTS).remove(K_FAVS).apply();
                toast("Listas borradas");
            }
        }));

        this.dialog = new AlertDialog.Builder(this.act).setTitle("★ Extras").setView(sv).setPositiveButton("Cerrar", null).create();
        this.dialog.show();
    }

    // ---------- tempo ----------
    private void tap() {
        long now = System.currentTimeMillis();
        if (!this.taps.isEmpty() && now - this.taps.get(this.taps.size() - 1) > 2000) {
            this.taps.clear();
        }
        this.taps.add(now);
        while (this.taps.size() > 5) {
            this.taps.remove(0);
        }
        if (this.taps.size() >= 2) {
            long span = this.taps.get(this.taps.size() - 1) - this.taps.get(0);
            double avg = span / (double) (this.taps.size() - 1);
            this.host.setBpm((int) Math.round(60000.0 / avg));
        }
    }

    private Runnable delta(final int dlt, final TextView label) {
        return new Runnable() {
            public void run() {
                host.setBpm(host.getBpm() + dlt);
                updateBpm(label);
            }
        };
    }

    private void updateBpm(TextView l) {
        l.setText("Tempo: " + this.host.getBpm() + " BPM");
    }

    // ---------- canales ----------
    private void channel(String label, final int... chans) {
        CheckBox cb = new CheckBox(this.act);
        cb.setText(label);
        cb.setTextColor(Color.WHITE);
        cb.setChecked(!this.synth.isMute(chans[0]));
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean on) {
                for (int c : chans) {
                    synth.setMute(c, !on);
                    host.muteChanged(c);
                }
            }
        });
        this.box.addView(cb);
    }

    // ---------- temporizador ----------
    private void sleepTimer() {
        final String[] names = {"Apagado", "15 minutos", "30 minutos", "60 minutos", "90 minutos"};
        final int[] mins = {0, 15, 30, 60, 90};
        new AlertDialog.Builder(this.act).setTitle("Detener el ritmo en...").setItems(names, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                if (sleepTask != null) {
                    H.removeCallbacks(sleepTask);
                    sleepTask = null;
                }
                if (mins[w] > 0) {
                    sleepTask = new Runnable() {
                        public void run() {
                            host.stopAll();
                        }
                    };
                    H.postDelayed(sleepTask, mins[w] * 60000L);
                    toast("El ritmo se detendra en " + mins[w] + " min");
                } else {
                    toast("Temporizador desactivado");
                }
            }
        }).show();
    }

    // ---------- biblioteca ----------
    private void pickStyle(String title, ArrayList<String> paths) {
        final ArrayList<File> files = new ArrayList<>();
        ArrayList<String> names = new ArrayList<>();
        for (String p : paths) {
            File f = new File(p);
            if (f.exists()) {
                files.add(f);
                names.add(f.getName());
            }
        }
        if (files.isEmpty()) {
            toast("No hay estilos en la lista");
            return;
        }
        new AlertDialog.Builder(this.act).setTitle(title).setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                host.loadStyle(files.get(w));
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        }).show();
    }

    private void toggleFav() {
        File f = this.host.currentStyle();
        if (f == null) {
            toast("No hay estilo cargado");
            return;
        }
        ArrayList<String> l = readList(this.pref, K_FAVS);
        if (l.remove(f.getAbsolutePath())) {
            toast("Quitado de favoritos");
        } else {
            l.add(f.getAbsolutePath());
            toast("★ Agregado a favoritos");
        }
        writeList(this.pref, K_FAVS, l);
    }

    // ---------- registros ----------
    boolean hasReg(int n) {
        return this.pref.contains("xreg" + n + "|bpm");
    }

    void saveReg(int n) {
        this.host.saveNow();
        SharedPreferences.Editor ed = this.pref.edit();
        for (Map.Entry<String, ?> en : this.pref.getAll().entrySet()) {
            String k = en.getKey();
            Object v = en.getValue();
            if (!k.startsWith("drums_")) {
                continue;
            }
            String nk = "xreg" + n + "|" + k;
            if (v instanceof String) {
                ed.putString(nk, (String) v);
            } else if (v instanceof Integer) {
                ed.putInt(nk, ((Integer) v).intValue());
            } else if (v instanceof Boolean) {
                ed.putBoolean(nk, ((Boolean) v).booleanValue());
            } else if (v instanceof Float) {
                ed.putFloat(nk, ((Float) v).floatValue());
            } else if (v instanceof Long) {
                ed.putLong(nk, ((Long) v).longValue());
            }
        }
        ed.putInt("xreg" + n + "|bpm", this.host.getBpm());
        ed.apply();
        toast("Registro " + n + " guardado");
    }

    void loadReg(int n) {
        if (!hasReg(n)) {
            toast("El registro " + n + " esta vacio");
            return;
        }
        String prefix = "xreg" + n + "|";
        SharedPreferences.Editor ed = this.pref.edit();
        String style = null;
        for (Map.Entry<String, ?> en : this.pref.getAll().entrySet()) {
            String k = en.getKey();
            Object v = en.getValue();
            if (!k.startsWith(prefix) || k.equals(prefix + "bpm")) {
                continue;
            }
            String nk = k.substring(prefix.length());
            if (nk.equals("drums_sty_path") && v instanceof String) {
                style = (String) v;
            }
            if (v instanceof String) {
                ed.putString(nk, (String) v);
            } else if (v instanceof Integer) {
                ed.putInt(nk, ((Integer) v).intValue());
            } else if (v instanceof Boolean) {
                ed.putBoolean(nk, ((Boolean) v).booleanValue());
            } else if (v instanceof Float) {
                ed.putFloat(nk, ((Float) v).floatValue());
            } else if (v instanceof Long) {
                ed.putLong(nk, ((Long) v).longValue());
            }
        }
        ed.commit();
        File cur = this.host.currentStyle();
        if (style != null && new File(style).exists() && (cur == null || !cur.getAbsolutePath().equals(style))) {
            this.host.loadStyle(new File(style));
        }
        this.host.restoreNow();
        this.host.setBpm(this.pref.getInt(prefix + "bpm", this.host.getBpm()));
        toast("Registro " + n + " recuperado");
        if (this.dialog != null) {
            this.dialog.dismiss();
        }
    }

    // ---------- tempo avanzado ----------
    private void genreTempo(final TextView label) {
        final String[] names = {"Balada lenta 65", "Bolero 80", "Pop 100", "Cumbia 95", "Reggaeton 92", "Rock 120", "Disco 125", "Salsa 180", "Vals 150"};
        final int[] bpms = {65, 80, 100, 95, 92, 120, 125, 180, 150};
        new AlertDialog.Builder(this.act).setTitle("Tempo por g\u00e9nero").setItems(names, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                host.setBpm(bpms[w]);
                updateBpm(label);
            }
        }).show();
    }

    private Runnable ramp(final int total, final TextView label) {
        return new Runnable() {
            public void run() {
                if (rampTask != null) {
                    H.removeCallbacks(rampTask);
                }
                final int target = Math.max(40, Math.min(240, host.getBpm() + total));
                final int step = total > 0 ? 1 : -1;
                rampTask = new Runnable() {
                    public void run() {
                        int cur = host.getBpm();
                        if (cur == target) {
                            rampTask = null;
                            return;
                        }
                        host.setBpm(cur + step);
                        updateBpm(label);
                        H.postDelayed(this, 350);
                    }
                };
                H.post(rampTask);
                toast(total > 0 ? "Acelerando..." : "Frenando...");
            }
        };
    }

    // ---------- mezcla / ambiente ----------
    private Runnable mix(final boolean drums, final boolean bass, final boolean harmony) {
        return new Runnable() {
            public void run() {
                int[] dr = {8, 9};
                int[] ba = {10};
                int[] ha = {11, 12, 13, 14, 15};
                for (int c : dr) {
                    synth.setMute(c, !drums);
                    host.muteChanged(c);
                }
                for (int c : ba) {
                    synth.setMute(c, !bass);
                    host.muteChanged(c);
                }
                for (int c : ha) {
                    synth.setMute(c, !harmony);
                    host.muteChanged(c);
                }
                toast("Mezcla aplicada");
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        };
    }

    private Runnable room(final double size, final double damp, final double width, final double level) {
        return new Runnable() {
            public void run() {
                try {
                    net.duceng.xsynth.XSynth.midiPlayerReverbOn(1);
                    net.duceng.xsynth.XSynth.midiPlayerReverb(size, damp, width, level);
                    toast("Ambiente aplicado");
                } catch (Throwable t) {
                    toast("No disponible en este motor");
                }
            }
        };
    }

    private void autoVariation() {
        final String[] names = {"Apagada", "Cada 2 compases", "Cada 4 compases", "Cada 8 compases", "Cada 16 compases"};
        final int[] bars = {0, 2, 4, 8, 16};
        new AlertDialog.Builder(this.act).setTitle("Cambiar de MAIN autom\u00e1ticamente").setItems(names, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int w) {
                host.setAutoVariation(bars[w]);
                toast(bars[w] == 0 ? "Auto-variaci\u00f3n apagada" : "Auto-variaci\u00f3n: " + names[w].toLowerCase());
            }
        }).show();
    }

    // ---------- biblioteca avanzada ----------
    private static void collect(File dir, ArrayList<File> out, int depth) {
        File[] fs = dir.listFiles();
        if (fs == null || depth > 4) {
            return;
        }
        for (File f : fs) {
            if (f.isDirectory()) {
                collect(f, out, depth + 1);
            } else if (f.getName().toLowerCase().endsWith(".sty")) {
                out.add(f);
            }
        }
    }

    private ArrayList<File> allStyles() {
        ArrayList<File> out = new ArrayList<>();
        collect(new File(Synth.PATH_STY), out, 0);
        java.util.Collections.sort(out, new java.util.Comparator<File>() {
            public int compare(File a, File b) {
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        return out;
    }

    private void searchStyle() {
        final ArrayList<File> all = allStyles();
        if (all.isEmpty()) {
            toast("No hay estilos en la carpeta");
            return;
        }
        final android.widget.EditText et = new android.widget.EditText(this.act);
        et.setHint("Parte del nombre...");
        new AlertDialog.Builder(this.act).setTitle("Buscar estilo").setView(et)
            .setPositiveButton("Buscar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    String q = et.getText().toString().trim().toLowerCase();
                    ArrayList<String> hits = new ArrayList<>();
                    for (File f : all) {
                        if (f.getName().toLowerCase().contains(q)) {
                            hits.add(f.getAbsolutePath());
                        }
                        if (hits.size() >= 60) {
                            break;
                        }
                    }
                    pickStyle("Resultados (" + hits.size() + ")", hits);
                }
            }).setNegativeButton("Cancelar", null).show();
    }

    private void stepStyle(int dir) {
        ArrayList<File> all = allStyles();
        if (all.isEmpty()) {
            toast("No hay estilos en la carpeta");
            return;
        }
        File cur = this.host.currentStyle();
        int idx = -1;
        for (int i = 0; i < all.size(); i++) {
            if (cur != null && all.get(i).getAbsolutePath().equals(cur.getAbsolutePath())) {
                idx = i;
            }
        }
        int next;
        if (dir == 0) {
            next = (int) (Math.random() * all.size());
        } else {
            next = ((idx < 0 ? 0 : idx + dir) + all.size()) % all.size();
        }
        this.host.loadStyle(all.get(next));
        toast(all.get(next).getName());
    }

    // ---------- copia de registros ----------
    private File backupFile() {
        return new File(Synth.PATH_ROOT, "registros.json");
    }

    private void backupRegs() {
        try {
            org.json.JSONObject root = new org.json.JSONObject();
            for (Map.Entry<String, ?> en : this.pref.getAll().entrySet()) {
                if (!en.getKey().startsWith("xreg")) {
                    continue;
                }
                Object v = en.getValue();
                org.json.JSONArray a = new org.json.JSONArray();
                if (v instanceof Integer) {
                    a.put("i").put(((Integer) v).intValue());
                } else if (v instanceof Boolean) {
                    a.put("b").put(((Boolean) v).booleanValue());
                } else if (v instanceof String) {
                    a.put("s").put((String) v);
                } else {
                    continue;
                }
                root.put(en.getKey(), a);
            }
            java.io.FileOutputStream os = new java.io.FileOutputStream(backupFile());
            os.write(root.toString().getBytes("UTF-8"));
            os.close();
            toast("Copia guardada en registros.json");
        } catch (Exception e) {
            toast("No se pudo guardar la copia");
        }
    }

    private void restoreRegs() {
        try {
            File f = backupFile();
            if (!f.exists()) {
                toast("No hay copia (registros.json)");
                return;
            }
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] buf = new byte[(int) f.length()];
            int off = 0;
            while (off < buf.length) {
                int n = in.read(buf, off, buf.length - off);
                if (n <= 0) {
                    break;
                }
                off += n;
            }
            in.close();
            org.json.JSONObject root = new org.json.JSONObject(new String(buf, "UTF-8"));
            SharedPreferences.Editor ed = this.pref.edit();
            java.util.Iterator<String> it = root.keys();
            while (it.hasNext()) {
                String k = it.next();
                org.json.JSONArray a = root.getJSONArray(k);
                String t = a.getString(0);
                if ("i".equals(t)) {
                    ed.putInt(k, a.getInt(1));
                } else if ("b".equals(t)) {
                    ed.putBoolean(k, a.getBoolean(1));
                } else {
                    ed.putString(k, a.getString(1));
                }
            }
            ed.commit();
            toast("Registros restaurados");
            if (this.dialog != null) {
                this.dialog.dismiss();
            }
        } catch (Exception e) {
            toast("No se pudo restaurar la copia");
        }
    }

    // ---------- helpers de vista ----------
    private void toast(String s) {
        Toast.makeText(this.act, s, Toast.LENGTH_SHORT).show();
    }

    private TextView text(String s) {
        TextView t = new TextView(this.act);
        t.setText(s);
        t.setTextColor(0xffcccccc);
        t.setTextSize(14);
        t.setPadding(0, 6, 0, 6);
        return t;
    }

    private void header(String s) {
        TextView t = new TextView(this.act);
        t.setText(s.toUpperCase());
        t.setTextColor(0xffc9a55c);
        t.setTextSize(13);
        t.setPadding(0, (int) (14 * this.act.getResources().getDisplayMetrics().density), 0, 4);
        this.box.addView(t);
    }

    private Button button(String s, final Runnable r) {
        Button b = new Button(this.act);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                r.run();
            }
        });
        return b;
    }

    private Button small(String s, final Runnable r) {
        Button b = button(s, r);
        b.setTextSize(11);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(2, 0, 2, 0);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        return b;
    }

    private void row(View... views) {
        LinearLayout l = new LinearLayout(this.act);
        l.setGravity(Gravity.CENTER_VERTICAL);
        for (View v : views) {
            l.addView(v, new LinearLayout.LayoutParams(0, -2, 1.0f));
        }
        this.box.addView(l);
    }

    private void toggle(String label, final String key, boolean def) {
        CheckBox cb = new CheckBox(this.act);
        cb.setText(label);
        cb.setTextColor(Color.WHITE);
        cb.setChecked(this.pref.getBoolean(key, def));
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean on) {
                pref.edit().putBoolean(key, on).apply();
                host.applyScreen();
            }
        });
        this.box.addView(cb);
    }

    private void slider(String label, int max, int progress, SeekBar.OnSeekBarChangeListener l) {
        this.box.addView(text(label));
        SeekBar sb = new SeekBar(this.act);
        sb.setMax(max);
        sb.setProgress(Math.max(0, Math.min(max, progress)));
        sb.setOnSeekBarChangeListener(l);
        this.box.addView(sb);
    }
}
