package net.duceng.xmidi;

import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import java.io.File;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.duceng.midi.EventChannel;
import net.duceng.midi.MidiFile;
import net.duceng.midi.MidiUtil;
import net.duceng.xmidi.ui.DialogChannel;
import net.duceng.xmidi.ui.DialogChord;
import net.duceng.xmidi.ui.DialogPreset;
import net.duceng.xmidi.ui.DialogRhythm;
import net.duceng.xmidi.ui.DialogTonality;
import net.duceng.xmidi.util.Chords;
import net.duceng.xmidi.util.Rhythm;
import net.duceng.xmidi.widgets.GRhythm;
import net.duceng.xmidi.widgets.GuitarBoard;
import net.duceng.xmidi.widgets.MusicScore;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes3.dex */
public class Guitar extends BaseApp {
    private static int INSTRUMENT = 24;
    private ImageButton bAuto;
    private Button bPreset;
    private Button bTonality;
    private Chords.Chord chord;
    private Button chordLongBtn;
    private DialogChannel dialogChann;
    private DialogChord dialogChord;
    private DialogRhythm dialogRhythm;
    private DialogTonality dialogTonality;
    private View dih0;
    private View div0;
    private GuitarBoard gBoard;
    private MusicScore gScore;
    private LinearLayout glayout;
    private LinearLayout glchords0;
    private LinearLayout glchords1;
    private LinearLayout glrhythms;
    private ExecutorService mExecutor;
    private Runnable mRunnable;
    private List<EventChannel> notes;
    private Rhythm rhythm;
    private GRhythm rhythmLongGr;
    private Button[] gchords = new Button[8];
    private GRhythm[] grhythms = new GRhythm[3];
    private Chords guitarChords = new Chords();
    private boolean auto = false;
    private boolean playing = false;
    private int idxBeat = 0;
    private View.OnTouchListener chordTouchListener = new View.OnTouchListener() { // from class: net.duceng.xmidi.Guitar.1
        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View v, MotionEvent event) {
            int action = event.getAction() & 255;
            if (action != 0) {
                return false;
            }
            Button b = (Button) v;
            if (b.isSelected()) {
                return false;
            }
            Guitar.this.chordSelect((Button) v);
            return false;
        }
    };
    private View.OnLongClickListener chordLongClickListener = new View.OnLongClickListener() { // from class: net.duceng.xmidi.Guitar.2
        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View v) {
            Guitar.this.chordLongBtn = (Button) v;
            if (Guitar.this.dialogChord == null) {
                Guitar.this.dialogChord = new DialogChord(Guitar.this, Guitar.this.guitarChords);
                Guitar.this.dialogChord.setOnSelectListener(new DialogChord.OnSelectListener() { // from class: net.duceng.xmidi.Guitar.2.1
                    @Override // net.duceng.xmidi.ui.DialogChord.OnSelectListener
                    public boolean onSelect(int idx) {
                        Chords.Chord c = Guitar.this.guitarChords.getChord(idx);
                        Guitar.this.chordLongBtn.setText(c.name);
                        Guitar.this.chordLongBtn.setTag(c);
                        Guitar.this.chordSelect(Guitar.this.chordLongBtn);
                        Guitar.this.dialogChord.dismiss();
                        return true;
                    }
                });
            }
            Guitar.this.dialogChord.show();
            return true;
        }
    };
    private View.OnTouchListener rhythmTouchListener = new View.OnTouchListener() { // from class: net.duceng.xmidi.Guitar.3
        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View v, MotionEvent event) {
            int action = event.getAction() & 255;
            if (action == 0) {
                GRhythm g = (GRhythm) v;
                if (!g.isSelected()) {
                    Guitar.this.rhythmSelect(g);
                } else {
                    g.setSelected(false);
                    Guitar.this.playing = false;
                    Guitar.this.rhythm = null;
                    Guitar.this.notes = null;
                }
            }
            return false;
        }
    };
    private View.OnLongClickListener rhythmLongClickListener = new View.OnLongClickListener() { // from class: net.duceng.xmidi.Guitar.4
        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View v) {
            Guitar.this.rhythmLongGr = (GRhythm) v;
            Guitar.this.dialogRhythm.setOnSelectListener(new DialogRhythm.OnSelectListener() { // from class: net.duceng.xmidi.Guitar.4.1
                @Override // net.duceng.xmidi.ui.DialogRhythm.OnSelectListener
                public boolean onSelect(Rhythm r) {
                    Guitar.this.rhythmLongGr.setRhythm(r);
                    Guitar.this.rhythmLongGr.setTag(r);
                    Guitar.this.rhythmSelect(Guitar.this.rhythmLongGr);
                    Guitar.this.dialogRhythm.dismiss();
                    return true;
                }
            });
            Guitar.this.rhythmLongGr.setSelected(false);
            Guitar.this.playing = false;
            Guitar.this.rhythm = null;
            Guitar.this.notes = null;
            Guitar.this.dialogRhythm.show();
            return true;
        }
    };

    static /* synthetic */ int access$908(Guitar x0) {
        int i = x0.idxBeat;
        x0.idxBeat = i + 1;
        return i;
    }

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guitar);
        this.title.setText(R.string.guitar);
        for (int i = 0; i < this.listMore.size(); i++) {
            if (this.listMore.get(i).getId() == R.id.act_guitar) {
                ((Button) this.listMore.get(i)).setBackgroundResource(R.color.disabled);
                this.listMore.get(i).setVisibility(8);
                this.listMore.get(i + 1).setVisibility(8);
                break;
            }
        }
        LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.action_guitar, (ViewGroup) null);
        while (layout.getChildCount() > 0) {
            View child = layout.getChildAt(0);
            layout.removeView(child);
            this.listBottom.add(child);
            child.setOnClickListener(this.actionClickListener);
            if (child.getId() == R.id.guitar_tonality) {
                this.bTonality = (Button) child;
            } else if (child.getId() == R.id.guitar_preset) {
                this.bPreset = (Button) child;
                child.setOnLongClickListener(new View.OnLongClickListener() { // from class: net.duceng.xmidi.Guitar.5
                    private DialogPreset dialogPreset;

                    @Override // android.view.View.OnLongClickListener
                    public boolean onLongClick(View v) {
                        if (this.dialogPreset == null) {
                            this.dialogPreset = new DialogPreset(Guitar.this, Guitar.this.synth);
                            this.dialogPreset.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: net.duceng.xmidi.Guitar.5.1
                                @Override // android.content.DialogInterface.OnDismissListener
                                public void onDismiss(DialogInterface dialog) {
                                    Guitar.this.bPreset.setText(Guitar.this.getPresetName(Guitar.this.synth.getRecordChan()));
                                }
                            });
                        }
                        this.dialogPreset.setChannel(Guitar.this.synth.getRecordChan());
                        this.dialogPreset.show();
                        return true;
                    }
                });
            } else if (child.getId() == R.id.guitar_auto) {
                this.bAuto = (ImageButton) child;
            }
        }
        this.glayout = (LinearLayout) findViewById(R.id.guitar_layout);
        this.glchords0 = (LinearLayout) findViewById(R.id.guitar_chords0);
        this.glchords1 = (LinearLayout) findViewById(R.id.guitar_chords1);
        this.glrhythms = (LinearLayout) findViewById(R.id.guitar_rhythms);
        this.dih0 = findViewById(R.id.guitar_divider_h0);
        this.div0 = findViewById(R.id.guitar_divider_v0);
        this.gchords[0] = (Button) findViewById(R.id.guitar_chord0);
        this.gchords[1] = (Button) findViewById(R.id.guitar_chord1);
        this.gchords[2] = (Button) findViewById(R.id.guitar_chord2);
        this.gchords[3] = (Button) findViewById(R.id.guitar_chord3);
        this.gchords[4] = (Button) findViewById(R.id.guitar_chord4);
        this.gchords[5] = (Button) findViewById(R.id.guitar_chord5);
        this.gchords[6] = (Button) findViewById(R.id.guitar_chord6);
        this.gchords[7] = (Button) findViewById(R.id.guitar_chord7);
        this.grhythms[0] = (GRhythm) findViewById(R.id.guitar_rhythm0);
        this.grhythms[1] = (GRhythm) findViewById(R.id.guitar_rhythm1);
        this.grhythms[2] = (GRhythm) findViewById(R.id.guitar_rhythm2);
        this.gBoard = (GuitarBoard) findViewById(R.id.guitar_board);
        this.gScore = (MusicScore) findViewById(R.id.guitar_score);
        this.gScore.setScrollVert(true);
        Chords.Chord[] chords = this.guitarChords.getGChords(0);
        for (int i2 = 0; i2 < chords.length; i2++) {
            this.gchords[i2].setText(chords[i2].name);
            this.gchords[i2].setTag(chords[i2]);
            this.gchords[i2].setOnTouchListener(this.chordTouchListener);
            this.gchords[i2].setOnLongClickListener(this.chordLongClickListener);
        }
        this.dialogRhythm = new DialogRhythm(this, this.synth);
        this.dialogRhythm.getAdapter().setBeat(this.synth.getNumerator());
        for (int i3 = 0; i3 < this.grhythms.length; i3++) {
            Rhythm r = this.dialogRhythm.getAdapter().getItem(i3);
            this.grhythms[i3].setRhythm(r);
            this.grhythms[i3].setTag(r);
            this.grhythms[i3].setOnTouchListener(this.rhythmTouchListener);
            this.grhythms[i3].setOnLongClickListener(this.rhythmLongClickListener);
        }
        chordSelect(this.gchords[0]);
        this.mExecutor = Executors.newSingleThreadExecutor();
        this.mRunnable = new Runnable() { // from class: net.duceng.xmidi.Guitar.6
            @Override // java.lang.Runnable
            public void run() {
                Guitar.this.playing = true;
                while (Guitar.this.playing && !Guitar.this.synth.isPlaying()) {
                    Guitar.this.idxBeat = 0;
                    while (Guitar.this.idxBeat < Guitar.this.synth.getNumerator()) {
                        Guitar.this.playNotes();
                        if (!Guitar.this.playing || Guitar.this.synth.isPlaying()) {
                            break;
                        } else {
                            Guitar.access$908(Guitar.this);
                        }
                    }
                }
                Guitar.this.playing = false;
            }
        };
        this.synth.setBeatListener(new Synth.BeatListener() { // from class: net.duceng.xmidi.Guitar.7
            long pre = 0L;
            private ExecutorService executor = Executors.newSingleThreadExecutor();
            private Runnable run = new Runnable() { // from class: net.duceng.xmidi.Guitar.7.1
                @Override // java.lang.Runnable
                public void run() {
                    Guitar.this.playNotes();
                }
            };

            @Override // net.duceng.xsynth.Synth.BeatListener
            public void onBeating(long ticks) {
                if (Guitar.this.auto) {
                    this.executor.execute(this.run);
                    Guitar.access$908(Guitar.this);
                    if (Guitar.this.idxBeat >= Guitar.this.synth.getNumerator()) {
                        Guitar.this.idxBeat = 0;
                    }
                    Guitar.this.gScore.shadeNotes((int) ticks, (int) this.pre, 2);
                    this.pre = ticks;
                }
            }
        });
        this.gBoard.setGuitarBoardListener(new GuitarBoard.GuitarBoardListener() { // from class: net.duceng.xmidi.Guitar.8
            @Override // net.duceng.xmidi.widgets.GuitarBoard.GuitarBoardListener
            public void onKeysChanged(int note, int val) {
                Guitar.this.synth.noteOn((byte) note, (byte) val);
            }
        });
    }

    public void playNotes() {
        if (this.notes != null) {
            long lastSleep = System.currentTimeMillis();
            int mpqn = this.synth.getMidiFile().getTempo().getMpqn();
            int res = this.synth.getResolution();
            int tickStart = (this.idxBeat % this.rhythm.getBeat()) * MidiFile.DEFAULT_RESOLUTION;
            int tickEnd = tickStart + MidiFile.DEFAULT_RESOLUTION;
            long lastSleep2 = lastSleep;
            int lastTick = tickStart;
            for (EventChannel note : this.notes) {
                if (note.getTick() >= tickStart) {
                    if (note.getTick() <= tickEnd && ((note.getTick() != tickStart || note.getType() != 8) && (note.getTick() != tickEnd || note.getType() != 9))) {
                        int delta = ((note.getTick() - lastTick) * res) / MidiFile.DEFAULT_RESOLUTION;
                        if (delta > 0) {
                            long deltamillis = ((long) MidiUtil.ticksToMs(delta, mpqn, res)) - (System.currentTimeMillis() - lastSleep2);
                            if (deltamillis > 0) {
                                try {
                                    Thread.sleep(deltamillis);
                                } catch (InterruptedException e) {
                                    throw new RuntimeException("Interrupted during guitar sleep.");
                                }
                            }
                            lastSleep2 = System.currentTimeMillis();
                        }
                        switch (note.getType()) {
                            case 8:
                                this.synth.noteOff(note.getValue1());
                                break;
                            case 9:
                                this.synth.noteOn(note.getValue1(), note.getValue2());
                                break;
                        }
                        lastTick = note.getTick();
                    }
                    if (this.synth.isPlaying() && tickEnd > lastTick) {
                        long deltamillis2 = ((long) MidiUtil.ticksToMs(((tickEnd - lastTick) * res) / MidiFile.DEFAULT_RESOLUTION, mpqn, res)) - (System.currentTimeMillis() - lastSleep2);
                        if (deltamillis2 > 0) {
                            try {
                                Thread.sleep(deltamillis2);
                                return;
                            } catch (InterruptedException e2) {
                                throw new RuntimeException("Interrupted during guitar sleep.");
                            }
                        }
                        return;
                    }
                }
            }
            this.synth.isPlaying();
        }
    }

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base, android.app.Activity
    protected void onStart() {
        this.synth.setRecordChan((byte) 1);
        this.synth.setPreset(this.synth.getRecordChan(), INSTRUMENT);
        this.synth.setSustain(this.synth.getRecordChan(), 64);
        this.bPreset.setText(getPresetName(this.synth.getRecordChan()));
        super.onStart();
    }

    @Override // net.duceng.xmidi.BaseApp, android.app.Activity
    protected void onDestroy() {
        this.playing = false;
        this.mExecutor.shutdown();
        super.onDestroy();
    }

    @Override // net.duceng.xmidi.Base, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (this.isPortRait) {
            this.glayout.setOrientation(1);
            this.gScore.getLayoutParams().width = -1;
            this.gScore.getLayoutParams().height = 0;
            this.gBoard.getLayoutParams().width = -1;
            this.gBoard.getLayoutParams().height = 0;
            this.glchords0.setOrientation(0);
            this.glchords0.getLayoutParams().width = -1;
            this.glchords0.getLayoutParams().height = 0;
            this.glchords1.setOrientation(0);
            this.glchords1.getLayoutParams().width = -1;
            this.glchords1.getLayoutParams().height = 0;
            this.glrhythms.setOrientation(0);
            this.glrhythms.getLayoutParams().width = -1;
            this.glrhythms.getLayoutParams().height = 0;
            for (int i = 0; i < this.grhythms.length; i++) {
                this.grhythms[i].setDegree(0);
                this.grhythms[i].getLayoutParams().width = 0;
                this.grhythms[i].getLayoutParams().height = -1;
            }
            for (int i2 = 0; i2 < this.gchords.length; i2++) {
                this.gchords[i2].getLayoutParams().width = 0;
                this.gchords[i2].getLayoutParams().height = -1;
            }
            this.dih0.setVisibility(0);
            this.div0.setVisibility(8);
        } else {
            this.glayout.setOrientation(0);
            this.gScore.getLayoutParams().width = 0;
            this.gScore.getLayoutParams().height = -1;
            this.gBoard.getLayoutParams().width = 0;
            this.gBoard.getLayoutParams().height = -1;
            this.glchords0.setOrientation(1);
            this.glchords0.getLayoutParams().width = 0;
            this.glchords0.getLayoutParams().height = -1;
            this.glchords1.setOrientation(1);
            this.glchords1.getLayoutParams().width = 0;
            this.glchords1.getLayoutParams().height = -1;
            this.glrhythms.setOrientation(1);
            this.glrhythms.getLayoutParams().width = 0;
            this.glrhythms.getLayoutParams().height = -1;
            for (int i3 = 0; i3 < this.grhythms.length; i3++) {
                this.grhythms[i3].setDegree(-90);
                this.grhythms[i3].getLayoutParams().width = -1;
                this.grhythms[i3].getLayoutParams().height = 0;
            }
            for (int i4 = 0; i4 < this.gchords.length; i4++) {
                this.gchords[i4].getLayoutParams().width = -1;
                this.gchords[i4].getLayoutParams().height = 0;
            }
            this.dih0.setVisibility(8);
            this.div0.setVisibility(0);
        }
        this.bPreset.setText(getPresetName(this.synth.getRecordChan()));
    }

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base
    protected void onActionClick(View v) {
        switch (v.getId()) {
            case R.id.guitar_auto /* 2130968695 */:
                this.auto = !this.auto;
                if (this.auto) {
                    this.bAuto.getDrawable().setLevel(1);
                    this.gScore.setVisibility(0);
                    this.gBoard.setVisibility(8);
                } else {
                    this.bAuto.getDrawable().setLevel(0);
                    this.gScore.setVisibility(8);
                    this.gBoard.setVisibility(0);
                }
                break;
            case R.id.guitar_preset /* 2130968710 */:
                if (this.dialogChann == null) {
                    this.dialogChann = new DialogChannel(this, this.synth);
                    this.dialogChann.setOnSelectListener(new DialogChannel.OnSelectListener() { // from class: net.duceng.xmidi.Guitar.9
                        @Override // net.duceng.xmidi.ui.DialogChannel.OnSelectListener
                        public void onSelect(int chan, int preset, String instrument) {
                            Guitar.this.synth.setRecordChan((byte) chan);
                            Guitar.this.bPreset.setText(Guitar.this.getPresetName(chan));
                            Guitar.this.dialogChann.dismiss();
                        }
                    });
                }
                this.dialogChann.show();
                break;
            case R.id.guitar_tonality /* 2130968716 */:
                if (this.dialogTonality == null) {
                    this.dialogTonality = new DialogTonality(this, this.guitarChords);
                    this.dialogTonality.setOnSelectListener(new DialogTonality.OnSelectListener() { // from class: net.duceng.xmidi.Guitar.10
                        @Override // net.duceng.xmidi.ui.DialogTonality.OnSelectListener
                        public boolean onSelect(int id) {
                            Chords.Chord[] chords = Guitar.this.guitarChords.getGChords(id);
                            for (int i = 0; i < chords.length; i++) {
                                Guitar.this.gchords[i].setText(chords[i].name);
                                Guitar.this.gchords[i].setTag(chords[i]);
                            }
                            Guitar.this.chordSelect(Guitar.this.gchords[0]);
                            Guitar.this.bTonality.setText(chords[0].name);
                            Guitar.this.dialogTonality.dismiss();
                            return true;
                        }
                    });
                }
                this.dialogTonality.show();
                break;
            default:
                super.onActionClick(v);
                break;
        }
    }

    public void chordSelect(Button b) {
        for (int i = 0; i < this.gchords.length; i++) {
            this.gchords[i].setSelected(false);
        }
        b.setSelected(true);
        this.chord = (Chords.Chord) b.getTag();
        this.gBoard.setFingers(this.chord.gfingers);
        if (this.rhythm != null) {
            this.notes = this.rhythm.getNotes(this.chord);
        }
    }

    public void rhythmSelect(GRhythm b) {
        for (int i = 0; i < this.grhythms.length; i++) {
            this.grhythms[i].setSelected(false);
        }
        b.setSelected(true);
        this.rhythm = (Rhythm) b.getTag();
        if (this.chord == null) {
            chordSelect(this.gchords[0]);
        }
        this.notes = this.rhythm.getNotes(this.chord);
        if (!this.auto && !this.synth.isPlaying() && !this.playing) {
            this.mExecutor.execute(this.mRunnable);
        }
    }

    @Override // net.duceng.xmidi.BaseApp
    protected void onMidiChanged(File f) {
        super.onMidiChanged(f);
        this.gScore.setMidiFile(this.synth.getMidiFile(), this.synth.getScores());
    }

    @Override // net.duceng.xmidi.BaseApp
    protected void onTrackChanged() {
        super.onTrackChanged();
        this.gScore.setMidiFile(this.synth.getMidiFile(), this.synth.getScores());
    }
}
