package net.duceng.xmidi;

import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import java.io.File;
import net.duceng.xmidi.ui.DialogChannel;
import net.duceng.xmidi.ui.DialogPreset;
import net.duceng.xmidi.widgets.MusicScore;
import net.duceng.xmidi.widgets.PianoBoard;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes3.dex */
public class Keyboard extends BaseApp {
    private Button bPreset;
    private ImageButton buttonLock;
    private DialogChannel channDialog;
    private MusicScore musicScore;
    private PianoBoard pianoBoard;
    private PianoBoard pianoBoardFix;
    private int scoreStatus = 0;
    private final java.util.concurrent.ExecutorService scoreExec = java.util.concurrent.Executors.newSingleThreadExecutor();
    private PianoBoard.PianoBoardListener pianoListener = new PianoBoard.PianoBoardListener() { // from class: net.duceng.xmidi.Keyboard.1
        @Override // net.duceng.xmidi.widgets.PianoBoard.PianoBoardListener
        public void onKeysChanged(int note, int val) {
            Keyboard.this.synth.noteOn((byte) note, (byte) val);
        }
    };

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.keyboard);
        this.title.setText(R.string.keyboard);
        for (int i = 0; i < this.listMore.size(); i++) {
            if (this.listMore.get(i).getId() == R.id.act_keyboard) {
                ((Button) this.listMore.get(i)).setBackgroundResource(R.color.disabled);
                this.listMore.get(i).setVisibility(8);
                this.listMore.get(i + 1).setVisibility(8);
                break;
            }
        }
        LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.action_keyboard, (ViewGroup) null);
        while (layout.getChildCount() > 0) {
            View child = layout.getChildAt(0);
            layout.removeView(child);
            this.listBottom.add(child);
            child.setOnClickListener(this.actionClickListener);
            if (child.getId() == R.id.keyboard_preset) {
                this.bPreset = (Button) child;
                child.setOnLongClickListener(new View.OnLongClickListener() { // from class: net.duceng.xmidi.Keyboard.2
                    private DialogPreset dialogPreset;

                    @Override // android.view.View.OnLongClickListener
                    public boolean onLongClick(View v) {
                        if (this.dialogPreset == null) {
                            this.dialogPreset = new DialogPreset(Keyboard.this, Keyboard.this.synth);
                            this.dialogPreset.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: net.duceng.xmidi.Keyboard.2.1
                                @Override // android.content.DialogInterface.OnDismissListener
                                public void onDismiss(DialogInterface dialog) {
                                    Keyboard.this.bPreset.setText(Keyboard.this.getPresetName(Keyboard.this.synth.getRecordChan()));
                                }
                            });
                        }
                        this.dialogPreset.setChannel(Keyboard.this.synth.getRecordChan());
                        this.dialogPreset.show();
                        return true;
                    }
                });
            } else if (child.getId() == R.id.keyboard_lock) {
                this.buttonLock = (ImageButton) child;
            }
        }
        File f = (File) getIntent().getSerializableExtra("file");
        if (f != null) {
            this.synth.setFile(f);
        }
        this.musicScore = (MusicScore) findViewById(R.id.music_score);
        this.pianoBoard = (PianoBoard) findViewById(R.id.piano_board);
        this.pianoBoardFix = (PianoBoard) findViewById(R.id.piano_board_fix);
        this.instruments = getResources().getStringArray(R.array.preset_instruments);
        this.drums = getResources().getStringArray(R.array.preset_drums);
        this.pianoBoard.setScroll(67);
        this.pianoBoardFix.setScroll(55);
        this.pianoBoard.setPianoBoardListener(this.pianoListener);
        this.pianoBoardFix.setPianoBoardListener(this.pianoListener);
        this.synth.setBeatListener(new Synth.BeatListener() {
            private long pre = 0;
            private final java.util.concurrent.atomic.AtomicLong latest = new java.util.concurrent.atomic.AtomicLong(0);
            private final java.util.concurrent.atomic.AtomicBoolean pending = new java.util.concurrent.atomic.AtomicBoolean(false);

            @Override // net.duceng.xsynth.Synth.BeatListener
            public void onBeating(long ticks) {
                // El dibujo de la partitura va en otro hilo para no frenar la reproduccion
                this.latest.set(ticks);
                if (this.pending.compareAndSet(false, true)) {
                    Keyboard.this.scoreExec.execute(new Runnable() {
                        @Override
                        public void run() {
                            pending.set(false);
                            long t = latest.get();
                            try {
                                Keyboard.this.musicScore.shadeNotes((int) t, (int) pre, 2);
                            } catch (RuntimeException e) {
                                e.printStackTrace();
                            }
                            pre = t;
                        }
                    });
                }
            }
        });
    }

    @Override // net.duceng.xmidi.BaseApp, android.app.Activity
    protected void onDestroy() {
        this.synth.setBeatListener(null);
        this.scoreExec.shutdownNow();
        super.onDestroy();
    }

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base, android.app.Activity
    protected void onStart() {
        this.synth.setRecordChan((byte) 0);
        this.bPreset.setText(getPresetName(this.synth.getRecordChan()));
        super.onStart();
    }

    @Override // net.duceng.xmidi.Base, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        changeScore();
        this.bPreset.setText(getPresetName(this.synth.getRecordChan()));
    }

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base
    protected void onActionClick(View v) {
        switch (v.getId()) {
            case R.id.keyboard_lock /* 2130968718 */:
                this.pianoBoard.setLocked(!this.pianoBoard.isLocked());
                this.pianoBoardFix.setLocked(!this.pianoBoardFix.isLocked());
                if (this.pianoBoard.isLocked()) {
                    this.buttonLock.getDrawable().setLevel(1);
                } else {
                    this.buttonLock.getDrawable().setLevel(0);
                }
                break;
            case R.id.keyboard_preset /* 2130968719 */:
                if (this.channDialog == null) {
                    this.channDialog = new DialogChannel(this, this.synth);
                    this.channDialog.setOnSelectListener(new DialogChannel.OnSelectListener() { // from class: net.duceng.xmidi.Keyboard.4
                        @Override // net.duceng.xmidi.ui.DialogChannel.OnSelectListener
                        public void onSelect(int chan, int preset, String instrument) {
                            Keyboard.this.synth.setRecordChan((byte) chan);
                            Keyboard.this.bPreset.setText(Keyboard.this.getPresetName(chan));
                            Keyboard.this.channDialog.dismiss();
                        }
                    });
                }
                this.channDialog.show();
                break;
            case R.id.keyboard_score /* 2130968720 */:
                this.scoreStatus++;
                if (this.scoreStatus > 2) {
                    this.scoreStatus = 0;
                }
                changeScore();
                break;
            default:
                super.onActionClick(v);
                break;
        }
    }

    @Override // net.duceng.xmidi.BaseApp
    protected void onMidiChanged(File f) {
        super.onMidiChanged(f);
        this.musicScore.setMidiFile(this.synth.getMidiFile(), this.synth.getScores());
    }

    @Override // net.duceng.xmidi.BaseApp
    protected void onTrackChanged() {
        super.onTrackChanged();
        this.musicScore.setMidiFile(this.synth.getMidiFile(), this.synth.getScores());
    }

    private void changeScore() {
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) this.musicScore.getLayoutParams();
        if (this.isPortRait) {
            lp.weight = this.scoreStatus == 1 ? 2.0f : 1.0f;
            this.musicScore.setVisibility(0);
            this.musicScore.setScrollVert(this.scoreStatus != 0);
            this.pianoBoard.setVisibility(this.scoreStatus > 0 ? 8 : 0);
            this.pianoBoardFix.setVisibility(this.scoreStatus <= 1 ? 0 : 8);
            return;
        }
        lp.weight = 1.0f;
        this.musicScore.setVisibility(this.scoreStatus > 1 ? 8 : 0);
        this.musicScore.setScrollVert(this.scoreStatus != 0);
        this.pianoBoard.setVisibility(this.scoreStatus > 1 ? 0 : 8);
        this.pianoBoardFix.setVisibility(this.scoreStatus != 1 ? 0 : 8);
    }
}
