package net.duceng.xmidi;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.duceng.midi.MetaTempo;
import net.duceng.xmidi.widgets.BImage;
import net.duceng.xmidi.widgets.MetronomeHand;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes3.dex */
public class Metronome extends BaseApp {
    private static int[] SPEED = {0, 60, 66, 76, 108, MetaTempo.DEFAULT_BPM, 168};
    private BImage bk;
    private MetronomeHand hand;
    private ExecutorService mExecutor;
    private Runnable mRunnable;
    private TextView speed;
    private TextView speedName;
    private String[] speeds;
    private ImageButton start_btn;
    private int tempo = 4;
    private boolean running = false;

    static /* synthetic */ int access$408(Metronome x0) {
        int i = x0.tempo;
        x0.tempo = i + 1;
        return i;
    }

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.metronome);
        this.title.setText(R.string.metronome);
        for (int i = 0; i < this.listMore.size(); i++) {
            if (this.listMore.get(i).getId() == R.id.act_metronome) {
                ((Button) this.listMore.get(i)).setBackgroundResource(R.color.focused);
                this.listMore.get(i).setVisibility(8);
                this.listMore.get(i + 1).setVisibility(8);
                break;
            }
        }
        this.listTop.clear();
        this.listBottom.clear();
        this.title.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        this.title.setClickable(false);
        this.title.setLongClickable(false);
        this.speeds = getResources().getStringArray(R.array.metronome_speeds);
        this.bk = (BImage) findViewById(R.id.metronome_bk);
        this.bk.setImageResource(R.drawable.metronome);
        this.start_btn = (ImageButton) findViewById(R.id.metronome_start_btn);
        this.speed = (TextView) findViewById(R.id.metronome_speed);
        this.speedName = (TextView) findViewById(R.id.metronome_speed_name);
        this.hand = (MetronomeHand) findViewById(R.id.metronome_hand);
        this.hand.setSpeedListener(new MetronomeHand.SpeedListener() { // from class: net.duceng.xmidi.Metronome.1
            @Override // net.duceng.xmidi.widgets.MetronomeHand.SpeedListener
            public void onSpeedChanged(int sp) {
                Metronome.this.speed.setText(String.valueOf(sp));
                int idx = 0;
                for (int i2 = 0; i2 < Metronome.SPEED.length && sp > Metronome.SPEED[i2]; i2++) {
                    idx = i2;
                }
                Metronome.this.speedName.setText(Metronome.this.speeds[idx]);
                if (Metronome.this.synth != null) {
                    Metronome.this.synth.getMidiFile().getTempo().setBpm(sp);
                }
            }
        });
        final TextView textTempo = (TextView) findViewById(R.id.metronome_tempo);
        this.start_btn.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.Metronome.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Metronome.access$408(Metronome.this);
                if (Metronome.this.tempo > 12) {
                    Metronome.this.tempo = 1;
                }
                textTempo.setText(String.valueOf(Metronome.this.tempo));
                Metronome.this.synth.getMidiFile().getTimeSignature().setNumerator((byte) Metronome.this.tempo);
            }
        });
        this.hand.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.Metronome.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (Metronome.this.synth.isPlaying()) {
                    Metronome.this.synth.stop();
                    Metronome.this.running = false;
                } else {
                    Metronome.this.synth.play();
                    Metronome.this.running = true;
                    Metronome.this.mExecutor.execute(Metronome.this.mRunnable);
                }
            }
        });
        this.mExecutor = Executors.newSingleThreadExecutor();
        this.mRunnable = new Runnable() { // from class: net.duceng.xmidi.Metronome.4
            @Override // java.lang.Runnable
            public void run() {
                while (Metronome.this.running) {
                    if (Metronome.this.synth != null) {
                        Metronome.this.setPercent(Metronome.this.synth.getBeatPercent());
                    }
                    try {
                        Thread.sleep(50L);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                Metronome.this.setPercent(0.0f);
            }
        };
    }

    public void setPercent(final float percent) {
        runOnUiThread(new Runnable() { // from class: net.duceng.xmidi.Metronome.5
            @Override // java.lang.Runnable
            public void run() {
                Metronome.this.hand.setPercent(percent);
            }
        });
    }

    @Override // net.duceng.xmidi.BaseApp, android.app.Activity
    protected void onDestroy() {
        this.running = false;
        this.mExecutor.shutdown();
        super.onDestroy();
    }

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base, android.app.Activity
    protected void onStart() {
        this.synth.setFile(null);
        this.synth.setBeating(true);
        int bpm = this.synth.getMidiFile().getTempo().getBpm();
        this.speed.setText(String.valueOf(bpm));
        int idx = 0;
        for (int i = 0; i < SPEED.length && bpm > SPEED[i]; i++) {
            idx = i;
        }
        this.speedName.setText(this.speeds[idx]);
        super.onStart();
    }
}
