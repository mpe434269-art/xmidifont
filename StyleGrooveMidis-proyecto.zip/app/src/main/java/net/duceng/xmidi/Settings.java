package net.duceng.xmidi;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import net.duceng.xmidi.ui.DialogChannel;
import net.duceng.xmidi.ui.DialogMidi;
import net.duceng.xmidi.ui.DialogPercussion;
import net.duceng.xmidi.util.Importer;
import net.duceng.xmidi.util.MyArray;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;
import org.json.JSONArray;
import org.json.JSONException;

/* JADX INFO: loaded from: classes3.dex */
public class Settings extends Base {
    private DialogChannel channDialog;
    private DialogMidi dialogSynth;
    private SeekBar gain_seek;
    private TextView gain_value;
    private Button metroBtn;
    private DialogPercussion metroDialog;
    private Button metronome1;
    private Button metronome2;
    private SeekBar metronome_seek;
    private TextView metronome_velocity;
    private String[] percussions;
    private SeekBar polyphony_seek;
    private TextView polyphony_value;
    private SharedPreferences pref;
    private Set<String> sfonts;
    protected Synth synth;
    public static String SYNTH_INIT = "synth_init";
    public static String SYNTH_GAIN = "synth_gain";
    public static String SYNTH_POLYPHONY = "synth_polyphony";
    public static String SYNTH_BEATNOTE1 = "synth_beatNote1";
    public static String SYNTH_BEATNOTE2 = "synth_beatNote2";
    public static String SYNTH_BEATVEL = "synth_beatVelocity";
    public static String SYNTH_SFONTS = "synth_sfonts";
    public static String SYNTH_SFONT_DEFAULT = "synth_sfont_default";
    public static String SYNTH_SFONT_DEFAULT_VAL = "TimGM6mb.sf2";
    public static byte DRUMS_BASE = (byte) 27;
    private ArrayList<CheckBox> sfonts_check = new ArrayList<>();
    private ArrayList<RadioButton> sfonts_radio = new ArrayList<>();
    private View.OnClickListener metronomeClickListener = new View.OnClickListener() { // from class: net.duceng.xmidi.Settings.1
        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            Settings.this.metroBtn = (Button) v;
            if (Settings.this.metroDialog == null) {
                Settings.this.metroDialog = new DialogPercussion(Settings.this, Settings.this.percussions);
                Settings.this.metroDialog.setOnSelectListener(new DialogPercussion.OnSelectListener() { // from class: net.duceng.xmidi.Settings.1.1
                    @Override // net.duceng.xmidi.ui.DialogPercussion.OnSelectListener
                    public boolean onSelect(int idx) {
                        Settings.this.metroBtn.setText(Settings.this.percussions[idx]);
                        byte n = (byte) (Settings.DRUMS_BASE + idx);
                        SharedPreferences.Editor editor = Settings.this.pref.edit();
                        if (Settings.this.metroBtn.getId() == R.id.settings_metronome1) {
                            Settings.this.synth.setBeatNote1(n);
                            editor.putInt(Settings.SYNTH_BEATNOTE1, n);
                        } else {
                            Settings.this.synth.setBeatNote2(n);
                            editor.putInt(Settings.SYNTH_BEATNOTE2, n);
                        }
                        editor.commit();
                        Settings.this.metroDialog.dismiss();
                        return true;
                    }
                });
            }
            Settings.this.metroDialog.show();
        }
    };
    private CompoundButton.OnCheckedChangeListener checkChangeListener = new CompoundButton.OnCheckedChangeListener() { // from class: net.duceng.xmidi.Settings.2
        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public void onCheckedChanged(CompoundButton v, boolean isChecked) {
            int idx = 0;
            while (idx < Settings.this.sfonts_check.size() && !((CheckBox) Settings.this.sfonts_check.get(idx)).equals(v)) {
                idx++;
            }
            File sfont = (File) v.getTag();
            SharedPreferences.Editor editor = Settings.this.pref.edit();
            if (isChecked) {
                ((RadioButton) Settings.this.sfonts_radio.get(idx)).setEnabled(true);
                Settings.this.sfonts.add(sfont.getName());
            } else {
                ((RadioButton) Settings.this.sfonts_radio.get(idx)).setEnabled(false);
                Settings.this.sfonts.remove(sfont.getName());
            }
            editor.putString(Settings.SYNTH_SFONTS, Settings.this.join(Settings.this.sfonts));
            editor.commit();
            MyArray<File> synthfonts = Settings.this.synth.getSFonts();
            int index = synthfonts.indexOfValue(sfont);
            if (isChecked && index < 0) {
                Settings.this.synth.loadSFont(sfont);
            } else if (!isChecked && index >= 0) {
                Settings.this.synth.unloadSFont(sfont);
            }
        }
    };
    private CompoundButton.OnCheckedChangeListener radioChangeListener = new CompoundButton.OnCheckedChangeListener() { // from class: net.duceng.xmidi.Settings.3
        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public void onCheckedChanged(CompoundButton v, boolean isChecked) {
        }
    };
    private View.OnClickListener radioClickListener = new View.OnClickListener() { // from class: net.duceng.xmidi.Settings.4
        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            Settings.xmRadioClick(Settings.this, (RadioButton) v);
        }
    };

    static boolean xmHasEnabledRadio(Settings settings, String str) {
        ArrayList<RadioButton> arrayList = settings.sfonts_radio;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            RadioButton radioButton = arrayList.get(i);
            if (((File) radioButton.getTag()).getName().equals(str)) {
                return radioButton.isEnabled();
            }
        }
        return false;
    }

    static boolean xmIsSecond(Settings settings, File file) {
        return settings.pref.getString("synth_sfont_second", "").equals(file.getName());
    }

    static void xmRadioClick(Settings settings, RadioButton radioButton) {
        SharedPreferences sharedPreferences = settings.pref;
        String name = ((File) radioButton.getTag()).getName();
        String string = sharedPreferences.getString(SYNTH_SFONT_DEFAULT, SYNTH_SFONT_DEFAULT_VAL);
        String string2 = sharedPreferences.getString("synth_sfont_second", "");
        String str = string;
        String str2 = string2;
        if (name.equals(string)) {
            if (string2.length() != 0) {
                str = string2;
                str2 = "";
                xmSetPrimary(settings, str);
                xmSetSecond(settings, "");
            }
        } else if (name.equals(string2)) {
            str2 = "";
            xmSetSecond(settings, "");
        } else if (xmHasEnabledRadio(settings, string)) {
            str2 = name;
            xmSetSecond(settings, str2);
        } else {
            str = name;
            str2 = "";
            xmSetPrimary(settings, str);
            xmSetSecond(settings, "");
        }
        xmSyncRadios(settings, str, str2);
    }

    static void xmSetPrimary(Settings settings, String str) {
        SharedPreferences.Editor editorEdit = settings.pref.edit();
        editorEdit.putString(SYNTH_SFONT_DEFAULT, str);
        editorEdit.commit();
        Synth synth = settings.synth;
        File file = new File(Synth.PATH_FONT + "/" + str);
        MyArray<File> sFonts = synth.getSFonts();
        int iIndexOfValue = sFonts.indexOfValue(file);
        if (iIndexOfValue < 0) {
            synth.loadSFont(file);
            sFonts = synth.getSFonts();
            iIndexOfValue = sFonts.indexOfValue(file);
            if (iIndexOfValue < 0) {
                return;
            }
        }
        int iKeyAt = sFonts.keyAt(iIndexOfValue);
        for (int i = 0; i < 16; i++) {
            synth.setSFont(i, iKeyAt);
        }
    }

    static void xmSetSecond(Settings settings, String str) {
        SharedPreferences.Editor editorEdit = settings.pref.edit();
        editorEdit.putString("synth_sfont_second", str);
        editorEdit.commit();
        settings.synth.setFallbackByName(str);
    }

    static void xmSyncRadios(Settings settings, String str, String str2) {
        ArrayList<RadioButton> arrayList = settings.sfonts_radio;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            RadioButton radioButton = arrayList.get(i);
            String name = ((File) radioButton.getTag()).getName();
            boolean zEquals = name.equals(str);
            if (!zEquals) {
                zEquals = name.equals(str2);
            }
            radioButton.setChecked(zEquals);
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 4102 || resultCode != -1 || data == null || data.getData() == null) {
            return;
        }
        Importer.importAsync(this, data.getData(), new File(Synth.PATH_FONT), new String[]{"sf2"}, "sf2", new Importer.Callback() { // from class: net.duceng.xmidi.Settings.5
            @Override // net.duceng.xmidi.util.Importer.Callback
            public void onResult(File dest, boolean originalRemoved, String error) {
                if (error != null || dest == null) {
                    Toast.makeText(Settings.this, error != null ? error : "No se pudo importar el soundfont.", 1).show();
                } else {
                    Toast.makeText(Settings.this, "Soundfont importado: " + dest.getName() + (originalRemoved ? " (movido a la carpeta de la app)" : " (copiado; el original no se pudo borrar)") + ". Marcalo en la lista para cargarlo.", 1).show();
                    Settings.this.recreate();
                }
            }
        });
    }

    @Override // net.duceng.xmidi.Base, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.synth = Synth.getInstance();
        setContentView(R.layout.settings);
        this.title.setText(R.string.settings);
        this.pref = PreferenceManager.getDefaultSharedPreferences(this);
        this.percussions = getResources().getStringArray(R.array.preset_percussions);
        this.gain_value = (TextView) findViewById(R.id.settings_gain_value);
        this.gain_seek = (SeekBar) findViewById(R.id.settings_gain_seek);
        int gain = this.pref.getInt(SYNTH_GAIN, 3);
        this.gain_value.setText(String.valueOf(gain / 10.0f));
        this.gain_seek.setProgress(gain);
        this.gain_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.Settings.6
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                float v = progress / 10.0f;
                Settings.this.gain_value.setText(String.valueOf(v));
                Settings.this.synth.setGain(v);
                SharedPreferences.Editor editor = Settings.this.pref.edit();
                editor.putInt(Settings.SYNTH_GAIN, progress);
                editor.commit();
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
        this.polyphony_value = (TextView) findViewById(R.id.settings_polyphony_value);
        this.polyphony_seek = (SeekBar) findViewById(R.id.settings_polyphony_seek);
        int polyphony = this.pref.getInt(SYNTH_POLYPHONY, 128);
        this.polyphony_value.setText(String.valueOf(polyphony));
        this.polyphony_seek.setProgress(polyphony - 16);
        this.polyphony_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.Settings.7
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                int v = progress + 16;
                Settings.this.polyphony_value.setText(String.valueOf(v));
                Settings.this.synth.setPolyphony(v);
                SharedPreferences.Editor editor = Settings.this.pref.edit();
                editor.putInt(Settings.SYNTH_POLYPHONY, v);
                editor.commit();
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
        this.metronome1 = (Button) findViewById(R.id.settings_metronome1);
        this.metronome2 = (Button) findViewById(R.id.settings_metronome2);
        int bnote1 = this.pref.getInt(SYNTH_BEATNOTE1, 34);
        int bnote2 = this.pref.getInt(SYNTH_BEATNOTE2, 33);
        this.metronome1.setText(this.percussions[bnote1 - DRUMS_BASE]);
        this.metronome2.setText(this.percussions[bnote2 - DRUMS_BASE]);
        this.metronome1.setOnClickListener(this.metronomeClickListener);
        this.metronome2.setOnClickListener(this.metronomeClickListener);
        this.metronome_velocity = (TextView) findViewById(R.id.settings_metronome_velocity);
        this.metronome_seek = (SeekBar) findViewById(R.id.settings_metronome_seek);
        int velocity = this.pref.getInt(SYNTH_BEATVEL, 75);
        this.metronome_velocity.setText(String.valueOf(velocity));
        this.metronome_seek.setProgress(velocity);
        this.metronome_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.Settings.8
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                Settings.this.metronome_velocity.setText(String.valueOf(progress));
                Settings.this.synth.setBeatVelocity((byte) progress);
                SharedPreferences.Editor editor = Settings.this.pref.edit();
                editor.putInt(Settings.SYNTH_BEATVEL, progress);
                editor.commit();
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
        LinearLayout sfonts_file = (LinearLayout) findViewById(R.id.settings_sfonts_file);
        File path = new File(Synth.PATH_FONT);
        File[] files = path.listFiles();
        if (files == null) {
            files = new File[0];
        }
        Button importButton = (Button) getLayoutInflater().inflate(R.layout.button, (ViewGroup) sfonts_file, false);
        importButton.setText(R.string.import_soundfont);
        importButton.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.Settings.9
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Settings.this.startActivityForResult(Importer.pickIntent(), Importer.REQ_SF2);
            }
        });
        sfonts_file.addView(importButton);
        JSONArray ja = new JSONArray();
        ja.put(SYNTH_SFONT_DEFAULT_VAL);
        this.sfonts = split(this.pref.getString(SYNTH_SFONTS, ja.toString()));
        String sfont_default = this.pref.getString(SYNTH_SFONT_DEFAULT, SYNTH_SFONT_DEFAULT_VAL);
        int i = 0;
        while (i < files.length) {
            View item = LayoutInflater.from(this).inflate(R.layout.list_item_font, (ViewGroup) null);
            CheckBox cb = (CheckBox) item.findViewById(R.id.font_check);
            RadioButton rb = (RadioButton) item.findViewById(R.id.font_radio);
            int gain2 = gain;
            cb.setText(files[i].getName());
            cb.setTag(files[i]);
            rb.setTag(files[i]);
            int polyphony2 = polyphony;
            if (this.sfonts.contains(files[i].getName())) {
                cb.setChecked(true);
            } else {
                rb.setEnabled(false);
            }
            if (sfont_default.equals(files[i].getName())) {
                rb.setChecked(true);
            }
            if (xmIsSecond(this, files[i])) {
                rb.setChecked(true);
            }
            cb.setOnCheckedChangeListener(this.checkChangeListener);
            rb.setOnCheckedChangeListener(this.radioChangeListener);
            rb.setOnClickListener(this.radioClickListener);
            sfonts_file.addView(item);
            this.sfonts_check.add(cb);
            this.sfonts_radio.add(rb);
            i++;
            gain = gain2;
            polyphony = polyphony2;
        }
        LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.action_settings, (ViewGroup) null);
        while (layout.getChildCount() > 0) {
            View child = layout.getChildAt(0);
            layout.removeView(child);
            this.listBottom.add(child);
            child.setOnClickListener(this.actionClickListener);
        }
    }

    public String join(Set<String> set) {
        JSONArray ja = new JSONArray((Collection) set);
        return ja.toString();
    }

    private Set<String> split(String str) {
        HashSet<String> set = new HashSet<>();
        try {
            JSONArray ja = new JSONArray(str);
            for (int i = 0; i < ja.length(); i++) {
                set.add(ja.getString(i));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return set;
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        this.synth.freeInstance();
        super.onDestroy();
    }

    @Override // net.duceng.xmidi.Base, android.app.Activity
    protected void onStart() {
        super.onStart();
    }

    @Override // net.duceng.xmidi.Base
    protected void onActionClick(View v) {
        switch (v.getId()) {
            case R.id.btn_settings_channel /* 2130968593 */:
                if (this.channDialog == null) {
                    this.channDialog = new DialogChannel(this, this.synth);
                }
                this.channDialog.show();
                break;
            case R.id.btn_settings_midi /* 2130968594 */:
                if (this.dialogSynth == null) {
                    this.dialogSynth = new DialogMidi(this, this.synth);
                }
                this.dialogSynth.show();
                break;
            default:
                super.onActionClick(v);
                break;
        }
    }
}
