package net.duceng.xmidi;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import net.duceng.xsynth.Synth;

/** Pantalla de primera vez: enlaces de descarga de los soundfonts Yamaha SX700 / Tyros 4 e importacion. */
public class SoundfontSetup extends Activity {
    static final String[] KEYS = {"sx700", "tyros"};
    static final String[] TITLES = {"Yamaha SX700", "Yamaha Tyros 4"};
    static final String[] DEFAULT_NAMES = {"Yamaha_SX700.sf2", "Yamaha_Tyros4.sf2"};
    static final String[] LINKS = {
        "https://drive.usercontent.google.com/download?id=10EzjBIosJ5a6q17Wa5-xX6mVAwwuLpUZ&export=download&authuser=0",
        "https://drive.usercontent.google.com/download?id=1fNkSjXuVInBwjgPl_SvIYf3HWfceet-S&export=download"};
    private static final int REQ_PICK = 4711;
    static final String PREF_DECLINED = "sf_prompt_declined";

    private final TextView[] marks = new TextView[2];

    /** true en cada posicion si ese soundfont ya esta en la carpeta sf2. */
    static boolean[] present(Context c) {
        boolean[] r = new boolean[2];
        File[] files = new File(Synth.PATH_FONT).listFiles();
        if (files != null) {
            for (File f : files) {
                String n = f.getName().toLowerCase().replace(" ", "").replace("_", "").replace("-", "");
                if (!(n.endsWith(".sf2") || n.endsWith(".sf3"))) {
                    continue;
                }
                for (int i = 0; i < 2; i++) {
                    if (n.contains(KEYS[i])) {
                        r[i] = true;
                    }
                }
            }
        }
        return r;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        float d = getResources().getDisplayMetrics().density;
        int gold = 0xffc9a55c;
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xff12161a);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * d);
        root.setPadding(pad, pad, pad, pad);
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("Soundfonts recomendados");
        title.setTextColor(gold);
        title.setTextSize(22);
        root.addView(title);
        TextView sub = new TextView(this);
        sub.setText("Descarga los dos archivos (se abren en el navegador) y luego pulsa IMPORTAR para elegirlos desde tu almacenamiento.");
        sub.setTextColor(0xffcccccc);
        sub.setTextSize(14);
        sub.setPadding(0, (int) (6 * d), 0, (int) (14 * d));
        root.addView(sub);

        for (int i = 0; i < 2; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, (int) (8 * d), 0, (int) (8 * d));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            TextView name = new TextView(this);
            name.setText(TITLES[i]);
            name.setTextColor(Color.WHITE);
            name.setTextSize(17);
            col.addView(name);
            TextView link = new TextView(this);
            link.setText("Descargar (abrir en el navegador)");
            link.setTextColor(0xff29b6f6);
            link.setTextSize(14);
            link.setPaintFlags(link.getPaintFlags() | 8);
            final String url = LINKS[i];
            link.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception e) {
                        Toast.makeText(SoundfontSetup.this, "No se pudo abrir el navegador", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            col.addView(link);
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1.0f));
            TextView mark = new TextView(this);
            mark.setTextSize(28);
            mark.setTextColor(0xff4caf50);
            this.marks[i] = mark;
            row.addView(mark);
            root.addView(row);
        }

        Button imp = new Button(this);
        imp.setText("IMPORTAR");
        imp.setTextColor(0xff12161a);
        imp.setBackgroundColor(gold);
        imp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(i, REQ_PICK);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, (int) (52 * d));
        lp.topMargin = (int) (16 * d);
        root.addView(imp, lp);

        Button skip = new Button(this);
        skip.setText("Omitir");
        skip.setTextColor(0xffcccccc);
        skip.setBackgroundColor(0x00000000);
        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        root.addView(skip, new LinearLayout.LayoutParams(-1, -2));
        setContentView(sv);
        refreshMarks();
    }

    private void refreshMarks() {
        boolean[] p = present(this);
        for (int i = 0; i < 2; i++) {
            this.marks[i].setText(p[i] ? "✓" : "");
        }
        if (p[0] && p[1]) {
            Toast.makeText(this, "Listo, soundfonts instalados", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, final Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null) {
            return;
        }
        final java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
        if (data.getData() != null) {
            uris.add(data.getData());
        }
        ClipData cd = data.getClipData();
        if (cd != null) {
            for (int i = 0; i < cd.getItemCount(); i++) {
                uris.add(cd.getItemAt(i).getUri());
            }
        }
        Toast.makeText(this, "Importando...", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (Uri u : uris) {
                    copyOne(u);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshMarks();
                        }
                    });
                }
            }
        }).start();
    }

    private String displayName(Uri u) {
        Cursor c = null;
        try {
            c = getContentResolver().query(u, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (ix >= 0) {
                    return c.getString(ix);
                }
            }
        } catch (Exception e) {
        } finally {
            if (c != null) {
                c.close();
            }
        }
        return "soundfont.sf2";
    }

    private void copyOne(Uri u) {
        String name = displayName(u).replaceAll("[\\\\/:*?\"<>|]", "_");
        String norm = name.toLowerCase().replace(" ", "").replace("_", "").replace("-", "");
        boolean[] have = present(this);
        int slot = -1;
        for (int i = 0; i < 2; i++) {
            if (norm.contains(KEYS[i])) {
                slot = i;
            }
        }
        if (slot < 0) {
            // nombre desconocido: ocupar el primer hueco libre con un nombre reconocible
            slot = !have[0] ? 0 : (!have[1] ? 1 : -1);
            if (slot < 0) {
                return;
            }
            name = DEFAULT_NAMES[slot];
        }
        File dir = new File(Synth.PATH_FONT);
        dir.mkdirs();
        File tmp = new File(dir, name + ".part");
        File out = new File(dir, name);
        try {
            InputStream in = getContentResolver().openInputStream(u);
            OutputStream os = new FileOutputStream(tmp);
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) {
                os.write(buf, 0, n);
            }
            os.close();
            in.close();
            if (out.exists()) {
                out.delete();
            }
            tmp.renameTo(out);
        } catch (Exception e) {
            tmp.delete();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(SoundfontSetup.this, "No se pudo importar el archivo", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
