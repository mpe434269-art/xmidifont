package net.duceng.xmidi.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import net.duceng.xmidi.util.AdapterChannel;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes4.dex */
public class DialogChannel extends XDialog {
    private AdapterChannel ac;
    private OnSelectListener onSelectListener;
    protected Synth synth;

    public interface OnSelectListener {
        void onSelect(int i, int i2, String str);
    }

    public DialogChannel(Context context, Synth s) {
        super(context);
        this.synth = s;
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.settings_channel);
        setIcon(R.drawable.ic_settings_channel);
        ListView lv = (ListView) getLayoutInflater().inflate(R.layout.list, (ViewGroup) null);
        this.ac = new AdapterChannel(getContext(), this.synth);
        lv.setAdapter((ListAdapter) this.ac);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.ui.DialogChannel.1
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> av, View v, int pos, long id) {
                if (DialogChannel.this.onSelectListener != null) {
                    DialogChannel.this.onSelectListener.onSelect(pos, (int) id, DialogChannel.this.ac.getItem(pos));
                } else {
                    DialogChannel.this.synth.setRecordChan((byte) pos);
                    DialogChannel.this.ac.notifyDataSetChanged();
                }
            }
        });
        setContentView(lv);
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onStart() {
        this.ac.notifyDataSetChanged();
        super.onStart();
    }

    public void setOnSelectListener(OnSelectListener l) {
        this.onSelectListener = l;
    }
}
