package net.duceng.xmidi.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListAdapter;
import net.duceng.xmidi.util.Chords;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes4.dex */
public class DialogChord extends XDialog {
    private Chords gc;
    private OnSelectListener onSelectListener;

    public interface OnSelectListener {
        boolean onSelect(int i);
    }

    public DialogChord(Context context, Chords g) {
        super(context);
        this.gc = g;
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.chord);
        GridView gv = (GridView) getLayoutInflater().inflate(R.layout.grid, (ViewGroup) null);
        gv.setNumColumns(4);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getContext(), R.layout.list_item_1, this.gc.getGChords());
        gv.setAdapter((ListAdapter) arrayAdapter);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.ui.DialogChord.1
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View v, int pos, long id) {
                if (DialogChord.this.onSelectListener != null) {
                    DialogChord.this.onSelectListener.onSelect(pos);
                }
            }
        });
        setContentView(gv);
    }

    public void setOnSelectListener(OnSelectListener l) {
        this.onSelectListener = l;
    }
}
