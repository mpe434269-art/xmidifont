package net.duceng.xmidi.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.io.File;
import net.duceng.xmidi.util.AdapterExplorer;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes4.dex */
public class DialogExplorer extends XDialog {
    private AdapterExplorer af;
    private OnSelectListener onSelectListener;
    private ImageButton settings;
    protected Synth synth;

    public interface OnSelectListener {
        void onSelect(File file);
    }

    public DialogExplorer(Context context, Synth s) {
        super(context);
        this.synth = s;
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.select_file);
        ListView lv = (ListView) getLayoutInflater().inflate(R.layout.list, (ViewGroup) null);
        this.af = new AdapterExplorer(getContext(), new File(Synth.PATH_MIDI));
        lv.setAdapter((ListAdapter) this.af);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.ui.DialogExplorer.1
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View view, int pos, long id) {
                File f = DialogExplorer.this.af.getItem(pos);
                if (f.isDirectory() && f.canExecute()) {
                    DialogExplorer.this.af.setCurrentPath(f);
                    return;
                }
                if (f.isFile() && f.canRead() && DialogExplorer.this.onSelectListener != null) {
                    DialogExplorer.this.onSelectListener.onSelect(f);
                }
                arg0.setSelected(true);
            }
        });
        setContentView(lv);
        View v = getLayoutInflater().inflate(R.layout.action_file, (ViewGroup) null);
        ImageButton im = (ImageButton) v.findViewById(R.id.file_null);
        im.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogExplorer.2
            @Override // android.view.View.OnClickListener
            public void onClick(View arg0) {
                if (DialogExplorer.this.onSelectListener != null) {
                    DialogExplorer.this.onSelectListener.onSelect(null);
                }
            }
        });
        addAction(v);
        this.settings = (ImageButton) findViewById(R.id.file_settings);
        this.settings.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogExplorer.3
            private DialogTrack dialogTrack;

            @Override // android.view.View.OnClickListener
            public void onClick(View v2) {
                if (this.dialogTrack == null) {
                    this.dialogTrack = new DialogTrack(DialogExplorer.this.getContext(), DialogExplorer.this.synth);
                }
                this.dialogTrack.show();
            }
        });
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onStart() {
        this.af.notifyDataSetChanged();
        if (this.synth.getFile() == null) {
            setTitle(R.string.select_file);
            this.settings.setVisibility(8);
        } else {
            setTitle(this.synth.getFile().getName());
            this.settings.setVisibility(0);
        }
        super.onStart();
    }

    public void setOnSelectListener(OnSelectListener l) {
        this.onSelectListener = l;
    }
}
