package net.duceng.xmidi.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;
import java.io.File;
import net.duceng.xmidi.Keyboard;
import net.duceng.xmidi.util.AdapterExplorer;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes4.dex */
public class DialogFile extends XDialog {
    private AdapterExplorer ae;
    private Context context;
    private File file;

    public DialogFile(Context c, AdapterExplorer a) {
        super(c);
        this.context = c;
        this.ae = a;
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setItems(R.array.file_actions, new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.ui.DialogFile.1
            private XDialog delete;
            private XDialog edit;
            private EditText et;

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> av, View v, int pos, long id) {
                switch (pos) {
                    case 0:
                        Intent intent = new Intent(DialogFile.this.context, (Class<?>) Keyboard.class);
                        intent.putExtra("file", DialogFile.this.file);
                        DialogFile.this.context.startActivity(intent);
                        break;
                    case 1:
                        if (this.edit == null) {
                            this.edit = new XDialog(DialogFile.this.context);
                            this.et = new EditText(DialogFile.this.context);
                            final EditText etFinal = this.et;
                            this.edit.setContentView(this.et);
                            this.edit.getWapper().setPadding(12, 12, 12, 12);
                            this.edit.addButton(R.string.rename, new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogFile.1.1
                                @Override // android.view.View.OnClickListener
                                public void onClick(View v2) {
                                    File nf = new File(DialogFile.this.file.getParent(), etFinal.getText().toString());
                                    DialogFile.this.file.renameTo(nf);
                                    DialogFile.this.ae.notifyDataSetChanged();
                                }
                            });
                            this.edit.addButton(R.string.cancel, null);
                        }
                        this.edit.setTitle(DialogFile.this.file.getName());
                        this.et.setText(DialogFile.this.file.getName());
                        this.edit.show();
                        break;
                    case 2:
                        if (this.delete == null) {
                            this.delete = new XDialog(DialogFile.this.context);
                            TextView tv = new TextView(DialogFile.this.context);
                            tv.setText(R.string.sure);
                            this.delete.setContentView(tv);
                            this.delete.getWapper().setPadding(12, 12, 12, 12);
                            this.delete.addButton(R.string.delete, new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogFile.1.2
                                @Override // android.view.View.OnClickListener
                                public void onClick(View v2) {
                                    DialogFile.this.file.delete();
                                    DialogFile.this.ae.notifyDataSetChanged();
                                }
                            });
                            this.delete.addButton(R.string.cancel, null);
                        }
                        this.delete.setTitle(DialogFile.this.file.getName());
                        this.delete.show();
                        break;
                }
                DialogFile.this.dismiss();
            }
        });
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onStart() {
        setTitle(this.file.getName());
        super.onStart();
    }

    public File getFile() {
        return this.file;
    }

    public void setFile(File file) {
        this.file = file;
    }
}
