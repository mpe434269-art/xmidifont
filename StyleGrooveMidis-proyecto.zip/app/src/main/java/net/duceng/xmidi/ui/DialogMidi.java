package net.duceng.xmidi.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import net.duceng.midi.MetaTimeSignature;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes4.dex */
public class DialogMidi extends XDialog {
    private SeekBar bpm_seek;
    private TextView bpm_value;
    private SeekBar resolution_seek;
    private TextView resolution_value;
    protected Synth synth;
    private SeekBar time_denominator;
    private SeekBar time_numerator;
    private TextView time_value;

    public DialogMidi(Context context, Synth s) {
        super(context);
        this.synth = s;
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.settings_midi);
        setIcon(R.drawable.ic_settings_midi);
        View v = getLayoutInflater().inflate(R.layout.dailog_midi, (ViewGroup) null);
        setContentView(v);
        this.bpm_value = (TextView) v.findViewById(R.id.synth_bpm_value);
        this.bpm_seek = (SeekBar) v.findViewById(R.id.synth_bpm_seek);
        this.bpm_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.ui.DialogMidi.1
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                int bpm = progress + 40;
                DialogMidi.this.bpm_value.setText(String.valueOf(bpm));
                DialogMidi.this.synth.getMidiFile().getTempo().setBpm(bpm);
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
        this.time_value = (TextView) v.findViewById(R.id.synth_time_value);
        this.time_numerator = (SeekBar) v.findViewById(R.id.synth_time_numerator);
        this.time_denominator = (SeekBar) v.findViewById(R.id.synth_time_denominator);
        this.time_numerator.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.ui.DialogMidi.2
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                int denominator = DialogMidi.this.synth.getMidiFile().getTimeSignature().getDenominator();
                DialogMidi.this.time_value.setText(String.valueOf(progress) + "/" + ((int) Math.pow(2.0d, denominator)));
                DialogMidi.this.synth.getMidiFile().getTimeSignature().setNumerator((byte) progress);
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
        this.time_denominator.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.ui.DialogMidi.3
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                int numerator = DialogMidi.this.synth.getMidiFile().getTimeSignature().getNumerator();
                DialogMidi.this.time_value.setText(String.valueOf(numerator) + "/" + ((int) Math.pow(2.0d, progress)));
                DialogMidi.this.synth.getMidiFile().getTimeSignature().setDenominator((byte) progress);
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
        this.resolution_value = (TextView) v.findViewById(R.id.synth_resolution_value);
        this.resolution_seek = (SeekBar) v.findViewById(R.id.synth_resolution_seek);
        this.resolution_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.ui.DialogMidi.4
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                DialogMidi.this.resolution_value.setText(String.valueOf(progress));
                DialogMidi.this.synth.getMidiFile().setResolution(progress);
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onStart() {
        int bpm = this.synth.getMidiFile().getTempo().getBpm();
        this.bpm_value.setText(String.valueOf(bpm));
        this.bpm_seek.setProgress(bpm - 40);
        MetaTimeSignature timeSignature = this.synth.getMidiFile().getTimeSignature();
        this.time_value.setText(String.valueOf((int) timeSignature.getNumerator()) + "/" + ((int) Math.pow(2.0d, timeSignature.getDenominator())));
        this.time_numerator.setProgress(timeSignature.getNumerator());
        this.time_denominator.setProgress(timeSignature.getDenominator());
        this.resolution_value.setText(String.valueOf(this.synth.getMidiFile().getResolution()));
        this.resolution_seek.setProgress(this.synth.getMidiFile().getResolution());
        super.onStart();
    }
}
