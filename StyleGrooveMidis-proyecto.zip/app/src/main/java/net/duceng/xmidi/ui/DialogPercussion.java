package net.duceng.xmidi.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListAdapter;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes4.dex */
public class DialogPercussion extends XDialog {
    private OnSelectListener onSelectListener;
    private String[] percussions;

    public interface OnSelectListener {
        boolean onSelect(int i);
    }

    public DialogPercussion(Context context, String[] p) {
        super(context);
        this.percussions = p;
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.percussion);
        GridView gv = (GridView) getLayoutInflater().inflate(R.layout.grid, (ViewGroup) null);
        gv.setNumColumns(3);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getContext(), R.layout.list_item_1, this.percussions);
        gv.setAdapter((ListAdapter) arrayAdapter);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.ui.DialogPercussion.1
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View v, int pos, long id) {
                if (DialogPercussion.this.onSelectListener != null) {
                    DialogPercussion.this.onSelectListener.onSelect(pos);
                }
            }
        });
        setContentView(gv);
    }

    public void setOnSelectListener(OnSelectListener l) {
        this.onSelectListener = l;
    }
}
