package net.duceng.xmidi.ui;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.TextView;
import net.duceng.xmidi.util.AdapterSFont;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;
import net.duceng.xsynth.XSynth;

/* JADX INFO: loaded from: classes4.dex */
public class DialogPreset extends XDialog {
    private static int DFix = 8;
    private boolean absoluteVolume;
    private int chan;
    private CheckBox chorus_locked;
    private SeekBar chorus_seek;
    private TextView chorus_value;
    private String[] drums;
    private CheckBox ifdrums;
    private CheckBox ifmute;
    private String[] instruments;
    private SeekBar pan_seek;
    private TextView pan_value;
    private Button program;
    private CheckBox reverb_locked;
    private SeekBar reverb_seek;
    private TextView reverb_value;
    private Button sfont;
    private CheckBox sustain_locked;
    private SeekBar sustain_seek;
    private TextView sustain_value;
    protected Synth synth;
    private SeekBar volume_seek;
    private TextView volume_value;

    public void setAbsoluteVolume(boolean absolute) {
        this.absoluteVolume = absolute;
    }

    public DialogPreset(Context context, Synth s) {
        super(context);
        this.absoluteVolume = false;
        this.chan = 0;
        this.synth = s;
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setIcon(R.drawable.ic_settings_channel);
        setTitle(R.string.settings_channel);
        View v = getLayoutInflater().inflate(R.layout.dailog_preset, (ViewGroup) null);
        setContentView(v);
        this.instruments = getContext().getResources().getStringArray(R.array.preset_instruments);
        this.drums = getContext().getResources().getStringArray(R.array.preset_drums);
        this.ifmute = (CheckBox) v.findViewById(R.id.preset_mute);
        this.ifdrums = (CheckBox) v.findViewById(R.id.preset_drums);
        this.program = (Button) v.findViewById(R.id.preset_program);
        this.sfont = (Button) v.findViewById(R.id.preset_sfont);
        this.volume_value = (TextView) v.findViewById(R.id.preset_volume_value);
        this.volume_seek = (SeekBar) v.findViewById(R.id.preset_volume_seek);
        this.pan_value = (TextView) v.findViewById(R.id.preset_pan_value);
        this.pan_seek = (SeekBar) v.findViewById(R.id.preset_pan_seek);
        this.sustain_value = (TextView) v.findViewById(R.id.preset_sustain_value);
        this.sustain_seek = (SeekBar) v.findViewById(R.id.preset_sustain_seek);
        this.sustain_locked = (CheckBox) v.findViewById(R.id.preset_sustain_locked);
        this.reverb_value = (TextView) v.findViewById(R.id.preset_reverb_value);
        this.reverb_seek = (SeekBar) v.findViewById(R.id.preset_reverb_seek);
        this.reverb_locked = (CheckBox) v.findViewById(R.id.preset_reverb_locked);
        this.chorus_value = (TextView) v.findViewById(R.id.preset_chorus_value);
        this.chorus_seek = (SeekBar) v.findViewById(R.id.preset_chorus_seek);
        this.chorus_locked = (CheckBox) v.findViewById(R.id.preset_chorus_locked);
        this.ifmute.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogPreset.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v2) {
                DialogPreset.this.synth.setMute(DialogPreset.this.chan, DialogPreset.this.ifmute.isChecked());
            }
        });
        this.ifdrums.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogPreset.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v2) {
                DialogPreset.this.synth.setBank(DialogPreset.this.chan, DialogPreset.this.ifdrums.isChecked() ? Synth.DRUMS_BANK : 0);
                int p = ((Integer) DialogPreset.this.program.getTag()).intValue();
                DialogPreset.this.program.setTag(Integer.valueOf(DialogPreset.this.synth.getPreset(DialogPreset.this.chan)));
                DialogPreset.this.synth.setPreset(DialogPreset.this.chan, p);
                Button button = DialogPreset.this.program;
                String str = !DialogPreset.this.ifdrums.isChecked() ? DialogPreset.this.instruments[p] : DialogPreset.this.drums[p / DialogPreset.DFix];
                button.setText(str);
            }
        });
        this.volume_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.ui.DialogPreset.3
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                if (DialogPreset.this.absoluteVolume) {
                    DialogPreset.this.volume_value.setText(String.valueOf(progress));
                    DialogPreset.this.synth.setKeyVolume(DialogPreset.this.chan, progress);
                    return;
                }
                int v2 = progress - 50;
                if (v2 == 0) {
                    DialogPreset.this.volume_value.setText("0");
                    DialogPreset.this.synth.getControls(DialogPreset.this.chan).remove(XSynth.VOLUME_MSB);
                    DialogPreset.this.synth.refreshVolume(DialogPreset.this.chan);
                } else {
                    DialogPreset.this.volume_value.setText(String.valueOf(v2 > 0 ? "+" : "") + String.valueOf(v2) + "%");
                    DialogPreset.this.synth.setControl(DialogPreset.this.chan, XSynth.VOLUME_MSB, v2);
                    DialogPreset.this.synth.refreshVolume(DialogPreset.this.chan);
                }
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
        this.pan_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.ui.DialogPreset.4
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                DialogPreset.this.synth.setPan(DialogPreset.this.chan, progress);
                DialogPreset.this.pan_value.setText(String.valueOf(progress));
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
        this.sustain_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.ui.DialogPreset.5
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                DialogPreset.this.synth.setSustain(DialogPreset.this.chan, progress);
                DialogPreset.this.sustain_value.setText(String.valueOf(progress));
                if (DialogPreset.this.sustain_locked.isChecked()) {
                    DialogPreset.this.synth.setControl(DialogPreset.this.chan, XSynth.SUSTAIN_SWITCH, progress);
                }
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
        this.sustain_locked.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogPreset.6
            @Override // android.view.View.OnClickListener
            public void onClick(View v2) {
                if (DialogPreset.this.sustain_locked.isChecked()) {
                    DialogPreset.this.synth.setControl(DialogPreset.this.chan, XSynth.SUSTAIN_SWITCH, DialogPreset.this.synth.getSustain(DialogPreset.this.chan));
                } else {
                    DialogPreset.this.synth.getControls(DialogPreset.this.chan).remove(XSynth.SUSTAIN_SWITCH);
                }
            }
        });
        this.reverb_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.ui.DialogPreset.7
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                DialogPreset.this.synth.setReverb(DialogPreset.this.chan, progress);
                DialogPreset.this.reverb_value.setText(String.valueOf(progress));
                if (DialogPreset.this.reverb_locked.isChecked()) {
                    DialogPreset.this.synth.setControl(DialogPreset.this.chan, XSynth.EFFECTS_DEPTH1, progress);
                }
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
        this.reverb_locked.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogPreset.8
            @Override // android.view.View.OnClickListener
            public void onClick(View v2) {
                if (DialogPreset.this.reverb_locked.isChecked()) {
                    DialogPreset.this.synth.setControl(DialogPreset.this.chan, XSynth.EFFECTS_DEPTH1, DialogPreset.this.synth.getReverb(DialogPreset.this.chan));
                } else {
                    DialogPreset.this.synth.getControls(DialogPreset.this.chan).remove(XSynth.EFFECTS_DEPTH1);
                }
            }
        });
        this.chorus_seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: net.duceng.xmidi.ui.DialogPreset.9
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
                DialogPreset.this.synth.setChorus(DialogPreset.this.chan, progress);
                DialogPreset.this.chorus_value.setText(String.valueOf(progress));
                if (DialogPreset.this.chorus_locked.isChecked()) {
                    DialogPreset.this.synth.setControl(DialogPreset.this.chan, XSynth.EFFECTS_DEPTH3, progress);
                }
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar arg0) {
            }
        });
        this.chorus_locked.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogPreset.10
            @Override // android.view.View.OnClickListener
            public void onClick(View v2) {
                if (DialogPreset.this.chorus_locked.isChecked()) {
                    DialogPreset.this.synth.setControl(DialogPreset.this.chan, XSynth.EFFECTS_DEPTH3, DialogPreset.this.synth.getChorus(DialogPreset.this.chan));
                } else {
                    DialogPreset.this.synth.getControls(DialogPreset.this.chan).remove(XSynth.EFFECTS_DEPTH3);
                }
            }
        });
        this.program.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogPreset.11
            private DialogProgram dialogProgram;
            private PopupWindow populProgram;

            @Override // android.view.View.OnClickListener
            public void onClick(View v2) {
                if (DialogPreset.this.ifdrums.isChecked()) {
                    if (this.populProgram == null) {
                        ListView lv = (ListView) LayoutInflater.from(DialogPreset.this.getContext()).inflate(R.layout.list, (ViewGroup) null);
                        lv.setBackgroundResource(R.color.bg_menu);
                        lv.setPadding(0, 0, 0, 0);
                        ArrayAdapter<String> aa = new ArrayAdapter<>(DialogPreset.this.getContext(), R.layout.list_item, DialogPreset.this.drums);
                        lv.setAdapter((ListAdapter) aa);
                        final PopupWindow[] ph = new PopupWindow[1];
                        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.ui.DialogPreset.11.1
                            @Override // android.widget.AdapterView.OnItemClickListener
                            public void onItemClick(AdapterView<?> arg0, View v3, int pos, long id) {
                                DialogPreset.this.synth.setPreset(DialogPreset.this.chan, DialogPreset.DFix * pos);
                                DialogPreset.this.program.setText(DialogPreset.this.drums[pos]);
                                ph[0].dismiss();
                            }
                        });
                        this.populProgram = new PopupWindow(lv, -2, -2);
                        ph[0] = this.populProgram;
                        this.populProgram.setBackgroundDrawable(new ColorDrawable(android.R.color.transparent));
                        this.populProgram.setFocusable(true);
                    }
                    this.populProgram.setWidth(DialogPreset.this.program.getWidth());
                    this.populProgram.showAsDropDown(DialogPreset.this.program, 0, 0);
                    return;
                }
                if (this.dialogProgram == null) {
                    this.dialogProgram = new DialogProgram(DialogPreset.this.getContext(), DialogPreset.this.synth);
                    final DialogProgram dpFinal = this.dialogProgram;
                    this.dialogProgram.setOnClickListener(new DialogProgram.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogPreset.11.2
                        @Override // net.duceng.xmidi.ui.DialogProgram.OnClickListener
                        public boolean onClick(int id) {
                            DialogPreset.this.synth.setPreset(DialogPreset.this.chan, id);
                            DialogPreset.this.program.setText(DialogPreset.this.instruments[DialogPreset.this.synth.getPreset(DialogPreset.this.chan)]);
                            dpFinal.dismiss();
                            return true;
                        }
                    });
                }
                DialogProgram dpFinal2 = this.dialogProgram;
                dpFinal2.show();
                this.dialogProgram.setSelected(DialogPreset.this.synth.getPreset(DialogPreset.this.chan));
            }
        });
        this.sfont.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogPreset.12
            private AdapterSFont as;
            private ListView lv;
            private PopupWindow populSFont;

            @Override // android.view.View.OnClickListener
            public void onClick(View v2) {
                if (this.populSFont == null) {
                    this.lv = (ListView) LayoutInflater.from(DialogPreset.this.getContext()).inflate(R.layout.list, (ViewGroup) null);
                    this.lv.setBackgroundResource(R.color.bg_menu);
                    this.lv.setPadding(0, 0, 0, 0);
                    this.as = new AdapterSFont(DialogPreset.this.getContext(), DialogPreset.this.synth.getSFonts());
                    this.lv.setAdapter((ListAdapter) this.as);
                    final PopupWindow[] psf = new PopupWindow[1];
                    this.lv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.ui.DialogPreset.12.1
                        @Override // android.widget.AdapterView.OnItemClickListener
                        public void onItemClick(AdapterView<?> arg0, View v3, int pos, long id) {
                            DialogPreset.this.synth.setSFont(DialogPreset.this.chan, (int) id);
                            DialogPreset.this.sfont.setText(DialogPreset.this.synth.getSFonts().valueAt(pos).getName());
                            psf[0].dismiss();
                        }
                    });
                    this.populSFont = new PopupWindow(this.lv, -2, -2);
                    psf[0] = this.populSFont;
                    this.populSFont.setBackgroundDrawable(new ColorDrawable(android.R.color.transparent));
                    this.populSFont.setFocusable(true);
                }
                this.as.notifyDataSetChanged();
                this.as.setSelected(DialogPreset.this.synth.getSFonts().indexOfKey(DialogPreset.this.synth.getSFont(DialogPreset.this.chan)));
                this.populSFont.setWidth(DialogPreset.this.sfont.getWidth());
                this.populSFont.showAsDropDown(DialogPreset.this.sfont, 0, 0);
            }
        });
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onStart() {
        setTitle(String.valueOf(getContext().getString(R.string.settings_channel)) + ": " + this.chan);
        this.ifmute.setChecked(this.synth.isMute(this.chan));
        this.ifdrums.setChecked(this.synth.getBank(this.chan) == Synth.DRUMS_BANK);
        this.program.setTag(0);
        this.program.setText(this.ifdrums.isChecked() ? this.drums[this.synth.getPreset(this.chan) / DFix] : this.instruments[this.synth.getPreset(this.chan)]);
        this.sfont.setText(this.synth.getFontFile(this.chan).getName());
        if (this.absoluteVolume) {
            this.volume_seek.setMax(127);
            int base = this.synth.getBaseVolume(this.chan);
            this.volume_seek.setProgress(base);
            this.volume_value.setText(String.valueOf(base));
        } else {
            this.volume_seek.setMax(100);
            int v = 0;
            if (this.synth.getControls(this.chan).indexOfKey(XSynth.VOLUME_MSB) >= 0) {
                v = this.synth.getControls(this.chan).get(XSynth.VOLUME_MSB).intValue();
            }
            this.volume_seek.setProgress(v + 50);
            if (v == 0) {
                this.volume_value.setText("0");
            } else {
                this.volume_value.setText(String.valueOf(v > 0 ? "+" : "") + String.valueOf(v) + "%");
            }
        }
        this.pan_value.setText(String.valueOf(this.synth.getPan(this.chan)));
        this.pan_seek.setProgress(this.synth.getPan(this.chan));
        this.sustain_value.setText(String.valueOf(this.synth.getSustain(this.chan)));
        this.sustain_seek.setProgress(this.synth.getSustain(this.chan));
        this.sustain_locked.setChecked(this.synth.getControl(this.chan, XSynth.SUSTAIN_SWITCH) >= 0);
        this.reverb_value.setText(String.valueOf(this.synth.getReverb(this.chan)));
        this.reverb_seek.setProgress(this.synth.getReverb(this.chan));
        this.reverb_locked.setChecked(this.synth.getControl(this.chan, XSynth.EFFECTS_DEPTH1) >= 0);
        this.chorus_value.setText(String.valueOf(this.synth.getChorus(this.chan)));
        this.chorus_seek.setProgress(this.synth.getChorus(this.chan));
        this.chorus_locked.setChecked(this.synth.getControl(this.chan, XSynth.EFFECTS_DEPTH3) >= 0);
        super.onStart();
    }

    public int getChannel() {
        return this.chan;
    }

    public void setChannel(int c) {
        this.chan = c;
    }
}
