package net.duceng.xmidi.ui;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;
import net.duceng.xmidi.util.Immersive;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/** Selector de voces: buscador, familias con icono, tarjetas con el icono de cada instrumento. */
public class DialogProgram extends Dialog {
    public interface OnClickListener {
        boolean onClick(int i);
    }

    protected Synth synth;
    private OnClickListener onClickListener;
    private String[] instruments;
    private int selected = 0;
    private int family = -1;
    private final ArrayList<Integer> shown = new ArrayList<>();
    private GridView grid;
    private EditText search;
    private BaseAdapter adapter;
    private TextView[] chips;
    private TextView countText;
    private View panel;

    public DialogProgram(Context context, Synth s) {
        super(context, R.style.dialog);
        this.synth = s;
    }

    public void setOnClickListener(OnClickListener l) {
        this.onClickListener = l;
    }

    private int dp(float v) {
        return Fx.dp(getContext(), v);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(1);
        super.onCreate(savedInstanceState);
        final Context c = getContext();
        this.instruments = c.getResources().getStringArray(R.array.preset_instruments);

        FrameLayout scrim = new FrameLayout(c);
        scrim.setBackgroundColor(0xcc000000);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        LinearLayout p = new LinearLayout(c);
        this.panel = p;
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundResource(R.drawable.bg_panel_metal);
        p.setPadding(dp(14), dp(10), dp(14), dp(10));
        p.setClickable(true);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(-1, -1);
        plp.setMargins(dp(70), dp(10), dp(70), dp(10));
        scrim.addView(p, plp);

        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = Fx.badge(c, "🎹", 0xff6aa9ff, 0xff2150b8, 40, 22);
        head.addView(icon);
        TextView title = new TextView(c);
        title.setText("VOCES");
        title.setTextColor(Fx.GOLD_LIGHT);
        title.setTextSize(17);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setLetterSpacing(0.12f);
        title.setPadding(dp(12), 0, 0, 0);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        this.countText = new TextView(c);
        this.countText.setTextColor(Fx.MINT);
        this.countText.setTextSize(12);
        this.countText.setTypeface(Typeface.DEFAULT_BOLD);
        this.countText.setPadding(0, 0, dp(12), 0);
        head.addView(this.countText);
        TextView close = new TextView(c);
        close.setText("✕");
        close.setTextColor(Color.WHITE);
        close.setTextSize(14);
        close.setTypeface(Typeface.DEFAULT_BOLD);
        close.setGravity(Gravity.CENTER);
        close.setBackground(Fx.grad(0xff5a2530, 0xff2e1218, 22, 0x55ffffff, 1f, c));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        Fx.pressFx(close);
        head.addView(close, new LinearLayout.LayoutParams(dp(48), dp(36)));
        p.addView(head, new LinearLayout.LayoutParams(-1, -2));
        icon.animate().rotationBy(360f).setDuration(1200).start();

        LinearLayout sb = new LinearLayout(c);
        sb.setGravity(Gravity.CENTER_VERTICAL);
        sb.setBackground(Fx.grad(0xff0d0f13, 0xff15181e, 24, 0xff4a4130, 1.2f, c));
        sb.setPadding(dp(14), 0, dp(8), 0);
        TextView mag = new TextView(c);
        mag.setText("🔍");
        mag.setTextSize(16);
        sb.addView(mag);
        this.search = new EditText(c);
        this.search.setHint("Buscar voz (piano, guitarra, bateria, 25...)");
        this.search.setHintTextColor(0xff6c7280);
        this.search.setTextColor(Color.WHITE);
        this.search.setTextSize(15);
        this.search.setSingleLine(true);
        this.search.setBackground(null);
        this.search.setPadding(dp(10), 0, dp(10), 0);
        this.search.setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        sb.addView(this.search, new LinearLayout.LayoutParams(0, dp(42), 1f));
        LinearLayout.LayoutParams sblp = new LinearLayout.LayoutParams(-1, dp(44));
        sblp.topMargin = dp(8);
        p.addView(sb, sblp);
        this.search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int d) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int d) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                refilter(false);
            }
        });

        // familias
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow = new LinearLayout(c);
        this.chips = new TextView[17];
        for (int i = -1; i < 16; i++) {
            final int fam = i;
            TextView ch = new TextView(c);
            ch.setText(i < 0 ? "TODAS" : Fx.familyEmoji(i) + " " + Fx.FAMILY_NAME[i]);
            ch.setTextSize(12);
            ch.setTypeface(Typeface.DEFAULT_BOLD);
            ch.setGravity(Gravity.CENTER);
            ch.setSingleLine(true);
            ch.setPadding(dp(12), 0, dp(12), 0);
            ch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    family = fam;
                    refilter(true);
                }
            });
            Fx.pressFx(ch);
            this.chips[i + 1] = ch;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(32));
            lp.rightMargin = dp(6);
            chipRow.addView(ch, lp);
        }
        hs.addView(chipRow);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(-1, dp(34));
        hlp.topMargin = dp(8);
        p.addView(hs, hlp);

        this.grid = new GridView(c);
        this.grid.setNumColumns(3);
        this.grid.setHorizontalSpacing(dp(8));
        this.grid.setVerticalSpacing(dp(8));
        this.grid.setSelector(new android.graphics.drawable.ColorDrawable(0));
        this.grid.setPadding(0, dp(6), 0, dp(4));
        this.grid.setClipToPadding(false);
        this.adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return shown.size();
            }

            @Override
            public Object getItem(int i) {
                return shown.get(i);
            }

            @Override
            public long getItemId(int i) {
                return shown.get(i);
            }

            @Override
            public View getView(int pos, View convert, ViewGroup parent) {
                final int prog = shown.get(pos);
                LinearLayout row = new LinearLayout(c);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(8), dp(6), dp(8), dp(6));
                row.setBackground(Fx.cardBg(c, prog == selected));
                row.setMinimumHeight(dp(58));
                int[] col = Fx.voiceColors(prog);
                row.addView(Fx.badge(c, Fx.voiceEmoji(prog), col[0], col[1], 42, 20));
                LinearLayout t = new LinearLayout(c);
                t.setOrientation(LinearLayout.VERTICAL);
                t.setPadding(dp(10), 0, 0, 0);
                TextView nm = new TextView(c);
                nm.setText(instruments[prog]);
                nm.setTextColor(prog == selected ? Fx.GOLD_LIGHT : Color.WHITE);
                nm.setTextSize(13);
                nm.setTypeface(Typeface.DEFAULT_BOLD);
                nm.setMaxLines(2);
                nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
                t.addView(nm);
                TextView sub = new TextView(c);
                sub.setText("#" + prog + "  •  " + Fx.FAMILY_NAME[Fx.familyOf(prog)]);
                sub.setTextColor(col[0]);
                sub.setTextSize(10);
                sub.setSingleLine(true);
                t.addView(sub);
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                row.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selected = prog;
                        if (onClickListener != null) {
                            onClickListener.onClick(prog);
                        }
                    }
                });
                Fx.pressFx(row);
                Fx.popIn(row, pos);
                return row;
            }
        };
        this.grid.setAdapter(this.adapter);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-1, 0, 1f);
        glp.topMargin = dp(6);
        p.addView(this.grid, glp);

        setContentView(scrim);
        refilter(false);
    }

    private void paintChips() {
        for (int i = 0; i < this.chips.length; i++) {
            boolean on = (i - 1) == this.family;
            this.chips[i].setBackground(on ? Fx.grad(0xffffe29a, 0xffc9a55c, 22, 0xffffffff, 1f, getContext())
                    : Fx.grad(0xff333844, 0xff1b1e26, 22, 0x55ffffff, 1f, getContext()));
            this.chips[i].setTextColor(on ? 0xff2a1a00 : Color.WHITE);
        }
    }

    private void refilter(boolean fromChip) {
        String q = this.search.getText().toString().trim().toLowerCase(Locale.ROOT);
        this.shown.clear();
        for (int i = 0; i < 128; i++) {
            if (this.family >= 0 && Fx.familyOf(i) != this.family) {
                continue;
            }
            if (q.length() > 0 && !this.instruments[i].toLowerCase(Locale.ROOT).contains(q) && !String.valueOf(i).equals(q)
                    && !Fx.FAMILY_NAME[Fx.familyOf(i)].toLowerCase(Locale.ROOT).contains(q)) {
                continue;
            }
            this.shown.add(i);
        }
        paintChips();
        this.countText.setText(this.shown.size() + " voces");
        this.adapter.notifyDataSetChanged();
    }

    @Override
    protected void onStart() {
        super.onStart();
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        Immersive.apply(getWindow());
        if (this.panel != null) {
            this.panel.setScaleX(0.9f);
            this.panel.setScaleY(0.9f);
            this.panel.setAlpha(0f);
            this.panel.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(240).start();
        }
    }

    public void setSelected(int pos) {
        this.selected = pos;
        if (this.grid == null) {
            return;
        }
        this.search.setText("");
        this.family = Fx.familyOf(pos);
        refilter(true);
        int idx = this.shown.indexOf(pos);
        if (idx >= 0) {
            this.grid.setSelection(idx);
        }
    }
}
