package net.duceng.xmidi.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import net.duceng.xmidi.util.AdapterProgram;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes4.dex */
public class DialogProgram extends XDialog {
    private AdapterProgram ap;
    private ExpandableListView elv;
    private OnClickListener onClickListener;
    protected Synth synth;

    public interface OnClickListener {
        boolean onClick(int i);
    }

    public DialogProgram(Context context, Synth s) {
        super(context);
        this.synth = s;
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setIcon(R.drawable.ic_settings_channel);
        setTitle(R.string.instrument);
        this.elv = (ExpandableListView) getLayoutInflater().inflate(R.layout.list_expand, (ViewGroup) null);
        this.ap = new AdapterProgram(getContext());
        this.elv.setAdapter(this.ap);
        this.elv.setOnChildClickListener(new ExpandableListView.OnChildClickListener() { // from class: net.duceng.xmidi.ui.DialogProgram.1
            @Override // android.widget.ExpandableListView.OnChildClickListener
            public boolean onChildClick(ExpandableListView parent, View v, int gPos, int cPos, long id) {
                if (DialogProgram.this.onClickListener != null) {
                    return DialogProgram.this.onClickListener.onClick((int) id);
                }
                return false;
            }
        });
        setContentView(this.elv);
    }

    public void setOnClickListener(OnClickListener l) {
        this.onClickListener = l;
    }

    public void setSelected(int pos) {
        int gpos = pos / 8;
        int cpos = pos % 8;
        this.ap.setSelected(pos);
        this.ap.notifyDataSetChanged();
        for (int i = 0; i < this.ap.getGroupCount(); i++) {
            this.elv.collapseGroup(i);
        }
        this.elv.expandGroup(gpos);
        this.elv.setSelectedChild(gpos, cpos, true);
    }
}
