package net.duceng.xmidi.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import net.duceng.xmidi.util.Immersive;
import net.duceng.xmidi.util.Importer;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/**
 * Biblioteca de ritmos: buscador, carpetas (crear / mover / sacar / renombrar / borrar), insignias PSR-E y PSR-SX,
 * volumen del estilo y animaciones.
 */
public class DialogSty extends Dialog {
    public interface OnSelectListener {
        void onSelect(File file);
    }

    public interface VolumeControl {
        int get();

        int max();

        void set(int v);
    }

    private static final class Item {
        File file;
        boolean up;
        int series;
        String sub;
    }

    private OnSelectListener onSelectListener;
    private VolumeControl volumeControl;
    private SeekBar volSeek;
    private TextView volLabel;
    private TextView pathText;
    private TextView countText;
    private GridView grid;
    private EditText search;
    private LinearLayout chipRow;
    private final TextView[] chips = new TextView[3];
    private final ArrayList<Item> items = new ArrayList<>();
    private ItemAdapter adapter;
    private File root;
    private File current;
    private int filter = -1; // -1 todos, 1 E, 2 SX
    private int generation = 0;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private View panel;

    public DialogSty(Context context) {
        super(context, R.style.dialog);
    }

    public void setOnSelectListener(OnSelectListener l) {
        this.onSelectListener = l;
    }

    public void setVolumeControl(VolumeControl v) {
        this.volumeControl = v;
    }

    private int dp(float v) {
        return Fx.dp(getContext(), v);
    }

    private TextView pill(String text, int top, int bottom, View.OnClickListener l) {
        TextView t = new TextView(getContext());
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(Fx.grad(top, bottom, 22, 0x55ffffff, 1f, getContext()));
        t.setOnClickListener(l);
        Fx.pressFx(t);
        return t;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(1);
        super.onCreate(savedInstanceState);
        final Context c = getContext();
        this.root = new File(Synth.PATH_STY);
        this.current = this.root;

        FrameLayout scrim = new FrameLayout(c);
        scrim.setBackgroundColor(0xcc000000);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        LinearLayout p = new LinearLayout(c);
        this.panel = p;
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundResource(R.drawable.bg_panel_metal);
        p.setPadding(dp(14), dp(10), dp(14), dp(10));
        p.setClickable(true);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(-1, -1);
        plp.setMargins(dp(70), dp(10), dp(70), dp(10));
        scrim.addView(p, plp);

        // ---- cabecera
        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        final TextView icon = Fx.badge(c, "🎶", 0xffffc247, 0xffd9620a, 40, 22);
        head.addView(icon);
        LinearLayout titles = new LinearLayout(c);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        TextView title = new TextView(c);
        title.setText("BIBLIOTECA DE RITMOS");
        title.setTextColor(Fx.GOLD_LIGHT);
        title.setTextSize(17);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setLetterSpacing(0.08f);
        titles.addView(title);
        this.pathText = new TextView(c);
        this.pathText.setTextColor(0xff9aa3b2);
        this.pathText.setTextSize(11);
        this.pathText.setSingleLine(true);
        this.pathText.setEllipsize(android.text.TextUtils.TruncateAt.START);
        titles.addView(this.pathText);
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        this.countText = new TextView(c);
        this.countText.setTextColor(Fx.MINT);
        this.countText.setTextSize(12);
        this.countText.setTypeface(Typeface.DEFAULT_BOLD);
        this.countText.setPadding(0, 0, dp(12), 0);
        head.addView(this.countText);
        TextView close = pill("✕", 0xff5a2530, 0xff2e1218, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        close.setPadding(dp(14), 0, dp(14), 0);
        head.addView(close, new LinearLayout.LayoutParams(-2, dp(38)));
        p.addView(head, new LinearLayout.LayoutParams(-1, -2));
        icon.animate().rotationBy(360f).setDuration(1400).start();

        // ---- buscador
        LinearLayout sb = new LinearLayout(c);
        sb.setGravity(Gravity.CENTER_VERTICAL);
        sb.setBackground(Fx.grad(0xff0d0f13, 0xff15181e, 24, 0xff4a4130, 1.2f, c));
        sb.setPadding(dp(14), 0, dp(8), 0);
        TextView mag = new TextView(c);
        mag.setText("🔍");
        mag.setTextSize(16);
        sb.addView(mag);
        this.search = new EditText(c);
        this.search.setHint("Buscar ritmos (en todas las carpetas)...");
        this.search.setHintTextColor(0xff6c7280);
        this.search.setTextColor(Color.WHITE);
        this.search.setTextSize(15);
        this.search.setSingleLine(true);
        this.search.setBackground(null);
        this.search.setPadding(dp(10), 0, dp(10), 0);
        this.search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH | android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        sb.addView(this.search, new LinearLayout.LayoutParams(0, dp(42), 1f));
        final TextView clr = new TextView(c);
        clr.setText("✕");
        clr.setTextColor(0xff9aa3b2);
        clr.setTextSize(15);
        clr.setPadding(dp(10), dp(6), dp(10), dp(6));
        clr.setVisibility(View.GONE);
        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search.setText("");
            }
        });
        sb.addView(clr);
        LinearLayout.LayoutParams sblp = new LinearLayout.LayoutParams(-1, dp(44));
        sblp.topMargin = dp(8);
        p.addView(sb, sblp);
        this.search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int d) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int d) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                clr.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
                reload();
            }
        });

        // ---- fila de acciones: filtros + volumen + botones
        LinearLayout actions = new LinearLayout(c);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        this.chipRow = new LinearLayout(c);
        String[] chipNames = {"TODOS", "PSR-E", "PSR-SX"};
        final int[] chipFilter = {-1, 1, 2};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView ch = pill(chipNames[i], 0xff333844, 0xff1b1e26, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    filter = chipFilter[idx];
                    paintChips();
                    reload();
                }
            });
            this.chips[i] = ch;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(32));
            lp.rightMargin = dp(6);
            this.chipRow.addView(ch, lp);
        }
        actions.addView(this.chipRow);
        if (this.volumeControl != null) {
            LinearLayout vol = new LinearLayout(c);
            vol.setGravity(Gravity.CENTER_VERTICAL);
            vol.setBackground(Fx.grad(0xff22262e, 0xff14161b, 20, 0xff3a3f4c, 1f, c));
            vol.setPadding(dp(12), 0, dp(10), 0);
            this.volLabel = new TextView(c);
            this.volLabel.setTextColor(Fx.GOLD);
            this.volLabel.setTextSize(11);
            this.volLabel.setTypeface(Typeface.DEFAULT_BOLD);
            this.volLabel.setSingleLine(true);
            vol.addView(this.volLabel);
            this.volSeek = new SeekBar(c);
            this.volSeek.setMax(this.volumeControl.max());
            this.volSeek.setProgress(this.volumeControl.get());
            this.volSeek.setProgressTintList(ColorStateList.valueOf(Fx.GOLD));
            this.volSeek.setThumbTintList(ColorStateList.valueOf(Fx.GOLD_LIGHT));
            this.volLabel.setText("🔊 VOLUMEN STY  " + this.volumeControl.get());
            this.volSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar b, int pr, boolean user) {
                    if (user) {
                        volumeControl.set(pr);
                    }
                    volLabel.setText("🔊 VOLUMEN STY  " + pr);
                }

                @Override
                public void onStartTrackingTouch(SeekBar b) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar b) {
                }
            });
            vol.addView(this.volSeek, new LinearLayout.LayoutParams(0, -2, 1f));
            LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(0, dp(36), 1f);
            vlp.leftMargin = dp(6);
            vlp.rightMargin = dp(6);
            actions.addView(vol, vlp);
        } else {
            actions.addView(new View(c), new LinearLayout.LayoutParams(0, 1, 1f));
        }
        TextView newFolder = pill("📁+ CARPETA", 0xffffcf5a, 0xffc97a00, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askNewFolder();
            }
        });
        newFolder.setTextColor(0xff2a1a00);
        LinearLayout.LayoutParams nflp = new LinearLayout.LayoutParams(-2, dp(34));
        nflp.rightMargin = dp(6);
        actions.addView(newFolder, nflp);
        TextView imp = pill("⇩ IMPORTAR", 0xff4cc3ff, 0xff1b52d6, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Activity a = Importer.activityOf(getContext());
                if (a != null) {
                    dismiss();
                    a.startActivityForResult(Importer.pickIntent(), Importer.REQ_STY);
                }
            }
        });
        actions.addView(imp, new LinearLayout.LayoutParams(-2, dp(34)));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2);
        alp.topMargin = dp(8);
        p.addView(actions, alp);

        // ---- cuadricula
        this.grid = new GridView(c);
        this.grid.setNumColumns(2);
        this.grid.setHorizontalSpacing(dp(8));
        this.grid.setVerticalSpacing(dp(8));
        this.grid.setSelector(new android.graphics.drawable.ColorDrawable(0));
        this.grid.setClipToPadding(false);
        this.grid.setPadding(0, dp(6), 0, dp(4));
        this.adapter = new ItemAdapter();
        this.grid.setAdapter(this.adapter);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-1, 0, 1f);
        glp.topMargin = dp(8);
        p.addView(this.grid, glp);

        paintChips();
        setContentView(scrim);
        reload();
    }

    private void paintChips() {
        int[] f = {-1, 1, 2};
        for (int i = 0; i < 3; i++) {
            boolean on = filter == f[i];
            this.chips[i].setBackground(on ? Fx.grad(0xffffe29a, 0xffc9a55c, 22, 0xffffffff, 1f, getContext())
                    : Fx.grad(0xff333844, 0xff1b1e26, 22, 0x55ffffff, 1f, getContext()));
            this.chips[i].setTextColor(on ? 0xff2a1a00 : Color.WHITE);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        Immersive.apply(getWindow());
        if (this.volumeControl != null && this.volSeek != null) {
            this.volSeek.setProgress(this.volumeControl.get());
        }
        if (this.panel != null) {
            this.panel.setScaleX(0.9f);
            this.panel.setScaleY(0.9f);
            this.panel.setAlpha(0f);
            this.panel.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(240).start();
        }
        reload();
    }

    @Override
    public void onBackPressed() {
        if (this.search != null && this.search.getText().length() > 0) {
            this.search.setText("");
        } else if (this.current != null && !this.current.equals(this.root) && this.current.getParentFile() != null) {
            this.current = this.current.getParentFile();
            reload();
        } else {
            super.onBackPressed();
        }
    }

    // ------------------------------------------------------------------
    //  Carga de la lista (en segundo plano) + busqueda recursiva
    // ------------------------------------------------------------------
    private void reload() {
        if (this.grid == null) {
            return;
        }
        final int gen = ++this.generation;
        final String q = this.search.getText().toString().trim().toLowerCase(Locale.ROOT);
        final File dir = this.current;
        final File rootDir = this.root;
        final int flt = this.filter;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Item> res = new ArrayList<>();
                if (q.length() == 0) {
                    if (!dir.getAbsolutePath().equals(rootDir.getAbsolutePath()) && dir.getParentFile() != null) {
                        Item up = new Item();
                        up.file = dir.getParentFile();
                        up.up = true;
                        res.add(up);
                    }
                    File[] fs = dir.listFiles();
                    if (fs != null) {
                        for (File f : fs) {
                            addIfOk(res, f, flt, null);
                        }
                    }
                } else {
                    walk(rootDir, rootDir, q, flt, res, 0);
                }
                sortItems(res);
                final int total = res.size();
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (gen != generation) {
                            return;
                        }
                        items.clear();
                        items.addAll(res);
                        adapter.notifyDataSetChanged();
                        pathText.setText(q.length() > 0 ? "Resultados para \"" + q + "\"" : "📂 " + relPath(dir));
                        int n = 0;
                        for (Item it : res) {
                            if (!it.up) {
                                n++;
                            }
                        }
                        countText.setText(n + (n == 1 ? " elemento" : " elementos"));
                    }
                });
            }
        }).start();
    }

    private String relPath(File dir) {
        String r = dir.getAbsolutePath();
        String b = this.root.getAbsolutePath();
        if (r.equals(b)) {
            return "Estilos";
        }
        return "Estilos" + r.substring(b.length());
    }

    private static void walk(File base, File dir, String q, int flt, ArrayList<Item> out, int depth) {
        File[] fs = dir.listFiles();
        if (fs == null || depth > 8 || out.size() > 600) {
            return;
        }
        for (File f : fs) {
            if (f.getName().startsWith(".")) {
                continue;
            }
            if (f.isDirectory()) {
                if (f.getName().toLowerCase(Locale.ROOT).contains(q)) {
                    addIfOk(out, f, flt, base);
                }
                walk(base, f, q, flt, out, depth + 1);
            } else if (f.getName().toLowerCase(Locale.ROOT).contains(q)) {
                addIfOk(out, f, flt, base);
            }
        }
    }

    private static void addIfOk(ArrayList<Item> out, File f, int flt, File base) {
        if (f.getName().startsWith(".")) {
            return;
        }
        Item it = new Item();
        it.file = f;
        if (f.isDirectory()) {
            if (flt != -1) {
                return;
            }
            String[] l = f.list();
            int n = l == null ? 0 : l.length;
            it.sub = n + (n == 1 ? " elemento" : " elementos");
        } else {
            it.series = Fx.seriesOf(f);
            if (flt != -1 && it.series != flt) {
                return;
            }
            long s = f.length();
            it.sub = Math.max(1, s / 1024) + " KB";
            if (base != null && f.getParentFile() != null && !f.getParentFile().equals(base)) {
                it.sub += "  •  " + f.getParentFile().getName();
            }
        }
        out.add(it);
    }

    private static void sortItems(ArrayList<Item> l) {
        Collections.sort(l, new Comparator<Item>() {
            @Override
            public int compare(Item a, Item b) {
                if (a.up != b.up) {
                    return a.up ? -1 : 1;
                }
                boolean da = a.file.isDirectory();
                boolean db = b.file.isDirectory();
                if (da != db) {
                    return da ? -1 : 1;
                }
                return a.file.getName().compareToIgnoreCase(b.file.getName());
            }
        });
    }

    // ------------------------------------------------------------------
    //  Adaptador de tarjetas
    // ------------------------------------------------------------------
    private class ItemAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Item getItem(int i) {
            return items.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            final Context c = getContext();
            final Item it = items.get(pos);
            LinearLayout row = new LinearLayout(c);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(8), dp(10), dp(8));
            row.setBackground(Fx.cardBg(c, false));
            row.setMinimumHeight(dp(64));
            View badge;
            String name = it.file.getName();
            String sub = it.sub == null ? "" : it.sub;
            int subColor = 0xff9aa3b2;
            if (it.up) {
                badge = Fx.badge(c, "⬆", 0xff7a8396, 0xff3a4052, 46, 22);
                name = "Volver";
                sub = it.file.getName();
            } else if (it.file.isDirectory()) {
                badge = Fx.imageBadge(c, R.drawable.folder_art, 46);
                subColor = 0xffffcf5a;
            } else {
                int[] col = Fx.seriesColors(it.series);
                badge = Fx.imageBadge(c, Fx.seriesRes(it.series), 46);
                sub = Fx.seriesLabel(it.series) + "  •  " + sub;
                subColor = col[0];
            }
            row.addView(badge);
            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(12), 0, 0, 0);
            TextView nm = new TextView(c);
            nm.setText(name);
            nm.setTextColor(Color.WHITE);
            nm.setTextSize(15);
            nm.setTypeface(Typeface.DEFAULT_BOLD);
            nm.setSingleLine(true);
            nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
            col.addView(nm);
            TextView sb = new TextView(c);
            sb.setText(sub);
            sb.setTextColor(subColor);
            sb.setTextSize(11);
            sb.setSingleLine(true);
            sb.setEllipsize(android.text.TextUtils.TruncateAt.END);
            col.addView(sb);
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (it.up || it.file.isDirectory()) {
                        search.setText("");
                        current = it.file;
                        reload();
                    } else if (it.file.canRead() && onSelectListener != null) {
                        onSelectListener.onSelect(it.file);
                    }
                }
            });
            if (!it.up) {
                row.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        showActions(it.file);
                        return true;
                    }
                });
            }
            Fx.pressFx(row);
            Fx.popIn(row, pos);
            return row;
        }
    }

    // ------------------------------------------------------------------
    //  Carpetas y archivos
    // ------------------------------------------------------------------
    private void toast(String m) {
        Toast.makeText(getContext(), m, Toast.LENGTH_SHORT).show();
    }

    private void askNewFolder() {
        final EditText et = new EditText(getContext());
        et.setHint("Nombre de la carpeta");
        et.setSingleLine(true);
        new AlertDialog.Builder(getContext()).setTitle("Nueva carpeta de ritmos").setView(et)
                .setPositiveButton("Crear", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String n = et.getText().toString().trim().replaceAll("[\\\\/:*?\"<>|]", "_");
                        if (n.length() == 0) {
                            return;
                        }
                        File f = new File(current, n);
                        if (f.exists()) {
                            toast("Ya existe esa carpeta");
                        } else if (f.mkdirs()) {
                            toast("Carpeta creada");
                            reload();
                        } else {
                            toast("No se pudo crear la carpeta");
                        }
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    private void showActions(final File f) {
        ArrayList<String> opts = new ArrayList<>();
        opts.add("📂  Mover a una carpeta...");
        final boolean inSub = !f.getParentFile().getAbsolutePath().equals(this.root.getAbsolutePath());
        if (inSub) {
            opts.add("⬆  Sacar de esta carpeta");
        }
        opts.add("✏  Renombrar");
        opts.add("🗑  Eliminar");
        final String[] arr = opts.toArray(new String[0]);
        new AlertDialog.Builder(getContext()).setTitle(f.getName()).setItems(arr, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int which) {
                String s = arr[which];
                if (s.contains("Mover")) {
                    pickDestination(f);
                } else if (s.contains("Sacar")) {
                    moveTo(f, f.getParentFile().getParentFile());
                } else if (s.contains("Renombrar")) {
                    rename(f);
                } else {
                    confirmDelete(f);
                }
            }
        }).show();
    }

    private void collectDirs(File dir, ArrayList<File> out, File exclude, int depth) {
        File[] fs = dir.listFiles();
        if (fs == null || depth > 6) {
            return;
        }
        Arrays_sort(fs);
        for (File x : fs) {
            if (x.isDirectory() && !x.getName().startsWith(".") && (exclude == null || !x.equals(exclude))) {
                out.add(x);
                collectDirs(x, out, exclude, depth + 1);
            }
        }
    }

    private static void Arrays_sort(File[] fs) {
        java.util.Arrays.sort(fs, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
    }

    private void pickDestination(final File f) {
        final ArrayList<File> dirs = new ArrayList<>();
        dirs.add(this.root);
        collectDirs(this.root, dirs, f.isDirectory() ? f : null, 0);
        final String[] names = new String[dirs.size()];
        for (int i = 0; i < names.length; i++) {
            names[i] = i == 0 ? "🏠  Raiz (Estilos)" : "📁  " + relPath(dirs.get(i)).substring("Estilos/".length());
        }
        new AlertDialog.Builder(getContext()).setTitle("Mover \"" + f.getName() + "\" a...").setItems(names, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int which) {
                moveTo(f, dirs.get(which));
            }
        }).setNegativeButton("Cancelar", null).show();
    }

    private void moveTo(File f, File destDir) {
        if (destDir == null || f.getParentFile().equals(destDir)) {
            return;
        }
        if (f.isDirectory() && destDir.getAbsolutePath().startsWith(f.getAbsolutePath())) {
            toast("No se puede mover una carpeta dentro de si misma");
            return;
        }
        File dest = new File(destDir, f.getName());
        if (dest.exists()) {
            toast("Ya hay un elemento con ese nombre en el destino");
            return;
        }
        boolean ok = f.renameTo(dest);
        if (!ok && f.isFile()) {
            try {
                FileInputStream in = new FileInputStream(f);
                FileOutputStream out = new FileOutputStream(dest);
                byte[] b = new byte[16384];
                int n;
                while ((n = in.read(b)) > 0) {
                    out.write(b, 0, n);
                }
                in.close();
                out.close();
                ok = f.delete();
            } catch (Throwable t) {
                ok = false;
            }
        }
        toast(ok ? "Movido a " + (destDir.equals(this.root) ? "la raiz" : destDir.getName()) : "No se pudo mover");
        reload();
    }

    private void rename(final File f) {
        final EditText et = new EditText(getContext());
        et.setText(f.getName());
        et.setSingleLine(true);
        new AlertDialog.Builder(getContext()).setTitle("Renombrar").setView(et)
                .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String n = et.getText().toString().trim().replaceAll("[\\\\/:*?\"<>|]", "_");
                        if (n.length() == 0) {
                            return;
                        }
                        File nf = new File(f.getParentFile(), n);
                        if (nf.exists()) {
                            toast("Ya existe ese nombre");
                        } else {
                            toast(f.renameTo(nf) ? "Renombrado" : "No se pudo renombrar");
                            reload();
                        }
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    private void confirmDelete(final File f) {
        new AlertDialog.Builder(getContext()).setTitle("Eliminar").setMessage("¿Eliminar \"" + f.getName() + "\"" + (f.isDirectory() ? " y todo lo que contiene?" : "?"))
                .setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        deleteRec(f);
                        reload();
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    private static void deleteRec(File f) {
        if (f.isDirectory()) {
            File[] fs = f.listFiles();
            if (fs != null) {
                for (File x : fs) {
                    deleteRec(x);
                }
            }
        }
        f.delete();
    }
}
