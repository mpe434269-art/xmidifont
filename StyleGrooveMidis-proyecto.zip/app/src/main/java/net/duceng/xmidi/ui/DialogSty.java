package net.duceng.xmidi.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import java.io.File;
import net.duceng.xmidi.util.AdapterExplorer;
import net.duceng.xmidi.util.Importer;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes4.dex */
public class DialogSty extends XDialog {
    private AdapterExplorer af;
    private OnSelectListener onSelectListener;

    public interface OnSelectListener {
        void onSelect(File file);
    }

    public interface VolumeControl {
        int get();

        int max();

        void set(int v);
    }

    private VolumeControl volumeControl;
    private android.widget.SeekBar volSeek;
    private android.widget.TextView volLabel;

    public void setVolumeControl(VolumeControl v) {
        this.volumeControl = v;
    }

    public DialogSty(Context context) {
        super(context);
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.select_file);
        final ListView lv = (ListView) getLayoutInflater().inflate(R.layout.list, (ViewGroup) null);
        Button imp = new Button(getContext(), null, 0, R.style.btn_action_txt);
        imp.setText(R.string.import_style);
        imp.setMinimumHeight((int) (getContext().getResources().getDisplayMetrics().density * 46.0f));
        imp.setLayoutParams(new AbsListView.LayoutParams(-1, -2));
        imp.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogSty.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Activity activityActivityOf = Importer.activityOf(DialogSty.this.getContext());
                if (activityActivityOf != null) {
                    DialogSty.this.dismiss();
                    activityActivityOf.startActivityForResult(Importer.pickIntent(), Importer.REQ_STY);
                }
            }
        });
        if (this.volumeControl != null) {
            float d = getContext().getResources().getDisplayMetrics().density;
            android.widget.LinearLayout row = new android.widget.LinearLayout(getContext());
            row.setOrientation(android.widget.LinearLayout.VERTICAL);
            row.setPadding((int) (14 * d), (int) (8 * d), (int) (14 * d), (int) (8 * d));
            row.setLayoutParams(new AbsListView.LayoutParams(-1, -2));
            this.volLabel = new android.widget.TextView(getContext());
            this.volLabel.setTextColor(0xffc9a55c);
            this.volLabel.setTextSize(13);
            this.volLabel.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            this.volSeek = new android.widget.SeekBar(getContext());
            this.volSeek.setMax(this.volumeControl.max());
            this.volSeek.setProgress(this.volumeControl.get());
            this.volLabel.setText("VOLUMEN STY   " + this.volumeControl.get());
            this.volSeek.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(android.widget.SeekBar b, int p, boolean user) {
                    if (user) {
                        DialogSty.this.volumeControl.set(p);
                    }
                    DialogSty.this.volLabel.setText("VOLUMEN STY   " + p);
                }

                @Override
                public void onStartTrackingTouch(android.widget.SeekBar b) {
                }

                @Override
                public void onStopTrackingTouch(android.widget.SeekBar b) {
                }
            });
            row.addView(this.volLabel);
            row.addView(this.volSeek);
            lv.addHeaderView(row, null, false);
        }
        lv.addHeaderView(imp, null, false);
        this.af = new AdapterExplorer(getContext(), new File(Synth.PATH_STY));
        lv.setAdapter(this.af);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.ui.DialogSty.2
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View view, int pos, long id) {
                int idx = pos - lv.getHeaderViewsCount();
                if (idx >= 0 && idx < DialogSty.this.af.getCount()) {
                    File f = DialogSty.this.af.getItem(idx);
                    if (f.isDirectory() && f.canExecute()) {
                        DialogSty.this.af.setCurrentPath(f);
                    } else if (f.isFile() && f.canRead() && DialogSty.this.onSelectListener != null) {
                        DialogSty.this.onSelectListener.onSelect(f);
                    }
                }
            }
        });
        setContentView(lv);
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onStart() {
        this.af.notifyDataSetChanged();
        if (this.volumeControl != null && this.volSeek != null) {
            this.volSeek.setProgress(this.volumeControl.get());
        }
        super.onStart();
    }

    public void setOnSelectListener(OnSelectListener l) {
        this.onSelectListener = l;
    }
}
