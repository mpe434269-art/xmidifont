package net.duceng.xmidi.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import java.io.File;
import net.duceng.xmidi.util.AdapterExplorer;
import net.duceng.xmidi.util.Importer;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes4.dex */
public class DialogSty extends XDialog {
    private AdapterExplorer af;
    private OnSelectListener onSelectListener;

    public interface OnSelectListener {
        void onSelect(File file);
    }

    public DialogSty(Context context) {
        super(context);
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.select_file);
        final ListView lv = (ListView) getLayoutInflater().inflate(R.layout.list, (ViewGroup) null);
        Button imp = new Button(getContext(), null, 0, R.style.btn_action_txt);
        imp.setText(R.string.import_style);
        imp.setMinimumHeight((int) (getContext().getResources().getDisplayMetrics().density * 46.0f));
        imp.setLayoutParams(new AbsListView.LayoutParams(-1, -2));
        imp.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.DialogSty.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Activity activityActivityOf = Importer.activityOf(DialogSty.this.getContext());
                if (activityActivityOf != null) {
                    DialogSty.this.dismiss();
                    activityActivityOf.startActivityForResult(Importer.pickIntent(), Importer.REQ_STY);
                }
            }
        });
        lv.addHeaderView(imp, null, false);
        this.af = new AdapterExplorer(getContext(), new File(Synth.PATH_STY));
        lv.setAdapter(this.af);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.ui.DialogSty.2
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View view, int pos, long id) {
                int idx = pos - lv.getHeaderViewsCount();
                if (idx >= 0 && idx < DialogSty.this.af.getCount()) {
                    File f = DialogSty.this.af.getItem(idx);
                    if (f.isDirectory() && f.canExecute()) {
                        DialogSty.this.af.setCurrentPath(f);
                    } else if (f.isFile() && f.canRead() && DialogSty.this.onSelectListener != null) {
                        DialogSty.this.onSelectListener.onSelect(f);
                    }
                }
            }
        });
        setContentView(lv);
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onStart() {
        this.af.notifyDataSetChanged();
        super.onStart();
    }

    public void setOnSelectListener(OnSelectListener l) {
        this.onSelectListener = l;
    }
}
