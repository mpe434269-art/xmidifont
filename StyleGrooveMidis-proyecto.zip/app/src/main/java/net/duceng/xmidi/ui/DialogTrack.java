package net.duceng.xmidi.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import net.duceng.xmidi.util.AdapterTrack;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes4.dex */
public class DialogTrack extends XDialog {
    private AdapterTrack at;
    protected Synth synth;

    public DialogTrack(Context context, Synth s) {
        super(context);
        this.synth = s;
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setIcon(R.drawable.ic_settings_channel);
        ListView lv = (ListView) getLayoutInflater().inflate(R.layout.list, (ViewGroup) null);
        this.at = new AdapterTrack(getContext(), this.synth);
        lv.setAdapter((ListAdapter) this.at);
        setContentView(lv);
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onStart() {
        setTitle(this.synth.getFile().getName());
        this.at.notifyDataSetChanged();
        super.onStart();
    }
}
