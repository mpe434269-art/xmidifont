package net.duceng.xmidi.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;
import android.widget.ImageView;
import net.duceng.xsynth.R;
import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.regex.Pattern;

/** Utilidades visuales compartidas por los selectores (ritmos y voces). */
public final class Fx {
    public static final int GOLD = 0xffc9a55c;
    public static final int GOLD_LIGHT = 0xffffe29a;
    public static final int BG_TOP = 0xff1c2028;
    public static final int BG_BOT = 0xff08090c;
    public static final int CARD_TOP = 0xff2a2f3a;
    public static final int CARD_BOT = 0xff171a21;
    public static final int MINT = 0xff5eead4;

    public static final int SERIES_GENERIC = 0;
    public static final int SERIES_E = 1;
    public static final int SERIES_SX = 2;

    private Fx() {
    }

    public static int dp(Context c, float v) {
        return (int) ((v * c.getResources().getDisplayMetrics().density) + 0.5f);
    }

    public static GradientDrawable grad(int top, int bottom, float radiusDp, int stroke, float strokeDp, Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0) {
            g.setStroke(dp(c, strokeDp), stroke);
        }
        return g;
    }

    /** Fondo de tarjeta con estado "pulsado" dorado. */
    public static Drawable cardBg(Context c, boolean selected) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, grad(0xff6b5a2f, 0xff2e2714, 14, GOLD_LIGHT, 1.5f, c));
        if (selected) {
            s.addState(new int[]{}, grad(0xff4a3d1c, 0xff22190a, 14, GOLD_LIGHT, 2f, c));
        } else {
            s.addState(new int[]{}, grad(CARD_TOP, CARD_BOT, 14, 0xff3a3f4c, 1f, c));
        }
        return s;
    }

    /** Insignia redonda con degradado, reflejo de cristal y texto/emoji centrado. */
    public static TextView badge(Context c, String text, int top, int bottom, int sizeDp, float textSp) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(textSp);
        t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setShadowLayer(4f, 0f, 2f, 0x99000000);
        t.setIncludeFontPadding(false);
        setBadgeColors(c, t, top, bottom);
        t.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        return t;
    }

    public static void setBadgeColors(Context c, TextView t, int top, int bottom) {
        GradientDrawable base = grad(top, bottom, 14, 0x66ffffff, 1f, c);
        GradientDrawable gloss = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x66ffffff, 0x00ffffff});
        gloss.setCornerRadius(dp(c, 12));
        LayerDrawable ld = new LayerDrawable(new Drawable[]{base, gloss});
        ld.setLayerInset(1, dp(c, 3), dp(c, 3), dp(c, 3), dp(c, 22));
        t.setBackground(ld);
    }

    /** Efecto de pulsar: la vista se hunde y rebota. */
    public static void pressFx(View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(70).start();
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(180).setInterpolator(new OvershootInterpolator(2.2f)).start();
                }
                return false;
            }
        });
    }

    /** Aparicion escalonada de elementos de lista. */
    public static void popIn(View v, int index) {
        v.animate().cancel();
        v.setAlpha(0f);
        v.setTranslationY(28f);
        v.animate().alpha(1f).translationY(0f).setStartDelay(Math.min(index, 14) * 22L).setDuration(260).start();
    }

    // ------------------------------------------------------------------
    //  Voces
    // ------------------------------------------------------------------
    public static final String[] FAMILY_NAME = {"Piano", "Percusión cromática", "Órgano", "Guitarra", "Bajo", "Cuerdas", "Ensamble", "Metales",
            "Maderas", "Flautas", "Lead", "Pad", "Efectos synth", "Étnicos", "Percusivos", "Sonidos FX"};
    private static final String[] FAMILY_EMOJI = {"🎹", "🔔", "⛪", "🎸", "🎸", "🎻", "🎼", "🎺",
            "🎷", "🎶", "⚡", "☁️", "✨", "🌍", "🥁", "🌊"};
    private static final int[][] FAMILY_COL = {
            {0xff6aa9ff, 0xff2150b8}, {0xffffd24d, 0xffc47f00}, {0xffb98cff, 0xff5a2fb0}, {0xffff8a5b, 0xffb8300f},
            {0xffff6b8b, 0xff9c1238}, {0xffe2a45b, 0xff8a4a14}, {0xff5ee0c0, 0xff10806a}, {0xffffc247, 0xffd9620a},
            {0xff8fe36a, 0xff2f8a1c}, {0xff7fe0ff, 0xff1a7aa8}, {0xffff5fd2, 0xff8a1a78}, {0xff9aa7ff, 0xff3a3fb0},
            {0xffc0f0ff, 0xff3a7a9a}, {0xffe8b36a, 0xff8a5a1a}, {0xffff7a7a, 0xffa01818}, {0xff7ad0c8, 0xff1f6a70}};

    public static String voiceEmoji(int program) {
        int f = Math.max(0, Math.min(127, program)) / 8;
        if (program >= 16 && program <= 20) {
            return "🎹";
        }
        return FAMILY_EMOJI[f];
    }

    public static int[] voiceColors(int program) {
        return FAMILY_COL[Math.max(0, Math.min(127, program)) / 8];
    }

    public static int familyOf(int program) {
        return Math.max(0, Math.min(127, program)) / 8;
    }

    public static String familyEmoji(int family) {
        return FAMILY_EMOJI[family];
    }

    public static int[] familyColors(int family) {
        return FAMILY_COL[family];
    }

    public static final String DRUM_EMOJI = "🥁";

    // ------------------------------------------------------------------
    //  Estilos: serie PSR-E / PSR-SX
    // ------------------------------------------------------------------
    private static final Pattern SX = Pattern.compile("psr[-_ ]?sx|sx[-_ ]?\\d{3}|(^|[^a-z0-9])sx([^a-z0-9]|$)|genos|tyros|psr[-_ ]?s\\d{3}|\\bsx\\b");
    private static final Pattern E = Pattern.compile("psr[-_ ]?e|(^|[^a-z0-9])e[-_ ]?[3-4]\\d\\d([^0-9]|$)");
    private static final HashMap<String, Integer> SERIES_CACHE = new HashMap<>();

    /** Detecta la serie por el nombre y, si no se puede, por la marca SFF1 (PSR-E) / SFF2 (PSR-SX) del archivo. */
    public static synchronized int seriesOf(File f) {
        String key = f.getAbsolutePath() + "|" + f.lastModified();
        Integer cached = SERIES_CACHE.get(key);
        if (cached != null) {
            return cached;
        }
        int res = SERIES_GENERIC;
        String n = f.getName().toLowerCase(Locale.ROOT);
        if (SX.matcher(n).find()) {
            res = SERIES_SX;
        } else if (E.matcher(n).find()) {
            res = SERIES_E;
        } else {
            try {
                FileInputStream in = new FileInputStream(f);
                byte[] b = new byte[2048];
                int len = in.read(b);
                in.close();
                String head = new String(b, 0, Math.max(0, len), "ISO-8859-1");
                if (head.contains("SFF2")) {
                    res = SERIES_SX;
                } else if (head.contains("SFF1")) {
                    res = SERIES_E;
                }
            } catch (Throwable ignored) {
            }
        }
        SERIES_CACHE.put(key, res);
        return res;
    }

    public static int seriesRes(int s) {
        return s == SERIES_SX ? R.drawable.badge_sx : s == SERIES_E ? R.drawable.badge_e : R.drawable.badge_note;
    }

    /** Insignia de imagen (arte generado) de tamano fijo. */
    public static ImageView imageBadge(Context c, int resId, int sizeDp) {
        ImageView v = new ImageView(c);
        v.setImageResource(resId);
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        v.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        return v;
    }

    public static String seriesLabel(int s) {
        return s == SERIES_SX ? "PSR-SX" : s == SERIES_E ? "PSR-E" : "ESTILO";
    }

    public static String seriesBadgeText(int s) {
        return s == SERIES_SX ? "SX" : s == SERIES_E ? "E" : "♫";
    }

    public static int[] seriesColors(int s) {
        return s == SERIES_SX ? new int[]{0xff4cc3ff, 0xff1b52d6} : s == SERIES_E ? new int[]{0xff4be39a, 0xff0f7a58} : new int[]{0xffb08cff, 0xff5a34c8};
    }
}
