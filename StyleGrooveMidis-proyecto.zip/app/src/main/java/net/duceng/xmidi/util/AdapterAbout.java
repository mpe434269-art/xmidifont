package net.duceng.xmidi.util;

import android.content.Context;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes5.dex */
public class AdapterAbout extends BaseAdapter {
    private Context context;
    private ArrayList<AboutItem> items = new ArrayList<>();

    public AdapterAbout(Context c) {
        this.context = c;
        this.items.add(new AboutItem(this, this, this.context.getResources().getString(R.string.app_name), this.context.getResources().getString(R.string.app_abstract), null));
        this.items.add(new AboutItem(this, this, this.context.getResources().getString(R.string.contact), this.context.getResources().getString(R.string.contact_content), null));
        this.items.add(new AboutItem(this, this, this.context.getResources().getString(R.string.copyright), this.context.getResources().getString(R.string.copyright_content), null));
        this.items.add(new AboutItem(this, this, this.context.getResources().getString(R.string.thanks), this.context.getResources().getString(R.string.thanks_content), null));
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.items.size();
    }

    @Override // android.widget.Adapter
    public String getItem(int pos) {
        return this.items.get(pos).name;
    }

    @Override // android.widget.Adapter
    public long getItemId(int pos) {
        return pos;
    }

    @Override // android.widget.Adapter
    public View getView(int pos, View view, ViewGroup parent) {
        if (view == null) {
            view = LayoutInflater.from(this.context).inflate(android.R.layout.simple_list_item_2, (ViewGroup) null);
            ((TextView) view.findViewById(android.R.id.text2)).setMovementMethod(LinkMovementMethod.getInstance());
        }
        TextView name = (TextView) view.findViewById(android.R.id.text1);
        TextView desc = (TextView) view.findViewById(android.R.id.text2);
        name.setText(this.items.get(pos).name);
        desc.setText(Html.fromHtml(this.items.get(pos).desc));
        return view;
    }

    private class AboutItem {
        private String desc;
        private String name;

        private AboutItem(String n, String d) {
            this.name = n;
            this.desc = d;
        }

        AboutItem(AdapterAbout adapterAbout, AdapterAbout adapterAbout2, String str, String str2, AboutItem aboutItem) {
            this(str, str2);
        }
    }
}
