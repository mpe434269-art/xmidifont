package net.duceng.xmidi.util;

import android.content.Context;
import android.content.DialogInterface;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import java.util.ArrayList;
import net.duceng.midi.MidiTrack;
import net.duceng.xmidi.ui.DialogChannel;
import net.duceng.xmidi.ui.DialogPreset;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes5.dex */
public class AdapterTrack extends BaseAdapter {
    private Button chB;
    private DialogChannel chDialog;
    private Context context;
    private String[] drums;
    private String[] instruments;
    private Button prB;
    private DialogPreset prDialog;
    private Synth synth;
    private View.OnClickListener onCheckClickListener = new View.OnClickListener() { // from class: net.duceng.xmidi.util.AdapterTrack.1
        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            CheckBox cb = (CheckBox) v;
            int t = (int) AdapterTrack.this.getItemId(((Integer) cb.getTag()).intValue());
            AdapterTrack.this.synth.setScore(t, cb.isChecked());
        }
    };
    private View.OnClickListener onChannelClickListener = new View.OnClickListener() { // from class: net.duceng.xmidi.util.AdapterTrack.2
        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            AdapterTrack.this.chB = (Button) v;
            if (AdapterTrack.this.chDialog == null) {
                AdapterTrack.this.chDialog = new DialogChannel(AdapterTrack.this.context, AdapterTrack.this.synth);
                AdapterTrack.this.chDialog.setOnSelectListener(new DialogChannel.OnSelectListener() { // from class: net.duceng.xmidi.util.AdapterTrack.2.1
                    @Override // net.duceng.xmidi.ui.DialogChannel.OnSelectListener
                    public void onSelect(int chan, int preset, String instrument) {
                        MidiTrack midiTrack = AdapterTrack.this.getItem(((Integer) AdapterTrack.this.chB.getTag()).intValue());
                        midiTrack.setChannel((byte) chan);
                        midiTrack.setProgram((byte) preset);
                        AdapterTrack.this.notifyDataSetChanged();
                        AdapterTrack.this.chDialog.dismiss();
                    }
                });
            }
            AdapterTrack.this.chDialog.show();
        }
    };
    private View.OnClickListener onPresetClickListener = new View.OnClickListener() { // from class: net.duceng.xmidi.util.AdapterTrack.3
        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            AdapterTrack.this.prB = (Button) v;
            if (AdapterTrack.this.prDialog == null) {
                AdapterTrack.this.prDialog = new DialogPreset(AdapterTrack.this.context, AdapterTrack.this.synth);
                AdapterTrack.this.prDialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: net.duceng.xmidi.util.AdapterTrack.3.1
                    @Override // android.content.DialogInterface.OnDismissListener
                    public void onDismiss(DialogInterface d) {
                        MidiTrack midiTrack = AdapterTrack.this.getItem(((Integer) AdapterTrack.this.prB.getTag()).intValue());
                        byte p = (byte) AdapterTrack.this.synth.getPreset(AdapterTrack.this.prDialog.getChannel());
                        for (int i = 0; i < AdapterTrack.this.tracks.size(); i++) {
                            MidiTrack t = (MidiTrack) AdapterTrack.this.tracks.valueAt(i);
                            if (t.getChannel() == midiTrack.getChannel()) {
                                t.setProgram(p);
                            }
                        }
                        AdapterTrack.this.notifyDataSetChanged();
                    }
                });
            }
            AdapterTrack.this.prDialog.setChannel(AdapterTrack.this.getItem(((Integer) AdapterTrack.this.prB.getTag()).intValue()).getChannel());
            AdapterTrack.this.prDialog.show();
        }
    };
    private SparseArray<MidiTrack> tracks = new SparseArray<>();

    public AdapterTrack(Context c, Synth s) {
        this.context = c;
        this.synth = s;
        this.instruments = this.context.getResources().getStringArray(R.array.preset_instruments);
        this.drums = this.context.getResources().getStringArray(R.array.preset_drums);
        notifyDataSetChanged();
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        this.tracks.clear();
        ArrayList<MidiTrack> mts = this.synth.getMidiFile().getTracks();
        for (int i = 0; i < mts.size(); i++) {
            if (mts.get(i).getChannel() >= 0) {
                this.tracks.put(i, mts.get(i));
            }
        }
        super.notifyDataSetChanged();
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.tracks.size();
    }

    @Override // android.widget.Adapter
    public MidiTrack getItem(int pos) {
        return this.tracks.valueAt(pos);
    }

    @Override // android.widget.Adapter
    public long getItemId(int pos) {
        return this.tracks.keyAt(pos);
    }

    @Override // android.widget.Adapter
    public View getView(int pos, View view, ViewGroup parent) {
        if (view == null) {
            view = LayoutInflater.from(this.context).inflate(R.layout.list_item_track, (ViewGroup) null);
            ((CheckBox) view.findViewById(R.id.track_check)).setOnClickListener(this.onCheckClickListener);
            ((Button) view.findViewById(R.id.track_name)).setOnClickListener(this.onPresetClickListener);
            ((Button) view.findViewById(R.id.track_channel)).setOnClickListener(this.onChannelClickListener);
        }
        CheckBox cb = (CheckBox) view.findViewById(R.id.track_check);
        TextView num = (TextView) view.findViewById(R.id.track_num);
        Button name = (Button) view.findViewById(R.id.track_name);
        Button channel = (Button) view.findViewById(R.id.track_channel);
        cb.setChecked(this.synth.isScore(this.tracks.keyAt(pos)));
        cb.setTag(Integer.valueOf(pos));
        num.setText(String.valueOf(this.tracks.keyAt(pos)));
        MidiTrack midiTrack = getItem(pos);
        if (this.synth.getBank(midiTrack.getChannel()) == Synth.DRUMS_BANK) {
            name.setText(this.drums[midiTrack.getProgram() / 8]);
        } else {
            name.setText(this.instruments[midiTrack.getProgram()]);
        }
        name.setTag(Integer.valueOf(pos));
        channel.setText(String.valueOf((int) midiTrack.getChannel()));
        channel.setTag(Integer.valueOf(pos));
        return view;
    }
}
