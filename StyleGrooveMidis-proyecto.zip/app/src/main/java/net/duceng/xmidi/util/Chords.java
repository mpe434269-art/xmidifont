package net.duceng.xmidi.util;

import net.duceng.midi.StySection;

/* JADX INFO: loaded from: classes5.dex */
public class Chords {
    public static final byte[][] CBASES;
    public static final String[] CNAMES;
    private static byte[] GCHORD_BASES;
    private static byte[][] GCHORD_FINGERS;
    public static final String[] TONALITIES = {"C", "bD", "D", "bE", "E", "F", "#F", "G", "bA", "A", "bB", "B"};
    private static byte[] GCHORD_GROUP = {0, 5, 7, 31, 21, 14, 16, 40};
    private static String[] GCHORD_NAME = {"C", "bD", "D", "bE", "E", "F", "#F", "G", "bA", "A", "bB", "B", "Cm", "bDm", "Dm", "bEm", "Em", "Fm", "#Fm", "Gm", "bAm", "Am", "bBm", "Bm", "C7", "bD7", "D7", "bE7", "E7", "F7", "#F7", "G7", "bA7", "A7", "bB7", "B7", "Cm7", "bDm7", "Dm7", "bEm7", "Em7", "Fm7", "#Fm7", "Gm7", "bAm7", "Am7", "bBm7", "Bm7"};
    private static final byte[] GCHORD_GROUP16 = {0, 5, 7, 31, 21, 14, 16, 40, 10, 2, 4, 9, 12, 17, 19, 45};
    // 18 acordes por tonalidad (rejilla 6x3 estilo Yamaha): I IV V ... + relativos menores + dominantes
    private static final byte[] GCHORD_GROUP18 = {0, 5, 7, 31, 21, 14, 16, 40, 10, 2, 4, 9, 12, 17, 19, 45, 33, 28};

    static {
        byte[] bArr = new byte[7];
        bArr[2] = 2;
        bArr[3] = 2;
        byte[] bArr2 = new byte[7];
        bArr2[2] = 2;
        bArr2[4] = 1;
        byte[] bArr3 = new byte[7];
        bArr3[0] = 1;
        bArr3[2] = 2;
        byte[] bArr4 = new byte[7];
        bArr4[0] = 2;
        bArr4[2] = 2;
        byte[] bArr5 = new byte[7];
        bArr5[0] = 3;
        bArr5[2] = 2;
        byte[] bArr6 = new byte[7];
        bArr6[0] = 4;
        bArr6[2] = 2;
        GCHORD_FINGERS = new byte[][]{new byte[]{0, 3, 3, 2, 0, 1, 0}, new byte[]{1, -1, 3, 2, 0, 1, 0}, new byte[]{0, -1, -1, 0, 2, 3, 2}, new byte[]{0, -1, -1, 1, 3, 4, 3}, new byte[]{0, 0, 2, 2, 1, 0, 0}, new byte[]{1, 0, 2, 2, 1, 0, 0}, new byte[]{2, 0, 2, 2, 1, 0, 0}, new byte[]{0, 3, 2, 0, 0, 0, 3}, new byte[]{1, 3, 2, 0, 0, 0, 3}, new byte[]{0, -1, 0, 2, 2, 2, 0}, new byte[]{1, -1, 0, 2, 2, 2, 0}, new byte[]{2, -1, 0, 2, 2, 2, 0}, new byte[]{3, -1, 0, 2, 2, 1, 0}, new byte[]{0, -1, 4, 2, 1, 2, -1}, new byte[]{0, -1, 0, 0, 2, 3, 1}, new byte[]{0, -1, -1, 1, 3, 4, 2}, bArr, new byte[]{1, 0, 2, 2, 0, 0, 0}, new byte[]{2, 0, 2, 2, 0, 0, 0}, new byte[]{3, 0, 2, 2, 0, 0, 0}, new byte[]{0, 4, 2, 1, 1, -1, -1}, new byte[]{0, 0, 0, 2, 2, 1, 0}, new byte[]{1, -1, 0, 2, 2, 1, 0}, new byte[]{2, -1, 0, 2, 2, 1, 0}, new byte[]{3, -1, 0, 2, 0, 2, 0}, new byte[]{0, -1, 4, 3, 4, 2, -1}, new byte[]{0, -1, -1, 0, 2, 1, 2}, new byte[]{0, -1, -1, 1, 3, 2, 3}, bArr2, new byte[]{1, 0, 2, 0, 1, 0, 0}, new byte[]{2, 0, 2, 0, 1, 0, 0}, new byte[]{0, 3, 2, 0, 0, 0, 1}, new byte[]{1, 3, -1, 0, 0, 0, 1}, new byte[]{0, -1, 0, 2, 0, 2, 0}, new byte[]{1, -1, 0, 2, 0, 2, 0}, new byte[]{2, -1, 0, 2, 0, 2, 0}, new byte[]{3, -1, 0, 2, 0, 1, 0}, new byte[]{4, -1, 0, 2, 0, 1, 0}, new byte[]{0, -1, -1, 0, 2, 1, 1}, new byte[]{0, -1, -1, 1, 3, 2, 2}, new byte[]{0, 0, 2, 2, 0, 3, 0}, bArr3, bArr4, bArr5, bArr6, new byte[]{0, -1, 0, 2, 0, 1, 0}, new byte[]{1, -1, 0, 2, 0, 1, 0}, new byte[]{2, -1, 0, 2, 0, 1, 0}};
        GCHORD_BASES = new byte[]{40, 45, 50, 55, 59, 64};
        CNAMES = new String[]{"Maj", "Maj6", "Maj7", "M7#11", "Madd9", "M7(9)", "M6(9)", "aug", "m", "m6", "m7", "m7b5", "m(9)", "m7(9)", "m7(11)", "mM7", "mM7(9)", "dim", "dim7", "7", "7sus", "7b5", "7(9)", "7(#11)", "7(13)", "7(b9)", "7(b13)", "7(#9)", "M7aug", "7aug", "1+8", "1+5", "sus4", "1+2+5"};
        CBASES = new byte[][]{new byte[]{0, 4, 7}, new byte[]{0, 4, 7, 9}, new byte[]{0, 4, 7, 11}, new byte[]{0, 4, 7, 11, 18}, new byte[]{0, 4, 7, 14}, new byte[]{0, 4, 7, 11, 14}, new byte[]{0, 4, 7, 9, 14}, new byte[]{0, 4, 8}, new byte[]{0, 3, 7}, new byte[]{0, 3, 7, 9}, new byte[]{0, 3, 7, 10}, new byte[]{0, 3, 6, 10}, new byte[]{0, 3, 7, 14}, new byte[]{0, 3, 7, 10, 14}, new byte[]{0, 3, 7, 10, 17}, new byte[]{0, 3, 7, 11}, new byte[]{0, 3, 7, 11, 14}, new byte[]{0, 3, 6}, new byte[]{0, 3, 6, 8}, new byte[]{0, 4, 7, 10}, new byte[]{0, 5, 7, 10}, new byte[]{0, 4, 6, 10}, new byte[]{0, 4, 7, 10, 14}, new byte[]{0, 4, 7, 10, 18}, new byte[]{0, 4, 7, 10, 21}, new byte[]{0, 4, 7, 10, 13}, new byte[]{0, 4, 7, 10, 20}, new byte[]{0, 4, 7, 10, StySection.Phrase2}, new byte[]{0, 4, 8, 11}, new byte[]{0, 4, 8, 10}, new byte[]{0, 12}, new byte[]{0, 7}, new byte[]{0, 5, 7}, new byte[]{0, 2, 7}};
    }

    public class Chord {
        public byte[] chords;
        public byte[] gfingers = new byte[7];
        public byte[] gnotes = new byte[6];
        public int id;
        public String name;
        public byte root;
        public byte tonality;

        public Chord() {
        }
    }

    public Chord getChord(int index) {
        Chord chord = new Chord();
        chord.id = index;
        chord.root = (byte) (index % 12);
        chord.name = GCHORD_NAME[index];
        chord.gfingers = GCHORD_FINGERS[(byte) index];
        chord.gnotes = new byte[GCHORD_BASES.length];
        for (byte i = 0; i < GCHORD_BASES.length; i = (byte) (i + 1)) {
            if (GCHORD_FINGERS[index][i + 1] >= 0) {
                chord.gnotes[i] = (byte) (GCHORD_BASES[i] + GCHORD_FINGERS[index][i + 1] + GCHORD_FINGERS[index][0]);
            } else {
                chord.gnotes[i] = 0;
            }
        }
        int b = index / 12;
        switch (b) {
            case 0:
                chord.chords = CBASES[0];
                break;
            case 1:
                chord.chords = CBASES[8];
                break;
            case 2:
                chord.chords = CBASES[19];
                break;
            case 3:
                chord.chords = CBASES[10];
                break;
        }
        return chord;
    }

    public Chord getChord(String name) {
        for (int i = 0; i < GCHORD_NAME.length; i++) {
            if (GCHORD_NAME[i].equalsIgnoreCase(name)) {
                return getChord(i);
            }
        }
        return null;
    }

    public Chord[] getGChords16(int index) {
        Chord[] chords = new Chord[GCHORD_GROUP16.length];
        for (int i = 0; i < chords.length; i++) {
            int idx = ((GCHORD_GROUP16[i] / 12) * 12) + ((GCHORD_GROUP16[i] + index) % 12);
            chords[i] = getChord(idx);
            chords[i].tonality = (byte) index;
        }
        return chords;
    }

    public Chord[] getGChords18(int index) {
        Chord[] chords = new Chord[GCHORD_GROUP18.length];
        for (int i = 0; i < chords.length; i++) {
            int idx = ((GCHORD_GROUP18[i] / 12) * 12) + ((GCHORD_GROUP18[i] + index) % 12);
            chords[i] = getChord(idx);
            chords[i].tonality = (byte) index;
        }
        return chords;
    }

    public Chord[] getGChords(int index) {
        Chord[] chords = new Chord[8];
        for (int i = 0; i < chords.length; i++) {
            int idx = ((GCHORD_GROUP[i] / 12) * 12) + ((GCHORD_GROUP[i] + index) % 12);
            chords[i] = getChord(idx);
            chords[i].tonality = (byte) index;
        }
        return chords;
    }

    public Chord[] getGChords(String name) {
        for (int i = 0; i < TONALITIES.length; i++) {
            if (TONALITIES[i].equalsIgnoreCase(name)) {
                return getGChords(i);
            }
        }
        return null;
    }

    public String[] getTonalities() {
        return TONALITIES;
    }

    public String[] getGChords() {
        return GCHORD_NAME;
    }
}
