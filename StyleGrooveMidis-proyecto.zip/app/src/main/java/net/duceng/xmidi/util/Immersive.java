package net.duceng.xmidi.util;

import android.os.Build;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

/* JADX INFO: loaded from: classes5.dex */
public final class Immersive {
    private Immersive() {
    }

    public static void apply(Window w) {
        if (w == null) {
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams lp = w.getAttributes();
                lp.layoutInDisplayCutoutMode = 1;
                w.setAttributes(lp);
            }
            if (Build.VERSION.SDK_INT >= 30) {
                w.setDecorFitsSystemWindows(false);
                WindowInsetsController c = w.getInsetsController();
                if (c != null) {
                    c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    c.setSystemBarsBehavior(2);
                }
                return;
            }
            w.getDecorView().setSystemUiVisibility(5894);
        } catch (Throwable th) {
        }
    }
}
