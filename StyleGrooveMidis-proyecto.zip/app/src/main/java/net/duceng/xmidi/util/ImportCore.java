package net.duceng.xmidi.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

/* JADX INFO: loaded from: classes5.dex */
public final class ImportCore {
    public static String styleName(String str, String str2) {
        if (str != null && "sty".equals(str2)) {
            String lowerCase = str.toLowerCase();
            if (lowerCase.endsWith(".prs") || lowerCase.endsWith(".bcs") || lowerCase.endsWith(".sst")) {
                return str.substring(0, str.length() - 4) + ".sty";
            }
        }
        return str;
    }

    private ImportCore() {
    }

    public static String sanitizeName(String name) {
        if (name == null) {
            return "importado.bin";
        }
        String n = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        while (n.startsWith(".")) {
            n = n.substring(1);
        }
        return n.length() == 0 ? "importado.bin" : n;
    }

    public static boolean hasExtension(String name, String[] exts) {
        String lower = name.toLowerCase(Locale.ROOT);
        for (String e : exts) {
            if (lower.endsWith("." + e.toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        return false;
    }

    public static File uniqueFile(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) {
            return f;
        }
        int dot = name.lastIndexOf(46);
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i < 1000; i++) {
            File c = new File(dir, base + " (" + i + ")" + ext);
            if (!c.exists()) {
                return c;
            }
        }
        return new File(dir, base + "_" + System.currentTimeMillis() + ext);
    }

    public static long copy(InputStream in, File dest) throws IOException {
        long total = 0;
        FileOutputStream out = new FileOutputStream(dest);
        try {
            byte[] buf = new byte[65536];
            while (true) {
                int n = in.read(buf);
                if (n > 0) {
                    out.write(buf, 0, n);
                    total += (long) n;
                } else {
                    out.flush();
                    out.getFD().sync();
                    return total;
                }
            }
        } finally {
            out.close();
        }
    }

    public static String validate(File f, String kind) {
        if (f.length() < 64) {
            return "El archivo esta vacio o es demasiado pequeno.";
        }
        byte[] h = new byte[12];
        FileInputStream in = null;
        try {
            try {
                in = new FileInputStream(f);
                if (in.read(h) < 12) {
                    try {
                        in.close();
                    } catch (IOException e) {
                    }
                    return "El archivo no se pudo leer.";
                }
                try {
                    in.close();
                } catch (IOException e2) {
                }
                if ("sty".equals(kind)) {
                    if (h[0] == 77 && h[1] == 84 && h[2] == 104 && h[3] == 100) {
                        return null;
                    }
                    return "No parece un estilo Yamaha (.sty) valido.";
                }
                if (!"sf2".equals(kind)) {
                    return null;
                }
                if (h[0] == 82 && h[1] == 73 && h[2] == 70 && h[3] == 70 && h[8] == 115 && h[9] == 102 && h[10] == 98 && h[11] == 107) {
                    return null;
                }
                return "No parece un soundfont (.sf2) valido.";
            } catch (Throwable th) {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException e3) {
                    }
                }
                throw th;
            }
        } catch (IOException e4) {
            String str = "El archivo no se pudo leer: " + e4.getMessage();
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e5) {
                }
            }
            return str;
        }
    }
}
