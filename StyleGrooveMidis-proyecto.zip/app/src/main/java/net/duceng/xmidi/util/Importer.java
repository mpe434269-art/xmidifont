package net.duceng.xmidi.util;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/* JADX INFO: loaded from: classes5.dex */
public final class Importer {
    public static final int REQ_SF2 = 4102;
    public static final int REQ_STY = 4101;

    public interface Callback {
        void onResult(File file, boolean z, String str);
    }

    public static Activity activityOf(Context context) {
        while (!(context instanceof Activity)) {
            if (!(context instanceof ContextWrapper)) {
                return null;
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
        return (Activity) context;
    }

    private Importer() {
    }

    public static Intent pickIntent() {
        Intent i = new Intent("android.intent.action.OPEN_DOCUMENT");
        i.addCategory("android.intent.category.OPENABLE");
        i.setType("*/*");
        i.addFlags(3);
        return i;
    }

    private static String displayName(Activity act, Uri uri) {
        String p;
        String name = null;
        Cursor c = null;
        try {
            c = act.getContentResolver().query(uri, new String[]{"_display_name"}, null, null, null);
            if (c != null && c.moveToFirst()) {
                name = c.getString(0);
            }
            if (c != null) {
                c.close();
            }
        } catch (Exception e) {
            if (c != null) {
            }
        } catch (Throwable th) {
            if (c != null) {
                c.close();
            }
            throw th;
        }
        if (name == null && (p = uri.getLastPathSegment()) != null) {
            int i = p.lastIndexOf(47);
            return i >= 0 ? p.substring(i + 1) : p;
        }
        return name;
    }

    public static void importAsync(final Activity act, final Uri uri, final File dir, String[] exts, final String kind, final Callback cb) {
        AlertDialog tmp;
        final String name = ImportCore.styleName(ImportCore.sanitizeName(displayName(act, uri)), kind);
        if (ImportCore.hasExtension(name, exts)) {
            LinearLayout box = new LinearLayout(act);
            box.setOrientation(0);
            box.setGravity(16);
            box.setPadding(40, 30, 40, 30);
            box.addView(new ProgressBar(act));
            TextView tv = new TextView(act);
            tv.setText("  Importando " + name + "...");
            tv.setTextSize(16.0f);
            box.addView(tv);
            try {
                AlertDialog tmp2 = new AlertDialog.Builder(act).setView(box).setCancelable(false).create();
                tmp2.show();
                tmp = tmp2;
            } catch (Exception e) {
                tmp = null;
            }
            final AlertDialog progress = tmp;
            new Thread(new Runnable() { // from class: net.duceng.xmidi.util.Importer.1
                @Override // java.lang.Runnable
                public void run() {
                    File dest = null;
                    File part = null;
                    String error = null;
                    boolean removed = false;
                    InputStream in = null;
                    try {
                        try {
                            if (!dir.exists() && !dir.mkdirs()) {
                                throw new IOException("No hay acceso a la carpeta de la app (" + dir.getAbsolutePath() + ").");
                            }
                            InputStream in2 = act.getContentResolver().openInputStream(uri);
                            if (in2 == null) {
                                throw new IOException("No se pudo abrir el archivo elegido.");
                            }
                            part = new File(dir, ".importando_" + System.nanoTime() + ".part");
                            ImportCore.copy(in2, part);
                            String bad = ImportCore.validate(part, kind);
                            if (bad != null) {
                                error = bad;
                            } else {
                                dest = ImportCore.uniqueFile(dir, name);
                                if (!part.renameTo(dest)) {
                                    throw new IOException("No se pudo guardar " + dest.getName());
                                }
                                part = null;
                                try {
                                    if (DocumentsContract.isDocumentUri(act, uri)) {
                                        removed = DocumentsContract.deleteDocument(act.getContentResolver(), uri);
                                    } else if ("file".equals(uri.getScheme()) && uri.getPath() != null) {
                                        removed = new File(uri.getPath()).delete();
                                    }
                                } catch (Exception e2) {
                                    removed = false;
                                }
                            }
                            if (in2 != null) {
                                try {
                                    in2.close();
                                } catch (Exception e3) {
                                }
                            }
                            if (part != null && part.exists()) {
                                part.delete();
                            }
                            final File fDest = error == null ? dest : null;
                            final boolean fRemoved = removed;
                            final String fError = error;
                            act.runOnUiThread(new Runnable() { // from class: net.duceng.xmidi.util.Importer.1.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    try {
                                        if (progress != null && progress.isShowing()) {
                                            progress.dismiss();
                                        }
                                    } catch (Exception e4) {
                                    }
                                    cb.onResult(fDest, fRemoved, fError);
                                }
                            });
                        } catch (Exception e4) {
                            error = "No se pudo importar: " + e4.getMessage();
                            if (0 != 0) {
                                try {
                                    in.close();
                                } catch (Exception e5) {
                                }
                            }
                            if (0 != 0 && part.exists()) {
                            }
                        }
                    } catch (Throwable th) {
                        if (0 != 0) {
                            try {
                                in.close();
                            } catch (Exception e6) {
                            }
                        }
                        if (0 != 0 && part.exists()) {
                            part.delete();
                            throw th;
                        }
                        throw th;
                    }
                }
            }, "XMidi-Import").start();
            return;
        }
        cb.onResult(null, false, "Tipo de archivo no valido: " + name);
    }
}
