package net.duceng.xmidi.util;

import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.TreeMap;
import net.duceng.xsynth.Synth;

/**
 * Mano derecha del teclado estilo Yamaha:
 *  - VOICE RIGHT 1 (canal 0) y VOICE RIGHT 2 (canal 1) que suenan a la vez.
 *  - HARMONY: añade notas de armonía bajo la melodía según el acorde seleccionado.
 *  - ARPEGGIO: arpegia las teclas mantenidas al tempo del ritmo.
 */
public final class RightHand {
    public static final int VOICE1_CHAN = 0;
    public static final int VOICE2_CHAN = 1;

    /** Tipos: 0..4 = HARMONY, 5..9 = ARPEGGIO. */
    public static final String[] TYPE_NAMES = {
            "Harmony: Duet", "Harmony: Trio", "Harmony: Block", "Harmony: Octave", "Harmony: 1+5",
            "Arpeggio: Up 1/8", "Arpeggio: Up 1/16", "Arpeggio: Down 1/8",
            "Arpeggio: Up-Down 1/8", "Arpeggio: Random 1/16"};
    private static final int FIRST_ARP = 5;
    // patrón: 0 = arriba, 1 = abajo, 2 = arriba-abajo, 3 = aleatorio
    private static final int[] ARP_PATTERN = {0, 0, 1, 2, 3};
    // divisiones por negra: 2 = corcheas, 4 = semicorcheas
    private static final int[] ARP_DIV = {2, 4, 2, 2, 4};

    private final Synth synth;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private final TreeMap<Integer, Integer> held = new TreeMap<Integer, Integer>();
    private final HashMap<Integer, int[]> harmonyOf = new HashMap<Integer, int[]>();

    private boolean voice1 = true;
    private boolean voice2 = false;
    private boolean enabled = false;
    private int type = 0;
    private Chords.Chord chord = null;

    private boolean arpRunning = false;
    private int arpIndex = 0;
    private int arpSounding = -1;

    private final Runnable arpTick = new Runnable() {
        @Override
        public void run() {
            if (RightHand.this.arpSounding >= 0) {
                RightHand.this.soundOff(RightHand.this.arpSounding);
                RightHand.this.arpSounding = -1;
            }
            if (!RightHand.this.enabled || !RightHand.this.isArpeggio() || RightHand.this.held.isEmpty()) {
                RightHand.this.arpRunning = false;
                return;
            }
            ArrayList<Integer> seq = new ArrayList<Integer>(RightHand.this.held.keySet());
            int base = seq.size();
            if (base < 3) {
                for (int i = 0; i < base; i++) {
                    int up = seq.get(i).intValue() + 12;
                    if (up <= 127) {
                        seq.add(Integer.valueOf(up));
                    }
                }
            }
            int n = seq.size();
            int idx;
            switch (ARP_PATTERN[RightHand.this.type - FIRST_ARP]) {
                case 1:
                    idx = (n - 1) - (RightHand.this.arpIndex % n);
                    RightHand.this.arpIndex++;
                    break;
                case 2:
                    if (n == 1) {
                        idx = 0;
                    } else {
                        int period = (2 * n) - 2;
                        int k = RightHand.this.arpIndex % period;
                        idx = k < n ? k : period - k;
                        RightHand.this.arpIndex++;
                    }
                    break;
                case 3:
                    idx = RightHand.this.random.nextInt(n);
                    break;
                default:
                    idx = RightHand.this.arpIndex % n;
                    RightHand.this.arpIndex++;
                    break;
            }
            int note = seq.get(idx).intValue();
            Integer v = RightHand.this.held.get(Integer.valueOf(note));
            if (v == null) {
                v = RightHand.this.held.get(Integer.valueOf(note - 12));
            }
            int vel = v != null ? v.intValue() : 90;
            RightHand.this.soundOn(note, vel);
            RightHand.this.arpSounding = note;
            RightHand.this.handler.postDelayed(this, RightHand.this.stepMillis());
        }
    };

    public RightHand(Synth synth) {
        this.synth = synth;
    }

    // ---------------------------------------------------------------- voces
    public void setVoiceEnabled(int voice, boolean on) {
        if (voice == 1) {
            this.voice1 = on;
        } else {
            this.voice2 = on;
        }
        if (!on) {
            this.synth.keysOff(voice == 1 ? VOICE1_CHAN : VOICE2_CHAN);
        }
    }

    public boolean isVoiceEnabled(int voice) {
        return voice == 1 ? this.voice1 : this.voice2;
    }

    // ------------------------------------------------- harmony / arpeggio
    public void setEnabled(boolean on) {
        if (this.enabled == on) {
            return;
        }
        this.enabled = on;
        stopArpeggio();
        if (!on) {
            for (Integer melody : new ArrayList<Integer>(this.harmonyOf.keySet())) {
                noteOff(melody.intValue());
            }
        }
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setType(int t) {
        if (t < 0 || t >= TYPE_NAMES.length) {
            return;
        }
        boolean wasArp = isArpeggio();
        this.type = t;
        this.arpIndex = 0;
        if (wasArp != isArpeggio()) {
            stopArpeggio();
        }
    }

    public int getType() {
        return this.type;
    }

    public String getTypeName() {
        return TYPE_NAMES[this.type];
    }

    public boolean isArpeggio() {
        return this.type >= FIRST_ARP;
    }

    public void setChord(Chords.Chord c) {
        this.chord = c;
    }

    // ----------------------------------------------------------- teclado
    public void noteOn(int note, int vel) {
        if (this.enabled && isArpeggio()) {
            this.held.put(Integer.valueOf(note), Integer.valueOf(vel));
            if (!this.arpRunning) {
                this.arpRunning = true;
                this.arpIndex = 0;
                this.handler.post(this.arpTick);
            }
            return;
        }
        soundOn(note, vel);
        if (this.enabled) {
            int[] h = harmonyNotes(note);
            if (h.length > 0) {
                this.harmonyOf.put(Integer.valueOf(note), h);
                int hv = Math.max(1, (int) (vel * 0.75f));
                for (int n : h) {
                    soundOn(n, hv);
                }
            }
        }
    }

    public void noteOff(int note) {
        if (this.held.remove(Integer.valueOf(note)) != null) {
            return; // el arpegio apaga sus notas en cada paso
        }
        soundOff(note);
        int[] h = this.harmonyOf.remove(Integer.valueOf(note));
        if (h != null) {
            for (int n : h) {
                soundOff(n);
            }
        }
    }

    public void releaseAll() {
        stopArpeggio();
        this.harmonyOf.clear();
        this.synth.keysOff(VOICE1_CHAN);
        this.synth.keysOff(VOICE2_CHAN);
    }

    // ------------------------------------------------------------ interno
    private void stopArpeggio() {
        this.handler.removeCallbacks(this.arpTick);
        this.arpRunning = false;
        this.held.clear();
        if (this.arpSounding >= 0) {
            soundOff(this.arpSounding);
            this.arpSounding = -1;
        }
    }

    private int stepMillis() {
        int mpqn = this.synth.getMidiFile().getTempo().getMpqn();
        if (mpqn <= 0) {
            mpqn = 500000;
        }
        int div = ARP_DIV[this.type - FIRST_ARP];
        return Math.max(40, (mpqn / 1000) / div);
    }

    private void soundOn(int note, int vel) {
        if (note < 0 || note > 127) {
            return;
        }
        if (this.voice1) {
            this.synth.keyOn(VOICE1_CHAN, note, vel);
        }
        if (this.voice2) {
            this.synth.keyOn(VOICE2_CHAN, note, vel);
        }
    }

    private void soundOff(int note) {
        if (note < 0 || note > 127) {
            return;
        }
        this.synth.keyOff(VOICE1_CHAN, note);
        this.synth.keyOff(VOICE2_CHAN, note);
    }

    private int[] harmonyNotes(int note) {
        switch (this.type) {
            case 0:
                return below(note, 1);
            case 1:
                return below(note, 2);
            case 2:
                return below(note, 3);
            case 3:
                return clip(new int[]{note - 12});
            case 4:
                return clip(new int[]{note - 7});
            default:
                return new int[0];
        }
    }

    /** Las 'count' notas del acorde más cercanas por debajo de la melodía (al menos a una 3ª). */
    private int[] below(int note, int count) {
        if (this.chord == null || this.chord.chords == null) {
            return clip(new int[]{note - 12});
        }
        boolean[] pcs = new boolean[12];
        for (int i = 0; i < this.chord.chords.length; i++) {
            pcs[(this.chord.root + this.chord.chords[i]) % 12] = true;
        }
        int[] out = new int[count];
        int found = 0;
        for (int n = note - 3; n >= 0 && found < count; n--) {
            if (pcs[n % 12]) {
                out[found++] = n;
            }
        }
        int[] res = new int[found];
        System.arraycopy(out, 0, res, 0, found);
        return res;
    }

    private static int[] clip(int[] in) {
        int c = 0;
        for (int v : in) {
            if (v >= 0 && v <= 127) {
                c++;
            }
        }
        int[] out = new int[c];
        int j = 0;
        for (int v : in) {
            if (v >= 0 && v <= 127) {
                out[j++] = v;
            }
        }
        return out;
    }
}
