package net.duceng.xmidi.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.locks.LockSupport;
import net.duceng.midi.EventChannel;
import net.duceng.midi.MetaTempo;
import net.duceng.midi.StyFile;
import net.duceng.midi.StySection;
import net.duceng.xsynth.XSynth;

/* JADX INFO: loaded from: classes5.dex */
public final class StyleEngine implements Runnable {
    private static final Comparator<EventChannel> BAR_ORDER = new Comparator<EventChannel>() { // from class: net.duceng.xmidi.util.StyleEngine.5
        @Override // java.util.Comparator
        public int compare(EventChannel x, EventChannel y) {
            int i = 1;
            if (x.getTick() != y.getTick()) {
                return x.getTick() < y.getTick() ? -1 : 1;
            }
            int rx = (x.getType() == 8 || (x.getType() == 9 && x.getValue2() == 0)) ? 0 : 1;
            if (y.getType() == 8 || (y.getType() == 9 && y.getValue2() == 0)) {
                i = 0;
            }
            int ry = i;
            return rx - ry;
        }
    };
    private static final int DRUM = 9;
    private static final long MAX_PARK_NS = 5000000;
    private static final long MIN_PARK_NS = 20000;
    private String afterName;
    private int barIdx;
    private final int barTicks;
    private final int beatTicks;
    private Chords.Chord chordApplied;
    private volatile Chords.Chord chordV;
    private int cursor;
    private final ThreadFactory factory;
    private final Host host;
    private String lastNotified;
    private volatile Listener listener;
    private String pendingAfter;
    private String pendingName;
    private int prevBarIdx;
    private StySection prevSection;
    private final int res;
    private StySection section;
    private final Sink sink;
    private volatile String startName;
    private volatile String startAfter;
    private final StyFile sty;
    private volatile Thread thread;
    private double tickPos;
    private final ConcurrentLinkedQueue<Runnable> cmds = new ConcurrentLinkedQueue<>();
    private final boolean[] sounding = new boolean[2048];
    private volatile boolean running = false;
    private ArrayList<EventChannel> bar = new ArrayList<>();
    private long lastResyncNs = 0L;
    private final ArrayList<EventChannel> baseSetup = new ArrayList<>();
    private final Map<String, Integer> lastSent = new HashMap();
    private volatile boolean metroOn = false;
    private volatile boolean autoFill = true;
    private volatile int metroNoteAccent = 34;
    private volatile int metroNote = 33;
    private volatile int metroVel = 75;
    private double nextBeatTick = 0.0d;
    private int beatCount = 0;
    private boolean mergePrev = false;
    private String lastMain = null;
    private final boolean[] pbTouched = new boolean[16];
    private final HashSet<Integer> ccTouched = new HashSet<>();
    private final boolean[] mergeDefined = new boolean[16];
    private final long[] lastOnNs = new long[2048];
    private final ArrayList<long[]> lateOffs = new ArrayList<>();

    public interface Host {
        int mpqn();
    }

    public interface Listener {
        /** Beat of the bar (0 = downbeat). Called from the engine thread. */
        void onBeat(int beat);

        /** Section that will play after the current one (null when none). */
        void onNext(String dest);

        void onSection(String str);

        void onStopped();
    }

    public interface Sink {
        void send(EventChannel eventChannel);

        void silence();
    }

    static boolean xmSustains(int i) {
        int iMidiPlayerGetPreset;
        if (XSynth.midiPlayerGetBank(i) == 128 || (iMidiPlayerGetPreset = XSynth.midiPlayerGetPreset(i)) < 16) {
            return false;
        }
        if (iMidiPlayerGetPreset < 24) {
            return true;
        }
        if (iMidiPlayerGetPreset < 32) {
            return false;
        }
        if (iMidiPlayerGetPreset < 40 || iMidiPlayerGetPreset < 45) {
            return true;
        }
        if (iMidiPlayerGetPreset < 48) {
            return false;
        }
        if (iMidiPlayerGetPreset >= 55) {
            return iMidiPlayerGetPreset >= 56 && iMidiPlayerGetPreset < 96;
        }
        return true;
    }

    static /* synthetic */ double access$626(StyleEngine x0, double x1) {
        double d = x0.tickPos - x1;
        x0.tickPos = d;
        return d;
    }

    public StyleEngine(StyFile sty, Sink sink, Host host, ThreadFactory factory) {
        this.sty = sty;
        this.sink = sink;
        this.host = host;
        this.factory = factory;
        this.res = sty.getResolution();
        this.barTicks = sty.getBarTicks();
        this.beatTicks = sty.getBeatTicks();
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    public boolean isRunning() {
        return this.running;
    }

    /** AUTO FILL IN (Yamaha): when ON a fill-in is played when switching MAIN sections. */
    public void setAutoFill(boolean on) {
        this.autoFill = on;
    }

    public boolean isAutoFill() {
        return this.autoFill;
    }

    /** Duration of one beat in milliseconds at the current tempo. */
    public int beatMillis() {
        int mpqn = this.host.mpqn();
        if (mpqn <= 0) {
            mpqn = MetaTempo.DEFAULT_MPQN;
        }
        return (int) ((((double) this.beatTicks) * ((double) mpqn)) / (((double) this.res) * 1000.0d));
    }

    /** Duration of one bar in milliseconds at the current tempo. */
    public int barMillis() {
        int beats = this.beatTicks > 0 ? this.barTicks / this.beatTicks : 4;
        return beatMillis() * Math.max(1, beats);
    }

    public boolean hasBreak() {
        for (String k : this.sty.getSections().keySet()) {
            if (k.startsWith("Break")) {
                return true;
            }
        }
        return this.sty.containsSection("Fill In BA");
    }

    /** Nombre de la seccion de remate (fill) propia de un MAIN, o null si el estilo no tiene. */
    public String fillSectionFor(String main) {
        if (main == null || main.length() == 0) {
            return null;
        }
        char c = main.charAt(main.length() - 1);
        return fillFor(c, c);
    }

    /** Nombre de la seccion usada como BREAK, o null. */
    public String breakSection() {
        for (String k : this.sty.getSections().keySet()) {
            if (k.startsWith("Break")) {
                return k;
            }
        }
        return this.sty.containsSection("Fill In BA") ? "Fill In BA" : null;
    }

    public boolean hasSection(String name) {
        return name != null && this.sty.containsSection(name);
    }

    /** BREAK (Yamaha): plays the break fill and returns to the current MAIN. */
    public void requestBreak() {
        post(new Runnable() { // from class: net.duceng.xmidi.util.StyleEngine.6
            @Override // java.lang.Runnable
            public void run() {
                StyleEngine.this.applyBreak();
                StyleEngine.this.notifyNext();
            }
        });
    }

    public synchronized void start(String sectionName) {
        start(sectionName, null);
    }

    /** Arranca con una seccion (intro, fill, break...) y despues continua con 'after' (un MAIN). */
    public synchronized void start(String sectionName, String after) {
        if (this.running) {
            requestSection(sectionName);
            return;
        }
        this.startAfter = after;
        this.startName = sectionName;
        this.running = true;
        Thread t = this.factory != null ? this.factory.newThread(this) : new Thread(this, "StyleEngine");
        this.thread = t;
        t.start();
    }

    public void stop() {
        this.running = false;
        wake();
    }

    public void setBaseSetup(List<EventChannel> events) {
        final ArrayList<EventChannel> copy = new ArrayList<>(events);
        post(new Runnable() { // from class: net.duceng.xmidi.util.StyleEngine.1
            @Override // java.lang.Runnable
            public void run() {
                StyleEngine.this.baseSetup.clear();
                StyleEngine.this.baseSetup.addAll(copy);
                StyleEngine.this.lastSent.clear();
                for (EventChannel e : copy) {
                    StyleEngine.this.lastSent.put(StyleEngine.keyOf(e), Integer.valueOf(StyleEngine.valueOf(e)));
                }
            }
        });
    }

    public void setMetronome(boolean on, int accentNote, int note, int vel) {
        this.metroNoteAccent = accentNote;
        this.metroNote = note;
        this.metroVel = vel;
        this.metroOn = on;
    }

    public boolean isMetronomeOn() {
        return this.metroOn;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String keyOf(EventChannel e) {
        StringBuilder sbAppend;
        byte value1;
        if (e.getType() == 12) {
            sbAppend = new StringBuilder().append("P");
            value1 = e.getChannel();
        } else {
            sbAppend = new StringBuilder().append("C").append((int) e.getChannel()).append(":");
            value1 = e.getValue1();
        }
        return sbAppend.append((int) value1).toString();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int valueOf(EventChannel e) {
        return e.getType() == 12 ? e.getValue1() : e.getValue2();
    }

    public void stopAndWait(long ms) {
        this.running = false;
        Thread t = this.thread;
        wake();
        if (t != null && t != Thread.currentThread()) {
            try {
                t.join(ms);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public void setChord(Chords.Chord c) {
        this.chordV = c;
        post(new Runnable() { // from class: net.duceng.xmidi.util.StyleEngine.2
            @Override // java.lang.Runnable
            public void run() {
                StyleEngine.this.applyChord();
            }
        });
    }

    public void requestSection(final String name) {
        post(new Runnable() { // from class: net.duceng.xmidi.util.StyleEngine.3
            @Override // java.lang.Runnable
            public void run() {
                StyleEngine.this.applySectionRequest(name);
            }
        });
    }

    public void sync() {
        post(new Runnable() { // from class: net.duceng.xmidi.util.StyleEngine.4
            @Override // java.lang.Runnable
            public void run() {
                double p = StyleEngine.this.tickPos % ((double) StyleEngine.this.beatTicks);
                if (p > ((double) StyleEngine.this.beatTicks) / 2.0d) {
                    p -= (double) StyleEngine.this.beatTicks;
                }
                if (Math.abs(p) <= ((double) StyleEngine.this.beatTicks) / 8.0d) {
                    StyleEngine.access$626(StyleEngine.this, p);
                }
            }
        });
    }

    private void post(Runnable r) {
        this.cmds.add(r);
        wake();
    }

    private void wake() {
        Thread t = this.thread;
        if (t != null) {
            LockSupport.unpark(t);
        }
    }

    private static boolean isFill(String n) {
        return n.startsWith("Fill In") || n.startsWith("Break");
    }

    private static boolean isIntro(String n) {
        return n.startsWith("Intro");
    }

    private static boolean isEnding(String n) {
        return n.startsWith("Ending");
    }

    private static boolean isMain(String n) {
        return n.startsWith("Main");
    }

    private static char last(String n) {
        return n.charAt(n.length() - 1);
    }

    private String mainFor(char letter) {
        String m = "Main " + letter;
        if (this.sty.containsSection(m)) {
            return m;
        }
        if (this.sty.containsSection("Main A")) {
            return "Main A";
        }
        for (String k : this.sty.getSections().keySet()) {
            if (isMain(k)) {
                return k;
            }
        }
        return null;
    }

    private String destMainFor(String fillName) {
        char c = last(fillName);
        if (c < 'A' || c > 'D' || !this.sty.containsSection("Main " + c) || !fillName.startsWith("Fill In")) {
            return this.lastMain != null ? this.lastMain : mainFor('A');
        }
        return "Main " + c;
    }

    private StySection pick(String name) {
        StySection s = name == null ? null : this.sty.getSection(name);
        if (s == null) {
            String m = mainFor('A');
            s = m != null ? this.sty.getSection(m) : null;
        }
        if (s == null && !this.sty.getSections().isEmpty()) {
            return this.sty.getSections().values().iterator().next();
        }
        return s;
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            long last = System.nanoTime();
            drain();
            begin(this.startName);
            while (this.running && this.section != null) {
                try {
                    drain();
                    long now = System.nanoTime();
                    int mpqn = this.host.mpqn();
                    if (mpqn <= 0) {
                        mpqn = MetaTempo.DEFAULT_MPQN;
                    }
                    this.tickPos += ((now - last) * ((double) this.res)) / (((double) mpqn) * 1000.0d);
                    last = now;
                    fireDue();
                    fireMetronome();
                    fireLateOffs(now);
                    if (this.tickPos >= this.barTicks) {
                        this.tickPos -= (double) this.barTicks;
                        this.nextBeatTick = 0.0d;
                        this.beatCount = 0;
                        advanceBar();
                    } else {
                        double next = this.cursor < this.bar.size() ? this.bar.get(this.cursor).getTick() : this.barTicks;
                        if (next > this.barTicks) {
                            next = this.barTicks;
                        }
                        long ns = (long) ((((next - this.tickPos) * ((double) mpqn)) * 1000.0d) / ((double) this.res));
                        if (ns < MIN_PARK_NS) {
                            ns = MIN_PARK_NS;
                        }
                        if (ns > MAX_PARK_NS) {
                            ns = MAX_PARK_NS;
                        }
                        LockSupport.parkNanos(ns);
                    }
                } catch (Throwable t) {
                    System.err.println("StyleEngine: " + t);
                    this.running = false;
                }
            }
            this.running = false;
            try {
                resetAutomation();
                this.sink.silence();
            } catch (Throwable th) {
            }
            Arrays.fill(this.sounding, false);
            this.lateOffs.clear();
            Listener l = this.listener;
            if (l != null) {
                l.onStopped();
            }
        } catch (Throwable th2) {
            this.running = false;
            try {
                resetAutomation();
                this.sink.silence();
            } catch (Throwable th3) {
            }
            Arrays.fill(this.sounding, false);
            this.lateOffs.clear();
            Listener l2 = this.listener;
            if (l2 != null) {
                l2.onStopped();
                throw th2;
            }
            throw th2;
        }
    }

    private void fireMetronome() {
        while (this.nextBeatTick < this.barTicks && this.tickPos >= this.nextBeatTick) {
            if (this.metroOn) {
                boolean accent = this.beatCount == 0;
                this.sink.send(new EventChannel(0, (byte) 9, (byte) 9, (byte) (accent ? this.metroNoteAccent : this.metroNote), (byte) this.metroVel));
            }
            Listener bl = this.listener;
            if (bl != null) {
                bl.onBeat(this.beatCount);
            }
            this.beatCount++;
            this.nextBeatTick += (double) this.beatTicks;
        }
    }

    private void fireLateOffs(long now) {
        for (int i = this.lateOffs.size() - 1; i >= 0; i--) {
            long[] o = this.lateOffs.get(i);
            if (now >= o[0]) {
                this.lateOffs.remove(i);
                int k = (((int) o[1]) << 7) | ((int) o[2]);
                if (this.lastOnNs[k] <= o[3]) {
                    this.sounding[k] = false;
                    this.sink.send(new EventChannel(0, (byte) 8, (byte) o[1], (byte) o[2], (byte) 0));
                }
            }
        }
    }

    private static int neutralCC(int cc) {
        switch (cc) {
            case 1:
                return 0;
            case 7:
                return 100;
            case 10:
                return 64;
            case 11:
                return 127;
            case 64:
                return 0;
            case 91:
                return 40;
            case 93:
                return 0;
            default:
                return 64;
        }
    }

    private void resetAutomation() {
        for (int ch = 0; ch < 16; ch++) {
            if (this.pbTouched[ch]) {
                this.pbTouched[ch] = false;
                this.sink.send(new EventChannel(0, (byte) 14, (byte) ch, (byte) 0, (byte) 64));
            }
        }
    }

    private void applySectionSetup() {
        if (this.section == null) {
            return;
        }
        resetAutomation();
        Map<String, EventChannel> banks = new LinkedHashMap<>();
        Map<String, EventChannel> progs = new LinkedHashMap<>();
        LinkedHashMap<String, EventChannel> ctrls = new LinkedHashMap<>();
        for (EventChannel e : this.baseSetup) {
            classify(e, banks, progs, ctrls);
        }
        for (EventChannel e2 : this.section.getSetupEvents()) {
            classify(e2, banks, progs, ctrls);
        }
        for (Integer k : this.ccTouched) {
            int ch = k.intValue() >> 8;
            int cc = k.intValue() & 255;
            String key = "C" + ch + ":" + cc;
            if (!ctrls.containsKey(key)) {
                ctrls.put(key, new EventChannel(0, (byte) 11, (byte) ch, (byte) cc, (byte) neutralCC(cc)));
            }
        }
        this.ccTouched.clear();
        sendChanged(banks);
        sendChanged(progs);
        sendChanged(ctrls);
    }

    private static void classify(EventChannel e, Map<String, EventChannel> banks, Map<String, EventChannel> progs, Map<String, EventChannel> ctrls) {
        if (e.getType() == 12) {
            progs.put(keyOf(e), e);
            return;
        }
        if (e.getType() == 11 && (e.getValue1() == 0 || e.getValue1() == 32)) {
            banks.put(keyOf(e), e);
        } else if (e.getType() == 11) {
            ctrls.put(keyOf(e), e);
        }
    }

    private void sendChanged(Map<String, EventChannel> m) {
        for (Map.Entry<String, EventChannel> en : m.entrySet()) {
            Integer old = this.lastSent.get(en.getKey());
            int v = valueOf(en.getValue());
            if (old == null || old.intValue() != v) {
                this.lastSent.put(en.getKey(), Integer.valueOf(v));
                this.sink.send(en.getValue());
            }
        }
    }

    private void drain() {
        while (true) {
            Runnable r = this.cmds.poll();
            if (r != null) {
                r.run();
            } else {
                return;
            }
        }
    }

    private void fireDue() {
        while (this.cursor < this.bar.size() && this.bar.get(this.cursor).getTick() <= this.tickPos) {
            ArrayList<EventChannel> arrayList = this.bar;
            int i = this.cursor;
            this.cursor = i + 1;
            fire(arrayList.get(i));
        }
    }

    private boolean continuesNextBar() {
        return this.pendingName == null && this.section != null && this.barIdx + 1 < this.section.sizeBars();
    }

    private void fire(EventChannel e) {
        int ch = e.getChannel() & StySection.Phrase2;
        if (e.getType() == 14) {
            this.pbTouched[ch] = true;
        } else if (e.getType() == 11) {
            int cc = e.getValue1() & 127;
            this.ccTouched.add(Integer.valueOf((ch << 8) | cc));
            this.lastSent.put("C" + ch + ":" + cc, Integer.valueOf(e.getValue2()));
        }
        if (e.carry == 1 && continuesNextBar()) {
            return;
        }
        if (e.carry == 2 && ch != 9 && this.sounding[(ch << 7) | (e.getValue1() & 127)]) {
            return;
        }
        if (e.getType() == 9 && e.getValue2() > 0) {
            if (ch != 9) {
                this.sounding[(ch << 7) | (e.getValue1() & 127)] = true;
                this.lastOnNs[(ch << 7) | (e.getValue1() & 127)] = System.nanoTime();
            }
        } else if (e.getType() == 8 || (e.getType() == 9 && e.getValue2() == 0)) {
            this.sounding[(ch << 7) | (e.getValue1() & 127)] = false;
        }
        this.sink.send(e);
    }

    private void begin(String name) {
        this.chordApplied = this.chordV;
        this.section = pick(name);
        this.barIdx = 0;
        this.tickPos = 0.0d;
        this.nextBeatTick = 0.0d;
        this.beatCount = 0;
        this.afterName = this.startAfter;
        this.startAfter = null;
        if (this.afterName != null && isMain(this.afterName)) {
            this.lastMain = this.afterName;
        }
        this.pendingName = null;
        if (this.section == null) {
            return;
        }
        applySectionSetup();
        this.bar = this.section.getEvents(0, this.chordApplied);
        this.cursor = 0;
        notifySection();
    }

    private void notifySection() {
        if (this.section != null && isMain(this.section.getName())) {
            this.lastMain = this.section.getName();
        }
        Listener l = this.listener;
        if (l != null && this.section != null) {
            l.onNext(nextDest());
            l.onSection(this.section.getName());
        }
    }

    /** Section the UI should show as "coming next" (blinking LED). */
    private String nextDest() {
        if (this.pendingName != null) {
            if (isFill(this.pendingName) && this.pendingAfter != null) {
                return this.pendingAfter;
            }
            return this.pendingName;
        }
        return this.afterName;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void notifyNext() {
        Listener l = this.listener;
        if (l != null) {
            l.onNext(nextDest());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void applyBreak() {
        if (this.section == null) {
            return;
        }
        String cur = this.section.getName();
        if (isEnding(cur)) {
            return;
        }
        String br = null;
        for (String k : this.sty.getSections().keySet()) {
            if (k.startsWith("Break")) {
                br = k;
                break;
            }
        }
        if (br == null && this.sty.containsSection("Fill In BA")) {
            br = "Fill In BA";
        }
        if (br == null || br.equals(cur)) {
            return;
        }
        String dest;
        if (isMain(cur)) {
            dest = cur;
        } else if (this.afterName != null && isMain(this.afterName)) {
            dest = this.afterName;
        } else if (this.lastMain != null) {
            dest = this.lastMain;
        } else {
            dest = mainFor('A');
        }
        if (isFill(cur)) {
            switchFill(br, dest);
        } else {
            fillNow(br, dest);
        }
    }

    private void advanceBar() {
        String dest;
        this.mergePrev = false;
        this.barIdx++;
        boolean sectionChanged = false;
        if (this.pendingName != null) {
            sectionChanged = true;
            StySection s = pick(this.pendingName);
            this.afterName = this.pendingAfter;
            this.pendingName = null;
            this.pendingAfter = null;
            this.section = s;
            this.barIdx = 0;
            notifySection();
        } else if (this.barIdx >= this.section.sizeBars()) {
            this.barIdx = 0;
            String cur = this.section.getName();
            if (isEnding(cur)) {
                this.running = false;
                return;
            }
            if (isIntro(cur) || isFill(cur)) {
                sectionChanged = true;
                if (this.afterName != null) {
                    dest = this.afterName;
                } else {
                    dest = isFill(cur) ? destMainFor(cur) : mainFor(last(cur));
                }
                this.afterName = null;
                this.section = pick(dest);
                notifySection();
            }
        }
        if (sectionChanged) {
            silenceMelodic();
            applySectionSetup();
        }
        this.bar = this.section.getEvents(this.barIdx, this.chordApplied);
        this.cursor = 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void applyChord() {
        Chords.Chord c = this.chordV;
        if (this.section == null || c == this.chordApplied) {
            return;
        }
        this.chordApplied = c;
        resync();
    }

    private void resync() {
        boolean open;
        long nowNs = System.nanoTime();
        double velScale = nowNs - this.lastResyncNs < 250000000 ? 0.55d : 0.8d;
        this.lastResyncNs = nowNs;
        boolean[] old = (boolean[]) this.sounding.clone();
        this.bar = buildBar();
        this.cursor = firstIndexAfter(this.tickPos);
        boolean[] keep = new boolean[2048];
        boolean fired = false;
        byte b = 9;
        if (this.chordApplied != null) {
            int size = this.bar.size();
            int i = 0;
            while (i < this.cursor && i < size) {
                EventChannel on = this.bar.get(i);
                if (on.getType() == b && on.getValue2() > 0 && on.getChannel() != b && (this.section.getRetriggerRule(on.getChannel()) != 0 || xmSustains(on.getChannel()))) {
                    int j = i + 1;
                    while (true) {
                        if (j < size) {
                            EventChannel off = this.bar.get(j);
                            if ((off.getType() != 8 && (off.getType() != 9 || off.getValue2() != 0)) || off.getChannel() != on.getChannel() || off.getValue1() != on.getValue1()) {
                                j++;
                            } else {
                                open = j >= this.cursor;
                                break;
                            }
                        } else {
                            open = true;
                            break;
                        }
                    }
                    if (open) {
                        int k = ((on.getChannel() & StySection.Phrase2) << 7) | (on.getValue1() & 127);
                        keep[k] = true;
                        if (!old[k]) {
                            fire(on.withVelocity((int) Math.round(((double) on.getValue2()) * velScale)));
                            fired = true;
                        }
                    }
                }
                i++;
                b = 9;
            }
        }
        char c = 1;
        int i2 = this.lateOffs.size() - 1;
        while (i2 >= 0) {
            long[] o = this.lateOffs.get(i2);
            if (keep[(((int) o[c]) << 7) | ((int) o[2])]) {
                this.lateOffs.remove(i2);
            }
            i2--;
            c = 1;
        }
        int ch = 0;
        while (ch < 16) {
            if (ch != 9) {
                int n = 0;
                while (n < 128) {
                    int k2 = (ch << 7) | n;
                    if (old[k2] && !keep[k2]) {
                        if (!fired) {
                            this.sounding[k2] = false;
                            this.sink.send(new EventChannel(0, (byte) 8, (byte) ch, (byte) n, (byte) 0));
                        } else {
                            this.lateOffs.add(new long[]{35000000 + nowNs, ch, n, nowNs});
                        }
                    }
                    n++;
                    velScale = velScale;
                    old = old;
                }
            }
            ch++;
            velScale = velScale;
            old = old;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void applySectionRequest(String name) {
        applySectionRequestInner(name);
        notifyNext();
    }

    private void applySectionRequestInner(String name) {
        if (this.section == null || name == null || this.sty.getSection(name) == null) {
            return;
        }
        String cur = this.section.getName();
        String str = null;
        if (isEnding(cur) && !isEnding(name)) {
            this.section = pick(mainFor(last(cur)));
            this.barIdx = 0;
            this.afterName = null;
            this.pendingName = null;
            silenceMelodic();
            applySectionSetup();
            this.bar = this.section.getEvents(0, this.chordApplied);
            this.cursor = firstIndexAfter(this.tickPos);
            notifySection();
            cur = this.section.getName();
        }
        if (isFill(name)) {
            if (isFill(cur)) {
                switchFill(name, destMainFor(name));
            } else {
                fillNow(name, destMainFor(name));
            }
            return;
        }
        if (isMain(name)) {
            if (isFill(cur)) {
                // Cambio de opinion en pleno remate: se sustituye por el remate del MAIN elegido
                String f = this.autoFill ? fillFor(last(this.lastMain != null ? this.lastMain : name), last(name)) : null;
                if (f != null && !f.equals(cur)) {
                    switchFill(f, name);
                } else {
                    this.afterName = name;
                }
                return;
            }
            if (isIntro(cur)) {
                // Saltar la intro: remate hacia el MAIN elegido (o cambio directo si AUTO FILL esta apagado).
                String f = this.autoFill ? fillFor(this.lastMain != null ? last(this.lastMain) : last(name), last(name)) : null;
                if (f != null) {
                    fillNow(f, name);
                } else {
                    this.pendingName = name;
                    this.pendingAfter = null;
                }
                return;
            }
            if (isMain(cur)) {
                char a = last(cur);
                char b = last(name);
                if (a != b && !this.autoFill) {
                    // AUTO FILL IN off: change MAIN at the next bar, no fill-in.
                    this.pendingName = name;
                    this.pendingAfter = null;
                    return;
                }
                String f = fillFor(a, b);
                if (f != null) {
                    fillNow(f, name);
                    return;
                } else {
                    this.pendingName = name;
                    this.pendingAfter = null;
                    return;
                }
            }
            this.pendingName = name;
            this.pendingAfter = null;
            return;
        }
        this.pendingName = name;
        if (isIntro(name) && this.lastMain != null) {
            str = this.lastMain;
        }
        this.pendingAfter = str;
    }

    /**
     * Fill-in para pasar del MAIN 'a' al MAIN 'b'. Si el estilo comparte remates (p. ej. un solo
     * "Fill In AA" para Main A y Main B) se usa el mismo remate en los dos MAIN del par (A/B, C/D).
     */
    private String fillFor(char a, char b) {
        String[] cand = {"Fill In " + a + b, "Fill In " + b + b, "Fill In " + a + a,
                "Fill In " + partner(b) + partner(b), "Fill In " + partner(a) + partner(a)};
        for (String c : cand) {
            if (this.sty.containsSection(c)) {
                return c;
            }
        }
        return null;
    }

    private static char partner(char c) {
        switch (c) {
            case 'A':
                return 'B';
            case 'B':
                return 'A';
            case 'C':
                return 'D';
            case 'D':
                return 'C';
            default:
                return c;
        }
    }

    /** Cambia el remate que esta sonando por otro (continuando en la misma posicion del compas). */
    private void switchFill(String fillName, String after) {
        StySection ns = this.sty.getSection(fillName);
        if (ns == null || this.section == null) {
            return;
        }
        if (ns == this.section) {
            this.afterName = after;
            return;
        }
        if (!this.mergePrev || this.prevSection == null) {
            String m = this.lastMain != null ? this.lastMain : mainFor('A');
            this.prevSection = pick(m);
            this.prevBarIdx = 0;
            this.mergePrev = true;
        }
        this.section = ns;
        Arrays.fill(this.mergeDefined, false);
        for (EventChannel fe : this.section.getEvents(0, this.chordApplied)) {
            if (fe.getType() == 9 && fe.getValue2() > 0 && fe.getTick() > this.tickPos) {
                this.mergeDefined[fe.getChannel() & StySection.Phrase2] = true;
            }
        }
        this.barIdx = 0;
        this.afterName = after;
        this.pendingName = null;
        applySectionSetup();
        resync();
        notifySection();
    }

    private void fillNow(String fillName, String after) {
        if (((double) this.barTicks) - this.tickPos < ((double) this.beatTicks) / 2.0d) {
            this.pendingName = fillName;
            this.pendingAfter = after;
            return;
        }
        this.prevSection = this.section;
        this.prevBarIdx = this.barIdx;
        this.mergePrev = true;
        this.section = pick(fillName);
        Arrays.fill(this.mergeDefined, false);
        for (EventChannel fe : this.section.getEvents(0, this.chordApplied)) {
            if (fe.getType() == 9 && fe.getValue2() > 0 && fe.getTick() > this.tickPos) {
                this.mergeDefined[fe.getChannel() & StySection.Phrase2] = true;
            }
        }
        this.barIdx = 0;
        this.afterName = after;
        this.pendingName = null;
        applySectionSetup();
        resync();
        notifySection();
    }

    private ArrayList<EventChannel> buildBar() {
        ArrayList<EventChannel> b = this.section.getEvents(this.barIdx, this.chordApplied);
        if (this.mergePrev && this.prevSection != null) {
            ArrayList<EventChannel> own = new ArrayList<>();
            for (EventChannel e : b) {
                if (this.mergeDefined[e.getChannel() & StySection.Phrase2]) {
                    own.add(e);
                }
            }
            b = own;
            for (EventChannel e2 : this.prevSection.getEvents(this.prevBarIdx, this.chordApplied)) {
                if (!this.mergeDefined[e2.getChannel() & StySection.Phrase2]) {
                    b.add(e2);
                }
            }
            Collections.sort(b, BAR_ORDER);
        }
        return b;
    }

    private int firstIndexAfter(double t) {
        int i = 0;
        while (i < this.bar.size() && this.bar.get(i).getTick() <= t) {
            i++;
        }
        return i;
    }

    private void silenceMelodic() {
        this.lateOffs.clear();
        for (int ch = 0; ch < 16; ch++) {
            if (ch != 9) {
                for (int n = 0; n < 128; n++) {
                    int k = (ch << 7) | n;
                    if (this.sounding[k]) {
                        this.sounding[k] = false;
                        this.sink.send(new EventChannel(0, (byte) 8, (byte) ch, (byte) n, (byte) 0));
                    }
                }
            }
        }
    }
}
