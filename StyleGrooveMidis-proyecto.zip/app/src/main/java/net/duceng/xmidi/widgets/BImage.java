package net.duceng.xmidi.widgets;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.widget.ImageView;
import net.duceng.xmidi.Base;

/* JADX INFO: loaded from: classes2.dex */
public class BImage extends ImageView {
    public BImage(Context context) {
        super(context);
    }

    public BImage(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public BImage(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override // android.widget.ImageView
    public void setImageResource(int resId) {
        DisplayMetrics dis = getResources().getDisplayMetrics();
        Bitmap bmpTemp = Base.decodeResource(getResources(), resId, dis.widthPixels, dis.heightPixels);
        super.setImageBitmap(bmpTemp);
        System.gc();
    }
}
