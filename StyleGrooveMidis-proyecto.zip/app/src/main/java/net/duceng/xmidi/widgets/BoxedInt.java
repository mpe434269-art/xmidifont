package net.duceng.xmidi.widgets;

/* JADX INFO: loaded from: classes2.dex */
class BoxedInt {
    public int value;

    BoxedInt() {
    }
}
