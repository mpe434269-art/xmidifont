package net.duceng.xmidi.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.widget.ImageButton;
import net.duceng.xmidi.util.Rhythm;

/* JADX INFO: loaded from: classes2.dex */
public class GRhythm extends ImageButton {
    private int degree;
    private Rhythm rhythm;

    public GRhythm(Context context) {
        super(context);
        this.degree = 0;
        this.rhythm = null;
    }

    public GRhythm(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.degree = 0;
        this.rhythm = null;
    }

    public GRhythm(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.degree = 0;
        this.rhythm = null;
    }

    public int getDegree() {
        return this.degree;
    }

    public void setDegree(int degree) {
        if (this.degree != degree) {
            this.degree = degree;
            invalidate();
        }
    }

    public Rhythm getRhythm() {
        return this.rhythm;
    }

    public void setRhythm(Rhythm rhythm) {
        if (this.rhythm != rhythm) {
            this.rhythm = rhythm;
            invalidate();
        }
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onDraw(Canvas canvas) {
        if (this.rhythm != null) {
            int left = getPaddingLeft();
            int top = getPaddingTop();
            int right = getPaddingRight();
            int bottom = getPaddingBottom();
            int width = (getWidth() - left) - right;
            int height = (getHeight() - top) - bottom;
            double a = Math.toRadians(this.degree);
            int nw = (int) (Math.abs(((double) width) * Math.cos(a)) + Math.abs(((double) height) * Math.sin(a)));
            int nh = (int) (Math.abs(((double) width) * Math.sin(a)) + Math.abs(((double) height) * Math.cos(a)));
            int saveCount = canvas.getSaveCount();
            canvas.save();
            canvas.translate((width / 2) + left, (height / 2) + top);
            canvas.rotate(this.degree % 360);
            canvas.translate((-nw) / 2, (-nh) / 2);
            this.rhythm.draw(canvas, nw, nh);
            canvas.restoreToCount(saveCount);
        }
    }
}
