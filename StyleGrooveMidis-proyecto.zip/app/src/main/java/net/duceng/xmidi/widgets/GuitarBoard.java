package net.duceng.xmidi.widgets;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import net.duceng.xmidi.Base;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes2.dex */
public class GuitarBoard extends SurfaceView implements SurfaceHolder.Callback {
    public static final int KEYS = 7;
    public static final int OCTAVE = 7;
    private Bitmap barBitmap;
    private float barHeight;
    private Bitmap boardBitmap;
    private Rect boardRect;
    private int border;
    private int[] eventNotes;
    private Bitmap fingerBitmap;
    private int fingerWidth;
    private int[] fingers;
    private GuitarBoardListener guitarBoardListener;
    private SurfaceHolder holder;
    private int margin;
    private Paint paint;
    private float stringWidth;
    private boolean surfaceReady;
    private static float BWIDTH = 0.75f;
    private static int[] NOTES = {0, 40, 45, 50, 55, 59, 64};

    public interface GuitarBoardListener {
        void onKeysChanged(int i, int i2);
    }

    public GuitarBoard(Context context) {
        super(context);
        this.paint = new Paint();
        this.boardRect = new Rect();
        this.fingers = new int[]{1, 0, 2, 2, 1, 0, 0};
        this.eventNotes = new int[10];
        init();
    }

    public GuitarBoard(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.paint = new Paint();
        this.boardRect = new Rect();
        this.fingers = new int[]{1, 0, 2, 2, 1, 0, 0};
        this.eventNotes = new int[10];
        init();
    }

    public GuitarBoard(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.paint = new Paint();
        this.boardRect = new Rect();
        this.fingers = new int[]{1, 0, 2, 2, 1, 0, 0};
        this.eventNotes = new int[10];
        init();
    }

    private void init() {
        this.margin = 0;
        this.border = 1;
        this.holder = getHolder();
        this.holder.addCallback(this);
        this.holder.setFormat(1);
    }

    @Override // android.view.View
    protected void onSizeChanged(int width, int height, int oldw, int oldh) {
        int w = (int) (((width - (this.margin * 2)) - (this.border * 2)) * BWIDTH);
        this.boardRect.left = this.margin + this.border + ((getWidth() - w) / 2);
        this.boardRect.top = this.margin + this.border;
        this.boardRect.right = this.boardRect.left + w;
        this.boardRect.bottom = (height - this.margin) - this.border;
        this.stringWidth = w / 6.0f;
        this.barHeight = this.boardRect.height() / 5.0f;
        this.fingerWidth = (int) ((this.stringWidth * 3.0f) / 5.0f);
        Log.i("GuiterBoard", "onSizeChanged width: " + width);
        initBitmap();
    }

    private void initBitmap() {
        Bitmap bmpTemp = Base.decodeResource(getResources(), R.drawable.gfingers, this.boardRect.width(), this.boardRect.height());
        this.boardBitmap = Bitmap.createScaledBitmap(bmpTemp, this.boardRect.width(), this.boardRect.height(), true);
        bmpTemp.recycle();
        Bitmap bmpTemp2 = Base.decodeResource(getResources(), R.drawable.gon, this.fingerWidth, this.fingerWidth);
        this.fingerBitmap = Bitmap.createScaledBitmap(bmpTemp2, this.fingerWidth, this.fingerWidth, true);
        bmpTemp2.recycle();
        Bitmap bmpTemp3 = Base.decodeResource(getResources(), R.drawable.gbar, this.boardRect.width(), this.fingerWidth / 2);
        this.barBitmap = Bitmap.createScaledBitmap(bmpTemp3, this.boardRect.width(), this.fingerWidth / 2, true);
        bmpTemp3.recycle();
        System.gc();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        Log.i("PianoBoard", "onDraw: This will NOT happen!");
        draw(canvas);
    }

    @Override // android.view.SurfaceView, android.view.View
    public void draw(Canvas canvas) {
        canvas.drawColor(0, PorterDuff.Mode.CLEAR);
        drawBorder(canvas);
        canvas.drawBitmap(this.boardBitmap, this.boardRect.left, this.boardRect.top, this.paint);
        drawFingers(canvas);
    }

    private void drawBorder(Canvas canvas) {
        if (this.border > 0) {
            canvas.drawRect(this.margin, this.margin, getWidth() - this.margin, this.margin + this.border, this.paint);
            canvas.drawRect(this.margin, this.margin, this.margin + this.border, getHeight() - this.margin, this.paint);
            canvas.drawRect(this.margin, (getHeight() - this.margin) - this.border, getWidth() - this.margin, getHeight() - this.margin, this.paint);
            canvas.drawRect((getWidth() - this.margin) - this.border, this.margin, getWidth() - this.margin, getHeight() - this.margin, this.paint);
        }
    }

    private void drawFingers(Canvas canvas) {
        if (this.fingers[0] > 0) {
            canvas.drawBitmap(this.barBitmap, this.boardRect.left, ((this.boardRect.top + (this.barHeight * this.fingers[0])) - (this.barHeight / 2.0f)) - (this.fingerWidth / 2), this.paint);
        }
        for (int i = 1; i < this.fingers.length; i++) {
            if (this.fingers[i] > 0) {
                canvas.drawBitmap(this.fingerBitmap, ((this.boardRect.left - (this.stringWidth / 2.0f)) + (this.stringWidth * i)) - (this.fingerWidth / 2), ((this.boardRect.top + (this.barHeight * (this.fingers[i] + this.fingers[0]))) - (this.barHeight / 2.0f)) - (this.fingerWidth / 2), this.paint);
            }
        }
    }

    private void draw() {
        Canvas canvas;
        if (this.surfaceReady && (canvas = this.holder.lockCanvas()) != null) {
            draw(canvas);
            this.holder.unlockCanvasAndPost(canvas);
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction() & 255;
        if (action == 0 || action == 5) {
            int idx = event.getActionIndex();
            int x = (int) event.getX(idx);
            int y = (int) event.getY(idx);
            if (this.boardRect.contains(x, y)) {
                int xoff = (int) ((((x - this.boardRect.left) + (this.fingerWidth / 2)) + (this.stringWidth / 2.0f)) % this.stringWidth);
                if (xoff < this.fingerWidth) {
                    int xnum = (int) ((((x - this.boardRect.left) + (this.fingerWidth / 2)) + (this.stringWidth / 2.0f)) / this.stringWidth);
                    if (this.fingers[xnum] >= 0) {
                        int note2 = NOTES[xnum] + this.fingers[xnum] + this.fingers[0];
                        int val = ((y * 90) / this.boardRect.bottom) + 30;
                        if (this.guitarBoardListener != null) {
                            this.guitarBoardListener.onKeysChanged(note2, val);
                        }
                        this.eventNotes[event.getPointerId(idx)] = note2;
                    }
                }
            }
        } else if (action == 1 || action == 6) {
            int id = event.getPointerId(event.getActionIndex());
            if (this.guitarBoardListener != null && this.eventNotes[id] > 0) {
                this.guitarBoardListener.onKeysChanged(this.eventNotes[id], 0);
            }
            this.eventNotes[id] = 0;
        } else if (action == 2) {
            int idx2 = event.getActionIndex();
            int id2 = event.getPointerId(idx2);
            int x2 = (int) event.getX(idx2);
            int y2 = (int) event.getY(idx2);
            if (this.boardRect.contains(x2, y2)) {
                int xoff2 = (int) ((((x2 - this.boardRect.left) + (this.fingerWidth / 2)) + (this.stringWidth / 2.0f)) % this.stringWidth);
                if (xoff2 < this.fingerWidth) {
                    int xnum2 = (int) ((((x2 - this.boardRect.left) + (this.fingerWidth / 2)) + (this.stringWidth / 2.0f)) / this.stringWidth);
                    if (this.fingers[xnum2] >= 0) {
                        int i = this.eventNotes[id2];
                        int note = NOTES[xnum2] + this.fingers[xnum2] + this.fingers[0];
                        if (i != note) {
                            int val2 = ((y2 * 90) / this.boardRect.bottom) + 30;
                            if (this.guitarBoardListener != null) {
                                if (this.eventNotes[id2] > 0) {
                                    this.guitarBoardListener.onKeysChanged(this.eventNotes[id2], 0);
                                }
                                this.guitarBoardListener.onKeysChanged(note, val2);
                            }
                            this.eventNotes[id2] = note;
                        }
                    }
                }
            }
        }
        return true;
    }

    public int[] getFingers() {
        return this.fingers;
    }

    public void setFingers(byte[] f) {
        for (int i = 0; i < this.fingers.length; i++) {
            this.fingers[i] = f[i];
        }
        draw();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        draw();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceCreated(SurfaceHolder holder) {
        this.surfaceReady = true;
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceDestroyed(SurfaceHolder holder) {
        this.surfaceReady = false;
    }

    public void setGuitarBoardListener(GuitarBoardListener l) {
        this.guitarBoardListener = l;
    }
}
