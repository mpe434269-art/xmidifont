package net.duceng.xmidi.widgets;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import net.duceng.xsynth.R;

/**
 * Tecla de panel estilo Yamaha: un LED arriba (apagado / azul / naranja) y una etiqueta dorada.
 */
public class KeyPad extends LinearLayout {
    public static final int LED_OFF = 0;
    public static final int LED_BLUE = 1;
    public static final int LED_ORANGE = 2;

    private final ImageView led;
    private final TextView label;
    private int ledState;

    public KeyPad(Context context) {
        this(context, null);
    }

    public KeyPad(Context context, AttributeSet attrs) {
        super(context, attrs);
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);
        setBackgroundResource(R.drawable.bg_keycap);
        setClickable(true);
        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(android.view.View v, android.view.MotionEvent e) {
                int a = e.getActionMasked();
                if (a == android.view.MotionEvent.ACTION_DOWN) {
                    v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).start();
                } else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(new android.view.animation.OvershootInterpolator(2f)).start();
                }
                return false;
            }
        });
        setPadding(dp(3), dp(5), dp(3), dp(3));

        this.led = new ImageView(context);
        this.led.setImageResource(R.drawable.led_state);
        this.led.setScaleType(ImageView.ScaleType.FIT_XY);
        LayoutParams lp = new LayoutParams(dp(22), dp(7));
        lp.bottomMargin = dp(3);
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        addView(this.led, lp);

        this.label = new TextView(context);
        this.label.setGravity(Gravity.CENTER);
        this.label.setTextColor(getResources().getColor(R.color.gold));
        this.label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        this.label.setTypeface(Typeface.DEFAULT_BOLD);
        addView(this.label, new LayoutParams(LayoutParams.MATCH_PARENT, 0, 1.0f));

        this.ledState = -1;
        setLed(LED_BLUE);
    }

    private int dp(int v) {
        return (int) ((v * getResources().getDisplayMetrics().density) + 0.5f);
    }

    public void setLabel(CharSequence text) {
        this.label.setText(text);
    }

    public void setLabelSize(float sp) {
        this.label.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
    }

    public void setLed(int state) {
        if (state == this.ledState) {
            return;
        }
        this.ledState = state;
        this.led.setImageLevel(state);
        this.led.animate().cancel();
        if (state != LED_OFF) {
            // destello de encendido: el LED "late" al activarse
            this.led.setScaleX(1.5f);
            this.led.setScaleY(1.8f);
            this.led.animate().scaleX(1f).scaleY(1f).setDuration(220).start();
            this.label.animate().cancel();
            this.label.setAlpha(0.6f);
            this.label.animate().alpha(isEnabled() ? 1f : 0.3f).setDuration(220).start();
        }
    }

    public int getLed() {
        return this.ledState;
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        this.label.setAlpha(enabled ? 1.0f : 0.3f);
        if (!enabled) {
            setLed(LED_OFF);
        }
    }
}
