package net.duceng.xmidi.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageButton;

/* JADX INFO: loaded from: classes2.dex */
public class RButton extends ImageButton {
    private int degree;

    public RButton(Context context) {
        super(context);
        this.degree = 0;
    }

    public RButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.degree = 0;
    }

    public RButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.degree = 0;
    }

    public int getDegree() {
        return this.degree;
    }

    public void setDegree(int degree) {
        this.degree = degree;
        invalidate();
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onDraw(Canvas canvas) {
        Drawable d = getDrawable();
        if (d != null) {
            Rect bounds = d.getBounds();
            int w = bounds.right - bounds.left;
            int h = bounds.bottom - bounds.top;
            int left = getPaddingLeft();
            int top = getPaddingTop();
            int right = getPaddingRight();
            int bottom = getPaddingBottom();
            int width = (getWidth() - left) - right;
            int height = (getHeight() - top) - bottom;
            double a = Math.toRadians(this.degree);
            int nw = (int) (Math.abs(((double) w) * Math.cos(a)) + Math.abs(((double) h) * Math.sin(a)));
            int nh = (int) (Math.abs(((double) w) * Math.sin(a)) + Math.abs(((double) h) * Math.cos(a)));
            int saveCount = canvas.getSaveCount();
            canvas.save();
            canvas.translate((width / 2) + left, (height / 2) + top);
            canvas.scale(width / nw, height / nh);
            canvas.rotate(this.degree % 360);
            canvas.translate((-w) / 2, (-h) / 2);
            d.draw(canvas);
            canvas.restoreToCount(saveCount);
        }
    }
}
