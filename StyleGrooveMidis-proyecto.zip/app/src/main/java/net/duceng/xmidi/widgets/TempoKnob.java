package net.duceng.xmidi.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/** Perilla metalica de tempo: gira segun el BPM y se arrastra verticalmente para cambiarlo. */
public class TempoKnob extends View {
    public interface Listener {
        void onDelta(int bpmDelta);
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float angle = 0.0f;
    private Listener listener;
    private float lastY;
    private float acc;

    public TempoKnob(Context c) {
        super(c);
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    public void setBpm(int bpm) {
        this.angle = -135.0f + ((Math.max(40, Math.min(240, bpm)) - 40) / 200.0f) * 270.0f;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2.0f;
        float cy = getHeight() / 2.0f;
        float r = Math.min(cx, cy) - 2.0f;
        if (r <= 0) {
            return;
        }
        this.paint.setStyle(Paint.Style.FILL);
        this.paint.setShader(new RadialGradient(cx - r / 3.0f, cy - r / 3.0f, r * 1.4f,
            new int[]{0xfff4f4f4, 0xffa8a8a8, 0xff3c3c3c}, null, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, r, this.paint);
        this.paint.setShader(null);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeWidth(2.0f);
        this.paint.setColor(0xff1a1a1a);
        canvas.drawCircle(cx, cy, r, this.paint);
        canvas.save();
        canvas.rotate(this.angle, cx, cy);
        this.paint.setStrokeWidth(Math.max(3.0f, r / 7.0f));
        this.paint.setStrokeCap(Paint.Cap.ROUND);
        this.paint.setColor(0xff202020);
        canvas.drawLine(cx, cy - r * 0.25f, cx, cy - r * 0.8f, this.paint);
        canvas.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getAction() & 255) {
            case 0:
                this.lastY = e.getY();
                this.acc = 0.0f;
                getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case 2:
                this.acc += this.lastY - e.getY();
                this.lastY = e.getY();
                int steps = (int) (this.acc / 6.0f);
                if (steps != 0) {
                    this.acc -= steps * 6.0f;
                    if (this.listener != null) {
                        this.listener.onDelta(steps);
                    }
                }
                return true;
            default:
                return true;
        }
    }
}
