package net.duceng.xmidi.widgets.score;

/* JADX INFO: loaded from: classes6.dex */
public enum Accid {
    None,
    Sharp,
    Flat,
    Natural;

    public static Accid[] valuesCustom() {
        Accid[] accidArrValuesCustom = values();
        int length = accidArrValuesCustom.length;
        Accid[] accidArr = new Accid[length];
        System.arraycopy(accidArrValuesCustom, 0, accidArr, 0, length);
        return accidArr;
    }
}
