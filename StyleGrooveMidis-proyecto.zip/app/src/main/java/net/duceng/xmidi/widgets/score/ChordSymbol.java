package net.duceng.xmidi.widgets.score;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import java.util.ArrayList;
import net.duceng.xmidi.widgets.MusicScore;

/* JADX INFO: loaded from: classes6.dex */
public class ChordSymbol implements MusicSymbol {
    private AccidSymbol[] accidsymbols;
    private Clef clef;
    private int endtime;
    private boolean hastwostems;
    private MusicScore musicScore;
    private NoteData[] notedata;
    private int starttime;
    private Stem stem1;
    private Stem stem2;
    private int width;

    public ChordSymbol(ArrayList<Note> midinotes, MidiKey key, MidiTime time, Clef c, MusicScore score) {
        NoteDuration dur2;
        int change;
        Stem stem;
        int len = midinotes.size();
        this.hastwostems = false;
        this.clef = c;
        this.musicScore = score;
        this.starttime = midinotes.get(0).getStartTick();
        this.endtime = midinotes.get(0).getEndTick();
        for (int i = 0; i < len; i++) {
            if (i <= 1 || midinotes.get(i).getKey() >= midinotes.get(i - 1).getKey()) {
                this.endtime = Math.max(this.endtime, midinotes.get(i).getEndTick());
            } else {
                throw new IllegalArgumentException();
            }
        }
        this.notedata = createNoteData(midinotes, key, time);
        this.accidsymbols = CreateAccidSymbols(this.notedata, this.clef);
        NoteDuration dur1 = this.notedata[0].duration;
        NoteDuration dur3 = dur1;
        int i2 = 0;
        while (true) {
            if (i2 >= this.notedata.length) {
                dur2 = dur3;
                change = -1;
                break;
            }
            dur3 = this.notedata[i2].duration;
            if (dur1 == dur3) {
                i2++;
            } else {
                int change2 = i2;
                dur2 = dur3;
                change = change2;
                break;
            }
        }
        if (dur1 != dur2) {
            this.hastwostems = true;
            stem = null;
            this.stem1 = new Stem(this.notedata[0].whitenote, this.notedata[change - 1].whitenote, dur1, 2, NotesOverlap(this.notedata, 0, change));
            this.stem2 = new Stem(this.notedata[change].whitenote, this.notedata[this.notedata.length - 1].whitenote, dur2, 1, NotesOverlap(this.notedata, change, this.notedata.length));
        } else {
            stem = null;
            int direction = StemDirection(this.notedata[0].whitenote, this.notedata[this.notedata.length - 1].whitenote, this.clef);
            this.stem1 = new Stem(this.notedata[0].whitenote, this.notedata[this.notedata.length - 1].whitenote, dur1, direction, NotesOverlap(this.notedata, 0, this.notedata.length));
            this.stem2 = null;
        }
        if (dur1 == NoteDuration.Whole) {
            this.stem1 = stem;
        }
        if (dur2 == NoteDuration.Whole) {
            this.stem2 = stem;
        }
        this.width = getMinWidth();
    }

    private static NoteData[] createNoteData(ArrayList<Note> midinotes, MidiKey key, MidiTime time) {
        int len = midinotes.size();
        NoteData[] notedata = new NoteData[len];
        for (int i = 0; i < len; i++) {
            Note midi = midinotes.get(i);
            notedata[i] = new NoteData();
            notedata[i].number = midi.getKey();
            notedata[i].leftside = true;
            notedata[i].whitenote = key.GetWhiteNote(midi.getKey());
            notedata[i].duration = time.GetNoteDuration(midi.getEndTick() - midi.getStartTick());
            notedata[i].accid = key.GetAccidental(midi.getKey(), midi.getStartTick() / time.getMeasure());
            if (i > 0 && notedata[i].whitenote.Dist(notedata[i - 1].whitenote) == 1) {
                if (notedata[i - 1].leftside) {
                    notedata[i].leftside = false;
                } else {
                    notedata[i].leftside = true;
                }
            } else {
                notedata[i].leftside = true;
            }
        }
        return notedata;
    }

    private static AccidSymbol[] CreateAccidSymbols(NoteData[] notedata, Clef clef) {
        int count = 0;
        for (NoteData noteData : notedata) {
            if (noteData.accid != Accid.None) {
                count++;
            }
        }
        AccidSymbol[] accidsymbols = new AccidSymbol[count];
        int i = 0;
        for (NoteData n : notedata) {
            if (n.accid != Accid.None) {
                accidsymbols[i] = new AccidSymbol(n.accid, n.whitenote, clef);
                i++;
            }
        }
        return accidsymbols;
    }

    private static int StemDirection(WhiteNote bottom, WhiteNote top, Clef clef) {
        WhiteNote middle;
        if (clef == Clef.Treble) {
            middle = new WhiteNote(1, 5);
        } else {
            middle = new WhiteNote(3, 3);
        }
        int dist = middle.Dist(bottom) + middle.Dist(top);
        return dist >= 0 ? 1 : 2;
    }

    private static boolean NotesOverlap(NoteData[] notedata, int start, int end) {
        for (int i = start; i < end; i++) {
            if (!notedata[i].leftside) {
                return true;
            }
        }
        return false;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getStartTime() {
        return this.starttime;
    }

    public int getEndTime() {
        return this.endtime;
    }

    public Clef getClef() {
        return this.clef;
    }

    public boolean getHasTwoStems() {
        return this.hastwostems;
    }

    public Stem getStem() {
        if (this.stem1 == null) {
            return this.stem2;
        }
        if (this.stem2 != null && this.stem1.getDuration().ordinal() >= this.stem2.getDuration().ordinal()) {
            return this.stem2;
        }
        return this.stem1;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getWidth() {
        return this.width;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void setWidth(int value) {
        this.width = value;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getMinWidth() {
        int i = 16;
        if (this.accidsymbols.length > 0) {
            int result = this.accidsymbols[0].getMinWidth() + 16;
            for (int i2 = 1; i2 < this.accidsymbols.length; i2++) {
                AccidSymbol accid = this.accidsymbols[i2];
                AccidSymbol prev = this.accidsymbols[i2 - 1];
                if (accid.getNote().Dist(prev.getNote()) < 6) {
                    result += accid.getMinWidth();
                }
            }
            i = result;
        }
        if (this.musicScore != null && this.musicScore.getShowNoteLetters() != 0) {
            return i + 8;
        }
        return i;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getAboveStaff() {
        WhiteNote topnote = this.notedata[this.notedata.length - 1].whitenote;
        if (this.stem1 != null) {
            topnote = WhiteNote.Max(topnote, this.stem1.getEnd());
        }
        if (this.stem2 != null) {
            topnote = WhiteNote.Max(topnote, this.stem2.getEnd());
        }
        int dist = (topnote.Dist(WhiteNote.Top(this.clef)) * 8) / 2;
        int result = 0;
        if (dist > 0) {
            result = dist;
        }
        for (AccidSymbol symbol : this.accidsymbols) {
            if (symbol.getAboveStaff() > result) {
                result = symbol.getAboveStaff();
            }
        }
        return result;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getBelowStaff() {
        WhiteNote bottomnote = this.notedata[0].whitenote;
        if (this.stem1 != null) {
            bottomnote = WhiteNote.Min(bottomnote, this.stem1.getEnd());
        }
        if (this.stem2 != null) {
            bottomnote = WhiteNote.Min(bottomnote, this.stem2.getEnd());
        }
        int dist = (WhiteNote.Bottom(this.clef).Dist(bottomnote) * 8) / 2;
        int result = 0;
        if (dist > 0) {
            result = dist;
        }
        for (AccidSymbol symbol : this.accidsymbols) {
            if (symbol.getBelowStaff() > result) {
                result = symbol.getBelowStaff();
            }
        }
        return result;
    }

    private String NoteName(int notenumber, WhiteNote whitenote) {
        if (this.musicScore.getShowNoteLetters() == 1) {
            return Letter(notenumber, whitenote);
        }
        if (this.musicScore.getShowNoteLetters() == 2) {
            String[] fixedDoReMi = {"La", "Li", "Ti", "Do", "Di", "Re", "Ri", "Mi", "Fa", "Fi", "So", "Si"};
            int notescale = NoteScale.FromNumber(notenumber);
            return fixedDoReMi[notescale];
        }
        if (this.musicScore.getShowNoteLetters() == 3) {
            String[] fixedDoReMi2 = {"La", "Li", "Ti", "Do", "Di", "Re", "Ri", "Mi", "Fa", "Fi", "So", "Si"};
            int mainscale = this.musicScore.getMainKey().Notescale();
            int diff = 3 - mainscale;
            int notenumber2 = notenumber + diff;
            if (notenumber2 < 0) {
                notenumber2 += 12;
            }
            int notescale2 = NoteScale.FromNumber(notenumber2);
            return fixedDoReMi2[notescale2];
        }
        if (this.musicScore.getShowNoteLetters() == 4) {
            String[] num = {"10", "11", "12", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
            int notescale3 = NoteScale.FromNumber(notenumber);
            return num[notescale3];
        }
        if (this.musicScore.getShowNoteLetters() == 5) {
            String[] num2 = {"10", "11", "12", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
            int mainscale2 = this.musicScore.getMainKey().Notescale();
            int diff2 = 3 - mainscale2;
            int notenumber3 = notenumber + diff2;
            if (notenumber3 < 0) {
                notenumber3 += 12;
            }
            int notescale4 = NoteScale.FromNumber(notenumber3);
            return num2[notescale4];
        }
        return "";
    }

    private String Letter(int notenumber, WhiteNote whitenote) {
        int notescale = NoteScale.FromNumber(notenumber);
        switch (notescale) {
            case 0:
                return "A";
            case 1:
                if (whitenote.getLetter() == 0) {
                    return "A#";
                }
                return "Bb";
            case 2:
                return "B";
            case 3:
                return "C";
            case 4:
                if (whitenote.getLetter() == 2) {
                    return "C#";
                }
                return "Db";
            case 5:
                return "D";
            case 6:
                if (whitenote.getLetter() == 3) {
                    return "D#";
                }
                return "Eb";
            case 7:
                return "E";
            case 8:
                return "F";
            case 9:
                if (whitenote.getLetter() == 5) {
                    return "F#";
                }
                return "Gb";
            case 10:
                return "G";
            case 11:
                if (whitenote.getLetter() == 6) {
                    return "G#";
                }
                return "Ab";
            default:
                return "";
        }
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void draw(Canvas canvas, Paint paint, int ytop) {
        paint.setStyle(Paint.Style.STROKE);
        canvas.translate(getWidth() - getMinWidth(), 0.0f);
        WhiteNote topstaff = WhiteNote.Top(this.clef);
        int xpos = drawAccid(canvas, paint, ytop);
        canvas.translate(xpos, 0.0f);
        drawNotes(canvas, paint, ytop, topstaff);
        if (this.musicScore != null && this.musicScore.getShowNoteLetters() != 0) {
            drawNoteLetters(canvas, paint, ytop, topstaff);
        }
        if (this.stem1 != null) {
            this.stem1.draw(canvas, paint, ytop, topstaff);
        }
        if (this.stem2 != null) {
            this.stem2.draw(canvas, paint, ytop, topstaff);
        }
        canvas.translate(-xpos, 0.0f);
        canvas.translate(-(getWidth() - getMinWidth()), 0.0f);
    }

    public int drawAccid(Canvas canvas, Paint paint, int ytop) {
        int xpos = 0;
        AccidSymbol prev = null;
        for (AccidSymbol symbol : this.accidsymbols) {
            if (prev != null && symbol.getNote().Dist(prev.getNote()) < 6) {
                xpos += symbol.getWidth();
            }
            canvas.translate(xpos, 0.0f);
            symbol.draw(canvas, paint, ytop);
            canvas.translate(-xpos, 0.0f);
            prev = symbol;
        }
        if (prev != null) {
            return prev.getWidth() + xpos;
        }
        return xpos;
    }

    public void drawNotes(Canvas canvas, Paint paint, int ytop, WhiteNote topstaff) {
        int xnote;
        paint.setStrokeWidth(1.0f);
        NoteData[] noteDataArr = this.notedata;
        int length = noteDataArr.length;
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 < length) {
                NoteData note = noteDataArr[i2];
                int ynote = ytop + ((topstaff.Dist(note.whitenote) * 8) / 2);
                if (note.leftside) {
                    xnote = 1;
                } else {
                    xnote = 11;
                }
                canvas.translate(xnote + 5 + 1, (ynote - 1) + 4);
                canvas.rotate(-45.0f);
                if (note.duration == NoteDuration.Whole || note.duration == NoteDuration.Half || note.duration == NoteDuration.DottedHalf) {
                    RectF rect = new RectF(-5.0f, -4.0f, 5.0f, 3.0f);
                    canvas.drawOval(rect, paint);
                    RectF rect2 = new RectF(-5.0f, -3.0f, 5.0f, 3.0f);
                    canvas.drawOval(rect2, paint);
                    RectF rect3 = new RectF(-5.0f, -3.0f, 5.0f, 2.0f);
                    canvas.drawOval(rect3, paint);
                } else {
                    paint.setStyle(Paint.Style.FILL);
                    RectF rect4 = new RectF(-5.0f, -4.0f, 5.0f, 3.0f);
                    canvas.drawOval(rect4, paint);
                    paint.setStyle(Paint.Style.STROKE);
                }
                canvas.rotate(45.0f);
                canvas.translate(-(xnote + 5 + 1), -((ynote - 1) + 4));
                if (note.duration == NoteDuration.DottedHalf || note.duration == NoteDuration.DottedQuarter || note.duration == NoteDuration.DottedEighth) {
                    RectF rect5 = new RectF(xnote + 10 + 2, ynote + 2, xnote + 10 + 2 + 4, ynote + 2 + 4);
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawOval(rect5, paint);
                    paint.setStyle(Paint.Style.STROKE);
                }
                WhiteNote top = topstaff.Add(1);
                int dist = note.whitenote.Dist(top);
                int y = ytop - 1;
                if (dist >= 2) {
                    int i3 = 2;
                    while (i3 <= dist) {
                        int y2 = y - 8;
                        int y3 = xnote - 1;
                        canvas.drawLine(y3, y2, xnote + 10 + 1, y2, paint);
                        i3 += 2;
                        dist = dist;
                        y = y2;
                    }
                }
                WhiteNote bottom = top.Add(-8);
                int y4 = (ytop + 32) - 1;
                int dist2 = bottom.Dist(note.whitenote);
                if (dist2 >= 2) {
                    int i4 = 2;
                    while (i4 <= dist2) {
                        int y5 = y4 + 8;
                        int y6 = xnote - 1;
                        canvas.drawLine(y6, y5, xnote + 10 + 1, y5, paint);
                        i4 += 2;
                        dist2 = dist2;
                        bottom = bottom;
                        y4 = y5;
                    }
                }
                i = i2 + 1;
            } else {
                return;
            }
        }
    }

    public void drawNoteLetters(Canvas canvas, Paint paint, int ytop, WhiteNote topstaff) {
        boolean overlap = NotesOverlap(this.notedata, 0, this.notedata.length);
        paint.setStrokeWidth(1.0f);
        for (NoteData note : this.notedata) {
            if (note.leftside) {
                int ynote = ((topstaff.Dist(note.whitenote) * 8) / 2) + ytop;
                int xnote = 15;
                if (note.duration == NoteDuration.DottedHalf || note.duration == NoteDuration.DottedQuarter || note.duration == NoteDuration.DottedEighth || overlap) {
                    xnote = 20;
                }
                canvas.drawText(NoteName(note.number, note.whitenote), xnote, ynote + 4, paint);
            }
        }
    }

    public static boolean CanCreateBeam(ChordSymbol[] chords, MidiTime time, boolean startQuarter) {
        int numChords = chords.length;
        Stem firstStem = chords[0].getStem();
        Stem lastStem = chords[chords.length - 1].getStem();
        if (firstStem == null || lastStem == null) {
            return false;
        }
        int measure = chords[0].getStartTime() / time.getMeasure();
        NoteDuration dur = firstStem.getDuration();
        NoteDuration dur2 = lastStem.getDuration();
        boolean dotted8_to_16 = false;
        if (chords.length == 2 && dur == NoteDuration.DottedEighth && dur2 == NoteDuration.Sixteenth) {
            dotted8_to_16 = true;
        }
        if (dur == NoteDuration.Whole || dur == NoteDuration.Half || dur == NoteDuration.DottedHalf || dur == NoteDuration.Quarter || dur == NoteDuration.DottedQuarter || (dur == NoteDuration.DottedEighth && !dotted8_to_16)) {
            return false;
        }
        if (numChords == 6) {
            if (dur != NoteDuration.Eighth) {
                return false;
            }
            boolean correctTime = (time.getNumerator() == 3 && time.getDenominator() == 4) || (time.getNumerator() == 6 && time.getDenominator() == 8) || (time.getNumerator() == 6 && time.getDenominator() == 4);
            if (!correctTime) {
                return false;
            }
            if (time.getNumerator() == 6 && time.getDenominator() == 4 && chords[0].getStartTime() % (time.getResolution() * 3) > time.getResolution() / 6) {
                return false;
            }
        } else if (numChords == 4) {
            if (time.getNumerator() == 3 && time.getDenominator() == 8) {
                return false;
            }
            boolean correctTime2 = time.getNumerator() == 2 || time.getNumerator() == 4 || time.getNumerator() == 8;
            if (!correctTime2 && dur != NoteDuration.Sixteenth) {
                return false;
            }
            int beat = time.getResolution();
            if (dur == NoteDuration.Eighth) {
                beat = time.getResolution() * 2;
            } else if (dur == NoteDuration.ThirtySecond) {
                beat = time.getResolution() / 2;
            }
            if (chords[0].getStartTime() % beat > time.getResolution() / 6) {
                return false;
            }
        } else if (numChords == 3) {
            boolean valid = dur == NoteDuration.Triplet || (dur == NoteDuration.Eighth && time.getNumerator() == 12 && time.getDenominator() == 8);
            if (!valid) {
                return false;
            }
            int beat2 = time.getResolution();
            if (time.getNumerator() == 12 && time.getDenominator() == 8) {
                beat2 = (time.getResolution() / 2) * 3;
            }
            if (chords[0].getStartTime() % beat2 > time.getResolution() / 6) {
                return false;
            }
        } else if (numChords == 2 && startQuarter && chords[0].getStartTime() % time.getResolution() > time.getResolution() / 6) {
            return false;
        }
        for (ChordSymbol chord : chords) {
            if (chord.getStartTime() / time.getMeasure() != measure || chord.getStem() == null) {
                return false;
            }
            if ((chord.getStem().getDuration() != dur && !dotted8_to_16) || chord.getStem().IsBeam()) {
                return false;
            }
        }
        boolean hasTwoStems = false;
        int direction = 1;
        for (ChordSymbol chord2 : chords) {
            if (chord2.getHasTwoStems()) {
                if (hasTwoStems && chord2.getStem().getDirection() != direction) {
                    return false;
                }
                hasTwoStems = true;
                direction = chord2.getStem().getDirection();
            }
        }
        if (!hasTwoStems) {
            WhiteNote note1 = firstStem.getDirection() == 1 ? firstStem.getTop() : firstStem.getBottom();
            WhiteNote note2 = lastStem.getDirection() == 1 ? lastStem.getTop() : lastStem.getBottom();
            direction = StemDirection(note1, note2, chords[0].getClef());
        }
        if (direction == 1) {
            if (Math.abs(firstStem.getTop().Dist(lastStem.getTop())) >= 11) {
                return false;
            }
            return true;
        }
        if (Math.abs(firstStem.getBottom().Dist(lastStem.getBottom())) >= 11) {
            return false;
        }
        return true;
    }

    public static void CreateBeam(ChordSymbol[] chords, int spacing) {
        Stem firstStem = chords[0].getStem();
        Stem lastStem = chords[chords.length - 1].getStem();
        int newdirection = -1;
        for (ChordSymbol chord : chords) {
            if (chord.getHasTwoStems()) {
                newdirection = chord.getStem().getDirection();
                break;
            }
        }
        if (newdirection == -1) {
            WhiteNote note1 = firstStem.getDirection() == 1 ? firstStem.getTop() : firstStem.getBottom();
            WhiteNote note2 = lastStem.getDirection() == 1 ? lastStem.getTop() : lastStem.getBottom();
            newdirection = StemDirection(note1, note2, chords[0].getClef());
        }
        for (ChordSymbol chordSymbol : chords) {
            chordSymbol.getStem().setDirection(newdirection);
        }
        if (chords.length == 2) {
            BringStemsCloser(chords);
        } else {
            LineUpStemEnds(chords);
        }
        firstStem.SetPair(lastStem, spacing);
        for (int i = 1; i < chords.length; i++) {
            chords[i].getStem().setReceiver(true);
        }
    }

    static void BringStemsCloser(ChordSymbol[] chords) {
        Stem firstStem = chords[0].getStem();
        Stem lastStem = chords[1].getStem();
        if (firstStem.getDuration() == NoteDuration.DottedEighth && lastStem.getDuration() == NoteDuration.Sixteenth) {
            if (firstStem.getDirection() == 1) {
                firstStem.setEnd(firstStem.getEnd().Add(2));
            } else {
                firstStem.setEnd(firstStem.getEnd().Add(-2));
            }
        }
        int distance = Math.abs(firstStem.getEnd().Dist(lastStem.getEnd()));
        if (firstStem.getDirection() == 1) {
            if (WhiteNote.Max(firstStem.getEnd(), lastStem.getEnd()) == firstStem.getEnd()) {
                lastStem.setEnd(lastStem.getEnd().Add(distance / 2));
                return;
            } else {
                firstStem.setEnd(firstStem.getEnd().Add(distance / 2));
                return;
            }
        }
        if (WhiteNote.Min(firstStem.getEnd(), lastStem.getEnd()) == firstStem.getEnd()) {
            lastStem.setEnd(lastStem.getEnd().Add((-distance) / 2));
        } else {
            firstStem.setEnd(firstStem.getEnd().Add((-distance) / 2));
        }
    }

    static void LineUpStemEnds(ChordSymbol[] chords) {
        int i = 0;
        Stem firstStem = chords[0].getStem();
        Stem lastStem = chords[chords.length - 1].getStem();
        Stem middleStem = chords[1].getStem();
        if (firstStem.getDirection() == 1) {
            WhiteNote top = firstStem.getEnd();
            int length = chords.length;
            while (i < length) {
                ChordSymbol chord = chords[i];
                top = WhiteNote.Max(top, chord.getStem().getEnd());
                i++;
            }
            if (top == firstStem.getEnd() && top.Dist(lastStem.getEnd()) >= 2) {
                firstStem.setEnd(top);
                middleStem.setEnd(top.Add(-1));
                lastStem.setEnd(top.Add(-2));
            } else if (top == lastStem.getEnd() && top.Dist(firstStem.getEnd()) >= 2) {
                firstStem.setEnd(top.Add(-2));
                middleStem.setEnd(top.Add(-1));
                lastStem.setEnd(top);
            } else {
                firstStem.setEnd(top);
                middleStem.setEnd(top);
                lastStem.setEnd(top);
            }
        } else {
            WhiteNote bottom = firstStem.getEnd();
            int length2 = chords.length;
            while (i < length2) {
                ChordSymbol chord2 = chords[i];
                bottom = WhiteNote.Min(bottom, chord2.getStem().getEnd());
                i++;
            }
            if (bottom == firstStem.getEnd() && lastStem.getEnd().Dist(bottom) >= 2) {
                middleStem.setEnd(bottom.Add(1));
                lastStem.setEnd(bottom.Add(2));
            } else if (bottom == lastStem.getEnd() && firstStem.getEnd().Dist(bottom) >= 2) {
                middleStem.setEnd(bottom.Add(1));
                firstStem.setEnd(bottom.Add(2));
            } else {
                firstStem.setEnd(bottom);
                middleStem.setEnd(bottom);
                lastStem.setEnd(bottom);
            }
        }
        for (int i2 = 1; i2 < chords.length - 1; i2++) {
            Stem stem = chords[i2].getStem();
            stem.setEnd(middleStem.getEnd());
        }
    }

    public String toString() {
        String result = String.format("ChordSymbol clef=%1$s start=%2$s end=%3$s width=%4$s hastwostems=%5$s ", this.clef, Integer.valueOf(getStartTime()), Integer.valueOf(getEndTime()), Integer.valueOf(getWidth()), Boolean.valueOf(this.hastwostems));
        for (AccidSymbol symbol : this.accidsymbols) {
            result = String.valueOf(result) + symbol.toString() + " ";
        }
        for (NoteData note : this.notedata) {
            result = String.valueOf(result) + String.format("Note whitenote=%1$s duration=%2$s leftside=%3$s ", note.whitenote, note.duration, Boolean.valueOf(note.leftside));
        }
        if (this.stem1 != null) {
            result = String.valueOf(result) + this.stem1.toString() + " ";
        }
        if (this.stem2 != null) {
            return String.valueOf(result) + this.stem2.toString() + " ";
        }
        return result;
    }
}
