package net.duceng.xmidi.widgets.score;

/* JADX INFO: loaded from: classes6.dex */
public enum Clef {
    Treble,
    Bass;

    public static Clef[] valuesCustom() {
        Clef[] clefArrValuesCustom = values();
        int length = clefArrValuesCustom.length;
        Clef[] clefArr = new Clef[length];
        System.arraycopy(clefArrValuesCustom, 0, clefArr, 0, length);
        return clefArr;
    }
}
