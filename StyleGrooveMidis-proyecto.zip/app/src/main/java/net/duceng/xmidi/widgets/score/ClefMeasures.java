package net.duceng.xmidi.widgets.score;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes6.dex */
public class ClefMeasures {
    private ArrayList<Clef> clefs;
    private int measure;

    public ClefMeasures(ArrayList<Note> notes, int measurelen) {
        this.measure = measurelen;
        Clef mainclef = mainClef(notes);
        int nextmeasure = measurelen;
        int pos = 0;
        Clef clef = mainclef;
        this.clefs = new ArrayList<>();
        while (pos < notes.size()) {
            int sumnotes = 0;
            int notecount = 0;
            while (pos < notes.size() && notes.get(pos).getStartTick() < nextmeasure) {
                sumnotes += notes.get(pos).getKey();
                notecount++;
                pos++;
            }
            int avgnote = sumnotes / (notecount == 0 ? 1 : notecount);
            if (avgnote != 0) {
                if (avgnote >= WhiteNote.BottomTreble.getNumber()) {
                    clef = Clef.Treble;
                } else if (avgnote <= WhiteNote.TopBass.getNumber()) {
                    clef = Clef.Bass;
                } else {
                    clef = mainclef;
                }
            }
            this.clefs.add(clef);
            nextmeasure += measurelen;
        }
        this.clefs.add(clef);
    }

    public ClefMeasures(ArrayList<Note> notes, int measurelen, Clef mainclef) {
        this.measure = measurelen;
        int nextmeasure = measurelen;
        int pos = 0;
        Clef clef = mainclef;
        this.clefs = new ArrayList<>();
        while (pos < notes.size()) {
            int sumnotes = 0;
            int notecount = 0;
            while (pos < notes.size() && notes.get(pos).getStartTick() < nextmeasure) {
                sumnotes += notes.get(pos).getKey();
                notecount++;
                pos++;
            }
            int avgnote = sumnotes / (notecount == 0 ? 1 : notecount);
            if (avgnote != 0) {
                if (avgnote >= WhiteNote.BottomTreble.getNumber()) {
                    clef = Clef.Treble;
                } else if (avgnote <= WhiteNote.TopBass.getNumber()) {
                    clef = Clef.Bass;
                } else {
                    clef = mainclef;
                }
            }
            this.clefs.add(clef);
            nextmeasure += measurelen;
        }
        this.clefs.add(clef);
    }

    public Clef getClef(int starttime) {
        ArrayList<Clef> arrayList;
        int size;
        if (starttime / this.measure >= this.clefs.size()) {
            arrayList = this.clefs;
            size = this.clefs.size() - 1;
        } else {
            arrayList = this.clefs;
            size = starttime / this.measure;
        }
        return arrayList.get(size);
    }

    private static Clef mainClef(ArrayList<Note> notes) {
        int middleC = WhiteNote.MiddleC.getNumber();
        int total = 0;
        for (Note m : notes) {
            total += m.getKey();
        }
        if (notes.size() == 0) {
            return Clef.Treble;
        }
        if (total / notes.size() >= middleC) {
            return Clef.Treble;
        }
        return Clef.Bass;
    }
}
