package net.duceng.xmidi.widgets.score;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes6.dex */
public class ClefSymbol implements MusicSymbol {
    private static Bitmap bass;
    public static Bitmap treble;
    private Clef clef;
    private boolean smallsize;
    private int starttime;
    private int width;

    public ClefSymbol(Clef clef, int starttime, boolean small) {
        if (treble == null || bass == null) {
            throw new RuntimeException("ClefSymbol.LoadImages(Context) will be call first!");
        }
        this.clef = clef;
        this.starttime = starttime;
        this.smallsize = small;
        this.width = getMinWidth();
    }

    public static void LoadImages(Context context) {
        if (treble == null || bass == null) {
            Resources res = context.getResources();
            treble = BitmapFactory.decodeResource(res, R.drawable.treble);
            bass = BitmapFactory.decodeResource(res, R.drawable.bass);
        }
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getStartTime() {
        return this.starttime;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getMinWidth() {
        return this.smallsize ? 20 : 30;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getWidth() {
        return this.width;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void setWidth(int value) {
        this.width = value;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getAboveStaff() {
        return (this.clef != Clef.Treble || this.smallsize) ? 0 : 16;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getBelowStaff() {
        if (this.clef == Clef.Treble && !this.smallsize) {
            return 16;
        }
        if (this.clef == Clef.Treble && this.smallsize) {
            return 8;
        }
        return 0;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void draw(Canvas canvas, Paint paint, int ytop) {
        Bitmap image;
        int height;
        canvas.translate(getWidth() - getMinWidth(), 0.0f);
        int y = ytop;
        paint.setAntiAlias(true);
        if (this.clef == Clef.Treble) {
            image = treble;
            if (this.smallsize) {
                height = 41;
            } else {
                height = 54;
                y = ytop - 12;
            }
        } else {
            image = bass;
            if (this.smallsize) {
                height = 21;
            } else {
                height = 25;
            }
        }
        int imgwidth = (image.getWidth() * height) / image.getHeight();
        Rect src = new Rect(0, 0, image.getWidth(), image.getHeight());
        Rect dest = new Rect(0, y, imgwidth + 0, y + height);
        canvas.drawBitmap(image, src, dest, paint);
        canvas.translate(-(getWidth() - getMinWidth()), 0.0f);
    }

    public String toString() {
        return String.format("ClefSymbol clef=%1$s small=%2$s width=%3$s", this.clef, Boolean.valueOf(this.smallsize), Integer.valueOf(this.width));
    }
}
