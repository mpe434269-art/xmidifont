package net.duceng.xmidi.widgets.score;

/* JADX INFO: loaded from: classes6.dex */
public class DictInt {
    private int size = 0;
    private int lastpos = 0;
    private int[] keys = new int[23];
    private int[] values = new int[23];

    private void resize() {
        int newcapacity = this.keys.length * 2;
        int[] newkeys = new int[newcapacity];
        int[] newvalues = new int[newcapacity];
        for (int i = 0; i < this.keys.length; i++) {
            newkeys[i] = this.keys[i];
            newvalues[i] = this.values[i];
        }
        this.keys = newkeys;
        this.values = newvalues;
    }

    public void add(int key, int value) {
        if (this.size == this.keys.length) {
            resize();
        }
        int pos = this.size - 1;
        while (pos >= 0 && key < this.keys[pos]) {
            this.keys[pos + 1] = this.keys[pos];
            this.values[pos + 1] = this.values[pos];
            pos--;
        }
        this.keys[pos + 1] = key;
        this.values[pos + 1] = value;
        this.size++;
    }

    public void set(int key, int value) {
        if (contains(key)) {
            this.keys[this.lastpos] = key;
            this.values[this.lastpos] = value;
        } else {
            add(key, value);
        }
    }

    public boolean contains(int key) {
        if (this.size == 0) {
            return false;
        }
        if (this.lastpos < 0 || this.lastpos >= this.size || key < this.keys[this.lastpos]) {
            this.lastpos = 0;
        }
        while (this.lastpos < this.size && key > this.keys[this.lastpos]) {
            this.lastpos++;
        }
        return this.lastpos < this.size && key == this.keys[this.lastpos];
    }

    int get(int key) {
        if (contains(key)) {
            return this.values[this.lastpos];
        }
        return 0;
    }

    int count() {
        return this.size;
    }

    int getKey(int index) {
        return this.keys[index];
    }
}
