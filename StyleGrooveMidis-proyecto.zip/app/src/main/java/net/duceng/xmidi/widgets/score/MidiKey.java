package net.duceng.xmidi.widgets.score;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes6.dex */
public class MidiKey {
    public static final int A = 3;
    public static final int Aflat = 4;
    public static final int B = 5;
    public static final int Bflat = 2;
    public static final int C = 0;
    public static final int D = 2;
    public static final int Dflat = 5;
    public static final int E = 4;
    public static final int Eflat = 3;
    public static final int F = 1;
    public static final int G = 1;
    public static final int Gflat = 6;
    private static Accid[][] flatkeys;
    private static Accid[][] sharpkeys;
    private AccidSymbol[] bass;
    private Accid[] keymap;
    private int num_flats;
    private int num_sharps;
    private int prevmeasure;
    private AccidSymbol[] treble;

    public MidiKey(int num_sharps, int num_flats) {
        if (num_sharps > 0 && num_flats > 0) {
            throw new IllegalArgumentException();
        }
        this.num_sharps = num_sharps;
        this.num_flats = num_flats;
        CreateAccidentalMaps();
        this.keymap = new Accid[160];
        ResetKeyMap();
        CreateSymbols();
    }

    public MidiKey(int notescale) {
        this.num_flats = 0;
        this.num_sharps = 0;
        switch (notescale) {
            case 0:
                this.num_sharps = 3;
                break;
            case 1:
                this.num_flats = 2;
                break;
            case 2:
                this.num_sharps = 5;
                break;
            case 3:
                break;
            case 4:
                this.num_flats = 5;
                break;
            case 5:
                this.num_sharps = 2;
                break;
            case 6:
                this.num_flats = 3;
                break;
            case 7:
                this.num_sharps = 4;
                break;
            case 8:
                this.num_flats = 1;
                break;
            case 9:
                this.num_flats = 6;
                break;
            case 10:
                this.num_sharps = 1;
                break;
            case 11:
                this.num_flats = 4;
                break;
            default:
                throw new IllegalArgumentException();
        }
        CreateAccidentalMaps();
        this.keymap = new Accid[160];
        ResetKeyMap();
        CreateSymbols();
    }

    private static void CreateAccidentalMaps() {
        if (sharpkeys == null) {
            sharpkeys = new Accid[8][];
            flatkeys = new Accid[8][];
            for (int i = 0; i < 8; i++) {
                sharpkeys[i] = new Accid[12];
                flatkeys[i] = new Accid[12];
            }
            Accid[] map = sharpkeys[0];
            map[0] = Accid.None;
            map[1] = Accid.Flat;
            map[2] = Accid.None;
            map[3] = Accid.None;
            map[4] = Accid.Sharp;
            map[5] = Accid.None;
            map[6] = Accid.Sharp;
            map[7] = Accid.None;
            map[8] = Accid.None;
            map[9] = Accid.Sharp;
            map[10] = Accid.None;
            map[11] = Accid.Sharp;
            Accid[] map2 = sharpkeys[1];
            map2[0] = Accid.None;
            map2[1] = Accid.Flat;
            map2[2] = Accid.None;
            map2[3] = Accid.None;
            map2[4] = Accid.Sharp;
            map2[5] = Accid.None;
            map2[6] = Accid.Sharp;
            map2[7] = Accid.None;
            map2[8] = Accid.Natural;
            map2[9] = Accid.None;
            map2[10] = Accid.None;
            map2[11] = Accid.Sharp;
            Accid[] map3 = sharpkeys[2];
            map3[0] = Accid.None;
            map3[1] = Accid.Flat;
            map3[2] = Accid.None;
            map3[3] = Accid.Natural;
            map3[4] = Accid.None;
            map3[5] = Accid.None;
            map3[6] = Accid.Sharp;
            map3[7] = Accid.None;
            map3[8] = Accid.Natural;
            map3[9] = Accid.None;
            map3[10] = Accid.None;
            map3[11] = Accid.Sharp;
            Accid[] map4 = sharpkeys[3];
            map4[0] = Accid.None;
            map4[1] = Accid.Flat;
            map4[2] = Accid.None;
            map4[3] = Accid.Natural;
            map4[4] = Accid.None;
            map4[5] = Accid.None;
            map4[6] = Accid.Sharp;
            map4[7] = Accid.None;
            map4[8] = Accid.Natural;
            map4[9] = Accid.None;
            map4[10] = Accid.Natural;
            map4[11] = Accid.None;
            Accid[] map5 = sharpkeys[4];
            map5[0] = Accid.None;
            map5[1] = Accid.Flat;
            map5[2] = Accid.None;
            map5[3] = Accid.Natural;
            map5[4] = Accid.None;
            map5[5] = Accid.Natural;
            map5[6] = Accid.None;
            map5[7] = Accid.None;
            map5[8] = Accid.Natural;
            map5[9] = Accid.None;
            map5[10] = Accid.Natural;
            map5[11] = Accid.None;
            Accid[] map6 = sharpkeys[5];
            map6[0] = Accid.Natural;
            map6[1] = Accid.None;
            map6[2] = Accid.None;
            map6[3] = Accid.Natural;
            map6[4] = Accid.None;
            map6[5] = Accid.Natural;
            map6[6] = Accid.None;
            map6[7] = Accid.None;
            map6[8] = Accid.Natural;
            map6[9] = Accid.None;
            map6[10] = Accid.Natural;
            map6[11] = Accid.None;
            Accid[] map7 = flatkeys[0];
            map7[0] = Accid.None;
            map7[1] = Accid.Flat;
            map7[2] = Accid.None;
            map7[3] = Accid.None;
            map7[4] = Accid.Sharp;
            map7[5] = Accid.None;
            map7[6] = Accid.Sharp;
            map7[7] = Accid.None;
            map7[8] = Accid.None;
            map7[9] = Accid.Sharp;
            map7[10] = Accid.None;
            map7[11] = Accid.Sharp;
            Accid[] map8 = flatkeys[1];
            map8[0] = Accid.None;
            map8[1] = Accid.None;
            map8[2] = Accid.Natural;
            map8[3] = Accid.None;
            map8[4] = Accid.Sharp;
            map8[5] = Accid.None;
            map8[6] = Accid.Flat;
            map8[7] = Accid.None;
            map8[8] = Accid.None;
            map8[9] = Accid.Sharp;
            map8[10] = Accid.None;
            map8[11] = Accid.Flat;
            Accid[] map9 = flatkeys[2];
            map9[0] = Accid.None;
            map9[1] = Accid.None;
            map9[2] = Accid.Natural;
            map9[3] = Accid.None;
            map9[4] = Accid.Sharp;
            map9[5] = Accid.None;
            map9[6] = Accid.None;
            map9[7] = Accid.Natural;
            map9[8] = Accid.None;
            map9[9] = Accid.Sharp;
            map9[10] = Accid.None;
            map9[11] = Accid.Flat;
            Accid[] map10 = flatkeys[3];
            map10[0] = Accid.Natural;
            map10[1] = Accid.None;
            map10[2] = Accid.Natural;
            map10[3] = Accid.None;
            map10[4] = Accid.Flat;
            map10[5] = Accid.None;
            map10[6] = Accid.None;
            map10[7] = Accid.Natural;
            map10[8] = Accid.None;
            map10[9] = Accid.Sharp;
            map10[10] = Accid.None;
            map10[11] = Accid.None;
            Accid[] map11 = flatkeys[4];
            map11[0] = Accid.Natural;
            map11[1] = Accid.None;
            map11[2] = Accid.Natural;
            map11[3] = Accid.None;
            map11[4] = Accid.None;
            map11[5] = Accid.Natural;
            map11[6] = Accid.None;
            map11[7] = Accid.Natural;
            map11[8] = Accid.None;
            map11[9] = Accid.Sharp;
            map11[10] = Accid.None;
            map11[11] = Accid.None;
            Accid[] map12 = flatkeys[5];
            map12[0] = Accid.Natural;
            map12[1] = Accid.None;
            map12[2] = Accid.Natural;
            map12[3] = Accid.None;
            map12[4] = Accid.None;
            map12[5] = Accid.Natural;
            map12[6] = Accid.None;
            map12[7] = Accid.Natural;
            map12[8] = Accid.None;
            map12[9] = Accid.None;
            map12[10] = Accid.Natural;
            map12[11] = Accid.None;
            Accid[] map13 = flatkeys[6];
            map13[0] = Accid.Natural;
            map13[1] = Accid.None;
            map13[2] = Accid.None;
            map13[3] = Accid.Natural;
            map13[4] = Accid.None;
            map13[5] = Accid.Natural;
            map13[6] = Accid.None;
            map13[7] = Accid.Natural;
            map13[8] = Accid.None;
            map13[9] = Accid.None;
            map13[10] = Accid.Natural;
            map13[11] = Accid.None;
        }
    }

    private void ResetKeyMap() {
        Accid[] key;
        if (this.num_flats > 0) {
            key = flatkeys[this.num_flats];
        } else {
            key = sharpkeys[this.num_sharps];
        }
        for (int notenumber = 0; notenumber < this.keymap.length; notenumber++) {
            this.keymap[notenumber] = key[NoteScale.FromNumber(notenumber)];
        }
    }

    private void CreateSymbols() {
        Accid a;
        int count = Math.max(this.num_sharps, this.num_flats);
        this.treble = new AccidSymbol[count];
        this.bass = new AccidSymbol[count];
        if (count != 0) {
            WhiteNote[] treblenotes = null;
            WhiteNote[] bassnotes = null;
            if (this.num_sharps > 0) {
                treblenotes = new WhiteNote[]{new WhiteNote(5, 5), new WhiteNote(2, 5), new WhiteNote(6, 5), new WhiteNote(3, 5), new WhiteNote(0, 6), new WhiteNote(4, 5)};
                bassnotes = new WhiteNote[]{new WhiteNote(5, 3), new WhiteNote(2, 3), new WhiteNote(6, 3), new WhiteNote(3, 3), new WhiteNote(0, 4), new WhiteNote(4, 3)};
            } else if (this.num_flats > 0) {
                treblenotes = new WhiteNote[]{new WhiteNote(1, 5), new WhiteNote(4, 5), new WhiteNote(0, 5), new WhiteNote(3, 5), new WhiteNote(6, 4), new WhiteNote(2, 5)};
                bassnotes = new WhiteNote[]{new WhiteNote(1, 3), new WhiteNote(4, 3), new WhiteNote(0, 3), new WhiteNote(3, 3), new WhiteNote(6, 2), new WhiteNote(2, 3)};
            }
            Accid accid = Accid.None;
            if (this.num_sharps > 0) {
                a = Accid.Sharp;
            } else {
                a = Accid.Flat;
            }
            for (int i = 0; i < count; i++) {
                this.treble[i] = new AccidSymbol(a, treblenotes[i], Clef.Treble);
                this.bass[i] = new AccidSymbol(a, bassnotes[i], Clef.Bass);
            }
        }
    }

    public AccidSymbol[] GetSymbols(Clef clef) {
        return clef == Clef.Treble ? this.treble : this.bass;
    }

    public Accid GetAccidental(int notenumber, int measure) {
        if (measure != this.prevmeasure) {
            ResetKeyMap();
            this.prevmeasure = measure;
        }
        if (notenumber <= 1 || notenumber >= 127) {
            return Accid.None;
        }
        Accid result = this.keymap[notenumber];
        if (result == Accid.Sharp) {
            this.keymap[notenumber] = Accid.None;
            this.keymap[notenumber - 1] = Accid.Natural;
            return result;
        }
        if (result == Accid.Flat) {
            this.keymap[notenumber] = Accid.None;
            this.keymap[notenumber + 1] = Accid.Natural;
            return result;
        }
        if (result == Accid.Natural) {
            this.keymap[notenumber] = Accid.None;
            int nextkey = NoteScale.FromNumber(notenumber + 1);
            int prevkey = NoteScale.FromNumber(notenumber - 1);
            if (this.keymap[notenumber - 1] == Accid.None && this.keymap[notenumber + 1] == Accid.None && NoteScale.IsBlackKey(nextkey) && NoteScale.IsBlackKey(prevkey)) {
                if (this.num_flats == 0) {
                    this.keymap[notenumber + 1] = Accid.Sharp;
                    return result;
                }
                this.keymap[notenumber - 1] = Accid.Flat;
                return result;
            }
            if (this.keymap[notenumber - 1] == Accid.None && NoteScale.IsBlackKey(prevkey)) {
                this.keymap[notenumber - 1] = Accid.Flat;
                return result;
            }
            if (this.keymap[notenumber + 1] == Accid.None && NoteScale.IsBlackKey(nextkey)) {
                this.keymap[notenumber + 1] = Accid.Sharp;
                return result;
            }
            return result;
        }
        return result;
    }

    public WhiteNote GetWhiteNote(int notenumber) {
        int notescale = NoteScale.FromNumber(notenumber);
        int octave = ((notenumber + 3) / 12) - 1;
        int letter = 0;
        int[] whole_sharps = {0, 0, 1, 2, 2, 3, 3, 4, 5, 5, 6, 6};
        int[] whole_flats = {0, 1, 1, 2, 3, 3, 4, 4, 5, 6, 6, 0};
        Accid accid = this.keymap[notenumber];
        if (accid == Accid.Flat) {
            letter = whole_flats[notescale];
        } else if (accid == Accid.Sharp || accid == Accid.Natural) {
            letter = whole_sharps[notescale];
        } else if (accid == Accid.None) {
            letter = whole_sharps[notescale];
            if (NoteScale.IsBlackKey(notescale)) {
                if (this.keymap[notenumber - 1] == Accid.Natural && this.keymap[notenumber + 1] == Accid.Natural) {
                    letter = this.num_flats > 0 ? whole_flats[notescale] : whole_sharps[notescale];
                } else if (this.keymap[notenumber - 1] == Accid.Natural) {
                    letter = whole_sharps[notescale];
                } else if (this.keymap[notenumber + 1] == Accid.Natural) {
                    letter = whole_flats[notescale];
                }
            }
        }
        if (this.num_flats == 6 && notescale == 2) {
            letter = 2;
        }
        if (this.num_flats == 6 && notescale == 1) {
            letter = 1;
        }
        if (this.num_flats > 0 && notescale == 11) {
            octave++;
        }
        return new WhiteNote(letter, octave);
    }

    public static MidiKey guess(ArrayList<ArrayList<Note>> tracks) {
        CreateAccidentalMaps();
        int[] notecount = new int[12];
        int smallest_accid_count = 0;
        for (ArrayList<Note> t : tracks) {
            for (Note n : t) {
                int notescale = (n.getKey() + 3) % 12;
                notecount[notescale] = notecount[notescale] + 1;
                smallest_accid_count++;
            }
        }
        int bestkey = 0;
        boolean is_best_sharp = true;
        for (int key = 0; key < 6; key++) {
            int accid_count = 0;
            for (int n2 = 0; n2 < 12; n2++) {
                if (sharpkeys[key][n2] != Accid.None) {
                    accid_count += notecount[n2];
                }
            }
            if (accid_count < smallest_accid_count) {
                smallest_accid_count = accid_count;
                bestkey = key;
                is_best_sharp = true;
            }
        }
        for (int key2 = 0; key2 < 7; key2++) {
            int accid_count2 = 0;
            for (int n3 = 0; n3 < 12; n3++) {
                if (flatkeys[key2][n3] != Accid.None) {
                    accid_count2 += notecount[n3];
                }
            }
            if (accid_count2 < smallest_accid_count) {
                smallest_accid_count = accid_count2;
                bestkey = key2;
                is_best_sharp = false;
            }
        }
        if (is_best_sharp) {
            return new MidiKey(bestkey, 0);
        }
        return new MidiKey(0, bestkey);
    }

    public boolean equals(MidiKey k) {
        return k.num_sharps == this.num_sharps && k.num_flats == this.num_flats;
    }

    public int Notescale() {
        int[] flatmajor = {3, 8, 1, 6, 11, 4, 9, 2};
        int[] sharpmajor = {3, 10, 5, 0, 7, 2, 9, 4, 11, 6};
        return this.num_flats > 0 ? flatmajor[this.num_flats] : sharpmajor[this.num_sharps];
    }

    public static String KeyToString(int notescale) {
        switch (notescale) {
            case 0:
                return "A major";
            case 1:
                return "B-flat major";
            case 2:
                return "B major";
            case 3:
                return "C major";
            case 4:
                return "D-flat major";
            case 5:
                return "D major";
            case 6:
                return "E-flat major";
            case 7:
                return "E major";
            case 8:
                return "F major";
            case 9:
                return "G-flat major";
            case 10:
                return "G major";
            case 11:
                return "A-flat major";
            default:
                return "";
        }
    }

    public String toString() {
        return KeyToString(Notescale());
    }
}
