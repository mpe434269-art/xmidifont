package net.duceng.xmidi.widgets.score;

import android.graphics.Canvas;
import android.graphics.Paint;

/* JADX INFO: loaded from: classes6.dex */
public interface MusicSymbol {
    void draw(Canvas canvas, Paint paint, int i);

    int getAboveStaff();

    int getBelowStaff();

    int getMinWidth();

    int getStartTime();

    int getWidth();

    void setWidth(int i);
}
