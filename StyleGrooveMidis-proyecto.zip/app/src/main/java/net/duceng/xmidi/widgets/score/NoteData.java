package net.duceng.xmidi.widgets.score;

/* JADX INFO: loaded from: classes6.dex */
public class NoteData {
    public Accid accid;
    public NoteDuration duration;
    public boolean leftside;
    public int number;
    public WhiteNote whitenote;
}
