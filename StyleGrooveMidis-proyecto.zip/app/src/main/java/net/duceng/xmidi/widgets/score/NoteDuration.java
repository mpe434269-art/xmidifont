package net.duceng.xmidi.widgets.score;

/* JADX INFO: loaded from: classes6.dex */
public enum NoteDuration {
    ThirtySecond,
    Sixteenth,
    Triplet,
    Eighth,
    DottedEighth,
    Quarter,
    DottedQuarter,
    Half,
    DottedHalf,
    Whole;

    public static NoteDuration[] valuesCustom() {
        NoteDuration[] noteDurationArrValuesCustom = values();
        int length = noteDurationArrValuesCustom.length;
        NoteDuration[] noteDurationArr = new NoteDuration[length];
        System.arraycopy(noteDurationArrValuesCustom, 0, noteDurationArr, 0, length);
        return noteDurationArr;
    }
}
