package net.duceng.xmidi.widgets.score;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

/* JADX INFO: loaded from: classes6.dex */
public class RestSymbol implements MusicSymbol {
    private NoteDuration duration;
    private int starttime;
    private int width = getMinWidth();

    public RestSymbol(int start, NoteDuration dur) {
        this.starttime = start;
        this.duration = dur;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getStartTime() {
        return this.starttime;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getWidth() {
        return this.width;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void setWidth(int value) {
        this.width = value;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getMinWidth() {
        return 20;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getAboveStaff() {
        return 0;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getBelowStaff() {
        return 0;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void draw(Canvas canvas, Paint paint, int ytop) {
        canvas.translate(getWidth() - getMinWidth(), 0.0f);
        canvas.translate(4.0f, 0.0f);
        if (this.duration == NoteDuration.Whole) {
            DrawWhole(canvas, paint, ytop);
        } else if (this.duration == NoteDuration.Half) {
            DrawHalf(canvas, paint, ytop);
        } else if (this.duration == NoteDuration.Quarter) {
            DrawQuarter(canvas, paint, ytop);
        } else if (this.duration == NoteDuration.Eighth) {
            DrawEighth(canvas, paint, ytop);
        }
        canvas.translate(-4.0f, 0.0f);
        canvas.translate(-(getWidth() - getMinWidth()), 0.0f);
    }

    public void DrawWhole(Canvas canvas, Paint paint, int ytop) {
        int y = ytop + 8;
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(0.0f, y, 10.0f, y + 4, paint);
        paint.setStyle(Paint.Style.STROKE);
    }

    public void DrawHalf(Canvas canvas, Paint paint, int ytop) {
        int y = ytop + 8 + 4;
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(0.0f, y, 10.0f, y + 4, paint);
        paint.setStyle(Paint.Style.STROKE);
    }

    public void DrawQuarter(Canvas canvas, Paint paint, int ytop) {
        paint.setStrokeCap(Paint.Cap.BUTT);
        int y = ytop + 4;
        paint.setStrokeWidth(1.0f);
        canvas.drawLine(2.0f, y, 6.0f, (y + 8) - 1, paint);
        paint.setStrokeWidth(3.0f);
        int y2 = ytop + 8 + 1;
        canvas.drawLine(5.0f, y2, 2.0f, y2 + 8, paint);
        paint.setStrokeWidth(1.0f);
        int y3 = (ytop + 16) - 1;
        canvas.drawLine(0.0f, y3, 9.0f, y3 + 8, paint);
        paint.setStrokeWidth(3.0f);
        canvas.drawLine(7, y3 + 6, 1.0f, y3 + 6, paint);
        paint.setStrokeWidth(1.0f);
        canvas.drawLine(0.0f, y3 + 5 + 1, 6.0f, y3 + 12, paint);
    }

    public void DrawEighth(Canvas canvas, Paint paint, int ytop) {
        int y = (ytop + 8) - 1;
        RectF rect = new RectF(0.0f, y + 1, 6.0f, ((y + 1) + 7) - 1);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawOval(rect, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.0f);
        canvas.drawLine(2.0f, (y + 7) - 1, 10.0f, y + 3, paint);
        canvas.drawLine(10.0f, y + 3, 5.0f, y + 16, paint);
    }

    public String toString() {
        return String.format("RestSymbol starttime=%1$s duration=%2$s width=%3$s", Integer.valueOf(this.starttime), this.duration, Integer.valueOf(this.width));
    }
}
