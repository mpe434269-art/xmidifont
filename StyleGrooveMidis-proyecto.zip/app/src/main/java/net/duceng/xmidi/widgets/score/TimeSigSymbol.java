package net.duceng.xmidi.widgets.score;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes6.dex */
public class TimeSigSymbol implements MusicSymbol {
    private static Bitmap[] images;
    private boolean candraw;
    private int denominator;
    private int numerator;
    private int width;

    public TimeSigSymbol(int numer, int denom) {
        if (images == null) {
            throw new RuntimeException("TimeSigSymbol.LoadImages(Context) will be call first!");
        }
        this.numerator = numer;
        this.denominator = denom;
        if (numer >= 0 && numer < images.length && images[numer] != null && denom >= 0 && denom < images.length && images[numer] != null) {
            this.candraw = true;
        } else {
            this.candraw = false;
        }
        this.width = getMinWidth();
    }

    public static void LoadImages(Context context) {
        if (images == null) {
            images = new Bitmap[13];
            Resources res = context.getResources();
            images[2] = BitmapFactory.decodeResource(res, R.drawable.num2);
            images[3] = BitmapFactory.decodeResource(res, R.drawable.num3);
            images[4] = BitmapFactory.decodeResource(res, R.drawable.num4);
            images[6] = BitmapFactory.decodeResource(res, R.drawable.num6);
            images[8] = BitmapFactory.decodeResource(res, R.drawable.num8);
            images[9] = BitmapFactory.decodeResource(res, R.drawable.num9);
            images[12] = BitmapFactory.decodeResource(res, R.drawable.num12);
        }
    }

    public static Bitmap textAsBitmap(String text, float textSize, int textColor) {
        Paint paint = new Paint();
        paint.setTextSize(textSize);
        paint.setColor(textColor);
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        paint.setTypeface(Typeface.MONOSPACE);
        float baseline = (int) ((-paint.ascent()) + 0.5f);
        Bitmap image = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(image);
        canvas.drawText(text, 0.0f, baseline, paint);
        return image;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getStartTime() {
        return -1;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getMinWidth() {
        if (this.candraw) {
            return ((images[2].getWidth() * 8) * 2) / images[2].getHeight();
        }
        return 0;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getWidth() {
        return this.width;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void setWidth(int value) {
        this.width = value;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getAboveStaff() {
        return 0;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getBelowStaff() {
        return 0;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void draw(Canvas canvas, Paint paint, int ytop) {
        if (this.candraw) {
            canvas.translate(getWidth() - getMinWidth(), 0.0f);
            Bitmap numer = images[this.numerator];
            Bitmap denom = images[this.denominator];
            int ytop2 = ytop - 1;
            int imgwidth = (numer.getWidth() * 16) / numer.getHeight();
            Rect src = new Rect(0, 0, numer.getWidth(), numer.getHeight());
            Rect dest = new Rect(0, ytop2, imgwidth, ytop2 + 16);
            canvas.drawBitmap(numer, src, dest, paint);
            Rect src2 = new Rect(0, 0, denom.getWidth(), denom.getHeight());
            Rect dest2 = new Rect(0, ytop2 + 16, imgwidth, ytop2 + 16 + 16);
            canvas.drawBitmap(denom, src2, dest2, paint);
            canvas.translate(-(getWidth() - getMinWidth()), 0.0f);
        }
    }

    public String toString() {
        return String.format("TimeSigSymbol numerator=%1$s denominator=%2$s", Integer.valueOf(this.numerator), Integer.valueOf(this.denominator));
    }
}
