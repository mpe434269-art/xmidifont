package net.duceng.xsynth;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;
import android.preference.PreferenceManager;
import java.util.ArrayList;
import net.duceng.midi.EventChannel;
import net.duceng.midi.StyFile;
import net.duceng.midi.StySection;

/**
 * "Estudio de sonido": ecualizador general, limitador y compresor de dinamica para los ritmos, con
 * adaptacion automatica a cada estilo.
 *
 * - Ecualizador: efecto Equalizer de Android sobre la mezcla global (puede no existir en algunos telefonos).
 * - Limitador / ganancia: LoudnessEnhancer de Android (lleva un limitador interno).
 * - Compresor: compresion de velocidades de las notas del ritmo (se hace en Synth.noteOn).
 * - Tono por canal: filtro (FILTERFC) del sintetizador segun el tipo de instrumento.
 */
public class SoundStudio {
    public static final String K_ADAPT = "ss_adapt";
    public static final String K_COMP = "ss_comp";
    public static final String K_LIMIT = "ss_limit";
    public static final String K_LIMIT_DB = "ss_limit_db";
    public static final String K_EQ_ON = "ss_eq_on";
    private static final String K_BAND = "ss_band";
    private static final int GEN_FILTERFC = 8;

    private static Equalizer eq;
    private static LoudnessEnhancer limiter;
    private static boolean eqFailed = false;
    private static boolean limFailed = false;

    private SoundStudio() {
    }

    public static SharedPreferences prefs(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c);
    }

    /** Crea los efectos y aplica lo guardado. */
    public static void init(Context c, Synth synth) {
        SharedPreferences p = prefs(c);
        try {
            if (eq == null && !eqFailed) {
                eq = new Equalizer(0, 0);
            }
        } catch (Throwable t) {
            eq = null;
            eqFailed = true;
        }
        try {
            if (limiter == null && !limFailed) {
                limiter = new LoudnessEnhancer(0);
            }
        } catch (Throwable t) {
            limiter = null;
            limFailed = true;
        }
        applyAll(c, synth);
    }

    public static void release() {
        try {
            if (eq != null) {
                eq.release();
            }
        } catch (Throwable ignored) {
        }
        try {
            if (limiter != null) {
                limiter.release();
            }
        } catch (Throwable ignored) {
        }
        eq = null;
        limiter = null;
        eqFailed = false;
        limFailed = false;
    }

    public static boolean eqAvailable() {
        return eq != null;
    }

    public static boolean limiterAvailable() {
        return limiter != null;
    }

    public static int bandCount() {
        try {
            return eq != null ? eq.getNumberOfBands() : 0;
        } catch (Throwable t) {
            return 0;
        }
    }

    /** Frecuencia central de la banda en Hz. */
    public static int bandHz(int band) {
        try {
            return eq.getCenterFreq((short) band) / 1000;
        } catch (Throwable t) {
            return 0;
        }
    }

    /** Rango del ecualizador en dB: {min, max}. */
    public static int[] rangeDb() {
        try {
            short[] r = eq.getBandLevelRange();
            return new int[]{r[0] / 100, r[1] / 100};
        } catch (Throwable t) {
            return new int[]{-12, 12};
        }
    }

    public static int bandDb(Context c, int band) {
        return prefs(c).getInt(K_BAND + band, defaultDb(band, Math.max(1, bandCount())));
    }

    /** Curva "Yamaha": graves firmes, medios algo recortados, brillo suave arriba. */
    private static int defaultDb(int band, int count) {
        double pos = count <= 1 ? 0.0 : band / (double) (count - 1);
        double[] curve = {6.0, 3.5, -2.0, 0.5, 3.0};
        double x = pos * (curve.length - 1);
        int i = (int) Math.floor(x);
        int j = Math.min(curve.length - 1, i + 1);
        double v = curve[i] + (curve[j] - curve[i]) * (x - i);
        return (int) Math.round(v);
    }

    public static void setBandDb(Context c, int band, int db) {
        prefs(c).edit().putInt(K_BAND + band, db).apply();
        applyEq(c);
    }

    /** Presets: 0 Yamaha, 1 Plano, 2 Graves+, 3 Brillante. */
    public static void preset(Context c, int which) {
        int n = Math.max(1, bandCount());
        double[][] curves = {
            {6.0, 3.5, -2.0, 0.5, 3.0},
            {0.0, 0.0, 0.0, 0.0, 0.0},
            {9.0, 5.0, 0.0, -1.0, 1.0},
            {1.0, 0.0, 1.0, 4.0, 6.0}};
        double[] cv = curves[Math.max(0, Math.min(3, which))];
        SharedPreferences.Editor ed = prefs(c).edit();
        for (int b = 0; b < n; b++) {
            double pos = n <= 1 ? 0.0 : b / (double) (n - 1);
            double x = pos * (cv.length - 1);
            int i = (int) Math.floor(x);
            int j = Math.min(cv.length - 1, i + 1);
            ed.putInt(K_BAND + b, (int) Math.round(cv[i] + (cv[j] - cv[i]) * (x - i)));
        }
        ed.apply();
        applyEq(c);
    }

    public static void applyEq(Context c) {
        if (eq == null) {
            return;
        }
        try {
            boolean on = prefs(c).getBoolean(K_EQ_ON, true);
            short[] r = eq.getBandLevelRange();
            for (int b = 0; b < eq.getNumberOfBands(); b++) {
                int mb = bandDb(c, b) * 100;
                mb = Math.max(r[0], Math.min(r[1], mb));
                eq.setBandLevel((short) b, (short) (on ? mb : 0));
            }
            eq.setEnabled(true);
        } catch (Throwable ignored) {
        }
    }

    public static void applyLimiter(Context c) {
        if (limiter == null) {
            return;
        }
        try {
            SharedPreferences p = prefs(c);
            boolean on = p.getBoolean(K_LIMIT, true);
            limiter.setTargetGain(on ? p.getInt(K_LIMIT_DB, 5) * 100 : 0);
            limiter.setEnabled(on);
        } catch (Throwable ignored) {
        }
    }

    public static void applyAll(Context c, Synth synth) {
        applyEq(c);
        applyLimiter(c);
        synth.setCompressor(prefs(c).getInt(K_COMP, 45) / 100.0f);
    }

    // ------------------------------------------------------------------
    //  Adaptacion automatica a cada estilo
    // ------------------------------------------------------------------

    /**
     * Analiza el estilo (velocidades de cada canal) y ajusta el compresor por canal y el tono (filtro) segun el
     * instrumento. Se llama al cargar un estilo, despues de aplicar su configuracion inicial.
     */
    public static void adaptToStyle(Context c, Synth synth, StyFile sf) {
        SharedPreferences p = prefs(c);
        float[] target = new float[16];
        float[] strength = new float[16];
        for (int i = 0; i < 16; i++) {
            target[i] = 92.0f;
            strength[i] = 1.0f;
        }
        if (sf != null && p.getBoolean(K_ADAPT, true)) {
            double[] sum = new double[16];
            double[] sq = new double[16];
            int[] cnt = new int[16];
            try {
                for (String name : sf.getSections().keySet()) {
                    if (!name.startsWith("Main")) {
                        continue;
                    }
                    StySection sec = sf.getSection(name);
                    for (int bar = 0; bar < 2; bar++) {
                        ArrayList<EventChannel> ev = sec.getEvents(bar);
                        if (ev == null) {
                            continue;
                        }
                        for (EventChannel e : ev) {
                            if (e.getType() == 9 && e.getValue2() > 0 && e.getChannel() >= 8) {
                                int ch = e.getChannel();
                                sum[ch] += e.getValue2();
                                sq[ch] += (double) e.getValue2() * e.getValue2();
                                cnt[ch]++;
                            }
                        }
                    }
                }
            } catch (Throwable ignored) {
            }
            for (int ch = 8; ch < 16; ch++) {
                if (cnt[ch] >= 4) {
                    double mean = sum[ch] / cnt[ch];
                    double sd = Math.sqrt(Math.max(0.0, sq[ch] / cnt[ch] - mean * mean));
                    target[ch] = (float) Math.max(60.0, Math.min(112.0, mean));
                    strength[ch] = (float) Math.max(0.5, Math.min(1.3, sd / 22.0));
                }
            }
        }
        synth.setCompressorTargets(target, strength);
        applyTone(c, synth, p.getBoolean(K_ADAPT, true));
    }

    static volatile boolean adaptOn = true;

    /** Desplazamiento del filtro (centesimas de tono) segun el instrumento. */
    static float toneFor(int program, boolean drums) {
        if (!adaptOn || drums) {
            return 0.0f;
        }
        if (program >= 32 && program <= 39) {
            return -150.0f;
        }
        if (program >= 48 && program <= 55) {
            return 150.0f; // cuerdas: un poco mas de aire, nada de oscurecerlas
        }
        if (program >= 24 && program <= 31) {
            return -100.0f;
        }
        return 0.0f;
    }

    public static void applyTone(Context c, Synth synth, boolean adapt) {
        adaptOn = adapt;
        for (int ch = 8; ch < 16; ch++) {
            boolean drums = ch == Synth.DRUMS_CHAN || synth.getBank(ch) == Synth.DRUMS_BANK;
            try {
                XSynth.midiPlayerSetGen(ch, GEN_FILTERFC, toneFor(synth.getPreset(ch), drums));
            } catch (Throwable ignored) {
            }
        }
    }
}
