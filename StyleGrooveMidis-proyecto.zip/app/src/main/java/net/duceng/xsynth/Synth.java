package net.duceng.xsynth;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.duceng.midi.EventChannel;
import net.duceng.midi.MetaTempo;
import net.duceng.midi.MetaTimeSignature;
import net.duceng.midi.MidiEvent;
import net.duceng.midi.MidiFile;
import net.duceng.midi.MidiTrack;
import net.duceng.midi.MidiUtil;
import net.duceng.midi.StySection;
import net.duceng.xmidi.Settings;
import net.duceng.xmidi.util.MyArray;
import net.duceng.xmidi.widgets.MusicScore;

/* JADX INFO: loaded from: classes2.dex */
public class Synth {
    private BeatListener beatListener;
    private ExecutorService mExecutor;
    private Runnable mRunnable;
    private StatusListener statusListener;
    public static String PATH_ROOT = Environment.getExternalStorageDirectory() + "/net.duceng/XMidi";
    public static String PATH_FONT = String.valueOf(PATH_ROOT) + "/sf2";
    public static String PATH_MIDI = String.valueOf(PATH_ROOT) + "/midi";
    public static String PATH_STY = String.valueOf(PATH_ROOT) + "/sty";
    public static String PATH_RECORD = String.valueOf(PATH_MIDI) + "/record";
    public static String DEFAULT_FONT = String.valueOf(PATH_FONT) + "/TimGM6mb.sf2";
    public static byte DRUMS_CHAN = (byte) 9;
    public static int DRUMS_BANK = 128;
    private static Synth instance = null;
    private static final double[] FAMILY_DB = {3.0d, 1.0d, -2.0d, 2.5d, 3.0d, -3.0d, -4.5d, -2.0d, -1.5d, -1.0d, -2.0d, -4.5d, -3.0d, 0.0d, 0.0d, -2.0d};
    private static final double[] ROLE_DB = {0.0d, 0.0d, 0.0d, 1.5d, 0.5d, -1.0d, -4.0d, -3.0d};
    private MyArray<File> sfonts = new MyArray<>();
    private boolean[] mutes = new boolean[16];
    private ArrayList<MyArray<Integer>> controls = new ArrayList<>();
    private boolean[] scores = null;
    private File file = null;
    private MidiFile midiFile = new MidiFile();
    private MidiTrack recordTrack = null;
    private byte recordChan = (byte) 0;
    private byte listenChan = (byte) 0;
    private volatile boolean playing = false;
    private volatile boolean pause = false;
    private volatile int runGen = 0;
    private boolean recording = false;
    private boolean beating = false;
    private byte beatVelocity = (byte) 75;
    private byte beatNote1 = (byte) 34;
    private byte beatNote2 = (byte) 33;
    private volatile long lastBeatMillis = 0L;
    private volatile int lastBeatTicks = 0;
    private boolean inited = false;
    private int bound = 0;
    private volatile boolean playLoopActive = false;
    private final int[] baseVolume = {100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100};
    private volatile boolean styleMix = false;
    private volatile float styleGain = 1.0f;

    public interface BeatListener {
        void onBeating(long j);
    }

    public interface StatusListener {
        void onStatusChanged(boolean z);
    }

    private int xmDefaultVolume(int i, int i2) {
        int preset;
        int i3 = 0;
        if (this.styleMix && i != DRUMS_CHAN && i >= 8 && getBank(i) != DRUMS_BANK && (preset = getPreset(i)) >= 0) {
            if (preset < 8) {
                i3 = -24;
            } else if (preset >= 32) {
                if (preset <= 39) {
                    i3 = 18;
                } else if (preset >= 40 && (preset <= 45 || (preset >= 48 && preset <= 51))) {
                    i3 = 12;
                }
            }
            int iRound = Math.round(i2 * ((i3 / 100.0f) + 1.0f));
            if (iRound > 127) {
                iRound = 127;
            }
            if (iRound < 0) {
                return 0;
            }
            return iRound;
        }
        return i2;
    }

    public void setFallbackByName(String name) {
        if (name != null && name.length() != 0) {
            File file = new File(PATH_FONT + "/" + name);
            if (this.sfonts.indexOfValue(file) < 0) {
                if (file.exists()) {
                    loadSFont(file);
                }
            }
            XSynth.midiPlayerSetFallback(name);
            return;
        }
        XSynth.midiPlayerSetFallback("");
    }

    public static boolean isInitialized(Context c) {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(c);
        return pref.getBoolean(Settings.SYNTH_INIT, false) && PATH_ROOT.equals(pref.getString("synth_init_root", "")) && new File(DEFAULT_FONT).exists();
    }

    public static boolean hasSharedStorageAccess(Context c) {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        }
        return Build.VERSION.SDK_INT < 23 || c.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0;
    }

    public static void configurePaths(Context c) {
        String root;
        if (hasSharedStorageAccess(c)) {
            root = Environment.getExternalStorageDirectory() + "/net.duceng/XMidi";
        } else {
            File base = c.getExternalFilesDir(null);
            if (base == null) {
                base = c.getFilesDir();
            }
            root = base.getAbsolutePath() + "/XMidi";
        }
        PATH_ROOT = root;
        PATH_FONT = String.valueOf(PATH_ROOT) + "/sf2";
        PATH_MIDI = String.valueOf(PATH_ROOT) + "/midi";
        PATH_STY = String.valueOf(PATH_ROOT) + "/sty";
        PATH_RECORD = String.valueOf(PATH_MIDI) + "/record";
        DEFAULT_FONT = String.valueOf(PATH_FONT) + "/TimGM6mb.sf2";
    }

    private Synth() {
        for (int i = 0; i < 16; i++) {
            this.controls.add(new MyArray<>());
        }
    }

    public static Synth getInstance() {
        if (instance == null) {
            instance = new Synth();
            instance.create();
        }
        instance.bound++;
        return instance;
    }

    public void freeInstance() {
        stop();
        this.bound--;
        if (this.bound <= 0) {
            release();
            instance = null;
        }
    }

    public boolean isInited() {
        return this.inited;
    }

    public void init(Context content) {
        if (!this.inited) {
            SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(content);
            boolean synth_init = isInitialized(content);
            if (!synth_init) {
                try {
                    File font = new File(DEFAULT_FONT);
                    if (!font.getParentFile().exists()) {
                        font.getParentFile().mkdirs();
                    }
                    font.createNewFile();
                    InputStream inputStream = content.getAssets().open(font.getName());
                    OutputStream outputStream = new FileOutputStream(font);
                    byte[] buff = new byte[16384];
                    while (true) {
                        int nLen = inputStream.read(buff);
                        if (nLen <= 0) {
                            break;
                        } else {
                            outputStream.write(buff, 0, nLen);
                        }
                    }
                    outputStream.close();
                    inputStream.close();
                    File dir = new File(PATH_RECORD);
                    if (!dir.exists()) {
                        dir.mkdirs();
                    }
                    init_dir(content, "midi", PATH_MIDI);
                    init_dir(content, "sty", PATH_STY);
                    SharedPreferences.Editor editor = pref.edit();
                    editor.putBoolean(Settings.SYNTH_INIT, true);
                    editor.putString("synth_init_root", PATH_ROOT);
                    editor.commit();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            int gain = pref.getInt(Settings.SYNTH_GAIN, 3);
            setGain(gain / 10.0f);
            int polyphony = pref.getInt(Settings.SYNTH_POLYPHONY, 128);
            setPolyphony(polyphony);
            this.beatVelocity = (byte) pref.getInt(Settings.SYNTH_BEATVEL, 75);
            this.beatNote1 = (byte) pref.getInt(Settings.SYNTH_BEATNOTE1, 34);
            this.beatNote2 = (byte) pref.getInt(Settings.SYNTH_BEATNOTE2, 33);
            String sfont_default = pref.getString(Settings.SYNTH_SFONT_DEFAULT, Settings.SYNTH_SFONT_DEFAULT_VAL);
            int iLoadSFont = loadSFont(new File(String.valueOf(PATH_FONT) + File.separator + sfont_default));
            setFallbackByName(pref.getString("synth_sfont_second", ""));
            for (int i = 0; i < 16; i++) {
                if (iLoadSFont > 0) {
                    setSFont(i, iLoadSFont);
                }
                if (i == 9) {
                    setPreset(i, 0);
                } else {
                    setPreset(i, getPreset(i));
                }
            }
            this.inited = true;
        }
    }

    private void init_dir(Context content, String src, String tag) throws IOException {
        File dir = new File(tag);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        String[] files = content.getAssets().list(src);
        byte[] b = new byte[1024];
        for (String file : files) {
            File of = new File(String.valueOf(tag) + File.separator + file);
            InputStream i = content.getAssets().open(String.valueOf(src) + File.separator + file);
            OutputStream o = new FileOutputStream(of);
            while (true) {
                int n = i.read(b);
                if (n <= 0) {
                    break;
                } else {
                    o.write(b, 0, n);
                }
            }
            o.close();
            i.close();
        }
    }

    private void create() {
        XSynth.createEngine();
        XSynth.createMidiPlayer();
    }

    private void release() {
        for (int i = 0; i < 150 && this.playLoopActive; i++) {
            try {
                Thread.sleep(10L);
            } catch (InterruptedException e) {
            }
        }
        XSynth.releaseMidiPlayer();
        XSynth.releaseEngine();
    }

    public int loadSFont(File f) {
        int sfont_id = -1;
        if (f.exists()) {
            sfont_id = XSynth.midiPlayerSFLoad(f.getAbsolutePath(), 0);
            if (sfont_id > 0) {
                this.sfonts.put(sfont_id, f);
            }
            Log.i("Synth", "Load SoundFont " + f.getName() + " return: " + sfont_id + " Total: " + XSynth.midiPlayerSFCount());
        }
        return sfont_id;
    }

    public void unloadSFont(File f) {
        int index = this.sfonts.indexOfValue(f);
        if (index >= 0) {
            XSynth.midiPlayerSFUnload(this.sfonts.keyAt(index), 0);
            this.sfonts.removeAt(index);
            Log.i("Synth", "Unload SoundFont " + f.getName() + " Total: " + XSynth.midiPlayerSFCount());
        }
    }

    public MyArray<File> getSFonts() {
        return this.sfonts;
    }

    public File getFontFile(int chan) {
        int sfont_id = getSFont(chan);
        return (sfont_id <= 0 || this.sfonts.indexOfKey(sfont_id) < 0) ? this.sfonts.valueAt(0) : this.sfonts.get(sfont_id);
    }

    public float getGain() {
        return XSynth.midiPlayerGetGain();
    }

    public void setGain(float gain) {
        XSynth.midiPlayerSetGain(gain);
    }

    public float getPolyphony() {
        return XSynth.midiPlayerGetPolyphony();
    }

    public void setPolyphony(int polyphony) {
        XSynth.midiPlayerSetPolyphony(polyphony);
    }

    public void setSFont(int chan, int sfont_id) {
        XSynth.midiPlayerSFontSelect(chan, sfont_id);
    }

    public void setBank(int chan, int bank) {
        XSynth.midiPlayerBankSelect(chan, bank);
    }

    public void setPreset(int chan, int val) {
        XSynth.midiPlayerProgramChange(chan, val);
        if (this.styleMix && chan >= 8) {
            refreshVolume(chan);
        }
    }

    public void setProgram(int chan, int sfont_id, int bank_num, int preset_num) {
        XSynth.midiPlayerProgramSelect(chan, sfont_id, bank_num, preset_num);
        if (this.styleMix && chan >= 8) {
            refreshVolume(chan);
        }
    }

    public int getSFont(int chan) {
        return XSynth.midiPlayerGetSFont(chan);
    }

    public int getBank(int chan) {
        return XSynth.midiPlayerGetBank(chan);
    }

    public int getPreset(int chan) {
        return XSynth.midiPlayerGetPreset(chan);
    }

    public void setCC(int chan, int ctrl, int val) {
        XSynth.midiPlayerCC(chan, ctrl, val);
    }

    public int getCC(int chan, int ctrl) {
        return XSynth.midiPlayerGetCC(chan, ctrl);
    }

    public void setPitchBend(int chan, int val) {
        XSynth.midiPlayerPitchBend(chan, val);
    }

    public int getPitchBend(int chan) {
        return XSynth.midiPlayerGetPitchBend(chan);
    }

    public void setVolume(int chan, int val) {
        XSynth.midiPlayerCC(chan, XSynth.VOLUME_MSB, val);
    }

    public int getVolume(int chan) {
        return XSynth.midiPlayerGetCC(chan, XSynth.VOLUME_MSB);
    }

    public void setPan(int chan, int val) {
        XSynth.midiPlayerCC(chan, XSynth.PAN_MSB, val);
    }

    public int getPan(int chan) {
        return XSynth.midiPlayerGetCC(chan, XSynth.PAN_MSB);
    }

    public void setSustain(int chan, int val) {
        XSynth.midiPlayerCC(chan, XSynth.SUSTAIN_SWITCH, val);
    }

    public int getSustain(int chan) {
        return XSynth.midiPlayerGetCC(chan, XSynth.SUSTAIN_SWITCH);
    }

    public void setReverb(int chan, int val) {
        XSynth.midiPlayerCC(chan, XSynth.EFFECTS_DEPTH1, val);
    }

    public int getReverb(int chan) {
        return XSynth.midiPlayerGetCC(chan, XSynth.EFFECTS_DEPTH1);
    }

    public void setChorus(int chan, int val) {
        XSynth.midiPlayerCC(chan, XSynth.EFFECTS_DEPTH3, val);
    }

    public int getChorus(int chan) {
        return XSynth.midiPlayerGetCC(chan, XSynth.EFFECTS_DEPTH3);
    }

    public boolean isMute(int chan) {
        return this.mutes[chan];
    }

    public void setMute(int chan, boolean val) {
        this.mutes[chan] = val;
    }

    public MyArray<Integer> getControls(int chan) {
        return this.controls.get(chan);
    }

    public int getControl(int chan, int ctrl) {
        if (this.controls.get(chan).indexOfKey(ctrl) >= 0) {
            return this.controls.get(chan).get(ctrl).intValue();
        }
        return -1;
    }

    public void setControl(int chan, int ctrl, int val) {
        this.controls.get(chan).put(ctrl, Integer.valueOf(val));
    }

    public boolean isScore(int t) {
        return this.scores[t];
    }

    public void setScore(int t, boolean val) {
        this.scores[t] = val;
    }

    public boolean[] getScores() {
        return this.scores;
    }

    public void silenceChannels(int from, int to) {
        for (int chan = from; chan <= to && chan < 16; chan++) {
            XSynth.midiPlayerCC(chan, XSynth.ALL_NOTES_OFF, 0);
        }
    }

    public void allNotesoff() {
        for (int chan = 0; chan < XSynth.midiPlayerMidiChannels(); chan++) {
            XSynth.midiPlayerCC(chan, XSynth.ALL_SOUND_OFF, 0);
        }
    }

    private void noteOn(int chan, int key, int vel) {
        if (vel == 0) {
            noteOff(chan, key);
        } else {
            XSynth.midiPlayerNoteon(chan, key, vel);
        }
    }

    private void noteOff(int chan, int key) {
        XSynth.midiPlayerNoteoff(chan, key);
    }

    private static int tune(int ctrl, int val) {
        if (ctrl == XSynth.EFFECTS_DEPTH1) {
            return (val * 6) / 10;
        }
        if (ctrl == XSynth.EFFECTS_DEPTH3) {
            return (val * 4) / 10;
        }
        if (ctrl == XSynth.SOUND_CTRL5) {
            return Math.max(val, 64);
        }
        if (ctrl == XSynth.SOUND_CTRL3) {
            return Math.max(val, 64);
        }
        return val;
    }

    public void refreshVolume(int chan) {
        if (chan >= 0 && chan < 16) {
            controlChange(chan, XSynth.VOLUME_MSB, this.baseVolume[chan]);
        }
    }

    public void setStyleMix(boolean on) {
        this.styleMix = on;
    }

    /** Master volume of the automatic accompaniment (channels 8-15). 1.0 = unchanged. */
    public float getStyleGain() {
        return this.styleGain;
    }

    public void setStyleGain(float gain) {
        this.styleGain = Math.max(0.0f, Math.min(1.5f, gain));
        for (int ch = 8; ch < 16; ch++) {
            refreshVolume(ch);
        }
    }

    private static double familyFactor(int chan, int program) {
        int fam = Math.max(0, Math.min(127, program)) / 8;
        double db = FAMILY_DB[fam];
        if (program >= 48 && program <= 51) {
            db = -4.5d;
        } else if (program >= 52 && program <= 55) {
            db = -3.0d;
        }
        if (chan >= 8 && chan <= 15) {
            db += ROLE_DB[chan - 8];
        }
        return Math.pow(10.0d, db / 40.0d);
    }

    private int trimVolume(int chan, int val) {
        if (chan == DRUMS_CHAN || getBank(chan) == DRUMS_BANK) {
            return val;
        }
        int out = (int) Math.round(((double) val) * familyFactor(chan, getPreset(chan)));
        return Math.max(1, Math.min(127, out));
    }

    private void controlChange(int chan, int ctrl, int val) {
        int val2 = tune(ctrl, val);
        if (ctrl == XSynth.VOLUME_MSB && chan >= 0 && chan < 16) {
            this.baseVolume[chan] = val2;
            if (this.styleMix && chan >= 8) {
                val2 = trimVolume(chan, val2);
            }
            if (this.controls.get(chan).indexOfKey(ctrl) >= 0) {
                int pct = this.controls.get(chan).get(ctrl).intValue();
                val2 = Math.round(val2 * ((pct / 100.0f) + 1.0f));
                if (val2 > 127) {
                    val2 = 127;
                }
                if (val2 < 0) {
                    val2 = 0;
                }
            } else {
                val2 = xmDefaultVolume(chan, val2);
            }
            if (this.styleMix && chan >= 8) {
                val2 = Math.max(0, Math.min(127, Math.round(val2 * this.styleGain)));
            }
        } else {
            int v = getControl(chan, ctrl);
            if (v >= 0) {
                val2 = v;
            }
        }
        if (this.styleMix && chan >= 8 && ctrl == XSynth.EFFECTS_DEPTH1) {
            int pr = getPreset(chan);
            if (pr >= 0 && pr < 8 && val2 < 76) {
                val2 = 76;
            }
        }
        XSynth.midiPlayerCC(chan, ctrl, val2);
    }

    private void programChange(int chan, int program) {
        XSynth.midiPlayerProgramChange(chan, program);
        if (this.styleMix && chan >= 8 && chan != DRUMS_CHAN && getBank(chan) != DRUMS_BANK) {
            // Si el banco pedido no existe en el soundfont, el canal conserva el instrumento anterior
            // (p.ej. un violin de otro ritmo). Reintentar con el banco GM 0 del mismo programa.
            if (getPreset(chan) != program) {
                XSynth.midiPlayerCC(chan, XSynth.BANK_SELECT_MSB, 0);
                XSynth.midiPlayerCC(chan, XSynth.BANK_SELECT_LSB, 0);
                XSynth.midiPlayerProgramChange(chan, program);
            }
            applyPianoReverb(chan);
        }
        if (this.styleMix && chan >= 8) {
            refreshVolume(chan);
        }
    }

    /** Los pianos de los estilos llevan un poco de reverb para que no suenen secos. */
    private void applyPianoReverb(int chan) {
        int pr = getPreset(chan);
        if (pr >= 0 && pr < 8 && XSynth.midiPlayerGetCC(chan, XSynth.EFFECTS_DEPTH1) < 76) {
            XSynth.midiPlayerCC(chan, XSynth.EFFECTS_DEPTH1, 76);
        }
    }

    private void pitchBend(int chan, int val) {
        XSynth.midiPlayerPitchBend(chan, val);
    }

    public int getRecordChan() {
        return this.recordChan;
    }

    public void setRecordChan(byte chan) {
        this.recordChan = chan;
    }

    public int getListenChan() {
        return this.listenChan;
    }

    public void setListenChan(byte chan) {
        this.listenChan = chan;
    }

    public void keyOn(int chan, int key, int vel) {
        if (chan < 0 || chan > 15 || key < 0 || key > 127) {
            return;
        }
        noteOn(chan, key, Math.max(1, Math.min(127, vel)));
    }

    public void keyOff(int chan, int key) {
        if (chan < 0 || chan > 15 || key < 0 || key > 127) {
            return;
        }
        noteOff(chan, key);
    }

    public void keysOff(int chan) {
        if (chan >= 0 && chan < 16) {
            XSynth.midiPlayerCC(chan, XSynth.ALL_NOTES_OFF, 0);
        }
    }

    public int getBaseVolume(int chan) {
        if (chan < 0 || chan >= 16) {
            return 100;
        }
        return this.baseVolume[chan];
    }

    public void setKeyVolume(int chan, int v) {
        if (chan >= 0 && chan < 16) {
            this.baseVolume[chan] = Math.max(0, Math.min(127, v));
            refreshVolume(chan);
        }
    }

    public void noteOn(byte key, byte vel) {
        if (vel == 0) {
            noteOff(key);
            return;
        }
        noteOn(this.recordChan, key, vel);
        if (this.recording && this.playing) {
            if (this.recordTrack == null) {
                this.recordTrack = new MidiTrack();
            }
            int millisecondsPerTick = (this.midiFile.getTempo().getMpqn() / 1000) / this.midiFile.getResolution();
            int tick = (int) ((System.currentTimeMillis() - this.lastBeatMillis) / ((long) millisecondsPerTick));
            MidiEvent e = new EventChannel(this.lastBeatTicks + tick, (byte) 9, this.recordChan, key, vel);
            this.recordTrack.insert(e);
        }
    }

    public void noteOff(byte key) {
        noteOff(this.recordChan, key);
        if (this.recording && this.playing) {
            if (this.recordTrack == null) {
                this.recordTrack = new MidiTrack();
            }
            int millisecondsPerTick = (this.midiFile.getTempo().getMpqn() / 1000) / this.midiFile.getResolution();
            int tick = (int) ((System.currentTimeMillis() - this.lastBeatMillis) / ((long) millisecondsPerTick));
            MidiEvent e = new EventChannel(this.lastBeatTicks + tick, (byte) 8, this.recordChan, key, (byte) 0);
            this.recordTrack.insert(e);
        }
    }

    public void execEvent(MidiEvent event) {
        if (event instanceof EventChannel) {
            EventChannel e = (EventChannel) event;
            switch (e.getType()) {
                case 8:
                    noteOff(e.getChannel(), e.getValue1());
                    break;
                case 9:
                    noteOn(e.getChannel(), e.getValue1(), e.getValue2());
                    break;
                case 11:
                    controlChange(e.getChannel(), e.getValue1(), e.getValue2());
                    break;
                case 12:
                    programChange(e.getChannel(), e.getValue1());
                    break;
                case MusicScore.TitleHeight /* 14 */:
                    pitchBend(e.getChannel(), ((e.getValue2() & 127) << 7) | (e.getValue1() & 127));
                    break;
            }
            if (this.recording && this.playing) {
                if (this.recordTrack == null) {
                    this.recordTrack = new MidiTrack();
                }
                int millisecondsPerTick = (this.midiFile.getTempo().getMpqn() / 1000) / this.midiFile.getResolution();
                int tick = (int) ((System.currentTimeMillis() - this.lastBeatMillis) / ((long) millisecondsPerTick));
                MidiEvent ne = new EventChannel(this.lastBeatTicks + tick, e.getType(), e.getChannel(), e.getValue1(), e.getValue2());
                this.recordTrack.insert(ne);
            }
        }
    }

    public int getNumerator() {
        return this.midiFile.getTimeSignature().getNumerator();
    }

    public int getResolution() {
        return this.midiFile.getResolution();
    }

    public MidiTrack getRecordTrack() {
        return this.recordTrack;
    }

    public MidiFile getMidiFile() {
        return this.midiFile;
    }

    public File getFile() {
        return this.file;
    }

    public void setFile(File f) {
        stop();
        this.file = f;
        if (this.file == null) {
            this.midiFile = new MidiFile();
            return;
        }
        try {
            this.midiFile = new MidiFile(new FileInputStream(this.file));
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        this.scores = new boolean[this.midiFile.getCount()];
        int prog = -1;
        for (int c = 0; c < this.midiFile.getCount(); c++) {
            MidiTrack t = this.midiFile.getTracks().get(c);
            this.scores[c] = false;
            if (t.getChannel() >= 0) {
                if (prog == -1) {
                    this.scores[c] = true;
                    prog = t.getProgram();
                } else if (t.getProgram() == prog) {
                    this.scores[c] = true;
                }
            }
        }
        this.styleMix = false;
        applyFileSetup();
        System.gc();
    }

    public void clearOverrides(int from, int to) {
        for (int ch = from; ch <= to && ch < 16; ch++) {
            this.controls.get(ch).clear();
        }
    }

    public void resetChannels(int from, int to) {
        for (int ch = from; ch <= to && ch < 16; ch++) {
            XSynth.midiPlayerCC(ch, XSynth.ALL_CTRL_OFF, 0);
            this.baseVolume[ch] = 100;
            XSynth.midiPlayerCC(ch, XSynth.VOLUME_MSB, 100);
            XSynth.midiPlayerCC(ch, XSynth.PAN_MSB, 64);
            XSynth.midiPlayerCC(ch, XSynth.EXPRESSION_MSB, 127);
            XSynth.midiPlayerCC(ch, XSynth.EFFECTS_DEPTH1, 40);
            XSynth.midiPlayerCC(ch, XSynth.EFFECTS_DEPTH3, 0);
            XSynth.midiPlayerPitchBend(ch, 8192);
            if (ch != DRUMS_CHAN) {
                XSynth.midiPlayerBankSelect(ch, 0);
            }
            XSynth.midiPlayerProgramChange(ch, 0);
        }
    }

    private void applyFileSetup() {
        resetChannels(0, 15);
        clearOverrides(0, 15);
        ArrayList<ArrayList<EventChannel>> perChan = new ArrayList<>();
        for (int i = 0; i < 16; i++) {
            perChan.add(new ArrayList<>());
        }
        boolean[] started = new boolean[16];
        TreeSet<MidiEvent> all = new TreeSet<>();
        for (MidiTrack t : this.midiFile.getTracks()) {
            all.addAll(t.getEvents());
        }
        for (MidiEvent ev : all) {
            if (ev instanceof EventChannel) {
                EventChannel e = (EventChannel) ev;
                int ch = e.getChannel() & StySection.Phrase2;
                if (e.getType() == 9 && e.getValue2() > 0) {
                    started[ch] = true;
                }
                if (!started[ch]) {
                    perChan.get(ch).add(e);
                }
            }
        }
        for (int ch2 = 0; ch2 < 16; ch2++) {
            ArrayList<EventChannel> l = perChan.get(ch2);
            for (EventChannel e2 : l) {
                if (e2.getType() == 11 && (e2.getValue1() == XSynth.BANK_SELECT_MSB || e2.getValue1() == XSynth.BANK_SELECT_LSB)) {
                    if (ch2 != DRUMS_CHAN) {
                        XSynth.midiPlayerCC(ch2, e2.getValue1(), e2.getValue2());
                    }
                }
            }
            for (EventChannel e3 : l) {
                if (e3.getType() == 12) {
                    if (ch2 == DRUMS_CHAN) {
                        XSynth.midiPlayerProgramChange(ch2, (e3.getValue1() / 8) * 8);
                    } else {
                        XSynth.midiPlayerProgramChange(ch2, e3.getValue1());
                    }
                }
            }
            for (EventChannel e4 : l) {
                if (e4.getType() == 11 && e4.getValue1() != XSynth.BANK_SELECT_MSB && e4.getValue1() != XSynth.BANK_SELECT_LSB) {
                    controlChange(ch2, e4.getValue1(), e4.getValue2());
                } else if (e4.getType() == 14) {
                    XSynth.midiPlayerPitchBend(ch2, ((e4.getValue2() & 127) << 7) | (e4.getValue1() & 127));
                }
            }
        }
    }

    public boolean isPlaying() {
        return this.playing;
    }

    public boolean isPause() {
        return this.pause;
    }

    public boolean isBeating() {
        return this.beating;
    }

    public boolean isRecording() {
        return this.recording;
    }

    public void play() {
        if (this.mExecutor == null) {
            this.mExecutor = Executors.newSingleThreadExecutor();
        }
        this.playing = true;
        this.pause = false;
        final int gen = this.runGen + 1;
        this.runGen = gen;
        this.mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                Synth.this.playing(gen);
            }
        });
    }

    public void pause() {
        this.playing = false;
        this.pause = true;
    }

    public void stop() {
        this.playing = false;
        this.pause = false;
        this.lastBeatTicks = 0;
    }

    public void setBeating(boolean b) {
        this.beating = b;
    }

    public void setRecording(boolean r) {
        this.recording = r;
        if (this.recording) {
            this.recordTrack = new MidiTrack();
            this.recordTrack.setChannel(this.recordChan);
            this.recordTrack.setProgram((byte) getPreset(this.recordChan));
        }
    }

    public void playing() {
        playing(this.runGen);
    }

    private void playing(int gen) {
        this.playLoopActive = true;
        try {
            playingInner(gen);
        } catch (RuntimeException e) {
            Log.i("Synth", "Error reproduciendo: " + e);
        } finally {
            this.playLoopActive = false;
        }
    }

    private boolean alive(int gen) {
        return this.playing && gen == this.runGen;
    }

    /** Espera (en trozos cortos para poder parar al instante). false si se detuvo la reproduccion. */
    private boolean sleepUntil(long targetMs, int gen) {
        while (alive(gen)) {
            long d = targetMs - System.currentTimeMillis();
            if (d <= 0) {
                return true;
            }
            try {
                Thread.sleep(Math.min(d, 15L));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return false;
    }

    private static int eventPriority(MidiEvent e) {
        if (e instanceof EventChannel) {
            EventChannel c = (EventChannel) e;
            if (c.getType() == 8 || (c.getType() == 9 && c.getValue2() == 0)) {
                return 1;
            }
            if (c.getType() == 9 && c.getValue2() > 0) {
                return 2;
            }
        }
        return 0;
    }

    private void playingInner(int gen) {
        if (this.statusListener != null) {
            this.statusListener.onStatusChanged(true);
        }
        MetaTempo tempo = this.midiFile.getTempo();
        MetaTimeSignature ts = this.midiFile.getTimeSignature();
        final int res = Math.max(1, this.midiFile.getResolution());
        int beatTicks = res * 4;
        for (int k = 0; k < ts.getDenominator() && beatTicks > 1; k++) {
            beatTicks /= 2;
        }
        final int perBar = Math.max(1, (int) ts.getNumerator());

        ArrayList<MidiEvent> list = new ArrayList<>();
        for (MidiTrack t : this.midiFile.getTracks()) {
            list.addAll(t.getEvents());
        }
        if (this.recordTrack != null) {
            list.addAll(this.recordTrack.getEvents());
        }
        boolean metronomeOnly = list.isEmpty();
        int lastTick = 0;
        for (MidiEvent e : list) {
            lastTick = Math.max(lastTick, e.getTick());
        }
        // marcas de pulso (metronomo y avance del cursor de la partitura)
        int idx = 0;
        int endTick;
        if (metronomeOnly) {
            for (int i = 0; i < perBar; i++) {
                list.add(new EventChannel(i * beatTicks, (byte) 9, DRUMS_CHAN, i == 0 ? this.beatNote1 : this.beatNote2, (byte) -1));
            }
            endTick = perBar * beatTicks;
        } else {
            int tick = 0;
            while (true) {
                list.add(new EventChannel(tick, (byte) 9, DRUMS_CHAN, idx % perBar == 0 ? this.beatNote1 : this.beatNote2, (byte) -1));
                idx++;
                if (tick > lastTick) {
                    break;
                }
                tick += beatTicks;
            }
            endTick = tick + beatTicks;
        }
        Collections.sort(list, new Comparator<MidiEvent>() {
            @Override
            public int compare(MidiEvent a, MidiEvent b) {
                int ta = a.getTick();
                int tb = b.getTick();
                if (ta != tb) {
                    return ta < tb ? -1 : 1;
                }
                return eventPriority(a) - eventPriority(b);
            }
        });

        if (this.recording) {
            long beatMs = Math.max(1, tempo.getMpqn() / 1000);
            for (int i = 0; i < perBar && alive(gen); i++) {
                noteOn(DRUMS_CHAN, this.beatNote2, this.beatVelocity);
                if (!sleepUntil(System.currentTimeMillis() + beatMs, gen)) {
                    break;
                }
            }
        }

        final int baseMpqn = Math.max(1, tempo.getMpqn());
        boolean first = true;
        while (alive(gen)) {
            final int startTick = first ? this.lastBeatTicks : 0;
            first = false;
            double curMpqn = baseMpqn;
            double wall = System.currentTimeMillis();
            int prevTick = startTick;
            for (MidiEvent event : list) {
                if (!alive(gen)) {
                    break;
                }
                int tk = event.getTick();
                if (tk < startTick) {
                    // al reanudar: solo se reaplica el estado (programas / controles), sin notas
                    if (event instanceof MetaTempo) {
                        int m0 = ((MetaTempo) event).getMpqn();
                        if (m0 > 0) {
                            curMpqn = m0;
                        }
                    } else if (event instanceof EventChannel) {
                        EventChannel c = (EventChannel) event;
                        int ch = c.getChannel() & 15;
                        if (c.getType() == 12) {
                            programChange(ch, c.getValue1());
                        } else if (c.getType() == 11) {
                            controlChange(ch, c.getValue1(), c.getValue2());
                        } else if (c.getType() == 14) {
                            pitchBend(ch, ((c.getValue2() & 127) << 7) | (c.getValue1() & 127));
                        }
                    }
                    continue;
                }
                if (tk > prevTick) {
                    double factor = ((double) tempo.getMpqn()) / ((double) baseMpqn);
                    wall += (((double) (tk - prevTick)) * curMpqn * factor) / 1000.0d / ((double) res);
                    prevTick = tk;
                    long now = System.currentTimeMillis();
                    if (wall < now - 250) {
                        wall = now; // nos quedamos atras: no intentar recuperar de golpe
                    }
                    if (!sleepUntil((long) wall, gen)) {
                        break;
                    }
                }
                if (event instanceof MetaTempo) {
                    int m = ((MetaTempo) event).getMpqn();
                    if (m > 0) {
                        curMpqn = m;
                    }
                    continue;
                }
                if (!(event instanceof EventChannel)) {
                    continue;
                }
                EventChannel ec = (EventChannel) event;
                int chan = ec.getChannel() & 15;
                if (this.mutes[chan] && ec.getValue2() != -1) {
                    continue;
                }
                switch (ec.getType()) {
                    case 8:
                        noteOff(chan, ec.getValue1());
                        break;
                    case 9:
                        if (ec.getValue2() == -1) {
                            if (this.beating) {
                                noteOn(chan, ec.getValue1(), this.beatVelocity);
                            }
                            this.lastBeatMillis = System.currentTimeMillis();
                            this.lastBeatTicks = ec.getTick();
                            BeatListener bl = this.beatListener;
                            if (bl != null) {
                                bl.onBeating(ec.getTick());
                            }
                        } else {
                            noteOn(chan, ec.getValue1(), ec.getValue2());
                        }
                        break;
                    case 11:
                        controlChange(chan, ec.getValue1(), ec.getValue2());
                        break;
                    case 12:
                        programChange(chan, ec.getValue1());
                        break;
                    case 14:
                        pitchBend(chan, ((ec.getValue2() & 127) << 7) | (ec.getValue1() & 127));
                        break;
                    default:
                        break;
                }
            }
            if (!alive(gen)) {
                break;
            }
            // fin del recorrido: esperar el ultimo pulso
            double factor2 = ((double) tempo.getMpqn()) / ((double) baseMpqn);
            wall += (((double) Math.max(0, endTick - prevTick)) * curMpqn * factor2) / 1000.0d / ((double) res);
            if (!sleepUntil((long) wall, gen)) {
                break;
            }
            if (metronomeOnly) {
                this.lastBeatTicks = 0;
                continue;
            }
            if (this.recording) {
                // seguir con el metronomo mientras se graba, hasta que se pare
                long beatMs2 = Math.max(1, tempo.getMpqn() / 1000);
                long next = System.currentTimeMillis();
                while (alive(gen)) {
                    if (this.beating) {
                        noteOn(DRUMS_CHAN, this.beatNote2, this.beatVelocity);
                    }
                    this.lastBeatMillis = System.currentTimeMillis();
                    this.lastBeatTicks += beatTicks;
                    next += beatMs2;
                    if (!sleepUntil(next, gen)) {
                        break;
                    }
                }
            } else if (gen == this.runGen) {
                // la cancion termino sola
                this.playing = false;
                this.pause = false;
            }
            break;
        }
        // limpieza (solo si seguimos siendo la ejecucion vigente)
        boolean current = gen == this.runGen;
        if (current && !this.pause) {
            this.lastBeatTicks = 0;
        }
        allNotesoff();
        if (current) {
            this.lastBeatMillis = 0L;
            if (this.statusListener != null) {
                this.statusListener.onStatusChanged(false);
            }
        }
    }

    public float getBeatPercent() {
        int interval = 60000 / this.midiFile.getTempo().getBpm();
        float elapsed = System.currentTimeMillis() - this.lastBeatMillis;
        return elapsed / interval;
    }

    public byte getBeatVelocity() {
        return this.beatVelocity;
    }

    public void setBeatVelocity(byte beatVelocity) {
        this.beatVelocity = beatVelocity;
    }

    public byte getBeatNote1() {
        return this.beatNote1;
    }

    public void setBeatNote1(byte beatNote1) {
        this.beatNote1 = beatNote1;
    }

    public byte getBeatNote2() {
        return this.beatNote2;
    }

    public void setBeatNote2(byte beatNote2) {
        this.beatNote2 = beatNote2;
    }

    public int getLastBeatTicks() {
        return this.lastBeatTicks;
    }

    public void setBeatListener(BeatListener l) {
        this.beatListener = l;
    }

    public void setStatusListener(StatusListener l) {
        this.statusListener = l;
    }
}
