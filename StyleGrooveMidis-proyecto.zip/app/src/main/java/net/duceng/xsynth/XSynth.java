package net.duceng.xsynth;

/* JADX INFO: loaded from: classes2.dex */
public class XSynth {
    public static byte ALL_CTRL_OFF;
    public static byte ALL_NOTES_OFF;
    public static byte ALL_SOUND_OFF;
    public static byte BALANCE_LSB;
    public static byte BALANCE_MSB;
    public static byte BANK_SELECT_LSB;
    public static byte BANK_SELECT_MSB;
    public static byte BREATH_LSB;
    public static byte BREATH_MSB;
    public static byte DATA_ENTRY_DECR;
    public static byte DATA_ENTRY_INCR;
    public static byte DATA_ENTRY_LSB;
    public static byte DATA_ENTRY_MSB;
    public static byte EFFECTS1_LSB;
    public static byte EFFECTS1_MSB;
    public static byte EFFECTS2_LSB;
    public static byte EFFECTS2_MSB;
    public static byte EFFECTS_DEPTH1;
    public static byte EFFECTS_DEPTH2;
    public static byte EFFECTS_DEPTH3;
    public static byte EFFECTS_DEPTH4;
    public static byte EFFECTS_DEPTH5;
    public static byte EXPRESSION_LSB;
    public static byte EXPRESSION_MSB;
    public static byte FOOT_LSB;
    public static byte FOOT_MSB;
    public static byte GPC1_LSB;
    public static byte GPC1_MSB;
    public static byte GPC2_LSB;
    public static byte GPC2_MSB;
    public static byte GPC3_LSB;
    public static byte GPC3_MSB;
    public static byte GPC4_LSB;
    public static byte GPC4_MSB;
    public static byte GPC5;
    public static byte GPC6;
    public static byte GPC7;
    public static byte GPC8;
    public static byte HOLD2_SWITCH;
    public static byte LEGATO_SWITCH;
    public static byte LOCAL_CONTROL;
    public static byte MODULATION_MSB;
    public static byte MODULATION_WHEEL_LSB;
    public static byte NRPN_LSB;
    public static byte NRPN_MSB;
    public static byte OMNI_OFF;
    public static byte OMNI_ON;
    public static byte PAN_LSB;
    public static byte PAN_MSB;
    public static byte POLY_OFF;
    public static byte POLY_ON;
    public static byte PORTAMENTO_CTRL;
    public static byte PORTAMENTO_SWITCH;
    public static byte PORTAMENTO_TIME_LSB;
    public static byte PORTAMENTO_TIME_MSB;
    public static byte RPN_LSB;
    public static byte RPN_MSB;
    public static byte SOFT_PEDAL_SWITCH;
    public static byte SOSTENUTO_SWITCH;
    public static byte SOUND_CTRL1;
    public static byte SOUND_CTRL10;
    public static byte SOUND_CTRL2;
    public static byte SOUND_CTRL3;
    public static byte SOUND_CTRL4;
    public static byte SOUND_CTRL5;
    public static byte SOUND_CTRL6;
    public static byte SOUND_CTRL7;
    public static byte SOUND_CTRL8;
    public static byte SOUND_CTRL9;
    public static byte SUSTAIN_SWITCH;
    public static byte VOLUME_LSB;
    public static byte VOLUME_MSB;

    public static byte[] adaptSafe(byte[] bArr) {
        try {
            byte[] bArrAdaptStyle = adaptStyle(bArr);
            return bArrAdaptStyle != null ? bArrAdaptStyle : bArr;
        } catch (Throwable th) {
            return bArr;
        }
    }

    public static native byte[] adaptStyle(byte[] bArr);

    public static native void createEngine();

    public static native void createMidiPlayer();

    public static native void midiPlayerBankSelect(int i, int i2);

    public static native void midiPlayerCC(int i, int i2, int i3);

    public static native void midiPlayerChorus(int i, double d, double d2, double d3, int i2);

    public static native void midiPlayerChorusOn(int i);

    public static native int midiPlayerGetBank(int i);

    public static native int midiPlayerGetCC(int i, int i2);

    public static native float midiPlayerGetGain();

    public static native float midiPlayerGetGen(int i, int i2);

    public static native int midiPlayerGetPitchBend(int i);

    public static native int midiPlayerGetPitchWhellSens(int i);

    public static native int midiPlayerGetPolyphony();

    public static native int midiPlayerGetPreset(int i);

    public static native int midiPlayerGetSFont(int i);

    public static native int midiPlayerMidiChannels();

    public static native void midiPlayerNoteoff(int i, int i2);

    public static native void midiPlayerNoteon(int i, int i2, int i3);

    public static native void midiPlayerPitchBend(int i, int i2);

    public static native void midiPlayerPitchWhellSens(int i, int i2);

    public static native void midiPlayerProgramChange(int i, int i2);

    public static native void midiPlayerProgramReset();

    public static native void midiPlayerProgramSelect(int i, int i2, int i3, int i4);

    public static native void midiPlayerReverb(double d, double d2, double d3, double d4);

    public static native void midiPlayerReverbOn(int i);

    public static native int midiPlayerSFCount();

    public static native int midiPlayerSFLoad(String str, int i);

    public static native int midiPlayerSFReload(int i);

    public static native void midiPlayerSFUnload(int i, int i2);

    public static native void midiPlayerSFontSelect(int i, int i2);

    public static native void midiPlayerSetFallback(String str);

    public static native void midiPlayerSetGain(float f);

    public static native void midiPlayerSetGen(int i, int i2, float f);

    public static native void midiPlayerSetPolyphony(int i);

    public static native void midiPlayerSystemReset();

    public static native void releaseEngine();

    public static native void releaseMidiPlayer();

    public static native void setPlayingMidiPlayer(boolean z);

    static {
        System.loadLibrary("fluidsynth");
        System.loadLibrary("xsynth");
        BANK_SELECT_MSB = (byte) 0;
        MODULATION_MSB = (byte) 1;
        BREATH_MSB = (byte) 2;
        FOOT_MSB = (byte) 4;
        PORTAMENTO_TIME_MSB = (byte) 5;
        DATA_ENTRY_MSB = (byte) 6;
        VOLUME_MSB = (byte) 7;
        BALANCE_MSB = (byte) 8;
        PAN_MSB = (byte) 10;
        EXPRESSION_MSB = (byte) 11;
        EFFECTS1_MSB = (byte) 12;
        EFFECTS2_MSB = (byte) 13;
        GPC1_MSB = (byte) 16;
        GPC2_MSB = (byte) 17;
        GPC3_MSB = (byte) 18;
        GPC4_MSB = (byte) 19;
        BANK_SELECT_LSB = (byte) 32;
        MODULATION_WHEEL_LSB = (byte) 33;
        BREATH_LSB = (byte) 34;
        FOOT_LSB = (byte) 36;
        PORTAMENTO_TIME_LSB = (byte) 37;
        DATA_ENTRY_LSB = (byte) 38;
        VOLUME_LSB = (byte) 39;
        BALANCE_LSB = (byte) 40;
        PAN_LSB = (byte) 42;
        EXPRESSION_LSB = (byte) 43;
        EFFECTS1_LSB = (byte) 44;
        EFFECTS2_LSB = (byte) 45;
        GPC1_LSB = (byte) 48;
        GPC2_LSB = (byte) 49;
        GPC3_LSB = (byte) 50;
        GPC4_LSB = (byte) 51;
        SUSTAIN_SWITCH = (byte) 64;
        PORTAMENTO_SWITCH = (byte) 65;
        SOSTENUTO_SWITCH = (byte) 66;
        SOFT_PEDAL_SWITCH = (byte) 67;
        LEGATO_SWITCH = (byte) 69;
        HOLD2_SWITCH = (byte) 69;
        SOUND_CTRL1 = (byte) 70;
        SOUND_CTRL2 = (byte) 71;
        SOUND_CTRL3 = (byte) 72;
        SOUND_CTRL4 = (byte) 73;
        SOUND_CTRL5 = (byte) 74;
        SOUND_CTRL6 = (byte) 75;
        SOUND_CTRL7 = (byte) 76;
        SOUND_CTRL8 = (byte) 77;
        SOUND_CTRL9 = (byte) 78;
        SOUND_CTRL10 = (byte) 79;
        GPC5 = (byte) 80;
        GPC6 = (byte) 81;
        GPC7 = (byte) 82;
        GPC8 = (byte) 83;
        PORTAMENTO_CTRL = (byte) 84;
        EFFECTS_DEPTH1 = (byte) 91;
        EFFECTS_DEPTH2 = (byte) 92;
        EFFECTS_DEPTH3 = (byte) 93;
        EFFECTS_DEPTH4 = (byte) 94;
        EFFECTS_DEPTH5 = (byte) 95;
        DATA_ENTRY_INCR = (byte) 96;
        DATA_ENTRY_DECR = (byte) 97;
        NRPN_LSB = (byte) 98;
        NRPN_MSB = (byte) 99;
        RPN_LSB = (byte) 100;
        RPN_MSB = (byte) 101;
        ALL_SOUND_OFF = (byte) 120;
        ALL_CTRL_OFF = (byte) 121;
        LOCAL_CONTROL = (byte) 122;
        ALL_NOTES_OFF = (byte) 123;
        OMNI_OFF = (byte) 124;
        OMNI_ON = (byte) 125;
        POLY_OFF = (byte) 126;
        POLY_ON = (byte) 127;
    }
}
