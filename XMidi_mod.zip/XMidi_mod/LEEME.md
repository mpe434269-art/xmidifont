# XMidi modificado

## Cómo compilar
1. Android Studio -> Open -> carpeta `proyecto_android_studio` -> Build > Build APK(s).
2. Al abrir la app en Android 11+ pide "Acceso a todos los archivos": actívalo
   (así sigue usando /sdcard/net.duceng/XMidi/{sf2,midi,sty} para tus soundfonts y estilos).

## Qué se cambió
- **Android actual**: targetSdk 34 / minSdk 21, `exported`, permisos de almacenamiento (Android 6-14+),
  rutas dinámicas. Se corrigieron además los `AnonymousClassN` que dejó el decompilador (no compilan).
- **Instrumentos por MIDI/ritmo**: al cargar un MIDI se reinician los 16 canales y se aplica banco -> programa ->
  controles que declara el archivo (cualquier tick, cualquier pista, MIDI tipo 0). Los ajustes manuales de
  "Channels settings" se borran al cargar otro archivo. Antes se descartaban pistas sin program change en el tick 0.
  En estilos .sty se aplican los programas/volúmenes/reverb/chorus del propio estilo.
- **Sonido horrible**: el canal 8 (Rhythm Sub) de los estilos Yamaha es BATERÍA y se tocaba como instrumento melódico;
  ahora va por el canal 9. La transposición de acordes (decompilada con la lógica invertida) se reescribió.
  Ganancia por defecto 0.5 -> 0.3 (evita saturación con soundfonts potentes; ajustable en Settings).
- **Fill-in (A/B/C/D)**: suena en el instante de pulsar, alineado al pulso (como PSR-SX); al terminar entra la
  sección destino en la línea de compás. Pulsar el Main actual dispara su fill; pulsar otro Main dispara el fill de transición.
- **Cambio de acorde**: inmediato (antes esperaba al siguiente compás); notas sostenidas se reinician sobre el acorde nuevo.

## Medido (JVM, Sample4.sty, 20 s)
Dispersión de tiempo ~0.6 ms, sin deriva; re-disparo de acorde ~1 ms; sin notas colgadas.

## Limitaciones (honestas)
- NO compilé la parte Android (no hay SDK aquí): solo probé en JVM el motor de estilos. Pueden salir errores
  menores de compilación en los archivos decompilados; pégame el log y los corrijo.
- Las .so originales son de 32 bits (armeabi-v7a/x86). Sin arm64 no corre en teléfonos solo-64-bit.
  Calidad de audio de bajo nivel (frecuencia, buffer, interpolación, reverb) vive en la .so nativa: no se pudo cambiar.
- Fill/cambio de acorde asumen compás de negras (igual que el original).


## Versión 2 (correcciones tras tus pruebas)
- **Ending + fill/main:** ahora puedes salir de un Ending pulsando un Fill o un Main (antes lo ignoraba).
- **Strings/pads que se cortaban y volvían a sonar:** el código original cortaba y re-atacaba toda nota larga en cada
  compás. Ahora las notas largas continúan entre compases. Al cambiar de acorde, las notas nuevas entran primero
  (solapadas) y las notas que no cambian NO se vuelven a atacar.
- **Compases/endings:** se reescribió la división de compases (tiempos relativos al compás, no a la 1.ª nota);
  los endings con acorde final largo ahora duran lo correcto (Ending A: 3 compases, antes 2).
- **Sonido ahogado:** reverb x0.6 y chorus x0.4 (los valores Yamaha lavaban el sonido en FluidSynth),
  brillo (CC74) y release (CC72) nunca por debajo de lo neutro, polifonía por defecto 64 -> 128 (se cortaban notas).
  Si ya tenías la app instalada, desinstálala primero (los valores por defecto solo aplican en instalación nueva).
- **Crashes:** (1) una excepción en el hilo del ritmo ya no cierra la app, (2) al cerrar la pantalla se espera a que
  el hilo termine ANTES de liberar el sintetizador (antes podía tocar un motor ya liberado), (3) más protecciones
  contra estilos sin cargar.

## Pruebas hechas (JVM, Sample4.sty)
re-ataques entre compases: 0 · notas colgadas al parar: 0 · cambio de acorde: notas nuevas a +0.3 ms ·
dispersión del reloj ~0.7 ms · falla simulada del sintetizador: 0 excepciones sin capturar.


## Versión 3
- **Instrumentos por sección (como Yamaha):** al ENTRAR a un Intro / Main / Ending / Fill se aplican los programas,
  bancos, volúmenes, pan y efectos que esa sección declara (p. ej. canal 14 = Orchestra Hit en el Intro y guitarra
  en el Main). Una sola vez por cambio de sección, no en cada compás. También cambia el kit de batería si la sección lo pide.
- **Volumen y ajustes por canal:** el deslizador de Volume (Channels Setting) era inútil: usaba una división entera
  (v/100 = 0) y tampoco se aplicaba hasta el siguiente evento. Ahora es RELATIVO al nivel que pide el ritmo para ese
  instrumento (-50% .. +50%), se oye al instante y también funciona con valores negativos. Se corrigió además el
  botón "Fixed" del chorus (al desmarcarlo quitaba el control del reverb).
  Reverb/Chorus/Sustain: sin "Fixed" siguen al ritmo (se restablecen al cambiar de sección); con "Fixed" se mantienen.
- **"Golpe" al cambiar de acorde rápido:** se corrigió un error que disparaba varias veces la misma nota sostenida;
  ahora cada nota se re-ataca una vez, con menos fuerza (más aún si los cambios son muy seguidos), y las notas
  anteriores se apagan 35 ms después (solape, sin corte seco).

## Pruebas v3 (JVM)
Cambios de programa por sección: 1 por sección (Intro 55 -> Main A 27 -> Main B 48) · ráfaga de 3 acordes en 90 ms:
1 disparo por nota, velocidades reducidas, offs con solape · re-ataques entre compases 0 · notas colgadas 0 · reloj ~0.7 ms.


## Versión 4
- **Instrumentos por sección, ahora también "de vuelta":** los ajustes iniciales del estilo (SInt) quedan guardados como base.
  Al entrar a cualquier sección se aplica base + ajustes propios de la sección (A/B/C/D, Intro, Ending...), enviando
  solo lo que cambió. Así el canal 14 pasa a "Orchestra Hit" en el Intro y VUELVE a su bajo al entrar al Main.
- ~~Mezcla por compresión de curva~~ (reemplazada en la versión 5: subía los strings y dejaba el piano abajo).
- **Fill-in a mitad de compás:** los canales que el relleno NO define (bajo, acordes, pads) siguen con el patrón del Main
  hasta el final del compás, mientras la batería hace el relleno; luego entra el Main de destino.
- **Teclado en vivo en la pantalla de ritmos:** ocupa el lugar de los pads (los pads vuelven con el botón auto/manual).
  Canal 0, independiente del ritmo. Multitoque real (hasta 32 punteros), sin notas pegadas al cancelar un toque o salir.
  Barra inferior: [metrónomo][grabar] | **Keyboard** (instrumento, soundfont, volumen 0-127, pan, sustain, reverb, chorus)
  | **Sus** (sustain on/off) | **↔** (bloquear/mover teclas: glissando o desplazamiento) | auto/manual.
  El selector de canales e instrumentos del RITMO pasó arriba (el título): toca para ver/ajustar cada canal.
- **Metrónomo sincronizado:** con el ritmo sonando, el click sale del mismo reloj del ritmo (acento en el 1, desviación <2 ms).
- **Estabilidad:** el teclado ya no puede tumbar la app con muchos dedos (el arreglo de punteros era de 10 posiciones).

## Pruebas v4 (JVM)
Canal 14: Intro=55 -> Main A=27 -> Ending sin ajuste = base 33 (restaurado) · fill a +1250 ms con relleno solo-batería: 9 notas del Main
siguen sonando · metrónomo: 9 clicks/4.3 s con acento en el 1, desviación 1.7 ms · regresión: 0 re-ataques, 0 notas colgadas,
0 excepciones sin capturar, reloj ~0.7 ms. Compilación de Synth/motor/MIDI con stubs: OK; XML y R.id verificados.


## Versión 5
- **Niveles por tipo de instrumento (reemplaza la compresión):** en un soundfont, con el mismo volumen MIDI unos instrumentos
  suenan mucho más fuerte que otros. Se compensa por familia GM, en dB sobre el volumen que pide el estilo, solo en canales
  de ritmo (8-15) sin batería: piano +3, piano eléctrico +3, guitarra +2.5, bajo +3, cuerdas -3, string ensemble -4.5,
  coro -3, pads -4.5, metales -2, órgano -2, leads -2, flautas -1. Tabla editable: `FAMILY_DB` en `Synth.java`.
  Se recalcula solo cuando cambia el instrumento de un canal. El deslizador de volumen por canal sigue encima de esto.
- **Fill a mitad de compás:** un canal es "del relleno" solo si el relleno tiene notas en lo que QUEDA del compás.
  Antes, si el piano del relleno tocaba solo al inicio del compás, el piano quedaba mudo el resto mientras los strings
  seguían. Ahora el piano y todos los canales sin notas en el resto del relleno siguen con el patrón del Main.
- **Teclado más pequeño:** teclas al 72% (cabe ~9 teclas blancas en lugar de ~7). Constante en `Drums.setupKeyboard()`:
  `setKeyScale(0.72f)`.

## Pruebas v5 (JVM)
Caso reproducido (relleno con piano solo en el 1.er tiempo y sin strings, pulsado a +1260 ms): suenan piano (3 notas), strings (3),
bajo (2) y batería del relleno (7) hasta el final del compás. Regresión: 0 re-ataques, 0 notas colgadas, 0 excepciones,
metrónomo con acento en el 1 (desviación <3 ms), reloj ~0.7 ms. Synth/motor/MIDI compilan; sintaxis de todo el proyecto: OK.


## Versión 6
- **App solo horizontal** (`sensorLandscape` en las 7 pantallas). La pantalla de ritmos tiene una sola disposición:
  izquierda archivo + secciones, derecha 16 acordes (4x4), abajo teclado de 14 teclas blancas; la barra superior reúne
  selector del ritmo, play, metrónomo, grabar, instrumento del teclado, Sus, mover teclas y auto/manual.
  Modo manual: los pads de percusión ocupan toda la pantalla.
- **16 acordes:** filas 1-2 como en tu diseño (I IV V V7 / vi ii iii iii7); filas 3-4 por defecto: bVII II III VI / i iv v vi7
  (en C: bB D E A / Cm Fm Gm Am7). Cualquier botón se cambia con pulsación larga.
- **Instrumentos al terminar un Intro:** corregido. La configuración base del estilo llegaba al motor DESPUÉS de empezar el
  Intro, así que creía que el canal ya estaba restaurado y no volvía a enviar el instrumento del Main.
- **Intro vuelve al Main que sonaba:** estando en Main C y pulsando Intro A, al terminar el Intro vuelve a Main C.
- **Canal 14 (phrase) más bajo:** ajuste por rol del canal sobre el balance por familia: phrase1 -4 dB, phrase2 -3 dB,
  chord1 (piano) +1.5 dB, chord2 +0.5 dB, pad -1 dB. Tabla `ROLE_DB` en `Synth.java`.
- **Notas largas en cada vuelta de un Main:** se cortaban sin necesidad; corregido.

## Pruebas v6 (JVM)
Intro A (canal 14 = Orchestra Hit) -> Main: el instrumento vuelve al bajo a los 2011 ms · Main B + Intro A: vuelve a Main B ·
16 acordes válidos en las 12 tonalidades (192/192) · regresión completa OK (0 re-ataques, 0 notas colgadas, 0 excepciones,
fill con piano+strings, metrónomo) · reloj ~0.9 ms · Synth/motor/MIDI compilan; XML, manifest y R.id verificados.
