# XMidi modificado

## Cómo compilar
1. Android Studio -> Open -> carpeta `proyecto_android_studio` -> Build > Build APK(s).
2. Al abrir la app en Android 11+ pide "Acceso a todos los archivos": actívalo
   (así sigue usando /sdcard/net.duceng/XMidi/{sf2,midi,sty} para tus soundfonts y estilos).

## Qué se cambió
- **Android actual**: targetSdk 34 / minSdk 21, `exported`, permisos de almacenamiento (Android 6-14+),
  rutas dinámicas. Se corrigieron además los `AnonymousClassN` que dejó el decompilador (no compilan).
- **Instrumentos por MIDI/ritmo**: al cargar un MIDI se reinician los 16 canales y se aplica banco -> programa ->
  controles que declara el archivo (cualquier tick, cualquier pista, MIDI tipo 0). Los ajustes manuales de
  "Channels settings" se borran al cargar otro archivo. Antes se descartaban pistas sin program change en el tick 0.
  En estilos .sty se aplican los programas/volúmenes/reverb/chorus del propio estilo.
- **Sonido horrible**: el canal 8 (Rhythm Sub) de los estilos Yamaha es BATERÍA y se tocaba como instrumento melódico;
  ahora va por el canal 9. La transposición de acordes (decompilada con la lógica invertida) se reescribió.
  Ganancia por defecto 0.5 -> 0.3 (evita saturación con soundfonts potentes; ajustable en Settings).
- **Fill-in (A/B/C/D)**: suena en el instante de pulsar, alineado al pulso (como PSR-SX); al terminar entra la
  sección destino en la línea de compás. Pulsar el Main actual dispara su fill; pulsar otro Main dispara el fill de transición.
- **Cambio de acorde**: inmediato (antes esperaba al siguiente compás); notas sostenidas se reinician sobre el acorde nuevo.

## Medido (JVM, Sample4.sty, 20 s)
Dispersión de tiempo ~0.6 ms, sin deriva; re-disparo de acorde ~1 ms; sin notas colgadas.

## Limitaciones (honestas)
- NO compilé la parte Android (no hay SDK aquí): solo probé en JVM el motor de estilos. Pueden salir errores
  menores de compilación en los archivos decompilados; pégame el log y los corrijo.
- Las .so originales son de 32 bits (armeabi-v7a/x86). Sin arm64 no corre en teléfonos solo-64-bit.
  Calidad de audio de bajo nivel (frecuencia, buffer, interpolación, reverb) vive en la .so nativa: no se pudo cambiar.
- Fill/cambio de acorde asumen compás de negras (igual que el original).


## Versión 2 (correcciones tras tus pruebas)
- **Ending + fill/main:** ahora puedes salir de un Ending pulsando un Fill o un Main (antes lo ignoraba).
- **Strings/pads que se cortaban y volvían a sonar:** el código original cortaba y re-atacaba toda nota larga en cada
  compás. Ahora las notas largas continúan entre compases. Al cambiar de acorde, las notas nuevas entran primero
  (solapadas) y las notas que no cambian NO se vuelven a atacar.
- **Compases/endings:** se reescribió la división de compases (tiempos relativos al compás, no a la 1.ª nota);
  los endings con acorde final largo ahora duran lo correcto (Ending A: 3 compases, antes 2).
- **Sonido ahogado:** reverb x0.6 y chorus x0.4 (los valores Yamaha lavaban el sonido en FluidSynth),
  brillo (CC74) y release (CC72) nunca por debajo de lo neutro, polifonía por defecto 64 -> 128 (se cortaban notas).
  Si ya tenías la app instalada, desinstálala primero (los valores por defecto solo aplican en instalación nueva).
- **Crashes:** (1) una excepción en el hilo del ritmo ya no cierra la app, (2) al cerrar la pantalla se espera a que
  el hilo termine ANTES de liberar el sintetizador (antes podía tocar un motor ya liberado), (3) más protecciones
  contra estilos sin cargar.

## Pruebas hechas (JVM, Sample4.sty)
re-ataques entre compases: 0 · notas colgadas al parar: 0 · cambio de acorde: notas nuevas a +0.3 ms ·
dispersión del reloj ~0.7 ms · falla simulada del sintetizador: 0 excepciones sin capturar.
