package net.duceng.midi;

import java.io.IOException;
import java.io.OutputStream;

/* JADX INFO: loaded from: classes.dex */
public class EventChannel extends MidiEvent {
    public static final byte CHANNEL_AFTERTOUCH = 13;
    public static final byte CONTROLLER = 11;
    public static final byte NOTE_AFTERTOUCH = 10;
    public static final byte NOTE_OFF = 8;
    public static final byte NOTE_ON = 9;
    public static final byte PITCH_BEND = 14;
    public static final byte PROGRAM_CHANGE = 12;
    protected byte channel;
    /** 0 = normal, 1 = nota-off sintetico de fin de compas, 2 = nota-on sintetico de inicio de compas */
    public byte carry = 0;
    protected byte type;
    protected byte value1;
    protected byte value2;

    protected EventChannel(int t, int d, byte tp, byte ch, byte v1, byte v2) {
        super(t, d);
        this.type = tp;
        this.channel = ch;
        this.value1 = v1;
        this.value2 = v2;
    }

    public EventChannel(int t, byte tp, byte ch, byte v1, byte v2) {
        this(t, 0, tp, ch, v1, v2);
    }

    public byte getType() {
        return this.type;
    }

    public void setType(byte t) {
        this.type = t;
    }

    public byte getChannel() {
        return this.channel;
    }

    public void setChannel(byte c) {
        this.channel = c;
    }

    public byte getValue1() {
        return this.value1;
    }

    public void setValue1(byte v1) {
        this.value1 = v1;
    }

    public byte getValue2() {
        return this.value2;
    }

    public void setValue2(byte v2) {
        this.value2 = v2;
    }

    @Override // net.duceng.midi.MidiEvent
    public int getSize() {
        int size = super.getSize();
        return (this.type == 12 || this.type == 13) ? size + 2 : size + 3;
    }

    @Override // net.duceng.midi.MidiEvent
    public void write(OutputStream out) throws IOException {
        super.write(out);
        int code = (this.type << 4) + this.channel;
        out.write(code);
        out.write(this.value1);
        if (this.type != 12 && this.type != 13) {
            out.write(this.value2);
        }
    }

    @Override // java.lang.Comparable
    public int compareTo(MidiEvent other) {
        if (this.tick != other.tick) {
            return this.tick < other.tick ? -1 : 1;
        }
        if (this.delta != other.delta) {
            return this.delta >= other.delta ? -1 : 1;
        }
        if (!(other instanceof EventChannel)) {
            return 1;
        }
        EventChannel o = (EventChannel) other;
        if (this.type != o.type) {
            return 1;
        }
        if (this.channel != o.channel) {
            return this.channel >= o.channel ? 1 : -1;
        }
        if (this.value1 != o.value1) {
            return this.value1 >= o.value1 ? 1 : -1;
        }
        if (this.value2 != o.value2) {
            return this.value2 >= o.value2 ? 1 : -1;
        }
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /** Copia de este evento con otra velocidad (1..127). */
    public EventChannel withVelocity(int vel) {
        EventChannel c = clone();
        c.value2 = (byte) Math.max(1, Math.min(127, vel));
        return c;
    }

    public EventChannel clone() {
        EventChannel c = new EventChannel(this.tick, this.delta, this.type, this.channel, this.value1, this.value2);
        c.carry = this.carry;
        return c;
    }
}
