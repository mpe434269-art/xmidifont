package net.duceng.midi;

import android.util.SparseIntArray;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.TreeSet;

/* JADX INFO: loaded from: classes.dex */
public class MidiTrack {
    public static final String ID = "MTrk";
    protected byte channel;
    private boolean closed;
    protected SparseIntArray controls;
    protected TreeSet<MidiEvent> events;
    protected byte program;
    private boolean recalculating;
    private int size;

    public MidiTrack() {
        this.size = 0;
        this.closed = false;
        this.recalculating = true;
        this.program = (byte) -1;
        this.channel = (byte) -1;
        this.controls = new SparseIntArray();
        this.events = new TreeSet<>();
    }

    public MidiTrack(InputStream in) throws IOException {
        this();
        byte[] buffer = new byte[4];
        in.read(buffer, 0, 4);
        String id = new String(buffer, 0, 4, "US-ASCII");
        if (!id.equals("MTrk")) {
            throw new RuntimeException("Track id did not match MTrk!");
        }
        in.read(buffer, 0, 4);
        this.size = MidiUtil.bytesToInt(buffer, 0, 4);
        int totalTicks = 0;
        int firstTick = -1;
        boolean noteSeen = false;
        while (true) {
            int delta = MidiUtil.readVInt(in);
            totalTicks += delta;
            MidiEvent E = MidiEvent.parse(totalTicks, delta, in);
            if (E == null) {
                System.out.println("Event skipped!");
            } else {
                if ((E instanceof EventMeta) && ((EventMeta) E).getType() == 47) {
                    break;
                }
                firstTick = firstTick == -1 ? E.tick : firstTick;
                if (E instanceof EventChannel) {
                    EventChannel ec = (EventChannel) E;
                    if (ec.type == 8 || ec.type == 9) {
                        noteSeen = true;
                        if (this.channel == -1) {
                            this.channel = ec.channel;      // pista sin program change: toma el canal de sus notas
                        }
                    } else if (!noteSeen) {
                        if (ec.type == 12) {
                            this.channel = ec.channel;
                            this.program = ec.value1;
                        } else if (ec.type == 11) {
                            this.controls.put(ec.value1, ec.value2);
                        }
                    }
                }
                this.events.add(E);
            }
        }
        if (firstTick > 0 && this.events.size() > 0) {
            this.events.first().delta += firstTick;
        }
    }

    public byte getChannel() {
        return this.channel;
    }

    public void setChannel(byte c) {
        if (this.channel == -1) {
            this.recalculating = true;
        }
        this.channel = c;
        for (MidiEvent e : this.events) {
            if (e instanceof EventChannel) {
                EventChannel ec = (EventChannel) e;
                ec.channel = c;
            }
        }
    }

    public byte getProgram() {
        return this.program;
    }

    public void setProgram(byte p) {
        if (this.channel == -1) {
            this.recalculating = true;
        }
        this.program = p;
    }

    public byte getControl(byte t) {
        if (this.controls.indexOfKey(t) >= 0) {
            return (byte) this.controls.get(t);
        }
        return (byte) -1;
    }

    public void setControl(byte t, byte v) {
        if (this.controls.indexOfKey(t) < 0) {
            this.recalculating = true;
        }
        this.controls.put(t, v);
    }

    public SparseIntArray getControls() {
        return this.controls;
    }

    public TreeSet<MidiEvent> getEvents() {
        return this.events;
    }

    public int getCount() {
        return (this.channel == -1 ? 0 : 1) + this.controls.size() + this.events.size();
    }

    public int getSize() {
        if (this.recalculating) {
            recalculate();
        }
        return this.size;
    }

    private void recalculate() {
        this.size = this.channel == -1 ? 0 : 3;
        this.size += this.controls.size() * 4;
        for (MidiEvent e : this.events) {
            this.size += e.getSize();
        }
        this.recalculating = false;
    }

    public int getLastTicks() {
        if (this.events.size() == 0) {
            return 0;
        }
        return this.events.last().getTick();
    }

    public void insert(MidiEvent e) {
        if (e != null) {
            if (this.closed) {
                throw new RuntimeException("Error: Cannot add an event to a closed track.");
            }
            this.recalculating = true;
            MidiEvent prev = this.events.floor(e);
            MidiEvent next = this.events.ceiling(e);
            this.events.add(e);
            if (prev != null) {
                e.setDelta(e.getTick() - prev.getTick());
            } else {
                e.setDelta(e.getTick());
            }
            if (next != null) {
                next.setDelta(next.getTick() - e.getTick());
            }
            if ((e instanceof EventMeta) && ((EventMeta) e).getType() == 47) {
                if (next != null) {
                    throw new IllegalArgumentException("Attempting to insert END_OF_TRACK before an existing event. Use close() when finished with MidiTrack.");
                }
                this.closed = true;
            }
        }
    }

    public boolean remove(MidiEvent e) {
        MidiEvent next;
        Iterator<MidiEvent> it = this.events.iterator();
        MidiEvent prev = null;
        MidiEvent curr = null;
        while (true) {
            next = null;
            if (!it.hasNext()) {
                break;
            }
            MidiEvent next2 = it.next();
            next = next2;
            if (e.equals(curr)) {
                break;
            }
            prev = curr;
            curr = next;
        }
        if (next == null) {
            this.recalculating = true;
            return this.events.remove(curr);
        }
        if (!this.events.remove(curr)) {
            return false;
        }
        if (prev != null) {
            next.setDelta(next.getTick() - prev.getTick());
        } else {
            next.setDelta(next.getTick());
        }
        this.recalculating = true;
        return true;
    }

    public void close() {
        int lastTick = 0;
        if (this.events.size() > 0) {
            MidiEvent last = this.events.last();
            lastTick = last.getTick() + 1;
        }
        byte[] buff = new byte[0];
        EventMeta eot = new EventMeta(lastTick, 0, (short) 47, buff);
        insert(eot);
    }

    public void write(OutputStream out) throws IOException {
        if (!this.closed) {
            close();
        }
        if (this.recalculating) {
            recalculate();
        }
        out.write("MTrk".getBytes("US-ASCII"));
        out.write(MidiUtil.intToBytes(this.size, 4));
        EventChannel ec = new EventChannel(0, (byte) 12, (byte) 0, (byte) 0, (byte) 0);
        if (this.channel != -1) {
            ec.setType((byte) 12);
            ec.setChannel(this.channel);
            ec.setValue1(this.program);
            ec.write(out);
        }
        ec.setType((byte) 11);
        ec.setChannel(this.channel);
        for (int i = 0; i < this.controls.size(); i++) {
            ec.setValue1((byte) this.controls.keyAt(i));
            ec.setValue2((byte) this.controls.valueAt(i));
            ec.write(out);
        }
        for (MidiEvent e : this.events) {
            e.write(out);
        }
    }
}
