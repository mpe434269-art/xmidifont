package net.duceng.midi;

import android.util.Log;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

/* JADX INFO: loaded from: classes.dex */
public class StyFile {
    public static final String HEAD = "MThd";
    private int count;
    private String identifier;
    private int resolution;
    private MetaTempo tempo;
    private MetaTimeSignature timeSignature;
    private StyTrack track;
    private int type;
    private ArrayList<MidiEvent> head = new ArrayList<>();
    private ArrayList<MidiEvent> sint = new ArrayList<>();
    private Map<String, StySection> sections = new TreeMap(new CompratorSection(null));

    private static class CompratorSection implements Comparator<String> {
        private CompratorSection() {
        }

        /* synthetic */ CompratorSection(CompratorSection compratorSection) {
            this();
        }

        @Override // java.util.Comparator
        public int compare(String lhs, String rhs) {
            if (lhs.matches("Main.*")) {
                if (rhs.matches("Main.*")) {
                    return lhs.compareTo(rhs);
                }
                return 1;
            }
            if (lhs.matches("Intro.*")) {
                if (rhs.matches("Intro.*")) {
                    return lhs.compareTo(rhs);
                }
                return rhs.matches("Ending.*") ? -1 : -1;
            }
            if (lhs.matches("Ending.*")) {
                if (rhs.matches("Ending.*")) {
                    return lhs.compareTo(rhs);
                }
                return !rhs.matches("Intro.*") ? -1 : 1;
            }
            if (lhs.matches("Fill In.*")) {
                if (rhs.matches("Main.*")) {
                    return -1;
                }
                if (rhs.matches("Intro.*")) {
                    return 1;
                }
                return lhs.compareTo(rhs);
            }
            return lhs.compareTo(rhs);
        }
    }

    public StyFile(InputStream is) throws IOException {
        this.identifier = null;
        BufferedInputStream in = new BufferedInputStream(is);
        byte[] buffer = new byte[14];
        in.read(buffer);
        String id = new String(buffer, 0, 4, "US-ASCII");
        if (!id.equals("MThd")) {
            throw new RuntimeException("File identifier not MThd. Exiting");
        }
        this.type = MidiUtil.bytesToInt(buffer, 8, 2);
        this.count = MidiUtil.bytesToInt(buffer, 10, 2);
        this.resolution = MidiUtil.bytesToInt(buffer, 12, 2);
        if (this.type != 0 || this.count != 1) {
            throw new RuntimeException("This File is not YAMAHA sty. Exiting");
        }
        this.track = new StyTrack(in);
        ArrayList<MidiEvent> list = null;
        int tick = 0;
        for (MidiEvent e : this.track.events) {
            if ((e instanceof EventMeta) && ((EventMeta) e).type == 6) {
                String mark = new String(((EventMeta) e).value);
                if (mark.matches("SFF.*")) {
                    this.identifier = mark;
                    list = this.head;
                } else if (mark.equals("SInt")) {
                    list = this.sint;
                } else if (mark.matches("Main.*") || mark.matches("Intro.*") || mark.matches("Fill In.*") || mark.matches("Ending.*")) {
                    StySection s = new StySection(mark);
                    this.sections.put(mark, s);
                    list = s.getEvents();
                } else {
                    list = null;
                }
                tick = 0;
            } else if (list != null) {
                tick += e.delta;
                e.tick = tick;
                list.add(e);
            }
        }
        String check = MidiUtil.readString(in, 4);
        if (!check.equals("CASM")) {
            throw new RuntimeException("The CASM is not found. Exiting for: " + check);
        }
        int casmRemain = MidiUtil.readInt(in);
        while (casmRemain > 0 && MidiUtil.readString(in, 4).equals("CSEG")) {
            int csegRemain = MidiUtil.readInt(in);
            casmRemain = (casmRemain - 8) - csegRemain;
            StySection ss = null;
            while (csegRemain > 0) {
                String check2 = MidiUtil.readString(in, 4);
                int len = MidiUtil.readInt(in);
                csegRemain = (csegRemain - 8) - len;
                if (check2.equals("Sdec")) {
                    String[] snames = MidiUtil.readString(in, len).split(",");
                    if (this.sections.containsKey(snames[0])) {
                        StySection ss2 = this.sections.get(snames[0]);
                        ss = ss2;
                        if (snames.length > 1) {
                            for (int i = 1; i < snames.length; i++) {
                                if (this.sections.containsKey(snames[i])) {
                                    this.sections.get(snames[i]).setControls(ss.getControls());
                                }
                            }
                        }
                    }
                } else if (check2.equals("Ctab")) {
                    byte[] tdata = new byte[len];
                    in.read(tdata);
                    StyControl sc = new StyControl(tdata);
                    if (ss != null) {
                        ss.getControls().put(sc.source, sc);
                    }
                } else if (check2.equals("Cntt")) {
                    byte c = (byte) in.read();
                    byte ntt = (byte) in.read();
                    if (ss != null && ss.getControls().indexOfKey(c) >= 0) {
                        ss.getControls().get(c).ntt = ntt;
                    }
                } else {
                    in.skip(len);
                }
            }
        }
        Log.i("XMidi", "Load StyFile, resolution:" + getResolution() + " tempo:" + getTempo().getBpm() + " identifier:" + this.identifier + " sections:" + this.sections.size());
        for (StySection ss3 : this.sections.values()) {
            ss3.init(this);
        }
    }

    public int getType() {
        return this.type;
    }

    public int getCount() {
        return this.count;
    }

    public int getResolution() {
        return this.resolution;
    }

    public MetaTempo getTempo() {
        if (this.tempo != null) {
            return this.tempo;
        }
        for (MidiEvent e : this.track.getEvents()) {
            if (e instanceof MetaTempo) {
                this.tempo = (MetaTempo) e;
                return this.tempo;
            }
        }
        this.tempo = new MetaTempo();
        return this.tempo;
    }

    public MetaTimeSignature getTimeSignature() {
        if (this.timeSignature != null) {
            return this.timeSignature;
        }
        for (MidiEvent e : this.track.getEvents()) {
            if (e instanceof MetaTimeSignature) {
                this.timeSignature = (MetaTimeSignature) e;
                return this.timeSignature;
            }
        }
        this.timeSignature = new MetaTimeSignature();
        return this.timeSignature;
    }

    public StyTrack getTrack() {
        return this.track;
    }

    public String getIdentifier() {
        return this.identifier;
    }

    public ArrayList<MidiEvent> getHead() {
        return this.head;
    }

    public ArrayList<MidiEvent> getSint() {
        return this.sint;
    }

    public Map<String, StySection> getSections() {
        return this.sections;
    }

    public StySection getSection(String key) {
        return this.sections.get(key);
    }

    public boolean containsSection(String key) {
        return this.sections.containsKey(key);
    }
}
