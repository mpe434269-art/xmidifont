package net.duceng.midi;

import android.util.Log;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

/* JADX INFO: loaded from: classes.dex */
public class StyFile {
    public static final String HEAD = "MThd";
    private int count;
    private String identifier;
    private int resolution;
    private MetaTempo tempo;
    private MetaTimeSignature timeSignature;
    private StyTrack track;
    private int type;
    private ArrayList<MidiEvent> head = new ArrayList<>();
    private ArrayList<MidiEvent> sint = new ArrayList<>();
    private Map<String, StySection> sections = new TreeMap(new CompratorSection(null));

    private static class CompratorSection implements Comparator<String> {
        private CompratorSection() {
        }

        /* synthetic */ CompratorSection(CompratorSection compratorSection) {
            this();
        }

        @Override // java.util.Comparator
        public int compare(String lhs, String rhs) {
            if (lhs.matches("Main.*")) {
                if (rhs.matches("Main.*")) {
                    return lhs.compareTo(rhs);
                }
                return 1;
            }
            if (lhs.matches("Intro.*")) {
                if (rhs.matches("Intro.*")) {
                    return lhs.compareTo(rhs);
                }
                return rhs.matches("Ending.*") ? -1 : -1;
            }
            if (lhs.matches("Ending.*")) {
                if (rhs.matches("Ending.*")) {
                    return lhs.compareTo(rhs);
                }
                return !rhs.matches("Intro.*") ? -1 : 1;
            }
            if (lhs.matches("Fill In.*")) {
                if (rhs.matches("Main.*")) {
                    return -1;
                }
                if (rhs.matches("Intro.*")) {
                    return 1;
                }
                return lhs.compareTo(rhs);
            }
            return lhs.compareTo(rhs);
        }
    }

    private static int u32(byte[] b, int p) {
        return ((b[p] & 255) << 24) | ((b[p + 1] & 255) << 16) | ((b[p + 2] & 255) << 8) | (b[p + 3] & 255);
    }

    private static String ascii(byte[] b, int p, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n && p + i < b.length; i++) {
            sb.append((char) (b[p + i] & 255));
        }
        return sb.toString();
    }

    /** Nombre de seccion normalizado: sin NUL ni espacios sobrantes. */
    private static String cleanName(String raw) {
        return raw.replace("\u0000", "").trim();
    }

    private static boolean isSectionName(String m) {
        return m.matches("Main.*") || m.matches("Intro.*") || m.matches("Fill In.*") || m.matches("Ending.*") || m.matches("Break.*");
    }

    private static byte[] readAll(InputStream is) throws IOException {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[32 * 1024];
        int n;
        while ((n = is.read(buf)) > 0) {
            bo.write(buf, 0, n);
        }
        return bo.toByteArray();
    }

    public StyFile(InputStream is) throws IOException {
        this.identifier = null;
        byte[] all = readAll(is);
        if (all.length < 22 || !ascii(all, 0, 4).equals("MThd")) {
            throw new RuntimeException("File identifier not MThd. Exiting");
        }
        int headLen = Math.max(6, u32(all, 4));
        this.type = MidiUtil.bytesToInt(all, 8, 2);
        this.count = MidiUtil.bytesToInt(all, 10, 2);
        this.resolution = MidiUtil.bytesToInt(all, 12, 2);
        if (this.type > 1 || this.count < 1 || this.resolution <= 0) {
            throw new RuntimeException("This File is not YAMAHA sty. Exiting");
        }
        int trackPos = 8 + headLen;
        java.io.ByteArrayInputStream in = new java.io.ByteArrayInputStream(all, trackPos, all.length - trackPos);
        this.track = new StyTrack(in);
        int parsedEnd = all.length - in.available();
        int declaredEnd = trackPos + 8 + this.track.getSize();
        int chunkStart = parsedEnd;
        if (declaredEnd >= parsedEnd && declaredEnd + 8 <= all.length && ascii(all, declaredEnd, 4).matches("[A-Za-z0-9 ]{4}")) {
            chunkStart = declaredEnd;
        }
        ArrayList<MidiEvent> list = null;
        int tick = 0;
        for (MidiEvent e : this.track.events) {
            if ((e instanceof EventMeta) && ((EventMeta) e).type == 6) {
                String mark = cleanName(new String(((EventMeta) e).value));
                if (mark.matches("SFF.*")) {
                    this.identifier = mark;
                    list = this.head;
                } else if (mark.equals("SInt")) {
                    list = this.sint;
                } else if (isSectionName(mark)) {
                    StySection s = new StySection(mark);
                    this.sections.put(mark, s);
                    list = s.getEvents();
                } else {
                    list = null;
                }
                tick = 0;
            } else if (list != null) {
                tick += e.delta;
                e.tick = tick;
                list.add(e);
            }
        }
        // Bloques despues de la pista: se busca el CASM saltando cualquier otro (OTSc, MH, FNRc... de los S700/S800/S900)
        try {
            int p = chunkStart;
            while (p + 8 <= all.length) {
                String tag = ascii(all, p, 4);
                int size = u32(all, p + 4);
                if (size < 0 || p + 8 + (long) size > all.length) {
                    size = all.length - (p + 8);
                }
                if (tag.equals("CASM")) {
                    parseCasm(all, p + 8, p + 8 + size);
                }
                p += 8 + size;
            }
        } catch (RuntimeException e) {
            Log.i("XMidi", "CASM ilegible, se usan tablas por defecto: " + e);
        }
        // Secciones sin ninguna tabla: tablas por defecto para los canales que tienen notas (estilo sin CASM o CASM danado)
        for (StySection ss : this.sections.values()) {
            if (ss.getControls().size() == 0) {
                boolean[] used = new boolean[16];
                for (MidiEvent e : ss.getEvents()) {
                    if (e instanceof EventChannel) {
                        used[((EventChannel) e).channel & 15] = true;
                    }
                }
                for (int ch = 8; ch < 16; ch++) {
                    if (used[ch]) {
                        ss.getControls().put(ch, StyControl.defaultFor(ch));
                    }
                }
            }
        }
        Log.i("XMidi", "Load StyFile, resolution:" + getResolution() + " tempo:" + getTempo().getBpm() + " identifier:" + this.identifier + " sections:" + this.sections.size());
        for (StySection ss3 : this.sections.values()) {
            ss3.init(this);
        }
    }

    private void parseCasm(byte[] b, int start, int end) {
        int p = start;
        while (p + 8 <= end) {
            String tag = ascii(b, p, 4);
            int size = u32(b, p + 4);
            int bodyEnd = (size < 0 || (long) p + 8 + size > end) ? end : p + 8 + size;
            if (tag.equals("CSEG")) {
                parseCseg(b, p + 8, bodyEnd);
            }
            p = bodyEnd;
        }
    }

    private void parseCseg(byte[] b, int start, int end) {
        ArrayList<String> names = new ArrayList<>();
        ArrayList<byte[]> ctabs = new ArrayList<>();
        ArrayList<byte[]> ctb2s = new ArrayList<>();
        ArrayList<byte[]> cntts = new ArrayList<>();
        int q = start;
        while (q + 8 <= end) {
            String tag = ascii(b, q, 4);
            int size = u32(b, q + 4);
            int bodyEnd = (size < 0 || (long) q + 8 + size > end) ? end : q + 8 + size;
            byte[] data = java.util.Arrays.copyOfRange(b, q + 8, bodyEnd);
            if (tag.equals("Sdec")) {
                for (String n : ascii(data, 0, data.length).split(",")) {
                    String cn = cleanName(n);
                    if (cn.length() > 0) {
                        names.add(cn);
                    }
                }
            } else if (tag.equals("Ctab") && data.length >= 26) {
                ctabs.add(java.util.Arrays.copyOf(data, Math.max(27, data.length)));
            } else if (tag.equals("Ctb2") && data.length >= 26) {
                ctb2s.add(java.util.Arrays.copyOf(data, Math.max(27, data.length)));
            } else if (tag.equals("Cntt") && data.length >= 2) {
                cntts.add(data);
            }
            q = bodyEnd;
        }
        ArrayList<StySection> targets = new ArrayList<>();
        for (String n : names) {
            if (this.sections.containsKey(n)) {
                targets.add(this.sections.get(n));
            }
        }
        if (targets.isEmpty()) {
            return;
        }
        android.util.SparseArray<StyControl> map = new android.util.SparseArray<>();
        for (byte[] t : ctabs) {
            StyControl sc = new StyControl(t);
            map.put(sc.source, sc);
        }
        for (byte[] t2 : ctb2s) {                       // SFF2 (S-series): Ctb2 solo completa canales sin Ctab
            StyControl sc2 = new StyControl(t2);
            if (map.indexOfKey(sc2.source) < 0) {
                map.put(sc2.source, sc2);
            }
        }
        for (byte[] c : cntts) {
            if (map.indexOfKey(c[0]) >= 0) {
                map.get(c[0]).ntt = c[1];               // el resto del bloque (bajo on/off, etc.) se ignora SIN desalinear la lectura
            }
        }
        for (StySection s : targets) {
            for (int i = 0; i < map.size(); i++) {
                s.getControls().put(map.keyAt(i), map.valueAt(i));
            }
        }
    }

    /** Ticks de un compas segun el compas real (4/4, 3/4, 6/8, 12/8...): negra = resolucion, denominador = 2^d. */
    public int getBarTicks() {
        MetaTimeSignature ts = getTimeSignature();
        int num = Math.max(1, ts.getNumerator());
        int den = 1 << Math.max(0, Math.min(6, ts.getDenominator()));
        return Math.max(1, (this.resolution * 4 * num) / den);
    }

    /** Ticks de un pulso (negra en x/4, corchea en x/8). */
    public int getBeatTicks() {
        int den = 1 << Math.max(0, Math.min(6, getTimeSignature().getDenominator()));
        return Math.max(1, (this.resolution * 4) / den);
    }

    public int getType() {
        return this.type;
    }

    public int getCount() {
        return this.count;
    }

    public int getResolution() {
        return this.resolution;
    }

    public MetaTempo getTempo() {
        if (this.tempo != null) {
            return this.tempo;
        }
        for (MidiEvent e : this.track.getEvents()) {
            if (e instanceof MetaTempo) {
                this.tempo = (MetaTempo) e;
                return this.tempo;
            }
        }
        this.tempo = new MetaTempo();
        return this.tempo;
    }

    public MetaTimeSignature getTimeSignature() {
        if (this.timeSignature != null) {
            return this.timeSignature;
        }
        for (MidiEvent e : this.track.getEvents()) {
            if (e instanceof MetaTimeSignature) {
                this.timeSignature = (MetaTimeSignature) e;
                return this.timeSignature;
            }
        }
        this.timeSignature = new MetaTimeSignature();
        return this.timeSignature;
    }

    public StyTrack getTrack() {
        return this.track;
    }

    public String getIdentifier() {
        return this.identifier;
    }

    public ArrayList<MidiEvent> getHead() {
        return this.head;
    }

    public ArrayList<MidiEvent> getSint() {
        return this.sint;
    }

    public Map<String, StySection> getSections() {
        return this.sections;
    }

    public StySection getSection(String key) {
        return this.sections.get(key);
    }

    public boolean containsSection(String key) {
        return this.sections.containsKey(key);
    }
}
