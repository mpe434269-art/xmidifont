package net.duceng.midi;

import android.util.Log;
import android.util.SparseArray;
import java.util.ArrayList;
import java.util.TreeSet;
import net.duceng.xmidi.util.Chords;

/* JADX INFO: loaded from: classes.dex */
public class StySection {
    public static final byte Bass = 10;
    public static final byte Chord1 = 11;
    public static final byte Chord2 = 12;
    public static final byte Pad = 13;
    public static final byte Phrase1 = 14;
    public static final byte Phrase2 = 15;
    public static final byte RhythmMain = 9;
    public static final byte RhythmSub = 8;
    private String name;
    private ArrayList<MidiEvent> events = new ArrayList<>();
    private SparseArray<StyControl> controls = new SparseArray<>();
    private ArrayList<TreeSet<EventChannel>> bars = new ArrayList<>();

    protected StySection(String n) {
        this.name = n;
    }

    public String getName() {
        return this.name;
    }

    protected ArrayList<MidiEvent> getEvents() {
        return this.events;
    }

    protected SparseArray<StyControl> getControls() {
        return this.controls;
    }

    protected void setControls(SparseArray<StyControl> sc) {
        this.controls = sc;
    }

    public int getLastTick() {
        return this.events.get(this.events.size() - 1).tick;
    }

    protected void init(StyFile sf) {
        int barTick = sf.getResolution() * sf.getTimeSignature().getNumerator();
        ArrayList<ArrayList<EventChannel>> i_bars = new ArrayList<>();
        ArrayList<EventChannel> bar = new ArrayList<>();
        i_bars.add(bar);
        int btick = barTick;
        for (MidiEvent e : this.events) {
            if (e instanceof EventChannel) {
                EventChannel ec = (EventChannel) e;
                if (ec.tick >= btick && ec.type == 9) {
                    btick += barTick;
                    bar = new ArrayList<>();
                    i_bars.add(bar);
                }
                bar.add(ec);
            }
        }
        for (int i = 0; i < i_bars.size(); i++) {
            ArrayList<EventChannel> b = i_bars.get(i);
            int first = b.get(0).tick;
            b.get(0).tick = 0;
            for (int k = 1; k < b.size(); k++) {
                b.get(k).tick -= first;
            }
        }
        for (int idxBar = 0; idxBar < i_bars.size(); idxBar++) {
            ArrayList<EventChannel> barNow = i_bars.get(idxBar);
            TreeSet<EventChannel> nbar = new TreeSet<>();
            int idxNow = 0;
            while (idxNow < barNow.size()) {
                if (barNow.get(idxNow).type == 9) {
                    boolean find = false;
                    for (int idxFind = idxNow; idxFind < barNow.size(); idxFind++) {
                        if (barNow.get(idxFind).type == 8 && barNow.get(idxFind).channel == barNow.get(idxNow).channel && barNow.get(idxFind).value1 == barNow.get(idxNow).value1) {
                            if (barNow.get(idxFind).tick - barNow.get(idxNow).tick < sf.getResolution() / 16) {
                                barNow.get(idxFind).tick = (barNow.get(idxNow).tick + (sf.getResolution() / 8)) - 1;
                            }
                            find = true;
                            nbar.add(barNow.get(idxNow));
                            nbar.add(barNow.get(idxFind));
                            barNow.remove(idxFind);
                            barNow.remove(idxNow);
                            idxNow--;
                            break;
                        }
                    }
                    if (!find) {
                        EventChannel ecoff = new EventChannel(barTick - 1, (byte) 8, barNow.get(idxNow).channel, barNow.get(idxNow).value1, (byte) 0);
                        if (idxBar < i_bars.size() - 1) {
                            EventChannel econ = new EventChannel(0, (byte) 9, barNow.get(idxNow).channel, barNow.get(idxNow).value1, barNow.get(idxNow).value2);
                            i_bars.get(idxBar + 1).add(econ);
                        }
                        nbar.add(barNow.get(idxNow));
                        barNow.remove(idxNow);
                        idxNow--;
                        nbar.add(ecoff);
                    }
                }
                idxNow++;
            }
            this.bars.add(nbar);
        }
        Log.i("XMidi", "Section:" + this.name + " bars: " + this.bars.size());
    }

    public int sizeBars() {
        return this.bars.size();
    }

    public ArrayList<EventChannel> getEvents(int idx) {
        return getEvents(idx, null);
    }

    // ---------------------------------------------------------------------
    //  Reescrito: el codigo decompilado de getEvents() estaba corrupto
    //  (condiciones invertidas, "break" mal colocados). Esta version aplica
    //  la regla Yamaha SFF: NTR (root trans / root fixed), NTT (tabla de
    //  transposicion), High Key y limites bajo/alto.
    // ---------------------------------------------------------------------
    private static final byte[] SCALE_MAJOR = {0, 2, 4, 5, 7, 9, 11};
    private static final byte[] SCALE_DORIAN = {0, 2, 3, 5, 7, 9, 10};
    private static final byte[] SCALE_MIXO = {0, 2, 4, 5, 7, 9, 10};
    private static final byte[] SCALE_MELMIN = {0, 2, 3, 5, 7, 9, 11};
    private static final byte[] SCALE_HARMIN = {0, 2, 3, 5, 7, 8, 11};

    /** true si el canal origen es una parte de bateria (Rhythm Sub / Rhythm Main). */
    public static boolean isRhythmChannel(int ch) {
        return ch == 8 || ch == 9;
    }

    /** Regla de retrigger de un canal origen (0 = stop, resto = reiniciar nota). */
    public int getRetriggerRule(int channel) {
        StyControl sc = this.controls.get(channel);
        return sc == null ? 1 : sc.retriggerRule;
    }

    public int getBarTicks(StyFile sf) {
        return sf.getResolution() * sf.getTimeSignature().getNumerator();
    }

    private static boolean contains(byte[] a, int v) {
        for (byte b : a) {
            if (b == v) {
                return true;
            }
        }
        return false;
    }

    private static byte[] scaleFor(int ntt, boolean minorFamily, boolean dominant) {
        if (minorFamily) {
            if (ntt == 4) {
                return SCALE_MELMIN;
            }
            return ntt == 5 ? SCALE_HARMIN : SCALE_DORIAN;
        }
        return dominant ? SCALE_MIXO : SCALE_MAJOR;
    }

    private static boolean sourceIsMinor(int chordType) {
        return chordType >= 8 && chordType <= 18;
    }

    private static boolean sourceIsDominant(int chordType) {
        return chordType >= 19 && chordType <= 27;
    }

    /** Convierte una nota del estilo (grabado sobre su acorde fuente) al acorde actual. */
    static int transposeNote(int note, StyControl sc, Chords.Chord chord) {
        int srcChordIdx = (sc.chord >= 0 && sc.chord < Chords.CBASES.length) ? sc.chord : 2;
        byte[] srcTones = Chords.CBASES[srcChordIdx];
        byte[] tgtTones = chord.chords != null ? chord.chords : Chords.CBASES[0];
        boolean tgtMinor = (chord.id / 12) == 1 || (chord.id / 12) == 3;
        boolean tgtDominant = (chord.id / 12) == 2;
        int srcRoot = sc.root & 0xFF;
        if (srcRoot > 11) {
            srcRoot = 0;
        }
        int tgtRoot = chord.root;

        // 1) desplazamiento de tonica
        int shift = ((tgtRoot - srcRoot) % 12 + 12) % 12;
        if (sc.noteRule == 1) {                 // ROOT FIXED: movimiento minimo
            if (shift > 6) {
                shift -= 12;
            }
        } else {                                // ROOT TRANS: regla "high key"
            if (shift > sc.highkey) {
                shift -= 12;
            }
        }

        // 2) tabla NTT
        int delta = 0;
        if (sc.noteTable != 0) {
            int rel = (((note - srcRoot) % 12) + 12) % 12;
            int idx = -1;
            for (int i = 0; i < srcTones.length; i++) {
                if (srcTones[i] % 12 == rel && (idx < 0 || srcTones[i] < 12)) {
                    idx = i;
                    if (srcTones[i] < 12) {
                        break;
                    }
                }
            }
            boolean chordTable = sc.noteTable == 2 || sc.noteTable == 3;
            if (idx >= 0 && (chordTable || sc.noteTable >= 1)) {
                int t = tgtTones[Math.min(idx, tgtTones.length - 1)];
                if (idx >= tgtTones.length) {
                    t += 12;
                }
                int s = srcTones[idx];
                delta = t - s;
                // evita saltos de mas de una octava en tonos extendidos (9, 11, 13)
                while (delta > 6) {
                    delta -= 12;
                }
                while (delta < -6) {
                    delta += 12;
                }
            } else {
                byte[] srcScale = scaleFor(1, sourceIsMinor(srcChordIdx), sourceIsDominant(srcChordIdx));
                byte[] tgtScale = scaleFor(sc.noteTable, tgtMinor, tgtDominant);
                int deg = -1;
                for (int i = 0; i < srcScale.length; i++) {
                    if (srcScale[i] <= rel) {
                        deg = i;
                    }
                }
                if (deg >= 0) {
                    delta = tgtScale[deg] - srcScale[deg];
                }
            }
        }

        int out = note + shift + delta;
        // 3) limites
        int lo = sc.lowLimit & 0xFF;
        int hi = sc.highLimit & 0xFF;
        if (hi > 127) {
            hi = 127;
        }
        if (hi >= lo + 11) {
            while (out > hi) {
                out -= 12;
            }
            while (out < lo) {
                out += 12;
            }
        }
        return Math.max(0, Math.min(127, out));
    }

    public ArrayList<EventChannel> getEvents(int idx, Chords.Chord chord) {
        if (idx > this.bars.size() - 1 || idx < 0) {
            idx = 0;
        }
        ArrayList<EventChannel> bar = new ArrayList<>();
        if (this.bars.isEmpty()) {
            return bar;
        }
        for (EventChannel e : this.bars.get(idx)) {
            StyControl sc = this.controls.get(e.channel);
            if (sc == null) {
                continue;
            }
            // Partes de bateria: SIEMPRE por el canal 9 (GM drums), sin transponer.
            if (isRhythmChannel(e.channel) || sc.destination == 9) {
                if (e.type == 8 || e.type == 9) {
                    EventChannel ec = e.clone();
                    ec.channel = (byte) 9;
                    bar.add(ec);
                }
                continue;
            }
            if (chord == null) {
                continue;               // sin acorde solo suena la bateria
            }
            EventChannel ec2 = e.clone();
            ec2.channel = sc.destination;
            if (e.type == 8 || e.type == 9) {
                ec2.value1 = (byte) transposeNote(e.value1, sc, chord);
            }
            bar.add(ec2);               // CC / program / pitch-bend pasan sin tocar
        }
        return bar;
    }
}
