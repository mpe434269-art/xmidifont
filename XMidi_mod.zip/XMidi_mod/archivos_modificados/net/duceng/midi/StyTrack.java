package net.duceng.midi;

import java.io.IOException;
import java.io.InputStream;
import java.util.TreeSet;

/* JADX INFO: loaded from: classes.dex */
public class StyTrack {
    public static final String ID = "MTrk";
    protected TreeSet<MidiEvent> events = new TreeSet<>();
    private int size;

    public StyTrack(InputStream in) throws IOException {
        this.size = 0;
        byte[] buffer = new byte[4];
        in.read(buffer, 0, 4);
        String id = new String(buffer, 0, 4, "US-ASCII");
        if (!id.equals("MTrk")) {
            throw new RuntimeException("Track id did not match MTrk!");
        }
        in.read(buffer, 0, 4);
        this.size = MidiUtil.bytesToInt(buffer, 0, 4);
        int totalTicks = 0;
        while (in.available() > 0) {                 // archivo truncado o sin fin de pista: no entrar en bucle infinito
            int delta = MidiUtil.readVInt(in);
            totalTicks += delta;
            MidiEvent E = MidiEvent.parse(totalTicks, delta, in);
            if (E == null) {
                System.out.println("Event skipped!");
            } else if (!(E instanceof EventMeta) || ((EventMeta) E).getType() != 47) {
                this.events.add(E);
            } else {
                return;
            }
        }
    }

    public TreeSet<MidiEvent> getEvents() {
        return this.events;
    }

    public int getCount() {
        return this.events.size();
    }

    public int getSize() {
        return this.size;
    }
}
