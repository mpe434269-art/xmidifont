package net.duceng.xmidi;

import net.duceng.xmidi.util.Immersive;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import java.util.ArrayList;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes.dex */
public abstract class Base extends Activity {
    protected static boolean isExit = false;
    private ImageButton back;
    private LinearLayout bottom;
    protected boolean isPortRait;
    private ImageButton launcher;
    private ImageButton more;
    private LinearLayout moreLayout;
    private PopupWindow moreWindow;
    protected Button title;
    private LinearLayout tools;
    private FrameLayout wapper;
    protected ArrayList<View> listTop = new ArrayList<>();
    protected ArrayList<View> listBottom = new ArrayList<>();
    protected ArrayList<View> listMore = new ArrayList<>();
    protected View.OnClickListener actionClickListener = new View.OnClickListener() { // from class: net.duceng.xmidi.Base.1
        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            Base.this.onActionClick(v);
        }
    };
    protected View.OnClickListener menuClickListener = new View.OnClickListener() { // from class: net.duceng.xmidi.Base.2
        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            Base.this.onActionClick(v);
            Base.this.moreWindow.dismiss();
        }
    };

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        isExit = false;
        super.onCreate(bundle);
        super.setContentView(R.layout.base);
        this.back = (ImageButton) findViewById(R.id.back);
        this.launcher = (ImageButton) findViewById(R.id.launcher);
        this.title = (Button) findViewById(R.id.title);
        this.more = (ImageButton) findViewById(R.id.more);
        this.tools = (LinearLayout) findViewById(R.id.tools);
        this.bottom = (LinearLayout) findViewById(R.id.bottom);
        this.wapper = (FrameLayout) findViewById(R.id.wapper);
        ScrollView scrollView = new ScrollView(this);
        this.moreLayout = new LinearLayout(this);
        this.moreLayout.setOrientation(1);
        scrollView.addView(this.moreLayout);
        this.moreWindow = new PopupWindow(scrollView, -2, -2);
        this.moreWindow.setBackgroundDrawable(new ColorDrawable(android.R.color.transparent));
        this.moreWindow.setFocusable(true);
        this.more.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.Base.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Base.this.showMenu();
            }
        });
        this.launcher.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.Base.4
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Base.this.finish();
            }
        });
    }

    protected void showMenu() {
        if (this.moreWindow.isShowing()) {
            this.moreWindow.dismiss();
        } else {
            this.moreWindow.showAsDropDown(this.more, 0, dpTopx(2));
        }
    }

    @Override // android.app.Activity
    protected void onStart() {
        onConfigurationChanged(getResources().getConfiguration());
        super.onStart();
    }

    @Override // android.app.Activity
    protected void onResume() {
        Immersive.apply(getWindow());
        if (isExit) {
            finish();
        }
        super.onResume();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        this.tools.removeAllViews();
        this.bottom.removeAllViews();
        for (int i = 0; i < this.listTop.size(); i++) {
            View child = this.listTop.get(i);
            this.tools.addView(child, this.tools.getChildCount());
        }
        if (newConfig.orientation == 1) {
            for (int i2 = 0; i2 < this.listBottom.size(); i2++) {
                View child2 = this.listBottom.get(i2);
                this.bottom.addView(child2);
            }
            if (this.listBottom.size() > 0) {
                this.bottom.setVisibility(0);
            } else {
                this.bottom.setVisibility(8);
            }
            this.isPortRait = true;
        } else {
            for (int i3 = 0; i3 < this.listBottom.size(); i3++) {
                View child3 = this.listBottom.get(i3);
                this.tools.addView(child3, this.tools.getChildCount());
            }
            this.bottom.setVisibility(8);
            this.isPortRait = false;
        }
        this.moreLayout.removeAllViews();
        if (this.listMore.size() > 0) {
            for (int i4 = 0; i4 < this.listMore.size(); i4++) {
                View child4 = this.listMore.get(i4);
                this.moreLayout.addView(child4, this.moreLayout.getChildCount());
            }
            this.more.setVisibility(0);
            return;
        }
        this.more.setVisibility(8);
    }

    @Override // android.app.Activity
    public void setContentView(int layoutResID) {
        View child = getLayoutInflater().inflate(layoutResID, (ViewGroup) null);
        this.wapper.addView(child);
    }

    @Override // android.app.Activity
    public void setContentView(View view) {
        this.wapper.addView(view);
    }

    protected void setTop(boolean top) {
        if (top) {
            this.back.setVisibility(4);
            this.launcher.setClickable(false);
        } else {
            this.back.setVisibility(0);
            this.launcher.setClickable(true);
        }
    }

    protected void onActionClick(View v) {
        switch (v.getId()) {
            case R.id.act_settings /* 2131296419 */:
                Intent intent = new Intent(this, (Class<?>) Settings.class);
                startActivity(intent);
                break;
            case R.id.act_about /* 2131296420 */:
                Intent intent2 = new Intent(this, (Class<?>) About.class);
                startActivity(intent2);
                break;
            case R.id.act_exit /* 2131296421 */:
                isExit = true;
                finish();
                break;
        }
    }

    public int pxTodp(int px) {
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        return (int) (((double) (px / displayMetrics.density)) + 0.5d);
    }

    public int dpTopx(int dp) {
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        return (int) (((double) (dp * displayMetrics.density)) + 0.5d);
    }

    private static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        int height = options.outHeight;
        int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            int halfHeight = height / 2;
            int halfWidth = width / 2;
            while (halfHeight / inSampleSize > reqHeight && halfWidth / inSampleSize > reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    public static Bitmap decodeResource(Resources res, int resId, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPurgeable = true;
        options.inInputShareable = true;
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(res, resId, options);
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(res, resId, options);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            Immersive.apply(getWindow());
        }
    }
}
