package net.duceng.xmidi;

import net.duceng.xmidi.util.Importer;
import android.widget.Toast;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.Bundle;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Process;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.ArrayList;
import net.duceng.xmidi.util.StyleEngine;
import net.duceng.xmidi.widgets.PianoBoard;
import net.duceng.midi.EventChannel;
import net.duceng.midi.MidiEvent;
import net.duceng.midi.MidiUtil;
import net.duceng.midi.StyFile;
import net.duceng.midi.StySection;
import net.duceng.xmidi.ui.DialogChannel;
import net.duceng.xmidi.ui.DialogChord;
import net.duceng.xmidi.ui.DialogPercussion;
import net.duceng.xmidi.ui.DialogPreset;
import net.duceng.xmidi.ui.DialogSty;
import net.duceng.xmidi.ui.DialogTonality;
import net.duceng.xmidi.util.Chords;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes.dex */
public class Drums extends BaseApp {
    private static byte NOTE_BASE = 27;
    private static byte NOTE_CHAN = 9;
    private static String STY_DEFAULT = "Sample4.sty";
    private ImageButton bAuto;
    private Button bPreset;
    private Button btnFile;
    private ImageButton btnPlay;
    private Button btnTonality;
    private DialogChannel channDialog;
    private Chords.Chord chord;
    private View divh;
    private View divv;
    private Handler handler;
    private LinearLayout layoutAuto;
    private LinearLayout layoutTop;
    private LinearLayout layoutDrums;
    private LinearLayout layoutManual;
    private ExecutorService mExecutor;
    private Runnable mRunnable;
    private List<EventChannel> notes;
    private String[] percussions;
    private StyFile styFile;
    private StySection stySection;
    private int[] notes8 = {9, 10, 11, 18, 21, 19, 22, 24};
    private int[] notes15 = {9, 10, 11, 14, 16, 18, 20, 21, 23, 15, 17, 19, 22, 24, 26};
    private LinearLayout[] layoutStys = new LinearLayout[5];
    private LinearLayout[] layoutBtns = new LinearLayout[5];
    private Button[] btnSections = new Button[20];
    private Button[] btnChords = new Button[16];
    private Button[] btnDrums = new Button[15];
    private StyleEngine engine;
    private Button chordLongBtn;
    private Button drumLongBtn;
    private DialogChord dialogChordRef;
    private DialogPercussion dialogPercRef;
    private DialogSty dialogStyRef;
    private DialogTonality dialogTonalityRef;
    private boolean startedBySynth = false;
    private volatile boolean destroyed = false;
    private static final int KEY_CHAN = 0;                 // canal propio del teclado en vivo (el ritmo usa 8-15)
    private Button bKeyboard;
    private Button bSustain;
    private ImageButton bLock;
    private PianoBoard piano;
    private LinearLayout layoutKeys;
    private DialogPreset keyboardPreset;
    private DialogPreset rhythmPreset;
    private Drawable sustainBg;
    private boolean sustainOn = false;
    private boolean metroOn = false;
    private ArrayList<EventChannel> baseApplied = new ArrayList<>();
    private final PianoBoard.PianoBoardListener keyListener = new PianoBoard.PianoBoardListener() {
        @Override // net.duceng.xmidi.widgets.PianoBoard.PianoBoardListener
        public void onKeysChanged(int note, int val) {
            if (Drums.this.destroyed) {
                return;
            }
            if (val > 0) {
                Drums.this.synth.keyOn(KEY_CHAN, note, val);
            } else {
                Drums.this.synth.keyOff(KEY_CHAN, note);
            }
        }
    };
    private boolean auto = true;
    private boolean playing = false;
    private int idxBeat = 0;
    private int idxBar = 0;
    private Chords gChords = new Chords();
    private View.OnTouchListener sectionTouchListener = new View.OnTouchListener() { // from class: net.duceng.xmidi.Drums.1
        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View v, MotionEvent event) {
            int action = event.getAction() & 255;
            if (action == 0 && v.getTag() != null) {
                Drums.this.sectionSelect((Button) v);
                return false;
            }
            return false;
        }
    };
    private View.OnTouchListener chordTouchListener = new View.OnTouchListener() { // from class: net.duceng.xmidi.Drums.2
        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View v, MotionEvent event) {
            int action = event.getAction() & 255;
            if (action == 0) {
                Drums.this.chordSelect((Button) v);
                return false;
            }
            return false;
        }
    };
    private View.OnLongClickListener chordLongClickListener = new View.OnLongClickListener() { // from class: net.duceng.xmidi.Drums.3
        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View v) {
            Drums.this.chordLongBtn = (Button) v;
            if (Drums.this.dialogChordRef == null) {
                Drums.this.dialogChordRef = new DialogChord(Drums.this, Drums.this.gChords);
                Drums.this.dialogChordRef.setOnSelectListener(new DialogChord.OnSelectListener() { // from class: net.duceng.xmidi.Drums.3.1
                    @Override // net.duceng.xmidi.ui.DialogChord.OnSelectListener
                    public boolean onSelect(int idx) {
                        Chords.Chord c = Drums.this.gChords.getChord(idx);
                        Drums.this.chordLongBtn.setText(c.name);
                        Drums.this.chordLongBtn.setTag(c);
                        if (Drums.this.chordLongBtn.isSelected()) {
                            Drums.this.chord = c;
                            if (Drums.this.engine != null) {
                                Drums.this.engine.setChord(c);
                            }
                        }
                        Drums.this.dialogChordRef.dismiss();
                        return true;
                    }
                });
            }
            Drums.this.dialogChordRef.show();
            return true;
        }
    };
    private View.OnTouchListener drumTouchListener = new View.OnTouchListener() { // from class: net.duceng.xmidi.Drums.4
        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View v, MotionEvent event) {
            int action = event.getAction() & 255;
            if (action == 0) {
                Drums.this.synth.noteOn(((Integer) v.getTag()).byteValue(), (byte) 100);
                return false;
            }
            if (action == 1) {
                Drums.this.synth.noteOff(((Integer) v.getTag()).byteValue());
                return false;
            }
            return false;
        }
    };
    private View.OnLongClickListener drumLongClickListener = new View.OnLongClickListener() { // from class: net.duceng.xmidi.Drums.5
        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View v) {
            Drums.this.drumLongBtn = (Button) v;
            if (Drums.this.dialogPercRef == null) {
                Drums.this.dialogPercRef = new DialogPercussion(Drums.this, Drums.this.percussions);
                Drums.this.dialogPercRef.setOnSelectListener(new DialogPercussion.OnSelectListener() { // from class: net.duceng.xmidi.Drums.5.1
                    @Override // net.duceng.xmidi.ui.DialogPercussion.OnSelectListener
                    public boolean onSelect(int idx) {
                        Drums.this.drumLongBtn.setText(Drums.this.percussions[idx]);
                        Drums.this.drumLongBtn.setTag(Integer.valueOf(Drums.NOTE_BASE + idx));
                        Drums.this.dialogPercRef.dismiss();
                        return true;
                    }
                });
            }
            Drums.this.dialogPercRef.show();
            return true;
        }
    };

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drums);
        this.synth.setStyleMix(true);
        this.title.setText(R.string.drums);
        this.bPreset = this.title;                       // el selector de canales/instrumentos del ritmo va ARRIBA (titulo)
        this.title.setOnLongClickListener(new View.OnLongClickListener() {
            @Override // android.view.View.OnLongClickListener
            public boolean onLongClick(View v) {
                if (Drums.this.rhythmPreset == null) {
                    Drums.this.rhythmPreset = new DialogPreset(Drums.this, Drums.this.synth);
                    Drums.this.rhythmPreset.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override // android.content.DialogInterface.OnDismissListener
                        public void onDismiss(DialogInterface dialog) {
                            Drums.this.bPreset.setText(Drums.this.getPresetName(Drums.this.synth.getRecordChan()));
                        }
                    });
                }
                Drums.this.rhythmPreset.setChannel(Drums.this.synth.getRecordChan());
                Drums.this.rhythmPreset.show();
                return true;
            }
        });
        for (int i = 0; i < this.listMore.size(); i++) {
            if (this.listMore.get(i).getId() == R.id.act_drums) {
                ((Button) this.listMore.get(i)).setBackgroundResource(R.color.focused);
                this.listMore.get(i).setVisibility(8);
                this.listMore.get(i + 1).setVisibility(8);
                break;
            }
        }
        LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.action_drums, (ViewGroup) null);
        while (layout.getChildCount() > 0) {
            View child = layout.getChildAt(0);
            layout.removeView(child);
            this.listBottom.add(child);
            child.setOnClickListener(this.actionClickListener);
            if (child.getId() == R.id.drums_keyboard) {
                this.bKeyboard = (Button) child;
            } else if (child.getId() == R.id.drums_sustain) {
                this.bSustain = (Button) child;
                if (child.getBackground() != null && child.getBackground().getConstantState() != null) {
                    this.sustainBg = child.getBackground().getConstantState().newDrawable();
                }
            } else if (child.getId() == R.id.drums_lock) {
                this.bLock = (ImageButton) child;
            } else if (child.getId() == R.id.drums_auto) {
                this.bAuto = (ImageButton) child;
            }
        }
        this.handler = new Handler();
        this.layoutDrums = (LinearLayout) findViewById(R.id.drums_layout);
        this.layoutAuto = (LinearLayout) findViewById(R.id.drums_layout_auto);
        this.layoutTop = (LinearLayout) findViewById(R.id.drums_layout_top);
        this.layoutManual = (LinearLayout) findViewById(R.id.drums_layout_manual);
        this.layoutKeys = (LinearLayout) findViewById(R.id.drums_layout_keys);
        this.piano = (PianoBoard) findViewById(R.id.drums_piano);
        this.layoutStys[0] = (LinearLayout) findViewById(R.id.drums_layout_sty0);
        this.layoutStys[1] = (LinearLayout) findViewById(R.id.drums_layout_sty1);
        this.layoutStys[2] = (LinearLayout) findViewById(R.id.drums_layout_sty2);
        this.layoutStys[3] = (LinearLayout) findViewById(R.id.drums_layout_sty3);
        this.layoutStys[4] = (LinearLayout) findViewById(R.id.drums_layout_sty4);
        this.layoutBtns[0] = (LinearLayout) findViewById(R.id.drums_layout_btns0);
        this.layoutBtns[1] = (LinearLayout) findViewById(R.id.drums_layout_btns1);
        this.layoutBtns[2] = (LinearLayout) findViewById(R.id.drums_layout_btns2);
        this.layoutBtns[3] = (LinearLayout) findViewById(R.id.drums_layout_btns3);
        this.layoutBtns[4] = (LinearLayout) findViewById(R.id.drums_layout_btns4);
        LinearLayout[] layoutChords = {(LinearLayout) findViewById(R.id.drums_layout_chord0), (LinearLayout) findViewById(R.id.drums_layout_chord1), (LinearLayout) findViewById(R.id.drums_layout_chord2), (LinearLayout) findViewById(R.id.drums_layout_chord3)};
        this.btnFile = (Button) findViewById(R.id.drums_styfile);
        this.btnFile.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.Drums.7
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (Drums.this.dialogStyRef == null) {
                    Drums.this.dialogStyRef = new DialogSty(Drums.this);
                    Drums.this.dialogStyRef.setOnSelectListener(new DialogSty.OnSelectListener() { // from class: net.duceng.xmidi.Drums.7.1
                        @Override // net.duceng.xmidi.ui.DialogSty.OnSelectListener
                        public void onSelect(File f) {
                            Drums.this.loadStyFile(f);
                            for (int i2 = 0; i2 < Drums.this.btnSections.length; i2++) {
                                Drums.this.btnSections[i2].setSelected(false);
                            }
                            Drums.this.stySection = null;
                            for (int i3 = 0; i3 < Drums.this.btnChords.length; i3++) {
                                Drums.this.btnChords[i3].setSelected(false);
                            }
                            Drums.this.chord = null;
                            if (Drums.this.engine != null) {
                                Drums.this.engine.setChord(null);
                            }
                            Drums.this.dialogStyRef.dismiss();
                        }
                    });
                }
                Drums.this.dialogStyRef.show();
            }
        });
        this.btnPlay = (ImageButton) findViewById(R.id.drums_play);
        this.btnPlay.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.Drums.8
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (!Drums.this.playing) {
                    Drums.this.play();
                } else {
                    Drums.this.stop();
                }
            }
        });
        this.btnTonality = (Button) findViewById(R.id.drums_tonality);
        this.btnTonality.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.Drums.9
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (Drums.this.dialogTonalityRef == null) {
                    Drums.this.dialogTonalityRef = new DialogTonality(Drums.this, Drums.this.gChords);
                    Drums.this.dialogTonalityRef.setOnSelectListener(new DialogTonality.OnSelectListener() { // from class: net.duceng.xmidi.Drums.9.1
                        @Override // net.duceng.xmidi.ui.DialogTonality.OnSelectListener
                        public boolean onSelect(int id) {
                            Chords.Chord[] chords = Drums.this.gChords.getGChords16(id);
                            for (int i2 = 0; i2 < chords.length; i2++) {
                                Drums.this.btnChords[i2].setText(chords[i2].name);
                                Drums.this.btnChords[i2].setTag(chords[i2]);
                            }
                            Drums.this.btnTonality.setText(chords[0].name);
                            for (int i3 = 0; i3 < Drums.this.btnChords.length; i3++) {
                                if (Drums.this.btnChords[i3].isSelected()) {
                                    Drums.this.chord = (Chords.Chord) Drums.this.btnChords[i3].getTag();
                                    if (Drums.this.engine != null) {
                                        Drums.this.engine.setChord(Drums.this.chord);
                                    }
                                }
                            }
                            Drums.this.dialogTonalityRef.dismiss();
                            return true;
                        }
                    });
                }
                Drums.this.dialogTonalityRef.show();
            }
        });
        int idx = 0;
        for (int i2 = 0; i2 < this.layoutStys.length; i2++) {
            int k = 0;
            while (k < this.layoutStys[i2].getChildCount()) {
                this.btnSections[idx] = (Button) this.layoutStys[i2].getChildAt(k);
                this.btnSections[idx].setOnTouchListener(this.sectionTouchListener);
                k++;
                idx++;
            }
        }
        int idx2 = 0;
        for (int i3 = 0; i3 < layoutChords.length; i3++) {
            int k2 = 0;
            while (k2 < layoutChords[i3].getChildCount()) {
                this.btnChords[idx2] = (Button) layoutChords[i3].getChildAt(k2);
                this.btnChords[idx2].setOnTouchListener(this.chordTouchListener);
                this.btnChords[idx2].setOnLongClickListener(this.chordLongClickListener);
                k2++;
                idx2++;
            }
        }
        int idx3 = 0;
        for (int i4 = 0; i4 < this.layoutBtns.length; i4++) {
            int k3 = 0;
            while (k3 < this.layoutBtns[i4].getChildCount()) {
                this.btnDrums[idx3] = (Button) this.layoutBtns[i4].getChildAt(k3);
                this.btnDrums[idx3].setOnTouchListener(this.drumTouchListener);
                this.btnDrums[idx3].setOnLongClickListener(this.drumLongClickListener);
                k3++;
                idx3++;
            }
        }
        this.divh = findViewById(R.id.drums_divider_h0);
        this.divv = findViewById(R.id.drums_divider_v0);
        this.percussions = getResources().getStringArray(R.array.preset_percussions);
        File f = new File(String.valueOf(Synth.PATH_STY) + "/" + STY_DEFAULT);
        loadStyFile(f);
        Chords.Chord[] chords = this.gChords.getGChords16(0);
        for (int i5 = 0; i5 < chords.length; i5++) {
            this.btnChords[i5].setText(chords[i5].name);
            this.btnChords[i5].setTag(chords[i5]);
        }
        if (this.auto) {
            for (int i6 = 0; i6 < this.notes8.length; i6++) {
                this.btnDrums[i6].setText(this.percussions[this.notes8[i6]]);
                this.btnDrums[i6].setTag(Integer.valueOf(this.notes8[i6] + NOTE_BASE));
            }
        } else {
            for (int i7 = 0; i7 < this.notes15.length; i7++) {
                this.btnDrums[i7].setText(this.percussions[this.notes15[i7]]);
                this.btnDrums[i7].setTag(Integer.valueOf(this.notes15[i7] + NOTE_BASE));
            }
        }
        this.synth.setBeatListener(new Synth.BeatListener() { // metronomo / reproduccion MIDI -> arranca y sincroniza el ritmo
            @Override // net.duceng.xsynth.Synth.BeatListener
            public void onBeating(long ticks) {
                StyleEngine en = Drums.this.engine;
                if (en == null || !Drums.this.auto || Drums.this.stySection == null) {
                    return;
                }
                if (en.isRunning()) {
                    en.sync();
                } else if (Drums.this.synth.isPlaying()) {
                    Drums.this.startedBySynth = true;
                    Drums.this.handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Drums.this.play();
                        }
                    });
                }
            }
        });
        setupKeyboard();
    }

    @Override // net.duceng.xmidi.BaseApp
    protected void onMidiChanged(File f) {
        // La pantalla de ritmos no usa archivos MIDI: el titulo muestra el instrumento del canal elegido.
        this.bPreset.setText(getPresetName(this.synth.getRecordChan()));
    }

    // ------------------------------------------------------------------
    //  Teclado en vivo (canal 0): se toca encima del ritmo sin afectarlo
    // ------------------------------------------------------------------
    private void setupKeyboard() {
        this.piano.setPianoBoardListener(this.keyListener);
        this.piano.setVisibleWhiteKeys(14);                 // 14 teclas blancas a lo ancho (como en el diseno)
        this.piano.setScroll(60);
        updateKeyboardUi();
        applyKeysVisibility();
    }

    private void updateKeyboardUi() {
        if (this.bKeyboard != null) {
            this.bKeyboard.setText(getPresetName(KEY_CHAN));
        }
        this.sustainOn = this.synth.getSustain(KEY_CHAN) >= 64;
        if (this.bSustain != null) {
            if (this.sustainOn) {
                this.bSustain.setBackgroundResource(R.color.focused);
            } else if (this.sustainBg != null) {
                this.bSustain.setBackground(this.sustainBg);
            }
        }
    }

    /** Modo ritmo: secciones + acordes arriba y teclado abajo. Modo manual: solo los pads de percusion a pantalla completa. */
    private void applyKeysVisibility() {
        if (this.layoutKeys == null || this.layoutManual == null || this.layoutTop == null) {
            return;
        }
        if (this.auto) {
            this.layoutTop.setVisibility(0);
            this.layoutKeys.setVisibility(0);
            this.layoutManual.setVisibility(8);
            this.divh.setVisibility(0);
        } else {
            this.piano.releaseAll();
            this.layoutTop.setVisibility(8);
            this.layoutKeys.setVisibility(8);
            this.layoutManual.setVisibility(0);
            this.divh.setVisibility(8);
        }
        this.divv.setVisibility(8);
        if (this.bLock != null) {
            this.bLock.setEnabled(this.auto);
        }
        if (this.bSustain != null) {
            this.bSustain.setEnabled(this.auto);
        }
        if (this.bKeyboard != null) {
            this.bKeyboard.setEnabled(this.auto);
        }
    }

    private void applyMetronome() {
        if (this.engine != null) {
            this.engine.setMetronome(this.metroOn, this.synth.getBeatNote1(), this.synth.getBeatNote2(), this.synth.getBeatVelocity());
        }
    }

    private void updateBeatIcon() {
        ImageButton ib = (ImageButton) findViewById(R.id.act_beat);
        if (ib != null) {
            ib.getDrawable().setLevel(this.metroOn ? 1 : 0);
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != Importer.REQ_STY || resultCode != -1 || data == null || data.getData() == null) {
            return;
        }
        Importer.importAsync(this, data.getData(), new File(Synth.PATH_STY), new String[]{"sty"}, "sty", new Importer.Callback() {
            @Override // net.duceng.xmidi.util.Importer.Callback
            public void onResult(File dest, boolean originalRemoved, String error) {
                if (error != null || dest == null) {
                    Toast.makeText(Drums.this, error != null ? error : "No se pudo importar el estilo.", Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(Drums.this, "Estilo importado: " + dest.getName() + (originalRemoved ? " (movido a la carpeta de estilos de la app)" : " (copiado; el original no se pudo borrar)"), Toast.LENGTH_LONG).show();
                Drums.this.loadStyFile(dest);           // queda en la lista y se carga de una vez
            }
        });
    }

    @Override // android.app.Activity
    protected void onPause() {
        if (this.piano != null) {
            this.piano.releaseAll();                    // no dejar notas pegadas al salir
        }
        this.synth.keysOff(KEY_CHAN);
        super.onPause();
    }

    @Override // net.duceng.xmidi.BaseApp, android.app.Activity
    protected void onDestroy() {
        this.destroyed = true;
        this.playing = false;
        this.synth.setBeatListener(null);
        if (this.engine != null) {
            this.engine.stopAndWait(500);      // esperar al hilo ANTES de que BaseApp libere el sintetizador
        }
        super.onDestroy();
    }

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base, android.app.Activity
    protected void onStart() {
        this.synth.setRecordChan(NOTE_CHAN);
        this.synth.setStyleMix(true);
        this.metroOn = this.synth.isBeating();
        this.bPreset.setText(getPresetName(this.synth.getRecordChan()));
        updateKeyboardUi();
        super.onStart();
    }

    @Override // net.duceng.xmidi.Base, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // La app es solo horizontal: la pantalla de ritmos tiene UNA sola disposicion.
        // Pads de percusion (modo manual): filas a lo ancho de la pantalla.
        this.layoutManual.setOrientation(1);
        for (int i = 0; i < this.layoutBtns.length; i++) {
            this.layoutBtns[i].setOrientation(0);
            this.layoutBtns[i].getLayoutParams().height = 0;
            this.layoutBtns[i].getLayoutParams().width = -1;
        }
        for (int i2 = 0; i2 < this.btnDrums.length; i2++) {
            this.btnDrums[i2].getLayoutParams().height = -1;
            this.btnDrums[i2].getLayoutParams().width = 0;
        }
        this.divv.setVisibility(8);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadStyFile(File f) {
        try {
            FileInputStream in = new FileInputStream(f);
            StyFile sf;
            try {
                sf = new StyFile(in);
            } finally {
                in.close();
            }
            if (this.engine != null) {
                this.engine.stop();
            }
            this.styFile = sf;
            this.stySection = null;
            this.btnFile.setText(f.getName());
            this.synth.getMidiFile().getTempo().setMpqn(this.styFile.getTempo().getMpqn());
            applyStyleSetup();
            for (int i = 0; i < this.btnSections.length; i++) {
                this.btnSections[i].setText((CharSequence) null);
                this.btnSections[i].setTag(null);
                this.btnSections[i].setVisibility(8);
            }
            Map<String, StySection> sections = this.styFile.getSections();
            int idx = 0;
            for (String key : sections.keySet()) {
                if (idx >= this.btnSections.length) {
                    break;
                }
                this.btnSections[idx].setText(sections.get(key).getName());
                this.btnSections[idx].setTag(sections.get(key));
                this.btnSections[idx].setVisibility(0);
                idx++;
            }
            for (int i2 = 0; i2 < this.layoutStys.length; i2++) {
                if (this.layoutStys[i2].getChildAt(0).getTag() != null) {
                    this.layoutStys[i2].setVisibility(0);
                } else {
                    this.layoutStys[i2].setVisibility(8);
                }
            }
            buildEngine();
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    /**
     * Configura los canales 8-15 del sintetizador con lo que dice el propio estilo
     * (programas, bancos, volumen, pan, reverb, chorus), en vez de dejar los valores
     * por defecto de la app o los de un estilo anterior.
     */
    private void applyStyleSetup() {
        this.synth.setStyleMix(true);
        this.synth.clearOverrides(8, 15);
        this.synth.resetChannels(8, 15);
        this.baseApplied = new ArrayList<>();
        ArrayList<EventChannel> init = new ArrayList<>();
        for (MidiEvent e : this.styFile.getHead()) {
            if (e instanceof EventChannel && ((EventChannel) e).getChannel() >= 8) {
                init.add((EventChannel) e);
            }
        }
        for (MidiEvent e2 : this.styFile.getSint()) {
            if (e2 instanceof EventChannel && ((EventChannel) e2).getChannel() >= 8) {
                init.add((EventChannel) e2);
            }
        }
        // El canal 8 (Rhythm Sub) se toca por el canal 9 (bateria GM): no se configura aparte.
        // 1) bancos (el MSB 127 de Yamaha = kit de bateria XG: no existe como banco melodico)
        for (EventChannel e3 : init) {
            int ch = e3.getChannel();
            if (ch == 8 || ch == 9 || e3.getType() != 11) {
                continue;
            }
            if ((e3.getValue1() == 0 && e3.getValue2() != 127) || e3.getValue1() == 32) {
                this.synth.execEvent(e3);
                this.baseApplied.add(e3);
            }
        }
        // 2) programas
        for (EventChannel e4 : init) {
            int ch2 = e4.getChannel();
            if (ch2 != 8 && ch2 != 9 && e4.getType() == 12) {
                this.synth.execEvent(e4);
                this.baseApplied.add(e4);
            }
        }
        // 3) volumen / pan / reverb / chorus / filtros
        for (EventChannel e5 : init) {
            int ch3 = e5.getChannel();
            if (ch3 == 8 || e5.getType() != 11 || e5.getValue1() == 0 || e5.getValue1() == 32) {
                continue;
            }
            this.synth.execEvent(e5);
            this.baseApplied.add(e5);
        }
    }

    private void buildEngine() {
        if (this.engine != null) {
            this.engine.stop();
        }
        this.engine = new StyleEngine(this.styFile, new StyleEngine.Sink() {
            @Override // net.duceng.xmidi.util.StyleEngine.Sink
            public void send(EventChannel e) {
                if (Drums.this.destroyed) {
                    return;
                }
                Drums.this.synth.execEvent(e);
            }

            @Override // net.duceng.xmidi.util.StyleEngine.Sink
            public void silence() {
                if (Drums.this.destroyed) {
                    return;
                }
                Drums.this.synth.silenceChannels(8, 15);       // solo el acompanamiento; el teclado en vivo sigue
            }
        }, new StyleEngine.Host() {
            @Override // net.duceng.xmidi.util.StyleEngine.Host
            public int mpqn() {
                return Drums.this.synth.getMidiFile().getTempo().getMpqn();
            }
        }, new ThreadFactory() {
            @Override // java.util.concurrent.ThreadFactory
            public Thread newThread(final Runnable r) {
                return new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Process.setThreadPriority(-16);   // URGENT_AUDIO
                        } catch (Throwable th) {
                            // sin prioridad especial
                        }
                        r.run();
                    }
                }, "XMidi-StyleEngine");
            }
        });
        this.engine.setListener(new StyleEngine.Listener() {
            @Override // net.duceng.xmidi.util.StyleEngine.Listener
            public void onSection(final String name) {
                Drums.this.handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Drums.this.highlight(name);
                    }
                });
            }

            @Override // net.duceng.xmidi.util.StyleEngine.Listener
            public void onStopped() {
                Drums.this.playing = false;
                Drums.this.handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (Drums.this.metroOn && !Drums.this.destroyed) {
                            Drums.this.synth.setBeating(true);
                        }
                        Drums.this.btnFile.setEnabled(true);
                        Drums.this.btnTonality.setEnabled(true);
                        Drums.this.btnPlay.getDrawable().setLevel(0);
                    }
                });
            }
        });
        this.engine.setBaseSetup(this.baseApplied);
        applyMetronome();
        this.engine.setChord(this.chord);
    }

    /** Marca en pantalla el boton de la seccion que esta sonando (llamar en el hilo de UI). */
    private void highlight(String name) {
        for (int i = 0; i < this.btnSections.length; i++) {
            StySection ss = (StySection) this.btnSections[i].getTag();
            this.btnSections[i].setSelected(ss != null && ss.getName().equals(name));
            if (ss != null && ss.getName().equals(name)) {
                this.stySection = ss;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void chordSelect(Button b) {
        if (b.isSelected()) {
            b.setSelected(false);
            this.chord = null;
        } else {
            for (int i = 0; i < this.btnChords.length; i++) {
                this.btnChords[i].setSelected(false);
            }
            b.setSelected(true);
            this.chord = (Chords.Chord) b.getTag();
        }
        if (this.engine != null) {
            this.engine.setChord(this.chord);       // cambio inmediato, sin esperar al compas
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sectionSelect(String k) {
        for (int i = 0; i < this.btnSections.length; i++) {
            StySection ss = (StySection) this.btnSections[i].getTag();
            if (ss != null && ss.getName().equals(k)) {
                sectionSelect(this.btnSections[i]);
                return;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sectionSelect(Button b) {
        StySection ss = (StySection) b.getTag();
        if (ss == null) {
            return;
        }
        highlight(ss.getName());                      // respuesta visual inmediata
        if (this.engine != null && this.engine.isRunning()) {
            this.engine.requestSection(ss.getName()); // fill / cambio de seccion alineado al tiempo
        }
    }

    @Override // net.duceng.xmidi.BaseApp, net.duceng.xmidi.Base
    protected void onActionClick(View v) {
        switch (v.getId()) {
            case R.id.drums_keyboard:
                if (this.keyboardPreset == null) {
                    this.keyboardPreset = new DialogPreset(this, this.synth);
                    this.keyboardPreset.setAbsoluteVolume(true);      // volumen REAL del teclado (0-127)
                    this.keyboardPreset.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override // android.content.DialogInterface.OnDismissListener
                        public void onDismiss(DialogInterface dialog) {
                            Drums.this.updateKeyboardUi();
                        }
                    });
                }
                this.keyboardPreset.setChannel(KEY_CHAN);
                this.keyboardPreset.show();
                return;
            case R.id.drums_sustain:
                this.sustainOn = !this.sustainOn;
                this.synth.setSustain(KEY_CHAN, this.sustainOn ? 127 : 0);
                if (!this.sustainOn) {
                    this.synth.keysOff(KEY_CHAN);
                }
                updateKeyboardUi();
                return;
            case R.id.drums_lock:
                this.piano.setLocked(!this.piano.isLocked());
                this.bLock.getDrawable().setLevel(this.piano.isLocked() ? 1 : 0);
                return;
            case R.id.act_beat:
                if (this.engine != null && this.engine.isRunning()) {
                    this.metroOn = !this.metroOn;           // click del ritmo: mismo reloj, nunca se desfasa
                    applyMetronome();
                    updateBeatIcon();
                    return;
                }
                break;
            case R.id.title:
                if (this.channDialog == null) {
                    this.channDialog = new DialogChannel(this, this.synth);
                    this.channDialog.setOnSelectListener(new DialogChannel.OnSelectListener() { // from class: net.duceng.xmidi.Drums.13
                        @Override // net.duceng.xmidi.ui.DialogChannel.OnSelectListener
                        public void onSelect(int chan, int preset, String instrument) {
                            Drums.this.synth.setRecordChan((byte) chan);
                            Drums.this.bPreset.setText(Drums.this.getPresetName(chan));
                            Drums.this.channDialog.dismiss();
                        }
                    });
                }
                this.channDialog.show();
                return;
            case R.id.drums_auto /* 2131296262 */:
                this.auto = !this.auto;
                applyKeysVisibility();
                if (this.auto) {
                    this.bAuto.getDrawable().setLevel(1);
                    this.layoutTop.setVisibility(0);
                    this.divh.setVisibility(0);
                    this.divv.setVisibility(8);
                    for (int i = 0; i < this.layoutBtns.length; i++) {
                        this.layoutBtns[i].removeAllViews();
                    }
                    int idx = 0;
                    for (int i2 = 0; i2 < 2; i2++) {
                        int idx2 = idx + 1;
                        this.layoutBtns[i2].addView(this.btnDrums[idx]);
                        int idx3 = idx2 + 1;
                        this.layoutBtns[i2].addView(this.btnDrums[idx2]);
                        int idx4 = idx3 + 1;
                        this.layoutBtns[i2].addView(this.btnDrums[idx3]);
                        idx = idx4 + 1;
                        this.layoutBtns[i2].addView(this.btnDrums[idx4]);
                        this.layoutBtns[i2].setVisibility(0);
                    }
                    for (int i3 = 2; i3 < this.layoutBtns.length; i3++) {
                        this.layoutBtns[i3].setVisibility(8);
                    }
                    for (int i4 = 0; i4 < this.notes8.length; i4++) {
                        this.btnDrums[i4].setText(this.percussions[this.notes8[i4]]);
                        this.btnDrums[i4].setTag(Integer.valueOf(this.notes8[i4] + NOTE_BASE));
                    }
                    return;
                }
                this.bAuto.getDrawable().setLevel(0);
                this.layoutTop.setVisibility(8);
                this.divh.setVisibility(8);
                this.divv.setVisibility(8);
                for (int i5 = 0; i5 < this.layoutBtns.length; i5++) {
                    this.layoutBtns[i5].removeAllViews();
                }
                int i6 = 0;
                int idx5 = 0;
                while (i6 < this.layoutBtns.length) {
                    int idx6 = idx5 + 1;
                    this.layoutBtns[i6].addView(this.btnDrums[idx5]);
                    int idx7 = idx6 + 1;
                    this.layoutBtns[i6].addView(this.btnDrums[idx6]);
                    this.layoutBtns[i6].addView(this.btnDrums[idx7]);
                    this.layoutBtns[i6].setVisibility(0);
                    i6++;
                    idx5 = idx7 + 1;
                }
                for (int i7 = 0; i7 < this.notes15.length; i7++) {
                    this.btnDrums[i7].setText(this.percussions[this.notes15[i7]]);
                    this.btnDrums[i7].setTag(Integer.valueOf(this.notes15[i7] + NOTE_BASE));
                }
                return;
            case R.id.act_play /* 2131296279 */:
                if (this.synth.isPlaying()) {
                    this.btnFile.setEnabled(true);
                    this.btnTonality.setEnabled(true);
                    this.btnPlay.setEnabled(true);
                } else {
                    this.btnFile.setEnabled(false);
                    this.btnTonality.setEnabled(false);
                    this.btnPlay.setEnabled(false);
                }
                if (this.auto) {
                    if (this.stySection == null && this.styFile != null) {
                        String mark = this.styFile.containsSection("Intro A") ? "Intro A" : "Main A";
                        sectionSelect(mark);
                    }
                }
                break;
        }
        super.onActionClick(v);
        if (v.getId() == R.id.act_beat) {
            this.metroOn = this.synth.isBeating();
        }
        if (v.getId() == R.id.act_play && !this.synth.isPlaying() && this.startedBySynth && this.engine != null) {
            this.engine.stop();         // el ritmo que arranco con el reloj del MIDI se detiene con el MIDI
            this.startedBySynth = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void play() {
        if (this.styFile == null || this.engine == null || this.engine.isRunning()) {
            return;
        }
        this.btnFile.setEnabled(false);
        this.btnTonality.setEnabled(false);
        this.btnPlay.getDrawable().setLevel(3);
        String name;
        if (this.stySection != null) {
            name = this.stySection.getName();
        } else {
            name = this.styFile.containsSection("Intro A") ? "Intro A" : "Main A";
            highlight(name);
        }
        this.playing = true;
        if (this.synth.isBeating()) {
            this.synth.setBeating(false);            // el click pasa al reloj del ritmo
            this.metroOn = true;
        }
        applyMetronome();
        updateBeatIcon();
        this.engine.setChord(this.chord);
        this.engine.start(name);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stop() {
        this.startedBySynth = false;
        if (this.engine != null) {
            this.engine.stop();
        }
        this.playing = false;
        this.synth.silenceChannels(8, 15);
        if (this.metroOn) {
            this.synth.setBeating(true);               // el metronomo sigue "activo" aunque el ritmo se detenga
        }
        this.handler.post(new Runnable() {
            @Override
            public void run() {
                Drums.this.btnFile.setEnabled(true);
                Drums.this.btnTonality.setEnabled(true);
                Drums.this.btnPlay.getDrawable().setLevel(0);
            }
        });
    }
}
