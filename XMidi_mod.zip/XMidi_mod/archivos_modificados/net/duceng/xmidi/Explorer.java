package net.duceng.xmidi;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.io.File;
import net.duceng.xmidi.ui.DialogFile;
import net.duceng.xmidi.util.AdapterExplorer;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes.dex */
public class Explorer extends Base {
    private AdapterExplorer fileAdapter;
    private ListView listv;
    protected Synth synth;

    @Override // net.duceng.xmidi.Base, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Synth.configurePaths(this);
        this.synth = Synth.getInstance();
        setTop(true);
        setContentView(R.layout.explorer);
        LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.menu_fixed, (ViewGroup) null);
        while (layout.getChildCount() > 0) {
            View child = layout.getChildAt(0);
            layout.removeView(child);
            this.listMore.add(child);
            child.setOnClickListener(this.menuClickListener);
        }
        LinearLayout mainLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.action_explorer, (ViewGroup) null);
        while (mainLayout.getChildCount() > 0) {
            View child2 = mainLayout.getChildAt(0);
            mainLayout.removeView(child2);
            this.listBottom.add(child2);
            child2.setOnClickListener(this.actionClickListener);
        }
        this.listv = (ListView) findViewById(R.id.explorer_list);
        this.listv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.Explorer.1
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View view, int position, long id) {
                File f = Explorer.this.fileAdapter.getItem(position);
                if (f.isDirectory() && f.canExecute()) {
                    Explorer.this.fileAdapter.setCurrentPath(f);
                } else if (f.isFile() && f.canRead()) {
                    Intent intent = new Intent(Explorer.this, (Class<?>) Keyboard.class);
                    intent.putExtra("file", f);
                    Explorer.this.startActivity(intent);
                }
            }
        });
        this.listv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { // from class: net.duceng.xmidi.Explorer.2
            private DialogFile df;

            @Override // android.widget.AdapterView.OnItemLongClickListener
            public boolean onItemLongClick(AdapterView<?> av, View view, int position, long id) {
                if (this.df == null) {
                    this.df = new DialogFile(Explorer.this, Explorer.this.fileAdapter);
                }
                this.df.setFile(Explorer.this.fileAdapter.getItem(position));
                this.df.show();
                return true;
            }
        });
    }

    private boolean startedUp = false;
    private boolean askedAccess = false;

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        if (this.startedUp) {
            return;
        }
        Synth.configurePaths(this);
        if (!Synth.hasSharedStorageAccess(this) && !this.askedAccess) {
            this.askedAccess = true;
            requestStorageAccess();
            return;
        }
        this.startedUp = true;
        startUp();
    }

    private void requestStorageAccess() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            try {
                Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        android.net.Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        } else if (android.os.Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, 1);
        }
    }

    private void startUp() {
        boolean synth_init = Synth.isInitialized(this);
        if (synth_init) {
            this.synth.init(this);
            this.fileAdapter = new AdapterExplorer(this, new File(Synth.PATH_MIDI));
            this.listv.setAdapter((ListAdapter) this.fileAdapter);
        } else {
            final ProgressDialog progress = new ProgressDialog(this);
            progress.setMessage(getString(R.string.process_init));
            progress.show();
            final Handler handler = new Handler(new Handler.Callback() { // from class: net.duceng.xmidi.Explorer.3
                @Override // android.os.Handler.Callback
                public boolean handleMessage(Message msg) {
                    Explorer.this.fileAdapter = new AdapterExplorer(Explorer.this, new File(Synth.PATH_MIDI));
                    Explorer.this.listv.setAdapter((ListAdapter) Explorer.this.fileAdapter);
                    progress.dismiss();
                    return true;
                }
            });
            Thread t = new Thread(new Runnable() { // from class: net.duceng.xmidi.Explorer.4
                @Override // java.lang.Runnable
                public void run() {
                    Explorer.this.synth.init(Explorer.this);
                    Message msg = handler.obtainMessage();
                    msg.sendToTarget();
                }
            });
            t.start();
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        this.synth.freeInstance();
        super.onDestroy();
    }

    @Override // net.duceng.xmidi.Base, android.app.Activity
    protected void onStart() {
        if (this.synth.getFile() != null) {
            this.title.setText(this.synth.getFile().getName());
        } else {
            this.title.setText(R.string.app_name);
        }
        super.onStart();
    }

    @Override // android.app.Activity
    public boolean onPrepareOptionsMenu(Menu menu) {
        showMenu();
        return false;
    }

    @Override // net.duceng.xmidi.Base
    protected void onActionClick(View v) {
        switch (v.getId()) {
            case R.id.explorer_keyboard /* 2131296264 */:
                Intent intent = new Intent(this, (Class<?>) Keyboard.class);
                startActivity(intent);
                break;
            case R.id.explorer_guitar /* 2131296265 */:
                Intent intent2 = new Intent(this, (Class<?>) Guitar.class);
                startActivity(intent2);
                break;
            case R.id.explorer_drums /* 2131296266 */:
                Intent intent3 = new Intent(this, (Class<?>) Drums.class);
                startActivity(intent3);
                break;
            case R.id.explorer_metronome /* 2131296267 */:
                Intent intent4 = new Intent(this, (Class<?>) Metronome.class);
                startActivity(intent4);
                break;
            default:
                super.onActionClick(v);
                break;
        }
    }
}
