package net.duceng.xmidi.ui;

import net.duceng.xmidi.util.Importer;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.io.File;
import net.duceng.xmidi.util.AdapterExplorer;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes.dex */
public class DialogSty extends XDialog {
    private AdapterExplorer af;
    private OnSelectListener onSelectListener;

    public interface OnSelectListener {
        void onSelect(File file);
    }

    public DialogSty(Context context) {
        super(context);
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.select_file);
        ListView lv = (ListView) getLayoutInflater().inflate(R.layout.list, (ViewGroup) null);
        this.af = new AdapterExplorer(getContext(), new File(Synth.PATH_STY));
        lv.setAdapter((ListAdapter) this.af);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.ui.DialogSty.1
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View view, int pos, long id) {
                File f = DialogSty.this.af.getItem(pos);
                if (f.isDirectory() && f.canExecute()) {
                    DialogSty.this.af.setCurrentPath(f);
                } else {
                    if (!f.isFile() || !f.canRead() || DialogSty.this.onSelectListener == null) {
                        return;
                    }
                    DialogSty.this.onSelectListener.onSelect(f);
                }
            }
        });
        setContentView(lv);
        addButton(R.string.import_style, new View.OnClickListener() { // importar un .sty desde la memoria del telefono
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (DialogSty.this.getContext() instanceof Activity) {
                    ((Activity) DialogSty.this.getContext()).startActivityForResult(Importer.pickIntent(), Importer.REQ_STY);
                }
            }
        });
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onStart() {
        this.af.notifyDataSetChanged();
        super.onStart();
    }

    public void setOnSelectListener(OnSelectListener l) {
        this.onSelectListener = l;
    }
}
