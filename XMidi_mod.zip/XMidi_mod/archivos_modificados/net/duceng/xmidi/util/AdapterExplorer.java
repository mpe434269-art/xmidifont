package net.duceng.xmidi.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.File;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes.dex */
public class AdapterExplorer extends BaseAdapter {
    private Context context;
    private File currentPath;
    private File rootPath;
    private boolean isRoot = true;
    private ArrayList<File> files = new ArrayList<>();
    private DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);

    private static class CompratorFileByName implements Comparator<File> {
        private CompratorFileByName() {
        }

        /* synthetic */ CompratorFileByName(CompratorFileByName compratorFileByName) {
            this();
        }

        @Override // java.util.Comparator
        public int compare(File lhs, File rhs) {
            if (lhs.isDirectory() && rhs.isFile()) {
                return -1;
            }
            if (lhs.isFile() && rhs.isDirectory()) {
                return 1;
            }
            return lhs.getName().compareTo(rhs.getName());
        }
    }

    public AdapterExplorer(Context context, File rootPath) {
        this.context = context;
        this.rootPath = rootPath;
        this.currentPath = rootPath;
        File[] fs = this.currentPath.listFiles();
        if (fs != null) {
            Arrays.sort(fs, new CompratorFileByName(null));
            this.files.addAll(Arrays.asList(fs));
        }
    }

    public void setCurrentPath(File f) {
        this.currentPath = f;
        this.files.clear();
        if (!this.rootPath.getAbsolutePath().equals(this.currentPath.getAbsolutePath())) {
            this.files.add(this.currentPath.getParentFile());
            this.isRoot = false;
        } else {
            this.isRoot = true;
        }
        File[] fs = this.currentPath.listFiles();
        if (fs != null) {
            Arrays.sort(fs, new CompratorFileByName(null));
            this.files.addAll(Arrays.asList(fs));
        }
        super.notifyDataSetChanged();
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.files.size();
    }

    @Override // android.widget.Adapter
    public File getItem(int position) {
        return this.files.get(position);
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return position;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View view, ViewGroup parent) {
        if (view == null) {
            view = LayoutInflater.from(this.context).inflate(R.layout.list_item_file, (ViewGroup) null);
        }
        StringBuffer detail = new StringBuffer();
        if (this.files.get(position).isDirectory()) {
            if (position == 0 && !this.isRoot) {
                ((TextView) view.findViewById(R.id.list_item_file_name)).setText("..");
            } else {
                ((TextView) view.findViewById(R.id.list_item_file_name)).setText(this.files.get(position).getName());
            }
            ((ImageView) view.findViewById(R.id.list_item_file_image)).setImageResource(R.drawable.folder);
        } else {
            ((ImageView) view.findViewById(R.id.list_item_file_image)).setImageResource(R.drawable.file);
            ((TextView) view.findViewById(R.id.list_item_file_name)).setText(this.files.get(position).getName());
            long fileS = this.files.get(position).length();
            DecimalFormat df = new DecimalFormat("#");
            if (fileS < 1024) {
                detail.append("1KB ");
            } else {
                detail.append(String.valueOf(df.format(fileS / 1024.0d)) + "KB ");
            }
        }
        Date d = new Date(this.files.get(position).lastModified());
        detail.append(this.df.format(d));
        ((TextView) view.findViewById(R.id.list_item_file_detail)).setText(detail);
        return view;
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        setCurrentPath(this.currentPath);
    }
}
