package net.duceng.xmidi.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

/**
 * Logica pura de importacion (sin Android): nombres seguros, extensiones, nombre unico, copia y validacion
 * del contenido (un .sty debe ser MIDI "MThd"; un .sf2 debe ser RIFF/"sfbk").
 */
public final class ImportCore {
    private ImportCore() {
    }

    public static String sanitizeName(String name) {
        if (name == null) {
            return "importado.bin";
        }
        String n = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        while (n.startsWith(".")) {
            n = n.substring(1);
        }
        return n.length() == 0 ? "importado.bin" : n;
    }

    public static boolean hasExtension(String name, String[] exts) {
        String lower = name.toLowerCase(Locale.ROOT);
        for (String e : exts) {
            if (lower.endsWith("." + e.toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        return false;
    }

    /** Si ya existe un archivo con ese nombre, devuelve "nombre (1).ext", "nombre (2).ext"... */
    public static File uniqueFile(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) {
            return f;
        }
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i < 1000; i++) {
            File c = new File(dir, base + " (" + i + ")" + ext);
            if (!c.exists()) {
                return c;
            }
        }
        return new File(dir, base + "_" + System.currentTimeMillis() + ext);
    }

    public static long copy(InputStream in, File dest) throws IOException {
        long total = 0;
        FileOutputStream out = new FileOutputStream(dest);
        try {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                total += n;
            }
            out.flush();
            out.getFD().sync();
        } finally {
            out.close();
        }
        return total;
    }

    /** null = valido; si no, el motivo. kind: "sty" o "sf2". */
    public static String validate(File f, String kind) {
        if (f.length() < 64) {
            return "El archivo esta vacio o es demasiado pequeno.";
        }
        byte[] h = new byte[12];
        FileInputStream in = null;
        try {
            in = new FileInputStream(f);
            if (in.read(h) < 12) {
                return "El archivo no se pudo leer.";
            }
        } catch (IOException e) {
            return "El archivo no se pudo leer: " + e.getMessage();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignored) {
                    // nada
                }
            }
        }
        if ("sty".equals(kind)) {
            if (h[0] == 'M' && h[1] == 'T' && h[2] == 'h' && h[3] == 'd') {
                return null;
            }
            return "No parece un estilo Yamaha (.sty) valido.";
        }
        if ("sf2".equals(kind)) {
            if (h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F' && h[8] == 's' && h[9] == 'f' && h[10] == 'b' && h[11] == 'k') {
                return null;
            }
            return "No parece un soundfont (.sf2) valido.";
        }
        return null;
    }
}
