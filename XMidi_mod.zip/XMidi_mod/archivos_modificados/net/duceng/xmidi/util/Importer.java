package net.duceng.xmidi.util;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.io.File;
import java.io.InputStream;

/**
 * Importa un estilo (.sty) o un soundfont (.sf2) desde la memoria del telefono (Descargas, tarjeta SD, nube...)
 * a la carpeta de la app. Usa el selector de archivos del sistema, copia en segundo plano (los soundfonts pesan
 * cientos de MB), valida el contenido y, si el sistema lo permite, borra el original (= "mover").
 */
public final class Importer {
    public static final int REQ_STY = 4101;
    public static final int REQ_SF2 = 4102;

    public interface Callback {
        /** error != null => fallo; si no, dest es el archivo ya dentro de la app. */
        void onResult(File dest, boolean originalRemoved, String error);
    }

    private Importer() {
    }

    public static Intent pickIntent() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        return i;
    }

    private static String displayName(Activity act, Uri uri) {
        String name = null;
        Cursor c = null;
        try {
            c = act.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                name = c.getString(0);
            }
        } catch (Exception ignored) {
            // se prueba con la ruta
        } finally {
            if (c != null) {
                c.close();
            }
        }
        if (name == null) {
            String p = uri.getLastPathSegment();
            if (p != null) {
                int i = p.lastIndexOf('/');
                name = i >= 0 ? p.substring(i + 1) : p;
            }
        }
        return name;
    }

    public static void importAsync(final Activity act, final Uri uri, final File dir, final String[] exts, final String kind, final Callback cb) {
        final String name = ImportCore.sanitizeName(displayName(act, uri));
        if (!ImportCore.hasExtension(name, exts)) {
            cb.onResult(null, false, "Tipo de archivo no valido: " + name);
            return;
        }
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(40, 30, 40, 30);
        box.addView(new ProgressBar(act));
        TextView tv = new TextView(act);
        tv.setText("  Importando " + name + "...");
        tv.setTextSize(16);
        box.addView(tv);
        AlertDialog tmp = null;
        try {
            tmp = new AlertDialog.Builder(act).setView(box).setCancelable(false).create();
            tmp.show();
        } catch (Exception e) {
            tmp = null;
        }
        final AlertDialog progress = tmp;
        new Thread(new Runnable() {
            @Override
            public void run() {
                File dest = null;
                File part = null;
                String error = null;
                boolean removed = false;
                InputStream in = null;
                try {
                    if (!dir.exists() && !dir.mkdirs()) {
                        throw new java.io.IOException("No hay acceso a la carpeta de la app (" + dir.getAbsolutePath() + ").");
                    }
                    in = act.getContentResolver().openInputStream(uri);
                    if (in == null) {
                        throw new java.io.IOException("No se pudo abrir el archivo elegido.");
                    }
                    part = new File(dir, ".importando_" + System.nanoTime() + ".part");
                    ImportCore.copy(in, part);
                    String bad = ImportCore.validate(part, kind);
                    if (bad != null) {
                        error = bad;
                    } else {
                        dest = ImportCore.uniqueFile(dir, name);
                        if (!part.renameTo(dest)) {
                            throw new java.io.IOException("No se pudo guardar " + dest.getName());
                        }
                        part = null;
                        try {
                            if (DocumentsContract.isDocumentUri(act, uri)) {
                                removed = DocumentsContract.deleteDocument(act.getContentResolver(), uri);
                            } else if ("file".equals(uri.getScheme()) && uri.getPath() != null) {
                                removed = new File(uri.getPath()).delete();
                            }
                        } catch (Exception ignored) {
                            removed = false;       // el sistema no deja borrar el original: queda como copia
                        }
                    }
                } catch (Exception e) {
                    error = "No se pudo importar: " + e.getMessage();
                } finally {
                    try {
                        if (in != null) {
                            in.close();
                        }
                    } catch (Exception ignored) {
                        // nada
                    }
                    if (part != null && part.exists()) {
                        part.delete();               // no dejar restos
                    }
                }
                final File fDest = error == null ? dest : null;
                final boolean fRemoved = removed;
                final String fError = error;
                act.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (progress != null && progress.isShowing()) {
                                progress.dismiss();
                            }
                        } catch (Exception ignored) {
                            // la pantalla ya se cerro
                        }
                        cb.onResult(fDest, fRemoved, fError);
                    }
                });
            }
        }, "XMidi-Import").start();
    }
}
