package net.duceng.xmidi.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.locks.LockSupport;
import net.duceng.midi.EventChannel;
import net.duceng.midi.StyFile;
import net.duceng.midi.StySection;

/**
 * Secuenciador de estilos (.sty) estilo "arranger".
 *
 * - Reloj propio en tiempo ABSOLUTO (System.nanoTime) con acumulacion de ticks:
 *   no hay Thread.sleep() por nota ni deriva acumulada, y un cambio de tempo
 *   se aplica al instante.
 * - Fill-in / cambio de seccion: se ejecutan EN EL MOMENTO de pulsar, sobre la
 *   misma posicion del compas (la bateria del fill suena alineada al tiempo,
 *   solo se oye lo que "queda" del compas del fill, como en un Yamaha PSR-SX).
 *   Si se pulsa en la ultima media negra del compas, el fill entra en el
 *   siguiente compas (para que no suene recortado).
 * - Cambio de acorde: inmediato (no espera al siguiente compas). Las notas
 *   sostenidas (pads, bajo) se reinician sobre el nuevo acorde.
 *
 * Todos los metodos publicos son seguros desde cualquier hilo.
 */
public final class StyleEngine implements Runnable {

    public interface Sink {
        void send(EventChannel e);
        void silence();
    }

    public interface Host {
        /** microsegundos por negra (tempo actual) */
        int mpqn();
    }

    public interface Listener {
        void onSection(String name);
        void onStopped();
    }

    private static final int DRUM = 9;
    private static final long MIN_PARK_NS = 20000L;
    private static final long MAX_PARK_NS = 5000000L;

    private final StyFile sty;
    private final Sink sink;
    private final Host host;
    private final ThreadFactory factory;
    private final int res;
    private final int barTicks;
    private final ConcurrentLinkedQueue<Runnable> cmds = new ConcurrentLinkedQueue<>();
    private final boolean[] sounding = new boolean[16 * 128];

    private volatile boolean running = false;
    private volatile Thread thread;
    private volatile Listener listener;
    private volatile Chords.Chord chordV;
    private volatile String startName;

    // estado: solo hilo del motor
    private StySection section;
    private int barIdx;
    private ArrayList<EventChannel> bar = new ArrayList<>();
    private int cursor;
    private double tickPos;
    private String afterName;
    private String pendingName;
    private String pendingAfter;
    private Chords.Chord chordApplied;
    private String lastNotified;
    private long lastResyncNs = 0L;
    // --- ajustes base del estilo (SInt) y estado enviado: al entrar a una seccion se restaura lo que la seccion anterior cambio
    private final ArrayList<EventChannel> baseSetup = new ArrayList<>();
    private final Map<String, Integer> lastSent = new HashMap<>();
    // --- metronomo sincronizado con el ritmo
    private volatile boolean metroOn = false;
    private volatile int metroNoteAccent = 34;
    private volatile int metroNote = 33;
    private volatile int metroVel = 75;
    private double nextBeatTick = 0.0;
    private int beatCount = 0;
    // --- relleno a mitad de compas: la seccion anterior sigue sonando en los canales que el relleno no define
    private StySection prevSection;
    private int prevBarIdx;
    private boolean mergePrev = false;
    private final boolean[] mergeDefined = new boolean[16];
    private final long[] lastOnNs = new long[16 * 128];
    private final ArrayList<long[]> lateOffs = new ArrayList<>();   // {vencimiento ns, canal, nota, creadoNs}

    public StyleEngine(StyFile sty, Sink sink, Host host, ThreadFactory factory) {
        this.sty = sty;
        this.sink = sink;
        this.host = host;
        this.factory = factory;
        this.res = sty.getResolution();
        this.barTicks = sty.getResolution() * sty.getTimeSignature().getNumerator();
    }

    // ------------------------------------------------------------ API
    public void setListener(Listener l) {
        this.listener = l;
    }

    public boolean isRunning() {
        return this.running;
    }

    public synchronized void start(String sectionName) {
        if (this.running) {
            requestSection(sectionName);
            return;
        }
        this.startName = sectionName;
        this.running = true;
        Thread t = this.factory != null ? this.factory.newThread(this) : new Thread(this, "StyleEngine");
        this.thread = t;
        t.start();
    }

    public void stop() {
        this.running = false;
        wake();
    }

    /** Ajustes iniciales del estilo (banco/programa/controles de los canales 8-15), ya aplicados al sintetizador. */
    public void setBaseSetup(final List<EventChannel> events) {
        final ArrayList<EventChannel> copy = new ArrayList<>(events);
        post(new Runnable() {
            @Override
            public void run() {
                StyleEngine.this.baseSetup.clear();
                StyleEngine.this.baseSetup.addAll(copy);
                StyleEngine.this.lastSent.clear();
                for (EventChannel e : copy) {
                    StyleEngine.this.lastSent.put(keyOf(e), valueOf(e));
                }
            }
        });
    }

    public void setMetronome(boolean on, int accentNote, int note, int vel) {
        this.metroNoteAccent = accentNote;
        this.metroNote = note;
        this.metroVel = vel;
        this.metroOn = on;
    }

    public boolean isMetronomeOn() {
        return this.metroOn;
    }

    private static String keyOf(EventChannel e) {
        return e.getType() == 12 ? ("P" + e.getChannel()) : ("C" + e.getChannel() + ":" + e.getValue1());
    }

    private static int valueOf(EventChannel e) {
        return e.getType() == 12 ? e.getValue1() : e.getValue2();
    }

    /** Detiene y ESPERA a que el hilo termine (usar al cerrar la pantalla, antes de liberar el sintetizador). */
    public void stopAndWait(long ms) {
        this.running = false;
        Thread t = this.thread;
        wake();
        if (t != null && t != Thread.currentThread()) {
            try {
                t.join(ms);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public void setChord(Chords.Chord c) {
        this.chordV = c;
        post(new Runnable() {
            @Override
            public void run() {
                applyChord();
            }
        });
    }

    public void requestSection(final String name) {
        post(new Runnable() {
            @Override
            public void run() {
                applySectionRequest(name);
            }
        });
    }

    /** Alinea la fase de pulso con un reloj externo (p.ej. el metronomo de Synth). */
    public void sync() {
        post(new Runnable() {
            @Override
            public void run() {
                double p = tickPos % res;
                if (p > res / 2.0) {
                    p -= res;
                }
                if (Math.abs(p) <= res / 8.0) {
                    tickPos -= p;
                }
            }
        });
    }

    private void post(Runnable r) {
        this.cmds.add(r);
        wake();
    }

    private void wake() {
        Thread t = this.thread;
        if (t != null) {
            LockSupport.unpark(t);
        }
    }

    // ------------------------------------------------------------ helpers de nombres
    private static boolean isFill(String n) {
        return n.startsWith("Fill In");
    }

    private static boolean isIntro(String n) {
        return n.startsWith("Intro");
    }

    private static boolean isEnding(String n) {
        return n.startsWith("Ending");
    }

    private static boolean isMain(String n) {
        return n.startsWith("Main");
    }

    private static char last(String n) {
        return n.charAt(n.length() - 1);
    }

    private String mainFor(char letter) {
        String m = "Main " + letter;
        if (this.sty.containsSection(m)) {
            return m;
        }
        if (this.sty.containsSection("Main A")) {
            return "Main A";
        }
        for (String k : this.sty.getSections().keySet()) {
            if (isMain(k)) {
                return k;
            }
        }
        return null;
    }

    private StySection pick(String name) {
        StySection s = name == null ? null : this.sty.getSection(name);
        if (s == null) {
            String m = mainFor('A');
            s = m != null ? this.sty.getSection(m) : null;
        }
        if (s == null && !this.sty.getSections().isEmpty()) {
            s = this.sty.getSections().values().iterator().next();
        }
        return s;
    }

    // ------------------------------------------------------------ nucleo
    @Override
    public void run() {
        try {
            long last = System.nanoTime();
            begin(this.startName);
            while (this.running && this.section != null) {
              try {
                drain();
                long now = System.nanoTime();
                int mpqn = this.host.mpqn();
                if (mpqn <= 0) {
                    mpqn = 500000;
                }
                this.tickPos += ((now - last) * (double) this.res) / (mpqn * 1000.0);
                last = now;
                fireDue();
                fireMetronome();
                fireLateOffs(now);
                if (this.tickPos >= this.barTicks) {
                    this.tickPos -= this.barTicks;
                    this.nextBeatTick = 0.0;
                    this.beatCount = 0;
                    advanceBar();
                    continue;
                }
                double next = this.cursor < this.bar.size() ? this.bar.get(this.cursor).getTick() : this.barTicks;
                if (next > this.barTicks) {
                    next = this.barTicks;
                }
                long ns = (long) (((next - this.tickPos) * mpqn * 1000.0) / this.res);
                if (ns < MIN_PARK_NS) {
                    ns = MIN_PARK_NS;
                }
                if (ns > MAX_PARK_NS) {
                    ns = MAX_PARK_NS;
                }
                LockSupport.parkNanos(ns);
              } catch (Throwable t) {                      // una excepcion NUNCA debe tumbar la app
                System.err.println("StyleEngine: " + t);
                this.running = false;
              }
            }
        } finally {
            this.running = false;
            try {
                this.sink.silence();
            } catch (Throwable t2) {
                // el sintetizador ya pudo haberse liberado
            }
            java.util.Arrays.fill(this.sounding, false);
            this.lateOffs.clear();
            Listener l = this.listener;
            if (l != null) {
                l.onStopped();
            }
        }
    }

    /** Click del metronomo EXACTAMENTE en cada pulso del ritmo (mismo reloj: no se desfasa). */
    private void fireMetronome() {
        while (this.nextBeatTick < this.barTicks && this.tickPos >= this.nextBeatTick) {
            if (this.metroOn) {
                boolean accent = this.beatCount == 0;
                this.sink.send(new EventChannel(0, (byte) 9, (byte) DRUM, (byte) (accent ? this.metroNoteAccent : this.metroNote), (byte) this.metroVel));
            }
            this.beatCount++;
            this.nextBeatTick += this.res;
        }
    }

    private void fireLateOffs(long now) {
        for (int i = this.lateOffs.size() - 1; i >= 0; i--) {
            long[] o = this.lateOffs.get(i);
            if (now >= o[0]) {
                this.lateOffs.remove(i);
                int k = (((int) o[1]) << 7) | ((int) o[2]);
                if (this.lastOnNs[k] > o[3]) {
                    continue;                      // la nota se volvio a tocar despues: no apagarla
                }
                this.sounding[k] = false;
                this.sink.send(new EventChannel(0, (byte) 8, (byte) o[1], (byte) o[2], (byte) 0));
            }
        }
    }

    /**
     * Al ENTRAR a una seccion: ajustes base del estilo + ajustes propios de la seccion (los de la seccion mandan).
     * Solo se envia lo que difiere de lo ultimo enviado. Asi un Intro puede poner "Orchestra Hit" en un canal y al
     * pasar al Main ese canal vuelve a su instrumento original (como en un Yamaha), y cada Main (A/B/C/D) puede
     * traer sus propios programas y niveles.
     */
    private void applySectionSetup() {
        if (this.section == null) {
            return;
        }
        LinkedHashMap<String, EventChannel> banks = new LinkedHashMap<>();
        LinkedHashMap<String, EventChannel> progs = new LinkedHashMap<>();
        LinkedHashMap<String, EventChannel> ctrls = new LinkedHashMap<>();
        for (EventChannel e : this.baseSetup) {
            classify(e, banks, progs, ctrls);
        }
        for (EventChannel e2 : this.section.getSetupEvents()) {
            classify(e2, banks, progs, ctrls);
        }
        sendChanged(banks);
        sendChanged(progs);
        sendChanged(ctrls);
    }

    private static void classify(EventChannel e, Map<String, EventChannel> banks, Map<String, EventChannel> progs, Map<String, EventChannel> ctrls) {
        if (e.getType() == 12) {
            progs.put(keyOf(e), e);
        } else if (e.getType() == 11 && (e.getValue1() == 0 || e.getValue1() == 32)) {
            banks.put(keyOf(e), e);
        } else if (e.getType() == 11) {
            ctrls.put(keyOf(e), e);
        }
    }

    private void sendChanged(Map<String, EventChannel> m) {
        for (Map.Entry<String, EventChannel> en : m.entrySet()) {
            Integer old = this.lastSent.get(en.getKey());
            int v = valueOf(en.getValue());
            if (old == null || old.intValue() != v) {
                this.lastSent.put(en.getKey(), Integer.valueOf(v));
                this.sink.send(en.getValue());
            }
        }
    }

    private void drain() {
        Runnable r;
        while ((r = this.cmds.poll()) != null) {
            r.run();
        }
    }

    private void fireDue() {
        while (this.cursor < this.bar.size() && this.bar.get(this.cursor).getTick() <= this.tickPos) {
            fire(this.bar.get(this.cursor++));
        }
    }

    /** true si el compas siguiente es de la MISMA seccion y sin cambios pendientes (las notas largas siguen sonando). */
    private boolean continuesNextBar() {
        return this.pendingName == null && this.section != null && this.barIdx + 1 < this.section.sizeBars();
    }

    private void fire(EventChannel e) {
        int ch = e.getChannel() & 15;
        if (e.carry == 1 && continuesNextBar()) {
            return;                                        // la nota larga continua en el compas siguiente: no cortar
        }
        if (e.carry == 2 && ch != DRUM && this.sounding[(ch << 7) | (e.getValue1() & 127)]) {
            return;                                        // ya esta sonando: no volver a atacar (strings/pads continuos)
        }
        if (e.getType() == 9 && e.getValue2() > 0) {
            if (ch != DRUM) {
                this.sounding[(ch << 7) | (e.getValue1() & 127)] = true;
                this.lastOnNs[(ch << 7) | (e.getValue1() & 127)] = System.nanoTime();
            }
        } else if (e.getType() == 8 || (e.getType() == 9 && e.getValue2() == 0)) {
            this.sounding[(ch << 7) | (e.getValue1() & 127)] = false;
        }
        this.sink.send(e);
    }

    private void begin(String name) {
        this.chordApplied = this.chordV;
        this.section = pick(name);
        this.barIdx = 0;
        this.tickPos = 0.0;
        this.nextBeatTick = 0.0;
        this.beatCount = 0;
        this.afterName = null;
        this.pendingName = null;
        if (this.section == null) {
            return;
        }
        applySectionSetup();
        this.bar = this.section.getEvents(0, this.chordApplied);
        this.cursor = 0;
        notifySection();
    }

    private void notifySection() {
        Listener l = this.listener;
        if (l != null && this.section != null) {
            l.onSection(this.section.getName());
        }
    }

    private void advanceBar() {
        this.mergePrev = false;
        this.barIdx++;
        boolean sectionChanged = false;
        if (this.pendingName != null) {
            sectionChanged = true;
            StySection s = pick(this.pendingName);
            this.afterName = this.pendingAfter;
            this.pendingName = null;
            this.pendingAfter = null;
            this.section = s;
            this.barIdx = 0;
            notifySection();
        } else if (this.barIdx >= this.section.sizeBars()) {
            sectionChanged = true;
            this.barIdx = 0;
            String cur = this.section.getName();
            if (isEnding(cur)) {
                this.running = false;
                return;
            }
            if (isIntro(cur) || isFill(cur)) {
                String dest = this.afterName != null ? this.afterName : mainFor(last(cur));
                this.afterName = null;
                this.section = pick(dest);
                notifySection();
            }
        }
        if (sectionChanged) {
            silenceMelodic();
            applySectionSetup();
        }
        this.bar = this.section.getEvents(this.barIdx, this.chordApplied);
        this.cursor = 0;
    }

    private void applyChord() {
        Chords.Chord c = this.chordV;
        if (this.section == null || c == this.chordApplied) {
            return;
        }
        this.chordApplied = c;
        resync();
    }

    /**
     * Reconstruye el compas actual (acorde / seccion nuevos) sin cortes bruscos:
     * 1) las notas nuevas entran primero (solapadas),
     * 2) las notas que siguen siendo iguales NO se vuelven a atacar,
     * 3) solo se apagan las que ya no corresponden.
     */
    private void resync() {
        long nowNs = System.nanoTime();
        // cambios de acorde muy seguidos: las notas re-atacadas entran mas suaves (evita el "golpe")
        double velScale = (nowNs - this.lastResyncNs) < 250000000L ? 0.55 : 0.8;
        this.lastResyncNs = nowNs;
        boolean[] old = this.sounding.clone();
        this.bar = buildBar();
        this.cursor = firstIndexAfter(this.tickPos);
        boolean[] keep = new boolean[16 * 128];
        boolean fired = false;
        if (this.chordApplied != null) {
            int size = this.bar.size();
            for (int i = 0; i < this.cursor && i < size; i++) {
                EventChannel on = this.bar.get(i);
                if (on.getType() != 9 || on.getValue2() <= 0 || on.getChannel() == DRUM) {
                    continue;
                }
                if (this.section.getRetriggerRule(on.getChannel()) == 0) {
                    continue;                                  // regla "stop": no continua
                }
                // "sostenida" = su PRIMER note-off posterior cae despues del instante actual
                boolean open = false;
                for (int j = i + 1; j < size; j++) {
                    EventChannel off = this.bar.get(j);
                    if ((off.getType() == 8 || (off.getType() == 9 && off.getValue2() == 0))
                            && off.getChannel() == on.getChannel() && off.getValue1() == on.getValue1()) {
                        open = j >= this.cursor;
                        break;
                    }
                }
                if (!open) {
                    continue;
                }
                int k = ((on.getChannel() & 15) << 7) | (on.getValue1() & 127);
                keep[k] = true;
                if (!old[k]) {
                    fire(on.withVelocity((int) Math.round(on.getValue2() * velScale)));
                    fired = true;
                }
            }
        }
        for (int i = this.lateOffs.size() - 1; i >= 0; i--) {      // un off pendiente no debe apagar una nota que se conserva
            long[] o = this.lateOffs.get(i);
            if (keep[(((int) o[1]) << 7) | ((int) o[2])]) {
                this.lateOffs.remove(i);
            }
        }
        for (int ch = 0; ch < 16; ch++) {
            if (ch == DRUM) {
                continue;
            }
            for (int n = 0; n < 128; n++) {
                int k2 = (ch << 7) | n;
                if (old[k2] && !keep[k2]) {
                    if (fired) {
                        // solape: las notas viejas se apagan 35 ms despues de que entran las nuevas (sin corte seco)
                        this.lateOffs.add(new long[]{nowNs + 35000000L, ch, n, nowNs});
                    } else {
                        this.sounding[k2] = false;
                        this.sink.send(new EventChannel(0, (byte) 8, (byte) ch, (byte) n, (byte) 0));
                    }
                }
            }
        }
    }

    private void applySectionRequest(String name) {
        if (this.section == null || name == null || this.sty.getSection(name) == null) {
            return;
        }
        String cur = this.section.getName();
        if (isEnding(cur) && !isEnding(name)) {
            this.section = pick(mainFor(last(cur)));   // salir del Ending: se vuelve a un Main y se aplica lo pedido
            this.barIdx = 0;
            this.afterName = null;
            this.pendingName = null;
            silenceMelodic();
            applySectionSetup();
            this.bar = this.section.getEvents(0, this.chordApplied);
            this.cursor = firstIndexAfter(this.tickPos);
            notifySection();
            cur = this.section.getName();
        }
        if (isFill(name)) {
            fillNow(name, mainFor(last(name)));
        } else if (isMain(name)) {
            if (isIntro(cur) || isFill(cur)) {
                this.afterName = name;                    // cambia el destino del intro / fill
            } else if (isMain(cur)) {
                char a = last(cur);
                char b = last(name);
                String f = "Fill In " + a + b;
                if (!this.sty.containsSection(f)) {
                    f = "Fill In " + b + b;
                }
                if (this.sty.containsSection(f)) {
                    fillNow(f, name);
                } else {
                    this.pendingName = name;
                    this.pendingAfter = null;
                }
            } else {
                this.pendingName = name;
                this.pendingAfter = null;
            }
        } else {
            this.pendingName = name;                       // Intro / Ending: al siguiente compas
            this.pendingAfter = null;
        }
    }

    private void fillNow(String fillName, String after) {
        if (this.barTicks - this.tickPos < this.res / 2.0) {
            this.pendingName = fillName;                   // demasiado tarde en el compas
            this.pendingAfter = after;
            return;
        }
        this.prevSection = this.section;                 // el Main que sonaba sigue en los canales que el relleno no toca
        this.prevBarIdx = this.barIdx;
        this.mergePrev = true;
        this.section = pick(fillName);
        // Un canal es "del relleno" solo si el relleno tiene notas en lo que QUEDA del compas. Si no (p.ej. el piano
        // del relleno toca solo al inicio del compas) ese canal sigue con el patron del Main hasta el final.
        java.util.Arrays.fill(this.mergeDefined, false);
        for (EventChannel fe : this.section.getEvents(0, this.chordApplied)) {
            if ((fe.getType() == 9 && fe.getValue2() > 0) && fe.getTick() > this.tickPos) {
                this.mergeDefined[fe.getChannel() & 15] = true;
            }
        }
        this.barIdx = 0;
        this.afterName = after;
        this.pendingName = null;
        applySectionSetup();
        resync();
        notifySection();
    }

    private static final java.util.Comparator<EventChannel> BAR_ORDER = new java.util.Comparator<EventChannel>() {
        @Override
        public int compare(EventChannel x, EventChannel y) {
            if (x.getTick() != y.getTick()) {
                return x.getTick() < y.getTick() ? -1 : 1;
            }
            int rx = (x.getType() == 8 || (x.getType() == 9 && x.getValue2() == 0)) ? 0 : 1;   // los off primero
            int ry = (y.getType() == 8 || (y.getType() == 9 && y.getValue2() == 0)) ? 0 : 1;
            return rx - ry;
        }
    };

    /**
     * Compas actual. Si se entro a un relleno A MITAD de compas, los canales que el relleno NO define
     * (bajo, acordes, pads...) siguen con el patron del Main hasta el final del compas, como en un Yamaha.
     */
    private ArrayList<EventChannel> buildBar() {
        ArrayList<EventChannel> b = this.section.getEvents(this.barIdx, this.chordApplied);
        if (this.mergePrev && this.prevSection != null) {
            ArrayList<EventChannel> own = new ArrayList<>();
            for (EventChannel e : b) {
                if (this.mergeDefined[e.getChannel() & 15]) {
                    own.add(e);                          // canales que el relleno realmente toca en lo que queda
                }
            }
            b = own;
            for (EventChannel e2 : this.prevSection.getEvents(this.prevBarIdx, this.chordApplied)) {
                if (!this.mergeDefined[e2.getChannel() & 15]) {
                    b.add(e2);                           // el resto sigue con el Main
                }
            }
            java.util.Collections.sort(b, BAR_ORDER);
        }
        return b;
    }

    private int firstIndexAfter(double t) {
        int i = 0;
        while (i < this.bar.size() && this.bar.get(i).getTick() <= t) {
            i++;
        }
        return i;
    }

    private void silenceMelodic() {
        this.lateOffs.clear();
        for (int ch = 0; ch < 16; ch++) {
            if (ch == DRUM) {
                continue;
            }
            for (int n = 0; n < 128; n++) {
                int k = (ch << 7) | n;
                if (this.sounding[k]) {
                    this.sounding[k] = false;
                    this.sink.send(new EventChannel(0, (byte) 8, (byte) ch, (byte) n, (byte) 0));
                }
            }
        }
    }
}
