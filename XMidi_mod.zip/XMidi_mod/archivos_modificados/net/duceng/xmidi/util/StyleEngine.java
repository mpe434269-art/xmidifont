package net.duceng.xmidi.util;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.locks.LockSupport;
import net.duceng.midi.EventChannel;
import net.duceng.midi.StyFile;
import net.duceng.midi.StySection;

/**
 * Secuenciador de estilos (.sty) estilo "arranger".
 *
 * - Reloj propio en tiempo ABSOLUTO (System.nanoTime) con acumulacion de ticks:
 *   no hay Thread.sleep() por nota ni deriva acumulada, y un cambio de tempo
 *   se aplica al instante.
 * - Fill-in / cambio de seccion: se ejecutan EN EL MOMENTO de pulsar, sobre la
 *   misma posicion del compas (la bateria del fill suena alineada al tiempo,
 *   solo se oye lo que "queda" del compas del fill, como en un Yamaha PSR-SX).
 *   Si se pulsa en la ultima media negra del compas, el fill entra en el
 *   siguiente compas (para que no suene recortado).
 * - Cambio de acorde: inmediato (no espera al siguiente compas). Las notas
 *   sostenidas (pads, bajo) se reinician sobre el nuevo acorde.
 *
 * Todos los metodos publicos son seguros desde cualquier hilo.
 */
public final class StyleEngine implements Runnable {

    public interface Sink {
        void send(EventChannel e);
        void silence();
    }

    public interface Host {
        /** microsegundos por negra (tempo actual) */
        int mpqn();
    }

    public interface Listener {
        void onSection(String name);
        void onStopped();
    }

    private static final int DRUM = 9;
    private static final long MIN_PARK_NS = 20000L;
    private static final long MAX_PARK_NS = 5000000L;

    private final StyFile sty;
    private final Sink sink;
    private final Host host;
    private final ThreadFactory factory;
    private final int res;
    private final int barTicks;
    private final ConcurrentLinkedQueue<Runnable> cmds = new ConcurrentLinkedQueue<>();
    private final boolean[] sounding = new boolean[16 * 128];

    private volatile boolean running = false;
    private volatile Thread thread;
    private volatile Listener listener;
    private volatile Chords.Chord chordV;
    private volatile String startName;

    // estado: solo hilo del motor
    private StySection section;
    private int barIdx;
    private ArrayList<EventChannel> bar = new ArrayList<>();
    private int cursor;
    private double tickPos;
    private String afterName;
    private String pendingName;
    private String pendingAfter;
    private Chords.Chord chordApplied;
    private String lastNotified;

    public StyleEngine(StyFile sty, Sink sink, Host host, ThreadFactory factory) {
        this.sty = sty;
        this.sink = sink;
        this.host = host;
        this.factory = factory;
        this.res = sty.getResolution();
        this.barTicks = sty.getResolution() * sty.getTimeSignature().getNumerator();
    }

    // ------------------------------------------------------------ API
    public void setListener(Listener l) {
        this.listener = l;
    }

    public boolean isRunning() {
        return this.running;
    }

    public synchronized void start(String sectionName) {
        if (this.running) {
            requestSection(sectionName);
            return;
        }
        this.startName = sectionName;
        this.running = true;
        Thread t = this.factory != null ? this.factory.newThread(this) : new Thread(this, "StyleEngine");
        this.thread = t;
        t.start();
    }

    public void stop() {
        this.running = false;
        wake();
    }

    /** Detiene y ESPERA a que el hilo termine (usar al cerrar la pantalla, antes de liberar el sintetizador). */
    public void stopAndWait(long ms) {
        this.running = false;
        Thread t = this.thread;
        wake();
        if (t != null && t != Thread.currentThread()) {
            try {
                t.join(ms);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public void setChord(Chords.Chord c) {
        this.chordV = c;
        post(new Runnable() {
            @Override
            public void run() {
                applyChord();
            }
        });
    }

    public void requestSection(final String name) {
        post(new Runnable() {
            @Override
            public void run() {
                applySectionRequest(name);
            }
        });
    }

    /** Alinea la fase de pulso con un reloj externo (p.ej. el metronomo de Synth). */
    public void sync() {
        post(new Runnable() {
            @Override
            public void run() {
                double p = tickPos % res;
                if (p > res / 2.0) {
                    p -= res;
                }
                if (Math.abs(p) <= res / 8.0) {
                    tickPos -= p;
                }
            }
        });
    }

    private void post(Runnable r) {
        this.cmds.add(r);
        wake();
    }

    private void wake() {
        Thread t = this.thread;
        if (t != null) {
            LockSupport.unpark(t);
        }
    }

    // ------------------------------------------------------------ helpers de nombres
    private static boolean isFill(String n) {
        return n.startsWith("Fill In");
    }

    private static boolean isIntro(String n) {
        return n.startsWith("Intro");
    }

    private static boolean isEnding(String n) {
        return n.startsWith("Ending");
    }

    private static boolean isMain(String n) {
        return n.startsWith("Main");
    }

    private static char last(String n) {
        return n.charAt(n.length() - 1);
    }

    private String mainFor(char letter) {
        String m = "Main " + letter;
        if (this.sty.containsSection(m)) {
            return m;
        }
        if (this.sty.containsSection("Main A")) {
            return "Main A";
        }
        for (String k : this.sty.getSections().keySet()) {
            if (isMain(k)) {
                return k;
            }
        }
        return null;
    }

    private StySection pick(String name) {
        StySection s = name == null ? null : this.sty.getSection(name);
        if (s == null) {
            String m = mainFor('A');
            s = m != null ? this.sty.getSection(m) : null;
        }
        if (s == null && !this.sty.getSections().isEmpty()) {
            s = this.sty.getSections().values().iterator().next();
        }
        return s;
    }

    // ------------------------------------------------------------ nucleo
    @Override
    public void run() {
        try {
            long last = System.nanoTime();
            begin(this.startName);
            while (this.running && this.section != null) {
              try {
                drain();
                long now = System.nanoTime();
                int mpqn = this.host.mpqn();
                if (mpqn <= 0) {
                    mpqn = 500000;
                }
                this.tickPos += ((now - last) * (double) this.res) / (mpqn * 1000.0);
                last = now;
                fireDue();
                if (this.tickPos >= this.barTicks) {
                    this.tickPos -= this.barTicks;
                    advanceBar();
                    continue;
                }
                double next = this.cursor < this.bar.size() ? this.bar.get(this.cursor).getTick() : this.barTicks;
                if (next > this.barTicks) {
                    next = this.barTicks;
                }
                long ns = (long) (((next - this.tickPos) * mpqn * 1000.0) / this.res);
                if (ns < MIN_PARK_NS) {
                    ns = MIN_PARK_NS;
                }
                if (ns > MAX_PARK_NS) {
                    ns = MAX_PARK_NS;
                }
                LockSupport.parkNanos(ns);
              } catch (Throwable t) {                      // una excepcion NUNCA debe tumbar la app
                System.err.println("StyleEngine: " + t);
                this.running = false;
              }
            }
        } finally {
            this.running = false;
            try {
                this.sink.silence();
            } catch (Throwable t2) {
                // el sintetizador ya pudo haberse liberado
            }
            java.util.Arrays.fill(this.sounding, false);
            Listener l = this.listener;
            if (l != null) {
                l.onStopped();
            }
        }
    }

    private void drain() {
        Runnable r;
        while ((r = this.cmds.poll()) != null) {
            r.run();
        }
    }

    private void fireDue() {
        while (this.cursor < this.bar.size() && this.bar.get(this.cursor).getTick() <= this.tickPos) {
            fire(this.bar.get(this.cursor++));
        }
    }

    /** true si el compas siguiente es de la MISMA seccion y sin cambios pendientes (las notas largas siguen sonando). */
    private boolean continuesNextBar() {
        return this.pendingName == null && this.section != null && this.barIdx + 1 < this.section.sizeBars();
    }

    private void fire(EventChannel e) {
        int ch = e.getChannel() & 15;
        if (e.carry == 1 && continuesNextBar()) {
            return;                                        // la nota larga continua en el compas siguiente: no cortar
        }
        if (e.carry == 2 && ch != DRUM && this.sounding[(ch << 7) | (e.getValue1() & 127)]) {
            return;                                        // ya esta sonando: no volver a atacar (strings/pads continuos)
        }
        if (e.getType() == 9 && e.getValue2() > 0) {
            if (ch != DRUM) {
                this.sounding[(ch << 7) | (e.getValue1() & 127)] = true;
            }
        } else if (e.getType() == 8 || (e.getType() == 9 && e.getValue2() == 0)) {
            this.sounding[(ch << 7) | (e.getValue1() & 127)] = false;
        }
        this.sink.send(e);
    }

    private void begin(String name) {
        this.chordApplied = this.chordV;
        this.section = pick(name);
        this.barIdx = 0;
        this.tickPos = 0.0;
        this.afterName = null;
        this.pendingName = null;
        if (this.section == null) {
            return;
        }
        this.bar = this.section.getEvents(0, this.chordApplied);
        this.cursor = 0;
        notifySection();
    }

    private void notifySection() {
        Listener l = this.listener;
        if (l != null && this.section != null) {
            l.onSection(this.section.getName());
        }
    }

    private void advanceBar() {
        this.barIdx++;
        boolean sectionChanged = false;
        if (this.pendingName != null) {
            sectionChanged = true;
            StySection s = pick(this.pendingName);
            this.afterName = this.pendingAfter;
            this.pendingName = null;
            this.pendingAfter = null;
            this.section = s;
            this.barIdx = 0;
            notifySection();
        } else if (this.barIdx >= this.section.sizeBars()) {
            sectionChanged = true;
            this.barIdx = 0;
            String cur = this.section.getName();
            if (isEnding(cur)) {
                this.running = false;
                return;
            }
            if (isIntro(cur) || isFill(cur)) {
                String dest = this.afterName != null ? this.afterName : mainFor(last(cur));
                this.afterName = null;
                this.section = pick(dest);
                notifySection();
            }
        }
        if (sectionChanged) {
            silenceMelodic();
        }
        this.bar = this.section.getEvents(this.barIdx, this.chordApplied);
        this.cursor = 0;
    }

    private void applyChord() {
        Chords.Chord c = this.chordV;
        if (this.section == null || c == this.chordApplied) {
            return;
        }
        this.chordApplied = c;
        resync();
    }

    /**
     * Reconstruye el compas actual (acorde / seccion nuevos) sin cortes bruscos:
     * 1) las notas nuevas entran primero (solapadas),
     * 2) las notas que siguen siendo iguales NO se vuelven a atacar,
     * 3) solo se apagan las que ya no corresponden.
     */
    private void resync() {
        boolean[] old = this.sounding.clone();
        this.bar = this.section.getEvents(this.barIdx, this.chordApplied);
        this.cursor = firstIndexAfter(this.tickPos);
        boolean[] keep = new boolean[16 * 128];
        if (this.chordApplied != null) {
            int size = this.bar.size();
            for (int i = 0; i < this.cursor && i < size; i++) {
                EventChannel on = this.bar.get(i);
                if (on.getType() != 9 || on.getValue2() <= 0 || on.getChannel() == DRUM) {
                    continue;
                }
                if (this.section.getRetriggerRule(on.getChannel()) == 0) {
                    continue;                                  // regla "stop": no continua
                }
                boolean open = false;
                for (int j = this.cursor; j < size; j++) {
                    EventChannel off = this.bar.get(j);
                    if ((off.getType() == 8 || (off.getType() == 9 && off.getValue2() == 0))
                            && off.getChannel() == on.getChannel() && off.getValue1() == on.getValue1()) {
                        open = true;
                        break;
                    }
                }
                if (!open) {
                    continue;
                }
                int k = ((on.getChannel() & 15) << 7) | (on.getValue1() & 127);
                keep[k] = true;
                if (!old[k]) {
                    fire(on);
                }
            }
        }
        for (int ch = 0; ch < 16; ch++) {
            if (ch == DRUM) {
                continue;
            }
            for (int n = 0; n < 128; n++) {
                int k2 = (ch << 7) | n;
                if (old[k2] && !keep[k2]) {
                    this.sounding[k2] = false;
                    this.sink.send(new EventChannel(0, (byte) 8, (byte) ch, (byte) n, (byte) 0));
                }
            }
        }
    }

    private void applySectionRequest(String name) {
        if (this.section == null || name == null || this.sty.getSection(name) == null) {
            return;
        }
        String cur = this.section.getName();
        if (isEnding(cur) && !isEnding(name)) {
            this.section = pick(mainFor(last(cur)));   // salir del Ending: se vuelve a un Main y se aplica lo pedido
            this.barIdx = 0;
            this.afterName = null;
            this.pendingName = null;
            silenceMelodic();
            this.bar = this.section.getEvents(0, this.chordApplied);
            this.cursor = firstIndexAfter(this.tickPos);
            notifySection();
            cur = this.section.getName();
        }
        if (isFill(name)) {
            fillNow(name, mainFor(last(name)));
        } else if (isMain(name)) {
            if (isIntro(cur) || isFill(cur)) {
                this.afterName = name;                    // cambia el destino del intro / fill
            } else if (isMain(cur)) {
                char a = last(cur);
                char b = last(name);
                String f = "Fill In " + a + b;
                if (!this.sty.containsSection(f)) {
                    f = "Fill In " + b + b;
                }
                if (this.sty.containsSection(f)) {
                    fillNow(f, name);
                } else {
                    this.pendingName = name;
                    this.pendingAfter = null;
                }
            } else {
                this.pendingName = name;
                this.pendingAfter = null;
            }
        } else {
            this.pendingName = name;                       // Intro / Ending: al siguiente compas
            this.pendingAfter = null;
        }
    }

    private void fillNow(String fillName, String after) {
        if (this.barTicks - this.tickPos < this.res / 2.0) {
            this.pendingName = fillName;                   // demasiado tarde en el compas
            this.pendingAfter = after;
            return;
        }
        this.section = pick(fillName);
        this.barIdx = 0;
        this.afterName = after;
        this.pendingName = null;
        resync();
        notifySection();
    }

    private int firstIndexAfter(double t) {
        int i = 0;
        while (i < this.bar.size() && this.bar.get(i).getTick() <= t) {
            i++;
        }
        return i;
    }

    private void silenceMelodic() {
        for (int ch = 0; ch < 16; ch++) {
            if (ch == DRUM) {
                continue;
            }
            for (int n = 0; n < 128; n++) {
                int k = (ch << 7) | n;
                if (this.sounding[k]) {
                    this.sounding[k] = false;
                    this.sink.send(new EventChannel(0, (byte) 8, (byte) ch, (byte) n, (byte) 0));
                }
            }
        }
    }
}
