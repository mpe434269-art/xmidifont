package net.duceng.xmidi.widgets;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import net.duceng.xmidi.Base;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes.dex */
public class PianoBoard extends SurfaceView implements SurfaceHolder.Callback {
    public static final int OCTAVES = 7;
    public static final int WKEYS = 7;
    private int blackKeyHeight;
    private int blackKeyWidth;
    private int boardWidth;
    private int border;
    private Bitmap bufferBitmap;
    private Canvas bufferCanvas;
    private int bufferWidth;
    private int bufferX;
    private Bitmap downBlack;
    private Bitmap downWhite;
    private int[] eventStatus;
    private GestureDetector gestureDetector;
    private SurfaceHolder holder;
    private boolean lockScroll;
    private int margin;
    private GestureDetector.OnGestureListener onGesture;
    private Paint paint;
    private PianoBoardListener pianoBoardListener;
    private int scrollX;
    private Bitmap shadeBlack;
    private int shadeSize;
    private Bitmap shadeWhite;
    private boolean surfaceReady;
    private Bitmap upBlack;
    private Bitmap upWhite;
    private int whiteKeyHeight;
    private int whiteKeyWidth;
    private static float[] OFFSETS = {0.0f, 0.6f, 1.0f, 1.8f, 2.0f, 3.0f, 3.55f, 4.0f, 4.7f, 5.0f, 5.85f, 6.0f};
    private static boolean[] ISWHITE = {true, false, true, false, true, true, false, true, false, true, false, true};
    private static int[] WHITES = {0, 2, 4, 5, 7, 9, 11};
    private static int GRAY1 = Color.argb(127, 60, 60, 60);
    private static int GRAY2 = Color.argb(210, 180, 180, 180);
    private static int BCOLOR = -16777216;

    public interface PianoBoardListener {
        void onKeysChanged(int i, int i2);
    }

    public PianoBoard(Context context) {
        super(context);
        this.eventStatus = new int[32];
        this.onGesture = new GestureDetector.SimpleOnGestureListener() { // from class: net.duceng.xmidi.widgets.PianoBoard.1
            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                PianoBoard.this.scroll(-((int) distanceX));
                return true;
            }
        };
        init(context);
    }

    public PianoBoard(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.eventStatus = new int[32];
        this.onGesture = new GestureDetector.SimpleOnGestureListener() { // from class: net.duceng.xmidi.widgets.PianoBoard.1
            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                PianoBoard.this.scroll(-((int) distanceX));
                return true;
            }
        };
        init(context);
    }

    public PianoBoard(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.eventStatus = new int[32];
        this.onGesture = new GestureDetector.SimpleOnGestureListener() { // from class: net.duceng.xmidi.widgets.PianoBoard.1
            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                PianoBoard.this.scroll(-((int) distanceX));
                return true;
            }
        };
        init(context);
    }

    private void init(Context context) {
        this.margin = 0;
        this.border = 1;
        this.paint = new Paint();
        this.whiteKeyWidth = (int) (53.0f * context.getResources().getDisplayMetrics().density);
        this.blackKeyWidth = (this.whiteKeyWidth * 3) / 5;
        this.shadeSize = this.blackKeyWidth / 5;
        this.bufferX = 295;
        this.scrollX = 295;
        this.lockScroll = false;
        this.gestureDetector = new GestureDetector(getContext(), this.onGesture);
        this.holder = getHolder();
        this.holder.addCallback(this);
        this.holder.setFormat(1);
    }

    @Override // android.view.View
    protected void onSizeChanged(int width, int height, int oldw, int oldh) {
        this.whiteKeyHeight = (height - (this.margin * 2)) - (this.border * 2);
        this.blackKeyHeight = (this.whiteKeyHeight * 3) / 5;
        this.boardWidth = (width - (this.margin * 2)) - (this.border * 2);
        if (this.targetWhiteKeys > 0 && this.boardWidth > 0) {
            this.whiteKeyWidth = Math.max(8, this.boardWidth / this.targetWhiteKeys);      // n teclas blancas exactas en pantalla
            this.blackKeyWidth = (this.whiteKeyWidth * 3) / 5;
            this.shadeSize = this.blackKeyWidth / 5;
        }
        this.bufferWidth = (int) (this.boardWidth * 1.2f);
        initBitmap();
        if (this.bufferBitmap != null) {
            this.bufferBitmap.recycle();
        }
        this.bufferBitmap = Bitmap.createBitmap(this.bufferWidth, this.whiteKeyHeight, Bitmap.Config.ARGB_8888);
        this.bufferCanvas = new Canvas(this.bufferBitmap);
        drawKeys(this.bufferCanvas);
        System.gc();
    }

    private int targetWhiteKeys = 0;

    /** Muestra exactamente n teclas blancas en el ancho disponible (se recalcula al cambiar el tamano). */
    public void setVisibleWhiteKeys(int n) {
        this.targetWhiteKeys = n;
        if (getWidth() > 0 && getHeight() > 0) {
            onSizeChanged(getWidth(), getHeight(), getWidth(), getHeight());
        }
    }

    /** Escala el ancho de las teclas (1.0 = tamano original, 0.7 = 30% mas pequenas). Llamar antes de mostrar o en cualquier momento. */
    public void setKeyScale(float scale) {
        float density = getContext().getResources().getDisplayMetrics().density;
        this.whiteKeyWidth = Math.max((int) (22.0f * density), (int) (53.0f * density * scale));
        this.blackKeyWidth = (this.whiteKeyWidth * 3) / 5;
        this.shadeSize = this.blackKeyWidth / 5;
        if (getWidth() > 0 && getHeight() > 0) {
            onSizeChanged(getWidth(), getHeight(), getWidth(), getHeight());   // regenerar bitmaps con el nuevo tamano
        }
        scroll(0);
    }

    private void initBitmap() {
        if (this.upWhite != null) {
            this.upWhite.recycle();
        }
        if (this.downWhite != null) {
            this.downWhite.recycle();
        }
        if (this.upBlack != null) {
            this.upBlack.recycle();
        }
        if (this.downBlack != null) {
            this.downBlack.recycle();
        }
        if (this.shadeWhite != null) {
            this.shadeWhite.recycle();
        }
        if (this.shadeBlack != null) {
            this.shadeBlack.recycle();
        }
        Bitmap bmpTemp = Base.decodeResource(getResources(), R.drawable.kw_up, this.whiteKeyWidth, this.whiteKeyHeight);
        this.upWhite = Bitmap.createScaledBitmap(bmpTemp, this.whiteKeyWidth, this.whiteKeyHeight, true);
        bmpTemp.recycle();
        Bitmap bmpTemp2 = Base.decodeResource(getResources(), R.drawable.kw_down, this.whiteKeyWidth, this.whiteKeyHeight);
        this.downWhite = Bitmap.createScaledBitmap(bmpTemp2, this.whiteKeyWidth, this.whiteKeyHeight, true);
        bmpTemp2.recycle();
        Bitmap bmpTemp3 = Base.decodeResource(getResources(), R.drawable.kb_up, this.blackKeyWidth, this.blackKeyHeight);
        this.upBlack = Bitmap.createScaledBitmap(bmpTemp3, this.blackKeyWidth, this.blackKeyHeight, true);
        bmpTemp3.recycle();
        Bitmap bmpTemp4 = Base.decodeResource(getResources(), R.drawable.kb_down, this.blackKeyWidth, this.blackKeyHeight);
        this.downBlack = Bitmap.createScaledBitmap(bmpTemp4, this.blackKeyWidth, this.blackKeyHeight, true);
        bmpTemp4.recycle();
        Bitmap bmpTemp5 = Base.decodeResource(getResources(), R.drawable.kw_shade, (this.whiteKeyWidth * 3) / 10, this.whiteKeyHeight);
        this.shadeWhite = Bitmap.createScaledBitmap(bmpTemp5, (this.whiteKeyWidth * 3) / 10, this.whiteKeyHeight, true);
        bmpTemp5.recycle();
        Bitmap bmpTemp6 = Base.decodeResource(getResources(), R.drawable.kb_shade, (int) (this.blackKeyWidth * 1.5f), (int) (this.blackKeyHeight * 1.5f));
        this.shadeBlack = Bitmap.createScaledBitmap(bmpTemp6, (int) (this.blackKeyWidth * 1.5f), (int) (this.blackKeyHeight * 1.5f), true);
        bmpTemp6.recycle();
        System.gc();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        Log.i("PianoBoard", "onDraw: This will NOT happen!");
        draw(canvas);
    }

    @Override // android.view.SurfaceView, android.view.View
    public void draw(Canvas canvas) {
        if (this.bufferX > this.scrollX) {
            while (this.bufferX > this.scrollX) {
                this.bufferX -= this.boardWidth / 5;
            }
            if (this.bufferX < 0) {
                this.bufferX = 0;
            }
            drawKeys(this.bufferCanvas);
        } else if (this.scrollX - this.bufferX > this.bufferWidth - this.boardWidth) {
            while (this.scrollX - this.bufferX > this.bufferWidth - this.boardWidth) {
                this.bufferX += this.boardWidth / 5;
            }
            if (this.bufferX + this.bufferWidth > this.whiteKeyWidth * 7 * 7) {
                this.bufferX = ((this.whiteKeyWidth * 7) * 7) - this.bufferWidth;
            }
            drawKeys(this.bufferCanvas);
        }
        canvas.drawColor(0, PorterDuff.Mode.CLEAR);
        canvas.save();
        canvas.translate(this.margin + this.border, this.margin + this.border);
        canvas.translate(this.bufferX - this.scrollX, 0.0f);
        canvas.drawBitmap(this.bufferBitmap, 0.0f, 0.0f, this.paint);
        canvas.restore();
        drawBorder(canvas);
    }

    private void drawBorder(Canvas canvas) {
        if (this.border > 0) {
            this.paint.setStyle(Paint.Style.FILL);
            this.paint.setColor(BCOLOR);
            canvas.drawRect(this.margin, this.margin, getWidth() - this.margin, this.margin + this.border, this.paint);
            canvas.drawRect(this.margin, this.margin, this.margin + this.border, getHeight() - this.margin, this.paint);
            canvas.drawRect(this.margin, (getHeight() - this.margin) - this.border, getWidth() - this.margin, getHeight() - this.margin, this.paint);
            canvas.drawRect((getWidth() - this.margin) - this.border, this.margin, getWidth() - this.margin, getHeight() - this.margin, this.paint);
            this.paint.reset();
        }
    }

    private void drawKeys(Canvas canvas) {
        int octave = (this.bufferX / (this.whiteKeyWidth * 7)) + 1;
        int offset = (-this.bufferX) % (this.whiteKeyWidth * 7);
        canvas.drawColor(0, PorterDuff.Mode.CLEAR);
        canvas.save();
        canvas.translate(offset, 0.0f);
        int oidx = octave;
        while (oidx <= 7) {
            for (int kidx = 0; kidx < OFFSETS.length; kidx++) {
                if (offset < 0) {
                    if ((!ISWHITE[kidx] || offset + (this.whiteKeyWidth * OFFSETS[kidx]) + this.whiteKeyWidth >= 0.0f) && (ISWHITE[kidx] || offset + (this.whiteKeyWidth * OFFSETS[kidx]) + this.blackKeyWidth >= 0.0f)) {
                    }
                } else if ((this.whiteKeyWidth * 7) + offset > this.bufferWidth && offset + (this.whiteKeyWidth * OFFSETS[kidx]) > this.bufferWidth) {
                    oidx = 7;
                    break;
                }
                canvas.save();
                canvas.translate(this.whiteKeyWidth * OFFSETS[kidx], 0.0f);
                drawKey(canvas, kidx, false);
                if (kidx == 0) {
                    drawString(canvas, 0, this.whiteKeyHeight, "C" + oidx);
                }
                canvas.restore();
            }
            canvas.translate(this.whiteKeyWidth * 7, 0.0f);
            offset += this.whiteKeyWidth * 7;
            oidx++;
        }
        canvas.restore();
    }

    private void drawKey(Canvas canvas, int index, boolean pressed) {
        if (ISWHITE[index]) {
            int left = 0;
            int right = this.whiteKeyWidth;
            Rect rect = new Rect();
            if (index != 0 && index != 5) {
                left = (((int) (this.whiteKeyWidth * OFFSETS[index - 1])) + this.blackKeyWidth) - ((int) (this.whiteKeyWidth * OFFSETS[index]));
            }
            if (index != 4 && index != 11) {
                right = ((int) (this.whiteKeyWidth * OFFSETS[index + 1])) - ((int) (this.whiteKeyWidth * OFFSETS[index]));
            }
            this.paint.setStyle(Paint.Style.FILL);
            this.paint.setColor(-16777216);
            canvas.save();
            rect.set(left, 0, right, this.blackKeyHeight);
            canvas.clipRect(rect);
            canvas.drawBitmap(pressed ? this.downWhite : this.upWhite, 0.0f, 0.0f, this.paint);
            canvas.restore();
            canvas.save();
            rect.set(0, this.blackKeyHeight, this.whiteKeyWidth, this.whiteKeyHeight);
            if (pressed) {
                canvas.drawRect(rect, this.paint);
            }
            canvas.clipRect(rect);
            canvas.drawBitmap(pressed ? this.downWhite : this.upWhite, 0.0f, 0.0f, this.paint);
            canvas.restore();
            if (pressed) {
                if (left > 0) {
                    canvas.save();
                    rect.set(left, 0, this.shadeSize + left, this.blackKeyHeight);
                    canvas.clipRect(rect);
                    canvas.drawBitmap(this.shadeBlack, (this.shadeSize - this.shadeBlack.getWidth()) + left, 0.0f, this.paint);
                    canvas.restore();
                    canvas.save();
                    rect.set(0, this.blackKeyHeight, this.shadeSize + left, this.blackKeyHeight + this.shadeSize);
                    canvas.clipRect(rect);
                    canvas.drawBitmap(this.shadeBlack, (this.shadeSize - this.shadeBlack.getWidth()) + left, (this.shadeSize - this.shadeBlack.getHeight()) + this.blackKeyHeight, this.paint);
                    canvas.restore();
                    canvas.save();
                    rect.set(0, this.blackKeyHeight + this.shadeSize, this.shadeWhite.getWidth(), this.whiteKeyHeight);
                    canvas.clipRect(rect);
                    canvas.drawBitmap(this.shadeWhite, 0.0f, this.blackKeyHeight + this.shadeSize, this.paint);
                    canvas.restore();
                } else {
                    canvas.save();
                    rect.set(0, 0, this.shadeWhite.getWidth(), this.whiteKeyHeight);
                    canvas.clipRect(rect);
                    canvas.drawBitmap(this.shadeWhite, 0.0f, 0.0f, this.paint);
                    canvas.restore();
                }
            } else {
                this.paint.setStyle(Paint.Style.STROKE);
                if (left > 0) {
                    this.paint.setColor(GRAY1);
                    canvas.drawLine(left, 0.0f, left, this.blackKeyHeight + 1, this.paint);
                    this.paint.setColor(GRAY2);
                    canvas.drawLine(2.0f, this.blackKeyHeight, left, this.blackKeyHeight, this.paint);
                }
                if (right < this.whiteKeyWidth) {
                    this.paint.setColor(GRAY2);
                    canvas.drawLine(right, this.blackKeyHeight, this.whiteKeyWidth - 2, this.blackKeyHeight, this.paint);
                }
            }
        } else {
            canvas.drawBitmap(pressed ? this.downBlack : this.upBlack, 0.0f, 0.0f, this.paint);
        }
        this.paint.reset();
    }

    private void drawString(Canvas canvas, int x, int y, String str) {
        this.paint.setTextSize(this.whiteKeyWidth / 3);
        this.paint.setColor(GRAY2);
        this.paint.setAntiAlias(true);
        canvas.drawText(str, x + ((this.whiteKeyWidth - this.paint.measureText(str)) / 2.0f), y - (this.whiteKeyWidth / 8), this.paint);
        this.paint.reset();
    }

    private void draw() {
        Canvas canvas;
        if (this.surfaceReady && (canvas = this.holder.lockCanvas()) != null) {
            draw(canvas);
            this.holder.unlockCanvasAndPost(canvas);
        }
    }

    private void drawNote(int note, boolean pressed) {
        if (this.surfaceReady) {
            int octave = (note / 12) - 2;
            int index = note % 12;
            if (octave >= 0 && octave < 7) {
                int left = (((this.whiteKeyWidth * 7) * octave) + ((int) (this.whiteKeyWidth * OFFSETS[index]))) - this.scrollX;
                this.bufferCanvas.save();
                this.bufferCanvas.translate((left - this.bufferX) + this.scrollX, 0.0f);
                drawKey(this.bufferCanvas, index, pressed);
                if (index == 0 && !pressed) {
                    drawString(this.bufferCanvas, 0, this.whiteKeyHeight, "C" + (octave + 1));
                }
                this.bufferCanvas.restore();
                Rect rect = new Rect();
                rect.set(left, 0, this.whiteKeyWidth + left, this.whiteKeyHeight);
                rect.offset(this.margin + this.border, this.margin + this.border);
                Canvas canvas = this.holder.lockCanvas(rect);
                if (canvas != null) {
                    canvas.translate((this.margin + this.border) - (this.scrollX - this.bufferX), this.margin + this.border);
                    canvas.drawBitmap(this.bufferBitmap, 0.0f, 0.0f, this.paint);
                    this.holder.unlockCanvasAndPost(canvas);
                }
            }
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction() & 255;
        if (action == 0 || action == 5) {
            int idx = event.getActionIndex();
            int x = (int) event.getX(idx);
            int y = (int) event.getY(idx);
            if (x < this.margin + this.border || x > (getWidth() - this.margin) - this.border || y < this.margin + this.border || y > this.whiteKeyHeight + this.margin + this.border) {
                return true;
            }
            int x2 = x - (this.margin + this.border);
            int y2 = y - (this.margin + this.border);
            int x3 = x2 + this.scrollX;
            int o = x3 / (this.whiteKeyWidth * 7);
            int ox = x3 % (this.whiteKeyWidth * 7);
            int on = ox / this.whiteKeyWidth;
            int note = WHITES[on];
            int val = ((y2 * 90) / this.whiteKeyHeight) + 30;
            if (y2 < this.blackKeyHeight) {
                if (on != 0 && on != 3 && ox < (OFFSETS[note - 1] * this.whiteKeyWidth) + this.blackKeyWidth) {
                    note--;
                    val = ((y2 * 90) / this.blackKeyHeight) + 30;
                } else if (on != 2 && on != 6 && ox > OFFSETS[note + 1] * this.whiteKeyWidth) {
                    note++;
                    val = ((y2 * 90) / this.blackKeyHeight) + 30;
                }
            }
            int note2 = note + (o * 12) + 24;
            if (this.pianoBoardListener != null) {
                this.pianoBoardListener.onKeysChanged(note2, val);
            }
            drawNote(note2, true);
            int pid = event.getPointerId(idx);
            if (pid >= 0 && pid < this.eventStatus.length) {
                this.eventStatus[pid] = note2;
            }
        } else if (action == 1 || action == 6) {
            int id = event.getPointerId(event.getActionIndex());
            if (id < 0 || id >= this.eventStatus.length) {
                return true;
            }
            if (this.pianoBoardListener != null && this.eventStatus[id] > 0) {
                this.pianoBoardListener.onKeysChanged(this.eventStatus[id], 0);
            }
            drawNote(this.eventStatus[id], false);
            this.eventStatus[id] = 0;
        } else if (action == 3) {
            releaseAll();                                  // toque cancelado por el sistema: no dejar notas pegadas
        } else if (this.lockScroll && action == 2) {
            int idx2 = event.getActionIndex();
            int id2 = event.getPointerId(idx2);
            if (id2 < 0 || id2 >= this.eventStatus.length) {
                return true;
            }
            int x4 = (int) event.getX(idx2);
            int y3 = (int) event.getY(idx2);
            if (x4 < this.margin + this.border || x4 > (getWidth() - this.margin) - this.border || y3 < this.margin + this.border || y3 > this.whiteKeyHeight + this.margin + this.border) {
                return true;
            }
            int x5 = x4 - (this.margin + this.border);
            int y4 = y3 - (this.margin + this.border);
            int x6 = x5 + this.scrollX;
            int o2 = x6 / (this.whiteKeyWidth * 7);
            int ox2 = x6 % (this.whiteKeyWidth * 7);
            int on2 = ox2 / this.whiteKeyWidth;
            int note3 = WHITES[on2];
            int val2 = ((y4 * 64) / this.whiteKeyHeight) + 63;
            if (y4 < this.blackKeyHeight) {
                if (on2 != 0 && on2 != 3 && ox2 < (OFFSETS[note3 - 1] * this.whiteKeyWidth) + this.blackKeyWidth) {
                    note3--;
                    val2 = ((y4 * 64) / this.blackKeyHeight) + 63;
                } else if (on2 != 2 && on2 != 6 && ox2 > OFFSETS[note3 + 1] * this.whiteKeyWidth) {
                    note3++;
                    val2 = ((y4 * 64) / this.blackKeyHeight) + 63;
                }
            }
            int note4 = note3 + (o2 * 12) + 24;
            if (this.eventStatus[id2] == note4) {
                return true;
            }
            if (this.pianoBoardListener != null) {
                if (this.eventStatus[id2] > 0) {
                    this.pianoBoardListener.onKeysChanged(this.eventStatus[id2], 0);
                }
                this.pianoBoardListener.onKeysChanged(note4, val2);
            }
            drawNote(this.eventStatus[id2], false);
            drawNote(note4, true);
            this.eventStatus[id2] = note4;
        }
        if (!this.lockScroll) {
            this.gestureDetector.onTouchEvent(event);
        }
        return true;
    }

    /** Suelta todas las teclas que estan pulsadas (al pausar la pantalla o cancelarse un toque). */
    public void releaseAll() {
        for (int i = 0; i < this.eventStatus.length; i++) {
            if (this.eventStatus[i] > 0) {
                if (this.pianoBoardListener != null) {
                    this.pianoBoardListener.onKeysChanged(this.eventStatus[i], 0);
                }
                drawNote(this.eventStatus[i], false);
                this.eventStatus[i] = 0;
            }
        }
    }

    public boolean isLocked() {
        return this.lockScroll;
    }

    public void setLocked(boolean locked) {
        this.lockScroll = locked;
    }

    public void setScroll(int note) {
        int octave = (note / 12) - 2;
        int index = note % 12;
        if (octave >= 0 && octave < 7) {
            this.scrollX = (this.whiteKeyWidth * 7 * octave) + ((int) (this.whiteKeyWidth * OFFSETS[index]));
            if (this.scrollX < 0) {
                this.scrollX = 0;
            }
            if (this.scrollX > ((this.whiteKeyWidth * 7) * 7) - this.boardWidth) {
                this.scrollX = ((this.whiteKeyWidth * 7) * 7) - this.boardWidth;
            }
            draw();
        }
    }

    public void scroll(int dx) {
        this.scrollX -= dx;
        if (this.scrollX < 0) {
            this.scrollX = 0;
        }
        if (this.scrollX > ((this.whiteKeyWidth * 7) * 7) - this.boardWidth) {
            this.scrollX = ((this.whiteKeyWidth * 7) * 7) - this.boardWidth;
        }
        draw();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        draw();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceCreated(SurfaceHolder holder) {
        this.surfaceReady = true;
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceDestroyed(SurfaceHolder holder) {
        this.surfaceReady = false;
    }

    public void setPianoBoardListener(PianoBoardListener l) {
        this.pianoBoardListener = l;
    }
}
