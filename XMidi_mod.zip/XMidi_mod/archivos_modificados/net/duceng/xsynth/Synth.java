package net.duceng.xsynth;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.duceng.midi.EventChannel;
import net.duceng.midi.MetaTempo;
import net.duceng.midi.MetaTimeSignature;
import net.duceng.midi.MidiEvent;
import net.duceng.midi.MidiFile;
import net.duceng.midi.MidiTrack;
import net.duceng.midi.MidiUtil;
import net.duceng.xmidi.Settings;
import net.duceng.xmidi.util.MyArray;
import net.duceng.xmidi.widgets.MusicScore;

/* JADX INFO: loaded from: classes.dex */
public class Synth {
    private BeatListener beatListener;
    private ExecutorService mExecutor;
    private Runnable mRunnable;
    private StatusListener statusListener;
    public static String PATH_ROOT = Environment.getExternalStorageDirectory() + "/net.duceng/XMidi";
    public static String PATH_FONT = String.valueOf(PATH_ROOT) + "/sf2";
    public static String PATH_MIDI = String.valueOf(PATH_ROOT) + "/midi";
    public static String PATH_STY = String.valueOf(PATH_ROOT) + "/sty";
    public static String PATH_RECORD = String.valueOf(PATH_MIDI) + "/record";
    public static String DEFAULT_FONT = String.valueOf(PATH_FONT) + "/TimGM6mb.sf2";

    /** true si los archivos base ya se copiaron A LA CARPETA ACTUAL (si cambia la carpeta, se copian de nuevo). */
    public static boolean isInitialized(Context c) {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(c);
        return pref.getBoolean(Settings.SYNTH_INIT, false)
                && PATH_ROOT.equals(pref.getString("synth_init_root", ""))
                && new File(DEFAULT_FONT).exists();
    }

    /** Devuelve true si la app puede usar /sdcard/net.duceng/XMidi (todos los Android). */
    public static boolean hasSharedStorageAccess(Context c) {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        }
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            return c.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    /** Fija las rutas: carpeta compartida si hay permiso; si no, carpeta propia de la app. */
    public static void configurePaths(Context c) {
        String root;
        if (hasSharedStorageAccess(c)) {
            root = Environment.getExternalStorageDirectory() + "/net.duceng/XMidi";
        } else {
            File base = c.getExternalFilesDir(null);
            if (base == null) {
                base = c.getFilesDir();
            }
            root = base.getAbsolutePath() + "/XMidi";
        }
        PATH_ROOT = root;
        PATH_FONT = String.valueOf(PATH_ROOT) + "/sf2";
        PATH_MIDI = String.valueOf(PATH_ROOT) + "/midi";
        PATH_STY = String.valueOf(PATH_ROOT) + "/sty";
        PATH_RECORD = String.valueOf(PATH_MIDI) + "/record";
        DEFAULT_FONT = String.valueOf(PATH_FONT) + "/TimGM6mb.sf2";
    }
    public static byte DRUMS_CHAN = 9;
    public static int DRUMS_BANK = 128;
    private static Synth instance = null;
    private MyArray<File> sfonts = new MyArray<>();
    private boolean[] mutes = new boolean[16];
    private ArrayList<MyArray<Integer>> controls = new ArrayList<>();
    private boolean[] scores = null;
    private File file = null;
    private MidiFile midiFile = new MidiFile();
    private MidiTrack recordTrack = null;
    private byte recordChan = 0;
    private byte listenChan = 0;
    private boolean playing = false;
    private boolean pause = false;
    private boolean recording = false;
    private boolean beating = false;
    private byte beatVelocity = 75;
    private byte beatNote1 = 34;
    private byte beatNote2 = 33;
    private long lastBeatMillis = 0;
    private int lastBeatTicks = 0;
    private boolean inited = false;
    private int bound = 0;

    public interface BeatListener {
        void onBeating(long j);
    }

    public interface StatusListener {
        void onStatusChanged(boolean z);
    }

    private Synth() {
        for (int i = 0; i < 16; i++) {
            this.controls.add(new MyArray<>());
        }
    }

    public static Synth getInstance() {
        if (instance == null) {
            instance = new Synth();
            instance.create();
        }
        instance.bound++;
        return instance;
    }

    public void freeInstance() {
        stop();
        this.bound--;
        if (this.bound <= 0) {
            release();
            instance = null;
        }
    }

    public boolean isInited() {
        return this.inited;
    }

    public void init(Context content) {
        if (!this.inited) {
            SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(content);
            boolean synth_init = isInitialized(content);
            if (!synth_init) {
                try {
                    File font = new File(DEFAULT_FONT);
                    if (!font.getParentFile().exists()) {
                        font.getParentFile().mkdirs();
                    }
                    font.createNewFile();
                    InputStream inputStream = content.getAssets().open(font.getName());
                    OutputStream outputStream = new FileOutputStream(font);
                    byte[] buff = new byte[1024];
                    while (true) {
                        int nLen = inputStream.read(buff);
                        if (nLen <= 0) {
                            break;
                        } else {
                            outputStream.write(buff, 0, nLen);
                        }
                    }
                    outputStream.close();
                    inputStream.close();
                    File dir = new File(PATH_RECORD);
                    if (!dir.exists()) {
                        dir.mkdirs();
                    }
                    init_dir(content, "midi", PATH_MIDI);
                    init_dir(content, "sty", PATH_STY);
                    SharedPreferences.Editor editor = pref.edit();
                    editor.putBoolean(Settings.SYNTH_INIT, true);
                    editor.putString("synth_init_root", PATH_ROOT);
                    editor.commit();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            int gain = pref.getInt(Settings.SYNTH_GAIN, 3);
            setGain(gain / 10.0f);
            int polyphony = pref.getInt(Settings.SYNTH_POLYPHONY, 128);
            setPolyphony(polyphony);
            this.beatVelocity = (byte) pref.getInt(Settings.SYNTH_BEATVEL, 75);
            this.beatNote1 = (byte) pref.getInt(Settings.SYNTH_BEATNOTE1, 34);
            this.beatNote2 = (byte) pref.getInt(Settings.SYNTH_BEATNOTE2, 33);
            String sfont_default = pref.getString(Settings.SYNTH_SFONT_DEFAULT, Settings.SYNTH_SFONT_DEFAULT_VAL);
            loadSFont(new File(String.valueOf(PATH_FONT) + File.separator + sfont_default));
            for (int i = 0; i < 16; i++) {
                if (i == 9) {
                    setPreset(i, 0);
                } else {
                    setPreset(i, getPreset(i));
                }
            }
            this.inited = true;
        }
    }

    private void init_dir(Context content, String src, String tag) throws IOException {
        File dir = new File(tag);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        String[] files = content.getAssets().list(src);
        byte[] b = new byte[1024];
        for (String file : files) {
            File of = new File(String.valueOf(tag) + File.separator + file);
            InputStream i = content.getAssets().open(String.valueOf(src) + File.separator + file);
            OutputStream o = new FileOutputStream(of);
            while (true) {
                int n = i.read(b);
                if (n <= 0) {
                    break;
                } else {
                    o.write(b, 0, n);
                }
            }
            o.close();
            i.close();
        }
    }

    private void create() {
        XSynth.createEngine();
        XSynth.createMidiPlayer();
    }

    private volatile boolean playLoopActive = false;

    private void release() {
        for (int i = 0; i < 150 && this.playLoopActive; i++) {   // hasta 1.5 s: el hilo de reproduccion no debe tocar un motor liberado
            try {
                Thread.sleep(10L);
            } catch (InterruptedException e) {
                break;
            }
        }
        XSynth.releaseMidiPlayer();
        XSynth.releaseEngine();
    }

    public int loadSFont(File f) {
        int sfont_id = -1;
        if (f.exists()) {
            sfont_id = XSynth.midiPlayerSFLoad(f.getAbsolutePath(), 0);
            if (sfont_id > 0) {
                this.sfonts.put(sfont_id, f);
            }
            Log.i("Synth", "Load SoundFont " + f.getName() + " return: " + sfont_id + " Total: " + XSynth.midiPlayerSFCount());
        }
        return sfont_id;
    }

    public void unloadSFont(File f) {
        int index = this.sfonts.indexOfValue(f);
        if (index >= 0) {
            XSynth.midiPlayerSFUnload(this.sfonts.keyAt(index), 0);
            this.sfonts.removeAt(index);
            Log.i("Synth", "Unload SoundFont " + f.getName() + " Total: " + XSynth.midiPlayerSFCount());
        }
    }

    public MyArray<File> getSFonts() {
        return this.sfonts;
    }

    public File getFontFile(int chan) {
        int sfont_id = getSFont(chan);
        return (sfont_id <= 0 || this.sfonts.indexOfKey(sfont_id) < 0) ? this.sfonts.valueAt(0) : this.sfonts.get(sfont_id);
    }

    public float getGain() {
        return XSynth.midiPlayerGetGain();
    }

    public void setGain(float gain) {
        XSynth.midiPlayerSetGain(gain);
    }

    public float getPolyphony() {
        return XSynth.midiPlayerGetPolyphony();
    }

    public void setPolyphony(int polyphony) {
        XSynth.midiPlayerSetPolyphony(polyphony);
    }

    public void setSFont(int chan, int sfont_id) {
        XSynth.midiPlayerSFontSelect(chan, sfont_id);
    }

    public void setBank(int chan, int bank) {
        XSynth.midiPlayerBankSelect(chan, bank);
    }

    public void setPreset(int chan, int val) {
        XSynth.midiPlayerProgramChange(chan, val);
        if (this.styleMix && chan >= 8) {
            refreshVolume(chan);
        }
    }

    public void setProgram(int chan, int sfont_id, int bank_num, int preset_num) {
        XSynth.midiPlayerProgramSelect(chan, sfont_id, bank_num, preset_num);
        if (this.styleMix && chan >= 8) {
            refreshVolume(chan);
        }
    }

    public int getSFont(int chan) {
        return XSynth.midiPlayerGetSFont(chan);
    }

    public int getBank(int chan) {
        return XSynth.midiPlayerGetBank(chan);
    }

    public int getPreset(int chan) {
        return XSynth.midiPlayerGetPreset(chan);
    }

    public void setCC(int chan, int ctrl, int val) {
        XSynth.midiPlayerCC(chan, ctrl, val);
    }

    public int getCC(int chan, int ctrl) {
        return XSynth.midiPlayerGetCC(chan, ctrl);
    }

    public void setPitchBend(int chan, int val) {
        XSynth.midiPlayerPitchBend(chan, val);
    }

    public int getPitchBend(int chan) {
        return XSynth.midiPlayerGetPitchBend(chan);
    }

    public void setVolume(int chan, int val) {
        XSynth.midiPlayerCC(chan, XSynth.VOLUME_MSB, val);
    }

    public int getVolume(int chan) {
        return XSynth.midiPlayerGetCC(chan, XSynth.VOLUME_MSB);
    }

    public void setPan(int chan, int val) {
        XSynth.midiPlayerCC(chan, XSynth.PAN_MSB, val);
    }

    public int getPan(int chan) {
        return XSynth.midiPlayerGetCC(chan, XSynth.PAN_MSB);
    }

    public void setSustain(int chan, int val) {
        XSynth.midiPlayerCC(chan, XSynth.SUSTAIN_SWITCH, val);
    }

    public int getSustain(int chan) {
        return XSynth.midiPlayerGetCC(chan, XSynth.SUSTAIN_SWITCH);
    }

    public void setReverb(int chan, int val) {
        XSynth.midiPlayerCC(chan, XSynth.EFFECTS_DEPTH1, val);
    }

    public int getReverb(int chan) {
        return XSynth.midiPlayerGetCC(chan, XSynth.EFFECTS_DEPTH1);
    }

    public void setChorus(int chan, int val) {
        XSynth.midiPlayerCC(chan, XSynth.EFFECTS_DEPTH3, val);
    }

    public int getChorus(int chan) {
        return XSynth.midiPlayerGetCC(chan, XSynth.EFFECTS_DEPTH3);
    }

    public boolean isMute(int chan) {
        return this.mutes[chan];
    }

    public void setMute(int chan, boolean val) {
        this.mutes[chan] = val;
    }

    public MyArray<Integer> getControls(int chan) {
        return this.controls.get(chan);
    }

    public int getControl(int chan, int ctrl) {
        if (this.controls.get(chan).indexOfKey(ctrl) >= 0) {
            return this.controls.get(chan).get(ctrl).intValue();
        }
        return -1;
    }

    public void setControl(int chan, int ctrl, int val) {
        this.controls.get(chan).put(ctrl, Integer.valueOf(val));
    }

    public boolean isScore(int t) {
        return this.scores[t];
    }

    public void setScore(int t, boolean val) {
        this.scores[t] = val;
    }

    public boolean[] getScores() {
        return this.scores;
    }

    /** Apaga solo los canales indicados (p.ej. el acompanamiento 8-15) sin cortar el teclado en vivo. */
    public void silenceChannels(int from, int to) {
        for (int chan = from; chan <= to && chan < 16; chan++) {
            XSynth.midiPlayerCC(chan, XSynth.ALL_NOTES_OFF, 0);
        }
    }

    public void allNotesoff() {
        for (int chan = 0; chan < XSynth.midiPlayerMidiChannels(); chan++) {
            XSynth.midiPlayerCC(chan, XSynth.ALL_SOUND_OFF, 0);
        }
    }

    private void noteOn(int chan, int key, int vel) {
        if (vel == 0) {
            noteOff(chan, key);
        } else {
            XSynth.midiPlayerNoteon(chan, key, vel);
        }
    }

    private void noteOff(int chan, int key) {
        XSynth.midiPlayerNoteoff(chan, key);
    }

    /**
     * Los estilos/MIDI Yamaha-XG traen envios de reverb/chorus pensados para los DSP de Yamaha;
     * en FluidSynth quedan "lavados/ahogados". Se suavizan, y se evita oscurecer el timbre.
     */
    private static int tune(int ctrl, int val) {
        if (ctrl == XSynth.EFFECTS_DEPTH1) {
            return (val * 6) / 10;                 // reverb send
        }
        if (ctrl == XSynth.EFFECTS_DEPTH3) {
            return (val * 4) / 10;                 // chorus send
        }
        if (ctrl == XSynth.SOUND_CTRL5) {
            return Math.max(val, 64);              // brightness: nunca mas oscuro que lo neutro
        }
        if (ctrl == XSynth.SOUND_CTRL3) {
            return Math.max(val, 64);              // release time: no cortar las colas
        }
        return val;
    }

    /** Volumen (CC7) que pide el ritmo / archivo para cada canal, SIN el ajuste del usuario. */
    private final int[] baseVolume = {100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100};

    /** Vuelve a aplicar el volumen de un canal (llamar cuando el usuario mueve el deslizador). */
    public void refreshVolume(int chan) {
        if (chan >= 0 && chan < 16) {
            controlChange(chan, XSynth.VOLUME_MSB, this.baseVolume[chan]);
        }
    }

    // ------------------------------------------------------------------
    //  Balance de estilos. En un soundfont, a igual volumen MIDI, unos instrumentos suenan mucho mas fuerte
    //  que otros: strings, pads y coros son sostenidos y "llenan"; piano, guitarra y bajo decaen y se pierden.
    //  Un estilo Yamaha trae esos niveles pensados para sus propios timbres. Se compensa por FAMILIA GM
    //  (en dB sobre el volumen del estilo), solo para los canales de ritmo (8-15, sin bateria).
    // ------------------------------------------------------------------
    private volatile boolean styleMix = false;
    /** Ajuste en dB por familia GM (cada 8 programas): piano, perc.cromatica, organo, guitarra, bajo, cuerdas, ensemble/coro, metales, cañas, flautas, leads, pads, fx, etnicos, percusivos, sfx */
    private static final double[] FAMILY_DB = {+3.0, +1.0, -2.0, +2.5, +3.0, -3.0, -4.5, -2.0, -1.5, -1.0, -2.0, -4.5, -3.0, 0.0, 0.0, -2.0};

    public void setStyleMix(boolean on) {
        this.styleMix = on;
    }

    /**
     * Ajuste en dB por ROL del canal en un estilo Yamaha (8 rhythm sub, 9 rhythm, 10 bass, 11 chord1, 12 chord2,
     * 13 pad, 14 phrase1, 15 phrase2). Las frases (phrase) suelen venir fuertes y tapan a los acordes (piano).
     */
    private static final double[] ROLE_DB = {0.0, 0.0, 0.0, +1.5, +0.5, -1.0, -4.0, -3.0};

    private static double familyFactor(int chan, int program) {
        int fam = Math.max(0, Math.min(127, program)) / 8;
        double db = FAMILY_DB[fam];
        if (program >= 48 && program <= 51) {
            db = -4.5;                                 // string ensemble
        } else if (program >= 52 && program <= 55) {
            db = -3.0;                                 // coro / voz / orchestra hit
        }
        if (chan >= 8 && chan <= 15) {
            db += ROLE_DB[chan - 8];
        }
        return Math.pow(10.0, db / 40.0);              // curva de volumen GM: dB = 40*log10(127/CC)
    }

    private int trimVolume(int chan, int val) {
        if (chan == DRUMS_CHAN || getBank(chan) == DRUMS_BANK) {
            return val;
        }
        int out = (int) Math.round(val * familyFactor(chan, getPreset(chan)));
        return Math.max(1, Math.min(127, out));
    }

    private void controlChange(int chan, int ctrl, int val) {
        val = tune(ctrl, val);
        if (ctrl == XSynth.VOLUME_MSB && chan >= 0 && chan < 16) {
            this.baseVolume[chan] = val;                       // nivel que pide el ritmo (sin compensar)
            if (this.styleMix && chan >= 8) {
                val = trimVolume(chan, val);                   // balance por tipo de instrumento
            }
            if (this.controls.get(chan).indexOfKey(ctrl) >= 0) {
                int pct = this.controls.get(chan).get(ctrl).intValue();   // ajuste relativo del usuario (%)
                val = Math.round(val * (1.0f + (pct / 100.0f)));
                if (val > 127) {
                    val = 127;
                }
                if (val < 0) {
                    val = 0;
                }
            }
        } else {
            int v = getControl(chan, ctrl);
            if (v >= 0) {
                val = v;                                        // control "Fixed" por el usuario
            }
        }
        XSynth.midiPlayerCC(chan, ctrl, val);
    }

    private void programChange(int chan, int program) {
        XSynth.midiPlayerProgramChange(chan, program);
        if (this.styleMix && chan >= 8) {
            refreshVolume(chan);                               // otro instrumento = otro balance
        }
    }

    private void pitchBend(int chan, int val) {
        XSynth.midiPlayerPitchBend(chan, val);
    }

    public int getRecordChan() {
        return this.recordChan;
    }

    public void setRecordChan(byte chan) {
        this.recordChan = chan;
    }

    public int getListenChan() {
        return this.listenChan;
    }

    public void setListenChan(byte chan) {
        this.listenChan = chan;
    }

    // ------------------------------------------------------------------
    //  Teclado en vivo (pantalla de ritmos): canal propio, independiente del ritmo
    // ------------------------------------------------------------------
    public void keyOn(int chan, int key, int vel) {
        if (chan < 0 || chan > 15 || key < 0 || key > 127) {
            return;
        }
        noteOn(chan, key, Math.max(1, Math.min(127, vel)));
    }

    public void keyOff(int chan, int key) {
        if (chan < 0 || chan > 15 || key < 0 || key > 127) {
            return;
        }
        noteOff(chan, key);
    }

    /** Suelta todas las notas de un canal (con su release natural). */
    public void keysOff(int chan) {
        if (chan >= 0 && chan < 16) {
            XSynth.midiPlayerCC(chan, XSynth.ALL_NOTES_OFF, 0);
        }
    }

    public int getBaseVolume(int chan) {
        return (chan >= 0 && chan < 16) ? this.baseVolume[chan] : 100;
    }

    /** Volumen absoluto (0-127) de un canal libre; el ajuste relativo "Channels Setting" se aplica encima. */
    public void setKeyVolume(int chan, int v) {
        if (chan >= 0 && chan < 16) {
            this.baseVolume[chan] = Math.max(0, Math.min(127, v));
            refreshVolume(chan);
        }
    }

    public void noteOn(byte key, byte vel) {
        if (vel == 0) {
            noteOff(key);
            return;
        }
        noteOn(this.recordChan, key, vel);
        if (this.recording && this.playing) {
            if (this.recordTrack == null) {
                this.recordTrack = new MidiTrack();
            }
            int millisecondsPerTick = (this.midiFile.getTempo().getMpqn() / 1000) / this.midiFile.getResolution();
            int tick = (int) ((System.currentTimeMillis() - this.lastBeatMillis) / ((long) millisecondsPerTick));
            MidiEvent e = new EventChannel(this.lastBeatTicks + tick, (byte) 9, this.recordChan, key, vel);
            this.recordTrack.insert(e);
        }
    }

    public void noteOff(byte key) {
        noteOff(this.recordChan, key);
        if (this.recording && this.playing) {
            if (this.recordTrack == null) {
                this.recordTrack = new MidiTrack();
            }
            int millisecondsPerTick = (this.midiFile.getTempo().getMpqn() / 1000) / this.midiFile.getResolution();
            int tick = (int) ((System.currentTimeMillis() - this.lastBeatMillis) / ((long) millisecondsPerTick));
            MidiEvent e = new EventChannel(this.lastBeatTicks + tick, (byte) 8, this.recordChan, key, (byte) 0);
            this.recordTrack.insert(e);
        }
    }

    public void execEvent(MidiEvent event) {
        if (event instanceof EventChannel) {
            EventChannel e = (EventChannel) event;
            switch (e.getType()) {
                case 8:
                    noteOff(e.getChannel(), e.getValue1());
                    break;
                case 9:
                    noteOn(e.getChannel(), e.getValue1(), e.getValue2());
                    break;
                case 11:
                    controlChange(e.getChannel(), e.getValue1(), e.getValue2());
                    break;
                case 12:
                    programChange(e.getChannel(), e.getValue1());
                    break;
                case MusicScore.TitleHeight /* 14 */:
                    // 14 bits: LSB (value1) + MSB (value2). Antes solo se usaba el LSB (0-127), lo que dejaba el canal
                    // casi totalmente desafinado hacia abajo con CUALQUIER evento de pitch bend.
                    pitchBend(e.getChannel(), ((e.getValue2() & 127) << 7) | (e.getValue1() & 127));
                    break;
            }
            if (this.recording && this.playing) {
                if (this.recordTrack == null) {
                    this.recordTrack = new MidiTrack();
                }
                int millisecondsPerTick = (this.midiFile.getTempo().getMpqn() / 1000) / this.midiFile.getResolution();
                int tick = (int) ((System.currentTimeMillis() - this.lastBeatMillis) / ((long) millisecondsPerTick));
                MidiEvent ne = new EventChannel(this.lastBeatTicks + tick, e.getType(), e.getChannel(), e.getValue1(), e.getValue2());
                this.recordTrack.insert(ne);
            }
        }
    }

    public int getNumerator() {
        return this.midiFile.getTimeSignature().getNumerator();
    }

    public int getResolution() {
        return this.midiFile.getResolution();
    }

    public MidiTrack getRecordTrack() {
        return this.recordTrack;
    }

    public MidiFile getMidiFile() {
        return this.midiFile;
    }

    public File getFile() {
        return this.file;
    }

    public void setFile(File f) {
        stop();
        this.file = f;
        if (this.file == null) {
            this.midiFile = new MidiFile();
            return;
        }
        try {
            this.midiFile = new MidiFile(new FileInputStream(this.file));
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        this.scores = new boolean[this.midiFile.getCount()];
        int prog = -1;
        for (int c = 0; c < this.midiFile.getCount(); c++) {
            MidiTrack t = this.midiFile.getTracks().get(c);
            this.scores[c] = false;
            if (t.getChannel() >= 0) {
                if (prog == -1) {
                    this.scores[c] = true;
                    prog = t.getProgram();
                } else if (t.getProgram() == prog) {
                    this.scores[c] = true;
                }
            }
        }
        this.styleMix = false;
        applyFileSetup();
        System.gc();
    }


    // ------------------------------------------------------------------
    //  Configuracion de canales al cargar un MIDI / estilo
    // ------------------------------------------------------------------
    /** Quita los ajustes manuales ("Channels settings") de los canales indicados. */
    public void clearOverrides(int from, int to) {
        for (int ch = from; ch <= to && ch < 16; ch++) {
            this.controls.get(ch).clear();
        }
    }

    /** Devuelve los canales al estado GM por defecto (volumen, pan, efectos, banco, programa). */
    public void resetChannels(int from, int to) {
        for (int ch = from; ch <= to && ch < 16; ch++) {
            XSynth.midiPlayerCC(ch, XSynth.ALL_CTRL_OFF, 0);
            this.baseVolume[ch] = 100;
            XSynth.midiPlayerCC(ch, XSynth.VOLUME_MSB, 100);
            XSynth.midiPlayerCC(ch, XSynth.PAN_MSB, 64);
            XSynth.midiPlayerCC(ch, XSynth.EXPRESSION_MSB, 127);
            XSynth.midiPlayerCC(ch, XSynth.EFFECTS_DEPTH1, 40);
            XSynth.midiPlayerCC(ch, XSynth.EFFECTS_DEPTH3, 0);
            XSynth.midiPlayerPitchBend(ch, 8192);
            if (ch != DRUMS_CHAN) {
                XSynth.midiPlayerBankSelect(ch, 0);
            }
            XSynth.midiPlayerProgramChange(ch, 0);
        }
    }

    /**
     * Aplica a cada canal los bancos/programas/controles que el archivo declara ANTES de su
     * primera nota (cualquier tick, cualquier pista, tambien MIDI tipo 0), en el orden correcto:
     * banco -> programa -> resto de controles.
     */
    private void applyFileSetup() {
        resetChannels(0, 15);
        clearOverrides(0, 15);
        ArrayList<ArrayList<EventChannel>> perChan = new ArrayList<>();
        for (int i = 0; i < 16; i++) {
            perChan.add(new ArrayList<EventChannel>());
        }
        boolean[] started = new boolean[16];
        TreeSet<MidiEvent> all = new TreeSet<>();
        for (MidiTrack t : this.midiFile.getTracks()) {
            all.addAll(t.getEvents());
        }
        for (MidiEvent ev : all) {
            if (!(ev instanceof EventChannel)) {
                continue;
            }
            EventChannel e = (EventChannel) ev;
            int ch = e.getChannel() & 15;
            if (e.getType() == 9 && e.getValue2() > 0) {
                started[ch] = true;
            }
            if (!started[ch]) {
                perChan.get(ch).add(e);
            }
        }
        for (int ch = 0; ch < 16; ch++) {
            ArrayList<EventChannel> l = perChan.get(ch);
            for (EventChannel e : l) {                                  // 1) banco
                if (e.getType() == 11 && (e.getValue1() == XSynth.BANK_SELECT_MSB || e.getValue1() == XSynth.BANK_SELECT_LSB)
                        && ch != DRUMS_CHAN) {
                    XSynth.midiPlayerCC(ch, e.getValue1(), e.getValue2());
                }
            }
            for (EventChannel e : l) {                                  // 2) programa
                if (e.getType() == 12) {
                    if (ch == DRUMS_CHAN) {
                        XSynth.midiPlayerProgramChange(ch, (e.getValue1() / 8) * 8);
                    } else {
                        XSynth.midiPlayerProgramChange(ch, e.getValue1());
                    }
                }
            }
            for (EventChannel e : l) {                                  // 3) controles / pitch bend
                if (e.getType() == 11 && e.getValue1() != XSynth.BANK_SELECT_MSB && e.getValue1() != XSynth.BANK_SELECT_LSB) {
                    controlChange(ch, e.getValue1(), e.getValue2());
                } else if (e.getType() == 14) {
                    XSynth.midiPlayerPitchBend(ch, ((e.getValue2() & 127) << 7) | (e.getValue1() & 127));
                }
            }
        }
    }

    public boolean isPlaying() {
        return this.playing;
    }

    public boolean isPause() {
        return this.pause;
    }

    public boolean isBeating() {
        return this.beating;
    }

    public boolean isRecording() {
        return this.recording;
    }

    public void play() {
        if (this.mExecutor == null) {
            this.mExecutor = Executors.newSingleThreadExecutor();
            this.mRunnable = new Runnable() { // from class: net.duceng.xsynth.Synth.1
                @Override // java.lang.Runnable
                public void run() {
                    Synth.this.playing();
                }
            };
        }
        this.playing = true;
        this.pause = false;
        this.mExecutor.execute(this.mRunnable);
    }

    public void pause() {
        this.playing = false;
        this.pause = true;
    }

    public void stop() {
        this.playing = false;
        this.pause = false;
        this.lastBeatTicks = 0;
    }

    public void setBeating(boolean b) {
        this.beating = b;
    }

    public void setRecording(boolean r) {
        this.recording = r;
        if (this.recording) {
            this.recordTrack = new MidiTrack();
            this.recordTrack.setChannel(this.recordChan);
            this.recordTrack.setProgram((byte) getPreset(this.recordChan));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:110:0x0290  */
    /* JADX WARN: Code duplicated, block: B:113:0x029a  */
    /* JADX WARN: Code duplicated, block: B:115:0x02a9  */
    /* JADX WARN: Code duplicated, block: B:181:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:47:0x00e5  */
    /* JADX WARN: Code duplicated, block: B:50:0x00f9  */
    public void playing() {
        this.playLoopActive = true;
        try {
            playingInner();
        } finally {
            this.playLoopActive = false;
        }
    }

    private void playingInner() {
        Iterator<MidiEvent> it;
        EventChannel e;
        if (this.statusListener != null) {
            this.statusListener.onStatusChanged(true);
        }
        TreeSet<MidiEvent> events = new TreeSet<>();
        TreeSet<MidiEvent> beats = new TreeSet<>();
        for (MidiTrack t : this.midiFile.getTracks()) {
            events.addAll(t.getEvents());
        }
        if (this.recordTrack != null) {
            events.addAll(this.recordTrack.getEvents());
        }
        MetaTempo tempo = this.midiFile.getTempo();
        MetaTimeSignature timeSignature = this.midiFile.getTimeSignature();
        int resolution = this.midiFile.getResolution() * 4;
        for (int i = 0; i < timeSignature.getDenominator(); i++) {
            resolution /= 2;
        }
        long milliseconds = tempo.getMpqn() / 1000;
        int tick = 0;
        while (true) {
            int i2 = 0;
            while (i2 < timeSignature.getNumerator()) {
                events.add(new EventChannel(tick, (byte) 9, DRUMS_CHAN, i2 == 0 ? this.beatNote1 : this.beatNote2, (byte) -1));
                tick += resolution;
                i2++;
            }
            if ((events.last() instanceof EventChannel) && ((EventChannel) events.last()).getValue2() == -1) {
                break;
            }
        }
        int i3 = 0;
        while (i3 < timeSignature.getNumerator()) {
            beats.add(new EventChannel(i3 * resolution, (byte) 9, DRUMS_CHAN, i3 == 0 ? this.beatNote1 : this.beatNote2, (byte) -1));
            i3++;
        }
        if (this.recording) {
            for (int i4 = 0; i4 < timeSignature.getNumerator() && this.playing; i4++) {
                noteOn(DRUMS_CHAN, this.beatNote2, this.beatVelocity);
                try {
                    Thread.sleep(milliseconds);
                } catch (InterruptedException e2) {
                    throw new RuntimeException("Interrupted during sleep.");
                }
            }
        }
        do {
            int ticking = this.lastBeatTicks;
            long lastSleep = System.currentTimeMillis();
            for (MidiEvent event : events) {
                if (this.playing) {
                    if (this.lastBeatTicks <= event.getTick()) {
                        int delta = event.getTick() - ticking;
                        if (delta > 0) {
                            ticking = event.getTick();
                            long deltamillis = ((long) MidiUtil.ticksToMs(delta, tempo.getMpqn(), this.midiFile.getResolution())) - (System.currentTimeMillis() - lastSleep);
                            if (deltamillis > 0) {
                                try {
                                    Thread.sleep(deltamillis);
                                } catch (InterruptedException e3) {
                                    throw new RuntimeException("Interrupted during sleep.");
                                }
                            }
                            lastSleep = System.currentTimeMillis();
                        }
                        if (event instanceof EventChannel) {
                            EventChannel ec = (EventChannel) event;
                            if (!this.mutes[ec.getChannel()]) {
                                switch (ec.getType()) {
                                    case 8:
                                        noteOff(ec.getChannel(), ec.getValue1());
                                        break;
                                    case 9:
                                        if (ec.getChannel() == DRUMS_CHAN && ec.getValue2() == -1) {
                                            if (this.beating) {
                                                noteOn(ec.getChannel(), ec.getValue1(), this.beatVelocity);
                                            }
                                            this.lastBeatMillis = System.currentTimeMillis();
                                            this.lastBeatTicks = ec.getTick();
                                            if (this.beatListener != null) {
                                                this.beatListener.onBeating(ec.getTick());
                                            }
                                        } else {
                                            noteOn(ec.getChannel(), ec.getValue1(), ec.getValue2());
                                        }
                                        break;
                                    case 11:
                                        controlChange(ec.getChannel(), ec.getValue1(), ec.getValue2());
                                        break;
                                    case 12:
                                        programChange(ec.getChannel(), ec.getValue1());
                                        break;
                                    case MusicScore.TitleHeight /* 14 */:
                                        pitchBend(ec.getChannel(), ec.getValue1());
                                        break;
                                }
                            }
                        }
                    }
                }
            }
            try {
                Thread.sleep(milliseconds);
                if (!this.pause) {
                    this.lastBeatTicks = 0;
                }
                if (this.playing) {
                }
                while (this.playing) {
                    it = beats.iterator();
                    while (it.hasNext()) {
                        e = (EventChannel) it.next();
                        if (this.beating) {
                            noteOn(e.getChannel(), e.getValue1(), this.beatVelocity);
                        }
                        this.lastBeatMillis = System.currentTimeMillis();
                        this.lastBeatTicks += resolution;
                        try {
                            Thread.sleep(milliseconds);
                        } catch (InterruptedException e4) {
                            throw new RuntimeException("Interrupted during sleep.");
                        }
                    }
                }
                if (!this.pause) {
                    this.lastBeatTicks = 0;
                }
                allNotesoff();
                this.lastBeatMillis = 0L;
                if (this.statusListener != null) {
                    this.statusListener.onStatusChanged(false);
                }
            } catch (InterruptedException e5) {
                throw new RuntimeException("Interrupted during sleep.");
            }
        } while (!this.recording);
        while (this.playing) {
            it = beats.iterator();
            while (it.hasNext()) {
                e = (EventChannel) it.next();
                if (this.beating) {
                    noteOn(e.getChannel(), e.getValue1(), this.beatVelocity);
                }
                this.lastBeatMillis = System.currentTimeMillis();
                this.lastBeatTicks += resolution;
                try {
                    Thread.sleep(milliseconds);
                } catch (InterruptedException e6) {
                    throw new RuntimeException("Interrupted during sleep.");
                }
            }
        }
        if (!this.pause) {
            this.lastBeatTicks = 0;
        }
        allNotesoff();
        this.lastBeatMillis = 0L;
        if (this.statusListener != null) {
            this.statusListener.onStatusChanged(false);
        }
    }

    public float getBeatPercent() {
        int interval = 60000 / this.midiFile.getTempo().getBpm();
        float elapsed = System.currentTimeMillis() - this.lastBeatMillis;
        return elapsed / interval;
    }

    public byte getBeatVelocity() {
        return this.beatVelocity;
    }

    public void setBeatVelocity(byte beatVelocity) {
        this.beatVelocity = beatVelocity;
    }

    public byte getBeatNote1() {
        return this.beatNote1;
    }

    public void setBeatNote1(byte beatNote1) {
        this.beatNote1 = beatNote1;
    }

    public byte getBeatNote2() {
        return this.beatNote2;
    }

    public void setBeatNote2(byte beatNote2) {
        this.beatNote2 = beatNote2;
    }

    public int getLastBeatTicks() {
        return this.lastBeatTicks;
    }

    public void setBeatListener(BeatListener l) {
        this.beatListener = l;
    }

    public void setStatusListener(StatusListener l) {
        this.statusListener = l;
    }
}
