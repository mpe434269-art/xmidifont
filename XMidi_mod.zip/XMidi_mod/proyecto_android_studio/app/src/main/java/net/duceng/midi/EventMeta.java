package net.duceng.midi;

import java.io.IOException;
import java.io.OutputStream;

/* JADX INFO: loaded from: classes.dex */
public class EventMeta extends MidiEvent {
    public static final short COPYRIGHT_NOTICE = 2;
    public static final short CUE_POINT = 7;
    public static final short END_OF_TRACK = 47;
    public static final short INSTRUMENT_NAME = 4;
    public static final short KEY_SIGNATURE = 89;
    public static final short LYRICS = 5;
    public static final short MARKER = 6;
    public static final short MIDI_CHANNEL_PREFIX = 32;
    public static final short SEQUENCER_SPECIFIC = 127;
    public static final short SEQUENCE_NUMBER = 0;
    public static final short SMPTE_OFFSET = 84;
    public static final short TEMPO = 81;
    public static final short TEXT_EVENT = 1;
    public static final short TIME_SIGNATURE = 88;
    public static final short TRACK_NAME = 3;
    protected int length;
    protected short type;
    protected byte[] value;

    protected EventMeta(int t, int d, short tp, byte[] v) {
        super(t, d);
        this.type = tp;
        this.value = v;
        this.length = v.length;
    }

    public short getType() {
        return this.type;
    }

    public void setType(short t) {
        this.type = t;
    }

    public int getLength() {
        return this.length;
    }

    public byte[] getValue() {
        return this.value;
    }

    public void setValue(byte[] v) {
        this.value = v;
        this.length = v.length;
    }

    @Override // net.duceng.midi.MidiEvent
    public int getSize() {
        int size = super.getSize();
        return size + MidiUtil.vintToBytes(this.length).length + 2 + this.length;
    }

    @Override // net.duceng.midi.MidiEvent
    public void write(OutputStream out) throws IOException {
        super.write(out);
        out.write(255);
        out.write(this.type);
        out.write(MidiUtil.vintToBytes(this.length));
        out.write(this.value);
    }

    @Override // java.lang.Comparable
    public int compareTo(MidiEvent other) {
        if (this.tick != other.getTick()) {
            return this.tick >= other.getTick() ? 1 : -1;
        }
        if (this.delta != other.delta) {
            return this.delta >= other.delta ? -1 : 1;
        }
        if (!(other instanceof EventMeta)) {
            return 1;
        }
        EventMeta o = (EventMeta) other;
        if (this.type != o.type) {
            return this.type >= o.type ? -1 : 1;
        }
        String curr = new String(this.value);
        String comp = new String(((EventMeta) other).value);
        return curr.compareTo(comp);
    }
}
