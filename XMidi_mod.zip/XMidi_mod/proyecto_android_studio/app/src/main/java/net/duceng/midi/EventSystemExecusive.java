package net.duceng.midi;

import java.io.IOException;
import java.io.OutputStream;

/* JADX INFO: loaded from: classes.dex */
public class EventSystemExecusive extends MidiEvent {
    protected int length;
    protected short type;
    protected byte[] value;

    protected EventSystemExecusive(int t, int d, short tp, byte[] v) {
        super(t, d);
        if (tp != 240 && tp != 247) {
            tp = 240;
        }
        this.type = tp;
        this.value = v;
        this.length = v.length;
    }

    public short getType() {
        return this.type;
    }

    public void setType(short t) {
        this.type = t;
    }

    public int getLength() {
        return this.length;
    }

    public byte[] getValue() {
        return this.value;
    }

    public void setValue(byte[] v) {
        this.value = v;
        this.length = v.length;
    }

    @Override // net.duceng.midi.MidiEvent
    public int getSize() {
        int size = super.getSize();
        return size + MidiUtil.vintToBytes(this.length).length + 1 + this.length;
    }

    @Override // net.duceng.midi.MidiEvent
    public void write(OutputStream out) throws IOException {
        super.write(out);
        out.write(this.type);
        out.write(MidiUtil.vintToBytes(this.length));
        out.write(this.value);
    }

    @Override // java.lang.Comparable
    public int compareTo(MidiEvent other) {
        if (this.tick != other.getTick()) {
            return this.tick >= other.getTick() ? 1 : -1;
        }
        if (this.delta != other.delta) {
            return this.delta >= other.delta ? -1 : 1;
        }
        if (!(other instanceof EventSystemExecusive)) {
            return 1;
        }
        String curr = new String(this.value);
        String comp = new String(((EventSystemExecusive) other).value);
        return curr.compareTo(comp);
    }
}
