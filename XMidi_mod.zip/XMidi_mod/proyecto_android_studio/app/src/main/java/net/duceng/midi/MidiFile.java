package net.duceng.midi;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class MidiFile {
    public static final int DEFAULT_RESOLUTION = 480;
    public static final String HEAD = "MThd";
    private int count;
    private MetaKeySignature keySignature;
    private int resolution;
    private MetaTempo tempo;
    private MetaTimeSignature timeSignature;
    private ArrayList<MidiTrack> tracks;
    private int type;

    public MidiFile() {
        this(DEFAULT_RESOLUTION);
    }

    public MidiFile(int r) {
        this(r, new ArrayList());
    }

    public MidiFile(int r, ArrayList<MidiTrack> t) {
        this.tempo = null;
        this.keySignature = null;
        this.timeSignature = null;
        this.resolution = r < 0 ? DEFAULT_RESOLUTION : r;
        this.tracks = t == null ? new ArrayList<>() : t;
        this.count = this.tracks.size();
        this.type = this.count <= 1 ? 0 : 1;
    }

    public MidiFile(InputStream is) throws IOException {
        this.tempo = null;
        this.keySignature = null;
        this.timeSignature = null;
        BufferedInputStream in = new BufferedInputStream(is);
        byte[] buffer = new byte[14];
        in.read(buffer);
        String head = new String(buffer, 0, 4, "US-ASCII");
        if (!head.equals("MThd")) {
            System.out.println("File identifier not MThd. Exiting");
            this.type = 0;
            this.count = 0;
            this.resolution = DEFAULT_RESOLUTION;
            return;
        }
        this.type = MidiUtil.bytesToInt(buffer, 8, 2);
        this.count = MidiUtil.bytesToInt(buffer, 10, 2);
        this.resolution = MidiUtil.bytesToInt(buffer, 12, 2);
        this.tracks = new ArrayList<>();
        for (int i = 0; i < this.count; i++) {
            this.tracks.add(new MidiTrack(in));
            System.out.println("T: " + i + " CH: " + ((int) this.tracks.get(i).getChannel()) + " PRG: " + ((int) this.tracks.get(i).getProgram()) + " CTLS: " + this.tracks.get(i).getControls().size() + " COUNT: " + this.tracks.get(i).events.size() + " COUNT: " + this.tracks.get(i).getCount());
        }
        System.out.println("Track size: " + this.tracks.size());
    }

    public void setType(int t) {
        if (t < 0) {
            t = 0;
        } else if (t > 2) {
            t = 1;
        } else if (t == 0 && this.count > 1) {
            t = 1;
        }
        this.type = t;
    }

    public int getType() {
        return this.type;
    }

    public int getCount() {
        return this.count;
    }

    public void setResolution(int res) {
        if (res >= 0) {
            this.resolution = res;
        }
    }

    public int getResolution() {
        return this.resolution;
    }

    public long getTicks() {
        long length = 0;
        for (MidiTrack T : this.tracks) {
            long l = T.getLastTicks();
            if (l > length) {
                length = l;
            }
        }
        return length;
    }

    public ArrayList<MidiTrack> getTracks() {
        return this.tracks;
    }

    public void addTrack(MidiTrack t) {
        this.tracks.add(t);
        this.count = this.tracks.size();
        this.type = this.count <= 1 ? 0 : 1;
    }

    public void removeTrack(int pos) {
        if (pos >= 0 && pos < this.tracks.size()) {
            this.tracks.remove(pos);
            this.count = this.tracks.size();
            this.type = this.count <= 1 ? 0 : 1;
        }
    }

    public void write(OutputStream out) throws IOException {
        out.write("MThd".getBytes("US-ASCII"));
        out.write(MidiUtil.intToBytes(6, 4));
        out.write(MidiUtil.intToBytes(this.type, 2));
        out.write(MidiUtil.intToBytes(this.count, 2));
        out.write(MidiUtil.intToBytes(this.resolution, 2));
        for (MidiTrack t : this.tracks) {
            t.write(out);
        }
    }

    public MetaTempo getTempo() {
        if (this.tempo != null) {
            return this.tempo;
        }
        for (MidiTrack t : this.tracks) {
            for (MidiEvent e : t.getEvents()) {
                if (e instanceof MetaTempo) {
                    this.tempo = (MetaTempo) e;
                    return this.tempo;
                }
            }
        }
        this.tempo = new MetaTempo();
        return this.tempo;
    }

    public MetaKeySignature getKeySignature() {
        if (this.keySignature != null) {
            return this.keySignature;
        }
        for (MidiTrack t : this.tracks) {
            for (MidiEvent e : t.getEvents()) {
                if (e instanceof MetaKeySignature) {
                    this.keySignature = (MetaKeySignature) e;
                    return this.keySignature;
                }
            }
        }
        this.keySignature = new MetaKeySignature();
        return this.keySignature;
    }

    public MetaTimeSignature getTimeSignature() {
        if (this.timeSignature != null) {
            return this.timeSignature;
        }
        for (MidiTrack t : this.tracks) {
            for (MidiEvent e : t.getEvents()) {
                if (e instanceof MetaTimeSignature) {
                    this.timeSignature = (MetaTimeSignature) e;
                    return this.timeSignature;
                }
            }
        }
        this.timeSignature = new MetaTimeSignature();
        return this.timeSignature;
    }
}
