package net.duceng.midi;

/* JADX INFO: loaded from: classes.dex */
public class StyControl {
    protected static final byte Bass = 3;
    protected static final byte Bypass = 0;
    protected static final byte Chord = 2;
    private static StyControl DEFAULT = null;
    protected static final byte HarmonicMinor = 5;
    protected static final byte MelodicMinor = 4;
    protected static final byte Melody = 1;
    protected static final byte RootFix = 1;
    protected static final byte RootTran = 0;
    protected byte chord;
    protected byte[] chordMute;
    protected byte destination;
    protected byte editable;
    protected byte highLimit;
    protected byte highkey;
    protected byte lowLimit;
    protected String name;
    protected byte[] noteMute;
    protected byte noteRule;
    protected byte noteTable;
    protected byte ntt;
    protected byte retriggerRule;
    protected byte root;
    protected byte source;

    public StyControl(byte[] data) {
        this.noteMute = new byte[2];
        this.chordMute = new byte[5];
        this.source = data[0];
        this.name = new String(data, 1, 8);
        this.destination = data[9];
        this.editable = data[10];
        System.arraycopy(data, 11, this.noteMute, 0, this.noteMute.length);
        System.arraycopy(data, 13, this.chordMute, 0, this.chordMute.length);
        this.root = data[18];
        this.chord = data[19];
        this.noteRule = data[20];
        this.noteTable = data[21];
        this.highkey = data[22];
        this.lowLimit = data[23];
        this.highLimit = data[24];
        this.retriggerRule = data[25];
    }

    private StyControl() {
        this.noteMute = new byte[2];
        this.chordMute = new byte[5];
        this.source = (byte) -1;
        this.destination = (byte) -1;
        this.name = "DEFAULT";
        this.root = (byte) 0;
        this.chord = (byte) 2;
        this.noteRule = (byte) -1;
        this.noteTable = (byte) -1;
        this.highkey = (byte) 11;
        this.lowLimit = (byte) 0;
        this.highLimit = (byte) 127;
        this.retriggerRule = (byte) -1;
    }

    protected static StyControl getDefault() {
        if (DEFAULT == null) {
            DEFAULT = new StyControl();
        }
        return DEFAULT;
    }
}
