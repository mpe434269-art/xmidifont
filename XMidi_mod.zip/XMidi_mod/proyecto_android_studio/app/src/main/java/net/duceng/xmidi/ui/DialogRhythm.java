package net.duceng.xmidi.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListAdapter;
import net.duceng.xmidi.util.AdapterRhythm;
import net.duceng.xmidi.util.Rhythm;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes.dex */
public class DialogRhythm extends XDialog {
    private AdapterRhythm ar;
    private OnSelectListener onSelectListener;
    protected Synth synth;

    public interface OnSelectListener {
        boolean onSelect(Rhythm rhythm);
    }

    public DialogRhythm(Context context, Synth s) {
        super(context);
        this.synth = s;
        this.ar = new AdapterRhythm(getContext());
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.rhythm);
        GridView gv = (GridView) getLayoutInflater().inflate(R.layout.grid, (ViewGroup) null);
        gv.setNumColumns(2);
        gv.setAdapter((ListAdapter) this.ar);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.duceng.xmidi.ui.DialogRhythm.1
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View v, int pos, long id) {
                if (DialogRhythm.this.onSelectListener != null) {
                    DialogRhythm.this.onSelectListener.onSelect(DialogRhythm.this.ar.getItem(pos));
                }
            }
        });
        setContentView(gv);
    }

    @Override // net.duceng.xmidi.ui.XDialog, android.app.Dialog
    protected void onStart() {
        this.ar.setBeat(this.synth.getNumerator());
        super.onStart();
    }

    public AdapterRhythm getAdapter() {
        return this.ar;
    }

    public void setOnSelectListener(OnSelectListener l) {
        this.onSelectListener = l;
    }
}
