package net.duceng.xmidi.ui;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes.dex */
public class XDialog extends Dialog {
    private LinearLayout bottom;
    private Context context;
    private View dialog;
    private ImageView icon;
    private Button title;
    private LinearLayout tools;
    private FrameLayout wapper;

    public XDialog(Context c) {
        super(c, R.style.dialog);
        this.context = c;
        this.dialog = getLayoutInflater().inflate(R.layout.dialog, (ViewGroup) null);
        this.wapper = (FrameLayout) this.dialog.findViewById(R.id.dialog_wapper);
        this.tools = (LinearLayout) this.dialog.findViewById(R.id.dialog_tools);
        this.title = (Button) this.dialog.findViewById(R.id.dialog_title);
        this.icon = (ImageView) this.dialog.findViewById(R.id.dialog_icon);
        this.bottom = (LinearLayout) this.dialog.findViewById(R.id.dialog_bottom);
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(1);
        super.onCreate(savedInstanceState);
        super.setContentView(this.dialog);
    }

    @Override // android.app.Dialog
    protected void onStart() {
        int width = getContext().getResources().getDisplayMetrics().widthPixels;
        int height = getContext().getResources().getDisplayMetrics().heightPixels;
        getWindow().setLayout((int) (width > height ? ((double) width) * 0.6d : ((double) width) * 0.9d), -2);
        if (this.bottom.getChildCount() == 0) {
            this.bottom.setVisibility(8);
        }
        super.onStart();
    }

    @Override // android.app.Dialog
    public void setContentView(int id) {
        View child = getLayoutInflater().inflate(id, (ViewGroup) this.wapper, false);
        this.wapper.addView(child);
    }

    @Override // android.app.Dialog
    public void setContentView(View view) {
        this.wapper.addView(view);
    }

    public FrameLayout getWapper() {
        return this.wapper;
    }

    @Override // android.app.Dialog
    public void setTitle(CharSequence t) {
        this.title.setText(t);
    }

    @Override // android.app.Dialog
    public void setTitle(int titleId) {
        this.title.setText(titleId);
    }

    public void setIcon(Drawable d) {
        this.icon.setImageDrawable(d);
    }

    public void setIcon(int resId) {
        this.icon.setImageResource(resId);
    }

    public void addAction(View v) {
        this.tools.addView(v);
    }

    public void addButton(int id, final View.OnClickListener listener) {
        if (this.bottom.getChildCount() > 0) {
            View d = getLayoutInflater().inflate(R.layout.divider_v, (ViewGroup) this.bottom, false);
            this.bottom.addView(d);
        }
        Button b = (Button) getLayoutInflater().inflate(R.layout.button, (ViewGroup) this.bottom, false);
        b.setText(id);
        b.setOnClickListener(new View.OnClickListener() { // from class: net.duceng.xmidi.ui.XDialog.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (listener != null) {
                    listener.onClick(v);
                }
                XDialog.this.dismiss();
            }
        });
        this.bottom.addView(b);
    }

    public void setItems(int id, AdapterView.OnItemClickListener listener) {
        ListView lv = (ListView) getLayoutInflater().inflate(R.layout.list, (ViewGroup) null);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this.context, R.layout.list_item, this.context.getResources().getStringArray(id));
        lv.setAdapter((ListAdapter) arrayAdapter);
        lv.setOnItemClickListener(listener);
        this.wapper.addView(lv);
    }
}
