package net.duceng.xmidi.util;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.TextView;
import net.duceng.xmidi.ui.DialogPreset;
import net.duceng.xsynth.R;
import net.duceng.xsynth.Synth;

/* JADX INFO: loaded from: classes.dex */
public class AdapterChannel extends BaseAdapter {
    private Context context;
    private String[] drums;
    private String[] instruments;
    private CompoundButton.OnCheckedChangeListener onCheckedChangeListener = new CompoundButton.OnCheckedChangeListener() { // from class: net.duceng.xmidi.util.AdapterChannel.1
        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public void onCheckedChanged(CompoundButton cb, boolean arg1) {
            int chan = ((Integer) cb.getTag()).intValue();
            AdapterChannel.this.synth.setMute(chan, !arg1);
        }
    };
    private View.OnClickListener onClickListener = new View.OnClickListener() { // from class: net.duceng.xmidi.util.AdapterChannel.2
        private DialogPreset dialogPreset;

        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            if (this.dialogPreset == null) {
                this.dialogPreset = new DialogPreset(AdapterChannel.this.context, AdapterChannel.this.synth);
                this.dialogPreset.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: net.duceng.xmidi.util.AdapterChannel.2.1
                    @Override // android.content.DialogInterface.OnDismissListener
                    public void onDismiss(DialogInterface arg0) {
                        AdapterChannel.this.notifyDataSetChanged();
                    }
                });
            }
            int chan = ((Integer) v.getTag()).intValue();
            this.dialogPreset.setChannel(chan);
            this.dialogPreset.show();
        }
    };
    private Synth synth;

    public AdapterChannel(Context c, Synth s) {
        this.context = c;
        this.synth = s;
        this.instruments = this.context.getResources().getStringArray(R.array.preset_instruments);
        this.drums = this.context.getResources().getStringArray(R.array.preset_drums);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return 16;
    }

    @Override // android.widget.Adapter
    public String getItem(int pos) {
        return this.synth.getBank(pos) == Synth.DRUMS_BANK ? this.drums[this.synth.getPreset(pos) / 8] : this.instruments[this.synth.getPreset(pos)];
    }

    @Override // android.widget.Adapter
    public long getItemId(int pos) {
        return this.synth.getPreset(pos);
    }

    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
    public boolean isEnabled(int position) {
        return !this.synth.isMute(position);
    }

    @Override // android.widget.Adapter
    public View getView(int position, View view, ViewGroup parent) {
        if (view == null) {
            view = LayoutInflater.from(this.context).inflate(R.layout.list_item_chann, (ViewGroup) null);
            ((CheckBox) view.findViewById(R.id.chann_check)).setOnCheckedChangeListener(this.onCheckedChangeListener);
            ((ImageButton) view.findViewById(R.id.chann_settings)).setOnClickListener(this.onClickListener);
        }
        CheckBox cb = (CheckBox) view.findViewById(R.id.chann_check);
        cb.setTag(Integer.valueOf(position));
        cb.setChecked(!this.synth.isMute(position));
        ((ImageButton) view.findViewById(R.id.chann_settings)).setTag(Integer.valueOf(position));
        if (this.synth.getBank(position) == Synth.DRUMS_BANK) {
            ((TextView) view.findViewById(R.id.chann_name)).setText(String.valueOf(position) + ": " + this.drums[this.synth.getPreset(position) / 8]);
        } else {
            ((TextView) view.findViewById(R.id.chann_name)).setText(String.valueOf(position) + ": " + this.instruments[this.synth.getPreset(position)]);
        }
        if (position == this.synth.getRecordChan()) {
            view.setBackgroundColor(this.context.getResources().getColor(R.color.selected));
        } else {
            view.setBackgroundColor(0);
        }
        return view;
    }
}
