package net.duceng.xmidi.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;
import java.lang.reflect.Array;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes.dex */
public class AdapterProgram extends BaseExpandableListAdapter {
    private Context context;
    private String[] groups;
    private int selected = 0;
    private String[][] presets = (String[][]) Array.newInstance((Class<?>) String.class, 16, 8);

    public AdapterProgram(Context context) {
        this.context = context;
        this.groups = context.getResources().getStringArray(R.array.preset_groups);
        String[] instruments = context.getResources().getStringArray(R.array.preset_instruments);
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 8; j++) {
                this.presets[i][j] = instruments[(i * 8) + j];
            }
        }
    }

    public void setSelected(int pos) {
        this.selected = pos;
    }

    @Override // android.widget.ExpandableListAdapter
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(this.context);
            convertView = inflater.inflate(R.layout.list_expand_item, (ViewGroup) null);
        }
        ((TextView) convertView).setText(getGroup(groupPosition).toString());
        return convertView;
    }

    @Override // android.widget.ExpandableListAdapter
    public View getChildView(int gpos, int cpos, boolean isLastChild, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(this.context);
            convertView = inflater.inflate(R.layout.list_expand_item, (ViewGroup) null);
        }
        ((TextView) convertView).setText(String.valueOf(getChild(gpos, cpos)) + " (" + String.valueOf((gpos * 8) + cpos) + ")");
        if ((gpos * 8) + cpos == this.selected) {
            convertView.setBackgroundColor(this.context.getResources().getColor(R.color.selected));
        } else {
            convertView.setBackgroundColor(0);
        }
        return convertView;
    }

    @Override // android.widget.ExpandableListAdapter
    public String getChild(int gpos, int cpos) {
        return this.presets[gpos][cpos];
    }

    @Override // android.widget.ExpandableListAdapter
    public long getChildId(int gpos, int cpos) {
        return (gpos * 8) + cpos;
    }

    @Override // android.widget.ExpandableListAdapter
    public int getChildrenCount(int gpos) {
        return this.presets[gpos].length;
    }

    @Override // android.widget.ExpandableListAdapter
    public String getGroup(int gpos) {
        return this.groups[gpos];
    }

    @Override // android.widget.ExpandableListAdapter
    public long getGroupId(int gpos) {
        return gpos;
    }

    @Override // android.widget.ExpandableListAdapter
    public int getGroupCount() {
        return this.groups.length;
    }

    @Override // android.widget.ExpandableListAdapter
    public boolean hasStableIds() {
        return true;
    }

    @Override // android.widget.ExpandableListAdapter
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
