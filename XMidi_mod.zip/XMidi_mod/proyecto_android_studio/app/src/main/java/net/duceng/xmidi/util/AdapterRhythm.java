package net.duceng.xmidi.util;

import android.content.Context;
import android.content.res.XmlResourceParser;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import net.duceng.xmidi.widgets.GRhythm;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes.dex */
public class AdapterRhythm extends BaseAdapter {
    private Context context;
    private ArrayList<Rhythm> items = new ArrayList<>();
    private Map<Integer, ArrayList<Rhythm>> rhythms = new HashMap();
    private int beat = 4;

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:10:0x0037  */
    /* JADX WARN: Failed to find 'out' block for switch in B:9:0x0034. Please report as an issue. */
    public AdapterRhythm(Context c) {
        Rhythm rhythm;
        this.context = c;
        XmlResourceParser parser = this.context.getResources().getXml(R.xml.rhythm);
        try {
            int event = parser.getEventType();
            Rhythm rhythm2 = null;
            while (event != 1) {
                switch (event) {
                    case 0:
                        rhythm = rhythm2;
                        event = parser.next();
                        rhythm2 = rhythm;
                        break;
                    case 1:
                    default:
                        rhythm = rhythm2;
                        event = parser.next();
                        rhythm2 = rhythm;
                        break;
                    case 2:
                        try {
                            if ("rhythm".equals(parser.getName())) {
                                rhythm = new Rhythm();
                                rhythm.id = parser.getAttributeIntValue(null, "id", 0);
                                rhythm.beat = (byte) parser.getAttributeIntValue(null, "beat", 4);
                                rhythm.durs = (byte) parser.getAttributeIntValue(null, "durs", 4);
                            } else {
                                rhythm = rhythm2;
                            }
                            if (rhythm != null && "chord".equals(parser.getName())) {
                                Rhythm.RChord chord = rhythm.addChord();
                                chord.dur = (byte) parser.getAttributeIntValue(null, "dur", 1);
                                chord.mod = (byte) parser.getAttributeIntValue(null, "mod", 0);
                                chord.keep = parser.getAttributeBooleanValue(null, "keep", false);
                                int val = parser.getAttributeIntValue(null, "chord", 0);
                                byte[] vals = new byte[String.valueOf(val).length()];
                                for (int i = vals.length - 1; i >= 0; i--) {
                                    vals[i] = (byte) (val % 10);
                                    val /= 10;
                                }
                                chord.chord = vals;
                            }
                            event = parser.next();
                            rhythm2 = rhythm;
                        } catch (Exception e) {
                            e = e;
                            e.printStackTrace();
                            System.gc();
                            setBeat(4);
                        }
                        break;
                    case 3:
                        if ("rhythm".equals(parser.getName())) {
                            if (!this.rhythms.containsKey(Integer.valueOf(rhythm2.beat))) {
                                this.rhythms.put(Integer.valueOf(rhythm2.beat), new ArrayList<>());
                            }
                            this.rhythms.get(Integer.valueOf(rhythm2.beat)).add(rhythm2);
                            rhythm = null;
                        } else {
                            rhythm = rhythm2;
                        }
                        event = parser.next();
                        rhythm2 = rhythm;
                        break;
                }
                System.gc();
                setBeat(4);
            }
        } catch (Exception e2) {
            e = e2;
        }
        System.gc();
        setBeat(4);
    }

    public int getBeat() {
        return this.beat;
    }

    public void setBeat(int b) {
        this.beat = b;
        this.items.clear();
        switch (this.beat) {
            case 2:
                if (this.rhythms.containsKey(2)) {
                    this.items.addAll(this.rhythms.get(2));
                }
                break;
            case 3:
                if (this.rhythms.containsKey(3)) {
                    this.items.addAll(this.rhythms.get(3));
                }
                break;
            case 4:
                if (this.rhythms.containsKey(2)) {
                    this.items.addAll(this.rhythms.get(2));
                }
                if (this.rhythms.containsKey(4)) {
                    this.items.addAll(this.rhythms.get(4));
                }
                break;
            case 6:
                if (this.rhythms.containsKey(3)) {
                    this.items.addAll(this.rhythms.get(3));
                }
                if (this.rhythms.containsKey(6)) {
                    this.items.addAll(this.rhythms.get(6));
                }
                break;
        }
        notifyDataSetChanged();
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.items.size();
    }

    @Override // android.widget.Adapter
    public Rhythm getItem(int position) {
        return this.items.get(position);
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return this.items.get(position).id;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View view, ViewGroup parent) {
        if (view == null) {
            view = LayoutInflater.from(this.context).inflate(R.layout.list_item_rhythm, (ViewGroup) null);
            view.setFocusable(false);
        }
        ((GRhythm) view).setRhythm(getItem(position));
        return view;
    }
}
