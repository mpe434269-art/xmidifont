package net.duceng.xmidi.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.io.File;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes.dex */
public class AdapterSFont extends BaseAdapter {
    private Context context;
    private int selected = 0;
    private MyArray<File> sfonts;

    public AdapterSFont(Context c, MyArray<File> s) {
        this.context = c;
        this.sfonts = s;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.sfonts.size();
    }

    @Override // android.widget.Adapter
    public File getItem(int position) {
        return this.sfonts.valueAt(position);
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return this.sfonts.keyAt(position);
    }

    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
    public boolean isEnabled(int position) {
        return true;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View view, ViewGroup parent) {
        if (view == null) {
            view = LayoutInflater.from(this.context).inflate(R.layout.list_item, (ViewGroup) null);
        }
        TextView tv = (TextView) view;
        tv.setText(getItem(position).getName());
        if (position == this.selected) {
            view.setBackgroundColor(this.context.getResources().getColor(R.color.selected));
        } else {
            view.setBackgroundColor(0);
        }
        return view;
    }

    public void setSelected(int pos) {
        this.selected = pos;
    }
}
