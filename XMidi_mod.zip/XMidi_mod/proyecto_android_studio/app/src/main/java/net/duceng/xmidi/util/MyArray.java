package net.duceng.xmidi.util;

import android.util.SparseArray;

/* JADX INFO: loaded from: classes.dex */
public class MyArray<E> extends SparseArray<E> {
    @Override // android.util.SparseArray
    public int indexOfValue(E value) {
        for (int i = 0; i < size(); i++) {
            if (valueAt(i).equals(value)) {
                return i;
            }
        }
        return -1;
    }
}
