package net.duceng.xmidi.util;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.RectF;
import java.util.ArrayList;
import java.util.List;
import net.duceng.midi.EventChannel;

/* JADX INFO: loaded from: classes.dex */
public class Rhythm {
    protected int id = 0;
    protected byte beat = 4;
    protected byte durs = 4;
    protected ArrayList<RChord> chords = new ArrayList<>();

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public byte getBeat() {
        return this.beat;
    }

    public void setBeat(byte beat) {
        this.beat = beat;
    }

    public byte getDurs() {
        return this.durs;
    }

    public void setDurs(byte durs) {
        this.durs = durs;
    }

    public ArrayList<RChord> getChords() {
        return this.chords;
    }

    public RChord getChord(int i) {
        return this.chords.get(i);
    }

    public RChord addChord() {
        RChord c = new RChord();
        this.chords.add(c);
        return c;
    }

    public List<EventChannel> getNotes(Chords.Chord chord) {
        int tickAdd;
        ArrayList<EventChannel> notes = new ArrayList<>();
        int totalTick = this.beat * 480;
        int durTick = totalTick / this.durs;
        int tick = 0;
        ArrayList<EventChannel> notesTmp = new ArrayList<>();
        for (RChord rchord : this.chords) {
            if (rchord.keep) {
                tick += rchord.dur * durTick;
            } else {
                for (EventChannel note : notesTmp) {
                    notes.add(new EventChannel(tick, (byte) 8, (byte) 0, note.getValue1(), (byte) 0));
                }
                notesTmp.clear();
                if (rchord.mod == 1) {
                    tickAdd = 5;
                } else {
                    tickAdd = rchord.mod == 2 ? 40 : 0;
                }
                for (int i = 0; i < rchord.chord.length; i++) {
                    EventChannel e = new EventChannel(tick + (tickAdd * i), (byte) 9, (byte) 0, chord.gnotes[6 - rchord.chord[i]], (byte) 80);
                    notes.add(e);
                    notesTmp.add(e);
                }
                tick += rchord.dur * durTick;
            }
        }
        for (EventChannel note2 : notesTmp) {
            notes.add(new EventChannel(tick, (byte) 8, (byte) 0, note2.getValue1(), (byte) 0));
        }
        return notes;
    }

    public void draw(Canvas canvas, int w, int h) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.argb(255, 144, 144, 144));
        int[] ly = {(h * 10) / 48, (h * 15) / 48, (h * 20) / 48, (h * 25) / 48, (h * 30) / 48, (h * 35) / 48};
        int lh = (h * 5) / 48;
        int lx1 = (w * 8) / 96;
        int lx2 = (w * 88) / 96;
        int dur_len = ((w * 80) / 96) / this.chords.size();
        int dur_x = lx1 + (dur_len / 2);
        int beat_durs = this.durs / this.beat;
        for (int i = 0; i < 6; i++) {
            canvas.drawLine(lx1, ly[i], lx2, ly[i], paint);
        }
        canvas.drawLine(lx1, ly[0], lx1, ly[5], paint);
        canvas.drawLine(lx2, ly[0], lx2, ly[5], paint);
        int dur_n = 0;
        boolean lining = false;
        int i2 = 0;
        while (i2 < this.chords.size()) {
            RChord curr = this.chords.get(i2);
            RChord prev = i2 > 0 ? this.chords.get(i2 - 1) : null;
            RChord next = i2 < this.chords.size() + (-1) ? this.chords.get(i2 + 1) : null;
            if (curr.keep) {
                curr.chord = prev.chord;
                curr.mod = prev.mod;
            }
            int lmax = Math.max((int) curr.chord[0], (int) curr.chord[curr.chord.length - 1]);
            int lmin = Math.min((int) curr.chord[0], (int) curr.chord[curr.chord.length - 1]);
            if (curr.keep) {
                canvas.drawArc(new RectF(dur_x - dur_len, ly[lmin - 1] - ((dur_len * 2) / 3), dur_x, ly[lmin - 1] + ((dur_len * 1) / 3)), 195.0f, 150.0f, false, paint);
            }
            for (int c = 0; c < curr.chord.length; c++) {
                if (curr.mod == 0) {
                    canvas.drawLine(dur_x - (lh / 2), ly[curr.chord[c] - 1] - (lh / 2), (lh / 2) + dur_x, ly[curr.chord[c] - 1] + (lh / 2), paint);
                    canvas.drawLine(dur_x - (lh / 2), ly[curr.chord[c] - 1] + (lh / 2), (lh / 2) + dur_x, ly[curr.chord[c] - 1] - (lh / 2), paint);
                } else if (curr.mod == 1 || curr.mod == 2) {
                    if (curr.mod == 2) {
                        PathEffect effects = new DashPathEffect(new float[]{4.0f, 4.0f}, 0.0f);
                        paint.setPathEffect(effects);
                        Path p = new Path();
                        p.moveTo(dur_x, ly[lmin - 1] - 1);
                        p.lineTo(dur_x, ly[lmax - 1] + 1);
                        canvas.drawPath(p, paint);
                        paint.setPathEffect(null);
                    } else {
                        canvas.drawLine(dur_x, ly[lmin - 1] - 1, dur_x, ly[lmax - 1] + 1, paint);
                    }
                    if (curr.chord[0] > curr.chord[curr.chord.length - 1]) {
                        canvas.drawLine(dur_x - (lh / 2), (ly[lmin - 1] - 1) + (lh / 2), dur_x, ly[lmin - 1] - 1, paint);
                        canvas.drawLine(dur_x, ly[lmin - 1] - 1, (lh / 2) + dur_x, (ly[lmin - 1] - 1) + (lh / 2), paint);
                    } else {
                        canvas.drawLine(dur_x - (lh / 2), (ly[lmax - 1] + 1) - (lh / 2), dur_x, ly[lmax - 1] + 1, paint);
                        canvas.drawLine(dur_x, ly[lmax - 1] + 1, (lh / 2) + dur_x, (ly[lmax - 1] + 1) - (lh / 2), paint);
                    }
                }
            }
            canvas.drawLine(dur_x, ly[lmax - 1] + ((lh * 2) / 3), dur_x, ly[5] + lh, paint);
            dur_n += curr.dur;
            if (curr.dur < beat_durs) {
                if (dur_n % beat_durs != 0) {
                    if (i2 < this.chords.size() - 1) {
                        if (next.dur <= beat_durs) {
                            canvas.drawLine(dur_x, ly[5] + lh, dur_x + dur_len, ly[5] + lh, paint);
                            if (curr.dur * 2 < beat_durs) {
                                if (curr.dur == next.dur) {
                                    canvas.drawLine(dur_x, (ly[5] + lh) - ((lh * 2) / 5), dur_x + dur_len, (ly[5] + lh) - ((lh * 2) / 5), paint);
                                } else if (curr.dur < next.dur) {
                                    canvas.drawLine(dur_x, (ly[5] + lh) - ((lh * 2) / 5), (dur_len / 3) + dur_x, (ly[5] + lh) - ((lh * 2) / 5), paint);
                                }
                            }
                            lining = true;
                        } else {
                            canvas.drawLine(dur_x, ly[5] + lh, (lh / 2) + dur_x, (ly[5] + lh) - (lh / 2), paint);
                            if (curr.dur * 2 < beat_durs) {
                                canvas.drawLine(dur_x, (ly[5] + lh) - ((lh * 2) / 5), (lh / 2) + dur_x, ((ly[5] + lh) - (lh / 2)) - ((lh * 2) / 5), paint);
                            }
                        }
                    }
                } else {
                    if (!lining) {
                        canvas.drawLine(dur_x, ly[5] + lh, (lh / 2) + dur_x, (ly[5] + lh) - (lh / 2), paint);
                        if (curr.dur * 2 < beat_durs) {
                            canvas.drawLine(dur_x, (ly[5] + lh) - ((lh * 2) / 5), (lh / 2) + dur_x, ((ly[5] + lh) - (lh / 2)) - ((lh * 2) / 5), paint);
                        }
                    } else if (curr.dur * 2 < beat_durs && curr.dur < prev.dur) {
                        canvas.drawLine(dur_x, (ly[5] + lh) - ((lh * 2) / 5), dur_x - (dur_len / 3), (ly[5] + lh) - ((lh * 2) / 5), paint);
                    }
                    lining = false;
                }
            }
            dur_x += dur_len;
            i2++;
        }
    }

    public Bitmap getBitmap(int w, int h) {
        Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Paint paint = new Paint();
        Canvas canvas = new Canvas(bitmap);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.argb(255, 144, 144, 144));
        int[] ly = {(h * 10) / 48, (h * 15) / 48, (h * 20) / 48, (h * 25) / 48, (h * 30) / 48, (h * 35) / 48};
        int lh = (h * 5) / 48;
        int lx1 = (w * 8) / 96;
        int lx2 = (w * 88) / 96;
        int dur_len = ((w * 80) / 96) / this.chords.size();
        int dur_x = lx1 + (dur_len / 2);
        int beat_durs = this.durs / this.beat;
        for (int i = 0; i < 6; i++) {
            canvas.drawLine(lx1, ly[i], lx2, ly[i], paint);
        }
        canvas.drawLine(lx1, ly[0], lx1, ly[5], paint);
        canvas.drawLine(lx2, ly[0], lx2, ly[5], paint);
        int dur_n = 0;
        boolean lining = false;
        int i2 = 0;
        while (i2 < this.chords.size()) {
            RChord curr = this.chords.get(i2);
            RChord prev = i2 > 0 ? this.chords.get(i2 - 1) : null;
            RChord next = i2 < this.chords.size() + (-1) ? this.chords.get(i2 + 1) : null;
            if (curr.keep) {
                curr.chord = prev.chord;
                curr.mod = prev.mod;
            }
            int lmax = Math.max((int) curr.chord[0], (int) curr.chord[curr.chord.length - 1]);
            int lmin = Math.min((int) curr.chord[0], (int) curr.chord[curr.chord.length - 1]);
            if (curr.keep) {
                canvas.drawArc(new RectF(dur_x - dur_len, ly[lmin - 1] - ((dur_len * 2) / 3), dur_x, ly[lmin - 1] + ((dur_len * 1) / 3)), 195.0f, 150.0f, false, paint);
            }
            for (int c = 0; c < curr.chord.length; c++) {
                if (curr.mod == 0) {
                    canvas.drawLine(dur_x - (lh / 2), ly[curr.chord[c] - 1] - (lh / 2), (lh / 2) + dur_x, ly[curr.chord[c] - 1] + (lh / 2), paint);
                    canvas.drawLine(dur_x - (lh / 2), ly[curr.chord[c] - 1] + (lh / 2), (lh / 2) + dur_x, ly[curr.chord[c] - 1] - (lh / 2), paint);
                } else if (curr.mod == 1 || curr.mod == 2) {
                    if (curr.mod == 2) {
                        PathEffect effects = new DashPathEffect(new float[]{2.0f, 3.0f}, 1.0f);
                        paint.setPathEffect(effects);
                    }
                    canvas.drawLine(dur_x, ly[lmin - 1] - 1, dur_x, ly[lmax - 1] + 1, paint);
                    if (curr.mod == 2) {
                        paint.setPathEffect(null);
                    }
                    if (curr.chord[0] > curr.chord[curr.chord.length - 1]) {
                        canvas.drawLine(dur_x - (lh / 2), (ly[lmin - 1] - 1) + (lh / 2), dur_x, ly[lmin - 1] - 1, paint);
                        canvas.drawLine(dur_x, ly[lmin - 1] - 1, (lh / 2) + dur_x, (ly[lmin - 1] - 1) + (lh / 2), paint);
                    } else {
                        canvas.drawLine(dur_x - (lh / 2), (ly[lmax - 1] + 1) - (lh / 2), dur_x, ly[lmax - 1] + 1, paint);
                        canvas.drawLine(dur_x, ly[lmax - 1] + 1, (lh / 2) + dur_x, (ly[lmax - 1] + 1) - (lh / 2), paint);
                    }
                }
            }
            canvas.drawLine(dur_x, ly[lmax - 1] + ((lh * 2) / 5), dur_x, ly[5] + lh, paint);
            dur_n += curr.dur;
            if (curr.dur < beat_durs) {
                if (dur_n % beat_durs != 0) {
                    if (i2 < this.chords.size() - 1) {
                        if (next.dur <= beat_durs) {
                            canvas.drawLine(dur_x, ly[5] + lh, dur_x + dur_len, ly[5] + lh, paint);
                            if (curr.dur * 2 < beat_durs) {
                                if (curr.dur == next.dur) {
                                    canvas.drawLine(dur_x, (ly[5] + lh) - ((lh * 2) / 5), dur_x + dur_len, (ly[5] + lh) - ((lh * 2) / 5), paint);
                                } else if (curr.dur < next.dur) {
                                    canvas.drawLine(dur_x, (ly[5] + lh) - ((lh * 2) / 5), (dur_len / 3) + dur_x, (ly[5] + lh) - ((lh * 2) / 5), paint);
                                }
                            }
                            lining = true;
                        } else {
                            canvas.drawLine(dur_x, ly[5] + lh, (lh / 2) + dur_x, (ly[5] + lh) - (lh / 2), paint);
                            if (curr.dur * 2 < beat_durs) {
                                canvas.drawLine(dur_x, (ly[5] + lh) - ((lh * 2) / 5), (lh / 2) + dur_x, ((ly[5] + lh) - (lh / 2)) - ((lh * 2) / 5), paint);
                            }
                        }
                    }
                } else {
                    if (!lining) {
                        canvas.drawLine(dur_x, ly[5] + lh, (lh / 2) + dur_x, (ly[5] + lh) - (lh / 2), paint);
                        if (curr.dur * 2 < beat_durs) {
                            canvas.drawLine(dur_x, (ly[5] + lh) - ((lh * 2) / 5), (lh / 2) + dur_x, ((ly[5] + lh) - (lh / 2)) - ((lh * 2) / 5), paint);
                        }
                    } else if (curr.dur * 2 < beat_durs && curr.dur < prev.dur) {
                        canvas.drawLine(dur_x, (ly[5] + lh) - ((lh * 2) / 5), dur_x - (dur_len / 3), (ly[5] + lh) - ((lh * 2) / 5), paint);
                    }
                    lining = false;
                }
            }
            dur_x += dur_len;
            i2++;
        }
        return bitmap;
    }

    private void initDefault() {
        this.id = 0;
        this.beat = (byte) 4;
        this.durs = (byte) 16;
        RChord c = new RChord((byte) 2, new byte[]{5});
        this.chords.add(c);
        RChord c2 = new RChord((byte) 1, new byte[]{3});
        this.chords.add(c2);
        RChord c3 = new RChord((byte) 1, new byte[]{2});
        this.chords.add(c3);
        RChord c4 = new RChord((byte) 1, new byte[0]);
        c4.keep = true;
        this.chords.add(c4);
        RChord c5 = new RChord((byte) 1, new byte[]{1});
        this.chords.add(c5);
        RChord c6 = new RChord((byte) 1, new byte[]{3});
        this.chords.add(c6);
        RChord c7 = new RChord((byte) 1, new byte[]{3, 2, 1});
        this.chords.add(c7);
        RChord c8 = new RChord((byte) 4, new byte[]{5, 4, 3, 2, 1});
        c8.mod = (byte) 2;
        this.chords.add(c8);
        RChord c9 = new RChord((byte) 2, new byte[]{6, 5, 4});
        c9.mod = (byte) 1;
        this.chords.add(c9);
        RChord c10 = new RChord((byte) 1, new byte[]{3, 2, 1});
        c10.mod = (byte) 1;
        this.chords.add(c10);
        RChord c11 = new RChord((byte) 1, new byte[]{1, 2, 3});
        c11.mod = (byte) 1;
        this.chords.add(c11);
    }

    public static Rhythm getDefault() {
        Rhythm rhythm = new Rhythm();
        rhythm.initDefault();
        return rhythm;
    }

    protected class RChord {
        protected byte[] chord;
        protected byte dur;
        protected boolean keep = false;
        protected byte mod = 0;

        protected RChord() {
        }

        protected RChord(byte d) {
            this.dur = d;
        }

        protected RChord(byte d, byte[] c) {
            this.dur = d;
            this.chord = c;
        }
    }
}
