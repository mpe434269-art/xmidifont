package net.duceng.xmidi.widgets;

/* JADX INFO: compiled from: MusicScore.java */
/* JADX INFO: loaded from: classes.dex */
class BoxedInt {
    public int value;

    BoxedInt() {
    }
}
