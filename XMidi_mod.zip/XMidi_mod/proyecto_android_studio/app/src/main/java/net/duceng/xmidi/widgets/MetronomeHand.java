package net.duceng.xmidi.widgets;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import net.duceng.midi.MetaTempo;
import net.duceng.xsynth.R;

/* JADX INFO: loaded from: classes.dex */
public class MetronomeHand extends View {
    private Bitmap block;
    private Rect blockRect;
    private float degree;
    private float degreeMax;
    private float lastY;
    private Matrix matrix;
    private Paint paint;
    private Bitmap ruler;
    private Rect rulerRect;
    private float scale;
    private int speed;
    private SpeedListener speedListener;
    private boolean toRight;
    private static int DEGREE_MIN = 5;
    private static int DEGREE_MAX = 27;
    private static int SPEED_MIN = 40;
    private static int SPEED_MAX = 208;
    private static float SPEED_MIN_Y = 0.08f;
    private static float SPEED_MAX_Y = 0.96f;

    public interface SpeedListener {
        void onSpeedChanged(int i);
    }

    public MetronomeHand(Context context) {
        super(context);
        this.scale = 1.0f;
        this.speed = MetaTempo.DEFAULT_BPM;
        this.degree = 0.0f;
        this.degreeMax = DEGREE_MAX - (((DEGREE_MAX - DEGREE_MIN) * (this.speed - SPEED_MIN)) / (SPEED_MAX - SPEED_MIN));
        this.toRight = true;
        this.lastY = 0.0f;
        init();
    }

    public MetronomeHand(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.scale = 1.0f;
        this.speed = MetaTempo.DEFAULT_BPM;
        this.degree = 0.0f;
        this.degreeMax = DEGREE_MAX - (((DEGREE_MAX - DEGREE_MIN) * (this.speed - SPEED_MIN)) / (SPEED_MAX - SPEED_MIN));
        this.toRight = true;
        this.lastY = 0.0f;
        init();
    }

    public MetronomeHand(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.scale = 1.0f;
        this.speed = MetaTempo.DEFAULT_BPM;
        this.degree = 0.0f;
        this.degreeMax = DEGREE_MAX - (((DEGREE_MAX - DEGREE_MIN) * (this.speed - SPEED_MIN)) / (SPEED_MAX - SPEED_MIN));
        this.toRight = true;
        this.lastY = 0.0f;
        init();
    }

    private void init() {
        Resources res = getResources();
        this.ruler = BitmapFactory.decodeResource(res, R.drawable.metronomer);
        this.block = BitmapFactory.decodeResource(res, R.drawable.metronomeb);
        this.matrix = new Matrix();
        this.paint = new Paint();
        this.paint.setAntiAlias(true);
        this.blockRect = new Rect();
        this.rulerRect = new Rect();
        setClickable(true);
    }

    public int getSpeed() {
        return this.speed;
    }

    public void setSpeed(int speed) {
        if (speed > SPEED_MAX) {
            this.speed = SPEED_MAX;
        } else if (speed < SPEED_MIN) {
            this.speed = SPEED_MIN;
        } else {
            this.speed = speed;
        }
        int newTop = (int) ((getHeight() * (SPEED_MAX_Y - SPEED_MIN_Y) * ((speed - SPEED_MIN) / (SPEED_MAX - SPEED_MIN))) + (getHeight() * SPEED_MIN_Y));
        this.blockRect.offsetTo(this.blockRect.left, newTop);
        invalidate();
        this.degreeMax = DEGREE_MAX - (((DEGREE_MAX - DEGREE_MIN) * (speed - SPEED_MIN)) / (SPEED_MAX - SPEED_MIN));
    }

    public float getDegree() {
        return this.degree;
    }

    public void setDegree(float degree) {
        if (Math.abs(degree) <= DEGREE_MAX) {
            this.degree = degree;
        } else {
            this.degree = degree > 0.0f ? DEGREE_MAX : DEGREE_MAX * (-1);
        }
    }

    public void setPercent(float percent) {
        if (percent > 1.0f) {
            percent = 1.0f;
        }
        if (this.toRight) {
            if (percent <= 0.5d) {
                this.degree = this.degreeMax * percent * 2.0f;
            } else if (this.degree > 0.0f) {
                this.toRight = false;
                this.degree = this.degreeMax * (1.0f - percent) * 2.0f;
            } else {
                this.degree = this.degreeMax * (1.0f - percent) * (-2.0f);
            }
        } else if (percent <= 0.5d) {
            this.degree = this.degreeMax * percent * (-2.0f);
        } else if (this.degree < 0.0f) {
            this.toRight = true;
            this.degree = this.degreeMax * (1.0f - percent) * (-2.0f);
        } else {
            this.degree = this.degreeMax * (1.0f - percent) * 2.0f;
        }
        invalidate();
    }

    @Override // android.view.View
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        this.scale = h / this.ruler.getHeight();
        this.rulerRect.top = 0;
        this.rulerRect.left = (int) ((getWidth() / 2) - ((this.scale * this.ruler.getWidth()) / 2.0f));
        this.blockRect.top = (int) ((h * (SPEED_MAX_Y - SPEED_MIN_Y) * ((this.speed - SPEED_MIN) / (SPEED_MAX - SPEED_MIN))) + (h * SPEED_MIN_Y));
        this.blockRect.left = (int) ((getWidth() / 2) - ((this.scale * this.block.getWidth()) / 2.0f));
        this.blockRect.right = this.blockRect.left + ((int) (this.scale * this.block.getWidth()));
        this.blockRect.bottom = this.blockRect.top + ((int) (this.scale * this.block.getHeight()));
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        canvas.rotate(this.degree, getWidth() / 2, (int) (((double) getHeight()) * 1.17d));
        this.matrix.reset();
        this.matrix.postScale(this.scale, this.scale);
        this.matrix.postTranslate(this.rulerRect.left, this.rulerRect.top);
        canvas.drawBitmap(this.ruler, this.matrix, this.paint);
        this.matrix.reset();
        this.matrix.postScale(this.scale, this.scale);
        this.matrix.postTranslate(this.blockRect.left, this.blockRect.top);
        canvas.drawBitmap(this.block, this.matrix, this.paint);
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        if (this.degree != 0.0f) {
            return super.onTouchEvent(event);
        }
        int action = event.getAction() & 255;
        if (action == 2) {
            if (this.lastY > 0.0f) {
                this.blockRect.offset(0, (int) (event.getY() - this.lastY));
                if (this.blockRect.top < getHeight() * SPEED_MIN_Y) {
                    this.blockRect.offsetTo(this.blockRect.left, (int) (getHeight() * SPEED_MIN_Y));
                } else if (this.blockRect.top > getHeight() * SPEED_MAX_Y) {
                    this.blockRect.offsetTo(this.blockRect.left, (int) (getHeight() * SPEED_MAX_Y));
                }
                invalidate();
                this.speed = ((int) (((SPEED_MAX - SPEED_MIN) * (this.blockRect.top - ((int) (getHeight() * SPEED_MIN_Y)))) / (getHeight() * (SPEED_MAX_Y - SPEED_MIN_Y)))) + SPEED_MIN;
                this.degreeMax = DEGREE_MAX - (((DEGREE_MAX - DEGREE_MIN) * (this.speed - SPEED_MIN)) / (SPEED_MAX - SPEED_MIN));
                if (this.speedListener != null) {
                    this.speedListener.onSpeedChanged(this.speed);
                }
                this.lastY = event.getY();
            }
        } else if (action == 0) {
            if (this.blockRect.contains((int) event.getX(), (int) event.getY())) {
                this.lastY = event.getY();
            }
        } else if (action == 3 || action == 1) {
            this.lastY = 0.0f;
        }
        return super.onTouchEvent(event);
    }

    public void setSpeedListener(SpeedListener speedListener) {
        this.speedListener = speedListener;
    }
}
