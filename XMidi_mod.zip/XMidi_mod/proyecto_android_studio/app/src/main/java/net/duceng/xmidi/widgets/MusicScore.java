package net.duceng.xmidi.widgets;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import java.util.ArrayList;
import java.util.TreeSet;
import net.duceng.midi.EventChannel;
import net.duceng.midi.MetaTimeSignature;
import net.duceng.midi.MidiEvent;
import net.duceng.midi.MidiFile;
import net.duceng.midi.MidiTrack;
import net.duceng.xmidi.widgets.score.AccidSymbol;
import net.duceng.xmidi.widgets.score.BarSymbol;
import net.duceng.xmidi.widgets.score.BlankSymbol;
import net.duceng.xmidi.widgets.score.ChordSymbol;
import net.duceng.xmidi.widgets.score.Clef;
import net.duceng.xmidi.widgets.score.ClefMeasures;
import net.duceng.xmidi.widgets.score.ClefSymbol;
import net.duceng.xmidi.widgets.score.LyricSymbol;
import net.duceng.xmidi.widgets.score.MidiKey;
import net.duceng.xmidi.widgets.score.MidiTime;
import net.duceng.xmidi.widgets.score.MusicSymbol;
import net.duceng.xmidi.widgets.score.Note;
import net.duceng.xmidi.widgets.score.NoteDuration;
import net.duceng.xmidi.widgets.score.NoteScale;
import net.duceng.xmidi.widgets.score.RestSymbol;
import net.duceng.xmidi.widgets.score.Staff;
import net.duceng.xmidi.widgets.score.SymbolWidths;
import net.duceng.xmidi.widgets.score.TimeSigSymbol;

/* JADX INFO: loaded from: classes.dex */
public class MusicScore extends SurfaceView implements SurfaceHolder.Callback {
    private static /* synthetic */ int[] $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration = null;
    public static final int DontScroll = 3;
    public static final int GradualScroll = 2;
    public static final int ImmediateScroll = 1;
    public static final int LineSpace = 7;
    public static final int LineWidth = 1;
    public static final int Margin = 4;
    public static final int NoteHeight = 8;
    public static final int NoteNameFixedDoReMi = 2;
    public static final int NoteNameFixedNumber = 4;
    public static final int NoteNameLetter = 1;
    public static final int NoteNameMovableDoReMi = 3;
    public static final int NoteNameMovableNumber = 5;
    public static final int NoteNameNone = 0;
    public static final int NoteWidth = 10;
    public static final int PageHeight = 1050;
    public static final int PageWidth = 800;
    public static final int StaffHeight = 33;
    public static final int TitleHeight = 14;
    private int[] NoteColors;
    private Bitmap bufferBitmap;
    private Canvas bufferCanvas;
    private int bufferX;
    private int bufferY;
    private int currentTicks;
    private GestureDetector gestureDetector;
    SurfaceHolder holder;
    private MidiKey mainkey;
    private MidiFile midiFile;
    private int numtracks;
    private GestureDetector.OnGestureListener onGestureListener;
    private Paint paint;
    private boolean scrollVert;
    private int scrollX;
    private int scrollY;
    private int shade1;
    private int shade2;
    private int sheetheight;
    private int sheetwidth;
    private boolean showMeasures;
    private int showNoteLetters;
    private boolean[] shows;
    private ArrayList<Staff> staffs;
    private boolean surfaceReady;
    private int viewheight;
    private int viewwidth;
    private float zoom;

    static /* synthetic */ int[] $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration() {
        int[] iArr = $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration;
        if (iArr == null) {
            iArr = new int[NoteDuration.valuesCustom().length];
            try {
                iArr[NoteDuration.DottedEighth.ordinal()] = 5;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[NoteDuration.DottedHalf.ordinal()] = 9;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[NoteDuration.DottedQuarter.ordinal()] = 7;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[NoteDuration.Eighth.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                iArr[NoteDuration.Half.ordinal()] = 8;
            } catch (NoSuchFieldError e5) {
            }
            try {
                iArr[NoteDuration.Quarter.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                iArr[NoteDuration.Sixteenth.ordinal()] = 2;
            } catch (NoSuchFieldError e7) {
            }
            try {
                iArr[NoteDuration.ThirtySecond.ordinal()] = 1;
            } catch (NoSuchFieldError e8) {
            }
            try {
                iArr[NoteDuration.Triplet.ordinal()] = 3;
            } catch (NoSuchFieldError e9) {
            }
            try {
                iArr[NoteDuration.Whole.ordinal()] = 10;
            } catch (NoSuchFieldError e10) {
            }
            $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration = iArr;
        }
        return iArr;
    }

    public MusicScore(Context context) {
        super(context);
        this.currentTicks = 0;
        this.onGestureListener = new GestureDetector.SimpleOnGestureListener() { // from class: net.duceng.xmidi.widgets.MusicScore.1
            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                MusicScore.this.scrollUpdate((int) distanceX, (int) distanceY);
                return true;
            }
        };
        init();
    }

    public MusicScore(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.currentTicks = 0;
        this.onGestureListener = new GestureDetector.SimpleOnGestureListener() { // from class: net.duceng.xmidi.widgets.MusicScore.1
            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                MusicScore.this.scrollUpdate((int) distanceX, (int) distanceY);
                return true;
            }
        };
        init();
    }

    public MusicScore(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.currentTicks = 0;
        this.onGestureListener = new GestureDetector.SimpleOnGestureListener() { // from class: net.duceng.xmidi.widgets.MusicScore.1
            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                MusicScore.this.scrollUpdate((int) distanceX, (int) distanceY);
                return true;
            }
        };
        init();
    }

    private void init() {
        ClefSymbol.LoadImages(getContext());
        TimeSigSymbol.LoadImages(getContext());
        this.holder = getHolder();
        this.holder.addCallback(this);
        this.holder.setFormat(4);
        this.scrollY = 0;
        this.scrollX = 0;
        this.bufferY = 0;
        this.bufferX = 0;
        this.gestureDetector = new GestureDetector(getContext(), this.onGestureListener);
        this.paint = new Paint();
        this.paint.setTextSize(12.0f);
        this.paint.setColor(-16777216);
        this.scrollVert = false;
        this.showNoteLetters = 1;
        this.numtracks = 1;
        this.zoom = 1.0f;
        setColors(null, Color.rgb(210, 210, 210), Color.rgb(150, 200, 220));
        this.midiFile = null;
        createStaffs();
    }

    private void createStaffs() {
        if (this.midiFile == null) {
            this.showNoteLetters = 0;
            this.numtracks = 2;
            this.staffs = new ArrayList<>();
            this.staffs.add(new Staff(Clef.Treble, 0, 2));
            this.staffs.add(new Staff(Clef.Bass, 1, 2));
            return;
        }
        int lastTick = 0;
        ArrayList<ArrayList<Note>> tracks = new ArrayList<>();
        ArrayList<Integer> tracksSum = new ArrayList<>();
        for (int k = 0; k < this.midiFile.getTracks().size(); k++) {
            MidiTrack t = this.midiFile.getTracks().get(k);
            if (this.shows[k]) {
                ArrayList<Note> notes = new ArrayList<>();
                int sum = 0;
                for (MidiEvent e : t.getEvents()) {
                    if (e instanceof EventChannel) {
                        EventChannel ec = (EventChannel) e;
                        if (ec.getType() == 9 && ec.getValue2() > 0) {
                            Note note = new Note(ec.getTick(), 0, ec.getChannel(), ec.getValue1());
                            notes.add(note);
                            sum += ec.getValue1();
                        } else if ((ec.getType() == 9 && ec.getValue2() == 0) || ec.getType() == 8) {
                            for (int i = notes.size() - 1; i >= 0; i--) {
                                Note n = notes.get(i);
                                if (n.getChannel() == ec.getChannel() && n.getKey() == ec.getValue1()) {
                                    if (n.getDuration() != 0) {
                                        break;
                                    }
                                    n.setDuration(ec.getTick() - n.getStartTick());
                                    break;
                                }
                            }
                        }
                    }
                }
                if (notes.size() > 0) {
                    tracks.add(notes);
                    tracksSum.add(Integer.valueOf(sum));
                }
                if (t.getLastTicks() > lastTick) {
                    lastTick = t.getLastTicks();
                }
            }
        }
        TreeSet<Note> notesTreble = new TreeSet<>();
        TreeSet<Note> notesBass = new TreeSet<>();
        if (tracks.size() == 2) {
            notesTreble.addAll(tracks.get(0));
            notesBass.addAll(tracks.get(1));
        } else {
            for (int i2 = 0; i2 < tracks.size(); i2++) {
                if (tracksSum.get(i2).intValue() / tracks.get(i2).size() > 60) {
                    notesTreble.addAll(tracks.get(i2));
                } else {
                    notesBass.addAll(tracks.get(i2));
                }
            }
        }
        tracks.clear();
        tracks.add(new ArrayList<>(notesTreble));
        tracks.add(new ArrayList<>(notesBass));
        MetaTimeSignature timeSignature = this.midiFile.getTimeSignature();
        this.mainkey = MidiKey.guess(tracks);
        MidiTime mainTime = new MidiTime(timeSignature.getNumerator(), (int) Math.pow(2.0d, timeSignature.getDenominator()), this.midiFile.getResolution(), this.midiFile.getTempo().getMpqn());
        ArrayList<ArrayList<MusicSymbol>> allsymbols = new ArrayList<>(2);
        int i3 = 0;
        while (i3 < 2) {
            ClefMeasures clefs = new ClefMeasures(tracks.get(i3), mainTime.getMeasure(), i3 == 0 ? Clef.Treble : Clef.Bass);
            ArrayList<ChordSymbol> chords = createChords(tracks.get(i3), this.mainkey, mainTime, clefs);
            allsymbols.add(createSymbols(chords, clefs, mainTime, lastTick));
            i3++;
        }
        SymbolWidths widths = new SymbolWidths(allsymbols, null);
        alignSymbols(allsymbols, widths);
        this.staffs = CreateStaffs(allsymbols, this.mainkey, mainTime, mainTime.getMeasure());
        CreateAllBeamedChords(allsymbols, mainTime);
        for (Staff staff : this.staffs) {
            staff.CalculateHeight();
        }
        System.gc();
    }

    private void calculateSize() {
        this.sheetwidth = this.viewwidth;
        this.sheetheight = this.viewheight;
        if (this.staffs != null) {
            this.sheetwidth = 0;
            this.sheetheight = 0;
            for (Staff staff : this.staffs) {
                this.sheetwidth = Math.max(this.sheetwidth, staff.getWidth());
                this.sheetheight += staff.getHeight();
            }
        }
        if (this.scrollVert) {
            this.zoom = this.viewwidth / 800.0f;
        } else {
            this.zoom = this.viewheight / this.sheetheight;
        }
    }

    @Override // android.view.View
    protected void onSizeChanged(int newwidth, int newheight, int oldwidth, int oldheight) {
        this.viewwidth = newwidth;
        this.viewheight = newheight;
        calculateSize();
        createBufferCanvas();
    }

    private ArrayList<ChordSymbol> createChords(ArrayList<Note> midinotes, MidiKey key, MidiTime time, ClefMeasures clefs) {
        int i = 0;
        ArrayList<ChordSymbol> chords = new ArrayList<>();
        TreeSet<Note> groupset = new TreeSet<>();
        ArrayList<Note> notegroup = new ArrayList<>(12);
        int len = midinotes.size();
        while (i < len) {
            int startTick = midinotes.get(i).getStartTick();
            Clef clef = clefs.getClef(startTick);
            groupset.clear();
            groupset.add(midinotes.get(i));
            i++;
            while (i < len && midinotes.get(i).getStartTick() == startTick) {
                groupset.add(midinotes.get(i));
                i++;
            }
            notegroup.clear();
            notegroup.addAll(groupset);
            ChordSymbol chord = new ChordSymbol(notegroup, key, time, clef, this);
            chords.add(chord);
        }
        return chords;
    }

    private ArrayList<MusicSymbol> createSymbols(ArrayList<ChordSymbol> chords, ClefMeasures clefs, MidiTime time, int lastStart) {
        new ArrayList();
        ArrayList<MusicSymbol> symbols = addBars(chords, time, lastStart);
        return addClefChanges(addRests(symbols, time), clefs, time);
    }

    private ArrayList<MusicSymbol> addBars(ArrayList<ChordSymbol> chords, MidiTime time, int lastStart) {
        ArrayList<MusicSymbol> symbols = new ArrayList<>();
        TimeSigSymbol timesig = new TimeSigSymbol(time.getNumerator(), time.getDenominator());
        symbols.add(timesig);
        int measuretime = 0;
        int i = 0;
        while (i < chords.size()) {
            if (measuretime <= chords.get(i).getStartTime()) {
                symbols.add(new BarSymbol(measuretime));
                measuretime += time.getMeasure();
            } else {
                symbols.add(chords.get(i));
                i++;
            }
        }
        while (measuretime < lastStart) {
            symbols.add(new BarSymbol(measuretime));
            measuretime += time.getMeasure();
        }
        symbols.add(new BarSymbol(measuretime));
        return symbols;
    }

    private ArrayList<MusicSymbol> addRests(ArrayList<MusicSymbol> symbols, MidiTime time) {
        int prevtime = 0;
        ArrayList<MusicSymbol> result = new ArrayList<>(symbols.size());
        for (MusicSymbol symbol : symbols) {
            int starttime = symbol.getStartTime();
            RestSymbol[] rests = GetRests(time, prevtime, starttime);
            if (rests != null) {
                for (RestSymbol r : rests) {
                    result.add(r);
                }
            }
            result.add(symbol);
            if (symbol instanceof ChordSymbol) {
                ChordSymbol chord = (ChordSymbol) symbol;
                prevtime = Math.max(chord.getEndTime(), prevtime);
            } else {
                prevtime = Math.max(starttime, prevtime);
            }
        }
        return result;
    }

    private RestSymbol[] GetRests(MidiTime time, int start, int end) {
        if (end - start < 0) {
            return null;
        }
        NoteDuration dur = time.GetNoteDuration(end - start);
        switch ($SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration()[dur.ordinal()]) {
            case 4:
            case 6:
            case 8:
            case 10:
                RestSymbol r1 = new RestSymbol(start, dur);
                return new RestSymbol[]{r1};
            case 5:
                RestSymbol r2 = new RestSymbol(start, NoteDuration.Eighth);
                RestSymbol r3 = new RestSymbol((time.getResolution() / 2) + start, NoteDuration.Sixteenth);
                return new RestSymbol[]{r2, r3};
            case 7:
                RestSymbol r4 = new RestSymbol(start, NoteDuration.Quarter);
                RestSymbol r5 = new RestSymbol(time.getResolution() + start, NoteDuration.Eighth);
                return new RestSymbol[]{r4, r5};
            case 9:
                RestSymbol r6 = new RestSymbol(start, NoteDuration.Half);
                RestSymbol r7 = new RestSymbol((time.getResolution() * 2) + start, NoteDuration.Quarter);
                return new RestSymbol[]{r6, r7};
            default:
                return null;
        }
    }

    private ArrayList<MusicSymbol> addClefChanges(ArrayList<MusicSymbol> symbols, ClefMeasures clefs, MidiTime time) {
        ArrayList<MusicSymbol> result = new ArrayList<>(symbols.size());
        Clef prevclef = clefs.getClef(0);
        for (MusicSymbol symbol : symbols) {
            if (symbol instanceof BarSymbol) {
                Clef clef = clefs.getClef(symbol.getStartTime());
                if (clef != prevclef) {
                    result.add(new ClefSymbol(clef, symbol.getStartTime() - 1, true));
                }
                prevclef = clef;
            }
            result.add(symbol);
        }
        return result;
    }

    private void alignSymbols(ArrayList<ArrayList<MusicSymbol>> allsymbols, SymbolWidths widths) {
        if (this.showMeasures) {
            for (int track = 0; track < allsymbols.size(); track++) {
                for (MusicSymbol sym : allsymbols.get(track)) {
                    if (sym instanceof BarSymbol) {
                        sym.setWidth(sym.getWidth() + 10);
                    }
                }
            }
        }
        for (int track2 = 0; track2 < allsymbols.size(); track2++) {
            ArrayList<MusicSymbol> symbols = allsymbols.get(track2);
            ArrayList<MusicSymbol> result = new ArrayList<>();
            int i = 0;
            for (int start : widths.getStartTimes()) {
                while (i < symbols.size() && (symbols.get(i) instanceof BarSymbol) && symbols.get(i).getStartTime() <= start) {
                    result.add(symbols.get(i));
                    i++;
                }
                if (i < symbols.size() && symbols.get(i).getStartTime() == start) {
                    while (i < symbols.size() && symbols.get(i).getStartTime() == start) {
                        result.add(symbols.get(i));
                        i++;
                    }
                } else {
                    result.add(new BlankSymbol(start, 0));
                }
            }
            int i2 = 0;
            while (i2 < result.size()) {
                if (result.get(i2) instanceof BarSymbol) {
                    i2++;
                } else {
                    int start2 = result.get(i2).getStartTime();
                    int extra = widths.GetExtraWidth(track2, start2);
                    int newwidth = result.get(i2).getWidth() + extra;
                    result.get(i2).setWidth(newwidth);
                    while (i2 < result.size() && result.get(i2).getStartTime() == start2) {
                        i2++;
                    }
                }
            }
            allsymbols.set(track2, result);
        }
    }

    private static boolean FindConsecutiveChords(ArrayList<MusicSymbol> symbols, MidiTime time, int startIndex, int[] chordIndexes, BoxedInt horizDistance) {
        boolean foundChords;
        int i = startIndex;
        int numChords = chordIndexes.length;
        do {
            horizDistance.value = 0;
            while (i < symbols.size() - numChords) {
                if (symbols.get(i) instanceof ChordSymbol) {
                    ChordSymbol c = (ChordSymbol) symbols.get(i);
                    if (c.getStem() != null) {
                        break;
                    }
                }
                i++;
            }
            if (i >= symbols.size() - numChords) {
                chordIndexes[0] = -1;
                return false;
            }
            chordIndexes[0] = i;
            foundChords = true;
            for (int chordIndex = 1; chordIndex < numChords; chordIndex++) {
                i++;
                int remaining = (numChords - 1) - chordIndex;
                while (i < symbols.size() - remaining && (symbols.get(i) instanceof BlankSymbol)) {
                    horizDistance.value = symbols.get(i).getWidth() + horizDistance.value;
                    i++;
                }
                if (i >= symbols.size() - remaining) {
                    return false;
                }
                if (!(symbols.get(i) instanceof ChordSymbol)) {
                    foundChords = false;
                    break;
                }
                chordIndexes[chordIndex] = i;
                horizDistance.value = symbols.get(i).getWidth() + horizDistance.value;
            }
        } while (!foundChords);
        return true;
    }

    private static void CreateBeamedChords(ArrayList<ArrayList<MusicSymbol>> allsymbols, MidiTime time, int numChords, boolean startBeat) {
        int[] chordIndexes = new int[numChords];
        ChordSymbol[] chords = new ChordSymbol[numChords];
        for (ArrayList<MusicSymbol> symbols : allsymbols) {
            int startIndex = 0;
            while (true) {
                BoxedInt horizDistance = new BoxedInt();
                horizDistance.value = 0;
                boolean found = FindConsecutiveChords(symbols, time, startIndex, chordIndexes, horizDistance);
                if (found) {
                    for (int i = 0; i < numChords; i++) {
                        chords[i] = (ChordSymbol) symbols.get(chordIndexes[i]);
                    }
                    if (ChordSymbol.CanCreateBeam(chords, time, startBeat)) {
                        ChordSymbol.CreateBeam(chords, horizDistance.value);
                        startIndex = chordIndexes[numChords - 1] + 1;
                    } else {
                        startIndex = chordIndexes[0] + 1;
                    }
                }
            }
        }
    }

    private static void CreateAllBeamedChords(ArrayList<ArrayList<MusicSymbol>> allsymbols, MidiTime time) {
        if ((time.getNumerator() == 3 && time.getDenominator() == 4) || ((time.getNumerator() == 6 && time.getDenominator() == 8) || (time.getNumerator() == 6 && time.getDenominator() == 4))) {
            CreateBeamedChords(allsymbols, time, 6, true);
        }
        CreateBeamedChords(allsymbols, time, 3, true);
        CreateBeamedChords(allsymbols, time, 4, true);
        CreateBeamedChords(allsymbols, time, 2, true);
        CreateBeamedChords(allsymbols, time, 2, false);
    }

    public static int KeySignatureWidth(MidiKey key) {
        ClefSymbol clefsym = new ClefSymbol(Clef.Treble, 0, false);
        int result = clefsym.getMinWidth();
        AccidSymbol[] keys = key.GetSymbols(Clef.Treble);
        for (AccidSymbol symbol : keys) {
            result += symbol.getMinWidth();
        }
        return result + 4 + 5;
    }

    private ArrayList<Staff> CreateStaffsForTrack(ArrayList<MusicSymbol> symbols, int measurelen, MidiKey key, MidiTime time, int track, int totaltracks) {
        int maxwidth;
        int endindex;
        int keysigWidth = KeySignatureWidth(key);
        ArrayList<Staff> thestaffs = new ArrayList<>(symbols.size() / 50);
        for (int startindex = 0; startindex < symbols.size(); startindex = endindex + 1) {
            int endindex2 = startindex;
            int width = keysigWidth;
            if (this.scrollVert) {
                maxwidth = PageWidth;
            } else {
                maxwidth = 2000000;
            }
            while (endindex2 < symbols.size() && symbols.get(endindex2).getWidth() + width < maxwidth) {
                width += symbols.get(endindex2).getWidth();
                endindex2++;
            }
            endindex = endindex2 - 1;
            if (endindex != symbols.size() - 1 && symbols.get(startindex).getStartTime() / measurelen != symbols.get(endindex).getStartTime() / measurelen) {
                int endmeasure = symbols.get(endindex + 1).getStartTime() / measurelen;
                while (symbols.get(endindex).getStartTime() / measurelen == endmeasure) {
                    endindex--;
                }
            }
            if (this.scrollVert) {
            }
            ArrayList<MusicSymbol> staffSymbols = new ArrayList<>();
            for (int i = startindex; i <= endindex; i++) {
                staffSymbols.add(symbols.get(i));
            }
            Staff staff = new Staff(staffSymbols, key, time, this.showMeasures, this.scrollVert, track, totaltracks);
            thestaffs.add(staff);
        }
        return thestaffs;
    }

    private ArrayList<Staff> CreateStaffs(ArrayList<ArrayList<MusicSymbol>> allsymbols, MidiKey key, MidiTime time, int measurelen) {
        ArrayList<ArrayList<Staff>> trackstaffs = new ArrayList<>(allsymbols.size());
        int totaltracks = allsymbols.size();
        for (int track = 0; track < totaltracks; track++) {
            ArrayList<MusicSymbol> symbols = allsymbols.get(track);
            trackstaffs.add(CreateStaffsForTrack(symbols, measurelen, key, time, track, totaltracks));
        }
        for (ArrayList<Staff> list : trackstaffs) {
            for (int i = 0; i < list.size() - 1; i++) {
                list.get(i).setEndTime(list.get(i + 1).getStartTime());
            }
        }
        int maxstaffs = 0;
        for (int i2 = 0; i2 < trackstaffs.size(); i2++) {
            if (maxstaffs < trackstaffs.get(i2).size()) {
                maxstaffs = trackstaffs.get(i2).size();
            }
        }
        ArrayList<Staff> result = new ArrayList<>(trackstaffs.size() * maxstaffs);
        for (int i3 = 0; i3 < maxstaffs; i3++) {
            for (ArrayList<Staff> list2 : trackstaffs) {
                if (i3 < list2.size()) {
                    result.add(list2.get(i3));
                }
            }
        }
        return result;
    }

    public void setColors(int[] newcolors, int newshade1, int newshade2) {
        if (this.NoteColors == null) {
            this.NoteColors = new int[12];
            for (int i = 0; i < 12; i++) {
                this.NoteColors[i] = -16777216;
            }
        }
        if (newcolors != null) {
            for (int i2 = 0; i2 < 12; i2++) {
                this.NoteColors[i2] = newcolors[i2];
            }
        }
        this.shade1 = newshade1;
        this.shade2 = newshade2;
    }

    public int NoteColor(int number) {
        return this.NoteColors[NoteScale.FromNumber(number)];
    }

    public int getShade1() {
        return this.shade1;
    }

    public int getShade2() {
        return this.shade2;
    }

    public int getShowNoteLetters() {
        return this.showNoteLetters;
    }

    public MidiKey getMainKey() {
        return this.mainkey;
    }

    static void AddLyricsToStaffs(ArrayList<Staff> staffs, ArrayList<ArrayList<LyricSymbol>> tracklyrics) {
        for (Staff staff : staffs) {
            ArrayList<LyricSymbol> lyrics = tracklyrics.get(staff.getTrack());
            staff.addLyrics(lyrics);
        }
    }

    void createBufferCanvas() {
        if (this.bufferBitmap != null) {
            this.bufferCanvas = null;
            this.bufferBitmap.recycle();
            this.bufferBitmap = null;
            System.gc();
        }
        if (this.scrollVert) {
            this.bufferBitmap = Bitmap.createBitmap(this.viewwidth, (int) (this.viewheight * 1.2f), Bitmap.Config.RGB_565);
        } else {
            this.bufferBitmap = Bitmap.createBitmap((int) (this.viewwidth * 1.5f), this.viewheight, Bitmap.Config.RGB_565);
        }
        this.bufferCanvas = new Canvas(this.bufferBitmap);
        drawToBuffer(this.scrollX, this.scrollY);
    }

    public void draw() {
        Canvas canvas;
        if (this.surfaceReady && (canvas = this.holder.lockCanvas()) != null) {
            draw(canvas);
            this.holder.unlockCanvasAndPost(canvas);
            if (this.currentTicks > 0) {
                shadeNotes(this.currentTicks, 0, 0);
            }
        }
    }

    @Override // android.view.SurfaceView, android.view.View
    public void draw(Canvas canvas) {
        if (this.bufferBitmap == null) {
            createBufferCanvas();
        }
        if (!isScrollPositionInBuffer()) {
            drawToBuffer(this.scrollX, this.scrollY);
        }
        canvas.translate(-(this.scrollX - this.bufferX), -(this.scrollY - this.bufferY));
        canvas.drawBitmap(this.bufferBitmap, 0.0f, 0.0f, this.paint);
        canvas.translate(this.scrollX - this.bufferX, this.scrollY - this.bufferY);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        draw(canvas);
    }

    private boolean isScrollPositionInBuffer() {
        return this.scrollY >= this.bufferY && this.scrollX >= this.bufferX && this.scrollY <= (this.bufferY + this.bufferBitmap.getHeight()) - this.viewheight && this.scrollX <= (this.bufferX + this.bufferBitmap.getWidth()) - this.viewwidth;
    }

    private void drawToBuffer(int left, int top) {
        this.bufferX = left;
        this.bufferY = top;
        this.bufferCanvas.translate(-this.bufferX, -this.bufferY);
        Rect clip = new Rect(this.bufferX, this.bufferY, this.bufferX + this.bufferBitmap.getWidth(), this.bufferY + this.bufferBitmap.getHeight());
        clip.left = (int) (clip.left / this.zoom);
        clip.top = (int) (clip.top / this.zoom);
        clip.right = (int) (clip.right / this.zoom);
        clip.bottom = (int) (clip.bottom / this.zoom);
        this.bufferCanvas.scale(this.zoom, this.zoom);
        this.paint.setAntiAlias(true);
        this.paint.setStyle(Paint.Style.FILL);
        this.paint.setColor(-1);
        this.bufferCanvas.drawRect(clip.left, clip.top, clip.right, clip.bottom, this.paint);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setColor(-16777216);
        if (this.staffs != null) {
            int ypos = 0;
            for (Staff staff : this.staffs) {
                if (staff.getHeight() + ypos >= clip.top && ypos <= clip.bottom) {
                    this.bufferCanvas.translate(0.0f, ypos);
                    staff.draw(this.bufferCanvas, clip, this.paint);
                    this.bufferCanvas.translate(0.0f, -ypos);
                }
                ypos += staff.getHeight();
            }
        }
        this.bufferCanvas.scale(1.0f / this.zoom, 1.0f / this.zoom);
        this.bufferCanvas.translate(this.bufferX, this.bufferY);
    }

    private void DrawTitle(Canvas canvas) {
        String title = "Title...".replace(".mid", "").replace("_", " ");
        canvas.translate(20, 20);
        canvas.drawText(title, 0.0f, 0.0f, this.paint);
        canvas.translate(-20, -20);
    }

    public int GetTotalPages() {
        int num = 1;
        int currheight = 14;
        if (this.numtracks == 2 && this.staffs.size() % 2 == 0) {
            for (int i = 0; i < this.staffs.size(); i += 2) {
                int heights = this.staffs.get(i).getHeight() + this.staffs.get(i + 1).getHeight();
                if (currheight + heights > 1050) {
                    num++;
                    currheight = heights;
                } else {
                    currheight += heights;
                }
            }
        } else {
            for (Staff staff : this.staffs) {
                if (staff.getHeight() + currheight > 1050) {
                    num++;
                    currheight = staff.getHeight();
                } else {
                    currheight += staff.getHeight();
                }
            }
        }
        return num;
    }

    public void DrawPage(Canvas canvas, int pagenumber) {
        int ypos;
        int ypos2;
        Rect clip = new Rect(0, 0, 840, 1090);
        this.paint.setAntiAlias(true);
        this.paint.setStyle(Paint.Style.FILL);
        this.paint.setColor(-1);
        canvas.drawRect(clip.left, clip.top, clip.right, clip.bottom, this.paint);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setColor(-16777216);
        int ypos3 = 14;
        int pagenum = 1;
        int staffnum = 0;
        if (this.numtracks == 2 && this.staffs.size() % 2 == 0) {
            while (staffnum + 1 < this.staffs.size() && pagenum < pagenumber) {
                int heights = this.staffs.get(staffnum).getHeight() + this.staffs.get(staffnum + 1).getHeight();
                if (ypos3 + heights >= 1050) {
                    pagenum++;
                    ypos3 = 0;
                } else {
                    ypos3 += heights;
                    staffnum += 2;
                }
            }
            if (pagenum == 1) {
                DrawTitle(canvas);
                ypos2 = 14;
            } else {
                ypos2 = 0;
            }
            while (staffnum + 1 < this.staffs.size() && ypos2 + this.staffs.get(staffnum).getHeight() + this.staffs.get(staffnum + 1).getHeight() < 1050) {
                canvas.translate(20, 20 + ypos2);
                this.staffs.get(staffnum).draw(canvas, clip, this.paint);
                canvas.translate(-20, -(20 + ypos2));
                int ypos4 = ypos2 + this.staffs.get(staffnum).getHeight();
                canvas.translate(20, 20 + ypos4);
                this.staffs.get(staffnum + 1).draw(canvas, clip, this.paint);
                canvas.translate(-20, -(20 + ypos4));
                ypos2 = ypos4 + this.staffs.get(staffnum + 1).getHeight();
                staffnum += 2;
            }
        } else {
            while (staffnum < this.staffs.size() && pagenum < pagenumber) {
                if (this.staffs.get(staffnum).getHeight() + ypos3 >= 1050) {
                    pagenum++;
                    ypos3 = 0;
                } else {
                    ypos3 += this.staffs.get(staffnum).getHeight();
                    staffnum++;
                }
            }
            if (pagenum == 1) {
                DrawTitle(canvas);
                ypos = 14;
            } else {
                ypos = 0;
            }
            while (staffnum < this.staffs.size() && this.staffs.get(staffnum).getHeight() + ypos < 1050) {
                canvas.translate(20, 20 + ypos);
                this.staffs.get(staffnum).draw(canvas, clip, this.paint);
                canvas.translate(-20, -(20 + ypos));
                ypos += this.staffs.get(staffnum).getHeight();
                staffnum++;
            }
        }
        canvas.drawText(new StringBuilder().append(pagenumber).toString(), 780, 1058, this.paint);
    }

    public void shadeNotes(int currentPulseTime, int prevPulseTime, int scrollType) {
        this.currentTicks = currentPulseTime;
        if ((this.surfaceReady || isInEditMode()) && this.staffs != null) {
            if (this.bufferCanvas == null) {
                createBufferCanvas();
            }
            if (!isScrollPositionInBuffer()) {
                drawToBuffer(this.scrollX, this.scrollY);
            }
            this.bufferCanvas.translate(-this.bufferX, -this.bufferY);
            int x_shade = 0;
            int y_shade = 0;
            this.paint.setAntiAlias(true);
            this.bufferCanvas.scale(this.zoom, this.zoom);
            int ypos = 0;
            for (Staff staff : this.staffs) {
                this.bufferCanvas.translate(0.0f, ypos);
                x_shade = staff.shadeNotes(this.bufferCanvas, this.paint, this.shade1, currentPulseTime, prevPulseTime, x_shade);
                this.bufferCanvas.translate(0.0f, -ypos);
                ypos += staff.getHeight();
                if (currentPulseTime >= staff.getEndTime()) {
                    y_shade += staff.getHeight();
                }
            }
            this.bufferCanvas.scale(1.0f / this.zoom, 1.0f / this.zoom);
            this.bufferCanvas.translate(this.bufferX, this.bufferY);
            if (currentPulseTime >= 0) {
                int x_shade2 = (int) (x_shade * this.zoom);
                int y_shade2 = (int) ((y_shade - 8) * this.zoom);
                if (scrollType == 1) {
                    scrollToShadedNotes(x_shade2, y_shade2, false);
                } else if (scrollType == 2) {
                    scrollToShadedNotes(x_shade2, y_shade2, true);
                }
            }
            if (this.scrollX < this.bufferX || this.scrollY < this.bufferY) {
                shadeNotes(currentPulseTime, prevPulseTime, scrollType);
                return;
            }
            SurfaceHolder holder = getHolder();
            Canvas canvas = holder.lockCanvas();
            if (canvas != null) {
                canvas.translate(-(this.scrollX - this.bufferX), -(this.scrollY - this.bufferY));
                canvas.drawBitmap(this.bufferBitmap, 0.0f, 0.0f, this.paint);
                canvas.translate(this.scrollX - this.bufferX, this.scrollY - this.bufferY);
                holder.unlockCanvasAndPost(canvas);
            }
        }
    }

    void scrollToShadedNotes(int x_shade, int y_shade, boolean scrollGradually) {
        if (this.scrollVert) {
            int scrollDist = y_shade - this.scrollY;
            if (scrollGradually) {
                if (scrollDist > this.zoom * 33.0f * 8.0f) {
                    scrollDist /= 2;
                } else if (scrollDist > this.zoom * 32.0f) {
                    scrollDist = (int) (this.zoom * 32.0f);
                }
            }
            this.scrollY += scrollDist;
        } else {
            int x_view = this.scrollX + ((this.viewwidth * 40) / 100);
            int xmax = this.scrollX + ((this.viewwidth * 65) / 100);
            int scrollDist2 = x_shade - x_view;
            if (scrollGradually) {
                if (x_shade > xmax) {
                    scrollDist2 = (x_shade - x_view) / 3;
                } else if (x_shade > x_view) {
                    scrollDist2 = (x_shade - x_view) / 6;
                }
            }
            this.scrollX += scrollDist2;
        }
        checkScrollBounds();
    }

    public int PulseTimeForPoint(Point point) {
        Point scaledPoint = new Point((int) (point.x / this.zoom), (int) (point.y / this.zoom));
        int y = 0;
        for (Staff staff : this.staffs) {
            if (scaledPoint.y >= y && scaledPoint.y <= staff.getHeight() + y) {
                return staff.PulseTimeForPoint(scaledPoint);
            }
            y += staff.getHeight();
        }
        return -1;
    }

    private void checkScrollBounds() {
        int scrollwidth = (int) (this.sheetwidth * this.zoom);
        int scrollheight = (int) (this.sheetheight * this.zoom);
        if (this.scrollX > scrollwidth - this.viewwidth) {
            this.scrollX = scrollwidth - this.viewwidth;
        }
        if (this.scrollY > scrollheight - this.viewheight) {
            this.scrollY = scrollheight - this.viewheight;
        }
        if (this.scrollX < 0) {
            this.scrollX = 0;
        }
        if (this.scrollY < 0) {
            this.scrollY = 0;
        }
    }

    public void setMidiFile(MidiFile file, boolean[] s) {
        this.midiFile = file;
        this.shows = s;
        createStaffs();
        this.scrollY = 0;
        this.scrollX = 0;
        calculateSize();
        Canvas canvas = this.holder.lockCanvas();
        if (canvas != null) {
            drawToBuffer(this.scrollX, this.scrollY);
            draw(canvas);
            this.holder.unlockCanvasAndPost(canvas);
        }
    }

    public boolean getScrollVert() {
        return this.scrollVert;
    }

    public void setScrollVert(boolean value) {
        if (this.scrollVert != value) {
            this.scrollVert = value;
            this.scrollX = 0;
            this.scrollY = 0;
            if (this.bufferCanvas != null) {
                createStaffs();
                drawToBuffer(this.scrollX, this.scrollY);
                draw();
            }
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        this.gestureDetector.onTouchEvent(event);
        return true;
    }

    public void scrollUpdate(int deltaX, int deltaY) {
        this.scrollX += deltaX;
        this.scrollY += deltaY;
        checkScrollBounds();
        draw();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        draw();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceCreated(SurfaceHolder holder) {
        this.surfaceReady = true;
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceDestroyed(SurfaceHolder holder) {
        this.surfaceReady = false;
    }

    @Override // android.view.View
    public String toString() {
        String result = "SheetMusic staffs=" + this.staffs.size() + "\n";
        for (Staff staff : this.staffs) {
            result = String.valueOf(result) + staff.toString();
        }
        return String.valueOf(result) + "End SheetMusic\n";
    }
}
