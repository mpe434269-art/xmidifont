package net.duceng.xmidi.widgets.score;

/* JADX INFO: loaded from: classes.dex */
public enum Accid {
    None,
    Sharp,
    Flat,
    Natural;

    /* JADX INFO: renamed from: values, reason: to resolve conflict with enum method */
    public static Accid[] valuesCustom() {
        Accid[] accidArrValuesCustom = values();
        int length = accidArrValuesCustom.length;
        Accid[] accidArr = new Accid[length];
        System.arraycopy(accidArrValuesCustom, 0, accidArr, 0, length);
        return accidArr;
    }
}
