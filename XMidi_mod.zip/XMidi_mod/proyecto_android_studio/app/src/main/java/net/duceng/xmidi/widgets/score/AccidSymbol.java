package net.duceng.xmidi.widgets.score;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

/* JADX INFO: loaded from: classes.dex */
public class AccidSymbol implements MusicSymbol {
    private Accid accid;
    private Clef clef;
    private WhiteNote whitenote;
    private int width = getMinWidth();

    public AccidSymbol(Accid accid, WhiteNote note, Clef clef) {
        this.accid = accid;
        this.whitenote = note;
        this.clef = clef;
    }

    public WhiteNote getNote() {
        return this.whitenote;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getStartTime() {
        return -1;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getMinWidth() {
        return 12;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getWidth() {
        return this.width;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void setWidth(int value) {
        this.width = value;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getAboveStaff() {
        int dist = (WhiteNote.Top(this.clef).Dist(this.whitenote) * 8) / 2;
        if (this.accid == Accid.Sharp || this.accid == Accid.Natural) {
            dist -= 8;
        } else if (this.accid == Accid.Flat) {
            dist -= 12;
        }
        if (dist < 0) {
            return -dist;
        }
        return 0;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getBelowStaff() {
        int dist = ((WhiteNote.Bottom(this.clef).Dist(this.whitenote) * 8) / 2) + 8;
        if (this.accid == Accid.Sharp || this.accid == Accid.Natural) {
            dist += 8;
        }
        if (dist > 0) {
            return dist;
        }
        return 0;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void draw(Canvas canvas, Paint paint, int ytop) {
        canvas.translate(getWidth() - getMinWidth(), 0.0f);
        int ynote = ytop + ((WhiteNote.Top(this.clef).Dist(this.whitenote) * 8) / 2);
        if (this.accid == Accid.Sharp) {
            drawSharp(canvas, paint, ynote);
        } else if (this.accid == Accid.Flat) {
            drawFlat(canvas, paint, ynote);
        } else if (this.accid == Accid.Natural) {
            drawNatural(canvas, paint, ynote);
        }
        canvas.translate(-(getWidth() - getMinWidth()), 0.0f);
    }

    public void drawSharp(Canvas canvas, Paint paint, int ynote) {
        int ystart = ynote - 8;
        int yend = ynote + 16;
        paint.setStrokeWidth(1.0f);
        canvas.drawLine(4, ystart + 2, 4, yend, paint);
        int x = 4 + 4;
        canvas.drawLine(x, ystart, x, yend - 2, paint);
        int ystart2 = ynote + 1;
        int yend2 = (ystart2 - 1) - 1;
        paint.setStrokeWidth(3.0f);
        canvas.drawLine(2, ystart2, 10, yend2, paint);
        canvas.drawLine(2, ystart2 + 7, 10, yend2 + 7, paint);
        paint.setStrokeWidth(1.0f);
    }

    public void drawFlat(Canvas canvas, Paint paint, int ynote) {
        paint.setStrokeWidth(1.0f);
        canvas.drawLine(1, (ynote - 8) - 4, 1, ynote + 8, paint);
        Path bezierPath = new Path();
        bezierPath.moveTo(1, ynote + 1);
        bezierPath.cubicTo(4, ynote - 3, 8, ynote + 2, 1, ynote + 7 + 1 + 1);
        canvas.drawPath(bezierPath, paint);
        Path bezierPath2 = new Path();
        bezierPath2.moveTo(1, ynote + 1);
        bezierPath2.cubicTo(4, ynote - 3, 9, (ynote + 2) - 1, 1, ynote + 7 + 1 + 1);
        canvas.drawPath(bezierPath2, paint);
        Path bezierPath3 = new Path();
        bezierPath3.moveTo(1, ynote + 1);
        bezierPath3.cubicTo(4, ynote - 3, 11, (ynote + 2) - 3, 1, ynote + 7 + 1 + 1);
        canvas.drawPath(bezierPath3, paint);
    }

    public void drawNatural(Canvas canvas, Paint paint, int ynote) {
        int ystart = (ynote - 7) - 1;
        int yend = ynote + 7 + 1;
        paint.setStrokeWidth(1.0f);
        canvas.drawLine(3, ystart, 3, yend, paint);
        int x = 3 + 6;
        int ystart2 = ynote - 1;
        int yend2 = ((ynote + 14) + 1) - 1;
        canvas.drawLine(x, ystart2, x, yend2, paint);
        int xend = 10 - 1;
        int ystart3 = ynote + 1;
        int yend3 = (ystart3 - 1) - 1;
        paint.setStrokeWidth(3.0f);
        canvas.drawLine(3, ystart3, xend, yend3, paint);
        canvas.drawLine(3, ystart3 + 7, xend, yend3 + 7, paint);
        paint.setStrokeWidth(1.0f);
    }

    public String toString() {
        return String.format("AccidSymbol accid={0} whitenote={1} clef={2} width={3}", this.accid, this.whitenote, this.clef, Integer.valueOf(this.width));
    }
}
