package net.duceng.xmidi.widgets.score;

import android.graphics.Canvas;
import android.graphics.Paint;

/* JADX INFO: loaded from: classes.dex */
public class BarSymbol implements MusicSymbol {
    private int starttime;
    private int width = getMinWidth();

    public BarSymbol(int starttime) {
        this.starttime = starttime;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getStartTime() {
        return this.starttime;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getMinWidth() {
        return 14;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getWidth() {
        return this.width;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void setWidth(int value) {
        this.width = value;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getAboveStaff() {
        return 0;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public int getBelowStaff() {
        return 0;
    }

    @Override // net.duceng.xmidi.widgets.score.MusicSymbol
    public void draw(Canvas canvas, Paint paint, int ytop) {
        int yend = ytop + 28 + 4;
        paint.setStrokeWidth(1.0f);
        canvas.drawLine(5.0f, ytop, 5.0f, yend, paint);
    }

    public String toString() {
        return String.format("BarSymbol starttime=%1$s width=%2$s", Integer.valueOf(this.starttime), Integer.valueOf(this.width));
    }
}
