package net.duceng.xmidi.widgets.score;

/* JADX INFO: loaded from: classes.dex */
public class LyricSymbol {
    private int starttime;
    private String text;
    private int x;

    public LyricSymbol(int starttime, String text) {
        this.starttime = starttime;
        this.text = text;
    }

    public int getStartTime() {
        return this.starttime;
    }

    public void setStartTime(int value) {
        this.starttime = value;
    }

    public String getText() {
        return this.text;
    }

    public void setText(String value) {
        this.text = value;
    }

    public int getX() {
        return this.x;
    }

    public void setX(int value) {
        this.x = value;
    }

    public int getMinWidth() {
        float width = this.text.length() * 6.6666665f;
        if (this.text.indexOf("i") >= 0) {
            width -= 6.6666665f / 2.0f;
        }
        if (this.text.indexOf("j") >= 0) {
            width -= 6.6666665f / 2.0f;
        }
        if (this.text.indexOf("l") >= 0) {
            width -= 6.6666665f / 2.0f;
        }
        return (int) width;
    }

    public String toString() {
        return String.format("Lyric start={0} x={1} text={2}", Integer.valueOf(this.starttime), Integer.valueOf(this.x), this.text);
    }
}
