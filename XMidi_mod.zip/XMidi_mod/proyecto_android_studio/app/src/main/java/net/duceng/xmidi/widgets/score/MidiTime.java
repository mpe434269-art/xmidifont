package net.duceng.xmidi.widgets.score;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public class MidiTime implements Serializable {
    private static /* synthetic */ int[] $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration;
    private int denominator;
    private int measure;
    private int mpqn;
    private int numerator;
    private int resolution;

    static /* synthetic */ int[] $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration() {
        int[] iArr = $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration;
        if (iArr == null) {
            iArr = new int[NoteDuration.valuesCustom().length];
            try {
                iArr[NoteDuration.DottedEighth.ordinal()] = 5;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[NoteDuration.DottedHalf.ordinal()] = 9;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[NoteDuration.DottedQuarter.ordinal()] = 7;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[NoteDuration.Eighth.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                iArr[NoteDuration.Half.ordinal()] = 8;
            } catch (NoSuchFieldError e5) {
            }
            try {
                iArr[NoteDuration.Quarter.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                iArr[NoteDuration.Sixteenth.ordinal()] = 2;
            } catch (NoSuchFieldError e7) {
            }
            try {
                iArr[NoteDuration.ThirtySecond.ordinal()] = 1;
            } catch (NoSuchFieldError e8) {
            }
            try {
                iArr[NoteDuration.Triplet.ordinal()] = 3;
            } catch (NoSuchFieldError e9) {
            }
            try {
                iArr[NoteDuration.Whole.ordinal()] = 10;
            } catch (NoSuchFieldError e10) {
            }
            $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration = iArr;
        }
        return iArr;
    }

    public int getNumerator() {
        return this.numerator;
    }

    public int getDenominator() {
        return this.denominator;
    }

    public int getResolution() {
        return this.resolution;
    }

    public int getMpqn() {
        return this.mpqn;
    }

    public int getMeasure() {
        return this.measure;
    }

    public MidiTime(int numerator, int denominator, int resolution, int mpqn) {
        int beat;
        if (numerator <= 0 || denominator <= 0 || resolution <= 0) {
            throw new RuntimeException("Invalid time signature");
        }
        numerator = numerator == 5 ? 4 : numerator;
        this.numerator = numerator;
        this.denominator = denominator;
        this.resolution = resolution;
        this.mpqn = mpqn;
        if (denominator < 4) {
            beat = resolution * 2;
        } else {
            beat = resolution / (denominator / 4);
        }
        this.measure = numerator * beat;
    }

    public int GetMeasure(int time) {
        return time / this.measure;
    }

    public NoteDuration GetNoteDuration(int duration) {
        int whole = this.resolution * 4;
        if (duration >= (whole * 28) / 32) {
            return NoteDuration.Whole;
        }
        if (duration >= (whole * 20) / 32) {
            return NoteDuration.DottedHalf;
        }
        if (duration >= (whole * 14) / 32) {
            return NoteDuration.Half;
        }
        if (duration >= (whole * 10) / 32) {
            return NoteDuration.DottedQuarter;
        }
        if (duration >= (whole * 7) / 32) {
            return NoteDuration.Quarter;
        }
        if (duration >= (whole * 5) / 32) {
            return NoteDuration.DottedEighth;
        }
        if (duration >= (whole * 6) / 64) {
            return NoteDuration.Eighth;
        }
        if (duration >= (whole * 5) / 64) {
            return NoteDuration.Triplet;
        }
        if (duration >= (whole * 3) / 64) {
            return NoteDuration.Sixteenth;
        }
        return NoteDuration.ThirtySecond;
    }

    public static NoteDuration GetStemDuration(NoteDuration dur) {
        if (dur == NoteDuration.DottedHalf) {
            return NoteDuration.Half;
        }
        if (dur == NoteDuration.DottedQuarter) {
            return NoteDuration.Quarter;
        }
        if (dur == NoteDuration.DottedEighth) {
            return NoteDuration.Eighth;
        }
        return dur;
    }

    public int DurationToTime(NoteDuration dur) {
        int eighth = this.resolution / 2;
        int sixteenth = eighth / 2;
        switch ($SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration()[dur.ordinal()]) {
            case 1:
                return sixteenth / 2;
            case 2:
                return sixteenth;
            case 3:
                return this.resolution / 3;
            case 4:
                return eighth;
            case 5:
                return sixteenth * 3;
            case 6:
                return this.resolution;
            case 7:
                return eighth * 3;
            case 8:
                return this.resolution * 2;
            case 9:
                return this.resolution * 3;
            case 10:
                return this.resolution * 4;
            default:
                return 0;
        }
    }

    public String toString() {
        return String.format("TimeSignature=%1$s/%2$s quarter=%3$s tempo=%4$s", Integer.valueOf(this.numerator), Integer.valueOf(this.denominator), Integer.valueOf(this.resolution), Integer.valueOf(this.mpqn));
    }
}
