package net.duceng.xmidi.widgets.score;

/* JADX INFO: loaded from: classes.dex */
public class Note implements Comparable<Note> {
    private byte channel;
    private int duration;
    private byte key;
    private int tick;

    public Note(int t, int d, byte c, byte k) {
        this.tick = t;
        this.duration = d;
        this.channel = c;
        this.key = k;
    }

    public int getStartTick() {
        return this.tick;
    }

    public void setStartTick(int value) {
        this.tick = value;
    }

    public int getDuration() {
        return this.duration;
    }

    public void setDuration(int value) {
        this.duration = value;
    }

    public int getEndTick() {
        return this.tick + this.duration;
    }

    public byte getChannel() {
        return this.channel;
    }

    public void setChannel(byte value) {
        this.channel = value;
    }

    public byte getKey() {
        return this.key;
    }

    public void setKey(byte value) {
        this.key = value;
    }

    @Override // java.lang.Comparable
    public int compareTo(Note other) {
        if (this.tick != other.getStartTick()) {
            return this.tick < other.getStartTick() ? -1 : 1;
        }
        if (this.key != other.getKey()) {
            return this.key >= other.getKey() ? 1 : -1;
        }
        if (this.channel != other.getChannel()) {
            return this.channel >= other.getChannel() ? 1 : -1;
        }
        if (this.duration != other.getDuration()) {
            return this.duration >= other.getDuration() ? 1 : -1;
        }
        return 0;
    }

    public Note Clone() {
        return new Note(this.tick, this.duration, this.channel, this.key);
    }

    public String toString() {
        String[] scale = {"A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#"};
        return String.format("MidiNote channel=%1$s number=%2$s %3$s start=%4$s duration=%5$s", Byte.valueOf(this.channel), Byte.valueOf(this.key), scale[(this.key + 3) % 12], Integer.valueOf(this.tick), Integer.valueOf(this.duration));
    }
}
