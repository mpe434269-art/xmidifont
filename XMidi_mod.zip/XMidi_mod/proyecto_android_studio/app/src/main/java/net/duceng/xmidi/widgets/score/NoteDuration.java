package net.duceng.xmidi.widgets.score;

/* JADX INFO: loaded from: classes.dex */
public enum NoteDuration {
    ThirtySecond,
    Sixteenth,
    Triplet,
    Eighth,
    DottedEighth,
    Quarter,
    DottedQuarter,
    Half,
    DottedHalf,
    Whole;

    /* JADX INFO: renamed from: values, reason: to resolve conflict with enum method */
    public static NoteDuration[] valuesCustom() {
        NoteDuration[] noteDurationArrValuesCustom = values();
        int length = noteDurationArrValuesCustom.length;
        NoteDuration[] noteDurationArr = new NoteDuration[length];
        System.arraycopy(noteDurationArrValuesCustom, 0, noteDurationArr, 0, length);
        return noteDurationArr;
    }
}
