package net.duceng.xmidi.widgets.score;

/* JADX INFO: loaded from: classes.dex */
public class NoteScale {
    public static final int A = 0;
    public static final int Aflat = 11;
    public static final int Asharp = 1;
    public static final int B = 2;
    public static final int Bflat = 1;
    public static final int C = 3;
    public static final int Csharp = 4;
    public static final int D = 5;
    public static final int Dflat = 4;
    public static final int Dsharp = 6;
    public static final int E = 7;
    public static final int Eflat = 6;
    public static final int F = 8;
    public static final int Fsharp = 9;
    public static final int G = 10;
    public static final int Gflat = 9;
    public static final int Gsharp = 11;

    public static int ToNumber(int notescale, int octave) {
        return notescale + 9 + (octave * 12);
    }

    public static int FromNumber(int number) {
        return (number + 3) % 12;
    }

    public static boolean IsBlackKey(int notescale) {
        return notescale == 1 || notescale == 4 || notescale == 6 || notescale == 9 || notescale == 11;
    }
}
