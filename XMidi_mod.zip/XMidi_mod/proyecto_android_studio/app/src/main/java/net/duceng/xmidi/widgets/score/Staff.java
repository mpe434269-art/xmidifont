package net.duceng.xmidi.widgets.score;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import java.util.ArrayList;
import net.duceng.midi.MetaTempo;
import net.duceng.xmidi.widgets.MusicScore;

/* JADX INFO: loaded from: classes.dex */
public class Staff {
    private ClefSymbol clefsym;
    private int endtime;
    private int height;
    private AccidSymbol[] keys;
    private int keysigWidth;
    private ArrayList<LyricSymbol> lyrics;
    private int measureLength;
    private boolean showMeasures;
    private int starttime;
    private ArrayList<MusicSymbol> symbols;
    private int totaltracks;
    private int tracknum;
    private int width;
    private int ytop;

    public Staff(ArrayList<MusicSymbol> symbols, MidiKey key, MidiTime time, boolean showMeasures, boolean scrollVert, int tracknum, int totaltracks) {
        this.keysigWidth = MusicScore.KeySignatureWidth(key);
        this.tracknum = tracknum;
        this.totaltracks = totaltracks;
        this.showMeasures = showMeasures && tracknum == 0;
        this.measureLength = time.getMeasure();
        Clef clef = findClef(symbols);
        this.clefsym = new ClefSymbol(clef, 0, false);
        this.keys = key.GetSymbols(clef);
        this.symbols = symbols;
        CalculateWidth(scrollVert);
        CalculateHeight();
        CalculateStartEndTime();
        FullJustify();
    }

    public Staff(Clef clef, int tracknum, int totaltracks) {
        MidiKey key = new MidiKey(3);
        this.keysigWidth = MusicScore.KeySignatureWidth(key);
        this.tracknum = tracknum;
        this.totaltracks = totaltracks;
        this.showMeasures = false;
        this.measureLength = MetaTempo.DEFAULT_BPM;
        this.clefsym = new ClefSymbol(clef, 0, false);
        this.keys = key.GetSymbols(clef);
        this.symbols = new ArrayList<>();
        this.width = MusicScore.PageWidth;
        this.ytop = 24;
        this.height = this.ytop + 40 + 16;
        this.endtime = 0;
        this.starttime = 0;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public int getTrack() {
        return this.tracknum;
    }

    public int getStartTime() {
        return this.starttime;
    }

    public int getEndTime() {
        return this.endtime;
    }

    public void setEndTime(int value) {
        this.endtime = value;
    }

    private Clef findClef(ArrayList<MusicSymbol> list) {
        for (MusicSymbol m : list) {
            if (m instanceof ChordSymbol) {
                ChordSymbol c = (ChordSymbol) m;
                return c.getClef();
            }
        }
        return Clef.Treble;
    }

    public void CalculateHeight() {
        int above = 0;
        int below = 0;
        for (MusicSymbol s : this.symbols) {
            above = Math.max(above, s.getAboveStaff());
            below = Math.max(below, s.getBelowStaff());
        }
        int above2 = Math.max(above, this.clefsym.getAboveStaff());
        int below2 = Math.max(below, this.clefsym.getBelowStaff());
        if (this.showMeasures) {
            above2 = Math.max(above2, 24);
        }
        this.ytop = above2 + 8;
        this.height = this.ytop + 40 + below2;
        if (this.lyrics != null) {
            this.height += 12;
        }
    }

    private void CalculateWidth(boolean scrollVert) {
        if (scrollVert) {
            this.width = MusicScore.PageWidth;
            return;
        }
        this.width = this.keysigWidth;
        for (MusicSymbol s : this.symbols) {
            this.width += s.getWidth();
        }
        this.width += 8;
    }

    private void CalculateStartEndTime() {
        this.endtime = 0;
        this.starttime = 0;
        if (this.symbols.size() != 0) {
            this.starttime = this.symbols.get(0).getStartTime();
            for (MusicSymbol m : this.symbols) {
                if (this.endtime < m.getStartTime()) {
                    this.endtime = m.getStartTime();
                }
                if (m instanceof ChordSymbol) {
                    ChordSymbol c = (ChordSymbol) m;
                    if (this.endtime < c.getEndTime()) {
                        this.endtime = c.getEndTime();
                    }
                }
            }
        }
    }

    private void FullJustify() {
        if (this.width == 800) {
            int totalwidth = this.keysigWidth;
            int totalsymbols = 0;
            int i = 0;
            while (i < this.symbols.size()) {
                int start = this.symbols.get(i).getStartTime();
                totalsymbols++;
                int width = this.symbols.get(i).getWidth();
                while (true) {
                    totalwidth += width;
                    i++;
                    if (i >= this.symbols.size() || this.symbols.get(i).getStartTime() != start) {
                        break;
                    } else {
                        width = this.symbols.get(i).getWidth();
                    }
                }
            }
            int extrawidth = ((800 - totalwidth) - 1) / totalsymbols;
            if (extrawidth > 16) {
                extrawidth = 16;
            }
            int i2 = 0;
            while (i2 < this.symbols.size()) {
                int start2 = this.symbols.get(i2).getStartTime();
                int newwidth = this.symbols.get(i2).getWidth() + extrawidth;
                this.symbols.get(i2).setWidth(newwidth);
                do {
                    i2++;
                    if (i2 >= this.symbols.size()) {
                        break;
                    }
                } while (this.symbols.get(i2).getStartTime() == start2);
            }
        }
    }

    public void addLyrics(ArrayList<LyricSymbol> tracklyrics) {
        if (tracklyrics != null && tracklyrics.size() != 0) {
            this.lyrics = new ArrayList<>();
            int xpos = 0;
            int symbolindex = 0;
            for (LyricSymbol lyric : tracklyrics) {
                if (lyric.getStartTime() >= this.starttime) {
                    if (lyric.getStartTime() > this.endtime) {
                        break;
                    }
                    while (symbolindex < this.symbols.size() && this.symbols.get(symbolindex).getStartTime() < lyric.getStartTime()) {
                        xpos += this.symbols.get(symbolindex).getWidth();
                        symbolindex++;
                    }
                    lyric.setX(xpos);
                    if (symbolindex < this.symbols.size() && (this.symbols.get(symbolindex) instanceof BarSymbol)) {
                        lyric.setX(lyric.getX() + 10);
                    }
                    this.lyrics.add(lyric);
                }
            }
            if (this.lyrics.size() == 0) {
                this.lyrics = null;
            }
        }
    }

    private void drawLyrics(Canvas canvas, Paint paint) {
        int xpos = this.keysigWidth;
        int ypos = this.height - 12;
        for (LyricSymbol lyric : this.lyrics) {
            canvas.drawText(lyric.getText(), lyric.getX() + xpos, ypos, paint);
        }
    }

    private void drawMeasureNumbers(Canvas canvas, Paint paint) {
        int xpos = this.keysigWidth;
        int ypos = this.ytop - 24;
        for (MusicSymbol s : this.symbols) {
            if (s instanceof BarSymbol) {
                int measure = (s.getStartTime() / this.measureLength) + 1;
                canvas.drawText(new StringBuilder().append(measure).toString(), xpos + 5, ypos, paint);
            }
            xpos += s.getWidth();
        }
    }

    private void drawHorizLines(Canvas canvas, Paint paint) {
        int y = this.ytop - 1;
        paint.setStrokeWidth(1.0f);
        for (int line = 1; line <= 5; line++) {
            canvas.drawLine(4.0f, y, this.width - 4, y, paint);
            y += 8;
        }
    }

    private void drawEndLines(Canvas canvas, Paint paint) {
        int ystart;
        int yend;
        paint.setStrokeWidth(1.0f);
        if (this.tracknum == 0) {
            ystart = this.ytop - 1;
        } else {
            ystart = 0;
        }
        if (this.tracknum == this.totaltracks - 1) {
            yend = this.ytop + 32;
        } else {
            yend = this.height;
        }
        canvas.drawLine(4.0f, ystart, 4.0f, yend, paint);
        canvas.drawLine(this.width - 4, ystart, this.width - 4, yend, paint);
    }

    public void draw(Canvas canvas, Rect clip, Paint paint) {
        paint.setColor(-16777216);
        canvas.translate(9, 0.0f);
        this.clefsym.draw(canvas, paint, this.ytop);
        canvas.translate(-9, 0.0f);
        int xpos = 9 + this.clefsym.getWidth();
        for (AccidSymbol a : this.keys) {
            canvas.translate(xpos, 0.0f);
            a.draw(canvas, paint, this.ytop);
            canvas.translate(-xpos, 0.0f);
            xpos += a.getWidth();
        }
        for (MusicSymbol s : this.symbols) {
            if (xpos <= clip.left + clip.width() + 50 && s.getWidth() + xpos + 50 >= clip.left) {
                canvas.translate(xpos, 0.0f);
                s.draw(canvas, paint, this.ytop);
                canvas.translate(-xpos, 0.0f);
            }
            xpos += s.getWidth();
        }
        paint.setColor(-16777216);
        drawHorizLines(canvas, paint);
        drawEndLines(canvas, paint);
        if (this.showMeasures) {
            drawMeasureNumbers(canvas, paint);
        }
        if (this.lyrics != null) {
            drawLyrics(canvas, paint);
        }
    }

    public int PulseTimeForPoint(Point point) {
        int xpos = this.keysigWidth;
        int pulseTime = this.starttime;
        for (MusicSymbol sym : this.symbols) {
            pulseTime = sym.getStartTime();
            if (point.x <= sym.getWidth() + xpos) {
                return pulseTime;
            }
            xpos += sym.getWidth();
        }
        return pulseTime;
    }

    public int shadeNotes(Canvas canvas, Paint paint, int shade, int currentPulseTime, int prevPulseTime, int x_shade) {
        int end;
        int width;
        if ((this.starttime > prevPulseTime || this.endtime < prevPulseTime) && (this.starttime > currentPulseTime || this.endtime < currentPulseTime)) {
            return x_shade;
        }
        int xpos = this.keysigWidth;
        ChordSymbol prevChord = null;
        int prev_xpos = 0;
        for (int i = 0; i < this.symbols.size(); i++) {
            MusicSymbol curr = this.symbols.get(i);
            if (curr instanceof BarSymbol) {
                width = curr.getWidth();
            } else {
                int start = curr.getStartTime();
                if (i + 2 < this.symbols.size() && (this.symbols.get(i + 1) instanceof BarSymbol)) {
                    end = this.symbols.get(i + 2).getStartTime();
                } else if (i + 1 < this.symbols.size()) {
                    end = this.symbols.get(i + 1).getStartTime();
                } else {
                    end = this.endtime;
                }
                if (start > prevPulseTime && start > currentPulseTime) {
                    if (x_shade == 0) {
                        x_shade = xpos;
                    }
                    return x_shade;
                }
                if (start <= currentPulseTime && currentPulseTime < end && start <= prevPulseTime && prevPulseTime < end) {
                    return xpos;
                }
                boolean redrawLines = false;
                if (start <= prevPulseTime && prevPulseTime < end) {
                    canvas.translate(xpos - 2, -2.0f);
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(-1);
                    canvas.drawRect(0.0f, 0.0f, curr.getWidth() + 4, getHeight() + 4, paint);
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setColor(-16777216);
                    canvas.translate(-(xpos - 2), 2.0f);
                    canvas.translate(xpos, 0.0f);
                    curr.draw(canvas, paint, this.ytop);
                    canvas.translate(-xpos, 0.0f);
                    redrawLines = true;
                }
                if (start <= currentPulseTime && currentPulseTime < end) {
                    x_shade = xpos;
                    canvas.translate(xpos, 0.0f);
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(shade);
                    canvas.drawRect(0.0f, 0.0f, curr.getWidth(), getHeight(), paint);
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setColor(-65536);
                    curr.draw(canvas, paint, this.ytop);
                    canvas.translate(-xpos, 0.0f);
                    redrawLines = true;
                }
                if (redrawLines) {
                    int y = this.ytop - 1;
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setColor(-16777216);
                    paint.setStrokeWidth(1.0f);
                    canvas.translate(xpos - 2, 0.0f);
                    for (int line = 1; line <= 5; line++) {
                        canvas.drawLine(0.0f, y, curr.getWidth() + 4, y, paint);
                        y += 8;
                    }
                    canvas.translate(-(xpos - 2), 0.0f);
                    if (prevChord != null) {
                        canvas.translate(prev_xpos, 0.0f);
                        prevChord.draw(canvas, paint, this.ytop);
                        canvas.translate(-prev_xpos, 0.0f);
                    }
                    if (this.showMeasures) {
                        drawMeasureNumbers(canvas, paint);
                    }
                    if (this.lyrics != null) {
                        drawLyrics(canvas, paint);
                    }
                }
                if (curr instanceof ChordSymbol) {
                    ChordSymbol chord = (ChordSymbol) curr;
                    if (chord.getStem() != null && !chord.getStem().getReceiver()) {
                        prevChord = (ChordSymbol) curr;
                        prev_xpos = xpos;
                    }
                }
                width = curr.getWidth();
            }
            xpos += width;
        }
        return x_shade;
    }

    public String toString() {
        String result = "Staff clef=" + this.clefsym.toString() + "\n";
        String result2 = String.valueOf(result) + "  Keys:\n";
        for (AccidSymbol a : this.keys) {
            result2 = String.valueOf(result2) + "    " + a.toString() + "\n";
        }
        String result3 = String.valueOf(result2) + "  Symbols:\n";
        for (MusicSymbol s : this.keys) {
            result3 = String.valueOf(result3) + "    " + s.toString() + "\n";
        }
        for (MusicSymbol m : this.symbols) {
            result3 = String.valueOf(result3) + "    " + m.toString() + "\n";
        }
        return String.valueOf(result3) + "End Staff\n";
    }
}
