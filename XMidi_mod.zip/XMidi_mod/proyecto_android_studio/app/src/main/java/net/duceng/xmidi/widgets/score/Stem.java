package net.duceng.xmidi.widgets.score;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

/* JADX INFO: loaded from: classes.dex */
public class Stem {
    public static final int Down = 2;
    public static final int LeftSide = 1;
    public static final int RightSide = 2;
    public static final int Up = 1;
    private WhiteNote bottom;
    private int direction;
    private NoteDuration duration;
    private WhiteNote end;
    private boolean notesoverlap;
    private Stem pair;
    private boolean receiver_in_pair;
    private int side;
    private WhiteNote top;
    private int width_to_pair;

    public int getDirection() {
        return this.direction;
    }

    public void setDirection(int value) {
        ChangeDirection(value);
    }

    public NoteDuration getDuration() {
        return this.duration;
    }

    public WhiteNote getTop() {
        return this.top;
    }

    public WhiteNote getBottom() {
        return this.bottom;
    }

    public WhiteNote getEnd() {
        return this.end;
    }

    public void setEnd(WhiteNote value) {
        this.end = value;
    }

    public boolean getReceiver() {
        return this.receiver_in_pair;
    }

    public void setReceiver(boolean value) {
        this.receiver_in_pair = value;
    }

    public Stem(WhiteNote bottom, WhiteNote top, NoteDuration duration, int direction, boolean overlap) {
        this.top = top;
        this.bottom = bottom;
        this.duration = duration;
        this.direction = direction;
        this.notesoverlap = overlap;
        if (direction == 1 || this.notesoverlap) {
            this.side = 2;
        } else {
            this.side = 1;
        }
        this.end = CalculateEnd();
        this.pair = null;
        this.width_to_pair = 0;
        this.receiver_in_pair = false;
    }

    public WhiteNote CalculateEnd() {
        if (this.direction == 1) {
            WhiteNote w = this.top.Add(6);
            if (this.duration == NoteDuration.Sixteenth) {
                return w.Add(2);
            }
            if (this.duration == NoteDuration.ThirtySecond) {
                return w.Add(4);
            }
            return w;
        }
        if (this.direction == 2) {
            WhiteNote w2 = this.bottom.Add(-6);
            if (this.duration == NoteDuration.Sixteenth) {
                return w2.Add(-2);
            }
            if (this.duration == NoteDuration.ThirtySecond) {
                return w2.Add(-4);
            }
            return w2;
        }
        return null;
    }

    public void ChangeDirection(int newdirection) {
        this.direction = newdirection;
        if (this.direction == 1 || this.notesoverlap) {
            this.side = 2;
        } else {
            this.side = 1;
        }
        this.end = CalculateEnd();
    }

    public void SetPair(Stem pair, int width_to_pair) {
        this.pair = pair;
        this.width_to_pair = width_to_pair;
    }

    public boolean IsBeam() {
        return this.receiver_in_pair || this.pair != null;
    }

    public void draw(Canvas canvas, Paint paint, int ytop, WhiteNote topstaff) {
        if (this.duration != NoteDuration.Whole) {
            drawVerticalLine(canvas, paint, ytop, topstaff);
            if (this.duration != NoteDuration.Quarter && this.duration != NoteDuration.DottedQuarter && this.duration != NoteDuration.Half && this.duration != NoteDuration.DottedHalf && !this.receiver_in_pair) {
                if (this.pair != null) {
                    drawHorizBarStem(canvas, paint, ytop, topstaff);
                } else {
                    drawCurvyStem(canvas, paint, ytop, topstaff);
                }
            }
        }
    }

    private void drawVerticalLine(Canvas canvas, Paint paint, int ytop, WhiteNote topstaff) {
        int xstart;
        int y1;
        if (this.side == 1) {
            xstart = 2;
        } else {
            xstart = 11;
        }
        if (this.direction == 1) {
            int y2 = ((topstaff.Dist(this.bottom) * 8) / 2) + ytop + 2;
            int ystem = ytop + ((topstaff.Dist(this.end) * 8) / 2);
            canvas.drawLine(xstart, y2, xstart, ystem, paint);
        } else if (this.direction == 2) {
            int y3 = ((topstaff.Dist(this.top) * 8) / 2) + ytop + 6;
            if (this.side == 1) {
                y1 = y3 - 2;
            } else {
                y1 = y3 - 4;
            }
            int ystem2 = ((topstaff.Dist(this.end) * 8) / 2) + ytop + 8;
            canvas.drawLine(xstart, y1, xstart, ystem2, paint);
        }
    }

    private void drawCurvyStem(Canvas canvas, Paint paint, int ytop, WhiteNote topstaff) {
        int xstart;
        paint.setStrokeWidth(2.0f);
        if (this.side == 1) {
            xstart = 2;
        } else {
            xstart = 11;
        }
        if (this.direction == 1) {
            int ystem = ytop + ((topstaff.Dist(this.end) * 8) / 2);
            if (this.duration == NoteDuration.Eighth || this.duration == NoteDuration.DottedEighth || this.duration == NoteDuration.Triplet || this.duration == NoteDuration.Sixteenth || this.duration == NoteDuration.ThirtySecond) {
                Path bezierPath = new Path();
                bezierPath.moveTo(xstart, ystem);
                bezierPath.cubicTo(xstart, ystem + 10, xstart + 14, ystem + 16, xstart + 3, ystem + 24);
                canvas.drawPath(bezierPath, paint);
            }
            int ystem2 = ystem + 8;
            if (this.duration == NoteDuration.Sixteenth || this.duration == NoteDuration.ThirtySecond) {
                Path bezierPath2 = new Path();
                bezierPath2.moveTo(xstart, ystem2);
                bezierPath2.cubicTo(xstart, ystem2 + 10, xstart + 14, ystem2 + 16, xstart + 3, ystem2 + 24);
                canvas.drawPath(bezierPath2, paint);
            }
            int ystem3 = ystem2 + 8;
            if (this.duration == NoteDuration.ThirtySecond) {
                Path bezierPath3 = new Path();
                bezierPath3.moveTo(xstart, ystem3);
                bezierPath3.cubicTo(xstart, ystem3 + 10, xstart + 14, ystem3 + 16, xstart + 3, ystem3 + 24);
                canvas.drawPath(bezierPath3, paint);
            }
        } else if (this.direction == 2) {
            int ystem4 = ((topstaff.Dist(this.end) * 8) / 2) + ytop + 8;
            if (this.duration == NoteDuration.Eighth || this.duration == NoteDuration.DottedEighth || this.duration == NoteDuration.Triplet || this.duration == NoteDuration.Sixteenth || this.duration == NoteDuration.ThirtySecond) {
                Path bezierPath4 = new Path();
                bezierPath4.moveTo(xstart, ystem4);
                bezierPath4.cubicTo(xstart, ystem4 - 7, xstart + 14, ystem4 - 16, xstart + 7, (ystem4 - 16) - 3);
                canvas.drawPath(bezierPath4, paint);
            }
            int ystem5 = ystem4 - 8;
            if (this.duration == NoteDuration.Sixteenth || this.duration == NoteDuration.ThirtySecond) {
                Path bezierPath5 = new Path();
                bezierPath5.moveTo(xstart, ystem5);
                bezierPath5.cubicTo(xstart, ystem5 - 7, xstart + 14, ystem5 - 16, xstart + 7, (ystem5 - 16) - 3);
                canvas.drawPath(bezierPath5, paint);
            }
            int ystem6 = ystem5 - 8;
            if (this.duration == NoteDuration.ThirtySecond) {
                Path bezierPath6 = new Path();
                bezierPath6.moveTo(xstart, ystem6);
                bezierPath6.cubicTo(xstart, ystem6 - 7, xstart + 14, ystem6 - 16, xstart + 7, (ystem6 - 16) - 3);
                canvas.drawPath(bezierPath6, paint);
            }
        }
        paint.setStrokeWidth(1.0f);
    }

    private void drawHorizBarStem(Canvas canvas, Paint paint, int ytop, WhiteNote topstaff) {
        paint.setStrokeWidth(4.0f);
        paint.setStrokeCap(Paint.Cap.BUTT);
        int xstart = 0;
        int xstart2 = 0;
        if (this.side == 1) {
            xstart = 2;
        } else if (this.side == 2) {
            xstart = 11;
        }
        if (this.pair.side == 1) {
            xstart2 = 2;
        } else if (this.pair.side == 2) {
            xstart2 = 11;
        }
        if (this.direction == 1) {
            int xend = this.width_to_pair + xstart2;
            int ystart = ytop + ((topstaff.Dist(this.end) * 8) / 2);
            int yend = ytop + ((topstaff.Dist(this.pair.end) * 8) / 2);
            if (this.duration == NoteDuration.Eighth || this.duration == NoteDuration.DottedEighth || this.duration == NoteDuration.Triplet || this.duration == NoteDuration.Sixteenth || this.duration == NoteDuration.ThirtySecond) {
                canvas.drawLine(xstart, ystart, xend, yend, paint);
            }
            int ystart2 = ystart + 8;
            int yend2 = yend + 8;
            if (this.duration == NoteDuration.DottedEighth) {
                int x = xend - 8;
                double slope = (((double) (yend2 - ystart2)) * 1.0d) / ((double) (xend - xstart));
                int y = (int) ((((double) (x - xend)) * slope) + ((double) yend2));
                canvas.drawLine(x, y, xend, yend2, paint);
            }
            if (this.duration == NoteDuration.Sixteenth || this.duration == NoteDuration.ThirtySecond) {
                canvas.drawLine(xstart, ystart2, xend, yend2, paint);
            }
            int ystart3 = ystart2 + 8;
            int yend3 = yend2 + 8;
            if (this.duration == NoteDuration.ThirtySecond) {
                canvas.drawLine(xstart, ystart3, xend, yend3, paint);
            }
        } else {
            int xend2 = this.width_to_pair + xstart2;
            int ystart4 = ((topstaff.Dist(this.end) * 8) / 2) + ytop + 8;
            int yend4 = ((topstaff.Dist(this.pair.end) * 8) / 2) + ytop + 8;
            if (this.duration == NoteDuration.Eighth || this.duration == NoteDuration.DottedEighth || this.duration == NoteDuration.Triplet || this.duration == NoteDuration.Sixteenth || this.duration == NoteDuration.ThirtySecond) {
                canvas.drawLine(xstart, ystart4, xend2, yend4, paint);
            }
            int ystart5 = ystart4 - 8;
            int yend5 = yend4 - 8;
            if (this.duration == NoteDuration.DottedEighth) {
                int x2 = xend2 - 8;
                double slope2 = (((double) (yend5 - ystart5)) * 1.0d) / ((double) (xend2 - xstart));
                int y2 = (int) ((((double) (x2 - xend2)) * slope2) + ((double) yend5));
                canvas.drawLine(x2, y2, xend2, yend5, paint);
            }
            if (this.duration == NoteDuration.Sixteenth || this.duration == NoteDuration.ThirtySecond) {
                canvas.drawLine(xstart, ystart5, xend2, yend5, paint);
            }
            int ystart6 = ystart5 - 8;
            int yend6 = yend5 - 8;
            if (this.duration == NoteDuration.ThirtySecond) {
                canvas.drawLine(xstart, ystart6, xend2, yend6, paint);
            }
        }
        paint.setStrokeWidth(1.0f);
    }

    public String toString() {
        return String.format("Stem duration=%1$s direction=%2$s top=%3$s bottom=%4$s end=%5$s overlap=%6$s side=%7$s width_to_pair=%8$s receiver_in_pair=%9$s", this.duration, Integer.valueOf(this.direction), this.top.toString(), this.bottom.toString(), this.end.toString(), Boolean.valueOf(this.notesoverlap), Integer.valueOf(this.side), Integer.valueOf(this.width_to_pair), Boolean.valueOf(this.receiver_in_pair));
    }
}
