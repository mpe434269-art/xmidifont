package net.duceng.xmidi.widgets.score;

import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public class SymbolWidths {
    private DictInt maxwidths;
    private int[] starttimes;
    private DictInt[] widths;

    public SymbolWidths(ArrayList<ArrayList<MusicSymbol>> tracks, ArrayList<ArrayList<LyricSymbol>> tracklyrics) {
        this.widths = new DictInt[tracks.size()];
        for (int track = 0; track < tracks.size(); track++) {
            this.widths[track] = GetTrackWidths(tracks.get(track));
        }
        this.maxwidths = new DictInt();
        for (DictInt dict : this.widths) {
            for (int i = 0; i < dict.count(); i++) {
                int time = dict.getKey(i);
                if (!this.maxwidths.contains(time) || this.maxwidths.get(time) < dict.get(time)) {
                    this.maxwidths.set(time, dict.get(time));
                }
            }
        }
        if (tracklyrics != null) {
            for (ArrayList<LyricSymbol> lyrics : tracklyrics) {
                if (lyrics != null) {
                    for (LyricSymbol lyric : lyrics) {
                        int width = lyric.getMinWidth();
                        int time2 = lyric.getStartTime();
                        if (!this.maxwidths.contains(time2) || this.maxwidths.get(time2) < width) {
                            this.maxwidths.set(time2, width);
                        }
                    }
                }
            }
        }
        this.starttimes = new int[this.maxwidths.count()];
        for (int i2 = 0; i2 < this.maxwidths.count(); i2++) {
            int key = this.maxwidths.getKey(i2);
            this.starttimes[i2] = key;
        }
        Arrays.sort(this.starttimes);
    }

    private static DictInt GetTrackWidths(ArrayList<MusicSymbol> symbols) {
        DictInt widths = new DictInt();
        for (MusicSymbol m : symbols) {
            int start = m.getStartTime();
            int w = m.getMinWidth();
            if (!(m instanceof BarSymbol)) {
                if (widths.contains(start)) {
                    widths.set(start, widths.get(start) + w);
                } else {
                    widths.set(start, w);
                }
            }
        }
        return widths;
    }

    public int GetExtraWidth(int track, int start) {
        return !this.widths[track].contains(start) ? this.maxwidths.get(start) : this.maxwidths.get(start) - this.widths[track].get(start);
    }

    public int[] getStartTimes() {
        return this.starttimes;
    }
}
