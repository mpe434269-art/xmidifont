package net.duceng.xsynth;

/* JADX INFO: loaded from: classes.dex */
public final class BuildConfig {
    public static final boolean DEBUG = false;
}
