import java.io.*; import java.util.*;
import net.duceng.midi.*; import net.duceng.xmidi.util.*;
public class Jit { public static void main(String[] a) throws Exception {
  StyFile sty = new StyFile(new FileInputStream(a[0]));
  final int mp=Integer.parseInt(a[1]); final int res=sty.getResolution(); final int bt=res*4;
  final double msPerTick=mp/1000.0/res;
  final long[] t0={0}; final int[] bars={0}; final int[] lastTick={-1}; final List<Double> dev=new ArrayList<>();
  StyleEngine eng=new StyleEngine(sty,new StyleEngine.Sink(){
    public void send(EventChannel e){ long now=System.nanoTime(); if(t0[0]==0){t0[0]=now;}
      if(e.getTick()<lastTick[0]-bt/2) bars[0]++; lastTick[0]=e.getTick();
      double ideal=(bars[0]*bt+e.getTick())*msPerTick; double act=(now-t0[0])/1e6; dev.add(act-ideal);} public void silence(){} },
    new StyleEngine.Host(){public int mpqn(){return mp;}},null);
  eng.start("Main A"); Thread.sleep(20000); eng.stop(); Thread.sleep(100);
  double max=0,sum=0; int n=0; for(double d:dev){ if(d>max)max=d; sum+=d; n++;} double mn=1e9; for(double d:dev) if(d<mn)mn=d;
  Collections.sort(dev); 
  System.out.printf("events=%d  late: mean=%.3f ms  p99=%.3f ms  max=%.3f ms  min=%.3f ms%n",n,sum/n,dev.get((int)(n*0.99)),max,mn);
}}
