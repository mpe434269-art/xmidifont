import java.io.*; import java.util.*;
import net.duceng.midi.*; import net.duceng.xmidi.util.*;
public class Test {
  static class Rec { double t; String s; Rec(double t,String s){this.t=t;this.s=s;} }
  public static void main(String[] a) throws Exception {
    StyFile sty = new StyFile(new FileInputStream(a[0]));
    System.out.println("sections="+sty.getSections().keySet()+" res="+sty.getResolution());
    for (String k: sty.getSections().keySet()) System.out.println("  "+k+" bars="+sty.getSection(k).sizeBars());
    final List<Rec> log = Collections.synchronizedList(new ArrayList<>());
    final long t0 = System.nanoTime();
    final int[] mp = {545454};
    final Set<String> held = Collections.synchronizedSet(new TreeSet<>());
    final List<String> secs = Collections.synchronizedList(new ArrayList<>());
    StyleEngine eng = new StyleEngine(sty, new StyleEngine.Sink(){
      public void send(EventChannel e){ double ms=(System.nanoTime()-t0)/1e6;
        String k=e.getChannel()+":"+e.getValue1();
        if(e.getType()==9&&e.getValue2()>0){ log.add(new Rec(ms,"ON  ch"+e.getChannel()+" n"+e.getValue1())); if(e.getChannel()!=9) held.add(k);} 
        else if(e.getType()==8||e.getType()==9){ log.add(new Rec(ms,"OFF ch"+e.getChannel()+" n"+e.getValue1())); held.remove(k);} }
      public void silence(){ log.add(new Rec((System.nanoTime()-t0)/1e6,"SILENCE")); held.clear(); } },
      new StyleEngine.Host(){ public int mpqn(){return mp[0];} }, null);
    eng.setListener(new StyleEngine.Listener(){ public void onSection(String n){ secs.add(String.format("%.0f ms -> %s",(System.nanoTime()-t0)/1e6,n)); } public void onStopped(){ secs.add("stopped"); } });
    Chords ch = new Chords(); Chords.Chord[] cs = ch.getGChords(0); // C F G ...
    double beatMs = 545454/1000.0;
    eng.start("Main A");
    long s = System.nanoTime();
    Thread.sleep((long)(beatMs*4.5)); eng.setChord(cs[0]);                 // C a mitad del compas 2
    double tChord1=(System.nanoTime()-t0)/1e6;
    Thread.sleep((long)(beatMs*3.3)); eng.setChord(cs[1]);                 // cambio de acorde
    double tChord2=(System.nanoTime()-t0)/1e6;
    Thread.sleep((long)(beatMs*2.7)); eng.requestSection("Fill In AB"); double tFill=(System.nanoTime()-t0)/1e6;
    Thread.sleep((long)(beatMs*6)); eng.requestSection("Main B");
    Thread.sleep((long)(beatMs*5)); eng.requestSection("Ending B");
    Thread.sleep((long)(beatMs*12));
    eng.stop(); Thread.sleep(100);
    System.out.println("beatMs="+beatMs+" barMs="+beatMs*4);
    System.out.println("chord1 pressed at "+String.format("%.1f",tChord1)+"  chord2 at "+String.format("%.1f",tChord2)+"  fill pressed at "+String.format("%.1f",tFill));
    for(String x:secs) System.out.println("SECTION "+x);
    // primer evento tras pulsar
    for (double tp : new double[]{tChord1,tChord2,tFill}) { for (Rec r: log) if (r.t>=tp) { System.out.println("first event after press @"+String.format("%.1f",tp)+": +"+String.format("%.2f",r.t-tp)+" ms "+r.s); break; } }
    // jitter: eventos de bombo/ritmo en rejilla
    System.out.println("stuck notes at end: "+held);
    for (double tp : new double[]{tChord1,tChord2}) { int c=0; for (Rec r: log) if (r.t>=tp && !r.s.contains("ch9") && r.s.startsWith("ON")) { System.out.println("  melodic ON after chord press +"+String.format("%.2f",r.t-tp)+" ms "+r.s); if(++c>=6) break; } }
    // jitter del reloj: instantes del mismo evento de bateria en 2 vueltas de Main A (4 compases = 8727 ms)
    List<Double> k=new ArrayList<>(); for(Rec r:log) if(r.s.equals("ON  ch9 n36") && r.t<5700) k.add(r.t);
    System.out.println("kick(n36) times before fill: "+k);
    double maxDev=0; for(int i=1;i<k.size();i++){ double d=k.get(i)-k.get(i-1); }
    
    int on=0,off=0; for(Rec r:log){ if(r.s.startsWith("ON"))on++; else if(r.s.startsWith("OFF"))off++; }
    System.out.println("ON="+on+" OFF="+off+" total events="+log.size());
  }
}
