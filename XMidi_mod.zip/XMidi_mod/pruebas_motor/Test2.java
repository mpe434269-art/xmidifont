import java.io.*; import java.util.*; import java.util.concurrent.atomic.*;
import net.duceng.midi.*; import net.duceng.xmidi.util.*;
public class Test2 {
  static final List<String> log = Collections.synchronizedList(new ArrayList<>()); static long t0;
  static StyleEngine mk(StyFile sty, final int[] mp, final boolean throwAfter, final AtomicInteger sent, final List<String> secs){
    StyleEngine e = new StyleEngine(sty,new StyleEngine.Sink(){
      public void send(EventChannel ev){ if(throwAfter && sent.incrementAndGet()>50) throw new IllegalStateException("native boom");
        log.add(String.format("%.1f %s ch%d n%d", (System.nanoTime()-t0)/1e6, ev.getType()==9&&ev.getValue2()>0?"ON ":"OFF", ev.getChannel(), ev.getValue1())); }
      public void silence(){ log.add("SILENCE"); } }, new StyleEngine.Host(){public int mpqn(){return mp[0];}}, null);
    e.setListener(new StyleEngine.Listener(){ public void onSection(String n){secs.add(String.format("%.0f->%s",(System.nanoTime()-t0)/1e6,n));} public void onStopped(){secs.add("stopped");} });
    return e; }
  public static void main(String[] a) throws Exception {
    StyFile sty=new StyFile(new FileInputStream(a[0])); int[] mp={500000}; Chords ch=new Chords(); Chords.Chord[] cs=ch.getGChords(0);
    for(String k:sty.getSections().keySet()) System.out.println("  "+k+" bars="+sty.getSection(k).sizeBars());
    // --- 1) continuidad de strings/pads: contar re-ataques (OFF seguido de ON de la misma nota en <15 ms) en 3 compases con acorde fijo
    List<String> secs=new ArrayList<>(); t0=System.nanoTime(); StyleEngine e=mk(sty,mp,false,null,secs); e.setChord(cs[0]); e.start("Main A"); Thread.sleep(6500); e.stopAndWait(500);
    int reat=0, offOnGap=0; Map<String,Double> lastOff=new HashMap<>();
    for(String l:log){ String[] p=l.split(" "); if(p.length<4||l.startsWith("SIL")) continue; double t=Double.parseDouble(p[0]); String key=p[2]+p[3]; if(p[1].equals("OFF")) lastOff.put(key,t); else if(!p[2].equals("ch9")){ Double lo=lastOff.get(key); if(lo!=null && t-lo<15) reat++; } }
    System.out.println("1) re-ataques (OFF+ON misma nota <15ms, canales melodicos) en 6.5 s = "+reat);
    // --- 2) salir de un Ending con Fill
    log.clear(); secs.clear(); t0=System.nanoTime(); e=mk(sty,mp,false,null,secs); e.setChord(cs[0]); e.start("Ending A"); Thread.sleep(700); e.requestSection("Fill In AA"); Thread.sleep(3500); e.requestSection("Main B"); Thread.sleep(2500); e.stopAndWait(500);
    System.out.println("2) Ending + Fill: "+secs);
    // --- 3) cierre sin notas colgadas
    log.clear(); secs.clear(); t0=System.nanoTime(); e=mk(sty,mp,false,null,secs); e.setChord(cs[0]); e.start("Main A"); Thread.sleep(2300); e.setChord(cs[1]); Thread.sleep(2300); e.setChord(null); Thread.sleep(600); e.stopAndWait(500);
    Set<String> on=new TreeSet<>(); for(String l:log){ String[] p=l.split(" "); if(l.startsWith("SIL")){on.clear();continue;} if(p.length<4||p[2].equals("ch9")) continue; if(p[1].equals("ON")) on.add(p[2]+p[3]); else on.remove(p[2]+p[3]); }
    System.out.println("3) notas colgadas al detener: "+on+"   (hilo vivo: "+e.isRunning()+")");
    // --- 4) crash en el sintetizador: el motor debe parar sin lanzar excepcion al exterior
    final AtomicInteger unc=new AtomicInteger(); Thread.setDefaultUncaughtExceptionHandler((th,ex)->unc.incrementAndGet());
    log.clear(); secs.clear(); t0=System.nanoTime(); e=mk(sty,mp,true,new AtomicInteger(),secs); e.setChord(cs[0]); e.start("Main A"); Thread.sleep(1500);
    System.out.println("4) excepciones sin capturar tras fallo del sintetizador: "+unc.get()+"   motor corriendo: "+e.isRunning()+"  "+secs);
    // --- 5) cambio de acorde: notas iguales no se reatacan; tiempo hasta el 1er evento melodico
    log.clear(); secs.clear(); t0=System.nanoTime(); e=mk(sty,mp,false,null,secs); e.setChord(cs[0]); e.start("Main A"); Thread.sleep(2100); int before=log.size(); double tp=(System.nanoTime()-t0)/1e6; e.setChord(cs[1]); Thread.sleep(300);
    System.out.println("5) acorde C->F: eventos inmediatos:"); for(int i=before;i<log.size()&&i<before+14;i++){ String l=log.get(i); String[] p=l.split(" "); if(p.length>3) System.out.println("    +"+String.format("%.2f",Double.parseDouble(p[0])-tp)+" ms "+l.substring(l.indexOf(' ')+1)); }
    e.stopAndWait(500);
  }}
