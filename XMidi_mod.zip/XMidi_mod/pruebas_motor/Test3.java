import java.io.*; import java.util.*;
import net.duceng.midi.*; import net.duceng.xmidi.util.*;
public class Test3 { static final List<String> log=Collections.synchronizedList(new ArrayList<>()); static long t0;
 public static void main(String[] a) throws Exception {
  StyFile sty=new StyFile(new FileInputStream(a[0])); int[] mp={500000}; Chords ch=new Chords(); Chords.Chord[] cs=ch.getGChords(0);
  System.out.println("setup Intro A: "+fmt(sty.getSection("Intro A").getSetupEvents()));
  System.out.println("setup Main A : "+fmt(sty.getSection("Main A").getSetupEvents()));
  System.out.println("setup Main B : "+fmt(sty.getSection("Main B").getSetupEvents()));
  StyleEngine e=new StyleEngine(sty,new StyleEngine.Sink(){
    public void send(EventChannel ev){ if(ev.getType()==12||ev.getType()==11&&ev.getValue1()==7&&ev.getChannel()==13||ev.getType()==11&&ev.getValue1()==0)
        log.add(String.format("%.0f ms: %s ch%d v1=%d v2=%d",(System.nanoTime()-t0)/1e6, ev.getType()==12?"PROGRAM":"CC", ev.getChannel(), ev.getValue1(), ev.getValue2())); }
    public void silence(){} }, new StyleEngine.Host(){public int mpqn(){return mp[0];}}, null);
  t0=System.nanoTime(); e.setChord(cs[0]); e.start("Intro A"); Thread.sleep(1200);
  e.requestSection("Main A"); Thread.sleep(2600);          // Intro A (1 compas = 2000 ms) -> luego Main A? (pulsar Main A durante el intro cambia el destino)
  e.requestSection("Main B"); Thread.sleep(2600);          // Main A -> fill AB -> Main B
  e.requestSection("Fill In BA"); Thread.sleep(1500);     // fill desde Main B
  e.stopAndWait(500);
  System.out.println("--- ajustes recibidos por el sintetizador en el canal 13 (y bancos) ---"); for(String l:log) if(l.contains("ch14")) System.out.println(l);
  int n13=0; for(String l:log) if(l.contains("ch14")&&l.contains("PROGRAM")) n13++; System.out.println("cambios de programa canal 13 en 9 s: "+n13+"  (esperado: 1 por cambio de seccion, no uno por compas)");
 }
 static String fmt(List<EventChannel> l){ StringBuilder s=new StringBuilder(); for(EventChannel e:l) s.append(e.getType()==12?"PC":"CC"+e.getValue1()).append("(ch").append(e.getChannel()).append(",").append(e.getType()==12?e.getValue1():e.getValue2()).append(") "); return s.toString(); } }
