import java.io.*; import java.util.*;
import net.duceng.midi.*; import net.duceng.xmidi.util.*;
public class Test4 { static final List<String> log=Collections.synchronizedList(new ArrayList<>()); static long t0;
 public static void main(String[] a) throws Exception {
  StyFile sty=new StyFile(new FileInputStream(a[0])); int[] mp={500000}; Chords ch=new Chords(); Chords.Chord[] cs=ch.getGChords(0);
  StyleEngine e=new StyleEngine(sty,new StyleEngine.Sink(){
    public void send(EventChannel ev){ if(ev.getChannel()!=9) log.add(String.format("%.1f %s ch%d n%d vel%d",(System.nanoTime()-t0)/1e6,(ev.getType()==9&&ev.getValue2()>0)?"ON ":"OFF",ev.getChannel(),ev.getValue1(),ev.getValue2())); }
    public void silence(){} }, new StyleEngine.Host(){public int mpqn(){return mp[0];}}, null);
  t0=System.nanoTime(); e.setChord(cs[0]); e.start("Main A"); Thread.sleep(1100);
  double t1=(System.nanoTime()-t0)/1e6; int b=log.size();
  e.setChord(cs[1]); Thread.sleep(90); e.setChord(cs[2]); Thread.sleep(90); e.setChord(cs[0]); Thread.sleep(400);
  System.out.println("rafaga de 3 cambios de acorde cada ~90 ms (eventos melodicos, tiempo relativo al 1er cambio):");
  for(int i=b;i<log.size();i++){ String l=log.get(i); String[] p=l.split(" "); double t=Double.parseDouble(p[0])-t1; if(t<420) System.out.printf("  +%6.1f ms  %s%n",t,l.substring(l.indexOf(' ')+1)); }
  e.stopAndWait(500);
 } }
