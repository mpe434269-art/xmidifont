import java.io.*; import java.util.*;
import net.duceng.midi.*; import net.duceng.xmidi.util.*;
public class Test5 { static final List<String> log=Collections.synchronizedList(new ArrayList<>()); static final List<double[]> ev=Collections.synchronizedList(new ArrayList<>()); static long t0;
 static StyleEngine mk(StyFile sty,int[] mp){ return new StyleEngine(sty,new StyleEngine.Sink(){
    public void send(EventChannel e){ double t=(System.nanoTime()-t0)/1e6; ev.add(new double[]{t,e.getType(),e.getChannel(),e.getValue1(),e.getValue2()});
      if(e.getType()==12) log.add(String.format("%.0f ms PROGRAM ch%d = %d",t,e.getChannel(),e.getValue1())); }
    public void silence(){} }, new StyleEngine.Host(){public int mpqn(){return mp[0];}}, null); }
 public static void main(String[] a) throws Exception {
  StyFile sty=new StyFile(new FileInputStream(a[0])); int[] mp={500000}; Chords ch=new Chords(); Chords.Chord[] cs=ch.getGChords(0);
  // ---- base (igual que Drums.applyStyleSetup)
  List<EventChannel> base=new ArrayList<>(); int baseProg14=-1;
  for(MidiEvent e: sty.getSint()) if(e instanceof EventChannel){ EventChannel c=(EventChannel)e; if(c.getChannel()>=8 && c.getChannel()!=8 && c.getChannel()!=9){ if(c.getType()==12||c.getType()==11) base.add(c); if(c.getType()==12&&c.getChannel()==14) baseProg14=c.getValue1(); } }
  base.add(new EventChannel(0,(byte)12,(byte)14,(byte)33,(byte)0)); baseProg14=33;
  System.out.println("1) programa BASE del canal 14 (bajo = 33) agregado a los ajustes base");
  StyleEngine e=mk(sty,mp); e.setBaseSetup(base); e.setChord(cs[0]); t0=System.nanoTime();
  e.start("Intro A"); Thread.sleep(900);
  e.requestSection("Main A"); Thread.sleep(2400);            // Intro A termina -> Main A
  e.requestSection("Ending A"); Thread.sleep(1500);          // Ending: sin ajustes propios -> debe restaurar la base
  e.stopAndWait(500);
  System.out.println("   cambios de programa del canal 14 (Intro=55, Main A=27, Ending sin ajuste -> base):"); for(String l:log) if(l.contains("ch14")) System.out.println("   "+l);
  // ---- relleno a mitad de compas
  ev.clear(); log.clear(); t0=System.nanoTime(); e=mk(sty,mp); e.setBaseSetup(base); e.setChord(cs[0]); e.start("Main A");
  Thread.sleep(1000+250); double tp=(System.nanoTime()-t0)/1e6; e.requestSection("Fill In AA"); Thread.sleep(1200); e.stopAndWait(500);
  // canales que define el relleno / que tenia el Main
  Set<Integer> fillCh=new TreeSet<>(), mainCh=new TreeSet<>();
  for(EventChannel x: sty.getSection("Fill In AA").getEvents(0,cs[0])) if(x.getType()==9) fillCh.add((int)x.getChannel());
  for(EventChannel x: sty.getSection("Main A").getEvents(0,cs[0])) if(x.getType()==9) mainCh.add((int)x.getChannel());
  System.out.println("2) canales con notas en Fill In AA: "+fillCh+"   en Main A: "+mainCh);
  double barMs=2000; double pos=(tp%barMs); int fromFill=0, fromMain=0;
  for(double[] r: ev){ if(r[0]>=tp && r[0]<tp+(barMs-pos)-5 && r[1]==9 && r[4]>0){ int c=(int)r[2]; if(fillCh.contains(c)) fromFill++; else fromMain++; } }
  System.out.printf("   pulso el Fill a +%.0f ms dentro del compas. Notas hasta el final del compas -> de canales del relleno: %d, de canales que el relleno NO define (siguen con el Main): %d%n",pos,fromFill,fromMain);
  // ---- metronomo
  ev.clear(); t0=System.nanoTime(); e=mk(sty,mp); e.setMetronome(true,76,77,90); e.start("Main A"); Thread.sleep(4300); e.stopAndWait(500);
  List<Double> clicks=new ArrayList<>(); List<Integer> notes=new ArrayList<>(); for(double[] r: ev) if(r[1]==9&&r[2]==9&&(r[3]==76||r[3]==77)&&r[4]==90){ clicks.add(r[0]); notes.add((int)r[3]); }
  System.out.println("3) metronomo: "+clicks.size()+" clicks en 4.3 s (esperado 8-9), notas: "+notes);
  double maxdev=0; for(int i=0;i<clicks.size();i++){ double ideal=clicks.get(0)+i*500.0; maxdev=Math.max(maxdev,Math.abs(clicks.get(i)-ideal)); } System.out.printf("   desviacion maxima respecto a una rejilla perfecta de 500 ms: %.2f ms%n",maxdev);
 }}
