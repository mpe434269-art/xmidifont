import java.io.*; import java.util.*;
import net.duceng.midi.*; import net.duceng.xmidi.util.*;
public class Test6 { static final List<double[]> ev=Collections.synchronizedList(new ArrayList<>()); static long t0;
 public static void main(String[] a) throws Exception {
  StyFile sty=new StyFile(new FileInputStream(a[0])); int[] mp={500000}; Chords ch=new Chords(); Chords.Chord[] cs=ch.getGChords(0);
  Map<Integer,Integer> fillAfter=new TreeMap<>(), fillAll=new TreeMap<>(), mainAfter=new TreeMap<>();
  for(EventChannel x: sty.getSection("Fill In AA").getEvents(0,cs[0])) if(x.getType()==9&&x.getValue2()>0){ fillAll.merge((int)x.getChannel(),1,Integer::sum); if(x.getTick()>240) fillAfter.merge((int)x.getChannel(),1,Integer::sum); }
  for(EventChannel x: sty.getSection("Main A").getEvents(0,cs[0])) if(x.getType()==9&&x.getValue2()>0&&x.getTick()>240) mainAfter.merge((int)x.getChannel(),1,Integer::sum);
  System.out.println("notas del RELLENO por canal (todo el compas): "+fillAll+"   | despues del tick 240: "+fillAfter);
  System.out.println("notas del MAIN A por canal despues del tick 240: "+mainAfter);
  StyleEngine e=new StyleEngine(sty,new StyleEngine.Sink(){ public void send(EventChannel x){ ev.add(new double[]{(System.nanoTime()-t0)/1e6,x.getType(),x.getChannel(),x.getValue1(),x.getValue2()}); } public void silence(){} }, new StyleEngine.Host(){public int mpqn(){return mp[0];}}, null);
  e.setChord(cs[0]); t0=System.nanoTime(); e.start("Main A"); Thread.sleep(1250); double tp=(System.nanoTime()-t0)/1e6; e.requestSection("Fill In AA"); Thread.sleep(1000); e.stopAndWait(400);
  double barEnd=Math.ceil(tp/2000.0)*2000.0; Map<Integer,Integer> got=new TreeMap<>();
  for(double[] r: ev) if(r[0]>=tp && r[0]<barEnd-3 && r[1]==9 && r[4]>0) got.merge((int)r[2],1,Integer::sum);
  System.out.println("notas que SUENAN desde que se pulsa el fill (a +"+Math.round(tp%2000)+" ms) hasta el final del compas, por canal: "+got);
  System.out.println("   piano (canal 11) suena: "+(got.getOrDefault(11,0)>0?"SI":"NO")+"   strings/pad (canal 12) suena: "+(got.getOrDefault(12,0)>0?"SI":"NO")+"   bateria (9) suena: "+(got.getOrDefault(9,0)>0?"SI":"NO"));
 }}
