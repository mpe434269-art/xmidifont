import java.io.*; import java.util.*;
import net.duceng.midi.*; import net.duceng.xmidi.util.*;
public class Test7 { static final List<String> log=Collections.synchronizedList(new ArrayList<>()); static long t0;
 static StyleEngine mk(StyFile sty,int[] mp,List<String> secs){ StyleEngine e=new StyleEngine(sty,new StyleEngine.Sink(){
   public void send(EventChannel x){ double t=(System.nanoTime()-t0)/1e6; if(x.getType()==12) log.add(String.format("%6.0f ms  PROGRAM ch%d = %d",t,x.getChannel(),x.getValue1())); if(x.getType()==8||x.getType()==9) lastNote.add(new double[]{t,x.getChannel(),x.getType(),x.getValue2()}); }
   public void silence(){} }, new StyleEngine.Host(){public int mpqn(){return mp[0];}}, null);
   e.setListener(new StyleEngine.Listener(){ public void onSection(String n){ secs.add(String.format("%.0f->%s",(System.nanoTime()-t0)/1e6,n)); } public void onStopped(){} }); return e; }
 static final List<double[]> lastNote=Collections.synchronizedList(new ArrayList<>());
 public static void main(String[] a) throws Exception {
  StyFile sty=new StyFile(new FileInputStream(a[0])); int[] mp={500000}; Chords ch=new Chords(); Chords.Chord[] cs=ch.getGChords(0);
  List<EventChannel> base=new ArrayList<>(); base.add(new EventChannel(0,(byte)12,(byte)14,(byte)33,(byte)0));   // bajo (base del estilo)
  // 1) Intro A (con Orchestra Hit en el canal 14) -> termina solo -> Main A: debe VOLVER al bajo
  List<String> secs=new ArrayList<>(); t0=System.nanoTime(); StyleEngine e=mk(sty,mp,secs); e.setBaseSetup(base); e.setChord(cs[0]); e.start("Intro A"); Thread.sleep(2600); e.stopAndWait(400);
  System.out.println("1) Intro A -> Main (sin tocar nada):"); for(String l:log) System.out.println("   "+l); System.out.println("   secciones: "+secs);
  // 2) Main C (usamos Main B como 'el que sonaba') + Intro A -> al terminar vuelve al Main B (no al A)
  log.clear(); secs.clear(); t0=System.nanoTime(); e=mk(sty,mp,secs); e.setBaseSetup(base); e.setChord(cs[0]); e.start("Main B"); Thread.sleep(1100); e.requestSection("Intro A"); Thread.sleep(4600); e.stopAndWait(400);
  System.out.println("2) estaba en Main B y pulso Intro A: "+secs);
  // 3) notas largas: un Main que da la vuelta (4 compases = 8 s) no debe cortar nada en la vuelta
  lastNote.clear(); log.clear(); secs.clear(); t0=System.nanoTime(); e=mk(sty,mp,secs); e.setBaseSetup(base); e.setChord(cs[0]); e.start("Main A"); Thread.sleep(10200); e.stopAndWait(400);
  int cutsAtLoop=0; for(double[] r: lastNote){ if(r[2]==8 && r[1]!=9 && Math.abs(r[0]-8000)<25 && true) cutsAtLoop++; }
  System.out.println("3) Main A de 4 compases, vuelta a los 8000 ms: note-off de canales melodicos en +-25 ms de la vuelta = "+cutsAtLoop+"  (programas reenviados en la vuelta: "+log.size()+")");
 }}
