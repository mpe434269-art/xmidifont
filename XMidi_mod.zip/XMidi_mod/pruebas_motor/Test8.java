import java.io.*; import java.util.*;
import net.duceng.midi.*; import net.duceng.xmidi.util.*;
public class Test8 { static final List<double[]> ev=Collections.synchronizedList(new ArrayList<>()); static long t0;
 static StyleEngine mk(StyFile sty,int[] mp,List<String> secs){ StyleEngine e=new StyleEngine(sty,new StyleEngine.Sink(){ public void send(EventChannel x){ ev.add(new double[]{(System.nanoTime()-t0)/1e6,x.getType(),x.getChannel(),x.getValue1(),x.getValue2()}); } public void silence(){} }, new StyleEngine.Host(){public int mpqn(){return mp[0];}}, null);
   e.setListener(new StyleEngine.Listener(){ public void onSection(String n){ secs.add(String.format("%.0f->%s",(System.nanoTime()-t0)/1e6,n)); } public void onStopped(){} }); return e; }
 public static void main(String[] a) throws Exception {
  StyFile sty=new StyFile(new FileInputStream(a[0])); int[] mp={sty.getTempo().getMpqn()}; Chords ch=new Chords(); Chords.Chord[] cs=ch.getGChords(0);
  System.out.println("tempo estilo: "+sty.getTempo().getBpm()+" bpm, resolucion "+sty.getResolution()+", compas "+sty.getBarTicks()+" ticks");
  for(String sec: new String[]{"Ending B"}) System.out.println(sec+": "+sty.getSection(sec).sizeBars()+" compases");
  // 1) corrida de exploracion: buscar un instante en que la afinacion este lejos del centro
  List<String> secs=new ArrayList<>(); t0=System.nanoTime(); StyleEngine e=mk(sty,mp,secs); e.setChord(cs[2]); e.start("Ending B"); Thread.sleep(9000); e.stopAndWait(400);
  double cutAt=-1; double prevT=0; int prevV=8192; for(double[] r: ev){ if(r[1]==14&&r[2]==13){ int v=((int)r[4]<<7)|(int)r[3]; if(Math.abs(v-8192)>3000 && cutAt<0 && r[0]>1500){ cutAt=r[0]+5; } } }
  System.out.printf("exploracion: la afinacion del bajo esta lejos del centro (<5192) a los %.0f ms%n",cutAt);
  ev.clear(); secs.clear(); t0=System.nanoTime(); e=mk(sty,mp,secs); e.setChord(cs[2]); e.start("Ending B");
  Thread.sleep((long)cutAt); double tc=(System.nanoTime()-t0)/1e6; e.requestSection("Main A"); Thread.sleep(900); e.stopAndWait(400);
  int n=0, lastBefore=-1, lastAfter=-1; int minV=99999, maxV=0;
  for(double[] r: ev){ if(r[1]==14 && r[2]==13){ int v=((int)r[4]<<7)|(int)r[3]; if(r[0]<tc){ n++; lastBefore=v; minV=Math.min(minV,v); maxV=Math.max(maxV,v);} else lastAfter=v; } }
  System.out.println("secciones: "+secs);
  System.out.printf("pitch bend del bajo (canal 13) antes de cortar el Ending: %d eventos, valores %d..%d, ultimo = %d (centro = 8192)%n",n,minV,maxV,lastBefore);
  System.out.printf("DESPUES de pasar a Main A el motor reinicia la afinacion -> ultimo valor = %d  %s%n",lastAfter, lastAfter==8192?"(centro: OK)":"(MAL)");
  int lsbOnly=((int)(((int)lastBefore)&127)); System.out.println("   (con el error anterior se habria enviado solo el LSB: "+lsbOnly+" en vez de "+lastBefore+")"); } }
