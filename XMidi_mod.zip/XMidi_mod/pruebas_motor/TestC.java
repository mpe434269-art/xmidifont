import net.duceng.xmidi.util.*;
public class TestC { public static void main(String[] a){ Chords c=new Chords();
  for(int t: new int[]{0,2,7,9}){ Chords.Chord[] g=c.getGChords16(t); StringBuilder sb=new StringBuilder("tonalidad "+Chords.TONALITIES[t]+": ");
    for(int i=0;i<g.length;i++){ sb.append(g[i].name).append(i%4==3?"  |  ":" "); } System.out.println(sb); }
  int ok=0; for(int t=0;t<12;t++){ Chords.Chord[] g=c.getGChords16(t); for(Chords.Chord x:g){ if(x!=null&&x.name!=null&&x.chords!=null) ok++; } }
  System.out.println("acordes validos (12 tonalidades x 16): "+ok+"/192"); } }
