import java.io.*; import java.nio.file.*; import net.duceng.xmidi.util.ImportCore;
public class TestImp { public static void main(String[] a) throws Exception {
  File dir=Files.createTempDirectory("imp").toFile(); File sty=new File(a[0]), sf2=new File(a[1]);
  File junk=new File(dir,"junk.sty"); Files.write(junk.toPath(), new byte[2000]);
  File txt=new File(dir,"nota.sty"); Files.write(txt.toPath(), "esto no es un estilo ni nada parecido, solo texto de relleno para pasar los 64 bytes de largo....".getBytes());
  System.out.println("sty real valido     : "+ImportCore.validate(sty,"sty"));
  System.out.println("sf2 real valido     : "+ImportCore.validate(sf2,"sf2"));
  System.out.println("ceros como .sty     : "+ImportCore.validate(junk,"sty"));
  System.out.println("texto como .sty     : "+ImportCore.validate(txt,"sty"));
  System.out.println("sty como soundfont  : "+ImportCore.validate(sty,"sf2"));
  System.out.println("sf2 como estilo     : "+ImportCore.validate(sf2,"sty"));
  File dest=new File(dir,"sty"); dest.mkdirs();
  for(int i=0;i<3;i++){ File d=ImportCore.uniqueFile(dest,"RICHY,CAMINO.STY"); try(InputStream in=new FileInputStream(sty)){ ImportCore.copy(in,d);} System.out.println("importacion "+(i+1)+" -> "+d.getName()+"  ("+d.length()+" bytes)"); }
  System.out.println("nombre raro         : '"+ImportCore.sanitizeName("../..//mi:estilo*?.sty")+"'   vacio: '"+ImportCore.sanitizeName("...")+"'   null: '"+ImportCore.sanitizeName(null)+"'");
  System.out.println("extensiones         : STY->"+ImportCore.hasExtension("A.STY",new String[]{"sty"})+"  Sty->"+ImportCore.hasExtension("a.Sty",new String[]{"sty"})+"  .mid->"+ImportCore.hasExtension("a.mid",new String[]{"sty"})+"  sf2->"+ImportCore.hasExtension("Gran Piano.sf2",new String[]{"sf2"}));
  long t=System.nanoTime(); File big=new File(dir,"copia.sf2"); try(InputStream in=new FileInputStream(sf2)){ long n=ImportCore.copy(in,big); System.out.printf("copia soundfont de %.1f MB en %.0f ms, tamano igual: %b%n",n/1e6,(System.nanoTime()-t)/1e6,n==sf2.length()); }
  System.out.println("contenido identico  : "+Arrays.equals(Files.readAllBytes(sf2.toPath()),Files.readAllBytes(big.toPath()))); } 
  static class Arrays{ static boolean equals(byte[] x, byte[] y){ return java.util.Arrays.equals(x,y);} } }
