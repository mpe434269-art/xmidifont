import java.io.*; import java.util.*;
import net.duceng.midi.*; import net.duceng.xmidi.util.*;
public class TestK { public static void main(String[] a) throws Exception {
  StyFile sty=new StyFile(new FileInputStream(a[0])); Chords ch=new Chords(); String[] N={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
  Chords.Chord[] g=ch.getGChords(0); // C F G G7 Am Dm Em Em7
  for(int ci: new int[]{0,2}){ Chords.Chord c=g[ci]; System.out.println("=== acorde "+c.name+" (raiz pc="+c.root+")");
   for(String sn: sty.getSections().keySet()){ StySection s=sty.getSection(sn); TreeMap<Integer,int[]> pcs=new TreeMap<>();
     for(int b=0;b<s.sizeBars();b++) for(EventChannel e: s.getEvents(b,c)) if(e.getType()==9&&e.getValue2()>0){ int[] h=pcs.computeIfAbsent((int)e.getChannel(),k->new int[12]); h[e.getValue1()%12]++; }
     StringBuilder sb=new StringBuilder(String.format("%-11s",sn));
     for(int chn: new int[]{10,11,12,14,15}){ int[] h=pcs.get(chn); if(h==null) continue; int best=0; for(int i=1;i<12;i++) if(h[i]>h[best]) best=i; int tot=0; for(int x:h) tot+=x; sb.append(String.format(" ch%d:%-2s(%d notas)",chn,N[best],tot)); }
     System.out.println(sb); } } } }
