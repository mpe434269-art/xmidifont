import java.io.*; import java.util.*;
import net.duceng.midi.*; import net.duceng.xmidi.util.*;
public class TestLoad { public static void main(String[] a) throws Exception { Chords ch=new Chords(); Chords.Chord g=ch.getGChords(0)[0];
  for(String f: a){ String r; try { StyFile s=new StyFile(new FileInputStream(f)); int notes=0, ctl=0; for(StySection sec: s.getSections().values()){ for(int b=0;b<sec.sizeBars();b++) for(EventChannel e: sec.getEvents(b,g)) if(e.getType()==9&&e.getValue2()>0) notes++; }
      for(StySection sec: s.getSections().values()) { ctl+=sec.getEvents(0,g).size()>0?1:0; }
      StySection mA=s.getSection("Main A"); int melodic=0; if(mA!=null) for(int b=0;b<mA.sizeBars();b++) for(EventChannel e: mA.getEvents(b,g)) if(e.getType()==9&&e.getChannel()!=9&&e.getChannel()!=8) melodic++;
      r=String.format("OK  secciones=%d  notas(total)=%d  notas melodicas en Main A=%d  barTicks=%d", s.getSections().size(), notes, melodic, s.getBarTicks()); }
    catch(Throwable t){ r="FALLA: "+t; }
    System.out.printf("%-26s %s%n", new File(f).getName(), r); } } }
