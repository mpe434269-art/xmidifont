/*
 * Adaptador de ritmos (estilos Yamaha SFF1/SFF2) para XMidi.
 * Recibe los bytes de un .sty y devuelve los bytes corregidos:
 *  1. Los ritmos Yamaha solo usan los canales 9-16 (0-based 8..15). Los estilos
 *     convertidos de otros teclados traen instrumentos en 1-8: se mueven a un canal
 *     libre segun su funcion (bajo, acordes, pad, frase), se descartan los duplicados
 *     y los restos; asi no pisan los instrumentos del teclado.
 *  2. Canales con notas pero sin instrumento (sonaban como piano por defecto) reciben
 *     uno adecuado a su funcion y al genero (latino o no).
 *  3. Canales sin volumen reciben uno razonable segun su funcion.
 * Si algo sale mal devuelve 0 y XMidi usa el archivo original.
 */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct {
    uint32_t tick;
    uint8_t  type;      /* 0 canal, 1 meta, 2 sysex */
    uint8_t  st, d1, d2, nd;
    uint8_t  mtype;
    uint32_t len;
    uint8_t *p;
    int      sec;       /* indice de seccion */
    int      del;
} SaEv;

typedef struct { SaEv *e; int n, cap; } SaList;

static void saPush(SaList *l, SaEv ev) {
    if (l->n == l->cap) { l->cap = l->cap ? l->cap * 2 : 1024; l->e = (SaEv *)realloc(l->e, l->cap * sizeof(SaEv)); }
    l->e[l->n++] = ev;
}
static int saVlq(const uint8_t *b, size_t n, size_t *i, uint32_t *v) {
    uint32_t r = 0;
    for (int k = 0; k < 4; k++) {
        if (*i >= n) return 0;
        uint8_t c = b[(*i)++]; r = (r << 7) | (c & 0x7f);
        if (!(c & 0x80)) { *v = r; return 1; }
    }
    return 0;
}

#define SA_MAXSEC 64
typedef struct {
    char names[SA_MAXSEC][32]; int nsec;
} SaSecs;

static int saIsSetupName(const char *s) { return !strcmp(s, "SFF1") || !strcmp(s, "SFF2") || !strcmp(s, "SInt") || !strcmp(s, "(inicio)"); }

typedef struct {
    int notes;                 /* notas fuera del setup */
    int hasPC, hasVol, hasRev; /* mensajes en cualquier parte */
    int msb, lsb, pc;          /* ultimo en el setup (-1 si no hay) */
    int sumNote, groups, grpSum;
    uint32_t lastTick; int lastSec; int curGrp;
} SaCh;

static int saCmpU64(const void *a, const void *b) { uint64_t x = *(const uint64_t *)a, y = *(const uint64_t *)b; return x < y ? -1 : x > y; }

/* log opcional */
#define SALOG(...) do { if (log && logn > 0) { size_t _l = strlen(log); if (_l + 1 < logn) snprintf(log + _l, logn - _l, __VA_ARGS__); } } while (0)

static int saRole(const SaCh *c, int ch) {
    /* 0 bateria, 1 bajo, 2 acordes, 3 pad, 4 frase */
    (void)ch;
    if (c->notes == 0) return 4;
    double med = (double)c->sumNote / c->notes;
    double poly = c->groups ? (double)c->grpSum / c->groups : 1.0;
    if (med < 52 && poly < 1.6) return 1;
    if (poly >= 2.5) return 2;
    return 4;
}

int saAdapt(const uint8_t *in, size_t n, uint8_t **out, size_t *outn, char *log, size_t logn) {
    *out = NULL; *outn = 0;
    if (n < 22 || memcmp(in, "MThd", 4)) return 0;
    uint32_t hl = (in[4] << 24) | (in[5] << 16) | (in[6] << 8) | in[7];
    size_t i = 8 + hl;
    if (i + 8 > n || memcmp(in + i, "MTrk", 4)) return 0;
    uint32_t tl = (in[i + 4] << 24) | (in[i + 5] << 16) | (in[i + 6] << 8) | in[i + 7];
    size_t hdrEnd = i + 8, end = hdrEnd + tl;
    if (hdrEnd > n) return 0;

    SaList L = {0}; SaSecs S; memset(&S, 0, sizeof S);
    strcpy(S.names[0], "(inicio)"); S.nsec = 1;
    size_t lim = n; int gotEot = 0;   /* algunos estilos declaran mal la longitud de la pista */
    uint32_t t = 0; int run = 0; int cur = 0; size_t p = hdrEnd; int ok = 1;
    while (p < lim) {
        uint32_t d;
        if (!saVlq(in, lim, &p, &d)) { ok = 0; break; }
        t += d;
        if (p >= lim) { ok = 0; break; }
        uint8_t s = in[p];
        SaEv ev; memset(&ev, 0, sizeof ev); ev.tick = t; ev.sec = cur;
        if (s == 0xFF) {
            if (p + 2 > lim) { ok = 0; break; }
            uint8_t mt = in[p + 1]; uint32_t l; size_t q = p + 2;
            if (!saVlq(in, lim, &q, &l) || q + l > lim) { ok = 0; break; }
            ev.type = 1; ev.mtype = mt; ev.len = l; ev.p = (uint8_t *)malloc(l ? l : 1); memcpy(ev.p, in + q, l);
            if (mt == 0x06 && S.nsec < SA_MAXSEC) {           /* marcador = seccion */
                char nm[32]; size_t k = l < 31 ? l : 31; memcpy(nm, in + q, k); nm[k] = 0;
                int found = -1; for (int z = 0; z < S.nsec; z++) if (!strcmp(S.names[z], nm)) found = z;
                if (found < 0) { found = S.nsec++; strcpy(S.names[found], nm); }
                cur = found; ev.sec = cur;
            }
            p = q + l;
            if (mt == 0x2F) { saPush(&L, ev); gotEot = 1; break; }
        } else if (s == 0xF0 || s == 0xF7) {
            uint32_t l; size_t q = p + 1;
            if (!saVlq(in, lim, &q, &l) || q + l > lim) { ok = 0; break; }
            ev.type = 2; ev.st = s; ev.len = l; ev.p = (uint8_t *)malloc(l ? l : 1); memcpy(ev.p, in + q, l);
            p = q + l;
        } else {
            if (s & 0x80) { run = s; p++; }
            if (!run) { ok = 0; break; }
            ev.type = 0; ev.st = (uint8_t)run;
            int hi = run & 0xF0; ev.nd = (hi == 0xC0 || hi == 0xD0) ? 1 : 2;
            if (p + ev.nd > lim) { ok = 0; break; }
            ev.d1 = in[p]; if (ev.nd == 2) ev.d2 = in[p + 1];
            p += ev.nd;
        }
        saPush(&L, ev);
    }
    if (gotEot) end = p;
    if (!ok || !gotEot || L.n == 0) { for (int k = 0; k < L.n; k++) free(L.e[k].p); free(L.e); return 0; }

    /* fin del setup = primer marcador que no es de setup */
    int setupEnd = L.n;
    for (int k = 0; k < L.n; k++)
        if (L.e[k].type == 1 && L.e[k].mtype == 0x06) {
            char nm[32]; size_t m = L.e[k].len < 31 ? L.e[k].len : 31; memcpy(nm, L.e[k].p, m); nm[m] = 0;
            if (!saIsSetupName(nm)) { setupEnd = k; break; }
        }

    /* estadisticas por canal */
    SaCh C[16]; memset(C, 0, sizeof C);
    for (int c = 0; c < 16; c++) { C[c].msb = C[c].lsb = C[c].pc = -1; C[c].lastSec = -1; }
    for (int k = 0; k < L.n; k++) {
        SaEv *e = &L.e[k]; if (e->type != 0) continue;
        int hi = e->st & 0xF0, ch = e->st & 0x0F; SaCh *c = &C[ch];
        if (hi == 0xB0) {
            if (e->d1 == 0 && k < setupEnd) c->msb = e->d2;
            else if (e->d1 == 32 && k < setupEnd) c->lsb = e->d2;
            else if (e->d1 == 7) c->hasVol = 1;
            else if (e->d1 == 91) c->hasRev = 1;
        } else if (hi == 0xC0) { c->hasPC = 1; if (k < setupEnd) c->pc = e->d1; }
        else if (hi == 0x90 && e->d2 > 0 && k >= setupEnd) {
            c->notes++; c->sumNote += e->d1;
            if (c->lastSec == e->sec && c->lastTick == e->tick) { c->curGrp++; }
            else { if (c->groups) c->grpSum += c->curGrp; c->groups++; c->curGrp = 1; c->lastSec = e->sec; c->lastTick = e->tick; }
        }
    }
    for (int c = 0; c < 16; c++) if (C[c].groups) C[c].grpSum += C[c].curGrp;

    int changed = 0;
    int remap[16], mergeTo[16]; for (int c = 0; c < 16; c++) { remap[c] = c; mergeTo[c] = 0; }   /* destino de cada canal; -1 = descartar */

    /* ---- 1. canales 0-7 con notas ---- */
    int busy8 = 0; for (int c = 8; c < 16; c++) if (C[c].notes) busy8++;
    int order[8], no = 0;
    for (int c = 0; c < 8; c++) if (C[c].notes) order[no++] = c;
    for (int a = 0; a < no; a++) for (int b = a + 1; b < no; b++)          /* mas notas primero */
        if (C[order[b]].notes > C[order[a]].notes) { int x = order[a]; order[a] = order[b]; order[b] = x; }
    int usedSlot[16]; for (int c = 0; c < 16; c++) usedSlot[c] = C[c].notes > 0;
    int slotPC[16], slotMSB[16];
    for (int c = 0; c < 16; c++) { slotPC[c] = C[c].pc; slotMSB[c] = C[c].msb; }
    for (int a = 0; a < no; a++) {
        int c = order[a];
        if (C[c].notes < 20 && busy8 >= 4) { remap[c] = -1; SALOG("canal %d descartado (%d notas sueltas)\n", c + 1, C[c].notes); continue; }
        /* claves de los canales 8-15 para comparar: exacta (seccion,tick,nota) y ritmica (seccion,tick) */
        int na = 0;
        uint64_t *ka = (uint64_t *)malloc(sizeof(uint64_t) * (C[c].notes + 1)), *ra = (uint64_t *)malloc(sizeof(uint64_t) * (C[c].notes + 1));
        for (int k = setupEnd; k < L.n; k++) { SaEv *e = &L.e[k]; if (e->type == 0 && (e->st & 0x0F) == c && (e->st & 0xF0) == 0x90 && e->d2 > 0) { ka[na] = ((uint64_t)e->sec << 40) | ((uint64_t)e->tick << 8) | e->d1; ra[na] = ((uint64_t)e->sec << 40) | e->tick; na++; } }
        int dup = 0, mergeInto = -1;
        for (int d = 8; d < 16 && !dup; d++) {
            if (!C[d].notes) continue;
            uint64_t *kd = (uint64_t *)malloc(sizeof(uint64_t) * C[d].notes), *rd = (uint64_t *)malloc(sizeof(uint64_t) * C[d].notes); int nd2 = 0;
            for (int k = setupEnd; k < L.n; k++) { SaEv *e = &L.e[k]; if (e->type == 0 && (e->st & 0x0F) == d && (e->st & 0xF0) == 0x90 && e->d2 > 0) { kd[nd2] = ((uint64_t)e->sec << 40) | ((uint64_t)e->tick << 8) | e->d1; rd[nd2] = ((uint64_t)e->sec << 40) | e->tick; nd2++; } }
            qsort(kd, nd2, sizeof(uint64_t), saCmpU64); qsort(rd, nd2, sizeof(uint64_t), saCmpU64);
            int hit = 0, rhit = 0;
            for (int q = 0; q < na; q++) { if (bsearch(&ka[q], kd, nd2, sizeof(uint64_t), saCmpU64)) hit++; if (bsearch(&ra[q], rd, nd2, sizeof(uint64_t), saCmpU64)) rhit++; }
            int sameVoice = (C[c].pc >= 0 && C[c].pc == C[d].pc && C[c].msb == C[d].msb);
            if (na && hit * 10 >= na * 6) { dup = 1; SALOG("canal %d descartado: copia del canal %d (%d%% coincide)\n", c + 1, d + 1, hit * 100 / na); }
            else if (na && sameVoice && rhit * 100 >= na * 85) { dup = 1; SALOG("canal %d descartado: mismo ritmo e instrumento que el canal %d\n", c + 1, d + 1); }
            else if (sameVoice && mergeInto < 0 && d != 8 && d != 9 && C[d].msb != 127 && C[d].msb != 126) mergeInto = d;
            free(kd); free(rd);
        }
        free(ka); free(ra);
        if (dup) { remap[c] = -1; continue; }
        /* canal destino libre segun la funcion */
        int drum = (C[c].msb == 127 || C[c].msb == 126);
        int role = drum ? 0 : saRole(&C[c], c);
        static const int pref[5][8] = { {8, 9, -1}, {10, 12, 11, 13, 14, 15, -1}, {11, 12, 13, 14, 15, 10, -1}, {13, 12, 11, 14, 15, 10, -1}, {14, 15, 13, 12, 11, 10, -1} };
        int tgt = -1;
        for (int z = 0; pref[role][z] >= 0; z++) { int cand = pref[role][z]; if (!usedSlot[cand]) { tgt = cand; break; } }
        if (tgt >= 0) {
            remap[c] = tgt; usedSlot[tgt] = 1; slotPC[tgt] = C[c].pc; slotMSB[tgt] = C[c].msb;
            SALOG("canal %d (%d notas, funcion %s) -> canal %d\n", c + 1, C[c].notes, role == 0 ? "bateria" : role == 1 ? "bajo" : role == 2 ? "acordes" : role == 3 ? "pad" : "frase", tgt + 1);
            continue;
        }
        /* sin canal libre: unir con otro canal que usa el mismo instrumento */
        if (mergeInto < 0 && !drum)
            for (int d = 10; d < 16; d++) if (usedSlot[d] && slotPC[d] >= 0 && slotPC[d] == C[c].pc && slotMSB[d] == C[c].msb) { mergeInto = d; break; }
        if (mergeInto >= 0) { remap[c] = mergeInto; SALOG("canal %d (%d notas) se une al canal %d (mismo instrumento)\n", c + 1, C[c].notes, mergeInto + 1); mergeTo[c] = 1; continue; }
        remap[c] = -1; SALOG("canal %d descartado (sin canal libre)\n", c + 1);
    }
    /* aplicar: borrar todo lo del canal destino (estaba sin notas) y mover/descartar los de 0-7 */
    for (int c = 0; c < 8; c++) {
        if (remap[c] >= 0 && remap[c] != c && !mergeTo[c]) {
            for (int k = 0; k < L.n; k++) { SaEv *e = &L.e[k]; if (e->type == 0 && (e->st & 0x0F) == remap[c]) e->del = 1; }
        }
    }
    int dropped = 0, moved = 0;
    for (int k = 0; k < L.n; k++) {
        SaEv *e = &L.e[k]; if (e->type != 0 || e->del) continue;
        int ch = e->st & 0x0F;
        if (ch < 8) {
            if (remap[ch] < 0 || remap[ch] == ch) { e->del = 1; dropped++; }   /* los estilos Yamaha ignoran 1-8 */
            else if (mergeTo[ch]) {
                if ((e->st & 0xF0) == 0x90 || (e->st & 0xF0) == 0x80 || (e->st & 0xF0) == 0xE0) { e->st = (uint8_t)((e->st & 0xF0) | remap[ch]); moved++; }
                else { e->del = 1; dropped++; }
            }
            else { e->st = (uint8_t)((e->st & 0xF0) | remap[ch]); moved++; }
        }
    }
    if (dropped || moved) changed = 1;

    /* recomputar estadisticas de canales 8-15 tras mover */
    SaCh D[16]; memset(D, 0, sizeof D);
    for (int c = 0; c < 16; c++) { D[c].msb = D[c].lsb = D[c].pc = -1; D[c].lastSec = -1; }
    for (int k = 0; k < L.n; k++) {
        SaEv *e = &L.e[k]; if (e->type != 0 || e->del) continue;
        int hi = e->st & 0xF0, ch = e->st & 0x0F; SaCh *c = &D[ch];
        if (hi == 0xB0) { if (e->d1 == 0 && k < setupEnd) c->msb = e->d2; else if (e->d1 == 32 && k < setupEnd) c->lsb = e->d2; else if (e->d1 == 7) c->hasVol = 1; else if (e->d1 == 91) c->hasRev = 1; }
        else if (hi == 0xC0) { c->hasPC = 1; if (k < setupEnd) c->pc = e->d1; }
        else if (hi == 0x90 && e->d2 > 0 && k >= setupEnd) {
            c->notes++; c->sumNote += e->d1;
            if (c->lastSec == e->sec && c->lastTick == e->tick) c->curGrp++;
            else { if (c->groups) c->grpSum += c->curGrp; c->groups++; c->curGrp = 1; c->lastSec = e->sec; c->lastTick = e->tick; }
        }
    }
    for (int c = 0; c < 16; c++) if (D[c].groups) D[c].grpSum += D[c].curGrp;

    /* ---- 2/3. voces y volumen que faltan ---- */
    int latin = 0, guitars = 0, drumNotes = 0, latinNotes = 0;
    for (int c = 8; c < 16; c++) if (D[c].pc >= 24 && D[c].pc <= 28 && D[c].msb != 127 && D[c].msb != 126) guitars++;
    for (int k = setupEnd; k < L.n; k++) {
        SaEv *e = &L.e[k]; if (e->type != 0 || e->del || (e->st & 0xF0) != 0x90 || e->d2 == 0) continue;
        int ch = e->st & 0x0F; if (ch != 8 && ch != 9) continue;
        drumNotes++; int nt = e->d1;
        if ((nt >= 60 && nt <= 70) || (nt >= 73 && nt <= 76) || nt == 82 || nt == 83 || nt == 85) latinNotes++;
    }
    if (guitars >= 1 || (drumNotes > 40 && latinNotes * 100 >= drumNotes * 12)) latin = 1;

    /* punto de insercion: justo antes del primer marcador de seccion real */
    int ins = setupEnd; uint32_t insTick = (setupEnd < L.n) ? L.e[setupEnd].tick : L.e[L.n - 1].tick;
    SaList add = {0};
    for (int c = 8; c < 16; c++) {
        SaCh *x = &D[c]; if (!x->notes) continue;
        int drumCh = (c == 8 || c == 9) || x->msb == 127 || x->msb == 126;
        int prog = -1, msb = 0;
        if (!x->hasPC) {
            if (drumCh && (c == 8 || c == 9)) { msb = 127; prog = 0; }
            else {
                int role = saRole(x, c);
                if (c == 10 && role != 2) role = 1;
                if (role == 1) prog = 33;
                else if (role == 2) prog = (c == 11) ? (latin ? 25 : 0) : (latin ? 24 : 4);
                else prog = (c == 13) ? 48 : (c == 14 ? (latin ? 27 : 73) : (latin ? 24 : 40));
                if (c == 13) prog = 48;
            }
            SALOG("canal %d sin instrumento -> %s %d\n", c + 1, msb == 127 ? "kit" : "programa", prog);
        }
        if (prog >= 0) {
            SaEv e; memset(&e, 0, sizeof e); e.tick = insTick; e.sec = L.e[ins > 0 ? ins - 1 : 0].sec; e.type = 0; e.nd = 2;
            e.st = (uint8_t)(0xB0 | c); e.d1 = 0; e.d2 = (uint8_t)msb; saPush(&add, e);
            e.d1 = 32; e.d2 = 0; saPush(&add, e);
            e.st = (uint8_t)(0xC0 | c); e.nd = 1; e.d1 = (uint8_t)prog; e.d2 = 0; saPush(&add, e);
        }
        if (!x->hasVol) {
            int role = drumCh ? 0 : saRole(x, c);
            int vol = role == 0 ? 105 : role == 1 ? 100 : role == 2 ? 90 : role == 3 ? 72 : 85;
            if (c == 13) vol = 72;
            SaEv e; memset(&e, 0, sizeof e); e.tick = insTick; e.sec = L.e[ins > 0 ? ins - 1 : 0].sec; e.type = 0; e.nd = 2; e.st = (uint8_t)(0xB0 | c); e.d1 = 7; e.d2 = (uint8_t)vol; saPush(&add, e);
            if (!x->hasRev && !drumCh) { e.d1 = 91; e.d2 = (uint8_t)(c == 13 ? 55 : role == 1 ? 0 : 30); saPush(&add, e); }
            SALOG("canal %d sin volumen -> %d\n", c + 1, vol);
        }
    }
    if (add.n) {
        changed = 1;
        L.e = (SaEv *)realloc(L.e, (L.n + add.n) * sizeof(SaEv)); L.cap = L.n + add.n;
        memmove(L.e + ins + add.n, L.e + ins, (L.n - ins) * sizeof(SaEv));
        memcpy(L.e + ins, add.e, add.n * sizeof(SaEv)); L.n += add.n;
    }
    free(add.e);

    if (!changed) { for (int k = 0; k < L.n; k++) free(L.e[k].p); free(L.e); return 0; }

    /* ---- escribir ---- */
    size_t cap = n + 64 * 1024; uint8_t *o = (uint8_t *)malloc(cap); size_t w = 0;
    memcpy(o, in, hdrEnd); w = hdrEnd;
    uint32_t prev = 0;
    for (int k = 0; k < L.n; k++) {
        SaEv *e = &L.e[k]; if (e->del) continue;
        uint32_t tk = e->tick < prev ? prev : e->tick; uint32_t d = tk - prev; prev = tk;
        uint8_t v[5]; int vn = 0; v[vn++] = d & 0x7f; d >>= 7; while (d) { v[vn++] = (d & 0x7f) | 0x80; d >>= 7; }
        if (w + 16 + e->len > cap) { cap = (w + 16 + e->len) * 2; o = (uint8_t *)realloc(o, cap); }
        while (vn) o[w++] = v[--vn];
        if (e->type == 0) { o[w++] = e->st; o[w++] = e->d1; if (e->nd == 2) o[w++] = e->d2; }
        else if (e->type == 1) {
            o[w++] = 0xFF; o[w++] = e->mtype; uint32_t l = e->len; uint8_t lv[5]; int ln = 0; lv[ln++] = l & 0x7f; l >>= 7; while (l) { lv[ln++] = (l & 0x7f) | 0x80; l >>= 7; }
            while (ln) o[w++] = lv[--ln]; memcpy(o + w, e->p, e->len); w += e->len;
        } else {
            o[w++] = e->st; uint32_t l = e->len; uint8_t lv[5]; int ln = 0; lv[ln++] = l & 0x7f; l >>= 7; while (l) { lv[ln++] = (l & 0x7f) | 0x80; l >>= 7; }
            while (ln) o[w++] = lv[--ln]; memcpy(o + w, e->p, e->len); w += e->len;
        }
    }
    uint32_t trkLen = (uint32_t)(w - hdrEnd);
    o[hdrEnd - 4] = trkLen >> 24; o[hdrEnd - 3] = trkLen >> 16; o[hdrEnd - 2] = trkLen >> 8; o[hdrEnd - 1] = trkLen;
    size_t rest = n - end;
    if (w + rest > cap) { cap = w + rest + 16; o = (uint8_t *)realloc(o, cap); }
    memcpy(o + w, in + end, rest); w += rest;
    for (int k = 0; k < L.n; k++) free(L.e[k].p);
    free(L.e);
    *out = o; *outn = w;
    return 1;
}
