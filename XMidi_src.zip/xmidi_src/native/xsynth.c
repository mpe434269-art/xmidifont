/*
 * libxsynth - puente JNI entre XMidi (net.duceng.xsynth.XSynth) y FluidSynth 2.x.
 * Reescritura propia que reemplaza la libxsynth.so original (compilada contra
 * FluidSynth 1.0.9). Mantiene exactamente los mismos nombres JNI.
 *
 * Audio: OpenSL ES, buffer queue, PCM 16 bit estereo a 44100 Hz.
 * Respecto al original: mas buffers y mas grandes (menos cortes de audio) e
 * interpolacion de 7mo orden (mejor calidad).
 */
#include <jni.h>
#include <string.h>
#include <stdlib.h>
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <android/log.h>
#include <fluidsynth.h>

#define TAG "XSynth"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

#define SAMPLE_RATE   44100
#define FRAMES        128          /* muestras por buffer */
#define NUM_BUFFERS   4            /* buffers en cola */
#define BUF_BYTES     (FRAMES * 2 * (int)sizeof(short))

static SLObjectItf engineObj = NULL;
static SLEngineItf engineItf = NULL;
static SLObjectItf mixObj = NULL;
static SLObjectItf playerObj = NULL;
static SLPlayItf playItf = NULL;
static SLAndroidSimpleBufferQueueItf bqItf = NULL;

static fluid_settings_t *settings = NULL;
static fluid_synth_t *volatile synth = NULL;

static short buffers[NUM_BUFFERS][FRAMES * 2];
static int bufIndex = 0;

#define SYN() fluid_synth_t *s = synth; if (!s) return
#define SYNR(v) fluid_synth_t *s = synth; if (!s) return (v)

/* ---------------------------------------------------------------- audio */

static void renderAndEnqueue(void) {
    short *b = buffers[bufIndex];
    fluid_synth_t *s = synth;
    if (s) fluid_synth_write_s16(s, FRAMES, b, 0, 2, b, 1, 2);
    else memset(b, 0, BUF_BYTES);
    if (bqItf) (*bqItf)->Enqueue(bqItf, b, BUF_BYTES);
    bufIndex = (bufIndex + 1) % NUM_BUFFERS;
}

static void bqCallback(SLAndroidSimpleBufferQueueItf bq, void *ctx) {
    (void)bq; (void)ctx;
    renderAndEnqueue();
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void)vm; (void)reserved;
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_createEngine(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz;
    LOGI("createEngine");
    if (engineObj) return;
    if (slCreateEngine(&engineObj, 0, NULL, 0, NULL, NULL) != SL_RESULT_SUCCESS) {
        LOGE("slCreateEngine fallo"); engineObj = NULL; return;
    }
    (*engineObj)->Realize(engineObj, SL_BOOLEAN_FALSE);
    (*engineObj)->GetInterface(engineObj, SL_IID_ENGINE, &engineItf);
    (*engineItf)->CreateOutputMix(engineItf, &mixObj, 0, NULL, NULL);
    (*mixObj)->Realize(mixObj, SL_BOOLEAN_FALSE);
}

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_releaseEngine(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz;
    LOGI("releaseEngine");
    if (mixObj) { (*mixObj)->Destroy(mixObj); mixObj = NULL; }
    if (engineObj) { (*engineObj)->Destroy(engineObj); engineObj = NULL; engineItf = NULL; }
}

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_createMidiPlayer(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz;
    LOGI("createMidiPlayer");
    if (!engineItf || !mixObj) { LOGE("motor OpenSL no creado"); return; }
    if (synth) return;

    /* --- sintetizador --- */
    settings = new_fluid_settings();
    fluid_settings_setnum(settings, "synth.sample-rate", SAMPLE_RATE);
    synth = new_fluid_synth(settings);
    if (!synth) { LOGE("new_fluid_synth fallo"); return; }
    fluid_synth_set_interp_method(synth, -1, FLUID_INTERP_7THORDER);

    /* --- reproductor OpenSL ES --- */
    SLDataLocator_AndroidSimpleBufferQueue locBq = {
        SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, NUM_BUFFERS };
    SLDataFormat_PCM fmt = {
        SL_DATAFORMAT_PCM, 2, SL_SAMPLINGRATE_44_1, SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_PCMSAMPLEFORMAT_FIXED_16, SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT,
        SL_BYTEORDER_LITTLEENDIAN };
    SLDataSource src = { &locBq, &fmt };
    SLDataLocator_OutputMix locMix = { SL_DATALOCATOR_OUTPUTMIX, mixObj };
    SLDataSink snk = { &locMix, NULL };
    const SLInterfaceID ids[1] = { SL_IID_ANDROIDSIMPLEBUFFERQUEUE };
    const SLboolean req[1] = { SL_BOOLEAN_TRUE };

    if ((*engineItf)->CreateAudioPlayer(engineItf, &playerObj, &src, &snk, 1, ids, req)
            != SL_RESULT_SUCCESS) { LOGE("CreateAudioPlayer fallo"); playerObj = NULL; return; }
    (*playerObj)->Realize(playerObj, SL_BOOLEAN_FALSE);
    (*playerObj)->GetInterface(playerObj, SL_IID_PLAY, &playItf);
    (*playerObj)->GetInterface(playerObj, SL_IID_ANDROIDSIMPLEBUFFERQUEUE, &bqItf);
    (*bqItf)->RegisterCallback(bqItf, bqCallback, NULL);

    bufIndex = 0;
    for (int i = 0; i < NUM_BUFFERS; i++) renderAndEnqueue();   /* llenar la cola */
    (*playItf)->SetPlayState(playItf, SL_PLAYSTATE_PLAYING);
}

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_releaseMidiPlayer(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz;
    LOGI("releaseMidiPlayer");
    if (playItf) (*playItf)->SetPlayState(playItf, SL_PLAYSTATE_STOPPED);
    if (bqItf) (*bqItf)->Clear(bqItf);
    if (playerObj) { (*playerObj)->Destroy(playerObj); playerObj = NULL; playItf = NULL; bqItf = NULL; }
    fluid_synth_t *s = synth;
    synth = NULL;
    if (s) delete_fluid_synth(s);
    if (settings) { delete_fluid_settings(settings); settings = NULL; }
}

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_setPlayingMidiPlayer(JNIEnv *env, jobject thiz, jboolean playing) {
    (void)env; (void)thiz;
    if (playItf)
        (*playItf)->SetPlayState(playItf, playing ? SL_PLAYSTATE_PLAYING : SL_PLAYSTATE_PAUSED);
}

/* ---------------------------------------------------------------- MIDI */

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerNoteon(JNIEnv *env, jobject thiz, jint chan, jint key, jint vel) {
    (void)env; (void)thiz; SYN(); fluid_synth_noteon(s, chan, key, vel);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerNoteoff(JNIEnv *env, jobject thiz, jint chan, jint key) {
    (void)env; (void)thiz; SYN(); fluid_synth_noteoff(s, chan, key);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerCC(JNIEnv *env, jobject thiz, jint chan, jint num, jint val) {
    (void)env; (void)thiz; SYN(); fluid_synth_cc(s, chan, num, val);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerProgramChange(JNIEnv *env, jobject thiz, jint chan, jint prog) {
    (void)env; (void)thiz; SYN(); fluid_synth_program_change(s, chan, prog);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerPitchBend(JNIEnv *env, jobject thiz, jint chan, jint val) {
    (void)env; (void)thiz; SYN(); fluid_synth_pitch_bend(s, chan, val);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerPitchWhellSens(JNIEnv *env, jobject thiz, jint chan, jint val) {
    (void)env; (void)thiz; SYN(); fluid_synth_pitch_wheel_sens(s, chan, val);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerBankSelect(JNIEnv *env, jobject thiz, jint chan, jint bank) {
    (void)env; (void)thiz; SYN(); fluid_synth_bank_select(s, chan, bank);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSFontSelect(JNIEnv *env, jobject thiz, jint chan, jint sfid) {
    (void)env; (void)thiz; SYN(); fluid_synth_sfont_select(s, chan, sfid);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerProgramSelect(JNIEnv *env, jobject thiz,
        jint chan, jint sfid, jint bank, jint preset) {
    (void)env; (void)thiz; SYN(); fluid_synth_program_select(s, chan, sfid, bank, preset);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerProgramReset(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYN(); fluid_synth_program_reset(s);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSystemReset(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYN(); fluid_synth_system_reset(s);
}

/* ------------------------------------------------------------- consultas */

JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetCC(JNIEnv *env, jobject thiz, jint chan, jint num) {
    (void)env; (void)thiz; SYNR(0); int v = 0; fluid_synth_get_cc(s, chan, num, &v); return v;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetPitchBend(JNIEnv *env, jobject thiz, jint chan) {
    (void)env; (void)thiz; SYNR(0); int v = 0; fluid_synth_get_pitch_bend(s, chan, &v); return v;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetPitchWhellSens(JNIEnv *env, jobject thiz, jint chan) {
    (void)env; (void)thiz; SYNR(0); int v = 0; fluid_synth_get_pitch_wheel_sens(s, chan, &v); return v;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetSFont(JNIEnv *env, jobject thiz, jint chan) {
    (void)env; (void)thiz; SYNR(0); int sf = 0, b = 0, p = 0; fluid_synth_get_program(s, chan, &sf, &b, &p); return sf;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetBank(JNIEnv *env, jobject thiz, jint chan) {
    (void)env; (void)thiz; SYNR(0); int sf = 0, b = 0, p = 0; fluid_synth_get_program(s, chan, &sf, &b, &p); return b;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetPreset(JNIEnv *env, jobject thiz, jint chan) {
    (void)env; (void)thiz; SYNR(0); int sf = 0, b = 0, p = 0; fluid_synth_get_program(s, chan, &sf, &b, &p); return p;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerMidiChannels(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYNR(0); return fluid_synth_count_midi_channels(s);
}

/* ------------------------------------------------------------ soundfonts */

JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSFLoad(JNIEnv *env, jobject thiz, jstring path, jint reset) {
    (void)thiz; SYNR(-1);
    if (!path) return -1;
    const char *p = (*env)->GetStringUTFChars(env, path, NULL);
    if (!p) return -1;
    LOGI("SFLoad %s", p);
    int id = fluid_synth_sfload(s, p, reset);
    (*env)->ReleaseStringUTFChars(env, path, p);
    return id;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSFReload(JNIEnv *env, jobject thiz, jint id) {
    (void)env; (void)thiz; SYNR(-1); return fluid_synth_sfreload(s, id);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSFUnload(JNIEnv *env, jobject thiz, jint id, jint reset) {
    (void)env; (void)thiz; SYN(); fluid_synth_sfunload(s, id, reset);
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSFCount(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYNR(0); return fluid_synth_sfcount(s);
}

/* ------------------------------------------------------ efectos y ganancia */

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerReverbOn(JNIEnv *env, jobject thiz, jint on) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_reverb_on(s, on);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerReverb(JNIEnv *env, jobject thiz,
        jdouble room, jdouble damp, jdouble width, jdouble level) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_reverb(s, room, damp, width, level);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerChorusOn(JNIEnv *env, jobject thiz, jint on) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_chorus_on(s, on);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerChorus(JNIEnv *env, jobject thiz,
        jint nr, jdouble level, jdouble speed, jdouble depth, jint type) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_chorus(s, nr, level, speed, depth, type);
}
JNIEXPORT jfloat JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetGain(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYNR(0.0f); return fluid_synth_get_gain(s);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSetGain(JNIEnv *env, jobject thiz, jfloat gain) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_gain(s, gain);
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetPolyphony(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYNR(0); return fluid_synth_get_polyphony(s);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSetPolyphony(JNIEnv *env, jobject thiz, jint n) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_polyphony(s, n);
}
JNIEXPORT jfloat JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetGen(JNIEnv *env, jobject thiz, jint chan, jint param) {
    (void)env; (void)thiz; SYNR(0.0f); return fluid_synth_get_gen(s, chan, param);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSetGen(JNIEnv *env, jobject thiz, jint chan, jint param, jfloat val) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_gen(s, chan, param, val);
}
