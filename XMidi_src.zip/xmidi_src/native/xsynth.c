/*
 * libxsynth - puente JNI entre XMidi (net.duceng.xsynth.XSynth) y FluidSynth 2.x.
 * Reescritura propia que reemplaza la libxsynth.so original (compilada contra
 * FluidSynth 1.0.9). Mantiene exactamente los mismos nombres JNI.
 *
 * Audio: OpenSL ES, buffer queue, PCM 16 bit estereo a 44100 Hz.
 * Respecto al original: mas buffers y mas grandes (menos cortes de audio) e
 * interpolacion de 7mo orden (mejor calidad).
 */
#include <jni.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <pthread.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <android/log.h>
#include <fluidsynth.h>
#include "styadapt.c"

#define TAG "XSynth"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

#define SAMPLE_RATE   44100
#define FRAMES_MAX    1024
#define BUFFERS_MAX   8

/* Configuracion (se puede cambiar con el archivo xsynth.cfg, ver loadConfig) */
static int   cfgFrames   = 256;    /* muestras por buffer */
static int   cfgBuffers  = 4;      /* buffers en cola */
static int   cfgInterp   = 4;      /* interpolacion: 0 ninguna, 1 lineal, 4 cuarto orden, 7 septimo orden */
static int   cfgLimiter  = 1;      /* limitador anti-saturacion */
static float cfgMaxGain  = 10.0f;  /* tope de ganancia (practicamente sin tope; el limitador protege) */
static int   cfgS16      = 0;      /* 1 = salida directa de FluidSynth en 16 bit, sin limitador */
static int   cfgDsp      = 1;      /* 1 = efectos por instrumento (bajo y cuerdas) */
static int   cfgAdapt    = 1;      /* 1 = adaptar los ritmos (canales, instrumentos que faltan) */
static int   cfgKits     = 1;      /* 1 = elegir el kit de bateria mas parecido que exista */
static int   cfgSArt     = 1;      /* guitarra en tiempo real: legato, deslizamiento (S.Art) */
static int   cfgRR       = 1;      /* rotacion anti-ametralladora en guitarras */
static int   cfgMega     = 0;      /* MegaVoice: -1 apagado, 0 solo canales con banco Yamaha 104-108, 1 todos los canales de ritmo con guitarra */
static unsigned cfgMegaMask = 0;   /* canales extra forzados a MegaVoice (mega_mask=hex) */
static int   cfgLegatoMs = 25;     /* un acorde llega en menos de esto; mas tarde es legato */
static int   cfgBassFx   = 1;      /* compresor + ecualizador en el bajo */
static int   cfgStrFx    = 1;      /* chorus + reverb en las cuerdas */
static float cfgBassThr  = -28.0f; /* umbral del compresor (dB) */
static float cfgBassRatio= 3.0f;   /* relacion del compresor */
static float cfgBassMakeup = 6.0f; /* ganancia de compensacion (dB) */
static float cfgStrChorus= 0.45f;  /* cantidad de chorus en cuerdas (0-1) */
static float cfgStrReverb= 0.30f;  /* cantidad de reverb en cuerdas (0-1) */
#define BUF_BYTES     (cfgFrames * 2 * (int)sizeof(short))

static void resetRouting(void);

static SLObjectItf engineObj = NULL;
static SLEngineItf engineItf = NULL;
static SLObjectItf mixObj = NULL;
static SLObjectItf playerObj = NULL;
static SLPlayItf playItf = NULL;
static SLAndroidSimpleBufferQueueItf bqItf = NULL;

static fluid_settings_t *settings = NULL;
static fluid_synth_t *volatile synth = NULL;

static short buffers[BUFFERS_MAX][FRAMES_MAX * 2];
static int bufIndex = 0;

#define SYN() fluid_synth_t *s = synth; if (!s) return
#define SYNR(v) fluid_synth_t *s = synth; if (!s) return (v)

/* ---------------------------------------------------------------- audio */

static float fbuf[FRAMES_MAX * 2];
static float limGain = 1.0f;        /* ganancia actual del limitador */

/* Limitador: baja la ganancia de golpe cuando la mezcla se acerca al maximo y la
 * recupera despacio, con un recorte suave de seguridad. Evita la distorsion
 * (saturacion) cuando varios canales suman mas de 0 dBFS. */
static void limitBlock(float *x, int frames) {
    const float CEIL = 0.90f;
    float peak = 0.0f;
    for (int i = 0; i < frames * 2; i++) {
        float a = x[i] < 0 ? -x[i] : x[i];
        if (a > peak) peak = a;
    }
    float target = peak > CEIL ? CEIL / peak : 1.0f;
    float g0 = limGain, g1;
    if (target < g0) g1 = target;                    /* ataque inmediato */
    else { g1 = g0 + 0.004f; if (g1 > 1.0f) g1 = 1.0f; }  /* recuperacion lenta */
    for (int i = 0; i < frames; i++) {
        float g = g0 + (g1 - g0) * ((float)i / (float)frames);
        for (int c = 0; c < 2; c++) {
            float v = x[2 * i + c] * g;
            float a = v < 0 ? -v : v;
            if (a > 0.95f) {                          /* recorte suave de seguridad */
                float o = 0.95f + 0.05f * tanhf((a - 0.95f) / 0.05f);
                v = v < 0 ? -o : o;
            }
            x[2 * i + c] = v;
        }
    }
    limGain = g1;
}


/* ===================================================================
 *  DSP POR INSTRUMENTO
 *   Cada canal MIDI sale por su propio bus estereo (synth.audio-groups = 16).
 *   - Bajo (programas GM 32-39): ecualizador + compresor -> mas cuerpo y pegada.
 *   - Cuerdas (40-45 y 48-51):   chorus estereo + reverb suave -> amplitud y calidez.
 *   El resto de canales se mezcla igual que antes.
 * =================================================================== */
#define FX_NONE 0
#define FX_BASS 1
#define FX_STR  2
static volatile int chanFx[16];
static int bankMsb[16], bankLsb[16];          /* ultimo banco pedido por canal (-1 = ninguno) */
static int dspOn = 0;                      /* 1 = el sintetizador entrega buses separados */
#define SR_F ((float)SAMPLE_RATE)

typedef struct { float b0, b1, b2, a1, a2, z1[2], z2[2]; } Biquad;

static void bqNorm(Biquad *q, float b0, float b1, float b2, float a0, float a1, float a2) {
    q->b0 = b0 / a0; q->b1 = b1 / a0; q->b2 = b2 / a0; q->a1 = a1 / a0; q->a2 = a2 / a0;
    q->z1[0] = q->z1[1] = q->z2[0] = q->z2[1] = 0.0f;
}
static void bqHighPass(Biquad *q, float f, float Q) {
    float w = 2.0f * (float)M_PI * f / SR_F, c = cosf(w), al = sinf(w) / (2.0f * Q);
    bqNorm(q, (1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al);
}
static void bqPeak(Biquad *q, float f, float dB, float Q) {
    float A = powf(10.0f, dB / 40.0f), w = 2.0f * (float)M_PI * f / SR_F, c = cosf(w), al = sinf(w) / (2.0f * Q);
    bqNorm(q, 1 + al * A, -2 * c, 1 - al * A, 1 + al / A, -2 * c, 1 - al / A);
}
static void bqLowShelf(Biquad *q, float f, float dB) {
    float A = powf(10.0f, dB / 40.0f), w = 2.0f * (float)M_PI * f / SR_F, c = cosf(w), sn = sinf(w);
    float al = sn / 2.0f * sqrtf((A + 1 / A) * (1.0f / 1.0f - 1) + 2), t = 2 * sqrtf(A) * al;
    bqNorm(q, A * ((A + 1) - (A - 1) * c + t), 2 * A * ((A - 1) - (A + 1) * c), A * ((A + 1) - (A - 1) * c - t),
              (A + 1) + (A - 1) * c + t, -2 * ((A - 1) + (A + 1) * c), (A + 1) + (A - 1) * c - t);
}
static void bqHighShelf(Biquad *q, float f, float dB) {
    float A = powf(10.0f, dB / 40.0f), w = 2.0f * (float)M_PI * f / SR_F, c = cosf(w), sn = sinf(w);
    float al = sn / 2.0f * sqrtf((A + 1 / A) * (1.0f / 1.0f - 1) + 2), t = 2 * sqrtf(A) * al;
    bqNorm(q, A * ((A + 1) + (A - 1) * c + t), -2 * A * ((A - 1) + (A + 1) * c), A * ((A + 1) + (A - 1) * c - t),
              (A + 1) - (A - 1) * c + t, 2 * ((A - 1) - (A + 1) * c), (A + 1) - (A - 1) * c - t);
}
static inline float bqRun(Biquad *q, int ch, float x) {
    float y = q->b0 * x + q->z1[ch];
    q->z1[ch] = q->b1 * x - q->a1 * y + q->z2[ch];
    q->z2[ch] = q->b2 * x - q->a2 * y;
    return y;
}

/* --- bajo --- */
static Biquad bassEq[5];
static float bassEnv = 0.0f, bassAtt, bassRel;
static void bassInit(void) {
    bqHighPass(&bassEq[0], 32.0f, 0.707f);      /* quita retumbo */
    bqLowShelf(&bassEq[1], 100.0f, 3.0f);       /* cuerpo */
    bqPeak(&bassEq[2], 280.0f, -2.0f, 1.1f);    /* menos "lodo" */
    bqPeak(&bassEq[3], 900.0f, 3.0f, 0.9f);     /* definicion y ataque del dedo */
    bqHighShelf(&bassEq[4], 3500.0f, 1.5f);     /* presencia */
    bassAtt = expf(-1.0f / (0.006f * SR_F));    /* ataque 6 ms: deja pasar el golpe */
    bassRel = expf(-1.0f / (0.140f * SR_F));    /* liberacion 140 ms */
    bassEnv = 0.0f;
}
static void bassProcess(float *L, float *R, int n) {
    const float knee = 6.0f, ratio = cfgBassRatio < 1.0f ? 1.0f : cfgBassRatio;
    for (int i = 0; i < n; i++) {
        float l = L[i], r = R[i];
        for (int k = 0; k < 5; k++) { l = bqRun(&bassEq[k], 0, l); r = bqRun(&bassEq[k], 1, r); }
        float lv = fabsf(l) > fabsf(r) ? fabsf(l) : fabsf(r);
        bassEnv = lv > bassEnv ? bassAtt * bassEnv + (1 - bassAtt) * lv : bassRel * bassEnv + (1 - bassRel) * lv;
        float db = 20.0f * log10f(bassEnv + 1e-9f), over = db - cfgBassThr, gr;
        if (2 * over < -knee) gr = 0;
        else if (2 * fabsf(over) <= knee) gr = (1.0f / ratio - 1) * (over + knee / 2) * (over + knee / 2) / (2 * knee);
        else gr = (1.0f / ratio - 1) * over;
        float g = powf(10.0f, (gr + cfgBassMakeup) / 20.0f);
        L[i] = l * g; R[i] = r * g;
    }
}

/* --- cuerdas: chorus estereo + reverb suave (tipo Freeverb) --- */
#define CH_LEN 4096
static float chL[CH_LEN], chR[CH_LEN];
static int chPos = 0;
static float lfoPhL = 0.0f, lfoPhR = 1.5707963f;

#define NCOMB 8
#define NAP 4
static const int combTune[NCOMB] = { 1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617 };
static const int apTune[NAP] = { 556, 441, 341, 225 };
static float combBufL[NCOMB][1700], combBufR[NCOMB][1700];
static int combIdxL[NCOMB], combIdxR[NCOMB];
static float combLpL[NCOMB], combLpR[NCOMB];
static float apBufL[NAP][600], apBufR[NAP][600];
static int apIdxL[NAP], apIdxR[NAP];
#define STEREO_SPREAD 23

static void stringsInit(void) {
    memset(chL, 0, sizeof chL); memset(chR, 0, sizeof chR); chPos = 0;
    memset(combBufL, 0, sizeof combBufL); memset(combBufR, 0, sizeof combBufR);
    memset(combIdxL, 0, sizeof combIdxL); memset(combIdxR, 0, sizeof combIdxR);
    memset(combLpL, 0, sizeof combLpL); memset(combLpR, 0, sizeof combLpR);
    memset(apBufL, 0, sizeof apBufL); memset(apBufR, 0, sizeof apBufR);
    memset(apIdxL, 0, sizeof apIdxL); memset(apIdxR, 0, sizeof apIdxR);
}
static float rdLine(const float *b, int pos, float delay) {       /* lectura con interpolacion lineal */
    float rp = (float)pos - delay;
    while (rp < 0) rp += CH_LEN;
    int i0 = (int)rp; float fr = rp - (float)i0;
    int i1 = i0 + 1; if (i1 >= CH_LEN) i1 -= CH_LEN;
    return b[i0] * (1 - fr) + b[i1] * fr;
}
static void stringsProcess(float *L, float *R, float *outRevL, float *outRevR, int n) {
    const float room = 0.70f, damp = 0.45f, fb = room * 0.28f + 0.7f;
    const float baseMs = 15.0f, depthMs = 3.2f, mix = cfgStrChorus;
    const float incL = 2.0f * (float)M_PI * 0.31f / SR_F, incR = 2.0f * (float)M_PI * 0.37f / SR_F;
    for (int i = 0; i < n; i++) {
        float xl = L[i], xr = R[i];
        chL[chPos] = xl; chR[chPos] = xr;
        float dl = (baseMs + depthMs * sinf(lfoPhL)) * SR_F / 1000.0f;
        float dr = (baseMs * 1.15f + depthMs * sinf(lfoPhR)) * SR_F / 1000.0f;
        lfoPhL += incL; if (lfoPhL > 6.2831853f) lfoPhL -= 6.2831853f;
        lfoPhR += incR; if (lfoPhR > 6.2831853f) lfoPhR -= 6.2831853f;
        /* la voz retrasada de cada lado se toma del lado contrario: mas amplitud estereo */
        float wl = rdLine(chR, chPos, dl), wr = rdLine(chL, chPos, dr);
        chPos++; if (chPos >= CH_LEN) chPos = 0;
        float yl = xl + mix * wl, yr = xr + mix * wr;
        L[i] = yl; R[i] = yr;
        /* reverb */
        float in = (yl + yr) * 0.015f, oL = 0, oR = 0;
        for (int c = 0; c < NCOMB; c++) {
            float v = combBufL[c][combIdxL[c]];
            combLpL[c] = v * (1 - damp) + combLpL[c] * damp;
            combBufL[c][combIdxL[c]] = in + combLpL[c] * fb;
            if (++combIdxL[c] >= combTune[c]) combIdxL[c] = 0;
            oL += v;
            int tr = combTune[c] + STEREO_SPREAD;
            v = combBufR[c][combIdxR[c]];
            combLpR[c] = v * (1 - damp) + combLpR[c] * damp;
            combBufR[c][combIdxR[c]] = in + combLpR[c] * fb;
            if (++combIdxR[c] >= tr) combIdxR[c] = 0;
            oR += v;
        }
        for (int a = 0; a < NAP; a++) {
            float b = apBufL[a][apIdxL[a]]; float o = -oL + b;
            apBufL[a][apIdxL[a]] = oL + b * 0.5f; oL = o;
            if (++apIdxL[a] >= apTune[a]) apIdxL[a] = 0;
            b = apBufR[a][apIdxR[a]]; o = -oR + b;
            apBufR[a][apIdxR[a]] = oR + b * 0.5f; oR = o;
            if (++apIdxR[a] >= apTune[a] + STEREO_SPREAD) apIdxR[a] = 0;
        }
        outRevL[i] = oL * 3.0f * cfgStrReverb;
        outRevR[i] = oR * 3.0f * cfgStrReverb;
    }
}

static float dryBuf[32][FRAMES_MAX], fxBuf[4][FRAMES_MAX];
static float mixL[FRAMES_MAX], mixR[FRAMES_MAX], bsL[FRAMES_MAX], bsR[FRAMES_MAX],
             stL[FRAMES_MAX], stR[FRAMES_MAX], rvL[FRAMES_MAX], rvR[FRAMES_MAX];

/* Genera 'frames' muestras estereo intercaladas en out. Devuelve 0 si no se pudo. */
static int dspRender(fluid_synth_t *s, float *out, int frames) {
    float *fxp[4] = { fxBuf[0], fxBuf[1], fxBuf[2], fxBuf[3] };
    float *op[32];
    for (int i = 0; i < 32; i++) { op[i] = dryBuf[i]; memset(dryBuf[i], 0, frames * sizeof(float)); }
    for (int i = 0; i < 4; i++) memset(fxBuf[i], 0, frames * sizeof(float));
    if (fluid_synth_process(s, frames, 4, fxp, 32, op) != FLUID_OK) return 0;
    memset(mixL, 0, frames * sizeof(float)); memset(mixR, 0, frames * sizeof(float));
    memset(bsL, 0, frames * sizeof(float));  memset(bsR, 0, frames * sizeof(float));
    memset(stL, 0, frames * sizeof(float));  memset(stR, 0, frames * sizeof(float));
    int hasBass = 0, hasStr = 0;
    for (int g = 0; g < 16; g++) {
        float *l = dryBuf[2 * g], *r = dryBuf[2 * g + 1];
        int t = chanFx[g];
        float *dl = mixL, *dr = mixR;
        if (t == FX_BASS && cfgBassFx) { dl = bsL; dr = bsR; hasBass = 1; }
        else if (t == FX_STR && cfgStrFx) { dl = stL; dr = stR; hasStr = 1; }
        for (int i = 0; i < frames; i++) { dl[i] += l[i]; dr[i] += r[i]; }
    }
    if (cfgBassFx) {                                   /* se procesa siempre para dejar correr la cola */
        bassProcess(bsL, bsR, frames);
        for (int i = 0; i < frames; i++) { mixL[i] += bsL[i]; mixR[i] += bsR[i]; }
    }
    (void)hasBass; (void)hasStr;
    if (cfgStrFx) {
        stringsProcess(stL, stR, rvL, rvR, frames);
        for (int i = 0; i < frames; i++) { mixL[i] += stL[i] + rvL[i]; mixR[i] += stR[i] + rvR[i]; }
    }
    for (int i = 0; i < frames; i++) {                 /* reverb y chorus internos de FluidSynth */
        out[2 * i]     = mixL[i] + fxBuf[0][i] + fxBuf[2][i];
        out[2 * i + 1] = mixR[i] + fxBuf[1][i] + fxBuf[3][i];
    }
    return 1;
}

/* Marca el tipo de efecto de un canal segun el instrumento (programa GM). */
static void updateFx(int chan, int bank, int prog) {
    if (chan < 0 || chan >= 16) return;
    int t = FX_NONE;
    if (chan != 9 && bank != 128) {
        if (prog >= 32 && prog <= 39) t = FX_BASS;
        else if ((prog >= 40 && prog <= 45) || (prog >= 48 && prog <= 51)) t = FX_STR;
    }
    chanFx[chan] = t;
}

static void runActs(fluid_synth_t *s);
static void renderAndEnqueue(void) {
    short *b = buffers[bufIndex];
    fluid_synth_t *s = synth;
    if (s) {
        runActs(s);
        if (cfgS16) {
            fluid_synth_write_s16(s, cfgFrames, b, 0, 2, b, 1, 2);
        } else {
            if (!(dspOn && dspRender(s, fbuf, cfgFrames)))
                fluid_synth_write_float(s, cfgFrames, fbuf, 0, 2, fbuf, 1, 2);
            if (cfgLimiter) limitBlock(fbuf, cfgFrames);
            for (int i = 0; i < cfgFrames * 2; i++) {
                float v = fbuf[i] * 32767.0f;
                b[i] = (short)(v > 32767.0f ? 32767 : (v < -32768.0f ? -32768 : v));
            }
        }
    } else memset(b, 0, BUF_BYTES);
    if (bqItf) (*bqItf)->Enqueue(bqItf, b, BUF_BYTES);
    bufIndex = (bufIndex + 1) % cfgBuffers;
}

/* Lee xsynth.cfg (lineas clave=valor). Si no existe se usan los valores de fabrica.
 * Rutas: variable XSYNTH_CFG (pruebas) o sdcard/net.duceng/XMidi/xsynth.cfg */
static void loadConfig(void) {
    const char *paths[3] = { getenv("XSYNTH_CFG"),
        "/sdcard/net.duceng/XMidi/xsynth.cfg",
        "/storage/emulated/0/net.duceng/XMidi/xsynth.cfg" };
    for (int i = 0; i < 3; i++) {
        if (!paths[i]) continue;
        FILE *f = fopen(paths[i], "r");
        if (!f) continue;
        char line[128];
        while (fgets(line, sizeof line, f)) {
            if (line[0] == '#') continue;
            char *eq = strchr(line, '=');
            if (!eq) continue;
            *eq = 0; const char *k = line; const char *v = eq + 1;
            if (!strcmp(k, "frames"))   cfgFrames  = atoi(v);
            else if (!strcmp(k, "buffers")) cfgBuffers = atoi(v);
            else if (!strcmp(k, "interp"))  cfgInterp  = atoi(v);
            else if (!strcmp(k, "limiter")) cfgLimiter = atoi(v);
            else if (!strcmp(k, "s16"))     cfgS16     = atoi(v);
            else if (!strcmp(k, "maxgain")) cfgMaxGain = (float)atof(v);
            else if (!strcmp(k, "dsp"))        cfgDsp      = atoi(v);
            else if (!strcmp(k, "adapt"))      cfgAdapt    = atoi(v);
            else if (!strcmp(k, "kits"))       cfgKits     = atoi(v);
            else if (!strcmp(k, "sart"))       cfgSArt     = atoi(v);
            else if (!strcmp(k, "rr"))         cfgRR       = atoi(v);
            else if (!strcmp(k, "mega"))       cfgMega     = atoi(v);
            else if (!strcmp(k, "mega_mask"))  cfgMegaMask = (unsigned)strtoul(v, NULL, 16);
            else if (!strcmp(k, "legato_ms"))  cfgLegatoMs = atoi(v);
            else if (!strcmp(k, "bass_fx"))    cfgBassFx   = atoi(v);
            else if (!strcmp(k, "str_fx"))     cfgStrFx    = atoi(v);
            else if (!strcmp(k, "bass_thr"))   cfgBassThr  = (float)atof(v);
            else if (!strcmp(k, "bass_ratio")) cfgBassRatio= (float)atof(v);
            else if (!strcmp(k, "bass_makeup"))cfgBassMakeup=(float)atof(v);
            else if (!strcmp(k, "str_chorus")) cfgStrChorus= (float)atof(v);
            else if (!strcmp(k, "str_reverb")) cfgStrReverb= (float)atof(v);
        }
        fclose(f);
        LOGI("config leida de %s", paths[i]);
        break;
    }
    if (cfgFrames < 32) cfgFrames = 32;
    if (cfgFrames > FRAMES_MAX) cfgFrames = FRAMES_MAX;
    if (cfgBuffers < 2) cfgBuffers = 2;
    if (cfgBuffers > BUFFERS_MAX) cfgBuffers = BUFFERS_MAX;
    if (cfgMaxGain < 0.01f) cfgMaxGain = 0.01f;
    if (cfgMaxGain > 10.0f) cfgMaxGain = 10.0f;
    LOGI("frames=%d buffers=%d interp=%d limiter=%d s16=%d maxgain=%.2f",
         cfgFrames, cfgBuffers, cfgInterp, cfgLimiter, cfgS16, cfgMaxGain);
}

static void bqCallback(SLAndroidSimpleBufferQueueItf bq, void *ctx) {
    (void)bq; (void)ctx;
    renderAndEnqueue();
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void)vm; (void)reserved;
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_createEngine(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz;
    LOGI("createEngine");
    if (engineObj) return;
    if (slCreateEngine(&engineObj, 0, NULL, 0, NULL, NULL) != SL_RESULT_SUCCESS) {
        LOGE("slCreateEngine fallo"); engineObj = NULL; return;
    }
    (*engineObj)->Realize(engineObj, SL_BOOLEAN_FALSE);
    (*engineObj)->GetInterface(engineObj, SL_IID_ENGINE, &engineItf);
    (*engineItf)->CreateOutputMix(engineItf, &mixObj, 0, NULL, NULL);
    (*mixObj)->Realize(mixObj, SL_BOOLEAN_FALSE);
}

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_releaseEngine(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz;
    LOGI("releaseEngine");
    if (mixObj) { (*mixObj)->Destroy(mixObj); mixObj = NULL; }
    if (engineObj) { (*engineObj)->Destroy(engineObj); engineObj = NULL; engineItf = NULL; }
}

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_createMidiPlayer(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz;
    LOGI("createMidiPlayer");
    if (!engineItf || !mixObj) { LOGE("motor OpenSL no creado"); return; }
    if (synth) return;

    /* --- sintetizador --- */
    loadConfig();
    settings = new_fluid_settings();
    fluid_settings_setnum(settings, "synth.sample-rate", SAMPLE_RATE);
    fluid_settings_setint(settings, "synth.midi-channels", 128);  /* 16 reales + sombra de bateria + articulaciones de guitarra */
    dspOn = cfgDsp && !cfgS16;
    if (dspOn) {                                                  /* un bus estereo por canal */
        fluid_settings_setint(settings, "synth.audio-groups", 16);
        fluid_settings_setint(settings, "synth.audio-channels", 16);
        bassInit(); stringsInit();
        memset((void *)chanFx, 0, sizeof chanFx);
    }
    resetRouting();
    synth = new_fluid_synth(settings);
    if (!synth) { LOGE("new_fluid_synth fallo"); return; }
    fluid_synth_set_interp_method(synth, -1, cfgInterp);
    fluid_synth_set_gain(synth, 0.2f);

    /* --- reproductor OpenSL ES --- */
    SLDataLocator_AndroidSimpleBufferQueue locBq = {
        SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, (SLuint32)cfgBuffers };
    SLDataFormat_PCM fmt = {
        SL_DATAFORMAT_PCM, 2, SL_SAMPLINGRATE_44_1, SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_PCMSAMPLEFORMAT_FIXED_16, SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT,
        SL_BYTEORDER_LITTLEENDIAN };
    SLDataSource src = { &locBq, &fmt };
    SLDataLocator_OutputMix locMix = { SL_DATALOCATOR_OUTPUTMIX, mixObj };
    SLDataSink snk = { &locMix, NULL };
    const SLInterfaceID ids[1] = { SL_IID_ANDROIDSIMPLEBUFFERQUEUE };
    const SLboolean req[1] = { SL_BOOLEAN_TRUE };

    if ((*engineItf)->CreateAudioPlayer(engineItf, &playerObj, &src, &snk, 1, ids, req)
            != SL_RESULT_SUCCESS) { LOGE("CreateAudioPlayer fallo"); playerObj = NULL; return; }
    (*playerObj)->Realize(playerObj, SL_BOOLEAN_FALSE);
    (*playerObj)->GetInterface(playerObj, SL_IID_PLAY, &playItf);
    (*playerObj)->GetInterface(playerObj, SL_IID_ANDROIDSIMPLEBUFFERQUEUE, &bqItf);
    (*bqItf)->RegisterCallback(bqItf, bqCallback, NULL);

    bufIndex = 0;
    for (int i = 0; i < cfgBuffers; i++) renderAndEnqueue();   /* llenar la cola */
    (*playItf)->SetPlayState(playItf, SL_PLAYSTATE_PLAYING);
}

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_releaseMidiPlayer(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz;
    LOGI("releaseMidiPlayer");
    if (playItf) (*playItf)->SetPlayState(playItf, SL_PLAYSTATE_STOPPED);
    if (bqItf) (*bqItf)->Clear(bqItf);
    if (playerObj) { (*playerObj)->Destroy(playerObj); playerObj = NULL; playItf = NULL; bqItf = NULL; }
    fluid_synth_t *s = synth;
    synth = NULL;
    if (s) delete_fluid_synth(s);
    resetRouting();
    if (settings) { delete_fluid_settings(settings); settings = NULL; }
}

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_setPlayingMidiPlayer(JNIEnv *env, jobject thiz, jboolean playing) {
    (void)env; (void)thiz;
    if (playItf)
        (*playItf)->SetPlayState(playItf, playing ? SL_PLAYSTATE_PLAYING : SL_PLAYSTATE_PAUSED);
}


/* ===================================================================
 *  DOS SOUNDFONTS: el principal manda; el secundario solo COMPLETA.
 *   - Instrumentos: si el principal no tiene el instrumento (banco/programa),
 *     se usa el del secundario.
 *   - Baterias: si el kit del principal no tiene una nota (p. ej. bongos,
 *     timbales por encima de C4), esa nota suena con el kit del secundario.
 *     Para eso cada canal de bateria tiene un canal "sombra" (canal+16).
 * =================================================================== */
#define MAX_SF   32
#define MAX_KITS 64
#define NCH      16

typedef struct { int prog; uint8_t keys[16]; } Kit;
typedef struct {
    int used, id, parsed, nkits;
    char path[512], base[256];
    Kit kits[MAX_KITS];
} SfReg;

static SfReg sfreg[MAX_SF];
static char fbName[256] = "";              /* nombre del soundfont secundario */
static int  userSf[NCH];                   /* soundfont elegido por canal (por XMidi) */
static int  overridden[NCH];               /* el canal esta usando el secundario */
static struct { int valid, sf, prog; } shadow[NCH];
static unsigned char shadowOn[NCH][128];   /* nota sonando en el canal sombra */
static pthread_mutex_t routeLock = PTHREAD_MUTEX_INITIALIZER;

static SfReg *findSf(int id) {
    for (int i = 0; i < MAX_SF; i++) if (sfreg[i].used && sfreg[i].id == id) return &sfreg[i];
    return NULL;
}
static void registerSf(int id, const char *path) {
    SfReg *r = findSf(id);
    if (!r) for (int i = 0; i < MAX_SF; i++) if (!sfreg[i].used) { r = &sfreg[i]; break; }
    if (!r) return;
    memset(r, 0, sizeof *r);
    r->used = 1; r->id = id;
    strncpy(r->path, path, sizeof r->path - 1);
    const char *b = strrchr(path, '/');
    strncpy(r->base, b ? b + 1 : path, sizeof r->base - 1);
}
static int fbId(void) {                    /* id del secundario o -1 */
    if (!fbName[0]) return -1;
    for (int i = 0; i < MAX_SF; i++)
        if (sfreg[i].used && !strcmp(sfreg[i].base, fbName)) return sfreg[i].id;
    return -1;
}
static int presetExists(int sfid, int bank, int prog) {
    fluid_synth_t *s = synth; if (!s) return 0;
    fluid_sfont_t *sf = fluid_synth_get_sfont_by_id(s, sfid);
    return sf && fluid_sfont_get_preset(sf, bank, prog) != NULL;
}

/* --- lectura de las tablas de presets del .sf2 para saber que notas cubre cada kit --- */
static uint32_t rd32(const uint8_t *p) { return p[0] | p[1] << 8 | p[2] << 16 | (uint32_t)p[3] << 24; }
static uint16_t rd16(const uint8_t *p) { return (uint16_t)(p[0] | p[1] << 8); }

static void markRange(uint8_t *keys, int lo, int hi) {
    if (lo < 0) lo = 0;
    if (hi > 127) hi = 127;
    for (int k = lo; k <= hi; k++) keys[k >> 3] |= (uint8_t)(1 << (k & 7));
}

static void parseKits(SfReg *r) {
    r->parsed = 1; r->nkits = 0;
    FILE *f = fopen(r->path, "rb");
    if (!f) return;
    uint8_t h[12];
    if (fread(h, 1, 12, f) != 12 || memcmp(h, "RIFF", 4) || memcmp(h + 8, "sfbk", 4)) { fclose(f); return; }
    uint8_t *phdr = 0, *pbag = 0, *pgen = 0, *inst = 0, *ibag = 0, *igen = 0;
    uint32_t nphdr = 0, npbag = 0, npgen = 0, ninst = 0, nibag = 0, nigen = 0;
    uint8_t ch[8];
    while (fread(ch, 1, 8, f) == 8) {
        uint32_t sz = rd32(ch + 4);
        if (!memcmp(ch, "LIST", 4)) {
            uint8_t t[4];
            if (fread(t, 1, 4, f) != 4) break;
            if (!memcmp(t, "pdta", 4)) {
                int64_t left = (int64_t)sz - 4;
                while (left >= 8) {
                    uint8_t sc[8];
                    if (fread(sc, 1, 8, f) != 8) break;
                    uint32_t ssz = rd32(sc + 4);
                    left -= 8 + (int64_t)ssz + (ssz & 1);
                    uint8_t **dst = NULL; uint32_t *cnt = NULL; uint32_t esz = 0;
                    if (!memcmp(sc, "phdr", 4)) { dst = &phdr; cnt = &nphdr; esz = 38; }
                    else if (!memcmp(sc, "pbag", 4)) { dst = &pbag; cnt = &npbag; esz = 4; }
                    else if (!memcmp(sc, "pgen", 4)) { dst = &pgen; cnt = &npgen; esz = 4; }
                    else if (!memcmp(sc, "inst", 4)) { dst = &inst; cnt = &ninst; esz = 22; }
                    else if (!memcmp(sc, "ibag", 4)) { dst = &ibag; cnt = &nibag; esz = 4; }
                    else if (!memcmp(sc, "igen", 4)) { dst = &igen; cnt = &nigen; esz = 4; }
                    if (dst && ssz < (64u << 20)) {
                        *dst = (uint8_t *)malloc(ssz ? ssz : 1);
                        if (!*dst || fread(*dst, 1, ssz, f) != ssz) { fclose(f); goto done; }
                        *cnt = ssz / esz;
                        if (ssz & 1) fseek(f, 1, SEEK_CUR);
                    } else fseek(f, (long)ssz + (ssz & 1), SEEK_CUR);
                }
                break;
            }
            fseek(f, (long)(sz - 4) + (sz & 1), SEEK_CUR);   /* INFO, sdta: saltar */
        } else fseek(f, (long)sz + (sz & 1), SEEK_CUR);
    }
    fclose(f);
    if (!phdr || !pbag || !pgen || !inst || !ibag || !igen || nphdr < 2) goto done;

    for (uint32_t i = 0; i + 1 < nphdr && r->nkits < MAX_KITS; i++) {
        if (rd16(phdr + i * 38 + 22) != 128) continue;            /* solo kits de bateria */
        int prog = rd16(phdr + i * 38 + 20);
        uint32_t zb = rd16(phdr + i * 38 + 24), ze = rd16(phdr + (i + 1) * 38 + 24);
        Kit *kit = &r->kits[r->nkits]; memset(kit, 0, sizeof *kit); kit->prog = prog;
        int gLo = 0, gHi = 127;                                   /* zona global del preset */
        for (uint32_t z = zb; z < ze && z + 1 < npbag; z++) {
            uint32_t g0 = rd16(pbag + z * 4), g1 = rd16(pbag + (z + 1) * 4);
            int lo = -1, hi = -1, instr = -1;
            for (uint32_t g = g0; g < g1 && g < npgen; g++) {
                int op = rd16(pgen + g * 4);
                if (op == 43) { lo = pgen[g * 4 + 2]; hi = pgen[g * 4 + 3]; }
                else if (op == 41) instr = rd16(pgen + g * 4 + 2);
            }
            if (instr < 0) { if (z == zb && lo >= 0) { gLo = lo; gHi = hi; } continue; }
            if (lo < 0) { lo = gLo; hi = gHi; }
            if ((uint32_t)instr + 1 >= ninst) continue;
            uint32_t ib = rd16(inst + (uint32_t)instr * 22 + 20), ie = rd16(inst + ((uint32_t)instr + 1) * 22 + 20);
            int iLo = 0, iHi = 127;                               /* zona global del instrumento */
            for (uint32_t zz = ib; zz < ie && zz + 1 < nibag; zz++) {
                uint32_t h0 = rd16(ibag + zz * 4), h1 = rd16(ibag + (zz + 1) * 4);
                int klo = -1, khi = -1, sample = 0;
                for (uint32_t g = h0; g < h1 && g < nigen; g++) {
                    int op = rd16(igen + g * 4);
                    if (op == 43) { klo = igen[g * 4 + 2]; khi = igen[g * 4 + 3]; }
                    else if (op == 53) sample = 1;
                }
                if (!sample) { if (zz == ib && klo >= 0) { iLo = klo; iHi = khi; } continue; }
                if (klo < 0) { klo = iLo; khi = iHi; }
                int a = lo > klo ? lo : klo, b = hi < khi ? hi : khi;
                if (a <= b) markRange(kit->keys, a, b);
            }
        }
        r->nkits++;
    }
done:
    free(phdr); free(pbag); free(pgen); free(inst); free(ibag); free(igen);
}

/* 1 si el kit (prog) del soundfont sfid tiene sonido para esa nota. Ante la duda, 1. */
static int kitHas(int sfid, int prog, int key) {
    SfReg *r = findSf(sfid);
    if (!r) return 1;
    if (!r->parsed) parseKits(r);
    for (int i = 0; i < r->nkits; i++)
        if (r->kits[i].prog == prog) return (r->kits[i].keys[key >> 3] >> (key & 7)) & 1;
    return 1;
}

/* Elige el soundfont y banco con que reproducir (bank,prog) en un canal cuyo soundfont
 * elegido es cur. Con secundario activo la eleccion es siempre explicita.
 * Devuelve -1 = comportamiento normal de FluidSynth. */
static int pickSf(int chan, int cur, int bank, int prog, int *outBank) {
    (void)chan;
    int fb = fbId();
    *outBank = bank;
    if (fb < 0 || cur < 0) return -1;
    if (presetExists(cur, bank, prog)) return cur;
    if (bank != 128 && presetExists(cur, 0, prog)) { *outBank = 0; return cur; }
    if (cur == fb) return -1;
    if (presetExists(fb, bank, prog)) return fb;                       /* completa con el secundario */
    if (bank != 128 && presetExists(fb, 0, prog)) { *outBank = 0; return fb; }
    return -1;
}

static void resetArt(void);
static void resetRouting(void) {
    resetArt();
    for (int i = 0; i < 16; i++) { bankMsb[i] = -1; bankLsb[i] = -1; }
    memset(overridden, 0, sizeof overridden);
    memset(shadow, 0, sizeof shadow);
    memset(shadowOn, 0, sizeof shadowOn);
    for (int i = 0; i < NCH; i++) userSf[i] = -1;
    memset(sfreg, 0, sizeof sfreg);
}


/* ---- kits de bateria: de los numeros de Yamaha (XG/PSR/Tyros) al kit mas parecido disponible ---- */
static int kitCandidates(int pc, int msb, int *o) {
    int n = 0;
    o[n++] = pc;                                   /* primero, el numero exacto (soundfonts de Yamaha) */
    if (msb == 127 && pc < 64) {                   /* familias de kits XG/GS: 8 Room, 16 Power, 24 Electro, 25 808, 32 Jazz, 40 Brush, 48 Orquesta */
        int base = pc & ~7;
        if (pc >= 25 && pc <= 31) base = 25;
        if (base != pc) o[n++] = base;
        if (base == 25) o[n++] = 24;
    }
    if (o[n - 1] != 0) o[n++] = 0;                 /* la bateria estandar siempre sirve (kits especiales, latinos...) */
    return n;
}

/* Si el canal pide una bateria (banco 127/126 o canal 10), elige el mejor kit que exista.
 * Devuelve 1 si ya selecciono el programa. */
static int resolveKit(fluid_synth_t *s, int chan, int pc, int cur) {
    if (!cfgKits || chan < 0 || chan >= NCH) return 0;
    int msb = bankMsb[chan];
    int isKit = (msb == 127 || msb == 126 || msb == 125 || chan == 9);
    if (!isKit) return 0;
    int fb = fbId();
    int sfs[2] = { cur, fb };
    int cand[8]; int nc = kitCandidates(pc, msb, cand);
    for (int a = 0; a < 2; a++) {
        int sf = sfs[a];
        if (sf < 0 || (a == 1 && sf == cur)) continue;
        for (int i = 0; i < nc; i++)
            if (presetExists(sf, 128, cand[i])) {
                fluid_synth_program_select(s, chan, sf, 128, cand[i]);
                overridden[chan] = (sf != cur);
                return 1;
            }
    }
    return 0;
}


/* Cobertura de una nota en el kit pedido por un ritmo, mirando los soundfonts cargados. */
static int xsCovered(int kitPc, int msb, int note) {
    if (!synth) return 1;
    int primary = -1;
    for (int i = 0; i < NCH && primary < 0; i++) if (userSf[i] >= 0 && userSf[i] != fbId()) primary = userSf[i];
    int sfs[2] = { primary, fbId() };
    int cand[8]; int nc = kitCandidates(kitPc, msb, cand);
    int any = 0, has = 0;
    for (int a = 0; a < 2; a++) {
        int sf = sfs[a]; if (sf < 0 || (a == 1 && sf == sfs[0])) continue;
        for (int i = 0; i < nc; i++)
            if (presetExists(sf, 128, cand[i])) { any = 1; if (kitHas(sf, cand[i], note)) has = 1; break; }
    }
    return any ? has : 1;                      /* sin informacion = no tocar */
}

static void invalidateShadow(int chan) { if (chan >= 0 && chan < NCH) shadow[chan].valid = 0; }

static int ensureShadow(fluid_synth_t *s, int chan, int prog) {
    int fb = fbId();
    if (fb < 0) return 0;
    int p = prog;
    if (!presetExists(fb, 128, p)) { p = 0; if (!presetExists(fb, 128, 0)) return 0; }
    if (shadow[chan].valid && shadow[chan].sf == fb && shadow[chan].prog == p) return 1;
    int sc = chan + NCH;
    if (fluid_synth_program_select(s, sc, fb, 128, p) != FLUID_OK) return 0;
    static const int ccs[] = { 1, 7, 10, 11, 71, 72, 73, 74, 91, 93 };
    for (unsigned i = 0; i < sizeof ccs / sizeof ccs[0]; i++) {
        int v = 0;
        if (fluid_synth_get_cc(s, chan, ccs[i], &v) == FLUID_OK) fluid_synth_cc(s, sc, ccs[i], v);
    }
    for (int g = 0; g < 60; g++) {                    /* ajustes por canal (volumen, etc.) */
        float v = fluid_synth_get_gen(s, chan, g);
        if (v != 0.0f) fluid_synth_set_gen(s, sc, g, v);
    }
    int pb = 0; if (fluid_synth_get_pitch_bend(s, chan, &pb) == FLUID_OK) fluid_synth_pitch_bend(s, sc, pb);
    shadow[chan].valid = 1; shadow[chan].sf = fb; shadow[chan].prog = p;
    return 1;
}


/* ===================================================================
 *  GUITARRA REALISTA
 *   - S.Art en tiempo real (canales 1-8, voces de guitarra): legato (martillo/tirada),
 *     deslizamiento (pitch bend automatico) y rotacion anti-ametralladora.
 *   - MegaVoice (canales de ritmo con voces de banco Yamaha 104-108): la velocidad elige la
 *     articulacion: abierta, apagada (palm mute), rasgueo/slap, nota muerta, deslizamiento, efectos.
 *  Cada articulacion suena en un canal auxiliar con la misma voz y ajustes distintos
 *  (filtro, ataque, caida), porque sin muestras propias de MegaVoice se emula con sintesis.
 * =================================================================== */
#define ART_MUTE   0
#define ART_SLAP   1
#define ART_DEAD   2
#define ART_SLIDE  3
#define ART_LEGATO 4
#define ART_FX     5
#define ART_N      6
#define ART_BASE(k) (NCH * (2 + (k)))

static unsigned megaBank = 0;                 /* canales cuyo banco es MegaVoice / S.Art de Yamaha */
static int curProg[NCH];
static struct { int valid, sf, bank, prog; } art[NCH][ART_N];
static unsigned char artOn[NCH][128];         /* 0 = normal, k+1 = suena en el auxiliar k */
typedef struct { int last, held, lastKey, rr; int64_t lastOnMs, lastKeyMs; } SArt;
static SArt sart[NCH];

static void resetArt(void) {
    memset(art, 0, sizeof art); memset(artOn, 0, sizeof artOn); memset(sart, 0, sizeof sart);
    for (int i = 0; i < NCH; i++) { curProg[i] = -1; sart[i].last = -1; sart[i].lastKey = -1; }
    megaBank = 0;
}
static int64_t nowMs(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return (int64_t)t.tv_sec * 1000 + t.tv_nsec / 1000000; }

/* --- acciones con tiempo (apagados cortos, deslizamientos); se ejecutan en el hilo de audio --- */
#define A_OFF  1
#define A_BEND 2
typedef struct { int used, type, chan, key, val; int64_t due; } Act;
#define MAXACT 512
static Act acts[MAXACT];
static int64_t clockSamples = 0;
static pthread_mutex_t actLock = PTHREAD_MUTEX_INITIALIZER;

static int schedAct(int type, int chan, int key, int val, int delayMs) {
    int ok = 0;
    int64_t now = __atomic_load_n(&clockSamples, __ATOMIC_RELAXED);
    pthread_mutex_lock(&actLock);
    for (int i = 0; i < MAXACT; i++)
        if (!acts[i].used) {
            acts[i].used = 1; acts[i].type = type; acts[i].chan = chan; acts[i].key = key; acts[i].val = val;
            acts[i].due = now + (int64_t)delayMs * SAMPLE_RATE / 1000;
            ok = 1;
            break;
        }
    pthread_mutex_unlock(&actLock);
    return ok;
}
static void runActs(fluid_synth_t *s) {
    int64_t now = __atomic_load_n(&clockSamples, __ATOMIC_RELAXED);
    static Act todo[MAXACT]; int n = 0;        /* solo lo usa el hilo de audio */
    if (pthread_mutex_trylock(&actLock) == 0) {          /* nunca bloquea el audio */
        for (int i = 0; i < MAXACT; i++)
            if (acts[i].used && acts[i].due <= now) { todo[n++] = acts[i]; acts[i].used = 0; }
        pthread_mutex_unlock(&actLock);
    }
    for (int i = 0; i < n; i++) {
        if (todo[i].type == A_OFF) fluid_synth_noteoff(s, todo[i].chan, todo[i].key);
        else if (todo[i].type == A_BEND) fluid_synth_pitch_bend(s, todo[i].chan, todo[i].val);
    }
    __atomic_fetch_add(&clockSamples, cfgFrames, __ATOMIC_RELAXED);
}

/* ajustes de cada articulacion respecto a la voz normal */
static float artOff(int k, int g) {
    switch (k) {
    case ART_MUTE:   if (g == GEN_FILTERFC) return -2800; if (g == GEN_FILTERQ) return 60;
                     if (g == GEN_VOLENVDECAY) return -1200; if (g == GEN_VOLENVRELEASE) return -1800; break;
    case ART_SLAP:   if (g == GEN_FILTERFC) return 1800; if (g == GEN_VOLENVDECAY) return -1500; break;
    case ART_DEAD:   if (g == GEN_FILTERFC) return -5600; if (g == GEN_VOLENVDECAY) return -2400;
                     if (g == GEN_VOLENVRELEASE) return -3000; break;
    case ART_LEGATO: if (g == GEN_VOLENVATTACK) return 5500; if (g == GEN_FILTERFC) return -500; break;
    default: break;
    }
    return 0;
}

static int isGuitar(int chan) {
    return chan >= 0 && chan < NCH && chan != 9 && curProg[chan] >= 24 && curProg[chan] <= 31
        && bankMsb[chan] != 127 && bankMsb[chan] != 126 && bankMsb[chan] != 125;
}
static int isMega(int chan) {
    if (cfgMega < 0) return 0;
    if (cfgMega == 1 && chan >= 8) return 1;
    return (((megaBank | cfgMegaMask) >> chan) & 1) != 0;
}
static void invalidateArt(int chan) { if (chan >= 0 && chan < NCH) memset(art[chan], 0, sizeof art[chan]); }

static int ensureArt(fluid_synth_t *s, int chan, int k) {
    fluid_preset_t *pr = fluid_synth_get_channel_preset(s, chan);
    if (!pr) return 0;
    fluid_sfont_t *sfo = fluid_preset_get_sfont(pr);
    int sf = sfo ? fluid_sfont_get_id(sfo) : -1, bank = fluid_preset_get_banknum(pr), prog = fluid_preset_get_num(pr);
    if (sf < 0) return 0;
    if (k == ART_FX) {                                  /* los efectos salen de un kit de bateria */
        int fb = fbId();
        if (presetExists(sf, 128, 0)) { bank = 128; prog = 0; }
        else if (fb >= 0 && presetExists(fb, 128, 0)) { sf = fb; bank = 128; prog = 0; }
        else return 0;
    }
    if (art[chan][k].valid && art[chan][k].sf == sf && art[chan][k].bank == bank && art[chan][k].prog == prog) return 1;
    int hc = ART_BASE(k) + chan;
    if (fluid_synth_program_select(s, hc, sf, bank, prog) != FLUID_OK) return 0;
    static const int ccs[] = { 1, 7, 10, 11, 64, 71, 72, 73, 74, 91, 93 };
    for (unsigned i = 0; i < sizeof ccs / sizeof ccs[0]; i++) {
        int v = 0;
        if (fluid_synth_get_cc(s, chan, ccs[i], &v) == FLUID_OK) fluid_synth_cc(s, hc, ccs[i], v);
    }
    if (k != ART_FX)
        for (int g = 0; g < 60; g++) {
            float v = fluid_synth_get_gen(s, chan, g) + artOff(k, g);
            if (v != 0.0f) fluid_synth_set_gen(s, hc, g, v);
        }
    if (k == ART_SLIDE) { fluid_synth_pitch_wheel_sens(s, hc, 8); fluid_synth_pitch_bend(s, hc, 8192); }
    else { int pb = 8192; if (fluid_synth_get_pitch_bend(s, chan, &pb) == FLUID_OK) fluid_synth_pitch_bend(s, hc, pb); }
    art[chan][k].valid = 1; art[chan][k].sf = sf; art[chan][k].bank = bank; art[chan][k].prog = prog;
    return 1;
}
static void artForwardCC(fluid_synth_t *s, int chan, int num, int val) {
    if (chan < 0 || chan >= NCH || num == 0 || num == 32) return;
    for (int k = 0; k < ART_N; k++) if (art[chan][k].valid) fluid_synth_cc(s, ART_BASE(k) + chan, num, val);
}
static void artForwardGen(fluid_synth_t *s, int chan, int param, float val) {
    if (chan < 0 || chan >= NCH) return;
    for (int k = 0; k < ART_N; k++) if (art[chan][k].valid && k != ART_FX) fluid_synth_set_gen(s, ART_BASE(k) + chan, param, val + artOff(k, param));
}
static void artForwardBend(fluid_synth_t *s, int chan, int val) {
    if (chan < 0 || chan >= NCH) return;
    for (int k = 0; k < ART_N; k++) if (art[chan][k].valid && k != ART_SLIDE) fluid_synth_pitch_bend(s, ART_BASE(k) + chan, val);
}

/* Devuelve 1 si la nota ya fue tocada por la logica de guitarra. Se llama con routeLock. */
static int artNoteOn(fluid_synth_t *s, int chan, int key, int vel) {
    if (chan < 0 || chan >= NCH || key < 0 || key > 127 || vel <= 0 || !isGuitar(chan)) return 0;
    int64_t now = nowMs(); SArt *st = &sart[chan];
    int mega = isMega(chan), k = -1, v2 = vel, bend = 0, prevOff = -1, offMs = 0;
    if (mega) {                                          /* MegaVoice: la velocidad elige la articulacion */
        if (vel <= 60) v2 = 50 + vel * 3 / 4;
        else if (vel <= 90) { k = ART_MUTE; v2 = 82 + (vel - 61) / 3; offMs = 95; }
        else if (vel <= 110) { k = ART_SLAP; v2 = 102 + (vel - 91) / 4; offMs = 220; }
        else if (vel <= 120) { k = ART_DEAD; v2 = 78; offMs = 38; }
        else if (vel <= 125) { k = ART_SLIDE; v2 = 96; bend = -2; }
        else k = ART_FX;
    } else if (cfgSArt && chan < 8 && st->held && key != st->last) {   /* S.Art: legato / slide */
        int64_t dt = now - st->lastOnMs;
        if (dt >= cfgLegatoMs && dt <= 1500) {
            int d = key - st->last, ad = d < 0 ? -d : d;
            if (ad <= 2) { k = ART_LEGATO; v2 = vel * 6 / 10; prevOff = st->last; }
            else if (ad <= 7) { k = ART_SLIDE; bend = -d; prevOff = st->last; }
        }
    }
    if (cfgRR && k != ART_FX) {                          /* anti-ametralladora: 3 variantes que rotan */
        static const int rrv[3] = { 0, -4, 3 };
        if (key == st->lastKey && now - st->lastKeyMs < 150) st->rr = (st->rr + 1) % 3; else st->rr = 0;
        v2 += rrv[st->rr];
    }
    st->lastKey = key; st->lastKeyMs = now; st->last = key; st->held = 1; st->lastOnMs = now;
    if (v2 < 1) v2 = 1; if (v2 > 127) v2 = 127;
    if (k < 0) { if (v2 == vel) return 0; fluid_synth_noteon(s, chan, key, v2); return 1; }
    if (!ensureArt(s, chan, k)) { fluid_synth_noteon(s, chan, key, v2 > 0 ? v2 : 1); return 1; }
    int hc = ART_BASE(k) + chan;
    if (prevOff >= 0) {                                  /* la nota anterior termina enseguida */
        int pk = artOn[chan][prevOff];
        { int pch = pk ? ART_BASE(pk - 1) + chan : chan; if (!schedAct(A_OFF, pch, prevOff, 0, 18)) fluid_synth_noteoff(s, pch, prevOff); }
        artOn[chan][prevOff] = 0;
    }
    if (k == ART_FX) {                                   /* golpe de madera / ruido de caja */
        int dk = vel >= 127 ? 77 : 76;
        fluid_synth_noteon(s, hc, dk, 85); if (!schedAct(A_OFF, hc, dk, 0, 180)) fluid_synth_noteoff(s, hc, dk);
        artOn[chan][key] = (unsigned char)(k + 1);
        return 1;
    }
    if (k == ART_SLIDE) {                                /* desliza desde (nota - bend) hasta la nota */
        int start = 8192 + bend * 8192 / 8; if (start < 0) start = 0; if (start > 16383) start = 16383;
        fluid_synth_pitch_bend(s, hc, start);
        fluid_synth_noteon(s, hc, key, v2);
        for (int j = 1; j <= 12; j++)
            if (!schedAct(A_BEND, hc, 0, 8192 + (start - 8192) * (12 - j) / 12, j * 6)) { fluid_synth_pitch_bend(s, hc, 8192); break; }
    } else fluid_synth_noteon(s, hc, key, v2);
    artOn[chan][key] = (unsigned char)(k + 1);
    if (offMs && !schedAct(A_OFF, hc, key, 0, offMs)) fluid_synth_noteoff(s, hc, key);
    return 1;
}

/* ---- API publica interna de los eventos (con bloqueo) ---- */
static void evNoteOn(fluid_synth_t *s, int chan, int key, int vel) {
    if (vel == 0) { fluid_synth_noteoff(s, chan, key); return; }
    pthread_mutex_lock(&routeLock);
    if (artNoteOn(s, chan, key, vel)) { pthread_mutex_unlock(&routeLock); return; }
    if (chan >= 0 && chan < NCH && key >= 0 && key < 128 && fbName[0]) {
        fluid_preset_t *pr = fluid_synth_get_channel_preset(s, chan);
        if (pr && fluid_preset_get_banknum(pr) == 128) {
            fluid_sfont_t *sf = fluid_preset_get_sfont(pr);
            int sfid = sf ? fluid_sfont_get_id(sf) : -1, fb = fbId();
            int prog = fluid_preset_get_num(pr);
            if (fb >= 0 && sfid >= 0 && sfid != fb && !kitHas(sfid, prog, key)
                    && ensureShadow(s, chan, prog)) {
                shadowOn[chan][key] = 1;
                fluid_synth_noteon(s, chan + NCH, key, vel);
                pthread_mutex_unlock(&routeLock);
                return;
            }
        }
    }
    pthread_mutex_unlock(&routeLock);
    fluid_synth_noteon(s, chan, key, vel);
}
static void evNoteOff(fluid_synth_t *s, int chan, int key) {
    if (chan >= 0 && chan < NCH && key >= 0 && key < 128) {
        pthread_mutex_lock(&routeLock);
        int k = artOn[chan][key] ? artOn[chan][key] - 1 : -1;
        if (k >= 0) artOn[chan][key] = 0;
        if (sart[chan].last == key) sart[chan].held = 0;
        int sh = shadowOn[chan][key];
        if (sh) shadowOn[chan][key] = 0;
        pthread_mutex_unlock(&routeLock);
        if (k >= 0) { if (k != ART_FX) fluid_synth_noteoff(s, ART_BASE(k) + chan, key); return; }
        if (sh) { fluid_synth_noteoff(s, chan + NCH, key); return; }
    }
    fluid_synth_noteoff(s, chan, key);
}

/* ---------------------------------------------------------------- MIDI */

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerNoteon(JNIEnv *env, jobject thiz, jint chan, jint key, jint vel) {
    (void)env; (void)thiz; SYN(); evNoteOn(s, chan, key, vel);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerNoteoff(JNIEnv *env, jobject thiz, jint chan, jint key) {
    (void)env; (void)thiz; SYN(); evNoteOff(s, chan, key);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerCC(JNIEnv *env, jobject thiz, jint chan, jint num, jint val) {
    (void)env; (void)thiz; SYN();
    if (chan >= 0 && chan < NCH) { if (num == 0) bankMsb[chan] = val; else if (num == 32) bankLsb[chan] = val; }
    fluid_synth_cc(s, chan, num, val);
    if (chan >= 0 && chan < NCH && shadow[chan].valid && num != 0 && num != 32)
        fluid_synth_cc(s, chan + NCH, num, val);
    artForwardCC(s, chan, num, val);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerProgramChange(JNIEnv *env, jobject thiz, jint chan, jint prog) {
    (void)env; (void)thiz; SYN();
    if (chan >= 0 && chan < NCH) {
        curProg[chan] = prog; invalidateArt(chan);
        if (bankMsb[chan] >= 104 && bankMsb[chan] <= 108) megaBank |= 1u << chan; else megaBank &= ~(1u << chan);
        int sf0 = -1, b0 = 0, o0 = 0;
        fluid_synth_get_program(s, chan, &sf0, &b0, &o0);
        int kitReq = (bankMsb[chan] == 127 || bankMsb[chan] == 126 || bankMsb[chan] == 125);
        updateFx(chan, kitReq ? 128 : b0, prog);
        pthread_mutex_lock(&routeLock);
        int curSf = userSf[chan] >= 0 ? userSf[chan] : sf0;
        int done = resolveKit(s, chan, prog, curSf);
        if (done) invalidateShadow(chan);
        pthread_mutex_unlock(&routeLock);
        if (done) return;
    }
    if (chan < 0 || chan >= NCH || !fbName[0]) { fluid_synth_program_change(s, chan, prog); return; }
    pthread_mutex_lock(&routeLock);
    int sf = -1, bank = 0, old = 0;
    fluid_synth_get_program(s, chan, &sf, &bank, &old);
    int cur = userSf[chan] >= 0 ? userSf[chan] : sf;
    int eb = (chan == 9) ? 128 : bank, ob = eb;
    int use = pickSf(chan, cur, eb, prog, &ob);
    if (use >= 0) { fluid_synth_program_select(s, chan, use, ob, prog); overridden[chan] = (use != cur); }
    else { fluid_synth_program_change(s, chan, prog); overridden[chan] = 0; }
    invalidateShadow(chan);
    pthread_mutex_unlock(&routeLock);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerPitchBend(JNIEnv *env, jobject thiz, jint chan, jint val) {
    (void)env; (void)thiz; SYN();
    fluid_synth_pitch_bend(s, chan, val);
    if (chan >= 0 && chan < NCH && shadow[chan].valid) fluid_synth_pitch_bend(s, chan + NCH, val);
    artForwardBend(s, chan, val);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerPitchWhellSens(JNIEnv *env, jobject thiz, jint chan, jint val) {
    (void)env; (void)thiz; SYN();
    fluid_synth_pitch_wheel_sens(s, chan, val);
    if (chan >= 0 && chan < NCH && shadow[chan].valid) fluid_synth_pitch_wheel_sens(s, chan + NCH, val);
    if (chan >= 0 && chan < NCH) for (int k = 0; k < ART_N; k++) if (art[chan][k].valid && k != ART_SLIDE) fluid_synth_pitch_wheel_sens(s, ART_BASE(k) + chan, val);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerBankSelect(JNIEnv *env, jobject thiz, jint chan, jint bank) {
    (void)env; (void)thiz; SYN();
    if (chan >= 0 && chan < NCH) bankMsb[chan] = bank;
    fluid_synth_bank_select(s, chan, bank); invalidateShadow(chan); invalidateArt(chan);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSFontSelect(JNIEnv *env, jobject thiz, jint chan, jint sfid) {
    (void)env; (void)thiz; SYN();
    if (chan >= 0 && chan < NCH) { userSf[chan] = sfid; overridden[chan] = 0; invalidateShadow(chan); invalidateArt(chan); }
    fluid_synth_sfont_select(s, chan, sfid);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerProgramSelect(JNIEnv *env, jobject thiz,
        jint chan, jint sfid, jint bank, jint preset) {
    (void)env; (void)thiz; SYN();
    updateFx(chan, bank, preset);
    if (chan >= 0 && chan < NCH) {
        curProg[chan] = preset; bankMsb[chan] = bank; invalidateArt(chan);
        if (bank >= 104 && bank <= 108) megaBank |= 1u << chan; else megaBank &= ~(1u << chan);
    }
    int use = sfid, ob = bank;
    if (chan >= 0 && chan < NCH) {
        pthread_mutex_lock(&routeLock);
        userSf[chan] = sfid;
        int pk = pickSf(chan, sfid, bank, preset, &ob);
        if (pk >= 0) use = pk; else ob = bank;
        overridden[chan] = (use != sfid);
        invalidateShadow(chan);
        pthread_mutex_unlock(&routeLock);
    }
    fluid_synth_program_select(s, chan, use, ob, preset);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerProgramReset(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYN();
    fluid_synth_program_reset(s);
    resetArt();
    memset((void *)chanFx, 0, sizeof chanFx);
    memset(overridden, 0, sizeof overridden); memset(shadow, 0, sizeof shadow);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSystemReset(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYN();
    fluid_synth_system_reset(s);
    resetArt();
    memset((void *)chanFx, 0, sizeof chanFx);
    memset(overridden, 0, sizeof overridden); memset(shadow, 0, sizeof shadow);
    memset(shadowOn, 0, sizeof shadowOn);
}

/* ------------------------------------------------------------- consultas */

JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetCC(JNIEnv *env, jobject thiz, jint chan, jint num) {
    (void)env; (void)thiz; SYNR(0); int v = 0; fluid_synth_get_cc(s, chan, num, &v); return v;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetPitchBend(JNIEnv *env, jobject thiz, jint chan) {
    (void)env; (void)thiz; SYNR(0); int v = 0; fluid_synth_get_pitch_bend(s, chan, &v); return v;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetPitchWhellSens(JNIEnv *env, jobject thiz, jint chan) {
    (void)env; (void)thiz; SYNR(0); int v = 0; fluid_synth_get_pitch_wheel_sens(s, chan, &v); return v;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetSFont(JNIEnv *env, jobject thiz, jint chan) {
    (void)env; (void)thiz; SYNR(0);
    if (chan >= 0 && chan < NCH && userSf[chan] >= 0) return userSf[chan];   /* lo que eligio el usuario */
    int sf = 0, b = 0, p = 0; fluid_synth_get_program(s, chan, &sf, &b, &p); return sf;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetBank(JNIEnv *env, jobject thiz, jint chan) {
    (void)env; (void)thiz; SYNR(0); int sf = 0, b = 0, p = 0; fluid_synth_get_program(s, chan, &sf, &b, &p); return b;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetPreset(JNIEnv *env, jobject thiz, jint chan) {
    (void)env; (void)thiz; SYNR(0); int sf = 0, b = 0, p = 0; fluid_synth_get_program(s, chan, &sf, &b, &p); return p;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerMidiChannels(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYNR(0);
    int n = fluid_synth_count_midi_channels(s);
    return n > NCH ? NCH : n;          /* los canales de sombra no se muestran */
}

/* ------------------------------------------------------------ soundfonts */

JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSFLoad(JNIEnv *env, jobject thiz, jstring path, jint reset) {
    (void)thiz; SYNR(-1);
    if (!path) return -1;
    const char *p = (*env)->GetStringUTFChars(env, path, NULL);
    if (!p) return -1;
    LOGI("SFLoad %s", p);
    int id = fluid_synth_sfload(s, p, reset);
    if (id >= 0) { pthread_mutex_lock(&routeLock); registerSf(id, p); pthread_mutex_unlock(&routeLock); }
    (*env)->ReleaseStringUTFChars(env, path, p);
    return id;
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSFReload(JNIEnv *env, jobject thiz, jint id) {
    (void)env; (void)thiz; SYNR(-1); return fluid_synth_sfreload(s, id);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSFUnload(JNIEnv *env, jobject thiz, jint id, jint reset) {
    (void)env; (void)thiz; SYN();
    pthread_mutex_lock(&routeLock);
    SfReg *r = findSf(id); if (r) memset(r, 0, sizeof *r);
    memset(shadow, 0, sizeof shadow);
    pthread_mutex_unlock(&routeLock);
    fluid_synth_sfunload(s, id, reset);
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSFCount(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYNR(0); return fluid_synth_sfcount(s);
}

/* ------------------------------------------------------ efectos y ganancia */

JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerReverbOn(JNIEnv *env, jobject thiz, jint on) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_reverb_on(s, on);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerReverb(JNIEnv *env, jobject thiz,
        jdouble room, jdouble damp, jdouble width, jdouble level) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_reverb(s, room, damp, width, level);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerChorusOn(JNIEnv *env, jobject thiz, jint on) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_chorus_on(s, on);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerChorus(JNIEnv *env, jobject thiz,
        jint nr, jdouble level, jdouble speed, jdouble depth, jint type) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_chorus(s, nr, level, speed, depth, type);
}
JNIEXPORT jfloat JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetGain(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYNR(0.0f); return fluid_synth_get_gain(s);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSetGain(JNIEnv *env, jobject thiz, jfloat gain) {
    (void)env; (void)thiz; SYN();
    if (gain > cfgMaxGain) gain = cfgMaxGain;
    fluid_synth_set_gain(s, gain);
}
JNIEXPORT jint JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetPolyphony(JNIEnv *env, jobject thiz) {
    (void)env; (void)thiz; SYNR(0); return fluid_synth_get_polyphony(s);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSetPolyphony(JNIEnv *env, jobject thiz, jint n) {
    (void)env; (void)thiz; SYN(); fluid_synth_set_polyphony(s, n);
}
JNIEXPORT jfloat JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerGetGen(JNIEnv *env, jobject thiz, jint chan, jint param) {
    (void)env; (void)thiz; SYNR(0.0f); return fluid_synth_get_gen(s, chan, param);
}
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSetGen(JNIEnv *env, jobject thiz, jint chan, jint param, jfloat val) {
    (void)env; (void)thiz; SYN();
    fluid_synth_set_gen(s, chan, param, val);
    if (chan >= 0 && chan < NCH && shadow[chan].valid) fluid_synth_set_gen(s, chan + NCH, param, val);
    artForwardGen(s, chan, param, val);
}

/* Elige el soundfont secundario (nombre de archivo, p. ej. "TimGM6mb.sf2"); "" = ninguno. */
JNIEXPORT void JNICALL
Java_net_duceng_xsynth_XSynth_midiPlayerSetFallback(JNIEnv *env, jobject thiz, jstring name) {
    (void)thiz;
    pthread_mutex_lock(&routeLock);
    fbName[0] = 0;
    if (name) {
        const char *n = (*env)->GetStringUTFChars(env, name, NULL);
        if (n) { strncpy(fbName, n, sizeof fbName - 1); fbName[sizeof fbName - 1] = 0;
                 (*env)->ReleaseStringUTFChars(env, name, n); }
    }
    memset(overridden, 0, sizeof overridden);
    memset(shadow, 0, sizeof shadow);
    LOGI("soundfont secundario: '%s'", fbName);
    pthread_mutex_unlock(&routeLock);
}

/* ------------------------------------------------------------------ ritmos */
static int cfgLoaded = 0;

/* Recibe los bytes de un .sty y devuelve los bytes adaptados, o null si no hay cambios. */
JNIEXPORT jbyteArray JNICALL
Java_net_duceng_xsynth_XSynth_adaptStyle(JNIEnv *env, jobject thiz, jbyteArray in) {
    (void)thiz;
    if (!cfgLoaded) { cfgLoaded = 1; loadConfig(); }
    if (!cfgAdapt || !in) return NULL;
    jsize n = (*env)->GetArrayLength(env, in);
    if (n < 64 || n > (32 << 20)) return NULL;
    uint8_t *buf = (uint8_t *)malloc((size_t)n);
    if (!buf) return NULL;
    (*env)->GetByteArrayRegion(env, in, 0, n, (jbyte *)buf);
    uint8_t *res = NULL; size_t rn = 0; char log[2048]; log[0] = 0;
    pthread_mutex_lock(&routeLock);
    saCovered = cfgKits ? xsCovered : NULL;
    int changed = saAdapt(buf, (size_t)n, &res, &rn, log, sizeof log);
    pthread_mutex_unlock(&routeLock);
    free(buf);
    if (!changed || !res) { free(res); return NULL; }
    LOGI("ritmo adaptado:\n%s", log);
    jbyteArray out = (*env)->NewByteArray(env, (jsize)rn);
    if (out) (*env)->SetByteArrayRegion(env, out, 0, (jsize)rn, (const jbyte *)res);
    free(res);
    return out;
}
