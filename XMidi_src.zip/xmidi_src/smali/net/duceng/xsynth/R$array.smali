.class public final Lnet/duceng/xsynth/R$array;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xsynth/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "array"
.end annotation


# static fields
.field public static final file_actions:I = 0x7f010000

.field public static final metronome_speeds:I = 0x7f010001

.field public static final preset_drums:I = 0x7f010002

.field public static final preset_groups:I = 0x7f010003

.field public static final preset_instruments:I = 0x7f010004

.field public static final preset_percussions:I = 0x7f010005


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
