.class public final Lnet/duceng/xsynth/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xsynth/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final bg_action:I = 0x7f020000

.field public static final bg_btn:I = 0x7f020001

.field public static final bg_menu:I = 0x7f020002

.field public static final border_action:I = 0x7f020003

.field public static final border_btn:I = 0x7f020004

.field public static final disabled:I = 0x7f020005

.field public static final divider:I = 0x7f020006

.field public static final focused:I = 0x7f020007

.field public static final pressed:I = 0x7f020008

.field public static final pressed_action:I = 0x7f020009

.field public static final selected:I = 0x7f02000a

.field public static final transparent:I = 0x7f02000b


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
