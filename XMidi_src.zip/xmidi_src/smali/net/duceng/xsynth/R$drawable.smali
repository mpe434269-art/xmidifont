.class public final Lnet/duceng/xsynth/R$drawable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xsynth/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static final bass:I = 0x7f030000

.field public static final bg_act:I = 0x7f030001

.field public static final bg_action:I = 0x7f030002

.field public static final bg_bline:I = 0x7f030003

.field public static final bg_btn:I = 0x7f030004

.field public static final bg_dialog:I = 0x7f030005

.field public static final bg_list:I = 0x7f030006

.field public static final bg_list_disabled:I = 0x7f030007

.field public static final bg_list_focused:I = 0x7f030008

.field public static final bg_list_pressed:I = 0x7f030009

.field public static final bg_menu:I = 0x7f03000a

.field public static final bg_spinner:I = 0x7f03000b

.field public static final btn_auto:I = 0x7f03000c

.field public static final btn_beat:I = 0x7f03000d

.field public static final btn_checkbox:I = 0x7f03000e

.field public static final btn_metronome:I = 0x7f03000f

.field public static final btn_play:I = 0x7f030010

.field public static final btn_radio:I = 0x7f030011

.field public static final btn_record:I = 0x7f030012

.field public static final btn_scroll:I = 0x7f030013

.field public static final divider_h:I = 0x7f030014

.field public static final file:I = 0x7f030015

.field public static final folder:I = 0x7f030016

.field public static final gbar:I = 0x7f030017

.field public static final gfingers:I = 0x7f030018

.field public static final goff:I = 0x7f030019

.field public static final gon:I = 0x7f03001a

.field public static final ic_about:I = 0x7f03001b

.field public static final ic_auto:I = 0x7f03001c

.field public static final ic_back:I = 0x7f03001d

.field public static final ic_beat:I = 0x7f03001e

.field public static final ic_beat_stop:I = 0x7f03001f

.field public static final ic_bg_spinner:I = 0x7f030020

.field public static final ic_bg_tline:I = 0x7f030021

.field public static final ic_check_off:I = 0x7f030022

.field public static final ic_check_off_disabled:I = 0x7f030023

.field public static final ic_check_on:I = 0x7f030024

.field public static final ic_check_on_disabled:I = 0x7f030025

.field public static final ic_drums:I = 0x7f030026

.field public static final ic_exit:I = 0x7f030027

.field public static final ic_folder:I = 0x7f030028

.field public static final ic_guitar:I = 0x7f030029

.field public static final ic_help:I = 0x7f03002a

.field public static final ic_launcher:I = 0x7f03002b

.field public static final ic_lock:I = 0x7f03002c

.field public static final ic_manual:I = 0x7f03002d

.field public static final ic_metronome:I = 0x7f03002e

.field public static final ic_midi_null:I = 0x7f03002f

.field public static final ic_more:I = 0x7f030030

.field public static final ic_paino:I = 0x7f030031

.field public static final ic_play:I = 0x7f030032

.field public static final ic_play_continue:I = 0x7f030033

.field public static final ic_play_pause:I = 0x7f030034

.field public static final ic_play_stop:I = 0x7f030035

.field public static final ic_radio_off:I = 0x7f030036

.field public static final ic_radio_off_disabled:I = 0x7f030037

.field public static final ic_radio_on:I = 0x7f030038

.field public static final ic_radio_on_disabled:I = 0x7f030039

.field public static final ic_record:I = 0x7f03003a

.field public static final ic_record_stop:I = 0x7f03003b

.field public static final ic_save:I = 0x7f03003c

.field public static final ic_score:I = 0x7f03003d

.field public static final ic_scroll:I = 0x7f03003e

.field public static final ic_search:I = 0x7f03003f

.field public static final ic_settings:I = 0x7f030040

.field public static final ic_settings_channel:I = 0x7f030041

.field public static final ic_settings_midi:I = 0x7f030042

.field public static final ic_split:I = 0x7f030043

.field public static final ic_unscroll:I = 0x7f030044

.field public static final kb_down:I = 0x7f030045

.field public static final kb_shade:I = 0x7f030046

.field public static final kb_up:I = 0x7f030047

.field public static final kw_down:I = 0x7f030048

.field public static final kw_shade:I = 0x7f030049

.field public static final kw_up:I = 0x7f03004a

.field public static final metronome:I = 0x7f03004b

.field public static final metronomeb:I = 0x7f03004c

.field public static final metronomer:I = 0x7f03004d

.field public static final num1:I = 0x7f03004e

.field public static final num12:I = 0x7f03004f

.field public static final num2:I = 0x7f030050

.field public static final num3:I = 0x7f030051

.field public static final num4:I = 0x7f030052

.field public static final num5:I = 0x7f030053

.field public static final num6:I = 0x7f030054

.field public static final num7:I = 0x7f030055

.field public static final num8:I = 0x7f030056

.field public static final num9:I = 0x7f030057

.field public static final pause:I = 0x7f030058

.field public static final play:I = 0x7f030059

.field public static final popul_border:I = 0x7f03005a

.field public static final progress_horizontal:I = 0x7f03005b

.field public static final progress_metronome:I = 0x7f03005c

.field public static final seek_thumb:I = 0x7f03005d

.field public static final seek_thumb_normal:I = 0x7f03005e

.field public static final seek_thumb_pressed:I = 0x7f03005f

.field public static final seek_thumb_selected:I = 0x7f030060

.field public static final tbg:I = 0x7f030061

.field public static final treble:I = 0x7f030062


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
