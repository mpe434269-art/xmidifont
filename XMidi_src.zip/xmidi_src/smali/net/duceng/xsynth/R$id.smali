.class public final Lnet/duceng/xsynth/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xsynth/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final about_list:I = 0x7f040000

.field public static final act_about:I = 0x7f040001

.field public static final act_beat:I = 0x7f040002

.field public static final act_drums:I = 0x7f040003

.field public static final act_exit:I = 0x7f040004

.field public static final act_guitar:I = 0x7f040005

.field public static final act_keyboard:I = 0x7f040006

.field public static final act_metronome:I = 0x7f040007

.field public static final act_play:I = 0x7f040008

.field public static final act_record:I = 0x7f040009

.field public static final act_settings:I = 0x7f04000a

.field public static final action_drums:I = 0x7f04000b

.field public static final action_guitar:I = 0x7f04000c

.field public static final action_keyboard:I = 0x7f04000d

.field public static final action_main:I = 0x7f04000e

.field public static final back:I = 0x7f04000f

.field public static final bottom:I = 0x7f040010

.field public static final btn_settings_channel:I = 0x7f040011

.field public static final btn_settings_midi:I = 0x7f040012

.field public static final chann_check:I = 0x7f040013

.field public static final chann_name:I = 0x7f040014

.field public static final chann_settings:I = 0x7f040015

.field public static final dialog_bottom:I = 0x7f040016

.field public static final dialog_icon:I = 0x7f040017

.field public static final dialog_title:I = 0x7f040018

.field public static final dialog_tools:I = 0x7f040019

.field public static final dialog_wapper:I = 0x7f04001a

.field public static final drums_auto:I = 0x7f04001b

.field public static final drums_chord0:I = 0x7f04001c

.field public static final drums_chord1:I = 0x7f04001d

.field public static final drums_chord10:I = 0x7f04001e

.field public static final drums_chord11:I = 0x7f04001f

.field public static final drums_chord12:I = 0x7f040020

.field public static final drums_chord13:I = 0x7f040021

.field public static final drums_chord14:I = 0x7f040022

.field public static final drums_chord15:I = 0x7f040023

.field public static final drums_chord2:I = 0x7f040024

.field public static final drums_chord3:I = 0x7f040025

.field public static final drums_chord4:I = 0x7f040026

.field public static final drums_chord5:I = 0x7f040027

.field public static final drums_chord6:I = 0x7f040028

.field public static final drums_chord7:I = 0x7f040029

.field public static final drums_chord8:I = 0x7f04002a

.field public static final drums_chord9:I = 0x7f04002b

.field public static final drums_divider_auto_h0:I = 0x7f04002c

.field public static final drums_divider_auto_v0:I = 0x7f04002d

.field public static final drums_divider_h0:I = 0x7f04002e

.field public static final drums_divider_v0:I = 0x7f04002f

.field public static final drums_drum0:I = 0x7f040030

.field public static final drums_drum1:I = 0x7f040031

.field public static final drums_drum10:I = 0x7f040032

.field public static final drums_drum11:I = 0x7f040033

.field public static final drums_drum12:I = 0x7f040034

.field public static final drums_drum13:I = 0x7f040035

.field public static final drums_drum14:I = 0x7f040036

.field public static final drums_drum2:I = 0x7f040037

.field public static final drums_drum3:I = 0x7f040038

.field public static final drums_drum4:I = 0x7f040039

.field public static final drums_drum5:I = 0x7f04003a

.field public static final drums_drum6:I = 0x7f04003b

.field public static final drums_drum7:I = 0x7f04003c

.field public static final drums_drum8:I = 0x7f04003d

.field public static final drums_drum9:I = 0x7f04003e

.field public static final drums_keyboard:I = 0x7f04003f

.field public static final drums_layout:I = 0x7f040040

.field public static final drums_layout_auto:I = 0x7f040041

.field public static final drums_layout_btns0:I = 0x7f040042

.field public static final drums_layout_btns1:I = 0x7f040043

.field public static final drums_layout_btns2:I = 0x7f040044

.field public static final drums_layout_btns3:I = 0x7f040045

.field public static final drums_layout_btns4:I = 0x7f040046

.field public static final drums_layout_chord0:I = 0x7f040047

.field public static final drums_layout_chord1:I = 0x7f040048

.field public static final drums_layout_chord2:I = 0x7f040049

.field public static final drums_layout_chord3:I = 0x7f04004a

.field public static final drums_layout_chords:I = 0x7f04004b

.field public static final drums_layout_keys:I = 0x7f04004c

.field public static final drums_layout_manual:I = 0x7f04004d

.field public static final drums_layout_sty0:I = 0x7f04004e

.field public static final drums_layout_sty1:I = 0x7f04004f

.field public static final drums_layout_sty2:I = 0x7f040050

.field public static final drums_layout_sty3:I = 0x7f040051

.field public static final drums_layout_sty4:I = 0x7f040052

.field public static final drums_layout_top:I = 0x7f040053

.field public static final drums_lock:I = 0x7f040054

.field public static final drums_piano:I = 0x7f040055

.field public static final drums_play:I = 0x7f040056

.field public static final drums_section0:I = 0x7f040057

.field public static final drums_section1:I = 0x7f040058

.field public static final drums_section10:I = 0x7f040059

.field public static final drums_section11:I = 0x7f04005a

.field public static final drums_section12:I = 0x7f04005b

.field public static final drums_section13:I = 0x7f04005c

.field public static final drums_section14:I = 0x7f04005d

.field public static final drums_section15:I = 0x7f04005e

.field public static final drums_section16:I = 0x7f04005f

.field public static final drums_section17:I = 0x7f040060

.field public static final drums_section18:I = 0x7f040061

.field public static final drums_section19:I = 0x7f040062

.field public static final drums_section2:I = 0x7f040063

.field public static final drums_section3:I = 0x7f040064

.field public static final drums_section4:I = 0x7f040065

.field public static final drums_section5:I = 0x7f040066

.field public static final drums_section6:I = 0x7f040067

.field public static final drums_section7:I = 0x7f040068

.field public static final drums_section8:I = 0x7f040069

.field public static final drums_section9:I = 0x7f04006a

.field public static final drums_styfile:I = 0x7f04006b

.field public static final drums_sustain:I = 0x7f04006c

.field public static final drums_tonality:I = 0x7f04006d

.field public static final explorer_drums:I = 0x7f04006e

.field public static final explorer_guitar:I = 0x7f04006f

.field public static final explorer_keyboard:I = 0x7f040070

.field public static final explorer_list:I = 0x7f040071

.field public static final explorer_metronome:I = 0x7f040072

.field public static final file_null:I = 0x7f040073

.field public static final file_settings:I = 0x7f040074

.field public static final font_check:I = 0x7f040075

.field public static final font_radio:I = 0x7f040076

.field public static final guitar_auto:I = 0x7f040077

.field public static final guitar_board:I = 0x7f040078

.field public static final guitar_chord0:I = 0x7f040079

.field public static final guitar_chord1:I = 0x7f04007a

.field public static final guitar_chord2:I = 0x7f04007b

.field public static final guitar_chord3:I = 0x7f04007c

.field public static final guitar_chord4:I = 0x7f04007d

.field public static final guitar_chord5:I = 0x7f04007e

.field public static final guitar_chord6:I = 0x7f04007f

.field public static final guitar_chord7:I = 0x7f040080

.field public static final guitar_chords0:I = 0x7f040081

.field public static final guitar_chords1:I = 0x7f040082

.field public static final guitar_divider_h0:I = 0x7f040083

.field public static final guitar_divider_v0:I = 0x7f040084

.field public static final guitar_layout:I = 0x7f040085

.field public static final guitar_preset:I = 0x7f040086

.field public static final guitar_rhythm0:I = 0x7f040087

.field public static final guitar_rhythm1:I = 0x7f040088

.field public static final guitar_rhythm2:I = 0x7f040089

.field public static final guitar_rhythms:I = 0x7f04008a

.field public static final guitar_score:I = 0x7f04008b

.field public static final guitar_tonality:I = 0x7f04008c

.field public static final keyboard_layout:I = 0x7f04008d

.field public static final keyboard_lock:I = 0x7f04008e

.field public static final keyboard_preset:I = 0x7f04008f

.field public static final keyboard_score:I = 0x7f040090

.field public static final launcher:I = 0x7f040091

.field public static final list_item_file_detail:I = 0x7f040092

.field public static final list_item_file_image:I = 0x7f040093

.field public static final list_item_file_name:I = 0x7f040094

.field public static final metronome_bk:I = 0x7f040095

.field public static final metronome_hand:I = 0x7f040096

.field public static final metronome_layout:I = 0x7f040097

.field public static final metronome_speed:I = 0x7f040098

.field public static final metronome_speed_name:I = 0x7f040099

.field public static final metronome_start_btn:I = 0x7f04009a

.field public static final metronome_tempo:I = 0x7f04009b

.field public static final more:I = 0x7f04009c

.field public static final music_score:I = 0x7f04009d

.field public static final piano_board:I = 0x7f04009e

.field public static final piano_board_fix:I = 0x7f04009f

.field public static final preset_chorus_locked:I = 0x7f0400a0

.field public static final preset_chorus_seek:I = 0x7f0400a1

.field public static final preset_chorus_value:I = 0x7f0400a2

.field public static final preset_drums:I = 0x7f0400a3

.field public static final preset_mute:I = 0x7f0400a4

.field public static final preset_pan_seek:I = 0x7f0400a5

.field public static final preset_pan_value:I = 0x7f0400a6

.field public static final preset_program:I = 0x7f0400a7

.field public static final preset_reverb_locked:I = 0x7f0400a8

.field public static final preset_reverb_seek:I = 0x7f0400a9

.field public static final preset_reverb_value:I = 0x7f0400aa

.field public static final preset_sfont:I = 0x7f0400ab

.field public static final preset_sustain_locked:I = 0x7f0400ac

.field public static final preset_sustain_seek:I = 0x7f0400ad

.field public static final preset_sustain_value:I = 0x7f0400ae

.field public static final preset_volume_seek:I = 0x7f0400af

.field public static final preset_volume_value:I = 0x7f0400b0

.field public static final settings_gain_seek:I = 0x7f0400b1

.field public static final settings_gain_value:I = 0x7f0400b2

.field public static final settings_metronome1:I = 0x7f0400b3

.field public static final settings_metronome2:I = 0x7f0400b4

.field public static final settings_metronome_seek:I = 0x7f0400b5

.field public static final settings_metronome_velocity:I = 0x7f0400b6

.field public static final settings_polyphony_seek:I = 0x7f0400b7

.field public static final settings_polyphony_value:I = 0x7f0400b8

.field public static final settings_sfonts_file:I = 0x7f0400b9

.field public static final synth_bpm_seek:I = 0x7f0400ba

.field public static final synth_bpm_value:I = 0x7f0400bb

.field public static final synth_resolution_seek:I = 0x7f0400bc

.field public static final synth_resolution_value:I = 0x7f0400bd

.field public static final synth_time_denominator:I = 0x7f0400be

.field public static final synth_time_numerator:I = 0x7f0400bf

.field public static final synth_time_value:I = 0x7f0400c0

.field public static final title:I = 0x7f0400c1

.field public static final tools:I = 0x7f0400c2

.field public static final track_channel:I = 0x7f0400c3

.field public static final track_check:I = 0x7f0400c4

.field public static final track_name:I = 0x7f0400c5

.field public static final track_num:I = 0x7f0400c6

.field public static final wapper:I = 0x7f0400c7


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
