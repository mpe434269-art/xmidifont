.class public final Lnet/duceng/xsynth/R$layout;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xsynth/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final about:I = 0x7f050000

.field public static final action_about:I = 0x7f050001

.field public static final action_bottom:I = 0x7f050002

.field public static final action_drums:I = 0x7f050003

.field public static final action_explorer:I = 0x7f050004

.field public static final action_file:I = 0x7f050005

.field public static final action_guitar:I = 0x7f050006

.field public static final action_keyboard:I = 0x7f050007

.field public static final action_settings:I = 0x7f050008

.field public static final action_top:I = 0x7f050009

.field public static final base:I = 0x7f05000a

.field public static final button:I = 0x7f05000b

.field public static final dailog_midi:I = 0x7f05000c

.field public static final dailog_preset:I = 0x7f05000d

.field public static final dialog:I = 0x7f05000e

.field public static final divider_v:I = 0x7f05000f

.field public static final drums:I = 0x7f050010

.field public static final explorer:I = 0x7f050011

.field public static final grid:I = 0x7f050012

.field public static final guitar:I = 0x7f050013

.field public static final keyboard:I = 0x7f050014

.field public static final list:I = 0x7f050015

.field public static final list_expand:I = 0x7f050016

.field public static final list_expand_item:I = 0x7f050017

.field public static final list_item:I = 0x7f050018

.field public static final list_item_1:I = 0x7f050019

.field public static final list_item_chann:I = 0x7f05001a

.field public static final list_item_file:I = 0x7f05001b

.field public static final list_item_font:I = 0x7f05001c

.field public static final list_item_rhythm:I = 0x7f05001d

.field public static final list_item_tonality:I = 0x7f05001e

.field public static final list_item_track:I = 0x7f05001f

.field public static final menu_fixed:I = 0x7f050020

.field public static final menu_more:I = 0x7f050021

.field public static final metronome:I = 0x7f050022

.field public static final settings:I = 0x7f050023


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
