.class public final Lnet/duceng/xsynth/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xsynth/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static final about:I = 0x7f060000

.field public static final app_abstract:I = 0x7f060001

.field public static final app_name:I = 0x7f060002

.field public static final cancel:I = 0x7f060003

.field public static final chord:I = 0x7f060004

.field public static final chorus:I = 0x7f060005

.field public static final contact:I = 0x7f060006

.field public static final contact_content:I = 0x7f060007

.field public static final copyright:I = 0x7f060008

.field public static final copyright_content:I = 0x7f060009

.field public static final delete:I = 0x7f06000a

.field public static final discard:I = 0x7f06000b

.field public static final drums:I = 0x7f06000c

.field public static final drums_channel:I = 0x7f06000d

.field public static final exit:I = 0x7f06000e

.field public static final fixed:I = 0x7f06000f

.field public static final guitar:I = 0x7f060010

.field public static final import_soundfont:I = 0x7f060011

.field public static final import_style:I = 0x7f060012

.field public static final instrument:I = 0x7f060013

.field public static final is_mute:I = 0x7f060014

.field public static final keyboard:I = 0x7f060015

.field public static final metronome:I = 0x7f060016

.field public static final metronome_note:I = 0x7f060017

.field public static final metronome_velocity:I = 0x7f060018

.field public static final output_gain:I = 0x7f060019

.field public static final pan:I = 0x7f06001a

.field public static final percussion:I = 0x7f06001b

.field public static final polyphony:I = 0x7f06001c

.field public static final process_init:I = 0x7f06001d

.field public static final rename:I = 0x7f06001e

.field public static final resolution:I = 0x7f06001f

.field public static final reverb:I = 0x7f060020

.field public static final rhythm:I = 0x7f060021

.field public static final save:I = 0x7f060022

.field public static final select_file:I = 0x7f060023

.field public static final settings:I = 0x7f060024

.field public static final settings_channel:I = 0x7f060025

.field public static final settings_midi:I = 0x7f060026

.field public static final settings_track:I = 0x7f060027

.field public static final sound_font:I = 0x7f060028

.field public static final sure:I = 0x7f060029

.field public static final sustain:I = 0x7f06002a

.field public static final tempo_bpm:I = 0x7f06002b

.field public static final thanks:I = 0x7f06002c

.field public static final thanks_content:I = 0x7f06002d

.field public static final time_signature:I = 0x7f06002e

.field public static final tonality:I = 0x7f06002f

.field public static final volume:I = 0x7f060030


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
