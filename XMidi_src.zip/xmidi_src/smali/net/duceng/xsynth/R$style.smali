.class public final Lnet/duceng/xsynth/R$style;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xsynth/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static final AppBaseTheme:I = 0x7f070000

.field public static final AppTheme:I = 0x7f070001

.field public static final btn_action:I = 0x7f070002

.field public static final btn_action_txt:I = 0x7f070003

.field public static final btn_default:I = 0x7f070004

.field public static final btn_drums:I = 0x7f070005

.field public static final btn_guitar:I = 0x7f070006

.field public static final btn_menu:I = 0x7f070007

.field public static final dialog:I = 0x7f070008

.field public static final divider_h:I = 0x7f070009

.field public static final divider_v:I = 0x7f07000a

.field public static final list:I = 0x7f07000b


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
