.class public final Lnet/duceng/xsynth/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xsynth/R$array;,
        Lnet/duceng/xsynth/R$color;,
        Lnet/duceng/xsynth/R$drawable;,
        Lnet/duceng/xsynth/R$id;,
        Lnet/duceng/xsynth/R$layout;,
        Lnet/duceng/xsynth/R$string;,
        Lnet/duceng/xsynth/R$style;,
        Lnet/duceng/xsynth/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
