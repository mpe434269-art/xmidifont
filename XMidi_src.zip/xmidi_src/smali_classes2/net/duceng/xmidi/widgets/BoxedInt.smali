.class Lnet/duceng/xmidi/widgets/BoxedInt;
.super Ljava/lang/Object;
.source "BoxedInt.java"


# instance fields
.field public value:I


# direct methods
.method constructor <init>()V
    .locals 0

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    return-void
.end method
