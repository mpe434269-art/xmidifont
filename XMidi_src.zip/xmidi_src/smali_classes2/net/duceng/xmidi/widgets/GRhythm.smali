.class public Lnet/duceng/xmidi/widgets/GRhythm;
.super Landroid/widget/ImageButton;
.source "GRhythm.java"


# instance fields
.field private degree:I

.field private rhythm:Lnet/duceng/xmidi/util/Rhythm;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .line 15
    invoke-direct {p0, p1}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;)V

    .line 16
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/GRhythm;->degree:I

    .line 17
    const/4 v0, 0x0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GRhythm;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    .line 18
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;

    .line 21
    invoke-direct {p0, p1, p2}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 22
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/GRhythm;->degree:I

    .line 23
    const/4 v0, 0x0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GRhythm;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    .line 24
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;
    .param p3, "defStyle"    # I

    .line 27
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 28
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/GRhythm;->degree:I

    .line 29
    const/4 v0, 0x0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GRhythm;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    .line 30
    return-void
.end method


# virtual methods
.method public getDegree()I
    .locals 1

    .line 33
    iget v0, p0, Lnet/duceng/xmidi/widgets/GRhythm;->degree:I

    return v0
.end method

.method public getRhythm()Lnet/duceng/xmidi/util/Rhythm;
    .locals 1

    .line 44
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/GRhythm;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    return-object v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 17
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 56
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Lnet/duceng/xmidi/widgets/GRhythm;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    if-eqz v2, :cond_0

    .line 57
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/GRhythm;->getPaddingLeft()I

    move-result v2

    .line 58
    .local v2, "left":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/GRhythm;->getPaddingTop()I

    move-result v3

    .line 59
    .local v3, "top":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/GRhythm;->getPaddingRight()I

    move-result v4

    .line 60
    .local v4, "right":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/GRhythm;->getPaddingBottom()I

    move-result v5

    .line 61
    .local v5, "bottom":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/GRhythm;->getWidth()I

    move-result v6

    sub-int/2addr v6, v2

    sub-int/2addr v6, v4

    .line 62
    .local v6, "width":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/GRhythm;->getHeight()I

    move-result v7

    sub-int/2addr v7, v3

    sub-int/2addr v7, v5

    .line 63
    .local v7, "height":I
    iget v8, v0, Lnet/duceng/xmidi/widgets/GRhythm;->degree:I

    int-to-double v8, v8

    invoke-static {v8, v9}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v8

    .line 64
    .local v8, "a":D
    int-to-double v10, v6

    invoke-static {v8, v9}, Ljava/lang/Math;->cos(D)D

    move-result-wide v12

    mul-double v10, v10, v12

    invoke-static {v10, v11}, Ljava/lang/Math;->abs(D)D

    move-result-wide v10

    int-to-double v12, v7

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v14

    mul-double v12, v12, v14

    invoke-static {v12, v13}, Ljava/lang/Math;->abs(D)D

    move-result-wide v12

    add-double/2addr v10, v12

    double-to-int v10, v10

    .line 65
    .local v10, "nw":I
    int-to-double v11, v6

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v13

    mul-double v11, v11, v13

    invoke-static {v11, v12}, Ljava/lang/Math;->abs(D)D

    move-result-wide v11

    int-to-double v13, v7

    invoke-static {v8, v9}, Ljava/lang/Math;->cos(D)D

    move-result-wide v15

    mul-double v13, v13, v15

    invoke-static {v13, v14}, Ljava/lang/Math;->abs(D)D

    move-result-wide v13

    add-double/2addr v11, v13

    double-to-int v11, v11

    .line 66
    .local v11, "nh":I
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->getSaveCount()I

    move-result v12

    .line 67
    .local v12, "saveCount":I
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    .line 68
    div-int/lit8 v13, v6, 0x2

    add-int/2addr v13, v2

    int-to-float v13, v13

    div-int/lit8 v14, v7, 0x2

    add-int/2addr v14, v3

    int-to-float v14, v14

    invoke-virtual {v1, v13, v14}, Landroid/graphics/Canvas;->translate(FF)V

    .line 69
    iget v13, v0, Lnet/duceng/xmidi/widgets/GRhythm;->degree:I

    rem-int/lit16 v13, v13, 0x168

    int-to-float v13, v13

    invoke-virtual {v1, v13}, Landroid/graphics/Canvas;->rotate(F)V

    .line 70
    neg-int v13, v10

    div-int/lit8 v13, v13, 0x2

    int-to-float v13, v13

    neg-int v14, v11

    div-int/lit8 v14, v14, 0x2

    int-to-float v14, v14

    invoke-virtual {v1, v13, v14}, Landroid/graphics/Canvas;->translate(FF)V

    .line 71
    iget-object v13, v0, Lnet/duceng/xmidi/widgets/GRhythm;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    invoke-virtual {v13, v1, v10, v11}, Lnet/duceng/xmidi/util/Rhythm;->draw(Landroid/graphics/Canvas;II)V

    .line 72
    invoke-virtual {v1, v12}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 74
    .end local v2    # "left":I
    .end local v3    # "top":I
    .end local v4    # "right":I
    .end local v5    # "bottom":I
    .end local v6    # "width":I
    .end local v7    # "height":I
    .end local v8    # "a":D
    .end local v10    # "nw":I
    .end local v11    # "nh":I
    .end local v12    # "saveCount":I
    :cond_0
    return-void
.end method

.method public setDegree(I)V
    .locals 1
    .param p1, "degree"    # I

    .line 37
    iget v0, p0, Lnet/duceng/xmidi/widgets/GRhythm;->degree:I

    if-eq v0, p1, :cond_0

    .line 38
    iput p1, p0, Lnet/duceng/xmidi/widgets/GRhythm;->degree:I

    .line 39
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GRhythm;->invalidate()V

    .line 41
    :cond_0
    return-void
.end method

.method public setRhythm(Lnet/duceng/xmidi/util/Rhythm;)V
    .locals 1
    .param p1, "rhythm"    # Lnet/duceng/xmidi/util/Rhythm;

    .line 48
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/GRhythm;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    if-eq v0, p1, :cond_0

    .line 49
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/GRhythm;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    .line 50
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GRhythm;->invalidate()V

    .line 52
    :cond_0
    return-void
.end method
