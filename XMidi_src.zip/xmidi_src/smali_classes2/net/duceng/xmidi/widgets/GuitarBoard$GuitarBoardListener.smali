.class public interface abstract Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;
.super Ljava/lang/Object;
.source "GuitarBoard.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/widgets/GuitarBoard;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "GuitarBoardListener"
.end annotation


# virtual methods
.method public abstract onKeysChanged(II)V
.end method
