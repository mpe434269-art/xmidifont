.class public Lnet/duceng/xmidi/widgets/GuitarBoard;
.super Landroid/view/SurfaceView;
.source "GuitarBoard.java"

# interfaces
.implements Landroid/view/SurfaceHolder$Callback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;
    }
.end annotation


# static fields
.field private static BWIDTH:F = 0.0f

.field public static final KEYS:I = 0x7

.field private static NOTES:[I = null

.field public static final OCTAVE:I = 0x7


# instance fields
.field private barBitmap:Landroid/graphics/Bitmap;

.field private barHeight:F

.field private boardBitmap:Landroid/graphics/Bitmap;

.field private boardRect:Landroid/graphics/Rect;

.field private border:I

.field private eventNotes:[I

.field private fingerBitmap:Landroid/graphics/Bitmap;

.field private fingerWidth:I

.field private fingers:[I

.field private guitarBoardListener:Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;

.field private holder:Landroid/view/SurfaceHolder;

.field private margin:I

.field private paint:Landroid/graphics/Paint;

.field private stringWidth:F

.field private surfaceReady:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 36
    const/high16 v0, 0x3f400000    # 0.75f

    sput v0, Lnet/duceng/xmidi/widgets/GuitarBoard;->BWIDTH:F

    .line 37
    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lnet/duceng/xmidi/widgets/GuitarBoard;->NOTES:[I

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x28
        0x2d
        0x32
        0x37
        0x3b
        0x40
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .line 44
    invoke-direct {p0, p1}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;)V

    .line 45
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->paint:Landroid/graphics/Paint;

    .line 46
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    .line 47
    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    .line 48
    const/16 v0, 0xa

    new-array v0, v0, [I

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->eventNotes:[I

    .line 49
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->init()V

    .line 50
    return-void

    nop

    :array_0
    .array-data 4
        0x1
        0x0
        0x2
        0x2
        0x1
        0x0
        0x0
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;

    .line 53
    invoke-direct {p0, p1, p2}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 54
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->paint:Landroid/graphics/Paint;

    .line 55
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    .line 56
    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    .line 57
    const/16 v0, 0xa

    new-array v0, v0, [I

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->eventNotes:[I

    .line 58
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->init()V

    .line 59
    return-void

    nop

    :array_0
    .array-data 4
        0x1
        0x0
        0x2
        0x2
        0x1
        0x0
        0x0
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;
    .param p3, "defStyle"    # I

    .line 62
    invoke-direct {p0, p1, p2, p3}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 63
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->paint:Landroid/graphics/Paint;

    .line 64
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    .line 65
    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    .line 66
    const/16 v0, 0xa

    new-array v0, v0, [I

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->eventNotes:[I

    .line 67
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->init()V

    .line 68
    return-void

    nop

    :array_0
    .array-data 4
        0x1
        0x0
        0x2
        0x2
        0x1
        0x0
        0x0
    .end array-data
.end method

.method private draw()V
    .locals 2

    .line 141
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->surfaceReady:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v0}, Landroid/view/SurfaceHolder;->lockCanvas()Landroid/graphics/Canvas;

    move-result-object v0

    move-object v1, v0

    .local v1, "canvas":Landroid/graphics/Canvas;
    if-eqz v0, :cond_0

    .line 142
    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/widgets/GuitarBoard;->draw(Landroid/graphics/Canvas;)V

    .line 143
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v0, v1}, Landroid/view/SurfaceHolder;->unlockCanvasAndPost(Landroid/graphics/Canvas;)V

    .line 145
    .end local v1    # "canvas":Landroid/graphics/Canvas;
    :cond_0
    return-void
.end method

.method private drawBorder(Landroid/graphics/Canvas;)V
    .locals 7
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 120
    iget v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->border:I

    if-lez v0, :cond_0

    .line 121
    iget v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    int-to-float v2, v0

    iget v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    int-to-float v3, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getWidth()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v4, v0

    iget v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->border:I

    add-int/2addr v0, v1

    int-to-float v5, v0

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->paint:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 122
    iget v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    int-to-float v2, v0

    iget v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    int-to-float v3, v0

    iget v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->border:I

    add-int/2addr v0, v1

    int-to-float v4, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getHeight()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v5, v0

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->paint:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 123
    iget v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    int-to-float v2, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getHeight()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    sub-int/2addr v0, v1

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->border:I

    sub-int/2addr v0, v1

    int-to-float v3, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getWidth()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v4, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getHeight()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v5, v0

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->paint:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 124
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getWidth()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    sub-int/2addr v0, v1

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->border:I

    sub-int/2addr v0, v1

    int-to-float v2, v0

    iget v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    int-to-float v3, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getWidth()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v4, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getHeight()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v5, v0

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->paint:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 126
    :cond_0
    return-void
.end method

.method private drawFingers(Landroid/graphics/Canvas;)V
    .locals 9
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 129
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    const/4 v1, 0x0

    aget v0, v0, v1

    const/high16 v2, 0x40000000    # 2.0f

    if-lez v0, :cond_0

    .line 130
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->barBitmap:Landroid/graphics/Bitmap;

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v3, v3, Landroid/graphics/Rect;->left:I

    int-to-float v3, v3

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->top:I

    int-to-float v4, v4

    iget v5, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->barHeight:F

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    aget v6, v6, v1

    int-to-float v6, v6

    mul-float v5, v5, v6

    add-float/2addr v4, v5

    iget v5, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->barHeight:F

    div-float/2addr v5, v2

    sub-float/2addr v4, v5

    iget v5, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    div-int/lit8 v5, v5, 0x2

    int-to-float v5, v5

    sub-float/2addr v4, v5

    iget-object v5, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v3, v4, v5}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 132
    :cond_0
    const/4 v0, 0x1

    .local v0, "i":I
    :goto_0
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    array-length v3, v3

    if-ge v0, v3, :cond_2

    .line 133
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    aget v3, v3, v0

    if-lez v3, :cond_1

    .line 134
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerBitmap:Landroid/graphics/Bitmap;

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->left:I

    int-to-float v4, v4

    iget v5, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    div-float/2addr v5, v2

    sub-float/2addr v4, v5

    iget v5, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    int-to-float v6, v0

    mul-float v5, v5, v6

    add-float/2addr v4, v5

    iget v5, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    div-int/lit8 v5, v5, 0x2

    int-to-float v5, v5

    sub-float/2addr v4, v5

    iget-object v5, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v5, v5, Landroid/graphics/Rect;->top:I

    int-to-float v5, v5

    iget v6, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->barHeight:F

    iget-object v7, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    aget v7, v7, v0

    iget-object v8, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    aget v8, v8, v1

    add-int/2addr v7, v8

    int-to-float v7, v7

    mul-float v6, v6, v7

    add-float/2addr v5, v6

    iget v6, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->barHeight:F

    div-float/2addr v6, v2

    sub-float/2addr v5, v6

    iget v6, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    div-int/lit8 v6, v6, 0x2

    int-to-float v6, v6

    sub-float/2addr v5, v6

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v3, v4, v5, v6}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 132
    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 137
    .end local v0    # "i":I
    :cond_2
    return-void
.end method

.method private init()V
    .locals 2

    .line 71
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    .line 72
    const/4 v0, 0x1

    iput v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->border:I

    .line 73
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->holder:Landroid/view/SurfaceHolder;

    .line 74
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v1, p0}, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V

    .line 75
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v1, v0}, Landroid/view/SurfaceHolder;->setFormat(I)V

    .line 76
    return-void
.end method

.method private initBitmap()V
    .locals 7

    .line 93
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v1

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v2

    const v3, 0x7f030018

    invoke-static {v0, v3, v1, v2}, Lnet/duceng/xmidi/Base;->decodeResource(Landroid/content/res/Resources;III)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 94
    .local v0, "bmpTemp":Landroid/graphics/Bitmap;
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v1

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v2

    const/4 v3, 0x1

    invoke-static {v0, v1, v2, v3}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardBitmap:Landroid/graphics/Bitmap;

    .line 95
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 96
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    iget v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    const v5, 0x7f03001a

    invoke-static {v1, v5, v2, v4}, Lnet/duceng/xmidi/Base;->decodeResource(Landroid/content/res/Resources;III)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 97
    .local v1, "bmpTemp2":Landroid/graphics/Bitmap;
    iget v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    iget v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    invoke-static {v1, v2, v4, v3}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v2

    iput-object v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerBitmap:Landroid/graphics/Bitmap;

    .line 98
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 99
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    invoke-virtual {v4}, Landroid/graphics/Rect;->width()I

    move-result v4

    iget v5, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    div-int/lit8 v5, v5, 0x2

    const v6, 0x7f030017

    invoke-static {v2, v6, v4, v5}, Lnet/duceng/xmidi/Base;->decodeResource(Landroid/content/res/Resources;III)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 100
    .local v2, "bmpTemp3":Landroid/graphics/Bitmap;
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    invoke-virtual {v4}, Landroid/graphics/Rect;->width()I

    move-result v4

    iget v5, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    div-int/lit8 v5, v5, 0x2

    invoke-static {v2, v4, v5, v3}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v3

    iput-object v3, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->barBitmap:Landroid/graphics/Bitmap;

    .line 101
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    .line 102
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 103
    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .locals 4
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 113
    const/4 v0, 0x0

    sget-object v1, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/PorterDuff$Mode;)V

    .line 114
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/widgets/GuitarBoard;->drawBorder(Landroid/graphics/Canvas;)V

    .line 115
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardBitmap:Landroid/graphics/Bitmap;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->left:I

    int-to-float v1, v1

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->top:I

    int-to-float v2, v2

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 116
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/widgets/GuitarBoard;->drawFingers(Landroid/graphics/Canvas;)V

    .line 117
    return-void
.end method

.method public getFingers()[I
    .locals 1

    .line 201
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    return-object v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 2
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 107
    const-string v0, "PianoBoard"

    const-string v1, "onDraw: This will NOT happen!"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 108
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/widgets/GuitarBoard;->draw(Landroid/graphics/Canvas;)V

    .line 109
    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 4
    .param p1, "width"    # I
    .param p2, "height"    # I
    .param p3, "oldw"    # I
    .param p4, "oldh"    # I

    .line 80
    iget v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    mul-int/lit8 v0, v0, 0x2

    sub-int v0, p1, v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->border:I

    mul-int/lit8 v1, v1, 0x2

    sub-int/2addr v0, v1

    int-to-float v0, v0

    sget v1, Lnet/duceng/xmidi/widgets/GuitarBoard;->BWIDTH:F

    mul-float v0, v0, v1

    float-to-int v0, v0

    .line 81
    .local v0, "w":I
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    iget v3, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->border:I

    add-int/2addr v2, v3

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getWidth()I

    move-result v3

    sub-int/2addr v3, v0

    div-int/lit8 v3, v3, 0x2

    add-int/2addr v2, v3

    iput v2, v1, Landroid/graphics/Rect;->left:I

    .line 82
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    iget v3, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->border:I

    add-int/2addr v2, v3

    iput v2, v1, Landroid/graphics/Rect;->top:I

    .line 83
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->left:I

    add-int/2addr v2, v0

    iput v2, v1, Landroid/graphics/Rect;->right:I

    .line 84
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->margin:I

    sub-int v2, p2, v2

    iget v3, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->border:I

    sub-int/2addr v2, v3

    iput v2, v1, Landroid/graphics/Rect;->bottom:I

    .line 85
    int-to-float v1, v0

    const/high16 v2, 0x40c00000    # 6.0f

    div-float/2addr v1, v2

    iput v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    .line 86
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    move-result v1

    int-to-float v1, v1

    const/high16 v2, 0x40a00000    # 5.0f

    div-float/2addr v1, v2

    iput v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->barHeight:F

    .line 87
    iget v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    const/high16 v3, 0x40400000    # 3.0f

    mul-float v1, v1, v3

    div-float/2addr v1, v2

    float-to-int v1, v1

    iput v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    .line 88
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "onSizeChanged width: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "GuiterBoard"

    invoke-static {v2, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 89
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->initBitmap()V

    .line 90
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 13
    .param p1, "event"    # Landroid/view/MotionEvent;

    .line 150
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    and-int/lit16 v0, v0, 0xff

    .line 151
    .local v0, "action":I
    const/4 v1, 0x1

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_7

    const/4 v5, 0x5

    if-ne v0, v5, :cond_0

    goto/16 :goto_1

    .line 169
    :cond_0
    if-eq v0, v1, :cond_4

    const/4 v5, 0x6

    if-ne v0, v5, :cond_1

    goto/16 :goto_0

    .line 175
    :cond_1
    if-ne v0, v4, :cond_6

    .line 176
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v5

    .line 177
    .local v5, "idx2":I
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v6

    .line 178
    .local v6, "id2":I
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getX(I)F

    move-result v7

    float-to-int v7, v7

    .line 179
    .local v7, "x2":I
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getY(I)F

    move-result v8

    float-to-int v8, v8

    .line 180
    .local v8, "y2":I
    iget-object v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    invoke-virtual {v9, v7, v8}, Landroid/graphics/Rect;->contains(II)Z

    move-result v9

    if-eqz v9, :cond_a

    .line 181
    iget-object v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->left:I

    sub-int v9, v7, v9

    iget v10, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    div-int/2addr v10, v4

    add-int/2addr v9, v10

    int-to-float v9, v9

    iget v10, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    div-float/2addr v10, v2

    add-float/2addr v9, v10

    iget v10, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    rem-float/2addr v9, v10

    float-to-int v9, v9

    .line 182
    .local v9, "xoff2":I
    iget v10, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    if-ge v9, v10, :cond_a

    .line 183
    iget-object v10, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v10, v10, Landroid/graphics/Rect;->left:I

    sub-int v10, v7, v10

    iget v11, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    div-int/2addr v11, v4

    add-int/2addr v10, v11

    int-to-float v4, v10

    iget v10, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    div-float/2addr v10, v2

    add-float/2addr v4, v10

    iget v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    div-float/2addr v4, v2

    float-to-int v2, v4

    .line 184
    .local v2, "xnum2":I
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    aget v4, v4, v2

    if-ltz v4, :cond_a

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->eventNotes:[I

    aget v4, v4, v6

    sget-object v10, Lnet/duceng/xmidi/widgets/GuitarBoard;->NOTES:[I

    aget v10, v10, v2

    iget-object v11, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    aget v11, v11, v2

    add-int/2addr v10, v11

    iget-object v11, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    aget v11, v11, v3

    add-int/2addr v10, v11

    move v11, v10

    .local v11, "note":I
    if-eq v4, v10, :cond_a

    .line 185
    mul-int/lit8 v4, v8, 0x5a

    iget-object v10, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v10, v10, Landroid/graphics/Rect;->bottom:I

    div-int/2addr v4, v10

    add-int/lit8 v4, v4, 0x1e

    .line 186
    .local v4, "val2":I
    iget-object v10, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->guitarBoardListener:Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;

    if-eqz v10, :cond_3

    .line 187
    iget-object v10, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->eventNotes:[I

    aget v10, v10, v6

    if-lez v10, :cond_2

    .line 188
    iget-object v10, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->guitarBoardListener:Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;

    iget-object v12, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->eventNotes:[I

    aget v12, v12, v6

    invoke-interface {v10, v12, v3}, Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;->onKeysChanged(II)V

    .line 190
    :cond_2
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->guitarBoardListener:Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;

    invoke-interface {v3, v11, v4}, Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;->onKeysChanged(II)V

    .line 192
    :cond_3
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->eventNotes:[I

    aput v11, v3, v6

    goto/16 :goto_2

    .line 170
    .end local v2    # "xnum2":I
    .end local v4    # "val2":I
    .end local v5    # "idx2":I
    .end local v6    # "id2":I
    .end local v7    # "x2":I
    .end local v8    # "y2":I
    .end local v9    # "xoff2":I
    .end local v11    # "note":I
    :cond_4
    :goto_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v2

    .line 171
    .local v2, "id":I
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->guitarBoardListener:Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;

    if-eqz v4, :cond_5

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->eventNotes:[I

    aget v4, v4, v2

    if-lez v4, :cond_5

    .line 172
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->guitarBoardListener:Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;

    iget-object v5, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->eventNotes:[I

    aget v5, v5, v2

    invoke-interface {v4, v5, v3}, Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;->onKeysChanged(II)V

    .line 174
    :cond_5
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->eventNotes:[I

    aput v3, v4, v2

    .line 175
    .end local v2    # "id":I
    :cond_6
    goto :goto_2

    .line 152
    :cond_7
    :goto_1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v5

    .line 153
    .local v5, "idx":I
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getX(I)F

    move-result v6

    float-to-int v6, v6

    .line 154
    .local v6, "x":I
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getY(I)F

    move-result v7

    float-to-int v7, v7

    .line 155
    .local v7, "y":I
    iget-object v8, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    invoke-virtual {v8, v6, v7}, Landroid/graphics/Rect;->contains(II)Z

    move-result v8

    if-eqz v8, :cond_9

    .line 156
    iget-object v8, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v8, v8, Landroid/graphics/Rect;->left:I

    sub-int v8, v6, v8

    iget v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    div-int/2addr v9, v4

    add-int/2addr v8, v9

    int-to-float v8, v8

    iget v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    div-float/2addr v9, v2

    add-float/2addr v8, v9

    iget v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    rem-float/2addr v8, v9

    float-to-int v8, v8

    .line 157
    .local v8, "xoff":I
    iget v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    if-ge v8, v9, :cond_9

    .line 158
    iget-object v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->left:I

    sub-int v9, v6, v9

    iget v10, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingerWidth:I

    div-int/2addr v10, v4

    add-int/2addr v9, v10

    int-to-float v4, v9

    iget v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    div-float/2addr v9, v2

    add-float/2addr v4, v9

    iget v2, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->stringWidth:F

    div-float/2addr v4, v2

    float-to-int v2, v4

    .line 159
    .local v2, "xnum":I
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    aget v4, v4, v2

    if-ltz v4, :cond_9

    .line 160
    sget-object v4, Lnet/duceng/xmidi/widgets/GuitarBoard;->NOTES:[I

    aget v4, v4, v2

    iget-object v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    aget v9, v9, v2

    add-int/2addr v4, v9

    iget-object v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    aget v3, v9, v3

    add-int/2addr v4, v3

    .line 161
    .local v4, "note2":I
    mul-int/lit8 v3, v7, 0x5a

    iget-object v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->boardRect:Landroid/graphics/Rect;

    iget v9, v9, Landroid/graphics/Rect;->bottom:I

    div-int/2addr v3, v9

    add-int/lit8 v3, v3, 0x1e

    .line 162
    .local v3, "val":I
    iget-object v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->guitarBoardListener:Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;

    if-eqz v9, :cond_8

    .line 163
    iget-object v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->guitarBoardListener:Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;

    invoke-interface {v9, v4, v3}, Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;->onKeysChanged(II)V

    .line 165
    :cond_8
    iget-object v9, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->eventNotes:[I

    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v10

    aput v4, v9, v10

    .line 169
    .end local v2    # "xnum":I
    .end local v3    # "val":I
    .end local v4    # "note2":I
    .end local v5    # "idx":I
    .end local v6    # "x":I
    .end local v7    # "y":I
    .end local v8    # "xoff":I
    :cond_9
    nop

    .line 197
    :cond_a
    :goto_2
    return v1
.end method

.method public setFingers([B)V
    .locals 3
    .param p1, "f"    # [B

    .line 205
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    array-length v1, v1

    if-ge v0, v1, :cond_0

    .line 206
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->fingers:[I

    aget-byte v2, p1, v0

    aput v2, v1, v0

    .line 205
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 208
    .end local v0    # "i":I
    :cond_0
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->draw()V

    .line 209
    return-void
.end method

.method public setGuitarBoardListener(Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;

    .line 227
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->guitarBoardListener:Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;

    .line 228
    return-void
.end method

.method public surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .locals 0
    .param p1, "holder"    # Landroid/view/SurfaceHolder;
    .param p2, "format"    # I
    .param p3, "width"    # I
    .param p4, "height"    # I

    .line 213
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->draw()V

    .line 214
    return-void
.end method

.method public surfaceCreated(Landroid/view/SurfaceHolder;)V
    .locals 1
    .param p1, "holder"    # Landroid/view/SurfaceHolder;

    .line 218
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->surfaceReady:Z

    .line 219
    return-void
.end method

.method public surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .locals 1
    .param p1, "holder"    # Landroid/view/SurfaceHolder;

    .line 223
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/widgets/GuitarBoard;->surfaceReady:Z

    .line 224
    return-void
.end method
