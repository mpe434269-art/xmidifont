.class public interface abstract Lnet/duceng/xmidi/widgets/MetronomeHand$SpeedListener;
.super Ljava/lang/Object;
.source "MetronomeHand.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/widgets/MetronomeHand;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "SpeedListener"
.end annotation


# virtual methods
.method public abstract onSpeedChanged(I)V
.end method
