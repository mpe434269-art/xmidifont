.class public Lnet/duceng/xmidi/widgets/MetronomeHand;
.super Landroid/view/View;
.source "MetronomeHand.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/widgets/MetronomeHand$SpeedListener;
    }
.end annotation


# static fields
.field private static DEGREE_MAX:I

.field private static DEGREE_MIN:I

.field private static SPEED_MAX:I

.field private static SPEED_MAX_Y:F

.field private static SPEED_MIN:I

.field private static SPEED_MIN_Y:F


# instance fields
.field private block:Landroid/graphics/Bitmap;

.field private blockRect:Landroid/graphics/Rect;

.field private degree:F

.field private degreeMax:F

.field private lastY:F

.field private matrix:Landroid/graphics/Matrix;

.field private paint:Landroid/graphics/Paint;

.field private ruler:Landroid/graphics/Bitmap;

.field private rulerRect:Landroid/graphics/Rect;

.field private scale:F

.field private speed:I

.field private speedListener:Lnet/duceng/xmidi/widgets/MetronomeHand$SpeedListener;

.field private toRight:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 32
    const/4 v0, 0x5

    sput v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MIN:I

    .line 33
    const/16 v0, 0x1b

    sput v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    .line 34
    const/16 v0, 0x28

    sput v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    .line 35
    const/16 v0, 0xd0

    sput v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX:I

    .line 36
    const v0, 0x3da3d70a    # 0.08f

    sput v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN_Y:F

    .line 37
    const v0, 0x3f75c28f    # 0.96f

    sput v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX_Y:F

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 5
    .param p1, "context"    # Landroid/content/Context;

    .line 44
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 45
    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    .line 46
    const/16 v0, 0x78

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    .line 47
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    .line 48
    sget v1, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    sget v2, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MIN:I

    sub-int/2addr v2, v3

    iget v3, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v3, v4

    mul-int v2, v2, v3

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX:I

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v3, v4

    div-int/2addr v2, v3

    sub-int/2addr v1, v2

    int-to-float v1, v1

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degreeMax:F

    .line 49
    const/4 v1, 0x1

    iput-boolean v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->toRight:Z

    .line 50
    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->lastY:F

    .line 51
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->init()V

    .line 52
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;

    .line 55
    invoke-direct {p0, p1, p2}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 56
    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    .line 57
    const/16 v0, 0x78

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    .line 58
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    .line 59
    sget v1, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    sget v2, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MIN:I

    sub-int/2addr v2, v3

    iget v3, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v3, v4

    mul-int v2, v2, v3

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX:I

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v3, v4

    div-int/2addr v2, v3

    sub-int/2addr v1, v2

    int-to-float v1, v1

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degreeMax:F

    .line 60
    const/4 v1, 0x1

    iput-boolean v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->toRight:Z

    .line 61
    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->lastY:F

    .line 62
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->init()V

    .line 63
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;
    .param p3, "defStyle"    # I

    .line 66
    invoke-direct {p0, p1, p2, p3}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 67
    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    .line 68
    const/16 v0, 0x78

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    .line 69
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    .line 70
    sget v1, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    sget v2, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MIN:I

    sub-int/2addr v2, v3

    iget v3, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v3, v4

    mul-int v2, v2, v3

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX:I

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v3, v4

    div-int/2addr v2, v3

    sub-int/2addr v1, v2

    int-to-float v1, v1

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degreeMax:F

    .line 71
    const/4 v1, 0x1

    iput-boolean v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->toRight:Z

    .line 72
    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->lastY:F

    .line 73
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->init()V

    .line 74
    return-void
.end method

.method private init()V
    .locals 3

    .line 77
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    .line 78
    .local v0, "res":Landroid/content/res/Resources;
    const v1, 0x7f03004d

    invoke-static {v0, v1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->ruler:Landroid/graphics/Bitmap;

    .line 79
    const v1, 0x7f03004c

    invoke-static {v0, v1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->block:Landroid/graphics/Bitmap;

    .line 80
    new-instance v1, Landroid/graphics/Matrix;

    invoke-direct {v1}, Landroid/graphics/Matrix;-><init>()V

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->matrix:Landroid/graphics/Matrix;

    .line 81
    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1}, Landroid/graphics/Paint;-><init>()V

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->paint:Landroid/graphics/Paint;

    .line 82
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->paint:Landroid/graphics/Paint;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 83
    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    .line 84
    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->rulerRect:Landroid/graphics/Rect;

    .line 85
    invoke-virtual {p0, v2}, Lnet/duceng/xmidi/widgets/MetronomeHand;->setClickable(Z)V

    .line 86
    return-void
.end method


# virtual methods
.method public getDegree()F
    .locals 1

    .line 107
    iget v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    return v0
.end method

.method public getSpeed()I
    .locals 1

    .line 89
    iget v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    return v0
.end method

.method public onDraw(Landroid/graphics/Canvas;)V
    .locals 6
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 156
    iget v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getWidth()I

    move-result v1

    div-int/lit8 v1, v1, 0x2

    int-to-float v1, v1

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getHeight()I

    move-result v2

    int-to-double v2, v2

    const-wide v4, 0x3ff2b851eb851eb8L    # 1.17

    mul-double v2, v2, v4

    double-to-int v2, v2

    int-to-float v2, v2

    invoke-virtual {p1, v0, v1, v2}, Landroid/graphics/Canvas;->rotate(FFF)V

    .line 157
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->matrix:Landroid/graphics/Matrix;

    invoke-virtual {v0}, Landroid/graphics/Matrix;->reset()V

    .line 158
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->matrix:Landroid/graphics/Matrix;

    iget v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    iget v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postScale(FF)Z

    .line 159
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->matrix:Landroid/graphics/Matrix;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->rulerRect:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->left:I

    int-to-float v1, v1

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->rulerRect:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->top:I

    int-to-float v2, v2

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 160
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->ruler:Landroid/graphics/Bitmap;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->matrix:Landroid/graphics/Matrix;

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V

    .line 161
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->matrix:Landroid/graphics/Matrix;

    invoke-virtual {v0}, Landroid/graphics/Matrix;->reset()V

    .line 162
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->matrix:Landroid/graphics/Matrix;

    iget v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    iget v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postScale(FF)Z

    .line 163
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->matrix:Landroid/graphics/Matrix;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->left:I

    int-to-float v1, v1

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->top:I

    int-to-float v2, v2

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 164
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->block:Landroid/graphics/Bitmap;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->matrix:Landroid/graphics/Matrix;

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V

    .line 165
    return-void
.end method

.method public onSizeChanged(IIII)V
    .locals 6
    .param p1, "w"    # I
    .param p2, "h"    # I
    .param p3, "oldw"    # I
    .param p4, "oldh"    # I

    .line 144
    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onSizeChanged(IIII)V

    .line 145
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->ruler:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v0

    div-int v0, p2, v0

    int-to-float v0, v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    .line 146
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->rulerRect:Landroid/graphics/Rect;

    const/4 v1, 0x0

    iput v1, v0, Landroid/graphics/Rect;->top:I

    .line 147
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->rulerRect:Landroid/graphics/Rect;

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getWidth()I

    move-result v1

    div-int/lit8 v1, v1, 0x2

    int-to-float v1, v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->ruler:Landroid/graphics/Bitmap;

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    int-to-float v3, v3

    mul-float v2, v2, v3

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v2, v3

    sub-float/2addr v1, v2

    float-to-int v1, v1

    iput v1, v0, Landroid/graphics/Rect;->left:I

    .line 148
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    int-to-float v1, p2

    sget v2, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX_Y:F

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN_Y:F

    sub-float/2addr v2, v4

    mul-float v1, v1, v2

    iget v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v2, v4

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX:I

    sget v5, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v4, v5

    div-int/2addr v2, v4

    int-to-float v2, v2

    mul-float v1, v1, v2

    int-to-float v2, p2

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN_Y:F

    mul-float v2, v2, v4

    add-float/2addr v1, v2

    float-to-int v1, v1

    iput v1, v0, Landroid/graphics/Rect;->top:I

    .line 149
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getWidth()I

    move-result v1

    div-int/lit8 v1, v1, 0x2

    int-to-float v1, v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->block:Landroid/graphics/Bitmap;

    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v4

    int-to-float v4, v4

    mul-float v2, v2, v4

    div-float/2addr v2, v3

    sub-float/2addr v1, v2

    float-to-int v1, v1

    iput v1, v0, Landroid/graphics/Rect;->left:I

    .line 150
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->left:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->block:Landroid/graphics/Bitmap;

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    int-to-float v3, v3

    mul-float v2, v2, v3

    float-to-int v2, v2

    add-int/2addr v1, v2

    iput v1, v0, Landroid/graphics/Rect;->right:I

    .line 151
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->top:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->scale:F

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->block:Landroid/graphics/Bitmap;

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v3

    int-to-float v3, v3

    mul-float v2, v2, v3

    float-to-int v2, v2

    add-int/2addr v1, v2

    iput v1, v0, Landroid/graphics/Rect;->bottom:I

    .line 152
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 5
    .param p1, "event"    # Landroid/view/MotionEvent;

    .line 169
    iget v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-eqz v0, :cond_0

    .line 170
    invoke-super {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    return v0

    .line 172
    :cond_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    and-int/lit16 v0, v0, 0xff

    .line 173
    .local v0, "action":I
    const/4 v2, 0x2

    if-ne v0, v2, :cond_4

    .line 174
    iget v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->lastY:F

    cmpl-float v1, v2, v1

    if-lez v1, :cond_7

    .line 175
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    iget v3, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->lastY:F

    sub-float/2addr v2, v3

    float-to-int v2, v2

    const/4 v3, 0x0

    invoke-virtual {v1, v3, v2}, Landroid/graphics/Rect;->offset(II)V

    .line 176
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->top:I

    int-to-float v1, v1

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getHeight()I

    move-result v2

    int-to-float v2, v2

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN_Y:F

    mul-float v2, v2, v3

    cmpg-float v1, v1, v2

    if-gez v1, :cond_1

    .line 177
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->left:I

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getHeight()I

    move-result v3

    int-to-float v3, v3

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN_Y:F

    mul-float v3, v3, v4

    float-to-int v3, v3

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Rect;->offsetTo(II)V

    goto :goto_0

    .line 178
    :cond_1
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget v1, v1, Landroid/graphics/Rect;->top:I

    int-to-float v1, v1

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getHeight()I

    move-result v2

    int-to-float v2, v2

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX_Y:F

    mul-float v2, v2, v3

    cmpl-float v1, v1, v2

    if-lez v1, :cond_2

    .line 179
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->left:I

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getHeight()I

    move-result v3

    int-to-float v3, v3

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX_Y:F

    mul-float v3, v3, v4

    float-to-int v3, v3

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Rect;->offsetTo(II)V

    .line 181
    :cond_2
    :goto_0
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->invalidate()V

    .line 182
    sget v1, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX:I

    sget v2, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v1, v2

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->top:I

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getHeight()I

    move-result v3

    int-to-float v3, v3

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN_Y:F

    mul-float v3, v3, v4

    float-to-int v3, v3

    sub-int/2addr v2, v3

    mul-int v1, v1, v2

    int-to-float v1, v1

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getHeight()I

    move-result v2

    int-to-float v2, v2

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX_Y:F

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN_Y:F

    sub-float/2addr v3, v4

    mul-float v2, v2, v3

    div-float/2addr v1, v2

    float-to-int v1, v1

    sget v2, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    add-int/2addr v1, v2

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    .line 183
    sget v1, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    sget v2, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MIN:I

    sub-int/2addr v2, v3

    iget v3, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v3, v4

    mul-int v2, v2, v3

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX:I

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v3, v4

    div-int/2addr v2, v3

    sub-int/2addr v1, v2

    int-to-float v1, v1

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degreeMax:F

    .line 184
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speedListener:Lnet/duceng/xmidi/widgets/MetronomeHand$SpeedListener;

    if-eqz v1, :cond_3

    .line 185
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speedListener:Lnet/duceng/xmidi/widgets/MetronomeHand$SpeedListener;

    iget v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    invoke-interface {v1, v2}, Lnet/duceng/xmidi/widgets/MetronomeHand$SpeedListener;->onSpeedChanged(I)V

    .line 187
    :cond_3
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->lastY:F

    goto :goto_1

    .line 189
    :cond_4
    if-nez v0, :cond_5

    .line 190
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    float-to-int v2, v2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    float-to-int v3, v3

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Rect;->contains(II)Z

    move-result v1

    if-eqz v1, :cond_7

    .line 191
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->lastY:F

    goto :goto_1

    .line 193
    :cond_5
    const/4 v2, 0x3

    if-eq v0, v2, :cond_6

    const/4 v2, 0x1

    if-ne v0, v2, :cond_7

    .line 194
    :cond_6
    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->lastY:F

    .line 196
    :cond_7
    :goto_1
    invoke-super {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v1

    return v1
.end method

.method public setDegree(F)V
    .locals 2
    .param p1, "degree"    # F

    .line 111
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result v0

    sget v1, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    int-to-float v1, v1

    cmpg-float v0, v0, v1

    if-gtz v0, :cond_0

    .line 112
    iput p1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    goto :goto_1

    .line 114
    :cond_0
    const/4 v0, 0x0

    cmpl-float v0, p1, v0

    if-lez v0, :cond_1

    sget v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    goto :goto_0

    :cond_1
    sget v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    mul-int/lit8 v0, v0, -0x1

    :goto_0
    int-to-float v0, v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    .line 116
    :goto_1
    return-void
.end method

.method public setPercent(F)V
    .locals 9
    .param p1, "percent"    # F

    .line 119
    const/high16 v0, 0x3f800000    # 1.0f

    cmpl-float v1, p1, v0

    if-lez v1, :cond_0

    .line 120
    const/high16 p1, 0x3f800000    # 1.0f

    .line 122
    :cond_0
    iget-boolean v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->toRight:Z

    const/4 v2, 0x0

    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    const/high16 v5, 0x40000000    # 2.0f

    const/high16 v6, -0x40000000    # -2.0f

    if-eqz v1, :cond_3

    .line 123
    float-to-double v7, p1

    cmpg-double v1, v7, v3

    if-gtz v1, :cond_1

    .line 124
    iget v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degreeMax:F

    mul-float v0, v0, p1

    mul-float v0, v0, v5

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    goto :goto_0

    .line 125
    :cond_1
    iget v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    cmpl-float v1, v1, v2

    if-lez v1, :cond_2

    .line 126
    const/4 v1, 0x0

    iput-boolean v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->toRight:Z

    .line 127
    iget v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degreeMax:F

    sub-float/2addr v0, p1

    mul-float v1, v1, v0

    mul-float v1, v1, v5

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    goto :goto_0

    .line 129
    :cond_2
    iget v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degreeMax:F

    sub-float/2addr v0, p1

    mul-float v1, v1, v0

    mul-float v1, v1, v6

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    goto :goto_0

    .line 131
    :cond_3
    float-to-double v7, p1

    cmpg-double v1, v7, v3

    if-gtz v1, :cond_4

    .line 132
    iget v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degreeMax:F

    mul-float v0, v0, p1

    mul-float v0, v0, v6

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    goto :goto_0

    .line 133
    :cond_4
    iget v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    cmpg-float v1, v1, v2

    if-gez v1, :cond_5

    .line 134
    const/4 v1, 0x1

    iput-boolean v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->toRight:Z

    .line 135
    iget v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degreeMax:F

    sub-float/2addr v0, p1

    mul-float v1, v1, v0

    mul-float v1, v1, v6

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    goto :goto_0

    .line 137
    :cond_5
    iget v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degreeMax:F

    sub-float/2addr v0, p1

    mul-float v1, v1, v0

    mul-float v1, v1, v5

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degree:F

    .line 139
    :goto_0
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->invalidate()V

    .line 140
    return-void
.end method

.method public setSpeed(I)V
    .locals 5
    .param p1, "speed"    # I

    .line 93
    sget v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX:I

    if-le p1, v0, :cond_0

    .line 94
    sget v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX:I

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    goto :goto_0

    .line 95
    :cond_0
    sget v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    if-ge p1, v0, :cond_1

    .line 96
    sget v0, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    iput v0, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    goto :goto_0

    .line 98
    :cond_1
    iput p1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speed:I

    .line 100
    :goto_0
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getHeight()I

    move-result v0

    int-to-float v0, v0

    sget v1, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX_Y:F

    sget v2, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN_Y:F

    sub-float/2addr v1, v2

    mul-float v0, v0, v1

    sget v1, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int v1, p1, v1

    sget v2, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX:I

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v2, v3

    div-int/2addr v1, v2

    int-to-float v1, v1

    mul-float v0, v0, v1

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->getHeight()I

    move-result v1

    int-to-float v1, v1

    sget v2, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN_Y:F

    mul-float v1, v1, v2

    add-float/2addr v0, v1

    float-to-int v0, v0

    .line 101
    .local v0, "newTop":I
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->blockRect:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->left:I

    invoke-virtual {v1, v2, v0}, Landroid/graphics/Rect;->offsetTo(II)V

    .line 102
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MetronomeHand;->invalidate()V

    .line 103
    sget v1, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    sget v2, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MAX:I

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->DEGREE_MIN:I

    sub-int/2addr v2, v3

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int v3, p1, v3

    mul-int v2, v2, v3

    sget v3, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MAX:I

    sget v4, Lnet/duceng/xmidi/widgets/MetronomeHand;->SPEED_MIN:I

    sub-int/2addr v3, v4

    div-int/2addr v2, v3

    sub-int/2addr v1, v2

    int-to-float v1, v1

    iput v1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->degreeMax:F

    .line 104
    return-void
.end method

.method public setSpeedListener(Lnet/duceng/xmidi/widgets/MetronomeHand$SpeedListener;)V
    .locals 0
    .param p1, "speedListener"    # Lnet/duceng/xmidi/widgets/MetronomeHand$SpeedListener;

    .line 200
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/MetronomeHand;->speedListener:Lnet/duceng/xmidi/widgets/MetronomeHand$SpeedListener;

    .line 201
    return-void
.end method
