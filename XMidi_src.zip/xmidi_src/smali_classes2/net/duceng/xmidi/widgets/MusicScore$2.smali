.class Lnet/duceng/xmidi/widgets/MusicScore$2;
.super Landroid/view/GestureDetector$SimpleOnGestureListener;
.source "MusicScore.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/widgets/MusicScore;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/widgets/MusicScore;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/widgets/MusicScore;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/widgets/MusicScore;

    .line 156
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/MusicScore$2;->this$0:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-direct {p0}, Landroid/view/GestureDetector$SimpleOnGestureListener;-><init>()V

    return-void
.end method


# virtual methods
.method public onScroll(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .locals 3
    .param p1, "e1"    # Landroid/view/MotionEvent;
    .param p2, "e2"    # Landroid/view/MotionEvent;
    .param p3, "distanceX"    # F
    .param p4, "distanceY"    # F

    .line 159
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore$2;->this$0:Lnet/duceng/xmidi/widgets/MusicScore;

    float-to-int v1, p3

    float-to-int v2, p4

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->scrollUpdate(II)V

    .line 160
    const/4 v0, 0x1

    return v0
.end method
