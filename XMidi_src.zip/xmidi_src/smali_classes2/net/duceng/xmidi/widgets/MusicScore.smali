.class public Lnet/duceng/xmidi/widgets/MusicScore;
.super Landroid/view/SurfaceView;
.source "MusicScore.java"

# interfaces
.implements Landroid/view/SurfaceHolder$Callback;


# static fields
.field private static $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration:[I = null

.field public static final DontScroll:I = 0x3

.field public static final GradualScroll:I = 0x2

.field public static final ImmediateScroll:I = 0x1

.field public static final LineSpace:I = 0x7

.field public static final LineWidth:I = 0x1

.field public static final Margin:I = 0x4

.field public static final NoteHeight:I = 0x8

.field public static final NoteNameFixedDoReMi:I = 0x2

.field public static final NoteNameFixedNumber:I = 0x4

.field public static final NoteNameLetter:I = 0x1

.field public static final NoteNameMovableDoReMi:I = 0x3

.field public static final NoteNameMovableNumber:I = 0x5

.field public static final NoteNameNone:I = 0x0

.field public static final NoteWidth:I = 0xa

.field public static final PageHeight:I = 0x41a

.field public static final PageWidth:I = 0x320

.field public static final StaffHeight:I = 0x21

.field public static final TitleHeight:I = 0xe


# instance fields
.field private NoteColors:[I

.field private bufferBitmap:Landroid/graphics/Bitmap;

.field private bufferCanvas:Landroid/graphics/Canvas;

.field private bufferX:I

.field private bufferY:I

.field private currentTicks:I

.field private gestureDetector:Landroid/view/GestureDetector;

.field holder:Landroid/view/SurfaceHolder;

.field private mainkey:Lnet/duceng/xmidi/widgets/score/MidiKey;

.field private midiFile:Lnet/duceng/midi/MidiFile;

.field private numtracks:I

.field private onGestureListener:Landroid/view/GestureDetector$OnGestureListener;

.field private paint:Landroid/graphics/Paint;

.field private scrollVert:Z

.field private scrollX:I

.field private scrollY:I

.field private shade1:I

.field private shade2:I

.field private sheetheight:I

.field private sheetwidth:I

.field private showMeasures:Z

.field private showNoteLetters:I

.field private shows:[Z

.field private staffs:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Staff;",
            ">;"
        }
    .end annotation
.end field

.field private surfaceReady:Z

.field private viewheight:I

.field private viewwidth:I

.field private zoom:F


# direct methods
.method static $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration()[I
    .locals 3

    .line 92
    sget-object v0, Lnet/duceng/xmidi/widgets/MusicScore;->$SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration:[I

    .line 93
    .local v0, "iArr":[I
    if-nez v0, :cond_0

    .line 94
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->valuesCustom()[Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v1

    array-length v1, v1

    new-array v0, v1, [I

    .line 96
    :try_start_0
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x5

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 98
    goto :goto_0

    .line 97
    :catch_0
    move-exception v1

    .line 100
    :goto_0
    :try_start_1
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/16 v2, 0x9

    aput v2, v0, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 102
    goto :goto_1

    .line 101
    :catch_1
    move-exception v1

    .line 104
    :goto_1
    :try_start_2
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedQuarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x7

    aput v2, v0, v1
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 106
    goto :goto_2

    .line 105
    :catch_2
    move-exception v1

    .line 108
    :goto_2
    :try_start_3
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 110
    goto :goto_3

    .line 109
    :catch_3
    move-exception v1

    .line 112
    :goto_3
    :try_start_4
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/16 v2, 0x8

    aput v2, v0, v1
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 114
    goto :goto_4

    .line 113
    :catch_4
    move-exception v1

    .line 116
    :goto_4
    :try_start_5
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x6

    aput v2, v0, v1
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    .line 118
    goto :goto_5

    .line 117
    :catch_5
    move-exception v1

    .line 120
    :goto_5
    :try_start_6
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    .line 122
    goto :goto_6

    .line 121
    :catch_6
    move-exception v1

    .line 124
    :goto_6
    :try_start_7
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_7} :catch_7

    .line 126
    goto :goto_7

    .line 125
    :catch_7
    move-exception v1

    .line 128
    :goto_7
    :try_start_8
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Triplet:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_8
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_8} :catch_8

    .line 130
    goto :goto_8

    .line 129
    :catch_8
    move-exception v1

    .line 132
    :goto_8
    :try_start_9
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/16 v2, 0xa

    aput v2, v0, v1
    :try_end_9
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_9} :catch_9

    .line 134
    goto :goto_9

    .line 133
    :catch_9
    move-exception v1

    .line 135
    :goto_9
    sput-object v0, Lnet/duceng/xmidi/widgets/MusicScore;->$SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration:[I

    .line 137
    :cond_0
    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 1

    .line 43
    const/4 v0, 0x0

    sput-object v0, Lnet/duceng/xmidi/widgets/MusicScore;->$SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .line 141
    invoke-direct {p0, p1}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;)V

    .line 142
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->currentTicks:I

    .line 143
    new-instance v0, Lnet/duceng/xmidi/widgets/MusicScore$1;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/widgets/MusicScore$1;-><init>(Lnet/duceng/xmidi/widgets/MusicScore;)V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->onGestureListener:Landroid/view/GestureDetector$OnGestureListener;

    .line 150
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->init()V

    .line 151
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;

    .line 154
    invoke-direct {p0, p1, p2}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 155
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->currentTicks:I

    .line 156
    new-instance v0, Lnet/duceng/xmidi/widgets/MusicScore$2;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/widgets/MusicScore$2;-><init>(Lnet/duceng/xmidi/widgets/MusicScore;)V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->onGestureListener:Landroid/view/GestureDetector$OnGestureListener;

    .line 163
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->init()V

    .line 164
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;
    .param p3, "defStyle"    # I

    .line 167
    invoke-direct {p0, p1, p2, p3}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 168
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->currentTicks:I

    .line 169
    new-instance v0, Lnet/duceng/xmidi/widgets/MusicScore$3;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/widgets/MusicScore$3;-><init>(Lnet/duceng/xmidi/widgets/MusicScore;)V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->onGestureListener:Landroid/view/GestureDetector$OnGestureListener;

    .line 176
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->init()V

    .line 177
    return-void
.end method

.method static AddLyricsToStaffs(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Staff;",
            ">;",
            "Ljava/util/ArrayList<",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/LyricSymbol;",
            ">;>;)V"
        }
    .end annotation

    .line 667
    .local p0, "staffs":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Staff;>;"
    .local p1, "tracklyrics":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/LyricSymbol;>;>;"
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/xmidi/widgets/score/Staff;

    .line 668
    .local v1, "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Staff;->getTrack()I

    move-result v2

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/ArrayList;

    .line 669
    .local v2, "lyrics":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/LyricSymbol;>;"
    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/widgets/score/Staff;->addLyrics(Ljava/util/ArrayList;)V

    .line 670
    .end local v1    # "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    .end local v2    # "lyrics":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/LyricSymbol;>;"
    goto :goto_0

    .line 671
    :cond_0
    return-void
.end method

.method private static CreateAllBeamedChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;)V
    .locals 6
    .param p1, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;>;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            ")V"
        }
    .end annotation

    .line 546
    .local p0, "allsymbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;>;"
    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-ne v0, v4, :cond_0

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getDenominator()I

    move-result v0

    if-eq v0, v1, :cond_2

    :cond_0
    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v0

    if-ne v0, v2, :cond_1

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getDenominator()I

    move-result v0

    const/16 v5, 0x8

    if-eq v0, v5, :cond_2

    :cond_1
    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v0

    if-ne v0, v2, :cond_3

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getDenominator()I

    move-result v0

    if-ne v0, v1, :cond_3

    .line 547
    :cond_2
    invoke-static {p0, p1, v2, v3}, Lnet/duceng/xmidi/widgets/MusicScore;->CreateBeamedChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;IZ)V

    .line 549
    :cond_3
    invoke-static {p0, p1, v4, v3}, Lnet/duceng/xmidi/widgets/MusicScore;->CreateBeamedChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;IZ)V

    .line 550
    invoke-static {p0, p1, v1, v3}, Lnet/duceng/xmidi/widgets/MusicScore;->CreateBeamedChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;IZ)V

    .line 551
    const/4 v0, 0x2

    invoke-static {p0, p1, v0, v3}, Lnet/duceng/xmidi/widgets/MusicScore;->CreateBeamedChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;IZ)V

    .line 552
    const/4 v1, 0x0

    invoke-static {p0, p1, v0, v1}, Lnet/duceng/xmidi/widgets/MusicScore;->CreateBeamedChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;IZ)V

    .line 553
    return-void
.end method

.method private static CreateBeamedChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;IZ)V
    .locals 8
    .param p1, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .param p2, "numChords"    # I
    .param p3, "startBeat"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;>;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            "IZ)V"
        }
    .end annotation

    .line 522
    .local p0, "allsymbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;>;"
    new-array v0, p2, [I

    .line 523
    .local v0, "chordIndexes":[I
    new-array v1, p2, [Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    .line 524
    .local v1, "chords":[Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    .end local v0    # "chordIndexes":[I
    .end local v1    # "chords":[Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    .end local p0    # "allsymbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;>;"
    .end local p1    # "time":Lnet/duceng/xmidi/widgets/score/MidiTime;
    .end local p2    # "numChords":I
    .end local p3    # "startBeat":Z
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    move-object v2, p0

    check-cast v2, Ljava/util/ArrayList;

    .line 525
    .local v2, "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    const/4 p0, 0x0

    .line 527
    .end local v2    # "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    .local p0, "startIndex":I
    :goto_0
    new-instance v3, Lnet/duceng/xmidi/widgets/BoxedInt;

    invoke-direct {v3}, Lnet/duceng/xmidi/widgets/BoxedInt;-><init>()V

    .line 528
    .local v3, "horizDistance":Lnet/duceng/xmidi/widgets/BoxedInt;
    const/4 v4, 0x0

    iput v4, v3, Lnet/duceng/xmidi/widgets/BoxedInt;->value:I

    .line 529
    invoke-static {v2, p1, p0, v0, v3}, Lnet/duceng/xmidi/widgets/MusicScore;->FindConsecutiveChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;I[ILnet/duceng/xmidi/widgets/BoxedInt;)Z

    move-result v5

    .line 530
    .local v5, "found":Z
    if-eqz v5, :cond_2

    .line 531
    const/4 v6, 0x0

    .local v6, "i":I
    :goto_1
    if-ge v6, p2, :cond_0

    .line 532
    aget v7, v0, v6

    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    aput-object v7, v1, v6

    .line 531
    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    .line 534
    .end local v6    # "i":I
    :cond_0
    invoke-static {v1, p1, p3}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->CanCreateBeam([Lnet/duceng/xmidi/widgets/score/ChordSymbol;Lnet/duceng/xmidi/widgets/score/MidiTime;Z)Z

    move-result v6

    if-eqz v6, :cond_1

    .line 535
    iget v4, v3, Lnet/duceng/xmidi/widgets/BoxedInt;->value:I

    invoke-static {v1, v4}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->CreateBeam([Lnet/duceng/xmidi/widgets/score/ChordSymbol;I)V

    .line 536
    add-int/lit8 v4, p2, -0x1

    aget v4, v0, v4

    add-int/lit8 v4, v4, 0x1

    move p0, v4

    .end local p0    # "startIndex":I
    .local v4, "startIndex":I
    goto :goto_2

    .line 538
    .end local v4    # "startIndex":I
    .restart local p0    # "startIndex":I
    :cond_1
    aget v4, v0, v4

    add-int/lit8 v4, v4, 0x1

    move p0, v4

    .line 541
    .end local v3    # "horizDistance":Lnet/duceng/xmidi/widgets/BoxedInt;
    .end local v5    # "found":Z
    :cond_2
    :goto_2
    goto :goto_0

    .line 543
    .local p0, "allsymbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;>;"
    :cond_3
    return-void
.end method

.method private CreateStaffs(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;I)Ljava/util/ArrayList;
    .locals 11
    .param p2, "key"    # Lnet/duceng/xmidi/widgets/score/MidiKey;
    .param p3, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .param p4, "measurelen"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;>;",
            "Lnet/duceng/xmidi/widgets/score/MidiKey;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            "I)",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Staff;",
            ">;"
        }
    .end annotation

    .line 602
    .local p1, "allsymbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;>;"
    new-instance v0, Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 603
    .local v0, "trackstaffs":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Staff;>;>;"
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v8

    .line 604
    .local v8, "totaltracks":I
    const/4 v1, 0x0

    move v9, v1

    .local v9, "track":I
    :goto_0
    if-ge v9, v8, :cond_0

    .line 605
    invoke-virtual {p1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v10, v1

    check-cast v10, Ljava/util/ArrayList;

    .line 606
    .local v10, "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    move-object v1, p0

    move-object v2, v10

    move v3, p4

    move-object v4, p2

    move-object v5, p3

    move v6, v9

    move v7, v8

    invoke-direct/range {v1 .. v7}, Lnet/duceng/xmidi/widgets/MusicScore;->CreateStaffsForTrack(Ljava/util/ArrayList;ILnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;II)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 604
    .end local v10    # "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    add-int/lit8 v9, v9, 0x1

    goto :goto_0

    .line 608
    .end local v9    # "track":I
    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/ArrayList;

    .line 609
    .local v2, "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Staff;>;"
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_2
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v4

    add-int/lit8 v4, v4, -0x1

    if-ge v3, v4, :cond_1

    .line 610
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/xmidi/widgets/score/Staff;

    add-int/lit8 v5, v3, 0x1

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Staff;->getStartTime()I

    move-result v5

    invoke-virtual {v4, v5}, Lnet/duceng/xmidi/widgets/score/Staff;->setEndTime(I)V

    .line 609
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    .line 612
    .end local v2    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Staff;>;"
    .end local v3    # "i":I
    :cond_1
    goto :goto_1

    .line 613
    :cond_2
    const/4 v1, 0x0

    .line 614
    .local v1, "maxstaffs":I
    const/4 v2, 0x0

    .local v2, "i2":I
    :goto_3
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_4

    .line 615
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_3

    .line 616
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v1

    .line 614
    :cond_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    .line 619
    .end local v2    # "i2":I
    :cond_4
    new-instance v2, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    mul-int v3, v3, v1

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 620
    .local v2, "result":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Staff;>;"
    const/4 v3, 0x0

    .local v3, "i3":I
    :goto_4
    if-ge v3, v1, :cond_7

    .line 621
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_5
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_6

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/ArrayList;

    .line 622
    .local v5, "list2":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Staff;>;"
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v3, v6, :cond_5

    .line 623
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 625
    .end local v5    # "list2":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Staff;>;"
    :cond_5
    goto :goto_5

    .line 620
    :cond_6
    add-int/lit8 v3, v3, 0x1

    goto :goto_4

    .line 627
    .end local v3    # "i3":I
    :cond_7
    return-object v2
.end method

.method private CreateStaffsForTrack(Ljava/util/ArrayList;ILnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;II)Ljava/util/ArrayList;
    .locals 19
    .param p2, "measurelen"    # I
    .param p3, "key"    # Lnet/duceng/xmidi/widgets/score/MidiKey;
    .param p4, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .param p5, "track"    # I
    .param p6, "totaltracks"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;I",
            "Lnet/duceng/xmidi/widgets/score/MidiKey;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            "II)",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Staff;",
            ">;"
        }
    .end annotation

    .line 568
    .local p1, "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-static/range {p3 .. p3}, Lnet/duceng/xmidi/widgets/MusicScore;->KeySignatureWidth(Lnet/duceng/xmidi/widgets/score/MidiKey;)I

    move-result v2

    .line 569
    .local v2, "keysigWidth":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->size()I

    move-result v4

    div-int/lit8 v4, v4, 0x32

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 570
    .local v3, "thestaffs":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Staff;>;"
    const/4 v4, 0x0

    .local v4, "startindex":I
    :goto_0
    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_4

    .line 571
    move v5, v4

    .line 572
    .local v5, "endindex2":I
    move v6, v2

    .line 573
    .local v6, "width":I
    iget-boolean v7, v0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollVert:Z

    if-eqz v7, :cond_0

    .line 574
    const/16 v7, 0x320

    .local v7, "maxwidth":I
    goto :goto_1

    .line 576
    .end local v7    # "maxwidth":I
    :cond_0
    const v7, 0x1e8480

    .line 578
    .restart local v7    # "maxwidth":I
    :goto_1
    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v5, v8, :cond_1

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v8}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v8

    add-int/2addr v8, v6

    if-ge v8, v7, :cond_1

    .line 579
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v8}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v8

    add-int/2addr v6, v8

    .line 580
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 582
    :cond_1
    add-int/lit8 v8, v5, -0x1

    .line 583
    .local v8, "endindex":I
    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->size()I

    move-result v9

    add-int/lit8 v9, v9, -0x1

    if-eq v8, v9, :cond_2

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v9}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v9

    div-int v9, v9, p2

    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v10}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v10

    div-int v10, v10, p2

    if-eq v9, v10, :cond_2

    .line 584
    add-int/lit8 v9, v8, 0x1

    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v9}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v9

    div-int v9, v9, p2

    .line 585
    .local v9, "endmeasure":I
    :goto_2
    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v10}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v10

    div-int v10, v10, p2

    if-ne v10, v9, :cond_2

    .line 586
    add-int/lit8 v8, v8, -0x1

    goto :goto_2

    .line 589
    .end local v9    # "endmeasure":I
    :cond_2
    nop

    .line 591
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 592
    .local v9, "staffSymbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    move v10, v4

    .local v10, "i":I
    :goto_3
    if-gt v10, v8, :cond_3

    .line 593
    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-virtual {v9, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 592
    add-int/lit8 v10, v10, 0x1

    goto :goto_3

    .line 595
    .end local v10    # "i":I
    :cond_3
    new-instance v18, Lnet/duceng/xmidi/widgets/score/Staff;

    iget-boolean v14, v0, Lnet/duceng/xmidi/widgets/MusicScore;->showMeasures:Z

    iget-boolean v15, v0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollVert:Z

    move-object/from16 v10, v18

    move-object v11, v9

    move-object/from16 v12, p3

    move-object/from16 v13, p4

    move/from16 v16, p5

    move/from16 v17, p6

    invoke-direct/range {v10 .. v17}, Lnet/duceng/xmidi/widgets/score/Staff;-><init>(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;ZZII)V

    .line 596
    .local v10, "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    invoke-virtual {v3, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 570
    .end local v5    # "endindex2":I
    .end local v6    # "width":I
    .end local v9    # "staffSymbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    .end local v10    # "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    add-int/lit8 v4, v8, 0x1

    goto/16 :goto_0

    .line 598
    .end local v4    # "startindex":I
    .end local v7    # "maxwidth":I
    .end local v8    # "endindex":I
    :cond_4
    return-object v3
.end method

.method private DrawTitle(Landroid/graphics/Canvas;)V
    .locals 3
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 754
    const-string v0, ".mid"

    const-string v1, ""

    const-string v2, "Title..."

    invoke-virtual {v2, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "_"

    const-string v2, " "

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    .line 755
    .local v0, "title":Ljava/lang/String;
    const/high16 v1, 0x41a00000    # 20.0f

    invoke-virtual {p1, v1, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 756
    const/4 v1, 0x0

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v1, v2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 757
    const/high16 v1, -0x3e600000    # -20.0f

    invoke-virtual {p1, v1, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 758
    return-void
.end method

.method private static FindConsecutiveChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;I[ILnet/duceng/xmidi/widgets/BoxedInt;)Z
    .locals 8
    .param p1, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .param p2, "startIndex"    # I
    .param p3, "chordIndexes"    # [I
    .param p4, "horizDistance"    # Lnet/duceng/xmidi/widgets/BoxedInt;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            "I[I",
            "Lnet/duceng/xmidi/widgets/BoxedInt;",
            ")Z"
        }
    .end annotation

    .line 481
    .local p0, "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    move v0, p2

    .line 482
    .local v0, "i":I
    array-length v1, p3

    .line 484
    .local v1, "numChords":I
    :cond_0
    const/4 v2, 0x0

    iput v2, p4, Lnet/duceng/xmidi/widgets/BoxedInt;->value:I

    .line 485
    :goto_0
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v3

    sub-int/2addr v3, v1

    if-ge v0, v3, :cond_2

    .line 486
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    instance-of v3, v3, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    if-eqz v3, :cond_1

    .line 487
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    .line 488
    .local v3, "c":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v4

    if-eqz v4, :cond_1

    .line 489
    goto :goto_1

    .line 492
    .end local v3    # "c":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 494
    :cond_2
    :goto_1
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v3

    sub-int/2addr v3, v1

    if-lt v0, v3, :cond_3

    .line 495
    const/4 v3, -0x1

    aput v3, p3, v2

    .line 496
    return v2

    .line 498
    :cond_3
    aput v0, p3, v2

    .line 499
    const/4 v3, 0x1

    .line 500
    .local v3, "foundChords":Z
    const/4 v4, 0x1

    .local v4, "chordIndex":I
    :goto_2
    if-ge v4, v1, :cond_7

    .line 501
    add-int/lit8 v0, v0, 0x1

    .line 502
    add-int/lit8 v5, v1, -0x1

    sub-int/2addr v5, v4

    .line 503
    .local v5, "remaining":I
    :goto_3
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v6

    sub-int/2addr v6, v5

    if-ge v0, v6, :cond_4

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    instance-of v6, v6, Lnet/duceng/xmidi/widgets/score/BlankSymbol;

    if-eqz v6, :cond_4

    .line 504
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v6}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v6

    iget v7, p4, Lnet/duceng/xmidi/widgets/BoxedInt;->value:I

    add-int/2addr v6, v7

    iput v6, p4, Lnet/duceng/xmidi/widgets/BoxedInt;->value:I

    .line 505
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    .line 507
    :cond_4
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v6

    sub-int/2addr v6, v5

    if-lt v0, v6, :cond_5

    .line 508
    return v2

    .line 510
    :cond_5
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    instance-of v6, v6, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    if-nez v6, :cond_6

    .line 511
    const/4 v3, 0x0

    .line 512
    goto :goto_4

    .line 514
    :cond_6
    aput v0, p3, v4

    .line 515
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v6}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v6

    iget v7, p4, Lnet/duceng/xmidi/widgets/BoxedInt;->value:I

    add-int/2addr v6, v7

    iput v6, p4, Lnet/duceng/xmidi/widgets/BoxedInt;->value:I

    .line 500
    .end local v5    # "remaining":I
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    .line 517
    .end local v4    # "chordIndex":I
    :cond_7
    :goto_4
    if-eqz v3, :cond_0

    .line 518
    const/4 v2, 0x1

    return v2
.end method

.method private GetRests(Lnet/duceng/xmidi/widgets/score/MidiTime;II)[Lnet/duceng/xmidi/widgets/score/RestSymbol;
    .locals 8
    .param p1, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .param p2, "start"    # I
    .param p3, "end"    # I

    .line 389
    sub-int v0, p3, p2

    const/4 v1, 0x0

    if-gez v0, :cond_0

    .line 390
    return-object v1

    .line 392
    :cond_0
    sub-int v0, p3, p2

    invoke-virtual {p1, v0}, Lnet/duceng/xmidi/widgets/score/MidiTime;->GetNoteDuration(I)Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v0

    .line 393
    .local v0, "dur":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    invoke-static {}, Lnet/duceng/xmidi/widgets/MusicScore;->$SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration()[I

    move-result-object v2

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v3

    aget v2, v2, v3

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    packed-switch v2, :pswitch_data_0

    .line 413
    return-object v1

    .line 409
    :pswitch_0
    new-instance v1, Lnet/duceng/xmidi/widgets/score/RestSymbol;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-direct {v1, p2, v2}, Lnet/duceng/xmidi/widgets/score/RestSymbol;-><init>(ILnet/duceng/xmidi/widgets/score/NoteDuration;)V

    .line 410
    .local v1, "r6":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    new-instance v2, Lnet/duceng/xmidi/widgets/score/RestSymbol;

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v6

    mul-int/lit8 v6, v6, 0x2

    add-int/2addr v6, p2

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-direct {v2, v6, v7}, Lnet/duceng/xmidi/widgets/score/RestSymbol;-><init>(ILnet/duceng/xmidi/widgets/score/NoteDuration;)V

    .line 411
    .local v2, "r7":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    new-array v5, v5, [Lnet/duceng/xmidi/widgets/score/RestSymbol;

    aput-object v1, v5, v3

    aput-object v2, v5, v4

    return-object v5

    .line 405
    .end local v1    # "r6":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    .end local v2    # "r7":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    :pswitch_1
    new-instance v1, Lnet/duceng/xmidi/widgets/score/RestSymbol;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-direct {v1, p2, v2}, Lnet/duceng/xmidi/widgets/score/RestSymbol;-><init>(ILnet/duceng/xmidi/widgets/score/NoteDuration;)V

    .line 406
    .local v1, "r4":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    new-instance v2, Lnet/duceng/xmidi/widgets/score/RestSymbol;

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v6

    add-int/2addr v6, p2

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-direct {v2, v6, v7}, Lnet/duceng/xmidi/widgets/score/RestSymbol;-><init>(ILnet/duceng/xmidi/widgets/score/NoteDuration;)V

    .line 407
    .local v2, "r5":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    new-array v5, v5, [Lnet/duceng/xmidi/widgets/score/RestSymbol;

    aput-object v1, v5, v3

    aput-object v2, v5, v4

    return-object v5

    .line 401
    .end local v1    # "r4":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    .end local v2    # "r5":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    :pswitch_2
    new-instance v1, Lnet/duceng/xmidi/widgets/score/RestSymbol;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-direct {v1, p2, v2}, Lnet/duceng/xmidi/widgets/score/RestSymbol;-><init>(ILnet/duceng/xmidi/widgets/score/NoteDuration;)V

    .line 402
    .local v1, "r2":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    new-instance v2, Lnet/duceng/xmidi/widgets/score/RestSymbol;

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v6

    div-int/2addr v6, v5

    add-int/2addr v6, p2

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-direct {v2, v6, v7}, Lnet/duceng/xmidi/widgets/score/RestSymbol;-><init>(ILnet/duceng/xmidi/widgets/score/NoteDuration;)V

    .line 403
    .local v2, "r3":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    new-array v5, v5, [Lnet/duceng/xmidi/widgets/score/RestSymbol;

    aput-object v1, v5, v3

    aput-object v2, v5, v4

    return-object v5

    .line 398
    .end local v1    # "r2":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    .end local v2    # "r3":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    :pswitch_3
    new-instance v1, Lnet/duceng/xmidi/widgets/score/RestSymbol;

    invoke-direct {v1, p2, v0}, Lnet/duceng/xmidi/widgets/score/RestSymbol;-><init>(ILnet/duceng/xmidi/widgets/score/NoteDuration;)V

    .line 399
    .local v1, "r1":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    new-array v2, v4, [Lnet/duceng/xmidi/widgets/score/RestSymbol;

    aput-object v1, v2, v3

    return-object v2

    :pswitch_data_0
    .packed-switch 0x4
        :pswitch_3
        :pswitch_2
        :pswitch_3
        :pswitch_1
        :pswitch_3
        :pswitch_0
        :pswitch_3
    .end packed-switch
.end method

.method public static KeySignatureWidth(Lnet/duceng/xmidi/widgets/score/MidiKey;)I
    .locals 7
    .param p0, "key"    # Lnet/duceng/xmidi/widgets/score/MidiKey;

    .line 556
    new-instance v0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;-><init>(Lnet/duceng/xmidi/widgets/score/Clef;IZ)V

    .line 557
    .local v0, "clefsym":Lnet/duceng/xmidi/widgets/score/ClefSymbol;
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->getMinWidth()I

    move-result v1

    .line 558
    .local v1, "result":I
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/widgets/score/MidiKey;->GetSymbols(Lnet/duceng/xmidi/widgets/score/Clef;)[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    move-result-object v3

    .line 559
    .local v3, "keys":[Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    array-length v4, v3

    :goto_0
    if-ge v2, v4, :cond_0

    aget-object v5, v3, v2

    .line 560
    .local v5, "symbol":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getMinWidth()I

    move-result v6

    add-int/2addr v1, v6

    .line 559
    .end local v5    # "symbol":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 562
    :cond_0
    add-int/lit8 v2, v1, 0x4

    add-int/lit8 v2, v2, 0x5

    return v2
.end method

.method private addBars(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;I)Ljava/util/ArrayList;
    .locals 5
    .param p2, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .param p3, "lastStart"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/ChordSymbol;",
            ">;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            "I)",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;"
        }
    .end annotation

    .line 344
    .local p1, "chords":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/ChordSymbol;>;"
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 345
    .local v0, "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    new-instance v1, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;

    invoke-virtual {p2}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v2

    invoke-virtual {p2}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getDenominator()I

    move-result v3

    invoke-direct {v1, v2, v3}, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;-><init>(II)V

    .line 346
    .local v1, "timesig":Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 347
    const/4 v2, 0x0

    .line 348
    .local v2, "measuretime":I
    const/4 v3, 0x0

    .line 349
    .local v3, "i":I
    :goto_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_1

    .line 350
    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStartTime()I

    move-result v4

    if-gt v2, v4, :cond_0

    .line 351
    new-instance v4, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    invoke-direct {v4, v2}, Lnet/duceng/xmidi/widgets/score/BarSymbol;-><init>(I)V

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 352
    invoke-virtual {p2}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getMeasure()I

    move-result v4

    add-int/2addr v2, v4

    goto :goto_0

    .line 354
    :cond_0
    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 355
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 358
    :cond_1
    :goto_1
    if-ge v2, p3, :cond_2

    .line 359
    new-instance v4, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    invoke-direct {v4, v2}, Lnet/duceng/xmidi/widgets/score/BarSymbol;-><init>(I)V

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 360
    invoke-virtual {p2}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getMeasure()I

    move-result v4

    add-int/2addr v2, v4

    goto :goto_1

    .line 362
    :cond_2
    new-instance v4, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    invoke-direct {v4, v2}, Lnet/duceng/xmidi/widgets/score/BarSymbol;-><init>(I)V

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 363
    return-object v0
.end method

.method private addClefChanges(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/ClefMeasures;Lnet/duceng/xmidi/widgets/score/MidiTime;)Ljava/util/ArrayList;
    .locals 8
    .param p2, "clefs"    # Lnet/duceng/xmidi/widgets/score/ClefMeasures;
    .param p3, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;",
            "Lnet/duceng/xmidi/widgets/score/ClefMeasures;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            ")",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;"
        }
    .end annotation

    .line 418
    .local p1, "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    new-instance v0, Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 419
    .local v0, "result":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    const/4 v1, 0x0

    invoke-virtual {p2, v1}, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->getClef(I)Lnet/duceng/xmidi/widgets/score/Clef;

    move-result-object v1

    .line 420
    .local v1, "prevclef":Lnet/duceng/xmidi/widgets/score/Clef;
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 421
    .local v3, "symbol":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    instance-of v4, v3, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    if-eqz v4, :cond_1

    .line 422
    invoke-interface {v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v4

    invoke-virtual {p2, v4}, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->getClef(I)Lnet/duceng/xmidi/widgets/score/Clef;

    move-result-object v4

    .line 423
    .local v4, "clef":Lnet/duceng/xmidi/widgets/score/Clef;
    if-eq v4, v1, :cond_0

    .line 424
    new-instance v5, Lnet/duceng/xmidi/widgets/score/ClefSymbol;

    invoke-interface {v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v6

    const/4 v7, 0x1

    sub-int/2addr v6, v7

    invoke-direct {v5, v4, v6, v7}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;-><init>(Lnet/duceng/xmidi/widgets/score/Clef;IZ)V

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 426
    :cond_0
    move-object v1, v4

    .line 428
    .end local v4    # "clef":Lnet/duceng/xmidi/widgets/score/Clef;
    :cond_1
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 429
    .end local v3    # "symbol":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    goto :goto_0

    .line 430
    :cond_2
    return-object v0
.end method

.method private addRests(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;)Ljava/util/ArrayList;
    .locals 9
    .param p2, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            ")",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;"
        }
    .end annotation

    .line 367
    .local p1, "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    const/4 v0, 0x0

    .line 368
    .local v0, "prevtime":I
    new-instance v1, Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 369
    .local v1, "result":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 370
    .local v3, "symbol":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    invoke-interface {v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v4

    .line 371
    .local v4, "starttime":I
    invoke-direct {p0, p2, v0, v4}, Lnet/duceng/xmidi/widgets/MusicScore;->GetRests(Lnet/duceng/xmidi/widgets/score/MidiTime;II)[Lnet/duceng/xmidi/widgets/score/RestSymbol;

    move-result-object v5

    .line 372
    .local v5, "rests":[Lnet/duceng/xmidi/widgets/score/RestSymbol;
    if-eqz v5, :cond_0

    .line 373
    array-length v6, v5

    const/4 v7, 0x0

    :goto_1
    if-ge v7, v6, :cond_0

    aget-object v8, v5, v7

    .line 374
    .local v8, "r":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 373
    .end local v8    # "r":Lnet/duceng/xmidi/widgets/score/RestSymbol;
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 377
    :cond_0
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 378
    instance-of v6, v3, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    if-eqz v6, :cond_1

    .line 379
    move-object v6, v3

    check-cast v6, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    .line 380
    .local v6, "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getEndTime()I

    move-result v7

    invoke-static {v7, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 381
    .end local v6    # "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    goto :goto_2

    .line 382
    :cond_1
    invoke-static {v4, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 384
    .end local v3    # "symbol":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .end local v4    # "starttime":I
    .end local v5    # "rests":[Lnet/duceng/xmidi/widgets/score/RestSymbol;
    :goto_2
    goto :goto_0

    .line 385
    :cond_2
    return-object v1
.end method

.method private alignSymbols(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/SymbolWidths;)V
    .locals 10
    .param p2, "widths"    # Lnet/duceng/xmidi/widgets/score/SymbolWidths;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;>;",
            "Lnet/duceng/xmidi/widgets/score/SymbolWidths;",
            ")V"
        }
    .end annotation

    .line 434
    .local p1, "allsymbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;>;"
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->showMeasures:Z

    if-eqz v0, :cond_2

    .line 435
    const/4 v0, 0x0

    .local v0, "track":I
    :goto_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    .line 436
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 437
    .local v2, "sym":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    instance-of v3, v2, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    if-eqz v3, :cond_0

    .line 438
    invoke-interface {v2}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v3

    add-int/lit8 v3, v3, 0xa

    invoke-interface {v2, v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->setWidth(I)V

    .line 440
    .end local v2    # "sym":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    :cond_0
    goto :goto_1

    .line 435
    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 443
    .end local v0    # "track":I
    :cond_2
    const/4 v0, 0x0

    .local v0, "track2":I
    :goto_2
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_a

    .line 444
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    .line 445
    .local v1, "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 446
    .local v2, "result":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    const/4 v3, 0x0

    .line 447
    .local v3, "i":I
    invoke-virtual {p2}, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->getStartTimes()[I

    move-result-object v4

    array-length v5, v4

    const/4 v6, 0x0

    const/4 v7, 0x0

    :goto_3
    if-ge v7, v5, :cond_6

    aget v8, v4, v7

    .line 448
    .local v8, "start":I
    :goto_4
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v3, v9, :cond_3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    instance-of v9, v9, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    if-eqz v9, :cond_3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v9}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v9

    if-gt v9, v8, :cond_3

    .line 449
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 450
    add-int/lit8 v3, v3, 0x1

    goto :goto_4

    .line 452
    :cond_3
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v3, v9, :cond_4

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v9}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v9

    if-ne v9, v8, :cond_4

    .line 453
    :goto_5
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v3, v9, :cond_5

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v9}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v9

    if-ne v9, v8, :cond_5

    .line 454
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 455
    add-int/lit8 v3, v3, 0x1

    goto :goto_5

    .line 458
    :cond_4
    new-instance v9, Lnet/duceng/xmidi/widgets/score/BlankSymbol;

    invoke-direct {v9, v8, v6}, Lnet/duceng/xmidi/widgets/score/BlankSymbol;-><init>(II)V

    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 447
    .end local v8    # "start":I
    :cond_5
    add-int/lit8 v7, v7, 0x1

    goto :goto_3

    .line 461
    :cond_6
    const/4 v4, 0x0

    .line 462
    .local v4, "i2":I
    :goto_6
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_9

    .line 463
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    instance-of v5, v5, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    if-eqz v5, :cond_7

    .line 464
    add-int/lit8 v4, v4, 0x1

    goto :goto_6

    .line 466
    :cond_7
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v5}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v5

    .line 467
    .local v5, "start2":I
    invoke-virtual {p2, v0, v5}, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->GetExtraWidth(II)I

    move-result v6

    .line 468
    .local v6, "extra":I
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v7}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v7

    add-int/2addr v7, v6

    .line 469
    .local v7, "newwidth":I
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v8, v7}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->setWidth(I)V

    .line 470
    :goto_7
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v4, v8, :cond_8

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v8}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v8

    if-ne v8, v5, :cond_8

    .line 471
    add-int/lit8 v4, v4, 0x1

    goto :goto_7

    .line 473
    .end local v5    # "start2":I
    .end local v6    # "extra":I
    .end local v7    # "newwidth":I
    :cond_8
    goto :goto_6

    .line 475
    :cond_9
    invoke-virtual {p1, v0, v2}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 443
    .end local v1    # "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    .end local v2    # "result":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    .end local v3    # "i":I
    .end local v4    # "i2":I
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_2

    .line 477
    .end local v0    # "track2":I
    :cond_a
    return-void
.end method

.method private calculateSize()V
    .locals 4

    .line 288
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewwidth:I

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->sheetwidth:I

    .line 289
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewheight:I

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->sheetheight:I

    .line 290
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    if-eqz v0, :cond_0

    .line 291
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->sheetwidth:I

    .line 292
    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->sheetheight:I

    .line 293
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/xmidi/widgets/score/Staff;

    .line 294
    .local v1, "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->sheetwidth:I

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Staff;->getWidth()I

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v2

    iput v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->sheetwidth:I

    .line 295
    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->sheetheight:I

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v3

    add-int/2addr v2, v3

    iput v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->sheetheight:I

    .line 296
    .end local v1    # "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    goto :goto_0

    .line 298
    :cond_0
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollVert:Z

    if-eqz v0, :cond_1

    .line 299
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewwidth:I

    int-to-float v0, v0

    const/high16 v1, 0x44480000    # 800.0f

    div-float/2addr v0, v1

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    goto :goto_1

    .line 301
    :cond_1
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewheight:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->sheetheight:I

    div-int/2addr v0, v1

    int-to-float v0, v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    .line 303
    :goto_1
    return-void
.end method

.method private checkScrollBounds()V
    .locals 4

    .line 944
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->sheetwidth:I

    int-to-float v0, v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    mul-float v0, v0, v1

    float-to-int v0, v0

    .line 945
    .local v0, "scrollwidth":I
    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->sheetheight:I

    int-to-float v1, v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    mul-float v1, v1, v2

    float-to-int v1, v1

    .line 946
    .local v1, "scrollheight":I
    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewwidth:I

    sub-int v3, v0, v3

    if-le v2, v3, :cond_0

    .line 947
    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewwidth:I

    sub-int v2, v0, v2

    iput v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    .line 949
    :cond_0
    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    iget v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewheight:I

    sub-int v3, v1, v3

    if-le v2, v3, :cond_1

    .line 950
    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewheight:I

    sub-int v2, v1, v2

    iput v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    .line 952
    :cond_1
    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    const/4 v3, 0x0

    if-gez v2, :cond_2

    .line 953
    iput v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    .line 955
    :cond_2
    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    if-gez v2, :cond_3

    .line 956
    iput v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    .line 958
    :cond_3
    return-void
.end method

.method private createChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;Lnet/duceng/xmidi/widgets/score/ClefMeasures;)Ljava/util/ArrayList;
    .locals 16
    .param p2, "key"    # Lnet/duceng/xmidi/widgets/score/MidiKey;
    .param p3, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .param p4, "clefs"    # Lnet/duceng/xmidi/widgets/score/ClefMeasures;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Note;",
            ">;",
            "Lnet/duceng/xmidi/widgets/score/MidiKey;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            "Lnet/duceng/xmidi/widgets/score/ClefMeasures;",
            ")",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/ChordSymbol;",
            ">;"
        }
    .end annotation

    .line 314
    .local p1, "midinotes":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;"
    move-object/from16 v0, p1

    const/4 v1, 0x0

    .line 315
    .local v1, "i":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 316
    .local v2, "chords":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/ChordSymbol;>;"
    new-instance v3, Ljava/util/TreeSet;

    invoke-direct {v3}, Ljava/util/TreeSet;-><init>()V

    .line 317
    .local v3, "groupset":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/xmidi/widgets/score/Note;>;"
    new-instance v4, Ljava/util/ArrayList;

    const/16 v5, 0xc

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 318
    .local v4, "notegroup":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;"
    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->size()I

    move-result v5

    .line 319
    .local v5, "len":I
    :goto_0
    if-ge v1, v5, :cond_1

    .line 320
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/Note;->getStartTick()I

    move-result v12

    .line 321
    .local v12, "startTick":I
    move-object/from16 v13, p4

    invoke-virtual {v13, v12}, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->getClef(I)Lnet/duceng/xmidi/widgets/score/Clef;

    move-result-object v14

    .line 322
    .local v14, "clef":Lnet/duceng/xmidi/widgets/score/Clef;
    invoke-virtual {v3}, Ljava/util/TreeSet;->clear()V

    .line 323
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v3, v6}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    .line 324
    add-int/lit8 v1, v1, 0x1

    .line 325
    :goto_1
    if-ge v1, v5, :cond_0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/Note;->getStartTick()I

    move-result v6

    if-ne v6, v12, :cond_0

    .line 326
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v3, v6}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    .line 327
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 329
    :cond_0
    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 330
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 331
    new-instance v15, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    move-object v6, v15

    move-object v7, v4

    move-object/from16 v8, p2

    move-object/from16 v9, p3

    move-object v10, v14

    move-object/from16 v11, p0

    invoke-direct/range {v6 .. v11}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;-><init>(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;Lnet/duceng/xmidi/widgets/score/Clef;Lnet/duceng/xmidi/widgets/MusicScore;)V

    .line 332
    .local v6, "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 333
    .end local v6    # "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    .end local v12    # "startTick":I
    .end local v14    # "clef":Lnet/duceng/xmidi/widgets/score/Clef;
    goto :goto_0

    .line 334
    :cond_1
    move-object/from16 v13, p4

    return-object v2
.end method

.method private createStaffs()V
    .locals 16

    .line 203
    move-object/from16 v0, p0

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->midiFile:Lnet/duceng/midi/MidiFile;

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-nez v1, :cond_0

    .line 204
    iput v2, v0, Lnet/duceng/xmidi/widgets/MusicScore;->showNoteLetters:I

    .line 205
    iput v4, v0, Lnet/duceng/xmidi/widgets/MusicScore;->numtracks:I

    .line 206
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    .line 207
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    new-instance v5, Lnet/duceng/xmidi/widgets/score/Staff;

    sget-object v6, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-direct {v5, v6, v2, v4}, Lnet/duceng/xmidi/widgets/score/Staff;-><init>(Lnet/duceng/xmidi/widgets/score/Clef;II)V

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 208
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    new-instance v2, Lnet/duceng/xmidi/widgets/score/Staff;

    sget-object v5, Lnet/duceng/xmidi/widgets/score/Clef;->Bass:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-direct {v2, v5, v3, v4}, Lnet/duceng/xmidi/widgets/score/Staff;-><init>(Lnet/duceng/xmidi/widgets/score/Clef;II)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 209
    return-void

    .line 211
    :cond_0
    const/4 v1, 0x0

    .line 212
    .local v1, "lastTick":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 213
    .local v5, "tracks":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;>;"
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 214
    .local v6, "tracksSum":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/Integer;>;"
    const/4 v7, 0x0

    .local v7, "k":I
    :goto_0
    iget-object v8, v0, Lnet/duceng/xmidi/widgets/MusicScore;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v8}, Lnet/duceng/midi/MidiFile;->getTracks()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v7, v8, :cond_b

    .line 215
    iget-object v8, v0, Lnet/duceng/xmidi/widgets/MusicScore;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v8}, Lnet/duceng/midi/MidiFile;->getTracks()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lnet/duceng/midi/MidiTrack;

    .line 216
    .local v8, "t":Lnet/duceng/midi/MidiTrack;
    iget-object v9, v0, Lnet/duceng/xmidi/widgets/MusicScore;->shows:[Z

    aget-boolean v9, v9, v7

    if-eqz v9, :cond_a

    .line 217
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 218
    .local v9, "notes":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;"
    const/4 v10, 0x0

    .line 219
    .local v10, "sum":I
    invoke-virtual {v8}, Lnet/duceng/midi/MidiTrack;->getEvents()Ljava/util/TreeSet;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_1
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_8

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lnet/duceng/midi/MidiEvent;

    .line 220
    .local v12, "e":Lnet/duceng/midi/MidiEvent;
    instance-of v13, v12, Lnet/duceng/midi/EventChannel;

    if-eqz v13, :cond_7

    .line 221
    move-object v13, v12

    check-cast v13, Lnet/duceng/midi/EventChannel;

    .line 222
    .local v13, "ec":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v14

    const/16 v15, 0x9

    if-ne v14, v15, :cond_2

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v14

    if-lez v14, :cond_2

    .line 223
    new-instance v14, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v15

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v4

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v3

    invoke-direct {v14, v15, v2, v4, v3}, Lnet/duceng/xmidi/widgets/score/Note;-><init>(IIBB)V

    move-object v3, v14

    .line 224
    .local v3, "note":Lnet/duceng/xmidi/widgets/score/Note;
    invoke-virtual {v9, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 225
    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v4

    add-int/2addr v10, v4

    .line 226
    .end local v3    # "note":Lnet/duceng/xmidi/widgets/score/Note;
    :cond_1
    goto :goto_3

    :cond_2
    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v3

    if-ne v3, v15, :cond_3

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v3

    if-eqz v3, :cond_4

    :cond_3
    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v3

    const/16 v4, 0x8

    if-ne v3, v4, :cond_1

    .line 227
    :cond_4
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    .local v3, "i":I
    :goto_2
    if-ltz v3, :cond_7

    .line 228
    invoke-virtual {v9, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/xmidi/widgets/score/Note;

    .line 229
    .local v4, "n":Lnet/duceng/xmidi/widgets/score/Note;
    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Note;->getChannel()B

    move-result v14

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v15

    if-ne v14, v15, :cond_6

    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v14

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v15

    if-ne v14, v15, :cond_6

    .line 230
    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Note;->getDuration()I

    move-result v14

    if-eqz v14, :cond_5

    .line 231
    goto :goto_3

    .line 233
    :cond_5
    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v14

    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Note;->getStartTick()I

    move-result v15

    sub-int/2addr v14, v15

    invoke-virtual {v4, v14}, Lnet/duceng/xmidi/widgets/score/Note;->setDuration(I)V

    .line 234
    goto :goto_3

    .line 227
    .end local v4    # "n":Lnet/duceng/xmidi/widgets/score/Note;
    :cond_6
    add-int/lit8 v3, v3, -0x1

    goto :goto_2

    .line 239
    .end local v3    # "i":I
    .end local v12    # "e":Lnet/duceng/midi/MidiEvent;
    .end local v13    # "ec":Lnet/duceng/midi/EventChannel;
    :cond_7
    :goto_3
    const/4 v3, 0x1

    const/4 v4, 0x2

    goto/16 :goto_1

    .line 240
    :cond_8
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_9

    .line 241
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 242
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 244
    :cond_9
    invoke-virtual {v8}, Lnet/duceng/midi/MidiTrack;->getLastTicks()I

    move-result v3

    if-le v3, v1, :cond_a

    .line 245
    invoke-virtual {v8}, Lnet/duceng/midi/MidiTrack;->getLastTicks()I

    move-result v1

    .line 214
    .end local v8    # "t":Lnet/duceng/midi/MidiTrack;
    .end local v9    # "notes":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;"
    .end local v10    # "sum":I
    :cond_a
    add-int/lit8 v7, v7, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto/16 :goto_0

    .line 249
    .end local v7    # "k":I
    :cond_b
    new-instance v3, Ljava/util/TreeSet;

    invoke-direct {v3}, Ljava/util/TreeSet;-><init>()V

    .line 250
    .local v3, "notesTreble":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/xmidi/widgets/score/Note;>;"
    new-instance v4, Ljava/util/TreeSet;

    invoke-direct {v4}, Ljava/util/TreeSet;-><init>()V

    .line 251
    .local v4, "notesBass":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/xmidi/widgets/score/Note;>;"
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v7

    const/4 v8, 0x2

    if-ne v7, v8, :cond_c

    .line 252
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    invoke-virtual {v3, v2}, Ljava/util/TreeSet;->addAll(Ljava/util/Collection;)Z

    .line 253
    const/4 v2, 0x1

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    invoke-virtual {v4, v2}, Ljava/util/TreeSet;->addAll(Ljava/util/Collection;)Z

    goto :goto_6

    .line 255
    :cond_c
    const/4 v2, 0x0

    .local v2, "i2":I
    :goto_4
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v2, v7, :cond_e

    .line 256
    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    div-int/2addr v7, v8

    const/16 v8, 0x3c

    if-le v7, v8, :cond_d

    .line 257
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Collection;

    invoke-virtual {v3, v7}, Ljava/util/TreeSet;->addAll(Ljava/util/Collection;)Z

    goto :goto_5

    .line 259
    :cond_d
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Collection;

    invoke-virtual {v4, v7}, Ljava/util/TreeSet;->addAll(Ljava/util/Collection;)Z

    .line 255
    :goto_5
    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    .line 263
    .end local v2    # "i2":I
    :cond_e
    :goto_6
    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    .line 264
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 265
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 266
    iget-object v2, v0, Lnet/duceng/xmidi/widgets/MusicScore;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v2}, Lnet/duceng/midi/MidiFile;->getTimeSignature()Lnet/duceng/midi/MetaTimeSignature;

    move-result-object v2

    .line 267
    .local v2, "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    invoke-static {v5}, Lnet/duceng/xmidi/widgets/score/MidiKey;->guess(Ljava/util/ArrayList;)Lnet/duceng/xmidi/widgets/score/MidiKey;

    move-result-object v7

    iput-object v7, v0, Lnet/duceng/xmidi/widgets/MusicScore;->mainkey:Lnet/duceng/xmidi/widgets/score/MidiKey;

    .line 268
    new-instance v7, Lnet/duceng/xmidi/widgets/score/MidiTime;

    invoke-virtual {v2}, Lnet/duceng/midi/MetaTimeSignature;->getNumerator()B

    move-result v8

    invoke-virtual {v2}, Lnet/duceng/midi/MetaTimeSignature;->getDenominator()B

    move-result v9

    int-to-double v9, v9

    const-wide/high16 v11, 0x4000000000000000L    # 2.0

    invoke-static {v11, v12, v9, v10}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v9

    double-to-int v9, v9

    iget-object v10, v0, Lnet/duceng/xmidi/widgets/MusicScore;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v10}, Lnet/duceng/midi/MidiFile;->getResolution()I

    move-result v10

    iget-object v11, v0, Lnet/duceng/xmidi/widgets/MusicScore;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v11}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v11

    invoke-virtual {v11}, Lnet/duceng/midi/MetaTempo;->getMpqn()I

    move-result v11

    invoke-direct {v7, v8, v9, v10, v11}, Lnet/duceng/xmidi/widgets/score/MidiTime;-><init>(IIII)V

    .line 269
    .local v7, "mainTime":Lnet/duceng/xmidi/widgets/score/MidiTime;
    new-instance v8, Ljava/util/ArrayList;

    const/4 v9, 0x2

    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 270
    .local v8, "allsymbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;>;"
    const/4 v10, 0x0

    .line 271
    .local v10, "i3":I
    :goto_7
    if-ge v10, v9, :cond_10

    .line 272
    new-instance v11, Lnet/duceng/xmidi/widgets/score/ClefMeasures;

    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/util/ArrayList;

    invoke-virtual {v7}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getMeasure()I

    move-result v13

    if-nez v10, :cond_f

    sget-object v14, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    goto :goto_8

    :cond_f
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Clef;->Bass:Lnet/duceng/xmidi/widgets/score/Clef;

    :goto_8
    invoke-direct {v11, v12, v13, v14}, Lnet/duceng/xmidi/widgets/score/ClefMeasures;-><init>(Ljava/util/ArrayList;ILnet/duceng/xmidi/widgets/score/Clef;)V

    .line 273
    .local v11, "clefs":Lnet/duceng/xmidi/widgets/score/ClefMeasures;
    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/util/ArrayList;

    iget-object v13, v0, Lnet/duceng/xmidi/widgets/MusicScore;->mainkey:Lnet/duceng/xmidi/widgets/score/MidiKey;

    invoke-direct {v0, v12, v13, v7, v11}, Lnet/duceng/xmidi/widgets/MusicScore;->createChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;Lnet/duceng/xmidi/widgets/score/ClefMeasures;)Ljava/util/ArrayList;

    move-result-object v12

    .line 274
    .local v12, "chords":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/ChordSymbol;>;"
    invoke-direct {v0, v12, v11, v7, v1}, Lnet/duceng/xmidi/widgets/MusicScore;->createSymbols(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/ClefMeasures;Lnet/duceng/xmidi/widgets/score/MidiTime;I)Ljava/util/ArrayList;

    move-result-object v13

    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 275
    nop

    .end local v11    # "clefs":Lnet/duceng/xmidi/widgets/score/ClefMeasures;
    .end local v12    # "chords":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/ChordSymbol;>;"
    add-int/lit8 v10, v10, 0x1

    .line 276
    goto :goto_7

    .line 277
    :cond_10
    new-instance v9, Lnet/duceng/xmidi/widgets/score/SymbolWidths;

    const/4 v11, 0x0

    invoke-direct {v9, v8, v11}, Lnet/duceng/xmidi/widgets/score/SymbolWidths;-><init>(Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    .line 278
    .local v9, "widths":Lnet/duceng/xmidi/widgets/score/SymbolWidths;
    invoke-direct {v0, v8, v9}, Lnet/duceng/xmidi/widgets/MusicScore;->alignSymbols(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/SymbolWidths;)V

    .line 279
    iget-object v11, v0, Lnet/duceng/xmidi/widgets/MusicScore;->mainkey:Lnet/duceng/xmidi/widgets/score/MidiKey;

    invoke-virtual {v7}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getMeasure()I

    move-result v12

    invoke-direct {v0, v8, v11, v7, v12}, Lnet/duceng/xmidi/widgets/MusicScore;->CreateStaffs(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;I)Ljava/util/ArrayList;

    move-result-object v11

    iput-object v11, v0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    .line 280
    invoke-static {v8, v7}, Lnet/duceng/xmidi/widgets/MusicScore;->CreateAllBeamedChords(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;)V

    .line 281
    iget-object v11, v0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_9
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_11

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lnet/duceng/xmidi/widgets/score/Staff;

    .line 282
    .local v12, "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    invoke-virtual {v12}, Lnet/duceng/xmidi/widgets/score/Staff;->CalculateHeight()V

    .line 283
    .end local v12    # "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    goto :goto_9

    .line 284
    :cond_11
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 285
    return-void
.end method

.method private createSymbols(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/ClefMeasures;Lnet/duceng/xmidi/widgets/score/MidiTime;I)Ljava/util/ArrayList;
    .locals 2
    .param p2, "clefs"    # Lnet/duceng/xmidi/widgets/score/ClefMeasures;
    .param p3, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .param p4, "lastStart"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/ChordSymbol;",
            ">;",
            "Lnet/duceng/xmidi/widgets/score/ClefMeasures;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            "I)",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;"
        }
    .end annotation

    .line 338
    .local p1, "chords":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/ChordSymbol;>;"
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 339
    invoke-direct {p0, p1, p3, p4}, Lnet/duceng/xmidi/widgets/MusicScore;->addBars(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;I)Ljava/util/ArrayList;

    move-result-object v0

    .line 340
    .local v0, "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    invoke-direct {p0, v0, p3}, Lnet/duceng/xmidi/widgets/MusicScore;->addRests(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiTime;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-direct {p0, v1, p2, p3}, Lnet/duceng/xmidi/widgets/MusicScore;->addClefChanges(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/ClefMeasures;Lnet/duceng/xmidi/widgets/score/MidiTime;)Ljava/util/ArrayList;

    move-result-object v1

    return-object v1
.end method

.method private drawToBuffer(II)V
    .locals 9
    .param p1, "left"    # I
    .param p2, "top"    # I

    .line 723
    iput p1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    .line 724
    iput p2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    .line 725
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    neg-int v1, v1

    int-to-float v1, v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    neg-int v2, v2

    int-to-float v2, v2

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 726
    new-instance v0, Landroid/graphics/Rect;

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    iget v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v4

    add-int/2addr v3, v4

    iget v4, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    add-int/2addr v4, v5

    invoke-direct {v0, v1, v2, v3, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 727
    .local v0, "clip":Landroid/graphics/Rect;
    iget v1, v0, Landroid/graphics/Rect;->left:I

    int-to-float v1, v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    div-float/2addr v1, v2

    float-to-int v1, v1

    iput v1, v0, Landroid/graphics/Rect;->left:I

    .line 728
    iget v1, v0, Landroid/graphics/Rect;->top:I

    int-to-float v1, v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    div-float/2addr v1, v2

    float-to-int v1, v1

    iput v1, v0, Landroid/graphics/Rect;->top:I

    .line 729
    iget v1, v0, Landroid/graphics/Rect;->right:I

    int-to-float v1, v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    div-float/2addr v1, v2

    float-to-int v1, v1

    iput v1, v0, Landroid/graphics/Rect;->right:I

    .line 730
    iget v1, v0, Landroid/graphics/Rect;->bottom:I

    int-to-float v1, v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    div-float/2addr v1, v2

    float-to-int v1, v1

    iput v1, v0, Landroid/graphics/Rect;->bottom:I

    .line 731
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    iget v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Canvas;->scale(FF)V

    .line 732
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 733
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 734
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    const/4 v2, -0x1

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 735
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    iget v1, v0, Landroid/graphics/Rect;->left:I

    int-to-float v4, v1

    iget v1, v0, Landroid/graphics/Rect;->top:I

    int-to-float v5, v1

    iget v1, v0, Landroid/graphics/Rect;->right:I

    int-to-float v6, v1

    iget v1, v0, Landroid/graphics/Rect;->bottom:I

    int-to-float v7, v1

    iget-object v8, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 736
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 737
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    const/high16 v2, -0x1000000

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 738
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    if-eqz v1, :cond_1

    .line 739
    const/4 v1, 0x0

    .line 740
    .local v1, "ypos":I
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/Staff;

    .line 741
    .local v3, "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v4

    add-int/2addr v4, v1

    iget v5, v0, Landroid/graphics/Rect;->top:I

    if-lt v4, v5, :cond_0

    iget v4, v0, Landroid/graphics/Rect;->bottom:I

    if-gt v1, v4, :cond_0

    .line 742
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    int-to-float v5, v1

    const/4 v6, 0x0

    invoke-virtual {v4, v6, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 743
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    invoke-virtual {v3, v4, v0, v5}, Lnet/duceng/xmidi/widgets/score/Staff;->draw(Landroid/graphics/Canvas;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 744
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    neg-int v5, v1

    int-to-float v5, v5

    invoke-virtual {v4, v6, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 746
    :cond_0
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v4

    add-int/2addr v1, v4

    .line 747
    .end local v3    # "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    goto :goto_0

    .line 749
    .end local v1    # "ypos":I
    :cond_1
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    const/high16 v3, 0x3f800000    # 1.0f

    div-float v2, v3, v2

    iget v4, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    div-float/2addr v3, v4

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Canvas;->scale(FF)V

    .line 750
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    int-to-float v2, v2

    iget v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    int-to-float v3, v3

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Canvas;->translate(FF)V

    .line 751
    return-void
.end method

.method private init()V
    .locals 4

    .line 180
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->LoadImages(Landroid/content/Context;)V

    .line 181
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->LoadImages(Landroid/content/Context;)V

    .line 182
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->holder:Landroid/view/SurfaceHolder;

    .line 183
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v0, p0}, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V

    .line 184
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->holder:Landroid/view/SurfaceHolder;

    const/4 v1, 0x4

    invoke-interface {v0, v1}, Landroid/view/SurfaceHolder;->setFormat(I)V

    .line 185
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    .line 186
    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    .line 187
    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    .line 188
    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    .line 189
    new-instance v1, Landroid/view/GestureDetector;

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->getContext()Landroid/content/Context;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->onGestureListener:Landroid/view/GestureDetector$OnGestureListener;

    invoke-direct {v1, v2, v3}, Landroid/view/GestureDetector;-><init>(Landroid/content/Context;Landroid/view/GestureDetector$OnGestureListener;)V

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->gestureDetector:Landroid/view/GestureDetector;

    .line 190
    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1}, Landroid/graphics/Paint;-><init>()V

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    .line 191
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    const/high16 v2, 0x41400000    # 12.0f

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 192
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    const/high16 v2, -0x1000000

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 193
    iput-boolean v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollVert:Z

    .line 194
    const/4 v0, 0x1

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->showNoteLetters:I

    .line 195
    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->numtracks:I

    .line 196
    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    .line 197
    const/16 v0, 0xd2

    invoke-static {v0, v0, v0}, Landroid/graphics/Color;->rgb(III)I

    move-result v0

    const/16 v1, 0xc8

    const/16 v2, 0xdc

    const/16 v3, 0x96

    invoke-static {v3, v1, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {p0, v2, v0, v1}, Lnet/duceng/xmidi/widgets/MusicScore;->setColors([III)V

    .line 198
    iput-object v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->midiFile:Lnet/duceng/midi/MidiFile;

    .line 199
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->createStaffs()V

    .line 200
    return-void
.end method

.method private isScrollPositionInBuffer()Z
    .locals 3

    .line 719
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    if-lt v0, v1, :cond_0

    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    if-lt v0, v1, :cond_0

    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v2

    add-int/2addr v1, v2

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewheight:I

    sub-int/2addr v1, v2

    if-gt v0, v1, :cond_0

    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    add-int/2addr v1, v2

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewwidth:I

    sub-int/2addr v1, v2

    if-gt v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method


# virtual methods
.method public DrawPage(Landroid/graphics/Canvas;I)V
    .locals 11
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "pagenumber"    # I

    .line 789
    new-instance v0, Landroid/graphics/Rect;

    const/16 v1, 0x348

    const/16 v2, 0x442

    const/4 v3, 0x0

    invoke-direct {v0, v3, v3, v1, v2}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 790
    .local v0, "clip":Landroid/graphics/Rect;
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 791
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 792
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    const/4 v3, -0x1

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 793
    iget v1, v0, Landroid/graphics/Rect;->left:I

    int-to-float v4, v1

    iget v1, v0, Landroid/graphics/Rect;->top:I

    int-to-float v5, v1

    iget v1, v0, Landroid/graphics/Rect;->right:I

    int-to-float v6, v1

    iget v1, v0, Landroid/graphics/Rect;->bottom:I

    int-to-float v7, v1

    iget-object v8, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    move-object v3, p1

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 794
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 795
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    const/high16 v3, -0x1000000

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 796
    const/16 v1, 0xe

    .line 797
    .local v1, "ypos3":I
    const/4 v3, 0x1

    .line 798
    .local v3, "pagenum":I
    const/4 v4, 0x0

    .line 799
    .local v4, "staffnum":I
    iget v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->numtracks:I

    const/high16 v6, -0x3e600000    # -20.0f

    const/high16 v7, 0x41a00000    # 20.0f

    const/16 v8, 0x41a

    const/4 v9, 0x2

    if-ne v5, v9, :cond_3

    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    rem-int/2addr v5, v9

    if-nez v5, :cond_3

    .line 800
    :goto_0
    add-int/lit8 v5, v4, 0x1

    iget-object v9, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v5, v9, :cond_1

    if-ge v3, p2, :cond_1

    .line 801
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v5

    iget-object v9, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    add-int/lit8 v10, v4, 0x1

    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v9}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v9

    add-int/2addr v5, v9

    .line 802
    .local v5, "heights":I
    add-int v9, v1, v5

    if-lt v9, v8, :cond_0

    .line 803
    add-int/lit8 v3, v3, 0x1

    .line 804
    const/4 v1, 0x0

    goto :goto_1

    .line 806
    :cond_0
    add-int/2addr v1, v5

    .line 807
    add-int/lit8 v4, v4, 0x2

    .line 809
    .end local v5    # "heights":I
    :goto_1
    goto :goto_0

    .line 810
    :cond_1
    if-ne v3, v2, :cond_2

    .line 811
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/widgets/MusicScore;->DrawTitle(Landroid/graphics/Canvas;)V

    .line 812
    const/16 v2, 0xe

    .local v2, "ypos2":I
    goto :goto_2

    .line 814
    .end local v2    # "ypos2":I
    :cond_2
    const/4 v2, 0x0

    .line 816
    .restart local v2    # "ypos2":I
    :goto_2
    add-int/lit8 v5, v4, 0x1

    iget-object v9, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v5, v9, :cond_7

    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v5

    add-int/2addr v5, v2

    iget-object v9, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    add-int/lit8 v10, v4, 0x1

    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v9}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v9

    add-int/2addr v5, v9

    if-ge v5, v8, :cond_7

    .line 817
    add-int/lit8 v5, v2, 0x14

    int-to-float v5, v5

    invoke-virtual {p1, v7, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 818
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Staff;

    iget-object v9, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    invoke-virtual {v5, p1, v0, v9}, Lnet/duceng/xmidi/widgets/score/Staff;->draw(Landroid/graphics/Canvas;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 819
    add-int/lit8 v5, v2, 0x14

    neg-int v5, v5

    int-to-float v5, v5

    invoke-virtual {p1, v6, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 820
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v5

    add-int/2addr v5, v2

    .line 821
    .local v5, "ypos4":I
    add-int/lit8 v9, v5, 0x14

    int-to-float v9, v9

    invoke-virtual {p1, v7, v9}, Landroid/graphics/Canvas;->translate(FF)V

    .line 822
    iget-object v9, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    add-int/lit8 v10, v4, 0x1

    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/xmidi/widgets/score/Staff;

    iget-object v10, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    invoke-virtual {v9, p1, v0, v10}, Lnet/duceng/xmidi/widgets/score/Staff;->draw(Landroid/graphics/Canvas;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 823
    add-int/lit8 v9, v5, 0x14

    neg-int v9, v9

    int-to-float v9, v9

    invoke-virtual {p1, v6, v9}, Landroid/graphics/Canvas;->translate(FF)V

    .line 824
    iget-object v9, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    add-int/lit8 v10, v4, 0x1

    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v9}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v9

    add-int v2, v5, v9

    .line 825
    nop

    .end local v5    # "ypos4":I
    add-int/lit8 v4, v4, 0x2

    .line 826
    goto :goto_2

    .line 828
    .end local v2    # "ypos2":I
    :cond_3
    :goto_3
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_5

    if-ge v3, p2, :cond_5

    .line 829
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v5

    add-int/2addr v5, v1

    if-lt v5, v8, :cond_4

    .line 830
    add-int/lit8 v3, v3, 0x1

    .line 831
    const/4 v1, 0x0

    goto :goto_3

    .line 833
    :cond_4
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v5

    add-int/2addr v1, v5

    .line 834
    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    .line 837
    :cond_5
    if-ne v3, v2, :cond_6

    .line 838
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/widgets/MusicScore;->DrawTitle(Landroid/graphics/Canvas;)V

    .line 839
    const/16 v2, 0xe

    .local v2, "ypos":I
    goto :goto_4

    .line 841
    .end local v2    # "ypos":I
    :cond_6
    const/4 v2, 0x0

    .line 843
    .restart local v2    # "ypos":I
    :goto_4
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_7

    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v5

    add-int/2addr v5, v2

    if-ge v5, v8, :cond_7

    .line 844
    add-int/lit8 v5, v2, 0x14

    int-to-float v5, v5

    invoke-virtual {p1, v7, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 845
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Staff;

    iget-object v9, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    invoke-virtual {v5, p1, v0, v9}, Lnet/duceng/xmidi/widgets/score/Staff;->draw(Landroid/graphics/Canvas;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 846
    add-int/lit8 v5, v2, 0x14

    neg-int v5, v5

    int-to-float v5, v5

    invoke-virtual {p1, v6, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 847
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v5

    add-int/2addr v2, v5

    .line 848
    add-int/lit8 v4, v4, 0x1

    goto :goto_4

    .line 851
    .end local v2    # "ypos":I
    :cond_7
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const v5, 0x44844000    # 1058.0f

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    const/high16 v7, 0x44430000    # 780.0f

    invoke-virtual {p1, v2, v7, v5, v6}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 852
    return-void
.end method

.method public GetTotalPages()I
    .locals 7

    .line 761
    const/4 v0, 0x1

    .line 762
    .local v0, "num":I
    const/16 v1, 0xe

    .line 763
    .local v1, "currheight":I
    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->numtracks:I

    const/16 v3, 0x41a

    const/4 v4, 0x2

    if-ne v2, v4, :cond_2

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    rem-int/2addr v2, v4

    if-nez v2, :cond_2

    .line 764
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_1

    .line 765
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v4

    iget-object v5, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    add-int/lit8 v6, v2, 0x1

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Staff;

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v5

    add-int/2addr v4, v5

    .line 766
    .local v4, "heights":I
    add-int v5, v1, v4

    if-le v5, v3, :cond_0

    .line 767
    add-int/lit8 v0, v0, 0x1

    .line 768
    move v1, v4

    goto :goto_1

    .line 770
    :cond_0
    add-int/2addr v1, v4

    .line 764
    .end local v4    # "heights":I
    :goto_1
    add-int/lit8 v2, v2, 0x2

    goto :goto_0

    .end local v2    # "i":I
    :cond_1
    goto :goto_4

    .line 774
    :cond_2
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/xmidi/widgets/score/Staff;

    .line 775
    .local v4, "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v5

    add-int/2addr v5, v1

    if-le v5, v3, :cond_3

    .line 776
    add-int/lit8 v0, v0, 0x1

    .line 777
    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v1

    goto :goto_3

    .line 779
    :cond_3
    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v5

    add-int/2addr v1, v5

    .line 781
    .end local v4    # "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    :goto_3
    goto :goto_2

    .line 783
    :cond_4
    :goto_4
    return v0
.end method

.method public NoteColor(I)I
    .locals 2
    .param p1, "number"    # I

    .line 647
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->NoteColors:[I

    invoke-static {p1}, Lnet/duceng/xmidi/widgets/score/NoteScale;->FromNumber(I)I

    move-result v1

    aget v0, v0, v1

    return v0
.end method

.method public PulseTimeForPoint(Landroid/graphics/Point;)I
    .locals 6
    .param p1, "point"    # Landroid/graphics/Point;

    .line 932
    new-instance v0, Landroid/graphics/Point;

    iget v1, p1, Landroid/graphics/Point;->x:I

    int-to-float v1, v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    div-float/2addr v1, v2

    float-to-int v1, v1

    iget v2, p1, Landroid/graphics/Point;->y:I

    int-to-float v2, v2

    iget v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    div-float/2addr v2, v3

    float-to-int v2, v2

    invoke-direct {v0, v1, v2}, Landroid/graphics/Point;-><init>(II)V

    .line 933
    .local v0, "scaledPoint":Landroid/graphics/Point;
    const/4 v1, 0x0

    .line 934
    .local v1, "y":I
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/Staff;

    .line 935
    .local v3, "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    iget v4, v0, Landroid/graphics/Point;->y:I

    if-lt v4, v1, :cond_0

    iget v4, v0, Landroid/graphics/Point;->y:I

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v5

    add-int/2addr v5, v1

    if-gt v4, v5, :cond_0

    .line 936
    invoke-virtual {v3, v0}, Lnet/duceng/xmidi/widgets/score/Staff;->PulseTimeForPoint(Landroid/graphics/Point;)I

    move-result v2

    return v2

    .line 938
    :cond_0
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v4

    add-int/2addr v1, v4

    .line 939
    .end local v3    # "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    goto :goto_0

    .line 940
    :cond_1
    const/4 v2, -0x1

    return v2
.end method

.method createBufferCanvas()V
    .locals 3

    .line 674
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    .line 675
    const/4 v0, 0x0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    .line 676
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 677
    iput-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    .line 678
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 680
    :cond_0
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollVert:Z

    if-eqz v0, :cond_1

    .line 681
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewwidth:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewheight:I

    int-to-float v1, v1

    const v2, 0x3f99999a    # 1.2f

    mul-float v1, v1, v2

    float-to-int v1, v1

    sget-object v2, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;

    invoke-static {v0, v1, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    goto :goto_0

    .line 683
    :cond_1
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewwidth:I

    int-to-float v0, v0

    const/high16 v1, 0x3fc00000    # 1.5f

    mul-float v0, v0, v1

    float-to-int v0, v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewheight:I

    sget-object v2, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;

    invoke-static {v0, v1, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    .line 685
    :goto_0
    new-instance v0, Landroid/graphics/Canvas;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    invoke-direct {v0, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    .line 686
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    invoke-direct {p0, v0, v1}, Lnet/duceng/xmidi/widgets/MusicScore;->drawToBuffer(II)V

    .line 687
    return-void
.end method

.method public draw()V
    .locals 3

    .line 691
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->surfaceReady:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v0}, Landroid/view/SurfaceHolder;->lockCanvas()Landroid/graphics/Canvas;

    move-result-object v0

    move-object v1, v0

    .local v1, "canvas":Landroid/graphics/Canvas;
    if-eqz v0, :cond_0

    .line 692
    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/widgets/MusicScore;->draw(Landroid/graphics/Canvas;)V

    .line 693
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v0, v1}, Landroid/view/SurfaceHolder;->unlockCanvasAndPost(Landroid/graphics/Canvas;)V

    .line 694
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->currentTicks:I

    if-lez v0, :cond_0

    .line 695
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->currentTicks:I

    const/4 v2, 0x0

    invoke-virtual {p0, v0, v2, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->shadeNotes(III)V

    .line 698
    .end local v1    # "canvas":Landroid/graphics/Canvas;
    :cond_0
    return-void
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 3
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 702
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    if-nez v0, :cond_0

    .line 703
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->createBufferCanvas()V

    .line 705
    :cond_0
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->isScrollPositionInBuffer()Z

    move-result v0

    if-nez v0, :cond_1

    .line 706
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    invoke-direct {p0, v0, v1}, Lnet/duceng/xmidi/widgets/MusicScore;->drawToBuffer(II)V

    .line 708
    :cond_1
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    sub-int/2addr v0, v1

    neg-int v0, v0

    int-to-float v0, v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    sub-int/2addr v1, v2

    neg-int v1, v1

    int-to-float v1, v1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 709
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v2, v2, v1}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 710
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    sub-int/2addr v0, v1

    int-to-float v0, v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    sub-int/2addr v1, v2

    int-to-float v1, v1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 711
    return-void
.end method

.method public getMainKey()Lnet/duceng/xmidi/widgets/score/MidiKey;
    .locals 1

    .line 663
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->mainkey:Lnet/duceng/xmidi/widgets/score/MidiKey;

    return-object v0
.end method

.method public getScrollVert()Z
    .locals 1

    .line 976
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollVert:Z

    return v0
.end method

.method public getShade1()I
    .locals 1

    .line 651
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->shade1:I

    return v0
.end method

.method public getShade2()I
    .locals 1

    .line 655
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->shade2:I

    return v0
.end method

.method public getShowNoteLetters()I
    .locals 1

    .line 659
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->showNoteLetters:I

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 0
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 715
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/widgets/MusicScore;->draw(Landroid/graphics/Canvas;)V

    .line 716
    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 0
    .param p1, "newwidth"    # I
    .param p2, "newheight"    # I
    .param p3, "oldwidth"    # I
    .param p4, "oldheight"    # I

    .line 307
    iput p1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewwidth:I

    .line 308
    iput p2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewheight:I

    .line 309
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->calculateSize()V

    .line 310
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->createBufferCanvas()V

    .line 311
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 1
    .param p1, "event"    # Landroid/view/MotionEvent;

    .line 994
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->gestureDetector:Landroid/view/GestureDetector;

    invoke-virtual {v0, p1}, Landroid/view/GestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 995
    const/4 v0, 0x1

    return v0
.end method

.method scrollToShadedNotes(IIZ)V
    .locals 4
    .param p1, "x_shade"    # I
    .param p2, "y_shade"    # I
    .param p3, "scrollGradually"    # Z

    .line 905
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollVert:Z

    if-eqz v0, :cond_2

    .line 906
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    sub-int v0, p2, v0

    .line 907
    .local v0, "scrollDist":I
    if-eqz p3, :cond_1

    .line 908
    int-to-float v1, v0

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    const/high16 v3, 0x42040000    # 33.0f

    mul-float v2, v2, v3

    const/high16 v3, 0x41000000    # 8.0f

    mul-float v2, v2, v3

    cmpl-float v1, v1, v2

    if-lez v1, :cond_0

    .line 909
    div-int/lit8 v0, v0, 0x2

    goto :goto_0

    .line 910
    :cond_0
    int-to-float v1, v0

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    const/high16 v3, 0x42000000    # 32.0f

    mul-float v2, v2, v3

    cmpl-float v1, v1, v2

    if-lez v1, :cond_1

    .line 911
    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    mul-float v1, v1, v3

    float-to-int v0, v1

    .line 914
    :cond_1
    :goto_0
    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    add-int/2addr v1, v0

    iput v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    .line 915
    .end local v0    # "scrollDist":I
    goto :goto_2

    .line 916
    :cond_2
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewwidth:I

    mul-int/lit8 v1, v1, 0x28

    div-int/lit8 v1, v1, 0x64

    add-int/2addr v0, v1

    .line 917
    .local v0, "x_view":I
    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->viewwidth:I

    mul-int/lit8 v2, v2, 0x41

    div-int/lit8 v2, v2, 0x64

    add-int/2addr v1, v2

    .line 918
    .local v1, "xmax":I
    sub-int v2, p1, v0

    .line 919
    .local v2, "scrollDist2":I
    if-eqz p3, :cond_4

    .line 920
    if-le p1, v1, :cond_3

    .line 921
    sub-int v3, p1, v0

    div-int/lit8 v2, v3, 0x3

    goto :goto_1

    .line 922
    :cond_3
    if-le p1, v0, :cond_4

    .line 923
    sub-int v3, p1, v0

    div-int/lit8 v2, v3, 0x6

    .line 926
    :cond_4
    :goto_1
    iget v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    add-int/2addr v3, v2

    iput v3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    .line 928
    .end local v0    # "x_view":I
    .end local v1    # "xmax":I
    .end local v2    # "scrollDist2":I
    :goto_2
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->checkScrollBounds()V

    .line 929
    return-void
.end method

.method public scrollUpdate(II)V
    .locals 1
    .param p1, "deltaX"    # I
    .param p2, "deltaY"    # I

    .line 999
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    add-int/2addr v0, p1

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    .line 1000
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    add-int/2addr v0, p2

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    .line 1001
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->checkScrollBounds()V

    .line 1002
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->draw()V

    .line 1003
    return-void
.end method

.method public setColors([III)V
    .locals 4
    .param p1, "newcolors"    # [I
    .param p2, "newshade1"    # I
    .param p3, "newshade2"    # I

    .line 631
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->NoteColors:[I

    const/16 v1, 0xc

    if-nez v0, :cond_0

    .line 632
    new-array v0, v1, [I

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->NoteColors:[I

    .line 633
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    if-ge v0, v1, :cond_0

    .line 634
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->NoteColors:[I

    const/high16 v3, -0x1000000

    aput v3, v2, v0

    .line 633
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 637
    .end local v0    # "i":I
    :cond_0
    if-eqz p1, :cond_1

    .line 638
    const/4 v0, 0x0

    .local v0, "i2":I
    :goto_1
    if-ge v0, v1, :cond_1

    .line 639
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->NoteColors:[I

    aget v3, p1, v0

    aput v3, v2, v0

    .line 638
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 642
    .end local v0    # "i2":I
    :cond_1
    iput p2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->shade1:I

    .line 643
    iput p3, p0, Lnet/duceng/xmidi/widgets/MusicScore;->shade2:I

    .line 644
    return-void
.end method

.method public setMidiFile(Lnet/duceng/midi/MidiFile;[Z)V
    .locals 3
    .param p1, "file"    # Lnet/duceng/midi/MidiFile;
    .param p2, "s"    # [Z

    .line 961
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->midiFile:Lnet/duceng/midi/MidiFile;

    .line 962
    iput-object p2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->shows:[Z

    .line 963
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->createStaffs()V

    .line 964
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    .line 965
    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    .line 966
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->calculateSize()V

    .line 967
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v0}, Landroid/view/SurfaceHolder;->lockCanvas()Landroid/graphics/Canvas;

    move-result-object v0

    .line 968
    .local v0, "canvas":Landroid/graphics/Canvas;
    if-eqz v0, :cond_0

    .line 969
    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    invoke-direct {p0, v1, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->drawToBuffer(II)V

    .line 970
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/widgets/MusicScore;->draw(Landroid/graphics/Canvas;)V

    .line 971
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v1, v0}, Landroid/view/SurfaceHolder;->unlockCanvasAndPost(Landroid/graphics/Canvas;)V

    .line 973
    :cond_0
    return-void
.end method

.method public setScrollVert(Z)V
    .locals 2
    .param p1, "value"    # Z

    .line 980
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollVert:Z

    if-eq v0, p1, :cond_0

    .line 981
    iput-boolean p1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollVert:Z

    .line 982
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    .line 983
    iput v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    .line 984
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    if-eqz v0, :cond_0

    .line 985
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->createStaffs()V

    .line 986
    iget v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    invoke-direct {p0, v0, v1}, Lnet/duceng/xmidi/widgets/MusicScore;->drawToBuffer(II)V

    .line 987
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->draw()V

    .line 990
    :cond_0
    return-void
.end method

.method public shadeNotes(III)V
    .locals 17
    .param p1, "currentPulseTime"    # I
    .param p2, "prevPulseTime"    # I
    .param p3, "scrollType"    # I

    .line 855
    move-object/from16 v0, p0

    move/from16 v8, p1

    move/from16 v9, p3

    iput v8, v0, Lnet/duceng/xmidi/widgets/MusicScore;->currentTicks:I

    .line 856
    iget-boolean v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->surfaceReady:Z

    if-nez v1, :cond_0

    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/MusicScore;->isInEditMode()Z

    move-result v1

    if-eqz v1, :cond_9

    :cond_0
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    if-eqz v1, :cond_9

    .line 857
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    if-nez v1, :cond_1

    .line 858
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/MusicScore;->createBufferCanvas()V

    .line 860
    :cond_1
    invoke-direct/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/MusicScore;->isScrollPositionInBuffer()Z

    move-result v1

    if-nez v1, :cond_2

    .line 861
    iget v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v2, v0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->drawToBuffer(II)V

    .line 863
    :cond_2
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    iget v2, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    neg-int v2, v2

    int-to-float v2, v2

    iget v3, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    neg-int v3, v3

    int-to-float v3, v3

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Canvas;->translate(FF)V

    .line 864
    const/4 v1, 0x0

    .line 865
    .local v1, "x_shade":I
    const/4 v2, 0x0

    .line 866
    .local v2, "y_shade":I
    iget-object v3, v0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    const/4 v10, 0x1

    invoke-virtual {v3, v10}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 867
    iget-object v3, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    iget v4, v0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    iget v5, v0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    invoke-virtual {v3, v4, v5}, Landroid/graphics/Canvas;->scale(FF)V

    .line 868
    const/4 v3, 0x0

    .line 869
    .local v3, "ypos":I
    iget-object v4, v0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v11

    move v12, v1

    move v13, v2

    move v14, v3

    .end local v1    # "x_shade":I
    .end local v2    # "y_shade":I
    .end local v3    # "ypos":I
    .local v12, "x_shade":I
    .local v13, "y_shade":I
    .local v14, "ypos":I
    :goto_0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v15, 0x0

    if-eqz v1, :cond_4

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v16, v1

    check-cast v16, Lnet/duceng/xmidi/widgets/score/Staff;

    .line 870
    .local v16, "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    int-to-float v2, v14

    invoke-virtual {v1, v15, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 871
    iget-object v2, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    iget-object v3, v0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    iget v4, v0, Lnet/duceng/xmidi/widgets/MusicScore;->shade1:I

    move-object/from16 v1, v16

    move/from16 v5, p1

    move/from16 v6, p2

    move v7, v12

    invoke-virtual/range {v1 .. v7}, Lnet/duceng/xmidi/widgets/score/Staff;->shadeNotes(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIII)I

    move-result v12

    .line 872
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    neg-int v2, v14

    int-to-float v2, v2

    invoke-virtual {v1, v15, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 873
    invoke-virtual/range {v16 .. v16}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v1

    add-int/2addr v14, v1

    .line 874
    invoke-virtual/range {v16 .. v16}, Lnet/duceng/xmidi/widgets/score/Staff;->getEndTime()I

    move-result v1

    if-lt v8, v1, :cond_3

    .line 875
    invoke-virtual/range {v16 .. v16}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v1

    add-int/2addr v13, v1

    .line 877
    .end local v16    # "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    :cond_3
    goto :goto_0

    .line 878
    :cond_4
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    iget v2, v0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    const/high16 v3, 0x3f800000    # 1.0f

    div-float v2, v3, v2

    iget v4, v0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    div-float/2addr v3, v4

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Canvas;->scale(FF)V

    .line 879
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferCanvas:Landroid/graphics/Canvas;

    iget v2, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    int-to-float v2, v2

    iget v3, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    int-to-float v3, v3

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Canvas;->translate(FF)V

    .line 880
    if-ltz v8, :cond_6

    .line 881
    int-to-float v1, v12

    iget v2, v0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    mul-float v1, v1, v2

    float-to-int v1, v1

    .line 882
    .local v1, "x_shade2":I
    add-int/lit8 v2, v13, -0x8

    int-to-float v2, v2

    iget v3, v0, Lnet/duceng/xmidi/widgets/MusicScore;->zoom:F

    mul-float v2, v2, v3

    float-to-int v2, v2

    .line 883
    .local v2, "y_shade2":I
    if-ne v9, v10, :cond_5

    .line 884
    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lnet/duceng/xmidi/widgets/MusicScore;->scrollToShadedNotes(IIZ)V

    goto :goto_1

    .line 885
    :cond_5
    const/4 v3, 0x2

    if-ne v9, v3, :cond_6

    .line 886
    invoke-virtual {v0, v1, v2, v10}, Lnet/duceng/xmidi/widgets/MusicScore;->scrollToShadedNotes(IIZ)V

    .line 889
    .end local v1    # "x_shade2":I
    .end local v2    # "y_shade2":I
    :cond_6
    :goto_1
    iget v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v2, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    if-lt v1, v2, :cond_8

    iget v1, v0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    iget v2, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    if-ge v1, v2, :cond_7

    goto :goto_2

    .line 893
    :cond_7
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/MusicScore;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v1

    .line 894
    .local v1, "holder":Landroid/view/SurfaceHolder;
    invoke-interface {v1}, Landroid/view/SurfaceHolder;->lockCanvas()Landroid/graphics/Canvas;

    move-result-object v2

    .line 895
    .local v2, "canvas":Landroid/graphics/Canvas;
    if-eqz v2, :cond_9

    .line 896
    iget v3, v0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v4, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    sub-int/2addr v3, v4

    neg-int v3, v3

    int-to-float v3, v3

    iget v4, v0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    iget v5, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    sub-int/2addr v4, v5

    neg-int v4, v4

    int-to-float v4, v4

    invoke-virtual {v2, v3, v4}, Landroid/graphics/Canvas;->translate(FF)V

    .line 897
    iget-object v3, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferBitmap:Landroid/graphics/Bitmap;

    iget-object v4, v0, Lnet/duceng/xmidi/widgets/MusicScore;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v3, v15, v15, v4}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 898
    iget v3, v0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollX:I

    iget v4, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferX:I

    sub-int/2addr v3, v4

    int-to-float v3, v3

    iget v4, v0, Lnet/duceng/xmidi/widgets/MusicScore;->scrollY:I

    iget v5, v0, Lnet/duceng/xmidi/widgets/MusicScore;->bufferY:I

    sub-int/2addr v4, v5

    int-to-float v4, v4

    invoke-virtual {v2, v3, v4}, Landroid/graphics/Canvas;->translate(FF)V

    .line 899
    invoke-interface {v1, v2}, Landroid/view/SurfaceHolder;->unlockCanvasAndPost(Landroid/graphics/Canvas;)V

    goto :goto_3

    .line 890
    .end local v1    # "holder":Landroid/view/SurfaceHolder;
    .end local v2    # "canvas":Landroid/graphics/Canvas;
    :cond_8
    :goto_2
    invoke-virtual/range {p0 .. p3}, Lnet/duceng/xmidi/widgets/MusicScore;->shadeNotes(III)V

    .line 891
    return-void

    .line 902
    .end local v12    # "x_shade":I
    .end local v13    # "y_shade":I
    .end local v14    # "ypos":I
    :cond_9
    :goto_3
    return-void
.end method

.method public surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .locals 0
    .param p1, "holder"    # Landroid/view/SurfaceHolder;
    .param p2, "format"    # I
    .param p3, "width"    # I
    .param p4, "height"    # I

    .line 1007
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/MusicScore;->draw()V

    .line 1008
    return-void
.end method

.method public surfaceCreated(Landroid/view/SurfaceHolder;)V
    .locals 1
    .param p1, "holder"    # Landroid/view/SurfaceHolder;

    .line 1012
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->surfaceReady:Z

    .line 1013
    return-void
.end method

.method public surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .locals 1
    .param p1, "holder"    # Landroid/view/SurfaceHolder;

    .line 1017
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/widgets/MusicScore;->surfaceReady:Z

    .line 1018
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    .line 1022
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "SheetMusic staffs="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 1023
    .local v0, "result":Ljava/lang/String;
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/MusicScore;->staffs:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/xmidi/widgets/score/Staff;

    .line 1024
    .local v2, "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Staff;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 1025
    .end local v2    # "staff":Lnet/duceng/xmidi/widgets/score/Staff;
    goto :goto_0

    .line 1026
    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "End SheetMusic\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method
