.class Lnet/duceng/xmidi/widgets/PianoBoard$2;
.super Landroid/view/GestureDetector$SimpleOnGestureListener;
.source "PianoBoard.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/widgets/PianoBoard;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/widgets/PianoBoard;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/widgets/PianoBoard;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/widgets/PianoBoard;

    .line 77
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/PianoBoard$2;->this$0:Lnet/duceng/xmidi/widgets/PianoBoard;

    invoke-direct {p0}, Landroid/view/GestureDetector$SimpleOnGestureListener;-><init>()V

    return-void
.end method


# virtual methods
.method public onScroll(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .locals 2
    .param p1, "e1"    # Landroid/view/MotionEvent;
    .param p2, "e2"    # Landroid/view/MotionEvent;
    .param p3, "distanceX"    # F
    .param p4, "distanceY"    # F

    .line 80
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard$2;->this$0:Lnet/duceng/xmidi/widgets/PianoBoard;

    float-to-int v1, p3

    neg-int v1, v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/PianoBoard;->scroll(I)V

    .line 81
    const/4 v0, 0x1

    return v0
.end method
