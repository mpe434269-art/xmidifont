.class public interface abstract Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;
.super Ljava/lang/Object;
.source "PianoBoard.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/widgets/PianoBoard;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "PianoBoardListener"
.end annotation


# virtual methods
.method public abstract onKeysChanged(II)V
.end method
