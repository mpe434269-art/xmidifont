.class public Lnet/duceng/xmidi/widgets/PianoBoard;
.super Landroid/view/SurfaceView;
.source "PianoBoard.java"

# interfaces
.implements Landroid/view/SurfaceHolder$Callback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;
    }
.end annotation


# static fields
.field private static BCOLOR:I = 0x0

.field private static GRAY1:I = 0x0

.field private static GRAY2:I = 0x0

.field private static ISWHITE:[Z = null

.field public static final OCTAVES:I = 0x7

.field private static OFFSETS:[F = null

.field private static WHITES:[I = null

.field public static final WKEYS:I = 0x7


# instance fields
.field private blackKeyHeight:I

.field private blackKeyWidth:I

.field private boardWidth:I

.field private border:I

.field private bufferBitmap:Landroid/graphics/Bitmap;

.field private bufferCanvas:Landroid/graphics/Canvas;

.field private bufferWidth:I

.field private bufferX:I

.field private downBlack:Landroid/graphics/Bitmap;

.field private downWhite:Landroid/graphics/Bitmap;

.field private eventStatus:[I

.field private gestureDetector:Landroid/view/GestureDetector;

.field private holder:Landroid/view/SurfaceHolder;

.field private lockScroll:Z

.field private margin:I

.field private onGesture:Landroid/view/GestureDetector$OnGestureListener;

.field private paint:Landroid/graphics/Paint;

.field private pianoBoardListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

.field private scrollX:I

.field private shadeBlack:Landroid/graphics/Bitmap;

.field private shadeSize:I

.field private shadeWhite:Landroid/graphics/Bitmap;

.field private surfaceReady:Z

.field private targetWhiteKeys:I

.field private upBlack:Landroid/graphics/Bitmap;

.field private upWhite:Landroid/graphics/Bitmap;

.field private whiteKeyHeight:I

.field private whiteKeyWidth:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 50
    const/16 v0, 0xc

    new-array v1, v0, [F

    fill-array-data v1, :array_0

    sput-object v1, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    .line 51
    new-array v0, v0, [Z

    fill-array-data v0, :array_1

    sput-object v0, Lnet/duceng/xmidi/widgets/PianoBoard;->ISWHITE:[Z

    .line 52
    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_2

    sput-object v0, Lnet/duceng/xmidi/widgets/PianoBoard;->WHITES:[I

    .line 53
    const/16 v0, 0x7f

    const/16 v1, 0x3c

    invoke-static {v0, v1, v1, v1}, Landroid/graphics/Color;->argb(IIII)I

    move-result v0

    sput v0, Lnet/duceng/xmidi/widgets/PianoBoard;->GRAY1:I

    .line 54
    const/16 v0, 0xd2

    const/16 v1, 0xb4

    invoke-static {v0, v1, v1, v1}, Landroid/graphics/Color;->argb(IIII)I

    move-result v0

    sput v0, Lnet/duceng/xmidi/widgets/PianoBoard;->GRAY2:I

    .line 55
    const/high16 v0, -0x1000000

    sput v0, Lnet/duceng/xmidi/widgets/PianoBoard;->BCOLOR:I

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x3f19999a    # 0.6f
        0x3f800000    # 1.0f
        0x3fe66666    # 1.8f
        0x40000000    # 2.0f
        0x40400000    # 3.0f
        0x40633333    # 3.55f
        0x40800000    # 4.0f
        0x40966666    # 4.7f
        0x40a00000    # 5.0f
        0x40bb3333    # 5.85f
        0x40c00000    # 6.0f
    .end array-data

    :array_1
    .array-data 1
        0x1t
        0x0t
        0x1t
        0x0t
        0x1t
        0x1t
        0x0t
        0x1t
        0x0t
        0x1t
        0x0t
        0x1t
    .end array-data

    :array_2
    .array-data 4
        0x0
        0x2
        0x4
        0x5
        0x7
        0x9
        0xb
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .line 62
    invoke-direct {p0, p1}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;)V

    .line 137
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->targetWhiteKeys:I

    .line 63
    const/16 v0, 0x20

    new-array v0, v0, [I

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    .line 64
    new-instance v0, Lnet/duceng/xmidi/widgets/PianoBoard$1;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/widgets/PianoBoard$1;-><init>(Lnet/duceng/xmidi/widgets/PianoBoard;)V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->onGesture:Landroid/view/GestureDetector$OnGestureListener;

    .line 71
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/widgets/PianoBoard;->init(Landroid/content/Context;)V

    .line 72
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;

    .line 75
    invoke-direct {p0, p1, p2}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 137
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->targetWhiteKeys:I

    .line 76
    const/16 v0, 0x20

    new-array v0, v0, [I

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    .line 77
    new-instance v0, Lnet/duceng/xmidi/widgets/PianoBoard$2;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/widgets/PianoBoard$2;-><init>(Lnet/duceng/xmidi/widgets/PianoBoard;)V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->onGesture:Landroid/view/GestureDetector$OnGestureListener;

    .line 84
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/widgets/PianoBoard;->init(Landroid/content/Context;)V

    .line 85
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;
    .param p3, "defStyle"    # I

    .line 88
    invoke-direct {p0, p1, p2, p3}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 137
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->targetWhiteKeys:I

    .line 89
    const/16 v0, 0x20

    new-array v0, v0, [I

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    .line 90
    new-instance v0, Lnet/duceng/xmidi/widgets/PianoBoard$3;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/widgets/PianoBoard$3;-><init>(Lnet/duceng/xmidi/widgets/PianoBoard;)V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->onGesture:Landroid/view/GestureDetector$OnGestureListener;

    .line 97
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/widgets/PianoBoard;->init(Landroid/content/Context;)V

    .line 98
    return-void
.end method

.method private draw()V
    .locals 2

    .line 355
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->surfaceReady:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v0}, Landroid/view/SurfaceHolder;->lockCanvas()Landroid/graphics/Canvas;

    move-result-object v0

    move-object v1, v0

    .local v1, "canvas":Landroid/graphics/Canvas;
    if-eqz v0, :cond_0

    .line 356
    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/widgets/PianoBoard;->draw(Landroid/graphics/Canvas;)V

    .line 357
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v0, v1}, Landroid/view/SurfaceHolder;->unlockCanvasAndPost(Landroid/graphics/Canvas;)V

    .line 359
    .end local v1    # "canvas":Landroid/graphics/Canvas;
    :cond_0
    return-void
.end method

.method private drawBorder(Landroid/graphics/Canvas;)V
    .locals 7
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 234
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    if-lez v0, :cond_0

    .line 235
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 236
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    sget v1, Lnet/duceng/xmidi/widgets/PianoBoard;->BCOLOR:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 237
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    int-to-float v2, v0

    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    int-to-float v3, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v4, v0

    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v0, v1

    int-to-float v5, v0

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 238
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    int-to-float v2, v0

    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    int-to-float v3, v0

    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v0, v1

    int-to-float v4, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getHeight()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v5, v0

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 239
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    int-to-float v2, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getHeight()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    sub-int/2addr v0, v1

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    sub-int/2addr v0, v1

    int-to-float v3, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v4, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getHeight()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v5, v0

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 240
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    sub-int/2addr v0, v1

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    sub-int/2addr v0, v1

    int-to-float v2, v0

    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    int-to-float v3, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v4, v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getHeight()I

    move-result v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    sub-int/2addr v0, v1

    int-to-float v5, v0

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 241
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {v0}, Landroid/graphics/Paint;->reset()V

    .line 243
    :cond_0
    return-void
.end method

.method private drawKey(Landroid/graphics/Canvas;IZ)V
    .locals 11
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "index"    # I
    .param p3, "pressed"    # Z

    .line 277
    sget-object v0, Lnet/duceng/xmidi/widgets/PianoBoard;->ISWHITE:[Z

    aget-boolean v0, v0, p2

    const/4 v1, 0x0

    if-eqz v0, :cond_9

    .line 278
    const/4 v0, 0x0

    .line 279
    .local v0, "left":I
    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    .line 280
    .local v2, "right":I
    new-instance v3, Landroid/graphics/Rect;

    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    .line 281
    .local v3, "rect":Landroid/graphics/Rect;
    if-eqz p2, :cond_0

    const/4 v4, 0x5

    if-eq p2, v4, :cond_0

    .line 282
    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v4, v4

    sget-object v5, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    add-int/lit8 v6, p2, -0x1

    aget v5, v5, v6

    mul-float v4, v4, v5

    float-to-int v4, v4

    iget v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    add-int/2addr v4, v5

    iget v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v5, v5

    sget-object v6, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    aget v6, v6, p2

    mul-float v5, v5, v6

    float-to-int v5, v5

    sub-int v0, v4, v5

    .line 284
    :cond_0
    const/4 v4, 0x4

    if-eq p2, v4, :cond_1

    const/16 v4, 0xb

    if-eq p2, v4, :cond_1

    .line 285
    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v4, v4

    sget-object v5, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    add-int/lit8 v6, p2, 0x1

    aget v5, v5, v6

    mul-float v4, v4, v5

    float-to-int v4, v4

    iget v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v5, v5

    sget-object v6, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    aget v6, v6, p2

    mul-float v5, v5, v6

    float-to-int v5, v5

    sub-int v2, v4, v5

    .line 287
    :cond_1
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 288
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    const/high16 v5, -0x1000000

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 289
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 290
    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    const/4 v5, 0x0

    invoke-virtual {v3, v0, v5, v2, v4}, Landroid/graphics/Rect;->set(IIII)V

    .line 291
    invoke-virtual {p1, v3}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/Rect;)Z

    .line 292
    if-eqz p3, :cond_2

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->downWhite:Landroid/graphics/Bitmap;

    goto :goto_0

    :cond_2
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->upWhite:Landroid/graphics/Bitmap;

    :goto_0
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v1, v1, v6}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 293
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 294
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 295
    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    invoke-virtual {v3, v5, v4, v6, v7}, Landroid/graphics/Rect;->set(IIII)V

    .line 296
    if-eqz p3, :cond_3

    .line 297
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v3, v4}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 299
    :cond_3
    invoke-virtual {p1, v3}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/Rect;)Z

    .line 300
    if-eqz p3, :cond_4

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->downWhite:Landroid/graphics/Bitmap;

    goto :goto_1

    :cond_4
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->upWhite:Landroid/graphics/Bitmap;

    :goto_1
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v1, v1, v6}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 301
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 302
    if-eqz p3, :cond_6

    .line 303
    if-lez v0, :cond_5

    .line 304
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 305
    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeSize:I

    add-int/2addr v4, v0

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    invoke-virtual {v3, v0, v5, v4, v6}, Landroid/graphics/Rect;->set(IIII)V

    .line 306
    invoke-virtual {p1, v3}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/Rect;)Z

    .line 307
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeBlack:Landroid/graphics/Bitmap;

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeSize:I

    iget-object v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeBlack:Landroid/graphics/Bitmap;

    invoke-virtual {v7}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v7

    sub-int/2addr v6, v7

    add-int/2addr v6, v0

    int-to-float v6, v6

    iget-object v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v6, v1, v7}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 308
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 309
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 310
    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeSize:I

    add-int/2addr v6, v0

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    iget v8, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeSize:I

    add-int/2addr v7, v8

    invoke-virtual {v3, v5, v4, v6, v7}, Landroid/graphics/Rect;->set(IIII)V

    .line 311
    invoke-virtual {p1, v3}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/Rect;)Z

    .line 312
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeBlack:Landroid/graphics/Bitmap;

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeSize:I

    iget-object v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeBlack:Landroid/graphics/Bitmap;

    invoke-virtual {v7}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v7

    sub-int/2addr v6, v7

    add-int/2addr v6, v0

    int-to-float v6, v6

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeSize:I

    iget-object v8, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeBlack:Landroid/graphics/Bitmap;

    invoke-virtual {v8}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v8

    sub-int/2addr v7, v8

    iget v8, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    add-int/2addr v7, v8

    int-to-float v7, v7

    iget-object v8, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v6, v7, v8}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 313
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 314
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 315
    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeSize:I

    add-int/2addr v4, v6

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeWhite:Landroid/graphics/Bitmap;

    invoke-virtual {v6}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v6

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    invoke-virtual {v3, v5, v4, v6, v7}, Landroid/graphics/Rect;->set(IIII)V

    .line 316
    invoke-virtual {p1, v3}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/Rect;)Z

    .line 317
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeWhite:Landroid/graphics/Bitmap;

    iget v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeSize:I

    add-int/2addr v5, v6

    int-to-float v5, v5

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v1, v5, v6}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 318
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    goto :goto_2

    .line 320
    :cond_5
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 321
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeWhite:Landroid/graphics/Bitmap;

    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v4

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    invoke-virtual {v3, v5, v5, v4, v6}, Landroid/graphics/Rect;->set(IIII)V

    .line 322
    invoke-virtual {p1, v3}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/Rect;)Z

    .line 323
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeWhite:Landroid/graphics/Bitmap;

    iget-object v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v1, v1, v5}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 324
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    goto :goto_2

    .line 327
    :cond_6
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 328
    if-lez v0, :cond_7

    .line 329
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    sget v4, Lnet/duceng/xmidi/widgets/PianoBoard;->GRAY1:I

    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 330
    int-to-float v6, v0

    int-to-float v8, v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    add-int/lit8 v1, v1, 0x1

    int-to-float v9, v1

    iget-object v10, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    const/4 v7, 0x0

    move-object v5, p1

    invoke-virtual/range {v5 .. v10}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 331
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    sget v4, Lnet/duceng/xmidi/widgets/PianoBoard;->GRAY2:I

    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 332
    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    int-to-float v6, v1

    int-to-float v7, v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    int-to-float v8, v1

    iget-object v9, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    const/high16 v5, 0x40000000    # 2.0f

    move-object v4, p1

    invoke-virtual/range {v4 .. v9}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 334
    :cond_7
    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    if-ge v2, v1, :cond_8

    .line 335
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    sget v4, Lnet/duceng/xmidi/widgets/PianoBoard;->GRAY2:I

    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 336
    int-to-float v6, v2

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    int-to-float v7, v1

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    add-int/lit8 v1, v1, -0x2

    int-to-float v8, v1

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    int-to-float v9, v1

    iget-object v10, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    move-object v5, p1

    invoke-virtual/range {v5 .. v10}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 339
    .end local v0    # "left":I
    .end local v2    # "right":I
    .end local v3    # "rect":Landroid/graphics/Rect;
    :cond_8
    :goto_2
    goto :goto_4

    .line 340
    :cond_9
    if-eqz p3, :cond_a

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->downBlack:Landroid/graphics/Bitmap;

    goto :goto_3

    :cond_a
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->upBlack:Landroid/graphics/Bitmap;

    :goto_3
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v1, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 342
    :goto_4
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {v0}, Landroid/graphics/Paint;->reset()V

    .line 343
    return-void
.end method

.method private drawKeys(Landroid/graphics/Canvas;)V
    .locals 10
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 246
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    const/4 v2, 0x7

    mul-int/lit8 v1, v1, 0x7

    div-int/2addr v0, v1

    add-int/lit8 v0, v0, 0x1

    .line 247
    .local v0, "octave":I
    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    neg-int v1, v1

    iget v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v3, v3, 0x7

    rem-int/2addr v1, v3

    .line 248
    .local v1, "offset":I
    sget-object v3, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    const/4 v4, 0x0

    invoke-virtual {p1, v4, v3}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/PorterDuff$Mode;)V

    .line 249
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 250
    int-to-float v3, v1

    const/4 v5, 0x0

    invoke-virtual {p1, v3, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 251
    move v3, v0

    .line 252
    .local v3, "oidx":I
    :goto_0
    if-gt v3, v2, :cond_5

    .line 253
    const/4 v6, 0x0

    .local v6, "kidx":I
    :goto_1
    sget-object v7, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    array-length v7, v7

    if-ge v6, v7, :cond_4

    .line 254
    if-gez v1, :cond_1

    .line 255
    sget-object v7, Lnet/duceng/xmidi/widgets/PianoBoard;->ISWHITE:[Z

    aget-boolean v7, v7, v6

    if-eqz v7, :cond_0

    int-to-float v7, v1

    iget v8, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v8, v8

    sget-object v9, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    aget v9, v9, v6

    mul-float v8, v8, v9

    add-float/2addr v7, v8

    iget v8, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v8, v8

    add-float/2addr v7, v8

    cmpl-float v7, v7, v5

    if-ltz v7, :cond_2

    :cond_0
    sget-object v7, Lnet/duceng/xmidi/widgets/PianoBoard;->ISWHITE:[Z

    aget-boolean v7, v7, v6

    if-nez v7, :cond_2

    sget-object v7, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    aget v7, v7, v6

    goto :goto_2

    .line 257
    :cond_1
    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v7, v7, 0x7

    add-int/2addr v7, v1

    iget v8, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferWidth:I

    if-le v7, v8, :cond_2

    int-to-float v7, v1

    iget v8, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v8, v8

    sget-object v9, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    aget v9, v9, v6

    mul-float v8, v8, v9

    add-float/2addr v7, v8

    iget v8, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferWidth:I

    int-to-float v8, v8

    cmpl-float v7, v7, v8

    if-lez v7, :cond_2

    .line 258
    const/4 v3, 0x7

    .line 259
    goto :goto_3

    .line 261
    :cond_2
    :goto_2
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 262
    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v7, v7

    sget-object v8, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    aget v8, v8, v6

    mul-float v7, v7, v8

    invoke-virtual {p1, v7, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 263
    invoke-direct {p0, p1, v6, v4}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawKey(Landroid/graphics/Canvas;IZ)V

    .line 264
    if-nez v6, :cond_3

    .line 265
    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "C"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {p0, p1, v4, v7, v8}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawString(Landroid/graphics/Canvas;IILjava/lang/String;)V

    .line 267
    :cond_3
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 253
    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    .line 269
    .end local v6    # "kidx":I
    :cond_4
    :goto_3
    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v6, v6, 0x7

    int-to-float v6, v6

    invoke-virtual {p1, v6, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 270
    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v6, v6, 0x7

    add-int/2addr v1, v6

    .line 271
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    .line 273
    :cond_5
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 274
    return-void
.end method

.method private drawNote(IZ)V
    .locals 9
    .param p1, "note"    # I
    .param p2, "pressed"    # Z

    .line 362
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->surfaceReady:Z

    if-eqz v0, :cond_1

    .line 363
    div-int/lit8 v0, p1, 0xc

    add-int/lit8 v0, v0, -0x2

    .line 364
    .local v0, "octave":I
    rem-int/lit8 v1, p1, 0xc

    .line 365
    .local v1, "index":I
    if-ltz v0, :cond_1

    const/4 v2, 0x7

    if-ge v0, v2, :cond_1

    .line 366
    iget v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v3, v3, 0x7

    mul-int v3, v3, v0

    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v2, v2

    sget-object v4, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    aget v4, v4, v1

    mul-float v2, v2, v4

    float-to-int v2, v2

    add-int/2addr v3, v2

    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    sub-int/2addr v3, v2

    .line 367
    .local v3, "left":I
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferCanvas:Landroid/graphics/Canvas;

    invoke-virtual {v2}, Landroid/graphics/Canvas;->save()I

    .line 368
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferCanvas:Landroid/graphics/Canvas;

    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    sub-int v4, v3, v4

    iget v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    add-int/2addr v4, v5

    int-to-float v4, v4

    const/4 v5, 0x0

    invoke-virtual {v2, v4, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 369
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferCanvas:Landroid/graphics/Canvas;

    invoke-direct {p0, v2, v1, p2}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawKey(Landroid/graphics/Canvas;IZ)V

    .line 370
    const/4 v2, 0x0

    if-nez v1, :cond_0

    if-nez p2, :cond_0

    .line 371
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferCanvas:Landroid/graphics/Canvas;

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "C"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    add-int/lit8 v8, v0, 0x1

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {p0, v4, v2, v6, v7}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawString(Landroid/graphics/Canvas;IILjava/lang/String;)V

    .line 373
    :cond_0
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferCanvas:Landroid/graphics/Canvas;

    invoke-virtual {v4}, Landroid/graphics/Canvas;->restore()V

    .line 374
    new-instance v4, Landroid/graphics/Rect;

    invoke-direct {v4}, Landroid/graphics/Rect;-><init>()V

    .line 375
    .local v4, "rect":Landroid/graphics/Rect;
    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    add-int/2addr v6, v3

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    invoke-virtual {v4, v3, v2, v6, v7}, Landroid/graphics/Rect;->set(IIII)V

    .line 376
    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v2, v6

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v6, v7

    invoke-virtual {v4, v2, v6}, Landroid/graphics/Rect;->offset(II)V

    .line 377
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v2, v4}, Landroid/view/SurfaceHolder;->lockCanvas(Landroid/graphics/Rect;)Landroid/graphics/Canvas;

    move-result-object v2

    .line 378
    .local v2, "canvas":Landroid/graphics/Canvas;
    if-eqz v2, :cond_1

    .line 379
    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v6, v7

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    iget v8, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    sub-int/2addr v7, v8

    sub-int/2addr v6, v7

    int-to-float v6, v6

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v8, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v7, v8

    int-to-float v7, v7

    invoke-virtual {v2, v6, v7}, Landroid/graphics/Canvas;->translate(FF)V

    .line 380
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferBitmap:Landroid/graphics/Bitmap;

    iget-object v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v6, v5, v5, v7}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 381
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v5, v2}, Landroid/view/SurfaceHolder;->unlockCanvasAndPost(Landroid/graphics/Canvas;)V

    .line 385
    .end local v0    # "octave":I
    .end local v1    # "index":I
    .end local v2    # "canvas":Landroid/graphics/Canvas;
    .end local v3    # "left":I
    .end local v4    # "rect":Landroid/graphics/Rect;
    :cond_1
    return-void
.end method

.method private drawString(Landroid/graphics/Canvas;IILjava/lang/String;)V
    .locals 3
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "x"    # I
    .param p3, "y"    # I
    .param p4, "str"    # Ljava/lang/String;

    .line 346
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    div-int/lit8 v1, v1, 0x3

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 347
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    sget v1, Lnet/duceng/xmidi/widgets/PianoBoard;->GRAY2:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 348
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 349
    int-to-float v0, p2

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v1, v1

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, p4}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v2

    sub-float/2addr v1, v2

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    add-float/2addr v0, v1

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    div-int/lit8 v1, v1, 0x8

    sub-int v1, p3, v1

    int-to-float v1, v1

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, p4, v0, v1, v2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 350
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {v0}, Landroid/graphics/Paint;->reset()V

    .line 351
    return-void
.end method

.method private init(Landroid/content/Context;)V
    .locals 4
    .param p1, "context"    # Landroid/content/Context;

    .line 101
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    .line 102
    const/4 v1, 0x1

    iput v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    .line 103
    new-instance v2, Landroid/graphics/Paint;

    invoke-direct {v2}, Landroid/graphics/Paint;-><init>()V

    iput-object v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    .line 104
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    const/high16 v3, 0x42540000    # 53.0f

    mul-float v2, v2, v3

    float-to-int v2, v2

    iput v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    .line 105
    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v2, v2, 0x3

    div-int/lit8 v2, v2, 0x5

    iput v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    .line 106
    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    div-int/lit8 v2, v2, 0x5

    iput v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeSize:I

    .line 107
    const/16 v2, 0x127

    iput v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    .line 108
    iput v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    .line 109
    iput-boolean v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->lockScroll:Z

    .line 110
    new-instance v0, Landroid/view/GestureDetector;

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getContext()Landroid/content/Context;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->onGesture:Landroid/view/GestureDetector$OnGestureListener;

    invoke-direct {v0, v2, v3}, Landroid/view/GestureDetector;-><init>(Landroid/content/Context;Landroid/view/GestureDetector$OnGestureListener;)V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->gestureDetector:Landroid/view/GestureDetector;

    .line 111
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->holder:Landroid/view/SurfaceHolder;

    .line 112
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v0, p0}, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V

    .line 113
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->holder:Landroid/view/SurfaceHolder;

    invoke-interface {v0, v1}, Landroid/view/SurfaceHolder;->setFormat(I)V

    .line 114
    return-void
.end method

.method private initBitmap()V
    .locals 11

    .line 160
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->upWhite:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    .line 161
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->upWhite:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 163
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->downWhite:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_1

    .line 164
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->downWhite:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 166
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->upBlack:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_2

    .line 167
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->upBlack:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 169
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->downBlack:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_3

    .line 170
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->downBlack:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 172
    :cond_3
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeWhite:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_4

    .line 173
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeWhite:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 175
    :cond_4
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeBlack:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_5

    .line 176
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeBlack:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 178
    :cond_5
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    const v3, 0x7f03004a

    invoke-static {v0, v3, v1, v2}, Lnet/duceng/xmidi/Base;->decodeResource(Landroid/content/res/Resources;III)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 179
    .local v0, "bmpTemp":Landroid/graphics/Bitmap;
    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    const/4 v3, 0x1

    invoke-static {v0, v1, v2, v3}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->upWhite:Landroid/graphics/Bitmap;

    .line 180
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 181
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    const v5, 0x7f030048

    invoke-static {v1, v5, v2, v4}, Lnet/duceng/xmidi/Base;->decodeResource(Landroid/content/res/Resources;III)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 182
    .local v1, "bmpTemp2":Landroid/graphics/Bitmap;
    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    invoke-static {v1, v2, v4, v3}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v2

    iput-object v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->downWhite:Landroid/graphics/Bitmap;

    .line 183
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 184
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    iget v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    const v6, 0x7f030047

    invoke-static {v2, v6, v4, v5}, Lnet/duceng/xmidi/Base;->decodeResource(Landroid/content/res/Resources;III)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 185
    .local v2, "bmpTemp3":Landroid/graphics/Bitmap;
    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    iget v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    invoke-static {v2, v4, v5, v3}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v4

    iput-object v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->upBlack:Landroid/graphics/Bitmap;

    .line 186
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    .line 187
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    iget v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    const v7, 0x7f030045

    invoke-static {v4, v7, v5, v6}, Lnet/duceng/xmidi/Base;->decodeResource(Landroid/content/res/Resources;III)Landroid/graphics/Bitmap;

    move-result-object v4

    .line 188
    .local v4, "bmpTemp4":Landroid/graphics/Bitmap;
    iget v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    invoke-static {v4, v5, v6, v3}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v5

    iput-object v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->downBlack:Landroid/graphics/Bitmap;

    .line 189
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->recycle()V

    .line 190
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v6, v6, 0x3

    div-int/lit8 v6, v6, 0xa

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    const v8, 0x7f030049

    invoke-static {v5, v8, v6, v7}, Lnet/duceng/xmidi/Base;->decodeResource(Landroid/content/res/Resources;III)Landroid/graphics/Bitmap;

    move-result-object v5

    .line 191
    .local v5, "bmpTemp5":Landroid/graphics/Bitmap;
    iget v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v6, v6, 0x3

    div-int/lit8 v6, v6, 0xa

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    invoke-static {v5, v6, v7, v3}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v6

    iput-object v6, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeWhite:Landroid/graphics/Bitmap;

    .line 192
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->recycle()V

    .line 193
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    int-to-float v7, v7

    const/high16 v8, 0x3fc00000    # 1.5f

    mul-float v7, v7, v8

    float-to-int v7, v7

    iget v9, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    int-to-float v9, v9

    mul-float v9, v9, v8

    float-to-int v9, v9

    const v10, 0x7f030046

    invoke-static {v6, v10, v7, v9}, Lnet/duceng/xmidi/Base;->decodeResource(Landroid/content/res/Resources;III)Landroid/graphics/Bitmap;

    move-result-object v6

    .line 194
    .local v6, "bmpTemp6":Landroid/graphics/Bitmap;
    iget v7, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    int-to-float v7, v7

    mul-float v7, v7, v8

    float-to-int v7, v7

    iget v9, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    int-to-float v9, v9

    mul-float v9, v9, v8

    float-to-int v8, v9

    invoke-static {v6, v7, v8, v3}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v3

    iput-object v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeBlack:Landroid/graphics/Bitmap;

    .line 195
    invoke-virtual {v6}, Landroid/graphics/Bitmap;->recycle()V

    .line 196
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 197
    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .locals 4
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 207
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    const/4 v2, 0x0

    if-le v0, v1, :cond_2

    .line 208
    :goto_0
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    if-le v0, v1, :cond_0

    .line 209
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    div-int/lit8 v1, v1, 0x5

    sub-int/2addr v0, v1

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    goto :goto_0

    .line 211
    :cond_0
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    if-gez v0, :cond_1

    .line 212
    iput v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    .line 214
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferCanvas:Landroid/graphics/Canvas;

    invoke-direct {p0, v0}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawKeys(Landroid/graphics/Canvas;)V

    goto :goto_2

    .line 215
    :cond_2
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    sub-int/2addr v0, v1

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferWidth:I

    iget v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    sub-int/2addr v1, v3

    if-le v0, v1, :cond_5

    .line 216
    :goto_1
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    sub-int/2addr v0, v1

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferWidth:I

    iget v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    sub-int/2addr v1, v3

    if-le v0, v1, :cond_3

    .line 217
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    div-int/lit8 v1, v1, 0x5

    add-int/2addr v0, v1

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    goto :goto_1

    .line 219
    :cond_3
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferWidth:I

    add-int/2addr v0, v1

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v1, v1, 0x7

    mul-int/lit8 v1, v1, 0x7

    if-le v0, v1, :cond_4

    .line 220
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v0, v0, 0x7

    mul-int/lit8 v0, v0, 0x7

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferWidth:I

    sub-int/2addr v0, v1

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    .line 222
    :cond_4
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferCanvas:Landroid/graphics/Canvas;

    invoke-direct {p0, v0}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawKeys(Landroid/graphics/Canvas;)V

    .line 224
    :cond_5
    :goto_2
    sget-object v0, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {p1, v2, v0}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/PorterDuff$Mode;)V

    .line 225
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 226
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v0, v1

    int-to-float v0, v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v1, v2

    int-to-float v1, v1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 227
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    sub-int/2addr v0, v1

    int-to-float v0, v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 228
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferBitmap:Landroid/graphics/Bitmap;

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v1, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 229
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 230
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawBorder(Landroid/graphics/Canvas;)V

    .line 231
    return-void
.end method

.method public isLocked()Z
    .locals 1

    .line 497
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->lockScroll:Z

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 2
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 201
    const-string v0, "PianoBoard"

    const-string v1, "onDraw: This will NOT happen!"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 202
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/widgets/PianoBoard;->draw(Landroid/graphics/Canvas;)V

    .line 203
    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 3
    .param p1, "width"    # I
    .param p2, "height"    # I
    .param p3, "oldw"    # I
    .param p4, "oldh"    # I

    .line 118
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    mul-int/lit8 v0, v0, 0x2

    sub-int v0, p2, v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    mul-int/lit8 v1, v1, 0x2

    sub-int/2addr v0, v1

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    .line 119
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    mul-int/lit8 v0, v0, 0x3

    div-int/lit8 v0, v0, 0x5

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    .line 120
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    mul-int/lit8 v0, v0, 0x2

    sub-int v0, p1, v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    mul-int/lit8 v1, v1, 0x2

    sub-int/2addr v0, v1

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    .line 121
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->targetWhiteKeys:I

    if-lez v0, :cond_0

    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    if-lez v0, :cond_0

    .line 122
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->targetWhiteKeys:I

    div-int/2addr v0, v1

    const/16 v1, 0x8

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    .line 123
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v0, v0, 0x3

    div-int/lit8 v0, v0, 0x5

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    .line 124
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    div-int/lit8 v0, v0, 0x5

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeSize:I

    .line 126
    :cond_0
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    int-to-float v0, v0

    const v1, 0x3f99999a    # 1.2f

    mul-float v0, v0, v1

    float-to-int v0, v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferWidth:I

    .line 127
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->initBitmap()V

    .line 128
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferBitmap:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_1

    .line 129
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferBitmap:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 131
    :cond_1
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferWidth:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v0, v1, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferBitmap:Landroid/graphics/Bitmap;

    .line 132
    new-instance v0, Landroid/graphics/Canvas;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferBitmap:Landroid/graphics/Bitmap;

    invoke-direct {v0, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferCanvas:Landroid/graphics/Canvas;

    .line 133
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->bufferCanvas:Landroid/graphics/Canvas;

    invoke-direct {p0, v0}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawKeys(Landroid/graphics/Canvas;)V

    .line 134
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 135
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 20
    .param p1, "event"    # Landroid/view/MotionEvent;

    .line 389
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v2

    and-int/lit16 v2, v2, 0xff

    .line 390
    .local v2, "action":I
    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz v2, :cond_11

    const/4 v7, 0x5

    if-ne v2, v7, :cond_0

    move/from16 v17, v2

    goto/16 :goto_8

    .line 423
    :cond_0
    if-eq v2, v6, :cond_d

    if-ne v2, v5, :cond_1

    move/from16 v17, v2

    goto/16 :goto_5

    .line 433
    :cond_1
    if-ne v2, v4, :cond_2

    .line 434
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->releaseAll()V

    move/from16 v17, v2

    goto/16 :goto_a

    .line 435
    :cond_2
    iget-boolean v8, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->lockScroll:Z

    if-eqz v8, :cond_c

    if-ne v2, v3, :cond_c

    .line 436
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v8

    .line 437
    .local v8, "idx2":I
    invoke-virtual {v1, v8}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v9

    .line 438
    .local v9, "id2":I
    if-ltz v9, :cond_b

    iget-object v10, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    array-length v10, v10

    if-lt v9, v10, :cond_3

    move/from16 v17, v2

    const/4 v2, 0x1

    goto/16 :goto_4

    .line 441
    :cond_3
    invoke-virtual {v1, v8}, Landroid/view/MotionEvent;->getX(I)F

    move-result v10

    float-to-int v10, v10

    .line 442
    .local v10, "x4":I
    invoke-virtual {v1, v8}, Landroid/view/MotionEvent;->getY(I)F

    move-result v11

    float-to-int v11, v11

    .line 443
    .local v11, "y3":I
    iget v12, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v13, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v12, v13

    if-lt v10, v12, :cond_a

    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v12

    iget v13, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    sub-int/2addr v12, v13

    iget v13, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    sub-int/2addr v12, v13

    if-gt v10, v12, :cond_a

    iget v12, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v13, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v12, v13

    if-lt v11, v12, :cond_a

    iget v12, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    iget v13, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    add-int/2addr v12, v13

    iget v13, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v12, v13

    if-le v11, v12, :cond_4

    move/from16 v17, v2

    goto/16 :goto_3

    .line 446
    :cond_4
    iget v12, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v13, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v12, v13

    sub-int v12, v10, v12

    .line 447
    .local v12, "x5":I
    iget v13, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v14, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v13, v14

    sub-int v13, v11, v13

    .line 448
    .local v13, "y4":I
    iget v14, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    add-int/2addr v14, v12

    .line 449
    .local v14, "x6":I
    iget v15, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v15, v15, 0x7

    div-int v15, v14, v15

    .line 450
    .local v15, "o2":I
    iget v7, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v7, v7, 0x7

    rem-int v7, v14, v7

    .line 451
    .local v7, "ox2":I
    iget v6, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    div-int v6, v7, v6

    .line 452
    .local v6, "on2":I
    sget-object v16, Lnet/duceng/xmidi/widgets/PianoBoard;->WHITES:[I

    aget v16, v16, v6

    .line 453
    .local v16, "note3":I
    mul-int/lit8 v17, v13, 0x40

    iget v5, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    div-int v17, v17, v5

    add-int/lit8 v17, v17, 0x3f

    .line 454
    .local v17, "val2":I
    iget v5, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    if-ge v13, v5, :cond_6

    .line 455
    if-eqz v6, :cond_5

    if-eq v6, v4, :cond_5

    int-to-float v4, v7

    sget-object v5, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    add-int/lit8 v19, v16, -0x1

    aget v5, v5, v19

    iget v3, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v3, v3

    mul-float v5, v5, v3

    iget v3, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    int-to-float v3, v3

    add-float/2addr v5, v3

    cmpg-float v3, v4, v5

    if-gez v3, :cond_5

    .line 456
    add-int/lit8 v16, v16, -0x1

    .line 457
    mul-int/lit8 v3, v13, 0x40

    iget v4, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    div-int/2addr v3, v4

    add-int/lit8 v17, v3, 0x3f

    move/from16 v3, v17

    goto :goto_0

    .line 458
    :cond_5
    const/4 v3, 0x2

    if-eq v6, v3, :cond_6

    const/4 v3, 0x6

    if-eq v6, v3, :cond_6

    int-to-float v3, v7

    sget-object v4, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    add-int/lit8 v5, v16, 0x1

    aget v4, v4, v5

    iget v5, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v5, v5

    mul-float v4, v4, v5

    cmpl-float v3, v3, v4

    if-lez v3, :cond_6

    .line 459
    add-int/lit8 v16, v16, 0x1

    .line 460
    mul-int/lit8 v3, v13, 0x40

    iget v4, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    div-int/2addr v3, v4

    add-int/lit8 v17, v3, 0x3f

    move/from16 v3, v17

    goto :goto_0

    .line 463
    :cond_6
    move/from16 v3, v17

    .end local v17    # "val2":I
    .local v3, "val2":I
    :goto_0
    mul-int/lit8 v4, v15, 0xc

    add-int v4, v16, v4

    add-int/lit8 v4, v4, 0x18

    .line 464
    .local v4, "note4":I
    iget-object v5, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aget v5, v5, v9

    if-ne v5, v4, :cond_7

    .line 465
    const/4 v5, 0x1

    return v5

    .line 467
    :cond_7
    iget-object v5, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->pianoBoardListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    if-eqz v5, :cond_9

    .line 468
    iget-object v5, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aget v5, v5, v9

    if-lez v5, :cond_8

    .line 469
    iget-object v5, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->pianoBoardListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    move/from16 v17, v2

    .end local v2    # "action":I
    .local v17, "action":I
    iget-object v2, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aget v2, v2, v9

    move/from16 v18, v6

    const/4 v6, 0x0

    .end local v6    # "on2":I
    .local v18, "on2":I
    invoke-interface {v5, v2, v6}, Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;->onKeysChanged(II)V

    goto :goto_1

    .line 468
    .end local v17    # "action":I
    .end local v18    # "on2":I
    .restart local v2    # "action":I
    .restart local v6    # "on2":I
    :cond_8
    move/from16 v17, v2

    move/from16 v18, v6

    .line 471
    .end local v2    # "action":I
    .end local v6    # "on2":I
    .restart local v17    # "action":I
    .restart local v18    # "on2":I
    :goto_1
    iget-object v2, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->pianoBoardListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    invoke-interface {v2, v4, v3}, Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;->onKeysChanged(II)V

    goto :goto_2

    .line 467
    .end local v17    # "action":I
    .end local v18    # "on2":I
    .restart local v2    # "action":I
    .restart local v6    # "on2":I
    :cond_9
    move/from16 v17, v2

    move/from16 v18, v6

    .line 473
    .end local v2    # "action":I
    .end local v6    # "on2":I
    .restart local v17    # "action":I
    .restart local v18    # "on2":I
    :goto_2
    iget-object v2, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aget v2, v2, v9

    const/4 v5, 0x0

    invoke-direct {v0, v2, v5}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawNote(IZ)V

    .line 474
    const/4 v2, 0x1

    invoke-direct {v0, v4, v2}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawNote(IZ)V

    .line 475
    iget-object v2, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aput v4, v2, v9

    goto/16 :goto_a

    .line 443
    .end local v3    # "val2":I
    .end local v4    # "note4":I
    .end local v7    # "ox2":I
    .end local v12    # "x5":I
    .end local v13    # "y4":I
    .end local v14    # "x6":I
    .end local v15    # "o2":I
    .end local v16    # "note3":I
    .end local v17    # "action":I
    .end local v18    # "on2":I
    .restart local v2    # "action":I
    :cond_a
    move/from16 v17, v2

    .line 444
    .end local v2    # "action":I
    .restart local v17    # "action":I
    :goto_3
    const/4 v2, 0x1

    return v2

    .line 438
    .end local v10    # "x4":I
    .end local v11    # "y3":I
    .end local v17    # "action":I
    .restart local v2    # "action":I
    :cond_b
    move/from16 v17, v2

    const/4 v2, 0x1

    .line 439
    .end local v2    # "action":I
    .restart local v17    # "action":I
    :goto_4
    return v2

    .line 435
    .end local v8    # "idx2":I
    .end local v9    # "id2":I
    .end local v17    # "action":I
    .restart local v2    # "action":I
    :cond_c
    move/from16 v17, v2

    .end local v2    # "action":I
    .restart local v17    # "action":I
    goto/16 :goto_a

    .line 423
    .end local v17    # "action":I
    .restart local v2    # "action":I
    :cond_d
    move/from16 v17, v2

    .line 424
    .end local v2    # "action":I
    .restart local v17    # "action":I
    :goto_5
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v2

    .line 425
    .local v2, "id":I
    if-ltz v2, :cond_10

    iget-object v3, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    array-length v3, v3

    if-lt v2, v3, :cond_e

    goto :goto_7

    .line 428
    :cond_e
    iget-object v3, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->pianoBoardListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    if-eqz v3, :cond_f

    iget-object v3, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aget v3, v3, v2

    if-lez v3, :cond_f

    .line 429
    iget-object v3, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->pianoBoardListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    iget-object v4, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aget v4, v4, v2

    const/4 v5, 0x0

    invoke-interface {v3, v4, v5}, Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;->onKeysChanged(II)V

    goto :goto_6

    .line 428
    :cond_f
    const/4 v5, 0x0

    .line 431
    :goto_6
    iget-object v3, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aget v3, v3, v2

    invoke-direct {v0, v3, v5}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawNote(IZ)V

    .line 432
    iget-object v3, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aput v5, v3, v2

    .line 433
    .end local v2    # "id":I
    goto/16 :goto_a

    .line 426
    .restart local v2    # "id":I
    :cond_10
    :goto_7
    const/4 v3, 0x1

    return v3

    .line 390
    .end local v17    # "action":I
    .local v2, "action":I
    :cond_11
    move/from16 v17, v2

    .line 391
    .end local v2    # "action":I
    .restart local v17    # "action":I
    :goto_8
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v2

    .line 392
    .local v2, "idx":I
    invoke-virtual {v1, v2}, Landroid/view/MotionEvent;->getX(I)F

    move-result v3

    float-to-int v3, v3

    .line 393
    .local v3, "x":I
    invoke-virtual {v1, v2}, Landroid/view/MotionEvent;->getY(I)F

    move-result v5

    float-to-int v5, v5

    .line 394
    .local v5, "y":I
    iget v6, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v7, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v6, v7

    if-lt v3, v6, :cond_18

    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v6

    iget v7, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    sub-int/2addr v6, v7

    iget v7, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    sub-int/2addr v6, v7

    if-gt v3, v6, :cond_18

    iget v6, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v7, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v6, v7

    if-lt v5, v6, :cond_18

    iget v6, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    iget v7, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    add-int/2addr v6, v7

    iget v7, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v6, v7

    if-le v5, v6, :cond_12

    const/4 v4, 0x1

    goto/16 :goto_b

    .line 397
    :cond_12
    iget v6, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v7, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v6, v7

    sub-int v6, v3, v6

    .line 398
    .local v6, "x2":I
    iget v7, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->margin:I

    iget v8, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->border:I

    add-int/2addr v7, v8

    sub-int v7, v5, v7

    .line 399
    .local v7, "y2":I
    iget v8, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    add-int/2addr v8, v6

    .line 400
    .local v8, "x3":I
    iget v9, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v9, v9, 0x7

    div-int v9, v8, v9

    .line 401
    .local v9, "o":I
    iget v10, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v10, v10, 0x7

    rem-int v10, v8, v10

    .line 402
    .local v10, "ox":I
    iget v11, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    div-int v11, v10, v11

    .line 403
    .local v11, "on":I
    sget-object v12, Lnet/duceng/xmidi/widgets/PianoBoard;->WHITES:[I

    aget v12, v12, v11

    .line 404
    .local v12, "note":I
    mul-int/lit8 v13, v7, 0x5a

    iget v14, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyHeight:I

    div-int/2addr v13, v14

    add-int/lit8 v13, v13, 0x1e

    .line 405
    .local v13, "val":I
    iget v14, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    if-ge v7, v14, :cond_14

    .line 406
    if-eqz v11, :cond_13

    if-eq v11, v4, :cond_13

    int-to-float v4, v10

    sget-object v14, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    add-int/lit8 v15, v12, -0x1

    aget v14, v14, v15

    iget v15, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v15, v15

    mul-float v14, v14, v15

    iget v15, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    int-to-float v15, v15

    add-float/2addr v14, v15

    cmpg-float v4, v4, v14

    if-gez v4, :cond_13

    .line 407
    add-int/lit8 v12, v12, -0x1

    .line 408
    mul-int/lit8 v4, v7, 0x5a

    iget v14, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    div-int/2addr v4, v14

    add-int/lit8 v13, v4, 0x1e

    goto :goto_9

    .line 409
    :cond_13
    const/4 v4, 0x2

    if-eq v11, v4, :cond_14

    const/4 v4, 0x6

    if-eq v11, v4, :cond_14

    int-to-float v4, v10

    sget-object v14, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    add-int/lit8 v15, v12, 0x1

    aget v14, v14, v15

    iget v15, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v15, v15

    mul-float v14, v14, v15

    cmpl-float v4, v4, v14

    if-lez v4, :cond_14

    .line 410
    add-int/lit8 v12, v12, 0x1

    .line 411
    mul-int/lit8 v4, v7, 0x5a

    iget v14, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyHeight:I

    div-int/2addr v4, v14

    add-int/lit8 v13, v4, 0x1e

    .line 414
    :cond_14
    :goto_9
    mul-int/lit8 v4, v9, 0xc

    add-int/2addr v4, v12

    add-int/lit8 v4, v4, 0x18

    .line 415
    .local v4, "note2":I
    iget-object v14, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->pianoBoardListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    if-eqz v14, :cond_15

    .line 416
    iget-object v14, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->pianoBoardListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    invoke-interface {v14, v4, v13}, Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;->onKeysChanged(II)V

    .line 418
    :cond_15
    const/4 v14, 0x1

    invoke-direct {v0, v4, v14}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawNote(IZ)V

    .line 419
    invoke-virtual {v1, v2}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v14

    .line 420
    .local v14, "pid":I
    if-ltz v14, :cond_16

    iget-object v15, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    array-length v15, v15

    if-ge v14, v15, :cond_16

    .line 421
    iget-object v15, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aput v4, v15, v14

    .line 423
    .end local v2    # "idx":I
    .end local v3    # "x":I
    .end local v4    # "note2":I
    .end local v5    # "y":I
    .end local v6    # "x2":I
    .end local v7    # "y2":I
    .end local v8    # "x3":I
    .end local v9    # "o":I
    .end local v10    # "ox":I
    .end local v11    # "on":I
    .end local v12    # "note":I
    .end local v13    # "val":I
    .end local v14    # "pid":I
    :cond_16
    nop

    .line 477
    :goto_a
    iget-boolean v2, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->lockScroll:Z

    if-nez v2, :cond_17

    .line 478
    iget-object v2, v0, Lnet/duceng/xmidi/widgets/PianoBoard;->gestureDetector:Landroid/view/GestureDetector;

    invoke-virtual {v2, v1}, Landroid/view/GestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 480
    :cond_17
    const/4 v4, 0x1

    return v4

    .line 394
    .restart local v2    # "idx":I
    .restart local v3    # "x":I
    .restart local v5    # "y":I
    :cond_18
    const/4 v4, 0x1

    .line 395
    :goto_b
    return v4
.end method

.method public releaseAll()V
    .locals 4

    .line 485
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    array-length v1, v1

    if-ge v0, v1, :cond_2

    .line 486
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aget v1, v1, v0

    if-lez v1, :cond_1

    .line 487
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->pianoBoardListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    .line 488
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->pianoBoardListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aget v3, v3, v0

    invoke-interface {v1, v3, v2}, Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;->onKeysChanged(II)V

    .line 490
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aget v1, v1, v0

    invoke-direct {p0, v1, v2}, Lnet/duceng/xmidi/widgets/PianoBoard;->drawNote(IZ)V

    .line 491
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->eventStatus:[I

    aput v2, v1, v0

    .line 485
    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 494
    .end local v0    # "i":I
    :cond_2
    return-void
.end method

.method public scroll(I)V
    .locals 3
    .param p1, "dx"    # I

    .line 520
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    sub-int/2addr v0, p1

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    .line 521
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    if-gez v0, :cond_0

    .line 522
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    .line 524
    :cond_0
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v1, v1, 0x7

    mul-int/lit8 v1, v1, 0x7

    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    sub-int/2addr v1, v2

    if-le v0, v1, :cond_1

    .line 525
    iget v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v0, v0, 0x7

    mul-int/lit8 v0, v0, 0x7

    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    sub-int/2addr v0, v1

    iput v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    .line 527
    :cond_1
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->draw()V

    .line 528
    return-void
.end method

.method public setKeyScale(F)V
    .locals 5
    .param p1, "scale"    # F

    .line 149
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 150
    .local v0, "density":F
    const/high16 v1, 0x41b00000    # 22.0f

    mul-float v1, v1, v0

    float-to-int v1, v1

    const/high16 v2, 0x42540000    # 53.0f

    mul-float v2, v2, v0

    mul-float v2, v2, p1

    float-to-int v2, v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    .line 151
    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v1, v1, 0x3

    div-int/lit8 v1, v1, 0x5

    iput v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    .line 152
    iget v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->blackKeyWidth:I

    div-int/lit8 v1, v1, 0x5

    iput v1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->shadeSize:I

    .line 153
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v1

    if-lez v1, :cond_0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getHeight()I

    move-result v1

    if-lez v1, :cond_0

    .line 154
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v1

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getHeight()I

    move-result v2

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v3

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getHeight()I

    move-result v4

    invoke-virtual {p0, v1, v2, v3, v4}, Lnet/duceng/xmidi/widgets/PianoBoard;->onSizeChanged(IIII)V

    .line 156
    :cond_0
    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/widgets/PianoBoard;->scroll(I)V

    .line 157
    return-void
.end method

.method public setLocked(Z)V
    .locals 0
    .param p1, "locked"    # Z

    .line 501
    iput-boolean p1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->lockScroll:Z

    .line 502
    return-void
.end method

.method public setPianoBoardListener(Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    .line 546
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->pianoBoardListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    .line 547
    return-void
.end method

.method public setScroll(I)V
    .locals 6
    .param p1, "note"    # I

    .line 505
    div-int/lit8 v0, p1, 0xc

    add-int/lit8 v0, v0, -0x2

    .line 506
    .local v0, "octave":I
    rem-int/lit8 v1, p1, 0xc

    .line 507
    .local v1, "index":I
    if-ltz v0, :cond_2

    const/4 v2, 0x7

    if-ge v0, v2, :cond_2

    .line 508
    iget v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v3, v3, 0x7

    mul-int v3, v3, v0

    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    int-to-float v4, v4

    sget-object v5, Lnet/duceng/xmidi/widgets/PianoBoard;->OFFSETS:[F

    aget v5, v5, v1

    mul-float v4, v4, v5

    float-to-int v4, v4

    add-int/2addr v3, v4

    iput v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    .line 509
    iget v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    if-gez v3, :cond_0

    .line 510
    const/4 v3, 0x0

    iput v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    .line 512
    :cond_0
    iget v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    iget v4, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v4, v4, 0x7

    mul-int/lit8 v4, v4, 0x7

    iget v5, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    sub-int/2addr v4, v5

    if-le v3, v4, :cond_1

    .line 513
    iget v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->whiteKeyWidth:I

    mul-int/lit8 v3, v3, 0x7

    mul-int/lit8 v3, v3, 0x7

    iget v2, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->boardWidth:I

    sub-int/2addr v3, v2

    iput v3, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->scrollX:I

    .line 515
    :cond_1
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->draw()V

    .line 517
    :cond_2
    return-void
.end method

.method public setVisibleWhiteKeys(I)V
    .locals 4
    .param p1, "n"    # I

    .line 141
    iput p1, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->targetWhiteKeys:I

    .line 142
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v0

    if-lez v0, :cond_0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getHeight()I

    move-result v0

    if-lez v0, :cond_0

    .line 143
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getHeight()I

    move-result v1

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getWidth()I

    move-result v2

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->getHeight()I

    move-result v3

    invoke-virtual {p0, v0, v1, v2, v3}, Lnet/duceng/xmidi/widgets/PianoBoard;->onSizeChanged(IIII)V

    .line 145
    :cond_0
    return-void
.end method

.method public surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .locals 0
    .param p1, "holder"    # Landroid/view/SurfaceHolder;
    .param p2, "format"    # I
    .param p3, "width"    # I
    .param p4, "height"    # I

    .line 532
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/PianoBoard;->draw()V

    .line 533
    return-void
.end method

.method public surfaceCreated(Landroid/view/SurfaceHolder;)V
    .locals 1
    .param p1, "holder"    # Landroid/view/SurfaceHolder;

    .line 537
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->surfaceReady:Z

    .line 538
    return-void
.end method

.method public surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .locals 1
    .param p1, "holder"    # Landroid/view/SurfaceHolder;

    .line 542
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/widgets/PianoBoard;->surfaceReady:Z

    .line 543
    return-void
.end method
