.class public Lnet/duceng/xmidi/widgets/RButton;
.super Landroid/widget/ImageButton;
.source "RButton.java"


# instance fields
.field private degree:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .line 15
    invoke-direct {p0, p1}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;)V

    .line 16
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/RButton;->degree:I

    .line 17
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;

    .line 20
    invoke-direct {p0, p1, p2}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 21
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/RButton;->degree:I

    .line 22
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "attrs"    # Landroid/util/AttributeSet;
    .param p3, "defStyle"    # I

    .line 25
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 26
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/RButton;->degree:I

    .line 27
    return-void
.end method


# virtual methods
.method public getDegree()I
    .locals 1

    .line 30
    iget v0, p0, Lnet/duceng/xmidi/widgets/RButton;->degree:I

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 21
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 40
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/RButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    .line 41
    .local v2, "d":Landroid/graphics/drawable/Drawable;
    if-eqz v2, :cond_0

    .line 42
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v3

    .line 43
    .local v3, "bounds":Landroid/graphics/Rect;
    iget v4, v3, Landroid/graphics/Rect;->right:I

    iget v5, v3, Landroid/graphics/Rect;->left:I

    sub-int/2addr v4, v5

    .line 44
    .local v4, "w":I
    iget v5, v3, Landroid/graphics/Rect;->bottom:I

    iget v6, v3, Landroid/graphics/Rect;->top:I

    sub-int/2addr v5, v6

    .line 45
    .local v5, "h":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/RButton;->getPaddingLeft()I

    move-result v6

    .line 46
    .local v6, "left":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/RButton;->getPaddingTop()I

    move-result v7

    .line 47
    .local v7, "top":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/RButton;->getPaddingRight()I

    move-result v8

    .line 48
    .local v8, "right":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/RButton;->getPaddingBottom()I

    move-result v9

    .line 49
    .local v9, "bottom":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/RButton;->getWidth()I

    move-result v10

    sub-int/2addr v10, v6

    sub-int/2addr v10, v8

    .line 50
    .local v10, "width":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/RButton;->getHeight()I

    move-result v11

    sub-int/2addr v11, v7

    sub-int/2addr v11, v9

    .line 51
    .local v11, "height":I
    iget v12, v0, Lnet/duceng/xmidi/widgets/RButton;->degree:I

    int-to-double v12, v12

    invoke-static {v12, v13}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v12

    .line 52
    .local v12, "a":D
    int-to-double v14, v4

    invoke-static {v12, v13}, Ljava/lang/Math;->cos(D)D

    move-result-wide v16

    mul-double v14, v14, v16

    invoke-static {v14, v15}, Ljava/lang/Math;->abs(D)D

    move-result-wide v14

    move/from16 v16, v8

    move/from16 v17, v9

    .end local v8    # "right":I
    .end local v9    # "bottom":I
    .local v16, "right":I
    .local v17, "bottom":I
    int-to-double v8, v5

    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    move-result-wide v18

    mul-double v8, v8, v18

    invoke-static {v8, v9}, Ljava/lang/Math;->abs(D)D

    move-result-wide v8

    add-double/2addr v14, v8

    double-to-int v8, v14

    .line 53
    .local v8, "nw":I
    int-to-double v14, v4

    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    move-result-wide v18

    mul-double v14, v14, v18

    invoke-static {v14, v15}, Ljava/lang/Math;->abs(D)D

    move-result-wide v14

    move-object v9, v2

    move-object/from16 v18, v3

    .end local v2    # "d":Landroid/graphics/drawable/Drawable;
    .end local v3    # "bounds":Landroid/graphics/Rect;
    .local v9, "d":Landroid/graphics/drawable/Drawable;
    .local v18, "bounds":Landroid/graphics/Rect;
    int-to-double v2, v5

    invoke-static {v12, v13}, Ljava/lang/Math;->cos(D)D

    move-result-wide v19

    mul-double v2, v2, v19

    invoke-static {v2, v3}, Ljava/lang/Math;->abs(D)D

    move-result-wide v2

    add-double/2addr v14, v2

    double-to-int v2, v14

    .line 54
    .local v2, "nh":I
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->getSaveCount()I

    move-result v3

    .line 55
    .local v3, "saveCount":I
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    .line 56
    div-int/lit8 v14, v10, 0x2

    add-int/2addr v14, v6

    int-to-float v14, v14

    div-int/lit8 v15, v11, 0x2

    add-int/2addr v15, v7

    int-to-float v15, v15

    invoke-virtual {v1, v14, v15}, Landroid/graphics/Canvas;->translate(FF)V

    .line 57
    div-int v14, v10, v8

    int-to-float v14, v14

    div-int v15, v11, v2

    int-to-float v15, v15

    invoke-virtual {v1, v14, v15}, Landroid/graphics/Canvas;->scale(FF)V

    .line 58
    iget v14, v0, Lnet/duceng/xmidi/widgets/RButton;->degree:I

    rem-int/lit16 v14, v14, 0x168

    int-to-float v14, v14

    invoke-virtual {v1, v14}, Landroid/graphics/Canvas;->rotate(F)V

    .line 59
    neg-int v14, v4

    div-int/lit8 v14, v14, 0x2

    int-to-float v14, v14

    neg-int v15, v5

    div-int/lit8 v15, v15, 0x2

    int-to-float v15, v15

    invoke-virtual {v1, v14, v15}, Landroid/graphics/Canvas;->translate(FF)V

    .line 60
    invoke-virtual {v9, v1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 61
    invoke-virtual {v1, v3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    goto :goto_0

    .line 41
    .end local v3    # "saveCount":I
    .end local v4    # "w":I
    .end local v5    # "h":I
    .end local v6    # "left":I
    .end local v7    # "top":I
    .end local v8    # "nw":I
    .end local v9    # "d":Landroid/graphics/drawable/Drawable;
    .end local v10    # "width":I
    .end local v11    # "height":I
    .end local v12    # "a":D
    .end local v16    # "right":I
    .end local v17    # "bottom":I
    .end local v18    # "bounds":Landroid/graphics/Rect;
    .local v2, "d":Landroid/graphics/drawable/Drawable;
    :cond_0
    move-object v9, v2

    .line 63
    .end local v2    # "d":Landroid/graphics/drawable/Drawable;
    .restart local v9    # "d":Landroid/graphics/drawable/Drawable;
    :goto_0
    return-void
.end method

.method public setDegree(I)V
    .locals 0
    .param p1, "degree"    # I

    .line 34
    iput p1, p0, Lnet/duceng/xmidi/widgets/RButton;->degree:I

    .line 35
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/RButton;->invalidate()V

    .line 36
    return-void
.end method
