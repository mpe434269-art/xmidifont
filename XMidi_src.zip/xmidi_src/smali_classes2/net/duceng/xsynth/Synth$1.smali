.class Lnet/duceng/xsynth/Synth$1;
.super Ljava/lang/Object;
.source "Synth.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xsynth/Synth;->play()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xsynth/Synth;


# direct methods
.method constructor <init>(Lnet/duceng/xsynth/Synth;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xsynth/Synth;

    .line 819
    iput-object p1, p0, Lnet/duceng/xsynth/Synth$1;->this$0:Lnet/duceng/xsynth/Synth;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 822
    iget-object v0, p0, Lnet/duceng/xsynth/Synth$1;->this$0:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->playing()V

    .line 823
    return-void
.end method
