.class public interface abstract Lnet/duceng/xsynth/Synth$BeatListener;
.super Ljava/lang/Object;
.source "Synth.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xsynth/Synth;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "BeatListener"
.end annotation


# virtual methods
.method public abstract onBeating(J)V
.end method
