.class public interface abstract Lnet/duceng/xsynth/Synth$StatusListener;
.super Ljava/lang/Object;
.source "Synth.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xsynth/Synth;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "StatusListener"
.end annotation


# virtual methods
.method public abstract onStatusChanged(Z)V
.end method
