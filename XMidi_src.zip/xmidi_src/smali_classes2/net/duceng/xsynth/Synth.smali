.class public Lnet/duceng/xsynth/Synth;
.super Ljava/lang/Object;
.source "Synth.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xsynth/Synth$StatusListener;,
        Lnet/duceng/xsynth/Synth$BeatListener;
    }
.end annotation


# static fields
.field public static DEFAULT_FONT:Ljava/lang/String;

.field public static DRUMS_BANK:I

.field public static DRUMS_CHAN:B

.field private static final FAMILY_DB:[D

.field public static PATH_FONT:Ljava/lang/String;

.field public static PATH_MIDI:Ljava/lang/String;

.field public static PATH_RECORD:Ljava/lang/String;

.field public static PATH_ROOT:Ljava/lang/String;

.field public static PATH_STY:Ljava/lang/String;

.field private static final ROLE_DB:[D

.field private static instance:Lnet/duceng/xsynth/Synth;


# instance fields
.field private final baseVolume:[I

.field private beatListener:Lnet/duceng/xsynth/Synth$BeatListener;

.field private beatNote1:B

.field private beatNote2:B

.field private beatVelocity:B

.field private beating:Z

.field private bound:I

.field private controls:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/util/MyArray<",
            "Ljava/lang/Integer;",
            ">;>;"
        }
    .end annotation
.end field

.field private file:Ljava/io/File;

.field private inited:Z

.field private lastBeatMillis:J

.field private lastBeatTicks:I

.field private listenChan:B

.field private mExecutor:Ljava/util/concurrent/ExecutorService;

.field private mRunnable:Ljava/lang/Runnable;

.field private midiFile:Lnet/duceng/midi/MidiFile;

.field private mutes:[Z

.field private pause:Z

.field private volatile playLoopActive:Z

.field private playing:Z

.field private recordChan:B

.field private recordTrack:Lnet/duceng/midi/MidiTrack;

.field private recording:Z

.field private scores:[Z

.field private sfonts:Lnet/duceng/xmidi/util/MyArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lnet/duceng/xmidi/util/MyArray<",
            "Ljava/io/File;",
            ">;"
        }
    .end annotation
.end field

.field private statusListener:Lnet/duceng/xsynth/Synth$StatusListener;

.field private volatile styleMix:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 36
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/net.duceng/XMidi"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lnet/duceng/xsynth/Synth;->PATH_ROOT:Ljava/lang/String;

    .line 37
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lnet/duceng/xsynth/Synth;->PATH_ROOT:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/sf2"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lnet/duceng/xsynth/Synth;->PATH_FONT:Ljava/lang/String;

    .line 38
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lnet/duceng/xsynth/Synth;->PATH_ROOT:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/midi"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lnet/duceng/xsynth/Synth;->PATH_MIDI:Ljava/lang/String;

    .line 39
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lnet/duceng/xsynth/Synth;->PATH_ROOT:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/sty"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lnet/duceng/xsynth/Synth;->PATH_STY:Ljava/lang/String;

    .line 40
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lnet/duceng/xsynth/Synth;->PATH_MIDI:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/record"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lnet/duceng/xsynth/Synth;->PATH_RECORD:Ljava/lang/String;

    .line 41
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lnet/duceng/xsynth/Synth;->PATH_FONT:Ljava/lang/String;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/TimGM6mb.sf2"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lnet/duceng/xsynth/Synth;->DEFAULT_FONT:Ljava/lang/String;

    .line 81
    const/16 v0, 0x9

    sput-byte v0, Lnet/duceng/xsynth/Synth;->DRUMS_CHAN:B

    .line 82
    const/16 v0, 0x80

    sput v0, Lnet/duceng/xsynth/Synth;->DRUMS_BANK:I

    .line 83
    const/4 v0, 0x0

    sput-object v0, Lnet/duceng/xsynth/Synth;->instance:Lnet/duceng/xsynth/Synth;

    .line 476
    const/16 v0, 0x10

    new-array v0, v0, [D

    fill-array-data v0, :array_0

    sput-object v0, Lnet/duceng/xsynth/Synth;->FAMILY_DB:[D

    .line 486
    const/16 v0, 0x8

    new-array v0, v0, [D

    fill-array-data v0, :array_1

    sput-object v0, Lnet/duceng/xsynth/Synth;->ROLE_DB:[D

    return-void

    :array_0
    .array-data 8
        0x4008000000000000L    # 3.0
        0x3ff0000000000000L    # 1.0
        -0x4000000000000000L    # -2.0
        0x4004000000000000L    # 2.5
        0x4008000000000000L    # 3.0
        -0x3ff8000000000000L    # -3.0
        -0x3fee000000000000L    # -4.5
        -0x4000000000000000L    # -2.0
        -0x4008000000000000L    # -1.5
        -0x4010000000000000L    # -1.0
        -0x4000000000000000L    # -2.0
        -0x3fee000000000000L    # -4.5
        -0x3ff8000000000000L    # -3.0
        0x0
        0x0
        -0x4000000000000000L    # -2.0
    .end array-data

    :array_1
    .array-data 8
        0x0
        0x0
        0x0
        0x3ff8000000000000L    # 1.5
        0x3fe0000000000000L    # 0.5
        -0x4010000000000000L    # -1.0
        -0x3ff0000000000000L    # -4.0
        -0x3ff8000000000000L    # -3.0
    .end array-data
.end method

.method private constructor <init>()V
    .locals 4

    .line 113
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 84
    new-instance v0, Lnet/duceng/xmidi/util/MyArray;

    invoke-direct {v0}, Lnet/duceng/xmidi/util/MyArray;-><init>()V

    iput-object v0, p0, Lnet/duceng/xsynth/Synth;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    .line 85
    const/16 v0, 0x10

    new-array v1, v0, [Z

    iput-object v1, p0, Lnet/duceng/xsynth/Synth;->mutes:[Z

    .line 86
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lnet/duceng/xsynth/Synth;->controls:Ljava/util/ArrayList;

    .line 87
    const/4 v1, 0x0

    iput-object v1, p0, Lnet/duceng/xsynth/Synth;->scores:[Z

    .line 88
    iput-object v1, p0, Lnet/duceng/xsynth/Synth;->file:Ljava/io/File;

    .line 89
    new-instance v2, Lnet/duceng/midi/MidiFile;

    invoke-direct {v2}, Lnet/duceng/midi/MidiFile;-><init>()V

    iput-object v2, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    .line 90
    iput-object v1, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    .line 91
    const/4 v1, 0x0

    iput-byte v1, p0, Lnet/duceng/xsynth/Synth;->recordChan:B

    .line 92
    iput-byte v1, p0, Lnet/duceng/xsynth/Synth;->listenChan:B

    .line 93
    iput-boolean v1, p0, Lnet/duceng/xsynth/Synth;->playing:Z

    .line 94
    iput-boolean v1, p0, Lnet/duceng/xsynth/Synth;->pause:Z

    .line 95
    iput-boolean v1, p0, Lnet/duceng/xsynth/Synth;->recording:Z

    .line 96
    iput-boolean v1, p0, Lnet/duceng/xsynth/Synth;->beating:Z

    .line 97
    const/16 v2, 0x4b

    iput-byte v2, p0, Lnet/duceng/xsynth/Synth;->beatVelocity:B

    .line 98
    const/16 v2, 0x22

    iput-byte v2, p0, Lnet/duceng/xsynth/Synth;->beatNote1:B

    .line 99
    const/16 v2, 0x21

    iput-byte v2, p0, Lnet/duceng/xsynth/Synth;->beatNote2:B

    .line 100
    const-wide/16 v2, 0x0

    iput-wide v2, p0, Lnet/duceng/xsynth/Synth;->lastBeatMillis:J

    .line 101
    iput v1, p0, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    .line 102
    iput-boolean v1, p0, Lnet/duceng/xsynth/Synth;->inited:Z

    .line 103
    iput v1, p0, Lnet/duceng/xsynth/Synth;->bound:I

    .line 228
    iput-boolean v1, p0, Lnet/duceng/xsynth/Synth;->playLoopActive:Z

    .line 459
    new-array v2, v0, [I

    fill-array-data v2, :array_0

    iput-object v2, p0, Lnet/duceng/xsynth/Synth;->baseVolume:[I

    .line 474
    iput-boolean v1, p0, Lnet/duceng/xsynth/Synth;->styleMix:Z

    .line 114
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    if-ge v1, v0, :cond_0

    .line 115
    iget-object v2, p0, Lnet/duceng/xsynth/Synth;->controls:Ljava/util/ArrayList;

    new-instance v3, Lnet/duceng/xmidi/util/MyArray;

    invoke-direct {v3}, Lnet/duceng/xmidi/util/MyArray;-><init>()V

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 114
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 117
    .end local v1    # "i":I
    :cond_0
    return-void

    :array_0
    .array-data 4
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
        0x64
    .end array-data
.end method

.method private applyFileSetup()V
    .locals 11

    .line 749
    const/4 v0, 0x0

    const/16 v1, 0xf

    invoke-virtual {p0, v0, v1}, Lnet/duceng/xsynth/Synth;->resetChannels(II)V

    .line 750
    invoke-virtual {p0, v0, v1}, Lnet/duceng/xsynth/Synth;->clearOverrides(II)V

    .line 751
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 752
    .local v0, "perChan":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;>;"
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    const/16 v3, 0x10

    if-ge v2, v3, :cond_0

    .line 753
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 752
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 755
    .end local v2    # "i":I
    :cond_0
    new-array v2, v3, [Z

    .line 756
    .local v2, "started":[Z
    new-instance v4, Ljava/util/TreeSet;

    invoke-direct {v4}, Ljava/util/TreeSet;-><init>()V

    .line 757
    .local v4, "all":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    iget-object v5, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v5}, Lnet/duceng/midi/MidiFile;->getTracks()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/midi/MidiTrack;

    .line 758
    .local v6, "t":Lnet/duceng/midi/MidiTrack;
    invoke-virtual {v6}, Lnet/duceng/midi/MidiTrack;->getEvents()Ljava/util/TreeSet;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/util/TreeSet;->addAll(Ljava/util/Collection;)Z

    .line 759
    .end local v6    # "t":Lnet/duceng/midi/MidiTrack;
    goto :goto_1

    .line 760
    :cond_1
    invoke-virtual {v4}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_5

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/midi/MidiEvent;

    .line 761
    .local v6, "ev":Lnet/duceng/midi/MidiEvent;
    instance-of v7, v6, Lnet/duceng/midi/EventChannel;

    if-nez v7, :cond_2

    .line 762
    goto :goto_2

    .line 764
    :cond_2
    move-object v7, v6

    check-cast v7, Lnet/duceng/midi/EventChannel;

    .line 765
    .local v7, "e":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v8

    and-int/2addr v8, v1

    .line 766
    .local v8, "ch":I
    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v9

    const/16 v10, 0x9

    if-ne v9, v10, :cond_3

    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v9

    if-lez v9, :cond_3

    .line 767
    const/4 v9, 0x1

    aput-boolean v9, v2, v8

    .line 769
    :cond_3
    aget-boolean v9, v2, v8

    if-nez v9, :cond_4

    .line 770
    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/ArrayList;

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 772
    .end local v6    # "ev":Lnet/duceng/midi/MidiEvent;
    .end local v7    # "e":Lnet/duceng/midi/EventChannel;
    .end local v8    # "ch":I
    :cond_4
    goto :goto_2

    .line 773
    :cond_5
    const/4 v1, 0x0

    .local v1, "ch":I
    :goto_3
    if-ge v1, v3, :cond_f

    .line 774
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/ArrayList;

    .line 775
    .local v5, "l":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_4
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/16 v8, 0xb

    if-eqz v7, :cond_8

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lnet/duceng/midi/EventChannel;

    .line 776
    .restart local v7    # "e":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v9

    if-ne v9, v8, :cond_7

    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v8

    sget-byte v9, Lnet/duceng/xsynth/XSynth;->BANK_SELECT_MSB:B

    if-eq v8, v9, :cond_6

    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v8

    sget-byte v9, Lnet/duceng/xsynth/XSynth;->BANK_SELECT_LSB:B

    if-ne v8, v9, :cond_7

    :cond_6
    sget-byte v8, Lnet/duceng/xsynth/Synth;->DRUMS_CHAN:B

    if-eq v1, v8, :cond_7

    .line 778
    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v8

    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v9

    invoke-static {v1, v8, v9}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 780
    .end local v7    # "e":Lnet/duceng/midi/EventChannel;
    :cond_7
    goto :goto_4

    .line 781
    :cond_8
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_5
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_b

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lnet/duceng/midi/EventChannel;

    .line 782
    .restart local v7    # "e":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v9

    const/16 v10, 0xc

    if-ne v9, v10, :cond_a

    .line 783
    sget-byte v9, Lnet/duceng/xsynth/Synth;->DRUMS_CHAN:B

    if-ne v1, v9, :cond_9

    .line 784
    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v9

    div-int/lit8 v9, v9, 0x8

    mul-int/lit8 v9, v9, 0x8

    invoke-static {v1, v9}, Lnet/duceng/xsynth/XSynth;->midiPlayerProgramChange(II)V

    goto :goto_6

    .line 786
    :cond_9
    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v9

    invoke-static {v1, v9}, Lnet/duceng/xsynth/XSynth;->midiPlayerProgramChange(II)V

    .line 789
    .end local v7    # "e":Lnet/duceng/midi/EventChannel;
    :cond_a
    :goto_6
    goto :goto_5

    .line 790
    :cond_b
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_7
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_e

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lnet/duceng/midi/EventChannel;

    .line 791
    .restart local v7    # "e":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v9

    if-ne v9, v8, :cond_c

    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v9

    sget-byte v10, Lnet/duceng/xsynth/XSynth;->BANK_SELECT_MSB:B

    if-eq v9, v10, :cond_c

    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v9

    sget-byte v10, Lnet/duceng/xsynth/XSynth;->BANK_SELECT_LSB:B

    if-eq v9, v10, :cond_c

    .line 792
    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v9

    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v10

    invoke-direct {p0, v1, v9, v10}, Lnet/duceng/xsynth/Synth;->controlChange(III)V

    goto :goto_8

    .line 793
    :cond_c
    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v9

    const/16 v10, 0xe

    if-ne v9, v10, :cond_d

    .line 794
    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v9

    and-int/lit8 v9, v9, 0x7f

    shl-int/lit8 v9, v9, 0x7

    invoke-virtual {v7}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v10

    and-int/lit8 v10, v10, 0x7f

    or-int/2addr v9, v10

    invoke-static {v1, v9}, Lnet/duceng/xsynth/XSynth;->midiPlayerPitchBend(II)V

    .line 796
    .end local v7    # "e":Lnet/duceng/midi/EventChannel;
    :cond_d
    :goto_8
    goto :goto_7

    .line 773
    .end local v5    # "l":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    :cond_e
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_3

    .line 798
    .end local v1    # "ch":I
    :cond_f
    return-void
.end method

.method public static configurePaths(Landroid/content/Context;)V
    .locals 3
    .param p0, "c"    # Landroid/content/Context;

    .line 65
    invoke-static {p0}, Lnet/duceng/xsynth/Synth;->hasSharedStorageAccess(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 66
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "/net.duceng/XMidi"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .local v0, "root":Ljava/lang/String;
    goto :goto_0

    .line 68
    .end local v0    # "root":Ljava/lang/String;
    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    .line 69
    .local v0, "base":Ljava/io/File;
    if-nez v0, :cond_1

    .line 70
    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v0

    .line 72
    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/XMidi"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    move-object v0, v1

    .line 74
    .local v0, "root":Ljava/lang/String;
    :goto_0
    sput-object v0, Lnet/duceng/xsynth/Synth;->PATH_ROOT:Ljava/lang/String;

    .line 75
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Lnet/duceng/xsynth/Synth;->PATH_ROOT:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/sf2"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lnet/duceng/xsynth/Synth;->PATH_FONT:Ljava/lang/String;

    .line 76
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Lnet/duceng/xsynth/Synth;->PATH_ROOT:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/midi"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lnet/duceng/xsynth/Synth;->PATH_MIDI:Ljava/lang/String;

    .line 77
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Lnet/duceng/xsynth/Synth;->PATH_ROOT:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/sty"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lnet/duceng/xsynth/Synth;->PATH_STY:Ljava/lang/String;

    .line 78
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Lnet/duceng/xsynth/Synth;->PATH_MIDI:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/record"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lnet/duceng/xsynth/Synth;->PATH_RECORD:Ljava/lang/String;

    .line 79
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Lnet/duceng/xsynth/Synth;->PATH_FONT:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/TimGM6mb.sf2"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lnet/duceng/xsynth/Synth;->DEFAULT_FONT:Ljava/lang/String;

    .line 80
    return-void
.end method

.method private controlChange(III)V
    .locals 4
    .param p1, "chan"    # I
    .param p2, "ctrl"    # I
    .param p3, "val"    # I

    .line 511
    invoke-static {p2, p3}, Lnet/duceng/xsynth/Synth;->tune(II)I

    move-result p3

    .line 512
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->VOLUME_MSB:B

    if-ne p2, v0, :cond_3

    if-ltz p1, :cond_3

    const/16 v0, 0x10

    if-ge p1, v0, :cond_3

    .line 513
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->baseVolume:[I

    aput p3, v0, p1

    .line 514
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->styleMix:Z

    if-eqz v0, :cond_0

    const/16 v0, 0x8

    if-lt p1, v0, :cond_0

    .line 515
    invoke-direct {p0, p1, p3}, Lnet/duceng/xsynth/Synth;->trimVolume(II)I

    move-result p3

    .line 517
    :cond_0
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->controls:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v0, p2}, Lnet/duceng/xmidi/util/MyArray;->indexOfKey(I)I

    move-result v0

    if-ltz v0, :cond_4

    .line 518
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->controls:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v0, p2}, Lnet/duceng/xmidi/util/MyArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 519
    .local v0, "pct":I
    int-to-float v1, p3

    int-to-float v2, v0

    const/high16 v3, 0x42c80000    # 100.0f

    div-float/2addr v2, v3

    const/high16 v3, 0x3f800000    # 1.0f

    add-float/2addr v2, v3

    mul-float v1, v1, v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result p3

    .line 520
    const/16 v1, 0x7f

    if-le p3, v1, :cond_1

    .line 521
    const/16 p3, 0x7f

    .line 523
    :cond_1
    if-gez p3, :cond_2

    .line 524
    const/4 p3, 0x0

    .line 526
    .end local v0    # "pct":I
    :cond_2
    goto :goto_0

    .line 528
    :cond_3
    invoke-virtual {p0, p1, p2}, Lnet/duceng/xsynth/Synth;->getControl(II)I

    move-result v0

    .line 529
    .local v0, "v":I
    if-ltz v0, :cond_4

    .line 530
    move p3, v0

    .line 533
    .end local v0    # "v":I
    :cond_4
    :goto_0
    invoke-static {p1, p2, p3}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 534
    return-void
.end method

.method private create()V
    .locals 0

    .line 224
    invoke-static {}, Lnet/duceng/xsynth/XSynth;->createEngine()V

    .line 225
    invoke-static {}, Lnet/duceng/xsynth/XSynth;->createMidiPlayer()V

    .line 226
    return-void
.end method

.method private static familyFactor(II)D
    .locals 7
    .param p0, "chan"    # I
    .param p1, "program"    # I

    .line 489
    const/16 v0, 0x7f

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/16 v1, 0x8

    div-int/2addr v0, v1

    .line 490
    .local v0, "fam":I
    sget-object v2, Lnet/duceng/xsynth/Synth;->FAMILY_DB:[D

    aget-wide v3, v2, v0

    .line 491
    .local v3, "db":D
    const/16 v2, 0x30

    if-lt p1, v2, :cond_0

    const/16 v2, 0x33

    if-gt p1, v2, :cond_0

    .line 492
    const-wide/high16 v3, -0x3fee000000000000L    # -4.5

    goto :goto_0

    .line 493
    :cond_0
    const/16 v2, 0x34

    if-lt p1, v2, :cond_1

    const/16 v2, 0x37

    if-gt p1, v2, :cond_1

    .line 494
    const-wide/high16 v3, -0x3ff8000000000000L    # -3.0

    .line 496
    :cond_1
    :goto_0
    if-lt p0, v1, :cond_2

    const/16 v1, 0xf

    if-gt p0, v1, :cond_2

    .line 497
    sget-object v1, Lnet/duceng/xsynth/Synth;->ROLE_DB:[D

    add-int/lit8 v2, p0, -0x8

    aget-wide v5, v1, v2

    add-double/2addr v3, v5

    .line 499
    :cond_2
    const-wide/high16 v1, 0x4044000000000000L    # 40.0

    div-double v1, v3, v1

    const-wide/high16 v5, 0x4024000000000000L    # 10.0

    invoke-static {v5, v6, v1, v2}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v1

    return-wide v1
.end method

.method public static getInstance()Lnet/duceng/xsynth/Synth;
    .locals 2

    .line 120
    sget-object v0, Lnet/duceng/xsynth/Synth;->instance:Lnet/duceng/xsynth/Synth;

    if-nez v0, :cond_0

    .line 121
    new-instance v0, Lnet/duceng/xsynth/Synth;

    invoke-direct {v0}, Lnet/duceng/xsynth/Synth;-><init>()V

    sput-object v0, Lnet/duceng/xsynth/Synth;->instance:Lnet/duceng/xsynth/Synth;

    .line 122
    sget-object v0, Lnet/duceng/xsynth/Synth;->instance:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0}, Lnet/duceng/xsynth/Synth;->create()V

    .line 124
    :cond_0
    sget-object v0, Lnet/duceng/xsynth/Synth;->instance:Lnet/duceng/xsynth/Synth;

    iget v1, v0, Lnet/duceng/xsynth/Synth;->bound:I

    add-int/lit8 v1, v1, 0x1

    iput v1, v0, Lnet/duceng/xsynth/Synth;->bound:I

    .line 125
    sget-object v0, Lnet/duceng/xsynth/Synth;->instance:Lnet/duceng/xsynth/Synth;

    return-object v0
.end method

.method public static hasSharedStorageAccess(Landroid/content/Context;)Z
    .locals 3
    .param p0, "c"    # Landroid/content/Context;

    .line 53
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_0

    .line 54
    invoke-static {}, Landroid/os/Environment;->isExternalStorageManager()Z

    move-result v0

    return v0

    .line 56
    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    const/4 v2, 0x1

    if-lt v0, v1, :cond_2

    .line 57
    const-string v0, "android.permission.WRITE_EXTERNAL_STORAGE"

    invoke-virtual {p0, v0}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    :goto_0
    return v2

    .line 59
    :cond_2
    return v2
.end method

.method private init_dir(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 11
    .param p1, "content"    # Landroid/content/Context;
    .param p2, "src"    # Ljava/lang/String;
    .param p3, "tag"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 200
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 201
    .local v0, "dir":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_0

    .line 202
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 204
    :cond_0
    invoke-virtual {p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v1

    invoke-virtual {v1, p2}, Landroid/content/res/AssetManager;->list(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 205
    .local v1, "files":[Ljava/lang/String;
    const/16 v2, 0x400

    new-array v2, v2, [B

    .line 206
    .local v2, "b":[B
    array-length v3, v1

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_0
    if-ge v5, v3, :cond_2

    aget-object v6, v1, v5

    .line 207
    .local v6, "file":Ljava/lang/String;
    new-instance v7, Ljava/io/File;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    sget-object v9, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 208
    .local v7, "of":Ljava/io/File;
    invoke-virtual {p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    sget-object v10, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v8

    .line 209
    .local v8, "i":Ljava/io/InputStream;
    new-instance v9, Ljava/io/FileOutputStream;

    invoke-direct {v9, v7}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 211
    .local v9, "o":Ljava/io/OutputStream;
    :goto_1
    invoke-virtual {v8, v2}, Ljava/io/InputStream;->read([B)I

    move-result v10

    .line 212
    .local v10, "n":I
    if-gtz v10, :cond_1

    .line 213
    nop

    .line 218
    .end local v10    # "n":I
    invoke-virtual {v9}, Ljava/io/OutputStream;->close()V

    .line 219
    invoke-virtual {v8}, Ljava/io/InputStream;->close()V

    .line 206
    .end local v6    # "file":Ljava/lang/String;
    .end local v7    # "of":Ljava/io/File;
    .end local v8    # "i":Ljava/io/InputStream;
    .end local v9    # "o":Ljava/io/OutputStream;
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 215
    .restart local v6    # "file":Ljava/lang/String;
    .restart local v7    # "of":Ljava/io/File;
    .restart local v8    # "i":Ljava/io/InputStream;
    .restart local v9    # "o":Ljava/io/OutputStream;
    .restart local v10    # "n":I
    :cond_1
    invoke-virtual {v9, v2, v4, v10}, Ljava/io/OutputStream;->write([BII)V

    .line 217
    .end local v10    # "n":I
    goto :goto_1

    .line 221
    .end local v6    # "file":Ljava/lang/String;
    .end local v7    # "of":Ljava/io/File;
    .end local v8    # "i":Ljava/io/InputStream;
    .end local v9    # "o":Ljava/io/OutputStream;
    :cond_2
    return-void
.end method

.method public static isInitialized(Landroid/content/Context;)Z
    .locals 5
    .param p0, "c"    # Landroid/content/Context;

    .line 45
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 46
    .local v0, "pref":Landroid/content/SharedPreferences;
    sget-object v1, Lnet/duceng/xmidi/Settings;->SYNTH_INIT:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, Lnet/duceng/xsynth/Synth;->PATH_ROOT:Ljava/lang/String;

    .line 47
    const-string v3, "synth_init_root"

    const-string v4, ""

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    new-instance v1, Ljava/io/File;

    sget-object v3, Lnet/duceng/xsynth/Synth;->DEFAULT_FONT:Ljava/lang/String;

    invoke-direct {v1, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 48
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    nop

    .line 46
    :goto_0
    return v2
.end method

.method private noteOff(II)V
    .locals 0
    .param p1, "chan"    # I
    .param p2, "key"    # I

    .line 435
    invoke-static {p1, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerNoteoff(II)V

    .line 436
    return-void
.end method

.method private noteOn(III)V
    .locals 0
    .param p1, "chan"    # I
    .param p2, "key"    # I
    .param p3, "vel"    # I

    .line 427
    if-nez p3, :cond_0

    .line 428
    invoke-direct {p0, p1, p2}, Lnet/duceng/xsynth/Synth;->noteOff(II)V

    goto :goto_0

    .line 430
    :cond_0
    invoke-static {p1, p2, p3}, Lnet/duceng/xsynth/XSynth;->midiPlayerNoteon(III)V

    .line 432
    :goto_0
    return-void
.end method

.method private pitchBend(II)V
    .locals 0
    .param p1, "chan"    # I
    .param p2, "val"    # I

    .line 544
    invoke-static {p1, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerPitchBend(II)V

    .line 545
    return-void
.end method

.method private playingInner()V
    .locals 25

    .line 874
    move-object/from16 v1, p0

    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->statusListener:Lnet/duceng/xsynth/Synth$StatusListener;

    if-eqz v0, :cond_0

    .line 875
    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->statusListener:Lnet/duceng/xsynth/Synth$StatusListener;

    const/4 v2, 0x1

    invoke-interface {v0, v2}, Lnet/duceng/xsynth/Synth$StatusListener;->onStatusChanged(Z)V

    .line 877
    :cond_0
    new-instance v0, Ljava/util/TreeSet;

    invoke-direct {v0}, Ljava/util/TreeSet;-><init>()V

    move-object v2, v0

    .line 878
    .local v2, "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    new-instance v0, Ljava/util/TreeSet;

    invoke-direct {v0}, Ljava/util/TreeSet;-><init>()V

    move-object v3, v0

    .line 879
    .local v3, "beats":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTracks()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/midi/MidiTrack;

    .line 880
    .local v4, "t":Lnet/duceng/midi/MidiTrack;
    invoke-virtual {v4}, Lnet/duceng/midi/MidiTrack;->getEvents()Ljava/util/TreeSet;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/TreeSet;->addAll(Ljava/util/Collection;)Z

    .line 881
    .end local v4    # "t":Lnet/duceng/midi/MidiTrack;
    goto :goto_0

    .line 882
    :cond_1
    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    if-eqz v0, :cond_2

    .line 883
    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiTrack;->getEvents()Ljava/util/TreeSet;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/TreeSet;->addAll(Ljava/util/Collection;)Z

    .line 885
    :cond_2
    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v4

    .line 886
    .local v4, "tempo":Lnet/duceng/midi/MetaTempo;
    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTimeSignature()Lnet/duceng/midi/MetaTimeSignature;

    move-result-object v5

    .line 887
    .local v5, "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getResolution()I

    move-result v0

    mul-int/lit8 v0, v0, 0x4

    .line 888
    .local v0, "resolution":I
    const/4 v6, 0x0

    move/from16 v24, v6

    move v6, v0

    move/from16 v0, v24

    .local v0, "i":I
    .local v6, "resolution":I
    :goto_1
    invoke-virtual {v5}, Lnet/duceng/midi/MetaTimeSignature;->getDenominator()B

    move-result v7

    if-ge v0, v7, :cond_3

    .line 889
    div-int/lit8 v6, v6, 0x2

    .line 888
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 891
    .end local v0    # "i":I
    :cond_3
    invoke-virtual {v4}, Lnet/duceng/midi/MetaTempo;->getMpqn()I

    move-result v0

    div-int/lit16 v0, v0, 0x3e8

    int-to-long v7, v0

    .line 892
    .local v7, "milliseconds":J
    const/4 v0, 0x0

    .line 894
    .local v0, "tick":I
    :goto_2
    const/4 v9, 0x0

    move/from16 v24, v9

    move v9, v0

    move/from16 v0, v24

    .line 895
    .local v0, "i2":I
    .local v9, "tick":I
    :goto_3
    invoke-virtual {v5}, Lnet/duceng/midi/MetaTimeSignature;->getNumerator()B

    move-result v10

    if-ge v0, v10, :cond_5

    .line 896
    new-instance v15, Lnet/duceng/midi/EventChannel;

    sget-byte v13, Lnet/duceng/xsynth/Synth;->DRUMS_CHAN:B

    if-nez v0, :cond_4

    iget-byte v10, v1, Lnet/duceng/xsynth/Synth;->beatNote1:B

    goto :goto_4

    :cond_4
    iget-byte v10, v1, Lnet/duceng/xsynth/Synth;->beatNote2:B

    :goto_4
    move v14, v10

    const/16 v16, -0x1

    const/16 v12, 0x9

    move-object v10, v15

    move v11, v9

    move-object/from16 v17, v4

    move-object v4, v15

    .end local v4    # "tempo":Lnet/duceng/midi/MetaTempo;
    .local v17, "tempo":Lnet/duceng/midi/MetaTempo;
    move/from16 v15, v16

    invoke-direct/range {v10 .. v15}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    invoke-virtual {v2, v4}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    .line 897
    add-int/2addr v9, v6

    .line 898
    add-int/lit8 v0, v0, 0x1

    move-object/from16 v4, v17

    goto :goto_3

    .line 900
    .end local v17    # "tempo":Lnet/duceng/midi/MetaTempo;
    .restart local v4    # "tempo":Lnet/duceng/midi/MetaTempo;
    :cond_5
    move-object/from16 v17, v4

    .end local v4    # "tempo":Lnet/duceng/midi/MetaTempo;
    .restart local v17    # "tempo":Lnet/duceng/midi/MetaTempo;
    invoke-virtual {v2}, Ljava/util/TreeSet;->last()Ljava/lang/Object;

    move-result-object v4

    instance-of v4, v4, Lnet/duceng/midi/EventChannel;

    if-eqz v4, :cond_1f

    invoke-virtual {v2}, Ljava/util/TreeSet;->last()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/midi/EventChannel;

    invoke-virtual {v4}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v4

    const/4 v10, -0x1

    if-ne v4, v10, :cond_1f

    .line 901
    nop

    .line 904
    .end local v0    # "i2":I
    const/4 v0, 0x0

    move v4, v0

    .line 905
    .local v4, "i3":I
    :goto_5
    invoke-virtual {v5}, Lnet/duceng/midi/MetaTimeSignature;->getNumerator()B

    move-result v0

    if-ge v4, v0, :cond_7

    .line 906
    new-instance v0, Lnet/duceng/midi/EventChannel;

    mul-int v12, v4, v6

    sget-byte v14, Lnet/duceng/xsynth/Synth;->DRUMS_CHAN:B

    if-nez v4, :cond_6

    iget-byte v11, v1, Lnet/duceng/xsynth/Synth;->beatNote1:B

    goto :goto_6

    :cond_6
    iget-byte v11, v1, Lnet/duceng/xsynth/Synth;->beatNote2:B

    :goto_6
    move v15, v11

    const/16 v16, -0x1

    const/16 v13, 0x9

    move-object v11, v0

    invoke-direct/range {v11 .. v16}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    invoke-virtual {v3, v0}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    .line 907
    add-int/lit8 v4, v4, 0x1

    goto :goto_5

    .line 909
    :cond_7
    iget-boolean v0, v1, Lnet/duceng/xsynth/Synth;->recording:Z

    const-string v11, "Interrupted during sleep."

    if-eqz v0, :cond_8

    .line 910
    const/4 v0, 0x0

    move v12, v0

    .local v12, "i4":I
    :goto_7
    invoke-virtual {v5}, Lnet/duceng/midi/MetaTimeSignature;->getNumerator()B

    move-result v0

    if-ge v12, v0, :cond_8

    iget-boolean v0, v1, Lnet/duceng/xsynth/Synth;->playing:Z

    if-eqz v0, :cond_8

    .line 911
    sget-byte v0, Lnet/duceng/xsynth/Synth;->DRUMS_CHAN:B

    iget-byte v13, v1, Lnet/duceng/xsynth/Synth;->beatNote2:B

    iget-byte v14, v1, Lnet/duceng/xsynth/Synth;->beatVelocity:B

    invoke-direct {v1, v0, v13, v14}, Lnet/duceng/xsynth/Synth;->noteOn(III)V

    .line 913
    :try_start_0
    invoke-static {v7, v8}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 916
    nop

    .line 910
    add-int/lit8 v12, v12, 0x1

    goto :goto_7

    .line 914
    :catch_0
    move-exception v0

    move-object v10, v0

    move-object v0, v10

    .line 915
    .local v0, "e2":Ljava/lang/InterruptedException;
    new-instance v10, Ljava/lang/RuntimeException;

    invoke-direct {v10, v11}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v10

    .line 920
    .end local v0    # "e2":Ljava/lang/InterruptedException;
    .end local v12    # "i4":I
    :cond_8
    :goto_8
    iget v0, v1, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    .line 921
    .local v0, "ticking":I
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    .line 922
    .local v12, "lastSleep":J
    invoke-virtual {v2}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v14

    move-wide v15, v12

    move v12, v0

    .end local v0    # "ticking":I
    .local v12, "ticking":I
    .local v15, "lastSleep":J
    :goto_9
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    move-object v13, v11

    if-eqz v0, :cond_12

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Lnet/duceng/midi/MidiEvent;

    .line 923
    .local v10, "event":Lnet/duceng/midi/MidiEvent;
    iget-boolean v0, v1, Lnet/duceng/xsynth/Synth;->playing:Z

    if-eqz v0, :cond_10

    .line 924
    iget v0, v1, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    invoke-virtual {v10}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v11

    if-gt v0, v11, :cond_f

    .line 925
    invoke-virtual {v10}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v0

    sub-int v11, v0, v12

    .line 926
    .local v11, "delta":I
    if-lez v11, :cond_a

    .line 927
    invoke-virtual {v10}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v12

    .line 928
    invoke-virtual/range {v17 .. v17}, Lnet/duceng/midi/MetaTempo;->getMpqn()I

    move-result v0

    move-object/from16 v20, v2

    .end local v2    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .local v20, "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    iget-object v2, v1, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v2}, Lnet/duceng/midi/MidiFile;->getResolution()I

    move-result v2

    invoke-static {v11, v0, v2}, Lnet/duceng/midi/MidiUtil;->ticksToMs(III)I

    move-result v0

    move/from16 v21, v4

    move-object v2, v5

    .end local v4    # "i3":I
    .end local v5    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .local v2, "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .local v21, "i3":I
    int-to-long v4, v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v22

    sub-long v22, v22, v15

    sub-long v4, v4, v22

    .line 929
    .local v4, "deltamillis":J
    const-wide/16 v18, 0x0

    cmp-long v0, v4, v18

    if-lez v0, :cond_9

    .line 931
    :try_start_1
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1

    .line 934
    goto :goto_a

    .line 932
    :catch_1
    move-exception v0

    move-object v14, v0

    move-object v0, v14

    .line 933
    .local v0, "e3":Ljava/lang/InterruptedException;
    new-instance v14, Ljava/lang/RuntimeException;

    invoke-direct {v14, v13}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v14

    .line 936
    .end local v0    # "e3":Ljava/lang/InterruptedException;
    :cond_9
    :goto_a
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v15

    goto :goto_b

    .line 926
    .end local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .end local v21    # "i3":I
    .local v2, "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .local v4, "i3":I
    .restart local v5    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :cond_a
    move-object/from16 v20, v2

    move/from16 v21, v4

    move-object v2, v5

    .line 938
    .end local v4    # "i3":I
    .end local v5    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .local v2, "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v21    # "i3":I
    :goto_b
    instance-of v0, v10, Lnet/duceng/midi/EventChannel;

    if-eqz v0, :cond_e

    .line 939
    move-object v0, v10

    check-cast v0, Lnet/duceng/midi/EventChannel;

    .line 940
    .local v0, "ec":Lnet/duceng/midi/EventChannel;
    iget-object v4, v1, Lnet/duceng/xsynth/Synth;->mutes:[Z

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v5

    aget-boolean v4, v4, v5

    if-nez v4, :cond_d

    .line 941
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v4

    packed-switch v4, :pswitch_data_0

    :pswitch_0
    move-object/from16 v22, v2

    .end local v2    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .local v22, "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    goto/16 :goto_c

    .line 966
    .end local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v2    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :pswitch_1
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v4

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v5

    invoke-direct {v1, v4, v5}, Lnet/duceng/xsynth/Synth;->pitchBend(II)V

    move-object/from16 v22, v2

    goto/16 :goto_c

    .line 963
    :pswitch_2
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v4

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v5

    invoke-direct {v1, v4, v5}, Lnet/duceng/xsynth/Synth;->programChange(II)V

    .line 964
    move-object/from16 v22, v2

    goto/16 :goto_c

    .line 960
    :pswitch_3
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v4

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v5

    move-object/from16 v22, v2

    .end local v2    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v2

    invoke-direct {v1, v4, v5, v2}, Lnet/duceng/xsynth/Synth;->controlChange(III)V

    .line 961
    goto/16 :goto_c

    .line 946
    .end local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v2    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :pswitch_4
    move-object/from16 v22, v2

    .end local v2    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v2

    sget-byte v4, Lnet/duceng/xsynth/Synth;->DRUMS_CHAN:B

    if-ne v2, v4, :cond_c

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v2

    const/4 v4, -0x1

    if-ne v2, v4, :cond_c

    .line 947
    iget-boolean v2, v1, Lnet/duceng/xsynth/Synth;->beating:Z

    if-eqz v2, :cond_b

    .line 948
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v2

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v5

    iget-byte v4, v1, Lnet/duceng/xsynth/Synth;->beatVelocity:B

    invoke-direct {v1, v2, v5, v4}, Lnet/duceng/xsynth/Synth;->noteOn(III)V

    .line 950
    :cond_b
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    iput-wide v4, v1, Lnet/duceng/xsynth/Synth;->lastBeatMillis:J

    .line 951
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v2

    iput v2, v1, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    .line 952
    iget-object v2, v1, Lnet/duceng/xsynth/Synth;->beatListener:Lnet/duceng/xsynth/Synth$BeatListener;

    if-eqz v2, :cond_11

    .line 953
    iget-object v2, v1, Lnet/duceng/xsynth/Synth;->beatListener:Lnet/duceng/xsynth/Synth$BeatListener;

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v4

    int-to-long v4, v4

    invoke-interface {v2, v4, v5}, Lnet/duceng/xsynth/Synth$BeatListener;->onBeating(J)V

    goto :goto_c

    .line 956
    :cond_c
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v2

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v4

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v5

    invoke-direct {v1, v2, v4, v5}, Lnet/duceng/xsynth/Synth;->noteOn(III)V

    .line 958
    goto :goto_c

    .line 943
    .end local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v2    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :pswitch_5
    move-object/from16 v22, v2

    .end local v2    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v2

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v4

    invoke-direct {v1, v2, v4}, Lnet/duceng/xsynth/Synth;->noteOff(II)V

    .line 944
    goto :goto_c

    .line 940
    .end local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v2    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :cond_d
    move-object/from16 v22, v2

    .end local v2    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    goto :goto_c

    .line 938
    .end local v0    # "ec":Lnet/duceng/midi/EventChannel;
    .end local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v2    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :cond_e
    move-object/from16 v22, v2

    .end local v2    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    goto :goto_c

    .line 924
    .end local v11    # "delta":I
    .end local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .end local v21    # "i3":I
    .end local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .local v2, "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v4    # "i3":I
    .restart local v5    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :cond_f
    move-object/from16 v20, v2

    move/from16 v21, v4

    move-object/from16 v22, v5

    .end local v2    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .end local v4    # "i3":I
    .end local v5    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v21    # "i3":I
    .restart local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    goto :goto_c

    .line 923
    .end local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .end local v21    # "i3":I
    .end local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v2    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v4    # "i3":I
    .restart local v5    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :cond_10
    move-object/from16 v20, v2

    move/from16 v21, v4

    move-object/from16 v22, v5

    .line 973
    .end local v2    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .end local v4    # "i3":I
    .end local v5    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .end local v10    # "event":Lnet/duceng/midi/MidiEvent;
    .restart local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v21    # "i3":I
    .restart local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :cond_11
    :goto_c
    move-object v11, v13

    move-object/from16 v2, v20

    move/from16 v4, v21

    move-object/from16 v5, v22

    const/4 v10, -0x1

    goto/16 :goto_9

    .line 975
    .end local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .end local v21    # "i3":I
    .end local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v2    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v4    # "i3":I
    .restart local v5    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :cond_12
    move-object/from16 v20, v2

    move/from16 v21, v4

    move-object/from16 v22, v5

    .end local v2    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .end local v4    # "i3":I
    .end local v5    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v21    # "i3":I
    .restart local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :try_start_2
    invoke-static {v7, v8}, Ljava/lang/Thread;->sleep(J)V

    .line 976
    iget-boolean v0, v1, Lnet/duceng/xsynth/Synth;->pause:Z

    const/4 v2, 0x0

    if-nez v0, :cond_13

    .line 977
    iput v2, v1, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    .line 979
    :cond_13
    nop

    .line 981
    :cond_14
    iget-boolean v0, v1, Lnet/duceng/xsynth/Synth;->playing:Z

    if-eqz v0, :cond_16

    .line 982
    invoke-virtual {v3}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    move-object v4, v0

    .line 983
    .local v4, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Lnet/duceng/midi/MidiEvent;>;"
    :goto_d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_14

    .line 984
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/midi/EventChannel;

    move-object v5, v0

    .line 985
    .local v5, "e":Lnet/duceng/midi/EventChannel;
    iget-boolean v0, v1, Lnet/duceng/xsynth/Synth;->beating:Z

    if-eqz v0, :cond_15

    .line 986
    invoke-virtual {v5}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v0

    invoke-virtual {v5}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v10

    iget-byte v11, v1, Lnet/duceng/xsynth/Synth;->beatVelocity:B

    invoke-direct {v1, v0, v10, v11}, Lnet/duceng/xsynth/Synth;->noteOn(III)V

    .line 988
    :cond_15
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    iput-wide v10, v1, Lnet/duceng/xsynth/Synth;->lastBeatMillis:J

    .line 989
    iget v0, v1, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    add-int/2addr v0, v6

    iput v0, v1, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_4

    .line 991
    :try_start_3
    invoke-static {v7, v8}, Ljava/lang/Thread;->sleep(J)V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_2

    .line 994
    goto :goto_d

    .line 992
    :catch_2
    move-exception v0

    move-object v2, v0

    move-object v0, v2

    .line 993
    .local v0, "e4":Ljava/lang/InterruptedException;
    :try_start_4
    new-instance v2, Ljava/lang/RuntimeException;

    invoke-direct {v2, v13}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .end local v3    # "beats":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .end local v6    # "resolution":I
    .end local v7    # "milliseconds":J
    .end local v9    # "tick":I
    .end local v12    # "ticking":I
    .end local v15    # "lastSleep":J
    .end local v17    # "tempo":Lnet/duceng/midi/MetaTempo;
    .end local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .end local v21    # "i3":I
    .end local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    throw v2

    .line 997
    .end local v0    # "e4":Ljava/lang/InterruptedException;
    .end local v4    # "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Lnet/duceng/midi/MidiEvent;>;"
    .end local v5    # "e":Lnet/duceng/midi/EventChannel;
    .restart local v3    # "beats":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v6    # "resolution":I
    .restart local v7    # "milliseconds":J
    .restart local v9    # "tick":I
    .restart local v12    # "ticking":I
    .restart local v15    # "lastSleep":J
    .restart local v17    # "tempo":Lnet/duceng/midi/MetaTempo;
    .restart local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v21    # "i3":I
    .restart local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :cond_16
    iget-boolean v0, v1, Lnet/duceng/xsynth/Synth;->pause:Z

    if-nez v0, :cond_17

    .line 998
    iput v2, v1, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    .line 1000
    :cond_17
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xsynth/Synth;->allNotesoff()V

    .line 1001
    const-wide/16 v4, 0x0

    iput-wide v4, v1, Lnet/duceng/xsynth/Synth;->lastBeatMillis:J

    .line 1002
    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->statusListener:Lnet/duceng/xsynth/Synth$StatusListener;

    if-eqz v0, :cond_18

    .line 1003
    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->statusListener:Lnet/duceng/xsynth/Synth$StatusListener;

    invoke-interface {v0, v2}, Lnet/duceng/xsynth/Synth$StatusListener;->onStatusChanged(Z)V
    :try_end_4
    .catch Ljava/lang/InterruptedException; {:try_start_4 .. :try_end_4} :catch_4

    .line 1007
    :cond_18
    nop

    .line 1008
    .end local v12    # "ticking":I
    .end local v15    # "lastSleep":J
    iget-boolean v0, v1, Lnet/duceng/xsynth/Synth;->recording:Z

    if-eqz v0, :cond_1e

    .line 1009
    :cond_19
    iget-boolean v0, v1, Lnet/duceng/xsynth/Synth;->playing:Z

    if-eqz v0, :cond_1b

    .line 1010
    invoke-virtual {v3}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v4

    .line 1011
    .restart local v4    # "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Lnet/duceng/midi/MidiEvent;>;"
    :goto_e
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_19

    .line 1012
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Lnet/duceng/midi/EventChannel;

    .line 1013
    .restart local v5    # "e":Lnet/duceng/midi/EventChannel;
    iget-boolean v0, v1, Lnet/duceng/xsynth/Synth;->beating:Z

    if-eqz v0, :cond_1a

    .line 1014
    invoke-virtual {v5}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v0

    invoke-virtual {v5}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v10

    iget-byte v11, v1, Lnet/duceng/xsynth/Synth;->beatVelocity:B

    invoke-direct {v1, v0, v10, v11}, Lnet/duceng/xsynth/Synth;->noteOn(III)V

    .line 1016
    :cond_1a
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    iput-wide v10, v1, Lnet/duceng/xsynth/Synth;->lastBeatMillis:J

    .line 1017
    iget v0, v1, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    add-int/2addr v0, v6

    iput v0, v1, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    .line 1019
    :try_start_5
    invoke-static {v7, v8}, Ljava/lang/Thread;->sleep(J)V
    :try_end_5
    .catch Ljava/lang/InterruptedException; {:try_start_5 .. :try_end_5} :catch_3

    .line 1022
    goto :goto_e

    .line 1020
    :catch_3
    move-exception v0

    move-object v2, v0

    move-object v0, v2

    .line 1021
    .local v0, "e6":Ljava/lang/InterruptedException;
    new-instance v2, Ljava/lang/RuntimeException;

    invoke-direct {v2, v13}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 1025
    .end local v0    # "e6":Ljava/lang/InterruptedException;
    .end local v4    # "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Lnet/duceng/midi/MidiEvent;>;"
    .end local v5    # "e":Lnet/duceng/midi/EventChannel;
    :cond_1b
    iget-boolean v0, v1, Lnet/duceng/xsynth/Synth;->pause:Z

    if-nez v0, :cond_1c

    .line 1026
    iput v2, v1, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    .line 1028
    :cond_1c
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xsynth/Synth;->allNotesoff()V

    .line 1029
    const-wide/16 v4, 0x0

    iput-wide v4, v1, Lnet/duceng/xsynth/Synth;->lastBeatMillis:J

    .line 1030
    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->statusListener:Lnet/duceng/xsynth/Synth$StatusListener;

    if-eqz v0, :cond_1d

    .line 1031
    iget-object v0, v1, Lnet/duceng/xsynth/Synth;->statusListener:Lnet/duceng/xsynth/Synth$StatusListener;

    invoke-interface {v0, v2}, Lnet/duceng/xsynth/Synth$StatusListener;->onStatusChanged(Z)V

    .line 1033
    :cond_1d
    return-void

    .line 1008
    :cond_1e
    move-object v11, v13

    move-object/from16 v2, v20

    move/from16 v4, v21

    move-object/from16 v5, v22

    const/4 v10, -0x1

    goto/16 :goto_8

    .line 1005
    .restart local v12    # "ticking":I
    .restart local v15    # "lastSleep":J
    :catch_4
    move-exception v0

    .line 1006
    .local v0, "e5":Ljava/lang/InterruptedException;
    new-instance v2, Ljava/lang/RuntimeException;

    invoke-direct {v2, v13}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 900
    .end local v12    # "ticking":I
    .end local v15    # "lastSleep":J
    .end local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .end local v21    # "i3":I
    .end local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .local v0, "i2":I
    .restart local v2    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .local v5, "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    :cond_1f
    move-object/from16 v20, v2

    move-object/from16 v22, v5

    .line 903
    .end local v0    # "i2":I
    .end local v2    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .end local v5    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    .restart local v20    # "events":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v22    # "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    move v0, v9

    move-object/from16 v4, v17

    move-object/from16 v2, v20

    move-object/from16 v5, v22

    goto/16 :goto_2

    :pswitch_data_0
    .packed-switch 0x8
        :pswitch_5
        :pswitch_4
        :pswitch_0
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method private programChange(II)V
    .locals 1
    .param p1, "chan"    # I
    .param p2, "program"    # I

    .line 537
    invoke-static {p1, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerProgramChange(II)V

    .line 538
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->styleMix:Z

    if-eqz v0, :cond_0

    const/16 v0, 0x8

    if-lt p1, v0, :cond_0

    .line 539
    invoke-virtual {p0, p1}, Lnet/duceng/xsynth/Synth;->refreshVolume(I)V

    .line 541
    :cond_0
    return-void
.end method

.method private release()V
    .locals 3

    .line 231
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    const/16 v1, 0x96

    if-ge v0, v1, :cond_0

    iget-boolean v1, p0, Lnet/duceng/xsynth/Synth;->playLoopActive:Z

    if-eqz v1, :cond_0

    .line 233
    const-wide/16 v1, 0xa

    :try_start_0
    invoke-static {v1, v2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 236
    nop

    .line 231
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 234
    :catch_0
    move-exception v1

    .line 235
    .local v1, "e":Ljava/lang/InterruptedException;
    nop

    .line 238
    .end local v0    # "i":I
    .end local v1    # "e":Ljava/lang/InterruptedException;
    :cond_0
    invoke-static {}, Lnet/duceng/xsynth/XSynth;->releaseMidiPlayer()V

    .line 239
    invoke-static {}, Lnet/duceng/xsynth/XSynth;->releaseEngine()V

    .line 240
    return-void
.end method

.method private trimVolume(II)I
    .locals 4
    .param p1, "chan"    # I
    .param p2, "val"    # I

    .line 503
    sget-byte v0, Lnet/duceng/xsynth/Synth;->DRUMS_CHAN:B

    if-eq p1, v0, :cond_1

    invoke-virtual {p0, p1}, Lnet/duceng/xsynth/Synth;->getBank(I)I

    move-result v0

    sget v1, Lnet/duceng/xsynth/Synth;->DRUMS_BANK:I

    if-ne v0, v1, :cond_0

    goto :goto_0

    .line 506
    :cond_0
    int-to-double v0, p2

    invoke-virtual {p0, p1}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v2

    invoke-static {p1, v2}, Lnet/duceng/xsynth/Synth;->familyFactor(II)D

    move-result-wide v2

    mul-double v0, v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v1, v0

    .line 507
    .local v1, "out":I
    const/16 v0, 0x7f

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v2, 0x1

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0

    .line 504
    .end local v1    # "out":I
    :cond_1
    :goto_0
    return p2
.end method

.method private static tune(II)I
    .locals 2
    .param p0, "ctrl"    # I
    .param p1, "val"    # I

    .line 443
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH1:B

    if-ne p0, v0, :cond_0

    .line 444
    mul-int/lit8 v0, p1, 0x6

    div-int/lit8 v0, v0, 0xa

    return v0

    .line 446
    :cond_0
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH3:B

    if-ne p0, v0, :cond_1

    .line 447
    mul-int/lit8 v0, p1, 0x4

    div-int/lit8 v0, v0, 0xa

    return v0

    .line 449
    :cond_1
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL5:B

    const/16 v1, 0x40

    if-ne p0, v0, :cond_2

    .line 450
    invoke-static {p1, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0

    .line 452
    :cond_2
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL3:B

    if-ne p0, v0, :cond_3

    .line 453
    invoke-static {p1, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0

    .line 455
    :cond_3
    return p1
.end method


# virtual methods
.method public allNotesoff()V
    .locals 3

    .line 421
    const/4 v0, 0x0

    .local v0, "chan":I
    :goto_0
    invoke-static {}, Lnet/duceng/xsynth/XSynth;->midiPlayerMidiChannels()I

    move-result v1

    if-ge v0, v1, :cond_0

    .line 422
    sget-byte v1, Lnet/duceng/xsynth/XSynth;->ALL_SOUND_OFF:B

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 421
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 424
    .end local v0    # "chan":I
    :cond_0
    return-void
.end method

.method public clearOverrides(II)V
    .locals 2
    .param p1, "from"    # I
    .param p2, "to"    # I

    .line 720
    move v0, p1

    .local v0, "ch":I
    :goto_0
    if-gt v0, p2, :cond_0

    const/16 v1, 0x10

    if-ge v0, v1, :cond_0

    .line 721
    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->controls:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v1}, Lnet/duceng/xmidi/util/MyArray;->clear()V

    .line 720
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 723
    .end local v0    # "ch":I
    :cond_0
    return-void
.end method

.method public execEvent(Lnet/duceng/midi/MidiEvent;)V
    .locals 10
    .param p1, "event"    # Lnet/duceng/midi/MidiEvent;

    .line 630
    instance-of v0, p1, Lnet/duceng/midi/EventChannel;

    if-eqz v0, :cond_1

    .line 631
    move-object v0, p1

    check-cast v0, Lnet/duceng/midi/EventChannel;

    .line 632
    .local v0, "e":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v1

    packed-switch v1, :pswitch_data_0

    :pswitch_0
    goto :goto_0

    .line 648
    :pswitch_1
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v1

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v2

    and-int/lit8 v2, v2, 0x7f

    shl-int/lit8 v2, v2, 0x7

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v3

    and-int/lit8 v3, v3, 0x7f

    or-int/2addr v2, v3

    invoke-direct {p0, v1, v2}, Lnet/duceng/xsynth/Synth;->pitchBend(II)V

    goto :goto_0

    .line 643
    :pswitch_2
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v1

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v2

    invoke-direct {p0, v1, v2}, Lnet/duceng/xsynth/Synth;->programChange(II)V

    .line 644
    goto :goto_0

    .line 640
    :pswitch_3
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v1

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v2

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v3

    invoke-direct {p0, v1, v2, v3}, Lnet/duceng/xsynth/Synth;->controlChange(III)V

    .line 641
    goto :goto_0

    .line 637
    :pswitch_4
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v1

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v2

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v3

    invoke-direct {p0, v1, v2, v3}, Lnet/duceng/xsynth/Synth;->noteOn(III)V

    .line 638
    goto :goto_0

    .line 634
    :pswitch_5
    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v1

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v2

    invoke-direct {p0, v1, v2}, Lnet/duceng/xsynth/Synth;->noteOff(II)V

    .line 635
    nop

    .line 651
    :goto_0
    iget-boolean v1, p0, Lnet/duceng/xsynth/Synth;->recording:Z

    if-eqz v1, :cond_1

    iget-boolean v1, p0, Lnet/duceng/xsynth/Synth;->playing:Z

    if-eqz v1, :cond_1

    .line 652
    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    if-nez v1, :cond_0

    .line 653
    new-instance v1, Lnet/duceng/midi/MidiTrack;

    invoke-direct {v1}, Lnet/duceng/midi/MidiTrack;-><init>()V

    iput-object v1, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    .line 655
    :cond_0
    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v1}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/midi/MetaTempo;->getMpqn()I

    move-result v1

    div-int/lit16 v1, v1, 0x3e8

    iget-object v2, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v2}, Lnet/duceng/midi/MidiFile;->getResolution()I

    move-result v2

    div-int/2addr v1, v2

    .line 656
    .local v1, "millisecondsPerTick":I
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iget-wide v4, p0, Lnet/duceng/xsynth/Synth;->lastBeatMillis:J

    sub-long/2addr v2, v4

    int-to-long v4, v1

    div-long/2addr v2, v4

    long-to-int v3, v2

    .line 657
    .local v3, "tick":I
    new-instance v2, Lnet/duceng/midi/EventChannel;

    iget v4, p0, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    add-int v5, v4, v3

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v6

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v7

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v8

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v9

    move-object v4, v2

    invoke-direct/range {v4 .. v9}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    .line 658
    .local v2, "ne":Lnet/duceng/midi/MidiEvent;
    iget-object v4, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    invoke-virtual {v4, v2}, Lnet/duceng/midi/MidiTrack;->insert(Lnet/duceng/midi/MidiEvent;)V

    .line 661
    .end local v0    # "e":Lnet/duceng/midi/EventChannel;
    .end local v1    # "millisecondsPerTick":I
    .end local v2    # "ne":Lnet/duceng/midi/MidiEvent;
    .end local v3    # "tick":I
    :cond_1
    return-void

    :pswitch_data_0
    .packed-switch 0x8
        :pswitch_5
        :pswitch_4
        :pswitch_0
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public freeInstance()V
    .locals 1

    .line 129
    invoke-virtual {p0}, Lnet/duceng/xsynth/Synth;->stop()V

    .line 130
    iget v0, p0, Lnet/duceng/xsynth/Synth;->bound:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lnet/duceng/xsynth/Synth;->bound:I

    .line 131
    iget v0, p0, Lnet/duceng/xsynth/Synth;->bound:I

    if-gtz v0, :cond_0

    .line 132
    invoke-direct {p0}, Lnet/duceng/xsynth/Synth;->release()V

    .line 133
    const/4 v0, 0x0

    sput-object v0, Lnet/duceng/xsynth/Synth;->instance:Lnet/duceng/xsynth/Synth;

    .line 135
    :cond_0
    return-void
.end method

.method public getBank(I)I
    .locals 1
    .param p1, "chan"    # I

    .line 315
    invoke-static {p1}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetBank(I)I

    move-result v0

    return v0
.end method

.method public getBaseVolume(I)I
    .locals 1
    .param p1, "chan"    # I

    .line 588
    if-ltz p1, :cond_0

    const/16 v0, 0x10

    if-ge p1, v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->baseVolume:[I

    aget v0, v0, p1

    goto :goto_0

    :cond_0
    const/16 v0, 0x64

    :goto_0
    return v0
.end method

.method public getBeatNote1()B
    .locals 1

    .line 1050
    iget-byte v0, p0, Lnet/duceng/xsynth/Synth;->beatNote1:B

    return v0
.end method

.method public getBeatNote2()B
    .locals 1

    .line 1058
    iget-byte v0, p0, Lnet/duceng/xsynth/Synth;->beatNote2:B

    return v0
.end method

.method public getBeatPercent()F
    .locals 6

    .line 1036
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MetaTempo;->getBpm()I

    move-result v0

    const v1, 0xea60

    div-int/2addr v1, v0

    .line 1037
    .local v1, "interval":I
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iget-wide v4, p0, Lnet/duceng/xsynth/Synth;->lastBeatMillis:J

    sub-long/2addr v2, v4

    long-to-float v0, v2

    .line 1038
    .local v0, "elapsed":F
    int-to-float v2, v1

    div-float v2, v0, v2

    return v2
.end method

.method public getBeatVelocity()B
    .locals 1

    .line 1042
    iget-byte v0, p0, Lnet/duceng/xsynth/Synth;->beatVelocity:B

    return v0
.end method

.method public getCC(II)I
    .locals 1
    .param p1, "chan"    # I
    .param p2, "ctrl"    # I

    .line 327
    invoke-static {p1, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetCC(II)I

    move-result v0

    return v0
.end method

.method public getChorus(I)I
    .locals 1
    .param p1, "chan"    # I

    .line 375
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH3:B

    invoke-static {p1, v0}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetCC(II)I

    move-result v0

    return v0
.end method

.method public getControl(II)I
    .locals 1
    .param p1, "chan"    # I
    .param p2, "ctrl"    # I

    .line 391
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->controls:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v0, p2}, Lnet/duceng/xmidi/util/MyArray;->indexOfKey(I)I

    move-result v0

    if-ltz v0, :cond_0

    .line 392
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->controls:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v0, p2}, Lnet/duceng/xmidi/util/MyArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    return v0

    .line 394
    :cond_0
    const/4 v0, -0x1

    return v0
.end method

.method public getControls(I)Lnet/duceng/xmidi/util/MyArray;
    .locals 1
    .param p1, "chan"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lnet/duceng/xmidi/util/MyArray<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 387
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->controls:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/MyArray;

    return-object v0
.end method

.method public getFile()Ljava/io/File;
    .locals 1

    .line 680
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->file:Ljava/io/File;

    return-object v0
.end method

.method public getFontFile(I)Ljava/io/File;
    .locals 3
    .param p1, "chan"    # I

    .line 268
    invoke-virtual {p0, p1}, Lnet/duceng/xsynth/Synth;->getSFont(I)I

    move-result v0

    .line 269
    .local v0, "sfont_id":I
    if-lez v0, :cond_1

    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v1, v0}, Lnet/duceng/xmidi/util/MyArray;->indexOfKey(I)I

    move-result v1

    if-gez v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v1, v0}, Lnet/duceng/xmidi/util/MyArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    goto :goto_1

    :cond_1
    :goto_0
    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/util/MyArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    :goto_1
    check-cast v1, Ljava/io/File;

    return-object v1
.end method

.method public getGain()F
    .locals 1

    .line 273
    invoke-static {}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetGain()F

    move-result v0

    return v0
.end method

.method public getLastBeatTicks()I
    .locals 1

    .line 1066
    iget v0, p0, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    return v0
.end method

.method public getListenChan()I
    .locals 1

    .line 556
    iget-byte v0, p0, Lnet/duceng/xsynth/Synth;->listenChan:B

    return v0
.end method

.method public getMidiFile()Lnet/duceng/midi/MidiFile;
    .locals 1

    .line 676
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    return-object v0
.end method

.method public getNumerator()I
    .locals 1

    .line 664
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTimeSignature()Lnet/duceng/midi/MetaTimeSignature;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MetaTimeSignature;->getNumerator()B

    move-result v0

    return v0
.end method

.method public getPan(I)I
    .locals 1
    .param p1, "chan"    # I

    .line 351
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->PAN_MSB:B

    invoke-static {p1, v0}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetCC(II)I

    move-result v0

    return v0
.end method

.method public getPitchBend(I)I
    .locals 1
    .param p1, "chan"    # I

    .line 335
    invoke-static {p1}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetPitchBend(I)I

    move-result v0

    return v0
.end method

.method public getPolyphony()F
    .locals 1

    .line 281
    invoke-static {}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetPolyphony()I

    move-result v0

    int-to-float v0, v0

    return v0
.end method

.method public getPreset(I)I
    .locals 1
    .param p1, "chan"    # I

    .line 319
    invoke-static {p1}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetPreset(I)I

    move-result v0

    return v0
.end method

.method public getRecordChan()I
    .locals 1

    .line 548
    iget-byte v0, p0, Lnet/duceng/xsynth/Synth;->recordChan:B

    return v0
.end method

.method public getRecordTrack()Lnet/duceng/midi/MidiTrack;
    .locals 1

    .line 672
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    return-object v0
.end method

.method public getResolution()I
    .locals 1

    .line 668
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getResolution()I

    move-result v0

    return v0
.end method

.method public getReverb(I)I
    .locals 1
    .param p1, "chan"    # I

    .line 367
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH1:B

    invoke-static {p1, v0}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetCC(II)I

    move-result v0

    return v0
.end method

.method public getSFont(I)I
    .locals 1
    .param p1, "chan"    # I

    .line 311
    invoke-static {p1}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetSFont(I)I

    move-result v0

    return v0
.end method

.method public getSFonts()Lnet/duceng/xmidi/util/MyArray;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lnet/duceng/xmidi/util/MyArray<",
            "Ljava/io/File;",
            ">;"
        }
    .end annotation

    .line 264
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    return-object v0
.end method

.method public getScores()[Z
    .locals 1

    .line 410
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->scores:[Z

    return-object v0
.end method

.method public getSustain(I)I
    .locals 1
    .param p1, "chan"    # I

    .line 359
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->SUSTAIN_SWITCH:B

    invoke-static {p1, v0}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetCC(II)I

    move-result v0

    return v0
.end method

.method public getVolume(I)I
    .locals 1
    .param p1, "chan"    # I

    .line 343
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->VOLUME_MSB:B

    invoke-static {p1, v0}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetCC(II)I

    move-result v0

    return v0
.end method

.method public init(Landroid/content/Context;)V
    .locals 12
    .param p1, "content"    # Landroid/content/Context;

    .line 142
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->inited:Z

    if-nez v0, :cond_6

    .line 143
    invoke-static {p1}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 144
    .local v0, "pref":Landroid/content/SharedPreferences;
    invoke-static {p1}, Lnet/duceng/xsynth/Synth;->isInitialized(Landroid/content/Context;)Z

    move-result v1

    .line 145
    .local v1, "synth_init":Z
    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v1, :cond_3

    .line 147
    :try_start_0
    new-instance v4, Ljava/io/File;

    sget-object v5, Lnet/duceng/xsynth/Synth;->DEFAULT_FONT:Ljava/lang/String;

    invoke-direct {v4, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 148
    .local v4, "font":Ljava/io/File;
    invoke-virtual {v4}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v5

    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v5

    if-nez v5, :cond_0

    .line 149
    invoke-virtual {v4}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v5

    invoke-virtual {v5}, Ljava/io/File;->mkdirs()Z

    .line 151
    :cond_0
    invoke-virtual {v4}, Ljava/io/File;->createNewFile()Z

    .line 152
    invoke-virtual {p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v5

    invoke-virtual {v4}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v5

    .line 153
    .local v5, "inputStream":Ljava/io/InputStream;
    new-instance v6, Ljava/io/FileOutputStream;

    invoke-direct {v6, v4}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 154
    .local v6, "outputStream":Ljava/io/OutputStream;
    const/16 v7, 0x4000

    new-array v7, v7, [B

    .line 156
    .local v7, "buff":[B
    :goto_0
    invoke-virtual {v5, v7}, Ljava/io/InputStream;->read([B)I

    move-result v8

    .line 157
    .local v8, "nLen":I
    if-gtz v8, :cond_2

    .line 158
    nop

    .line 163
    .end local v8    # "nLen":I
    invoke-virtual {v6}, Ljava/io/OutputStream;->close()V

    .line 164
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    .line 165
    new-instance v8, Ljava/io/File;

    sget-object v9, Lnet/duceng/xsynth/Synth;->PATH_RECORD:Ljava/lang/String;

    invoke-direct {v8, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 166
    .local v8, "dir":Ljava/io/File;
    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    move-result v9

    if-nez v9, :cond_1

    .line 167
    invoke-virtual {v8}, Ljava/io/File;->mkdirs()Z

    .line 169
    :cond_1
    const-string v9, "midi"

    sget-object v10, Lnet/duceng/xsynth/Synth;->PATH_MIDI:Ljava/lang/String;

    invoke-direct {p0, p1, v9, v10}, Lnet/duceng/xsynth/Synth;->init_dir(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 170
    const-string v9, "sty"

    sget-object v10, Lnet/duceng/xsynth/Synth;->PATH_STY:Ljava/lang/String;

    invoke-direct {p0, p1, v9, v10}, Lnet/duceng/xsynth/Synth;->init_dir(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 171
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    .line 172
    .local v9, "editor":Landroid/content/SharedPreferences$Editor;
    sget-object v10, Lnet/duceng/xmidi/Settings;->SYNTH_INIT:Ljava/lang/String;

    invoke-interface {v9, v10, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 173
    const-string v10, "synth_init_root"

    sget-object v11, Lnet/duceng/xsynth/Synth;->PATH_ROOT:Ljava/lang/String;

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 174
    invoke-interface {v9}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 177
    nop

    .end local v4    # "font":Ljava/io/File;
    .end local v5    # "inputStream":Ljava/io/InputStream;
    .end local v6    # "outputStream":Ljava/io/OutputStream;
    .end local v7    # "buff":[B
    .end local v8    # "dir":Ljava/io/File;
    .end local v9    # "editor":Landroid/content/SharedPreferences$Editor;
    goto :goto_1

    .line 160
    .restart local v4    # "font":Ljava/io/File;
    .restart local v5    # "inputStream":Ljava/io/InputStream;
    .restart local v6    # "outputStream":Ljava/io/OutputStream;
    .restart local v7    # "buff":[B
    .local v8, "nLen":I
    :cond_2
    invoke-virtual {v6, v7, v2, v8}, Ljava/io/OutputStream;->write([BII)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 162
    .end local v8    # "nLen":I
    goto :goto_0

    .line 175
    .end local v4    # "font":Ljava/io/File;
    .end local v5    # "inputStream":Ljava/io/InputStream;
    .end local v6    # "outputStream":Ljava/io/OutputStream;
    .end local v7    # "buff":[B
    :catch_0
    move-exception v4

    .line 176
    .local v4, "e":Ljava/io/IOException;
    invoke-virtual {v4}, Ljava/io/IOException;->printStackTrace()V

    .line 179
    .end local v4    # "e":Ljava/io/IOException;
    :cond_3
    :goto_1
    sget-object v4, Lnet/duceng/xmidi/Settings;->SYNTH_GAIN:Ljava/lang/String;

    const/4 v5, 0x3

    invoke-interface {v0, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    .line 180
    .local v4, "gain":I
    int-to-float v5, v4

    const/high16 v6, 0x41200000    # 10.0f

    div-float/2addr v5, v6

    invoke-virtual {p0, v5}, Lnet/duceng/xsynth/Synth;->setGain(F)V

    .line 181
    sget-object v5, Lnet/duceng/xmidi/Settings;->SYNTH_POLYPHONY:Ljava/lang/String;

    const/16 v6, 0x80

    invoke-interface {v0, v5, v6}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v5

    .line 182
    .local v5, "polyphony":I
    invoke-virtual {p0, v5}, Lnet/duceng/xsynth/Synth;->setPolyphony(I)V

    .line 183
    sget-object v6, Lnet/duceng/xmidi/Settings;->SYNTH_BEATVEL:Ljava/lang/String;

    const/16 v7, 0x4b

    invoke-interface {v0, v6, v7}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v6

    int-to-byte v6, v6

    iput-byte v6, p0, Lnet/duceng/xsynth/Synth;->beatVelocity:B

    .line 184
    sget-object v6, Lnet/duceng/xmidi/Settings;->SYNTH_BEATNOTE1:Ljava/lang/String;

    const/16 v7, 0x22

    invoke-interface {v0, v6, v7}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v6

    int-to-byte v6, v6

    iput-byte v6, p0, Lnet/duceng/xsynth/Synth;->beatNote1:B

    .line 185
    sget-object v6, Lnet/duceng/xmidi/Settings;->SYNTH_BEATNOTE2:Ljava/lang/String;

    const/16 v7, 0x21

    invoke-interface {v0, v6, v7}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v6

    int-to-byte v6, v6

    iput-byte v6, p0, Lnet/duceng/xsynth/Synth;->beatNote2:B

    .line 186
    sget-object v6, Lnet/duceng/xmidi/Settings;->SYNTH_SFONT_DEFAULT:Ljava/lang/String;

    sget-object v7, Lnet/duceng/xmidi/Settings;->SYNTH_SFONT_DEFAULT_VAL:Ljava/lang/String;

    invoke-interface {v0, v6, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 187
    .local v6, "sfont_default":Ljava/lang/String;
    new-instance v7, Ljava/io/File;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v9, Lnet/duceng/xsynth/Synth;->PATH_FONT:Ljava/lang/String;

    invoke-static {v9}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    sget-object v9, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v7}, Lnet/duceng/xsynth/Synth;->loadSFont(Ljava/io/File;)I

    move-result v9

    const-string v7, "synth_sfont_second"

    const-string v8, ""

    invoke-interface {v0, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p0, v7}, Lnet/duceng/xsynth/Synth;->setFallbackByName(Ljava/lang/String;)V

    .line 188
    const/4 v7, 0x0

    .local v7, "i":I
    :goto_2
    const/16 v8, 0x10

    if-ge v7, v8, :cond_5

    if-lez v9, :xm_sfskip

    invoke-virtual {p0, v7, v9}, Lnet/duceng/xsynth/Synth;->setSFont(II)V

    :xm_sfskip
    .line 189
    const/16 v8, 0x9

    if-ne v7, v8, :cond_4

    .line 190
    invoke-virtual {p0, v7, v2}, Lnet/duceng/xsynth/Synth;->setPreset(II)V

    goto :goto_3

    .line 192
    :cond_4
    invoke-virtual {p0, v7}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v8

    invoke-virtual {p0, v7, v8}, Lnet/duceng/xsynth/Synth;->setPreset(II)V

    .line 188
    :goto_3
    add-int/lit8 v7, v7, 0x1

    goto :goto_2

    .line 195
    .end local v7    # "i":I
    :cond_5
    iput-boolean v3, p0, Lnet/duceng/xsynth/Synth;->inited:Z

    .line 197
    .end local v0    # "pref":Landroid/content/SharedPreferences;
    .end local v1    # "synth_init":Z
    .end local v4    # "gain":I
    .end local v5    # "polyphony":I
    .end local v6    # "sfont_default":Ljava/lang/String;
    :cond_6
    return-void
.end method

.method public isBeating()Z
    .locals 1

    .line 809
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->beating:Z

    return v0
.end method

.method public isInited()Z
    .locals 1

    .line 138
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->inited:Z

    return v0
.end method

.method public isMute(I)Z
    .locals 1
    .param p1, "chan"    # I

    .line 379
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->mutes:[Z

    aget-boolean v0, v0, p1

    return v0
.end method

.method public isPause()Z
    .locals 1

    .line 805
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->pause:Z

    return v0
.end method

.method public isPlaying()Z
    .locals 1

    .line 801
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->playing:Z

    return v0
.end method

.method public isRecording()Z
    .locals 1

    .line 813
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->recording:Z

    return v0
.end method

.method public isScore(I)Z
    .locals 1
    .param p1, "t"    # I

    .line 402
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->scores:[Z

    aget-boolean v0, v0, p1

    return v0
.end method

.method public keyOff(II)V
    .locals 1
    .param p1, "chan"    # I
    .param p2, "key"    # I

    .line 574
    if-ltz p1, :cond_1

    const/16 v0, 0xf

    if-gt p1, v0, :cond_1

    if-ltz p2, :cond_1

    const/16 v0, 0x7f

    if-le p2, v0, :cond_0

    goto :goto_0

    .line 577
    :cond_0
    invoke-direct {p0, p1, p2}, Lnet/duceng/xsynth/Synth;->noteOff(II)V

    .line 578
    return-void

    .line 575
    :cond_1
    :goto_0
    return-void
.end method

.method public keyOn(III)V
    .locals 2
    .param p1, "chan"    # I
    .param p2, "key"    # I
    .param p3, "vel"    # I

    .line 567
    if-ltz p1, :cond_1

    const/16 v0, 0xf

    if-gt p1, v0, :cond_1

    if-ltz p2, :cond_1

    const/16 v0, 0x7f

    if-le p2, v0, :cond_0

    goto :goto_0

    .line 570
    :cond_0
    const/4 v1, 0x1

    invoke-static {v0, p3}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-direct {p0, p1, p2, v0}, Lnet/duceng/xsynth/Synth;->noteOn(III)V

    .line 571
    return-void

    .line 568
    :cond_1
    :goto_0
    return-void
.end method

.method public keysOff(I)V
    .locals 2
    .param p1, "chan"    # I

    .line 582
    if-ltz p1, :cond_0

    const/16 v0, 0x10

    if-ge p1, v0, :cond_0

    .line 583
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->ALL_NOTES_OFF:B

    const/4 v1, 0x0

    invoke-static {p1, v0, v1}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 585
    :cond_0
    return-void
.end method

.method public loadSFont(Ljava/io/File;)I
    .locals 3
    .param p1, "f"    # Ljava/io/File;

    .line 243
    const/4 v0, -0x1

    .line 244
    .local v0, "sfont_id":I
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 245
    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v1, v2}, Lnet/duceng/xsynth/XSynth;->midiPlayerSFLoad(Ljava/lang/String;I)I

    move-result v0

    .line 246
    if-lez v0, :cond_0

    .line 247
    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v1, v0, p1}, Lnet/duceng/xmidi/util/MyArray;->put(ILjava/lang/Object;)V

    .line 249
    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Load SoundFont "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " return: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " Total: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {}, Lnet/duceng/xsynth/XSynth;->midiPlayerSFCount()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Synth"

    invoke-static {v2, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 251
    :cond_1
    return v0
.end method

.method public noteOff(B)V
    .locals 9
    .param p1, "key"    # B

    .line 617
    iget-byte v0, p0, Lnet/duceng/xsynth/Synth;->recordChan:B

    invoke-direct {p0, v0, p1}, Lnet/duceng/xsynth/Synth;->noteOff(II)V

    .line 618
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->recording:Z

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->playing:Z

    if-eqz v0, :cond_1

    .line 619
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    if-nez v0, :cond_0

    .line 620
    new-instance v0, Lnet/duceng/midi/MidiTrack;

    invoke-direct {v0}, Lnet/duceng/midi/MidiTrack;-><init>()V

    iput-object v0, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    .line 622
    :cond_0
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MetaTempo;->getMpqn()I

    move-result v0

    div-int/lit16 v0, v0, 0x3e8

    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v1}, Lnet/duceng/midi/MidiFile;->getResolution()I

    move-result v1

    div-int/2addr v0, v1

    .line 623
    .local v0, "millisecondsPerTick":I
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    iget-wide v3, p0, Lnet/duceng/xsynth/Synth;->lastBeatMillis:J

    sub-long/2addr v1, v3

    int-to-long v3, v0

    div-long/2addr v1, v3

    long-to-int v2, v1

    .line 624
    .local v2, "tick":I
    new-instance v1, Lnet/duceng/midi/EventChannel;

    iget v3, p0, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    add-int v4, v3, v2

    iget-byte v6, p0, Lnet/duceng/xsynth/Synth;->recordChan:B

    const/4 v8, 0x0

    const/16 v5, 0x8

    move-object v3, v1

    move v7, p1

    invoke-direct/range {v3 .. v8}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    .line 625
    .local v1, "e":Lnet/duceng/midi/MidiEvent;
    iget-object v3, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    invoke-virtual {v3, v1}, Lnet/duceng/midi/MidiTrack;->insert(Lnet/duceng/midi/MidiEvent;)V

    .line 627
    .end local v0    # "millisecondsPerTick":I
    .end local v1    # "e":Lnet/duceng/midi/MidiEvent;
    .end local v2    # "tick":I
    :cond_1
    return-void
.end method

.method public noteOn(BB)V
    .locals 9
    .param p1, "key"    # B
    .param p2, "vel"    # B

    .line 600
    if-nez p2, :cond_0

    .line 601
    invoke-virtual {p0, p1}, Lnet/duceng/xsynth/Synth;->noteOff(B)V

    .line 602
    return-void

    .line 604
    :cond_0
    iget-byte v0, p0, Lnet/duceng/xsynth/Synth;->recordChan:B

    invoke-direct {p0, v0, p1, p2}, Lnet/duceng/xsynth/Synth;->noteOn(III)V

    .line 605
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->recording:Z

    if-eqz v0, :cond_2

    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->playing:Z

    if-eqz v0, :cond_2

    .line 606
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    if-nez v0, :cond_1

    .line 607
    new-instance v0, Lnet/duceng/midi/MidiTrack;

    invoke-direct {v0}, Lnet/duceng/midi/MidiTrack;-><init>()V

    iput-object v0, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    .line 609
    :cond_1
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MetaTempo;->getMpqn()I

    move-result v0

    div-int/lit16 v0, v0, 0x3e8

    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v1}, Lnet/duceng/midi/MidiFile;->getResolution()I

    move-result v1

    div-int/2addr v0, v1

    .line 610
    .local v0, "millisecondsPerTick":I
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    iget-wide v3, p0, Lnet/duceng/xsynth/Synth;->lastBeatMillis:J

    sub-long/2addr v1, v3

    int-to-long v3, v0

    div-long/2addr v1, v3

    long-to-int v2, v1

    .line 611
    .local v2, "tick":I
    new-instance v1, Lnet/duceng/midi/EventChannel;

    iget v3, p0, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    add-int v4, v3, v2

    const/16 v5, 0x9

    iget-byte v6, p0, Lnet/duceng/xsynth/Synth;->recordChan:B

    move-object v3, v1

    move v7, p1

    move v8, p2

    invoke-direct/range {v3 .. v8}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    .line 612
    .local v1, "e":Lnet/duceng/midi/MidiEvent;
    iget-object v3, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    invoke-virtual {v3, v1}, Lnet/duceng/midi/MidiTrack;->insert(Lnet/duceng/midi/MidiEvent;)V

    .line 614
    .end local v0    # "millisecondsPerTick":I
    .end local v1    # "e":Lnet/duceng/midi/MidiEvent;
    .end local v2    # "tick":I
    :cond_2
    return-void
.end method

.method public pause()V
    .locals 1

    .line 832
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xsynth/Synth;->playing:Z

    .line 833
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xsynth/Synth;->pause:Z

    .line 834
    return-void
.end method

.method public play()V
    .locals 2

    .line 817
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->mExecutor:Ljava/util/concurrent/ExecutorService;

    if-nez v0, :cond_0

    .line 818
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xsynth/Synth;->mExecutor:Ljava/util/concurrent/ExecutorService;

    .line 819
    new-instance v0, Lnet/duceng/xsynth/Synth$1;

    invoke-direct {v0, p0}, Lnet/duceng/xsynth/Synth$1;-><init>(Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xsynth/Synth;->mRunnable:Ljava/lang/Runnable;

    .line 826
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xsynth/Synth;->playing:Z

    .line 827
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xsynth/Synth;->pause:Z

    .line 828
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->mExecutor:Ljava/util/concurrent/ExecutorService;

    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->mRunnable:Ljava/lang/Runnable;

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 829
    return-void
.end method

.method public playing()V
    .locals 2

    .line 863
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xsynth/Synth;->playLoopActive:Z

    .line 865
    const/4 v0, 0x0

    :try_start_0
    invoke-direct {p0}, Lnet/duceng/xsynth/Synth;->playingInner()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 867
    iput-boolean v0, p0, Lnet/duceng/xsynth/Synth;->playLoopActive:Z

    .line 868
    nop

    .line 869
    return-void

    .line 867
    :catchall_0
    move-exception v1

    iput-boolean v0, p0, Lnet/duceng/xsynth/Synth;->playLoopActive:Z

    .line 868
    throw v1
.end method

.method public refreshVolume(I)V
    .locals 2
    .param p1, "chan"    # I

    .line 463
    if-ltz p1, :cond_0

    const/16 v0, 0x10

    if-ge p1, v0, :cond_0

    .line 464
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->VOLUME_MSB:B

    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->baseVolume:[I

    aget v1, v1, p1

    invoke-direct {p0, p1, v0, v1}, Lnet/duceng/xsynth/Synth;->controlChange(III)V

    .line 466
    :cond_0
    return-void
.end method

.method public resetChannels(II)V
    .locals 4
    .param p1, "from"    # I
    .param p2, "to"    # I

    .line 727
    move v0, p1

    .local v0, "ch":I
    :goto_0
    if-gt v0, p2, :cond_1

    const/16 v1, 0x10

    if-ge v0, v1, :cond_1

    .line 728
    sget-byte v1, Lnet/duceng/xsynth/XSynth;->ALL_CTRL_OFF:B

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 729
    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->baseVolume:[I

    const/16 v3, 0x64

    aput v3, v1, v0

    .line 730
    sget-byte v1, Lnet/duceng/xsynth/XSynth;->VOLUME_MSB:B

    invoke-static {v0, v1, v3}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 731
    sget-byte v1, Lnet/duceng/xsynth/XSynth;->PAN_MSB:B

    const/16 v3, 0x40

    invoke-static {v0, v1, v3}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 732
    sget-byte v1, Lnet/duceng/xsynth/XSynth;->EXPRESSION_MSB:B

    const/16 v3, 0x7f

    invoke-static {v0, v1, v3}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 733
    sget-byte v1, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH1:B

    const/16 v3, 0x28

    invoke-static {v0, v1, v3}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 734
    sget-byte v1, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH3:B

    invoke-static {v0, v1, v2}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 735
    const/16 v1, 0x2000

    invoke-static {v0, v1}, Lnet/duceng/xsynth/XSynth;->midiPlayerPitchBend(II)V

    .line 736
    sget-byte v1, Lnet/duceng/xsynth/Synth;->DRUMS_CHAN:B

    if-eq v0, v1, :cond_0

    .line 737
    invoke-static {v0, v2}, Lnet/duceng/xsynth/XSynth;->midiPlayerBankSelect(II)V

    .line 739
    :cond_0
    invoke-static {v0, v2}, Lnet/duceng/xsynth/XSynth;->midiPlayerProgramChange(II)V

    .line 727
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 741
    .end local v0    # "ch":I
    :cond_1
    return-void
.end method

.method public setBank(II)V
    .locals 0
    .param p1, "chan"    # I
    .param p2, "bank"    # I

    .line 293
    invoke-static {p1, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerBankSelect(II)V

    .line 294
    return-void
.end method

.method public setBeatListener(Lnet/duceng/xsynth/Synth$BeatListener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xsynth/Synth$BeatListener;

    .line 1070
    iput-object p1, p0, Lnet/duceng/xsynth/Synth;->beatListener:Lnet/duceng/xsynth/Synth$BeatListener;

    .line 1071
    return-void
.end method

.method public setBeatNote1(B)V
    .locals 0
    .param p1, "beatNote1"    # B

    .line 1054
    iput-byte p1, p0, Lnet/duceng/xsynth/Synth;->beatNote1:B

    .line 1055
    return-void
.end method

.method public setBeatNote2(B)V
    .locals 0
    .param p1, "beatNote2"    # B

    .line 1062
    iput-byte p1, p0, Lnet/duceng/xsynth/Synth;->beatNote2:B

    .line 1063
    return-void
.end method

.method public setBeatVelocity(B)V
    .locals 0
    .param p1, "beatVelocity"    # B

    .line 1046
    iput-byte p1, p0, Lnet/duceng/xsynth/Synth;->beatVelocity:B

    .line 1047
    return-void
.end method

.method public setBeating(Z)V
    .locals 0
    .param p1, "b"    # Z

    .line 843
    iput-boolean p1, p0, Lnet/duceng/xsynth/Synth;->beating:Z

    .line 844
    return-void
.end method

.method public setCC(III)V
    .locals 0
    .param p1, "chan"    # I
    .param p2, "ctrl"    # I
    .param p3, "val"    # I

    .line 323
    invoke-static {p1, p2, p3}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 324
    return-void
.end method

.method public setChorus(II)V
    .locals 1
    .param p1, "chan"    # I
    .param p2, "val"    # I

    .line 371
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH3:B

    invoke-static {p1, v0, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 372
    return-void
.end method

.method public setControl(III)V
    .locals 2
    .param p1, "chan"    # I
    .param p2, "ctrl"    # I
    .param p3, "val"    # I

    .line 398
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->controls:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/MyArray;

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, p2, v1}, Lnet/duceng/xmidi/util/MyArray;->put(ILjava/lang/Object;)V

    .line 399
    return-void
.end method

.method public setFile(Ljava/io/File;)V
    .locals 5
    .param p1, "f"    # Ljava/io/File;

    .line 684
    invoke-virtual {p0}, Lnet/duceng/xsynth/Synth;->stop()V

    .line 685
    iput-object p1, p0, Lnet/duceng/xsynth/Synth;->file:Ljava/io/File;

    .line 686
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->file:Ljava/io/File;

    if-nez v0, :cond_0

    .line 687
    new-instance v0, Lnet/duceng/midi/MidiFile;

    invoke-direct {v0}, Lnet/duceng/midi/MidiFile;-><init>()V

    iput-object v0, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    .line 688
    return-void

    .line 691
    :cond_0
    :try_start_0
    new-instance v0, Lnet/duceng/midi/MidiFile;

    new-instance v1, Ljava/io/FileInputStream;

    iget-object v2, p0, Lnet/duceng/xsynth/Synth;->file:Ljava/io/File;

    invoke-direct {v1, v2}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    invoke-direct {v0, v1}, Lnet/duceng/midi/MidiFile;-><init>(Ljava/io/InputStream;)V

    iput-object v0, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 694
    goto :goto_0

    .line 692
    :catch_0
    move-exception v0

    .line 693
    .local v0, "e1":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 695
    .end local v0    # "e1":Ljava/lang/Exception;
    :goto_0
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getCount()I

    move-result v0

    new-array v0, v0, [Z

    iput-object v0, p0, Lnet/duceng/xsynth/Synth;->scores:[Z

    .line 696
    const/4 v0, -0x1

    .line 697
    .local v0, "prog":I
    const/4 v1, 0x0

    .local v1, "c":I
    :goto_1
    iget-object v2, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v2}, Lnet/duceng/midi/MidiFile;->getCount()I

    move-result v2

    const/4 v3, 0x0

    if-ge v1, v2, :cond_3

    .line 698
    iget-object v2, p0, Lnet/duceng/xsynth/Synth;->midiFile:Lnet/duceng/midi/MidiFile;

    invoke-virtual {v2}, Lnet/duceng/midi/MidiFile;->getTracks()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/midi/MidiTrack;

    .line 699
    .local v2, "t":Lnet/duceng/midi/MidiTrack;
    iget-object v4, p0, Lnet/duceng/xsynth/Synth;->scores:[Z

    aput-boolean v3, v4, v1

    .line 700
    invoke-virtual {v2}, Lnet/duceng/midi/MidiTrack;->getChannel()B

    move-result v3

    if-ltz v3, :cond_2

    .line 701
    const/4 v3, -0x1

    const/4 v4, 0x1

    if-ne v0, v3, :cond_1

    .line 702
    iget-object v3, p0, Lnet/duceng/xsynth/Synth;->scores:[Z

    aput-boolean v4, v3, v1

    .line 703
    invoke-virtual {v2}, Lnet/duceng/midi/MidiTrack;->getProgram()B

    move-result v0

    goto :goto_2

    .line 704
    :cond_1
    invoke-virtual {v2}, Lnet/duceng/midi/MidiTrack;->getProgram()B

    move-result v3

    if-ne v3, v0, :cond_2

    .line 705
    iget-object v3, p0, Lnet/duceng/xsynth/Synth;->scores:[Z

    aput-boolean v4, v3, v1

    .line 697
    .end local v2    # "t":Lnet/duceng/midi/MidiTrack;
    :cond_2
    :goto_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 709
    .end local v1    # "c":I
    :cond_3
    iput-boolean v3, p0, Lnet/duceng/xsynth/Synth;->styleMix:Z

    .line 710
    invoke-direct {p0}, Lnet/duceng/xsynth/Synth;->applyFileSetup()V

    .line 711
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 712
    return-void
.end method

.method public setGain(F)V
    .locals 0
    .param p1, "gain"    # F

    .line 277
    invoke-static {p1}, Lnet/duceng/xsynth/XSynth;->midiPlayerSetGain(F)V

    .line 278
    return-void
.end method

.method public setKeyVolume(II)V
    .locals 3
    .param p1, "chan"    # I
    .param p2, "v"    # I

    .line 593
    if-ltz p1, :cond_0

    const/16 v0, 0x10

    if-ge p1, v0, :cond_0

    .line 594
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->baseVolume:[I

    const/16 v1, 0x7f

    invoke-static {v1, p2}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v2, 0x0

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    aput v1, v0, p1

    .line 595
    invoke-virtual {p0, p1}, Lnet/duceng/xsynth/Synth;->refreshVolume(I)V

    .line 597
    :cond_0
    return-void
.end method

.method public setListenChan(B)V
    .locals 0
    .param p1, "chan"    # B

    .line 560
    iput-byte p1, p0, Lnet/duceng/xsynth/Synth;->listenChan:B

    .line 561
    return-void
.end method

.method public setMute(IZ)V
    .locals 1
    .param p1, "chan"    # I
    .param p2, "val"    # Z

    .line 383
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->mutes:[Z

    aput-boolean p2, v0, p1

    .line 384
    return-void
.end method

.method public setPan(II)V
    .locals 1
    .param p1, "chan"    # I
    .param p2, "val"    # I

    .line 347
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->PAN_MSB:B

    invoke-static {p1, v0, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 348
    return-void
.end method

.method public setPitchBend(II)V
    .locals 0
    .param p1, "chan"    # I
    .param p2, "val"    # I

    .line 331
    invoke-static {p1, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerPitchBend(II)V

    .line 332
    return-void
.end method

.method public setPolyphony(I)V
    .locals 0
    .param p1, "polyphony"    # I

    .line 285
    invoke-static {p1}, Lnet/duceng/xsynth/XSynth;->midiPlayerSetPolyphony(I)V

    .line 286
    return-void
.end method

.method public setPreset(II)V
    .locals 1
    .param p1, "chan"    # I
    .param p2, "val"    # I

    .line 297
    invoke-static {p1, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerProgramChange(II)V

    .line 298
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->styleMix:Z

    if-eqz v0, :cond_0

    const/16 v0, 0x8

    if-lt p1, v0, :cond_0

    .line 299
    invoke-virtual {p0, p1}, Lnet/duceng/xsynth/Synth;->refreshVolume(I)V

    .line 301
    :cond_0
    return-void
.end method

.method public setProgram(IIII)V
    .locals 1
    .param p1, "chan"    # I
    .param p2, "sfont_id"    # I
    .param p3, "bank_num"    # I
    .param p4, "preset_num"    # I

    .line 304
    invoke-static {p1, p2, p3, p4}, Lnet/duceng/xsynth/XSynth;->midiPlayerProgramSelect(IIII)V

    .line 305
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->styleMix:Z

    if-eqz v0, :cond_0

    const/16 v0, 0x8

    if-lt p1, v0, :cond_0

    .line 306
    invoke-virtual {p0, p1}, Lnet/duceng/xsynth/Synth;->refreshVolume(I)V

    .line 308
    :cond_0
    return-void
.end method

.method public setRecordChan(B)V
    .locals 0
    .param p1, "chan"    # B

    .line 552
    iput-byte p1, p0, Lnet/duceng/xsynth/Synth;->recordChan:B

    .line 553
    return-void
.end method

.method public setRecording(Z)V
    .locals 2
    .param p1, "r"    # Z

    .line 847
    iput-boolean p1, p0, Lnet/duceng/xsynth/Synth;->recording:Z

    .line 848
    iget-boolean v0, p0, Lnet/duceng/xsynth/Synth;->recording:Z

    if-eqz v0, :cond_0

    .line 849
    new-instance v0, Lnet/duceng/midi/MidiTrack;

    invoke-direct {v0}, Lnet/duceng/midi/MidiTrack;-><init>()V

    iput-object v0, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    .line 850
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    iget-byte v1, p0, Lnet/duceng/xsynth/Synth;->recordChan:B

    invoke-virtual {v0, v1}, Lnet/duceng/midi/MidiTrack;->setChannel(B)V

    .line 851
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->recordTrack:Lnet/duceng/midi/MidiTrack;

    iget-byte v1, p0, Lnet/duceng/xsynth/Synth;->recordChan:B

    invoke-virtual {p0, v1}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v1

    int-to-byte v1, v1

    invoke-virtual {v0, v1}, Lnet/duceng/midi/MidiTrack;->setProgram(B)V

    .line 853
    :cond_0
    return-void
.end method

.method public setReverb(II)V
    .locals 1
    .param p1, "chan"    # I
    .param p2, "val"    # I

    .line 363
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH1:B

    invoke-static {p1, v0, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 364
    return-void
.end method

.method public setSFont(II)V
    .locals 0
    .param p1, "chan"    # I
    .param p2, "sfont_id"    # I

    .line 289
    invoke-static {p1, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerSFontSelect(II)V

    .line 290
    return-void
.end method

.method public setScore(IZ)V
    .locals 1
    .param p1, "t"    # I
    .param p2, "val"    # Z

    .line 406
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->scores:[Z

    aput-boolean p2, v0, p1

    .line 407
    return-void
.end method

.method public setStatusListener(Lnet/duceng/xsynth/Synth$StatusListener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xsynth/Synth$StatusListener;

    .line 1074
    iput-object p1, p0, Lnet/duceng/xsynth/Synth;->statusListener:Lnet/duceng/xsynth/Synth$StatusListener;

    .line 1075
    return-void
.end method

.method public setStyleMix(Z)V
    .locals 0
    .param p1, "on"    # Z

    .line 479
    iput-boolean p1, p0, Lnet/duceng/xsynth/Synth;->styleMix:Z

    .line 480
    return-void
.end method

.method public setSustain(II)V
    .locals 1
    .param p1, "chan"    # I
    .param p2, "val"    # I

    .line 355
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->SUSTAIN_SWITCH:B

    invoke-static {p1, v0, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 356
    return-void
.end method

.method public setVolume(II)V
    .locals 1
    .param p1, "chan"    # I
    .param p2, "val"    # I

    .line 339
    sget-byte v0, Lnet/duceng/xsynth/XSynth;->VOLUME_MSB:B

    invoke-static {p1, v0, p2}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 340
    return-void
.end method

.method public silenceChannels(II)V
    .locals 3
    .param p1, "from"    # I
    .param p2, "to"    # I

    .line 415
    move v0, p1

    .local v0, "chan":I
    :goto_0
    if-gt v0, p2, :cond_0

    const/16 v1, 0x10

    if-ge v0, v1, :cond_0

    .line 416
    sget-byte v1, Lnet/duceng/xsynth/XSynth;->ALL_NOTES_OFF:B

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Lnet/duceng/xsynth/XSynth;->midiPlayerCC(III)V

    .line 415
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 418
    .end local v0    # "chan":I
    :cond_0
    return-void
.end method

.method public stop()V
    .locals 1

    .line 837
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xsynth/Synth;->playing:Z

    .line 838
    iput-boolean v0, p0, Lnet/duceng/xsynth/Synth;->pause:Z

    .line 839
    iput v0, p0, Lnet/duceng/xsynth/Synth;->lastBeatTicks:I

    .line 840
    return-void
.end method

.method public unloadSFont(Ljava/io/File;)V
    .locals 3
    .param p1, "f"    # Ljava/io/File;

    .line 255
    iget-object v0, p0, Lnet/duceng/xsynth/Synth;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/util/MyArray;->indexOfValue(Ljava/lang/Object;)I

    move-result v0

    .line 256
    .local v0, "index":I
    if-ltz v0, :cond_0

    .line 257
    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v1, v0}, Lnet/duceng/xmidi/util/MyArray;->keyAt(I)I

    move-result v1

    const/4 v2, 0x0

    invoke-static {v1, v2}, Lnet/duceng/xsynth/XSynth;->midiPlayerSFUnload(II)V

    .line 258
    iget-object v1, p0, Lnet/duceng/xsynth/Synth;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v1, v0}, Lnet/duceng/xmidi/util/MyArray;->removeAt(I)V

    .line 259
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Unload SoundFont "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " Total: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-static {}, Lnet/duceng/xsynth/XSynth;->midiPlayerSFCount()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Synth"

    invoke-static {v2, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 261
    :cond_0
    return-void
.end method

.method public setFallbackByName(Ljava/lang/String;)V
    .locals 4
    .param p1, "name"    # Ljava/lang/String;

    if-eqz p1, :xm_clear

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-eqz v0, :xm_clear

    new-instance v1, Ljava/io/File;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Lnet/duceng/xsynth/Synth;->PATH_FONT:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lnet/duceng/xsynth/Synth;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v2, v1}, Lnet/duceng/xmidi/util/MyArray;->indexOfValue(Ljava/lang/Object;)I

    move-result v2

    if-gez v2, :xm_loaded

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :xm_clear

    invoke-virtual {p0, v1}, Lnet/duceng/xsynth/Synth;->loadSFont(Ljava/io/File;)I

    :xm_loaded
    invoke-static {p1}, Lnet/duceng/xsynth/XSynth;->midiPlayerSetFallback(Ljava/lang/String;)V

    return-void

    :xm_clear
    const-string v0, ""

    invoke-static {v0}, Lnet/duceng/xsynth/XSynth;->midiPlayerSetFallback(Ljava/lang/String;)V

    return-void
.end method
