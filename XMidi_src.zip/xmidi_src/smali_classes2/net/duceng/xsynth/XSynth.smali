.class public Lnet/duceng/xsynth/XSynth;
.super Ljava/lang/Object;
.source "XSynth.java"


# static fields
.field public static ALL_CTRL_OFF:B

.field public static ALL_NOTES_OFF:B

.field public static ALL_SOUND_OFF:B

.field public static BALANCE_LSB:B

.field public static BALANCE_MSB:B

.field public static BANK_SELECT_LSB:B

.field public static BANK_SELECT_MSB:B

.field public static BREATH_LSB:B

.field public static BREATH_MSB:B

.field public static DATA_ENTRY_DECR:B

.field public static DATA_ENTRY_INCR:B

.field public static DATA_ENTRY_LSB:B

.field public static DATA_ENTRY_MSB:B

.field public static EFFECTS1_LSB:B

.field public static EFFECTS1_MSB:B

.field public static EFFECTS2_LSB:B

.field public static EFFECTS2_MSB:B

.field public static EFFECTS_DEPTH1:B

.field public static EFFECTS_DEPTH2:B

.field public static EFFECTS_DEPTH3:B

.field public static EFFECTS_DEPTH4:B

.field public static EFFECTS_DEPTH5:B

.field public static EXPRESSION_LSB:B

.field public static EXPRESSION_MSB:B

.field public static FOOT_LSB:B

.field public static FOOT_MSB:B

.field public static GPC1_LSB:B

.field public static GPC1_MSB:B

.field public static GPC2_LSB:B

.field public static GPC2_MSB:B

.field public static GPC3_LSB:B

.field public static GPC3_MSB:B

.field public static GPC4_LSB:B

.field public static GPC4_MSB:B

.field public static GPC5:B

.field public static GPC6:B

.field public static GPC7:B

.field public static GPC8:B

.field public static HOLD2_SWITCH:B

.field public static LEGATO_SWITCH:B

.field public static LOCAL_CONTROL:B

.field public static MODULATION_MSB:B

.field public static MODULATION_WHEEL_LSB:B

.field public static NRPN_LSB:B

.field public static NRPN_MSB:B

.field public static OMNI_OFF:B

.field public static OMNI_ON:B

.field public static PAN_LSB:B

.field public static PAN_MSB:B

.field public static POLY_OFF:B

.field public static POLY_ON:B

.field public static PORTAMENTO_CTRL:B

.field public static PORTAMENTO_SWITCH:B

.field public static PORTAMENTO_TIME_LSB:B

.field public static PORTAMENTO_TIME_MSB:B

.field public static RPN_LSB:B

.field public static RPN_MSB:B

.field public static SOFT_PEDAL_SWITCH:B

.field public static SOSTENUTO_SWITCH:B

.field public static SOUND_CTRL1:B

.field public static SOUND_CTRL10:B

.field public static SOUND_CTRL2:B

.field public static SOUND_CTRL3:B

.field public static SOUND_CTRL4:B

.field public static SOUND_CTRL5:B

.field public static SOUND_CTRL6:B

.field public static SOUND_CTRL7:B

.field public static SOUND_CTRL8:B

.field public static SOUND_CTRL9:B

.field public static SUSTAIN_SWITCH:B

.field public static VOLUME_LSB:B

.field public static VOLUME_MSB:B


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 153
    const-string v0, "fluidsynth"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 154
    const-string v0, "xsynth"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 155
    const/4 v0, 0x0

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->BANK_SELECT_MSB:B

    .line 156
    const/4 v0, 0x1

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->MODULATION_MSB:B

    .line 157
    const/4 v0, 0x2

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->BREATH_MSB:B

    .line 158
    const/4 v0, 0x4

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->FOOT_MSB:B

    .line 159
    const/4 v0, 0x5

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->PORTAMENTO_TIME_MSB:B

    .line 160
    const/4 v0, 0x6

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->DATA_ENTRY_MSB:B

    .line 161
    const/4 v0, 0x7

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->VOLUME_MSB:B

    .line 162
    const/16 v0, 0x8

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->BALANCE_MSB:B

    .line 163
    const/16 v0, 0xa

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->PAN_MSB:B

    .line 164
    const/16 v0, 0xb

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->EXPRESSION_MSB:B

    .line 165
    const/16 v0, 0xc

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS1_MSB:B

    .line 166
    const/16 v0, 0xd

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS2_MSB:B

    .line 167
    const/16 v0, 0x10

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC1_MSB:B

    .line 168
    const/16 v0, 0x11

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC2_MSB:B

    .line 169
    const/16 v0, 0x12

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC3_MSB:B

    .line 170
    const/16 v0, 0x13

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC4_MSB:B

    .line 171
    const/16 v0, 0x20

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->BANK_SELECT_LSB:B

    .line 172
    const/16 v0, 0x21

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->MODULATION_WHEEL_LSB:B

    .line 173
    const/16 v0, 0x22

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->BREATH_LSB:B

    .line 174
    const/16 v0, 0x24

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->FOOT_LSB:B

    .line 175
    const/16 v0, 0x25

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->PORTAMENTO_TIME_LSB:B

    .line 176
    const/16 v0, 0x26

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->DATA_ENTRY_LSB:B

    .line 177
    const/16 v0, 0x27

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->VOLUME_LSB:B

    .line 178
    const/16 v0, 0x28

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->BALANCE_LSB:B

    .line 179
    const/16 v0, 0x2a

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->PAN_LSB:B

    .line 180
    const/16 v0, 0x2b

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->EXPRESSION_LSB:B

    .line 181
    const/16 v0, 0x2c

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS1_LSB:B

    .line 182
    const/16 v0, 0x2d

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS2_LSB:B

    .line 183
    const/16 v0, 0x30

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC1_LSB:B

    .line 184
    const/16 v0, 0x31

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC2_LSB:B

    .line 185
    const/16 v0, 0x32

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC3_LSB:B

    .line 186
    const/16 v0, 0x33

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC4_LSB:B

    .line 187
    const/16 v0, 0x40

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SUSTAIN_SWITCH:B

    .line 188
    const/16 v0, 0x41

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->PORTAMENTO_SWITCH:B

    .line 189
    const/16 v0, 0x42

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOSTENUTO_SWITCH:B

    .line 190
    const/16 v0, 0x43

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOFT_PEDAL_SWITCH:B

    .line 191
    const/16 v0, 0x45

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->LEGATO_SWITCH:B

    .line 192
    sput-byte v0, Lnet/duceng/xsynth/XSynth;->HOLD2_SWITCH:B

    .line 193
    const/16 v0, 0x46

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL1:B

    .line 194
    const/16 v0, 0x47

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL2:B

    .line 195
    const/16 v0, 0x48

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL3:B

    .line 196
    const/16 v0, 0x49

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL4:B

    .line 197
    const/16 v0, 0x4a

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL5:B

    .line 198
    const/16 v0, 0x4b

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL6:B

    .line 199
    const/16 v0, 0x4c

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL7:B

    .line 200
    const/16 v0, 0x4d

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL8:B

    .line 201
    const/16 v0, 0x4e

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL9:B

    .line 202
    const/16 v0, 0x4f

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->SOUND_CTRL10:B

    .line 203
    const/16 v0, 0x50

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC5:B

    .line 204
    const/16 v0, 0x51

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC6:B

    .line 205
    const/16 v0, 0x52

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC7:B

    .line 206
    const/16 v0, 0x53

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->GPC8:B

    .line 207
    const/16 v0, 0x54

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->PORTAMENTO_CTRL:B

    .line 208
    const/16 v0, 0x5b

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH1:B

    .line 209
    const/16 v0, 0x5c

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH2:B

    .line 210
    const/16 v0, 0x5d

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH3:B

    .line 211
    const/16 v0, 0x5e

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH4:B

    .line 212
    const/16 v0, 0x5f

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH5:B

    .line 213
    const/16 v0, 0x60

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->DATA_ENTRY_INCR:B

    .line 214
    const/16 v0, 0x61

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->DATA_ENTRY_DECR:B

    .line 215
    const/16 v0, 0x62

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->NRPN_LSB:B

    .line 216
    const/16 v0, 0x63

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->NRPN_MSB:B

    .line 217
    const/16 v0, 0x64

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->RPN_LSB:B

    .line 218
    const/16 v0, 0x65

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->RPN_MSB:B

    .line 219
    const/16 v0, 0x78

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->ALL_SOUND_OFF:B

    .line 220
    const/16 v0, 0x79

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->ALL_CTRL_OFF:B

    .line 221
    const/16 v0, 0x7a

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->LOCAL_CONTROL:B

    .line 222
    const/16 v0, 0x7b

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->ALL_NOTES_OFF:B

    .line 223
    const/16 v0, 0x7c

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->OMNI_OFF:B

    .line 224
    const/16 v0, 0x7d

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->OMNI_ON:B

    .line 225
    const/16 v0, 0x7e

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->POLY_OFF:B

    .line 226
    const/16 v0, 0x7f

    sput-byte v0, Lnet/duceng/xsynth/XSynth;->POLY_ON:B

    .line 227
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static native createEngine()V
.end method

.method public static native createMidiPlayer()V
.end method

.method public static native midiPlayerBankSelect(II)V
.end method

.method public static native midiPlayerCC(III)V
.end method

.method public static native midiPlayerChorus(IDDDI)V
.end method

.method public static native midiPlayerChorusOn(I)V
.end method

.method public static native midiPlayerGetBank(I)I
.end method

.method public static native midiPlayerGetCC(II)I
.end method

.method public static native midiPlayerGetGain()F
.end method

.method public static native midiPlayerGetGen(II)F
.end method

.method public static native midiPlayerGetPitchBend(I)I
.end method

.method public static native midiPlayerGetPitchWhellSens(I)I
.end method

.method public static native midiPlayerGetPolyphony()I
.end method

.method public static native midiPlayerGetPreset(I)I
.end method

.method public static native midiPlayerGetSFont(I)I
.end method

.method public static native midiPlayerMidiChannels()I
.end method

.method public static native midiPlayerNoteoff(II)V
.end method

.method public static native midiPlayerNoteon(III)V
.end method

.method public static native midiPlayerPitchBend(II)V
.end method

.method public static native midiPlayerPitchWhellSens(II)V
.end method

.method public static native midiPlayerProgramChange(II)V
.end method

.method public static native midiPlayerProgramReset()V
.end method

.method public static native midiPlayerProgramSelect(IIII)V
.end method

.method public static native midiPlayerReverb(DDDD)V
.end method

.method public static native midiPlayerReverbOn(I)V
.end method

.method public static native midiPlayerSFCount()I
.end method

.method public static native midiPlayerSFLoad(Ljava/lang/String;I)I
.end method

.method public static native midiPlayerSFReload(I)I
.end method

.method public static native midiPlayerSFUnload(II)V
.end method

.method public static native midiPlayerSFontSelect(II)V
.end method

.method public static native midiPlayerSetGain(F)V
.end method

.method public static native midiPlayerSetFallback(Ljava/lang/String;)V
.end method

.method public static native midiPlayerSetGen(IIF)V
.end method

.method public static native midiPlayerSetPolyphony(I)V
.end method

.method public static native midiPlayerSystemReset()V
.end method

.method public static native releaseEngine()V
.end method

.method public static native releaseMidiPlayer()V
.end method

.method public static native setPlayingMidiPlayer(Z)V
.end method
