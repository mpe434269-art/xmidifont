.class public Lnet/duceng/xmidi/About;
.super Lnet/duceng/xmidi/Base;
.source "About.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Lnet/duceng/xmidi/Base;-><init>()V

    return-void
.end method


# virtual methods
.method protected onActionClick(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 33
    invoke-super {p0, p1}, Lnet/duceng/xmidi/Base;->onActionClick(Landroid/view/View;)V

    .line 34
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 16
    invoke-super {p0, p1}, Lnet/duceng/xmidi/Base;->onCreate(Landroid/os/Bundle;)V

    .line 17
    const/high16 v0, 0x7f050000

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/About;->setContentView(I)V

    .line 18
    iget-object v0, p0, Lnet/duceng/xmidi/About;->title:Landroid/widget/Button;

    const/high16 v1, 0x7f060000

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(I)V

    .line 19
    const/high16 v0, 0x7f040000

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/About;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    .line 20
    .local v0, "list":Landroid/widget/ListView;
    new-instance v1, Lnet/duceng/xmidi/util/AdapterAbout;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/util/AdapterAbout;-><init>(Landroid/content/Context;)V

    .line 21
    .local v1, "adapter":Lnet/duceng/xmidi/util/AdapterAbout;
    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 22
    invoke-virtual {p0}, Lnet/duceng/xmidi/About;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v2

    const/4 v3, 0x0

    move-object v4, v3

    check-cast v4, Landroid/view/ViewGroup;

    const v4, 0x7f050001

    invoke-virtual {v2, v4, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    .line 23
    .local v2, "layout":Landroid/widget/LinearLayout;
    :goto_0
    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v3

    if-lez v3, :cond_0

    .line 24
    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    .line 25
    .local v3, "child":Landroid/view/View;
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->removeView(Landroid/view/View;)V

    .line 26
    iget-object v4, p0, Lnet/duceng/xmidi/About;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 27
    iget-object v4, p0, Lnet/duceng/xmidi/About;->actionClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v3, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 28
    .end local v3    # "child":Landroid/view/View;
    goto :goto_0

    .line 29
    :cond_0
    return-void
.end method
