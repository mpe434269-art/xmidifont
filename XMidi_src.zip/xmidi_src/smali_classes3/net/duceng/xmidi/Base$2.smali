.class Lnet/duceng/xmidi/Base$2;
.super Ljava/lang/Object;
.source "Base.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Base;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Base;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Base;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Base;

    .line 46
    iput-object p1, p0, Lnet/duceng/xmidi/Base$2;->this$0:Lnet/duceng/xmidi/Base;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 49
    iget-object v0, p0, Lnet/duceng/xmidi/Base$2;->this$0:Lnet/duceng/xmidi/Base;

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/Base;->onActionClick(Landroid/view/View;)V

    .line 50
    iget-object v0, p0, Lnet/duceng/xmidi/Base$2;->this$0:Lnet/duceng/xmidi/Base;

    invoke-static {v0}, Lnet/duceng/xmidi/Base;->access$000(Lnet/duceng/xmidi/Base;)Landroid/widget/PopupWindow;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->dismiss()V

    .line 51
    return-void
.end method
