.class Lnet/duceng/xmidi/Base$3;
.super Ljava/lang/Object;
.source "Base.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Base;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Base;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Base;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Base;

    .line 73
    iput-object p1, p0, Lnet/duceng/xmidi/Base$3;->this$0:Lnet/duceng/xmidi/Base;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 76
    iget-object v0, p0, Lnet/duceng/xmidi/Base$3;->this$0:Lnet/duceng/xmidi/Base;

    invoke-virtual {v0}, Lnet/duceng/xmidi/Base;->showMenu()V

    .line 77
    return-void
.end method
