.class public abstract Lnet/duceng/xmidi/Base;
.super Landroid/app/Activity;
.source "Base.java"


# static fields
.field protected static isExit:Z


# instance fields
.field protected actionClickListener:Landroid/view/View$OnClickListener;

.field private back:Landroid/widget/ImageButton;

.field private bottom:Landroid/widget/LinearLayout;

.field protected isPortRait:Z

.field private launcher:Landroid/widget/ImageButton;

.field protected listBottom:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field protected listMore:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field protected listTop:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field protected menuClickListener:Landroid/view/View$OnClickListener;

.field private more:Landroid/widget/ImageButton;

.field private moreLayout:Landroid/widget/LinearLayout;

.field private moreWindow:Landroid/widget/PopupWindow;

.field protected title:Landroid/widget/Button;

.field private tools:Landroid/widget/LinearLayout;

.field private wapper:Landroid/widget/FrameLayout;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 26
    const/4 v0, 0x0

    sput-boolean v0, Lnet/duceng/xmidi/Base;->isExit:Z

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 25
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 37
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->listTop:Ljava/util/ArrayList;

    .line 38
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->listBottom:Ljava/util/ArrayList;

    .line 39
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->listMore:Ljava/util/ArrayList;

    .line 40
    new-instance v0, Lnet/duceng/xmidi/Base$1;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Base$1;-><init>(Lnet/duceng/xmidi/Base;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->actionClickListener:Landroid/view/View$OnClickListener;

    .line 46
    new-instance v0, Lnet/duceng/xmidi/Base$2;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Base$2;-><init>(Lnet/duceng/xmidi/Base;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->menuClickListener:Landroid/view/View$OnClickListener;

    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/Base;)Landroid/widget/PopupWindow;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Base;

    .line 25
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->moreWindow:Landroid/widget/PopupWindow;

    return-object v0
.end method

.method private static calculateInSampleSize(Landroid/graphics/BitmapFactory$Options;II)I
    .locals 6
    .param p0, "options"    # Landroid/graphics/BitmapFactory$Options;
    .param p1, "reqWidth"    # I
    .param p2, "reqHeight"    # I

    .line 199
    iget v0, p0, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    .line 200
    .local v0, "height":I
    iget v1, p0, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    .line 201
    .local v1, "width":I
    const/4 v2, 0x1

    .line 202
    .local v2, "inSampleSize":I
    if-gt v0, p2, :cond_0

    if-le v1, p1, :cond_1

    .line 203
    :cond_0
    div-int/lit8 v3, v0, 0x2

    .line 204
    .local v3, "halfHeight":I
    div-int/lit8 v4, v1, 0x2

    .line 205
    .local v4, "halfWidth":I
    :goto_0
    div-int v5, v3, v2

    if-le v5, p2, :cond_1

    div-int v5, v4, v2

    if-le v5, p1, :cond_1

    .line 206
    mul-int/lit8 v2, v2, 0x2

    goto :goto_0

    .line 209
    .end local v3    # "halfHeight":I
    .end local v4    # "halfWidth":I
    :cond_1
    return v2
.end method

.method public static decodeResource(Landroid/content/res/Resources;III)Landroid/graphics/Bitmap;
    .locals 2
    .param p0, "res"    # Landroid/content/res/Resources;
    .param p1, "resId"    # I
    .param p2, "reqWidth"    # I
    .param p3, "reqHeight"    # I

    .line 213
    new-instance v0, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v0}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    .line 214
    .local v0, "options":Landroid/graphics/BitmapFactory$Options;
    const/4 v1, 0x1

    iput-boolean v1, v0, Landroid/graphics/BitmapFactory$Options;->inPurgeable:Z

    .line 215
    iput-boolean v1, v0, Landroid/graphics/BitmapFactory$Options;->inInputShareable:Z

    .line 216
    iput-boolean v1, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 217
    invoke-static {p0, p1, v0}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;ILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    .line 218
    invoke-static {v0, p2, p3}, Lnet/duceng/xmidi/Base;->calculateInSampleSize(Landroid/graphics/BitmapFactory$Options;II)I

    move-result v1

    iput v1, v0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 219
    const/4 v1, 0x0

    iput-boolean v1, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 220
    invoke-static {p0, p1, v0}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;ILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object v1

    return-object v1
.end method


# virtual methods
.method public dpTopx(I)I
    .locals 5
    .param p1, "dp"    # I

    .line 194
    invoke-virtual {p0}, Lnet/duceng/xmidi/Base;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    .line 195
    .local v0, "displayMetrics":Landroid/util/DisplayMetrics;
    int-to-float v1, p1

    iget v2, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float v1, v1, v2

    float-to-double v1, v1

    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    add-double/2addr v1, v3

    double-to-int v1, v1

    return v1
.end method

.method protected onActionClick(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 172
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    sparse-switch v0, :sswitch_data_0

    goto :goto_0

    .line 174
    :sswitch_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lnet/duceng/xmidi/Settings;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 175
    .local v0, "intent":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Base;->startActivity(Landroid/content/Intent;)V

    .line 176
    goto :goto_0

    .line 182
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_1
    const/4 v0, 0x1

    sput-boolean v0, Lnet/duceng/xmidi/Base;->isExit:Z

    .line 183
    invoke-virtual {p0}, Lnet/duceng/xmidi/Base;->finish()V

    goto :goto_0

    .line 178
    :sswitch_2
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lnet/duceng/xmidi/About;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 179
    .local v0, "intent2":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Base;->startActivity(Landroid/content/Intent;)V

    .line 180
    nop

    .line 186
    .end local v0    # "intent2":Landroid/content/Intent;
    :goto_0
    return-void

    :sswitch_data_0
    .sparse-switch
        0x7f040001 -> :sswitch_2
        0x7f040004 -> :sswitch_1
        0x7f04000a -> :sswitch_0
    .end sparse-switch
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 6
    .param p1, "newConfig"    # Landroid/content/res/Configuration;

    .line 112
    invoke-super {p0, p1}, Landroid/app/Activity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 113
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->tools:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 114
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->bottom:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 115
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->listTop:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    .line 116
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->listTop:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    .line 117
    .local v1, "child":Landroid/view/View;
    iget-object v2, p0, Lnet/duceng/xmidi/Base;->tools:Landroid/widget/LinearLayout;

    iget-object v3, p0, Lnet/duceng/xmidi/Base;->tools:Landroid/widget/LinearLayout;

    invoke-virtual {v3}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v3

    invoke-virtual {v2, v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;I)V

    .line 115
    .end local v1    # "child":Landroid/view/View;
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 119
    .end local v0    # "i":I
    :cond_0
    iget v0, p1, Landroid/content/res/Configuration;->orientation:I

    const/4 v1, 0x0

    const/16 v2, 0x8

    const/4 v3, 0x1

    if-ne v0, v3, :cond_3

    .line 120
    const/4 v0, 0x0

    .local v0, "i2":I
    :goto_1
    iget-object v4, p0, Lnet/duceng/xmidi/Base;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v0, v4, :cond_1

    .line 121
    iget-object v4, p0, Lnet/duceng/xmidi/Base;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/view/View;

    .line 122
    .local v4, "child2":Landroid/view/View;
    iget-object v5, p0, Lnet/duceng/xmidi/Base;->bottom:Landroid/widget/LinearLayout;

    invoke-virtual {v5, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 120
    .end local v4    # "child2":Landroid/view/View;
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 124
    .end local v0    # "i2":I
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_2

    .line 125
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->bottom:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    goto :goto_2

    .line 127
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->bottom:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 129
    :goto_2
    iput-boolean v3, p0, Lnet/duceng/xmidi/Base;->isPortRait:Z

    goto :goto_4

    .line 131
    :cond_3
    const/4 v0, 0x0

    .local v0, "i3":I
    :goto_3
    iget-object v3, p0, Lnet/duceng/xmidi/Base;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_4

    .line 132
    iget-object v3, p0, Lnet/duceng/xmidi/Base;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/view/View;

    .line 133
    .local v3, "child3":Landroid/view/View;
    iget-object v4, p0, Lnet/duceng/xmidi/Base;->tools:Landroid/widget/LinearLayout;

    iget-object v5, p0, Lnet/duceng/xmidi/Base;->tools:Landroid/widget/LinearLayout;

    invoke-virtual {v5}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v5

    invoke-virtual {v4, v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;I)V

    .line 131
    .end local v3    # "child3":Landroid/view/View;
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    .line 135
    .end local v0    # "i3":I
    :cond_4
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->bottom:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 136
    iput-boolean v1, p0, Lnet/duceng/xmidi/Base;->isPortRait:Z

    .line 138
    :goto_4
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->moreLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 139
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_6

    .line 140
    const/4 v0, 0x0

    .local v0, "i4":I
    :goto_5
    iget-object v2, p0, Lnet/duceng/xmidi/Base;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_5

    .line 141
    iget-object v2, p0, Lnet/duceng/xmidi/Base;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    .line 142
    .local v2, "child4":Landroid/view/View;
    iget-object v3, p0, Lnet/duceng/xmidi/Base;->moreLayout:Landroid/widget/LinearLayout;

    iget-object v4, p0, Lnet/duceng/xmidi/Base;->moreLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v4}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v4

    invoke-virtual {v3, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;I)V

    .line 140
    .end local v2    # "child4":Landroid/view/View;
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    .line 144
    .end local v0    # "i4":I
    :cond_5
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->more:Landroid/widget/ImageButton;

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 145
    return-void

    .line 147
    :cond_6
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->more:Landroid/widget/ImageButton;

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 148
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 56
    const/4 v0, 0x0

    sput-boolean v0, Lnet/duceng/xmidi/Base;->isExit:Z

    .line 57
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 58
    const v0, 0x7f05000a

    invoke-super {p0, v0}, Landroid/app/Activity;->setContentView(I)V

    .line 59
    const v0, 0x7f04000f

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Base;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->back:Landroid/widget/ImageButton;

    .line 60
    const v0, 0x7f040091

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Base;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->launcher:Landroid/widget/ImageButton;

    .line 61
    const v0, 0x7f0400c1

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Base;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->title:Landroid/widget/Button;

    .line 62
    const v0, 0x7f04009c

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Base;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->more:Landroid/widget/ImageButton;

    .line 63
    const v0, 0x7f0400c2

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Base;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->tools:Landroid/widget/LinearLayout;

    .line 64
    const v0, 0x7f040010

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Base;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->bottom:Landroid/widget/LinearLayout;

    .line 65
    const v0, 0x7f0400c7

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Base;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout;

    iput-object v0, p0, Lnet/duceng/xmidi/Base;->wapper:Landroid/widget/FrameLayout;

    .line 66
    new-instance v0, Landroid/widget/ScrollView;

    invoke-direct {v0, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 67
    .local v0, "scrollView":Landroid/widget/ScrollView;
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lnet/duceng/xmidi/Base;->moreLayout:Landroid/widget/LinearLayout;

    .line 68
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->moreLayout:Landroid/widget/LinearLayout;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 69
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->moreLayout:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 70
    new-instance v1, Landroid/widget/PopupWindow;

    const/4 v3, -0x2

    invoke-direct {v1, v0, v3, v3}, Landroid/widget/PopupWindow;-><init>(Landroid/view/View;II)V

    iput-object v1, p0, Lnet/duceng/xmidi/Base;->moreWindow:Landroid/widget/PopupWindow;

    .line 71
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->moreWindow:Landroid/widget/PopupWindow;

    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    const v4, 0x106000d

    invoke-direct {v3, v4}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v1, v3}, Landroid/widget/PopupWindow;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 72
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->moreWindow:Landroid/widget/PopupWindow;

    invoke-virtual {v1, v2}, Landroid/widget/PopupWindow;->setFocusable(Z)V

    .line 73
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->more:Landroid/widget/ImageButton;

    new-instance v2, Lnet/duceng/xmidi/Base$3;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/Base$3;-><init>(Lnet/duceng/xmidi/Base;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 79
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->launcher:Landroid/widget/ImageButton;

    new-instance v2, Lnet/duceng/xmidi/Base$4;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/Base$4;-><init>(Lnet/duceng/xmidi/Base;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 85
    return-void
.end method

.method protected onResume()V
    .locals 1

    .line 103
    invoke-virtual {p0}, Lnet/duceng/xmidi/Base;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-static {v0}, Lnet/duceng/xmidi/util/Immersive;->apply(Landroid/view/Window;)V

    .line 104
    sget-boolean v0, Lnet/duceng/xmidi/Base;->isExit:Z

    if-eqz v0, :cond_0

    .line 105
    invoke-virtual {p0}, Lnet/duceng/xmidi/Base;->finish()V

    .line 107
    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 108
    return-void
.end method

.method protected onStart()V
    .locals 1

    .line 97
    invoke-virtual {p0}, Lnet/duceng/xmidi/Base;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Base;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 98
    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    .line 99
    return-void
.end method

.method public onWindowFocusChanged(Z)V
    .locals 1
    .param p1, "hasFocus"    # Z

    .line 225
    invoke-super {p0, p1}, Landroid/app/Activity;->onWindowFocusChanged(Z)V

    .line 226
    if-eqz p1, :cond_0

    .line 227
    invoke-virtual {p0}, Lnet/duceng/xmidi/Base;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-static {v0}, Lnet/duceng/xmidi/util/Immersive;->apply(Landroid/view/Window;)V

    .line 229
    :cond_0
    return-void
.end method

.method public pxTodp(I)I
    .locals 5
    .param p1, "px"    # I

    .line 189
    invoke-virtual {p0}, Lnet/duceng/xmidi/Base;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    .line 190
    .local v0, "displayMetrics":Landroid/util/DisplayMetrics;
    int-to-float v1, p1

    iget v2, v0, Landroid/util/DisplayMetrics;->density:F

    div-float/2addr v1, v2

    float-to-double v1, v1

    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    add-double/2addr v1, v3

    double-to-int v1, v1

    return v1
.end method

.method public setContentView(I)V
    .locals 3
    .param p1, "layoutResID"    # I

    .line 152
    invoke-virtual {p0}, Lnet/duceng/xmidi/Base;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    invoke-virtual {v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    .line 153
    .local v0, "child":Landroid/view/View;
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->wapper:Landroid/widget/FrameLayout;

    invoke-virtual {v1, v0}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 154
    return-void
.end method

.method public setContentView(Landroid/view/View;)V
    .locals 1
    .param p1, "view"    # Landroid/view/View;

    .line 158
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->wapper:Landroid/widget/FrameLayout;

    invoke-virtual {v0, p1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 159
    return-void
.end method

.method protected setTop(Z)V
    .locals 3
    .param p1, "top"    # Z

    .line 162
    const/4 v0, 0x0

    if-eqz p1, :cond_0

    .line 163
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->back:Landroid/widget/ImageButton;

    const/4 v2, 0x4

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 164
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->launcher:Landroid/widget/ImageButton;

    invoke-virtual {v1, v0}, Landroid/widget/ImageButton;->setClickable(Z)V

    goto :goto_0

    .line 166
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/Base;->back:Landroid/widget/ImageButton;

    invoke-virtual {v1, v0}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 167
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->launcher:Landroid/widget/ImageButton;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setClickable(Z)V

    .line 169
    :goto_0
    return-void
.end method

.method protected showMenu()V
    .locals 4

    .line 88
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->moreWindow:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 89
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->moreWindow:Landroid/widget/PopupWindow;

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->dismiss()V

    goto :goto_0

    .line 91
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Base;->moreWindow:Landroid/widget/PopupWindow;

    iget-object v1, p0, Lnet/duceng/xmidi/Base;->more:Landroid/widget/ImageButton;

    const/4 v2, 0x2

    invoke-virtual {p0, v2}, Lnet/duceng/xmidi/Base;->dpTopx(I)I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v3, v2}, Landroid/widget/PopupWindow;->showAsDropDown(Landroid/view/View;II)V

    .line 93
    :goto_0
    return-void
.end method
