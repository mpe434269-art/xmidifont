.class Lnet/duceng/xmidi/BaseApp$1;
.super Ljava/lang/Object;
.source "BaseApp.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/BaseApp;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/BaseApp;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/BaseApp;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/BaseApp;

    .line 53
    iput-object p1, p0, Lnet/duceng/xmidi/BaseApp$1;->this$0:Lnet/duceng/xmidi/BaseApp;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 56
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$1;->this$0:Lnet/duceng/xmidi/BaseApp;

    iget-object v0, v0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->stop()V

    .line 57
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$1;->this$0:Lnet/duceng/xmidi/BaseApp;

    const v1, 0x7f040008

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/BaseApp;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    .line 58
    .local v0, "ibMidi":Landroid/widget/ImageButton;
    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 59
    const/4 v1, 0x1

    return v1
.end method
