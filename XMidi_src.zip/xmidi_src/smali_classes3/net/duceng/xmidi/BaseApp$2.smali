.class Lnet/duceng/xmidi/BaseApp$2;
.super Ljava/lang/Object;
.source "BaseApp.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/BaseApp;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private dialogSynth:Lnet/duceng/xmidi/ui/DialogMidi;

.field final synthetic this$0:Lnet/duceng/xmidi/BaseApp;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/BaseApp;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/BaseApp;

    .line 72
    iput-object p1, p0, Lnet/duceng/xmidi/BaseApp$2;->this$0:Lnet/duceng/xmidi/BaseApp;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 77
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$2;->dialogSynth:Lnet/duceng/xmidi/ui/DialogMidi;

    if-nez v0, :cond_0

    .line 78
    new-instance v0, Lnet/duceng/xmidi/ui/DialogMidi;

    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp$2;->this$0:Lnet/duceng/xmidi/BaseApp;

    iget-object v2, p0, Lnet/duceng/xmidi/BaseApp$2;->this$0:Lnet/duceng/xmidi/BaseApp;

    iget-object v2, v2, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/ui/DialogMidi;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/BaseApp$2;->dialogSynth:Lnet/duceng/xmidi/ui/DialogMidi;

    .line 80
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$2;->dialogSynth:Lnet/duceng/xmidi/ui/DialogMidi;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogMidi;->show()V

    .line 81
    const/4 v0, 0x1

    return v0
.end method
