.class Lnet/duceng/xmidi/BaseApp$3$1;
.super Ljava/lang/Object;
.source "BaseApp.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/BaseApp$3;->onLongClick(Landroid/view/View;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/BaseApp$3;

.field final synthetic val$etFinal:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/BaseApp$3;Landroid/widget/EditText;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/BaseApp$3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 98
    iput-object p1, p0, Lnet/duceng/xmidi/BaseApp$3$1;->this$1:Lnet/duceng/xmidi/BaseApp$3;

    iput-object p2, p0, Lnet/duceng/xmidi/BaseApp$3$1;->val$etFinal:Landroid/widget/EditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2
    .param p1, "v2"    # Landroid/view/View;

    .line 101
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$3$1;->this$1:Lnet/duceng/xmidi/BaseApp$3;

    iget-object v0, v0, Lnet/duceng/xmidi/BaseApp$3;->this$0:Lnet/duceng/xmidi/BaseApp;

    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp$3$1;->val$etFinal:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/BaseApp;->saveFile(Ljava/lang/String;)V

    .line 102
    return-void
.end method
