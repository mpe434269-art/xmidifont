.class Lnet/duceng/xmidi/BaseApp$3$2;
.super Ljava/lang/Object;
.source "BaseApp.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/BaseApp$3;->onLongClick(Landroid/view/View;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/BaseApp$3;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/BaseApp$3;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/BaseApp$3;

    .line 104
    iput-object p1, p0, Lnet/duceng/xmidi/BaseApp$3$2;->this$1:Lnet/duceng/xmidi/BaseApp$3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v2"    # Landroid/view/View;

    .line 107
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$3$2;->this$1:Lnet/duceng/xmidi/BaseApp$3;

    iget-object v0, v0, Lnet/duceng/xmidi/BaseApp$3;->this$0:Lnet/duceng/xmidi/BaseApp;

    iget-object v0, v0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getRecordTrack()Lnet/duceng/midi/MidiTrack;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MidiTrack;->getEvents()Ljava/util/TreeSet;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/TreeSet;->clear()V

    .line 108
    return-void
.end method
