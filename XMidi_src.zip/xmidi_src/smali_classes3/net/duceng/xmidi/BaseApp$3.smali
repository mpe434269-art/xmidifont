.class Lnet/duceng/xmidi/BaseApp$3;
.super Ljava/lang/Object;
.source "BaseApp.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/BaseApp;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private et:Landroid/widget/EditText;

.field private save:Lnet/duceng/xmidi/ui/XDialog;

.field final synthetic this$0:Lnet/duceng/xmidi/BaseApp;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/BaseApp;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/BaseApp;

    .line 85
    iput-object p1, p0, Lnet/duceng/xmidi/BaseApp$3;->this$0:Lnet/duceng/xmidi/BaseApp;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 5
    .param p1, "v"    # Landroid/view/View;

    .line 91
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$3;->save:Lnet/duceng/xmidi/ui/XDialog;

    if-nez v0, :cond_0

    .line 92
    new-instance v0, Lnet/duceng/xmidi/ui/XDialog;

    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp$3;->this$0:Lnet/duceng/xmidi/BaseApp;

    invoke-direct {v0, v1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lnet/duceng/xmidi/BaseApp$3;->save:Lnet/duceng/xmidi/ui/XDialog;

    .line 93
    new-instance v0, Landroid/widget/EditText;

    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp$3;->this$0:Lnet/duceng/xmidi/BaseApp;

    invoke-direct {v0, v1}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lnet/duceng/xmidi/BaseApp$3;->et:Landroid/widget/EditText;

    .line 94
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$3;->et:Landroid/widget/EditText;

    .line 95
    .local v0, "etFinal":Landroid/widget/EditText;
    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp$3;->save:Lnet/duceng/xmidi/ui/XDialog;

    const v2, 0x7f060022

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/ui/XDialog;->setTitle(I)V

    .line 96
    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp$3;->save:Lnet/duceng/xmidi/ui/XDialog;

    iget-object v3, p0, Lnet/duceng/xmidi/BaseApp$3;->et:Landroid/widget/EditText;

    invoke-virtual {v1, v3}, Lnet/duceng/xmidi/ui/XDialog;->setContentView(Landroid/view/View;)V

    .line 97
    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp$3;->save:Lnet/duceng/xmidi/ui/XDialog;

    invoke-virtual {v1}, Lnet/duceng/xmidi/ui/XDialog;->getWapper()Landroid/widget/FrameLayout;

    move-result-object v1

    const/16 v3, 0xc

    invoke-virtual {v1, v3, v3, v3, v3}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 98
    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp$3;->save:Lnet/duceng/xmidi/ui/XDialog;

    new-instance v3, Lnet/duceng/xmidi/BaseApp$3$1;

    invoke-direct {v3, p0, v0}, Lnet/duceng/xmidi/BaseApp$3$1;-><init>(Lnet/duceng/xmidi/BaseApp$3;Landroid/widget/EditText;)V

    invoke-virtual {v1, v2, v3}, Lnet/duceng/xmidi/ui/XDialog;->addButton(ILandroid/view/View$OnClickListener;)V

    .line 104
    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp$3;->save:Lnet/duceng/xmidi/ui/XDialog;

    new-instance v2, Lnet/duceng/xmidi/BaseApp$3$2;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/BaseApp$3$2;-><init>(Lnet/duceng/xmidi/BaseApp$3;)V

    const v3, 0x7f06000b

    invoke-virtual {v1, v3, v2}, Lnet/duceng/xmidi/ui/XDialog;->addButton(ILandroid/view/View$OnClickListener;)V

    .line 110
    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp$3;->save:Lnet/duceng/xmidi/ui/XDialog;

    const v2, 0x7f060003

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Lnet/duceng/xmidi/ui/XDialog;->addButton(ILandroid/view/View$OnClickListener;)V

    .line 112
    .end local v0    # "etFinal":Landroid/widget/EditText;
    :cond_0
    new-instance v0, Ljava/util/Date;

    invoke-direct {v0}, Ljava/util/Date;-><init>()V

    .line 113
    .local v0, "d":Ljava/util/Date;
    new-instance v1, Ljava/text/SimpleDateFormat;

    const-string v2, "yyMMddHHmmss"

    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v1, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 114
    .local v1, "sdf":Ljava/text/SimpleDateFormat;
    iget-object v2, p0, Lnet/duceng/xmidi/BaseApp$3;->et:Landroid/widget/EditText;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ".mid"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 115
    iget-object v2, p0, Lnet/duceng/xmidi/BaseApp$3;->save:Lnet/duceng/xmidi/ui/XDialog;

    invoke-virtual {v2}, Lnet/duceng/xmidi/ui/XDialog;->show()V

    .line 116
    const/4 v2, 0x1

    return v2
.end method
