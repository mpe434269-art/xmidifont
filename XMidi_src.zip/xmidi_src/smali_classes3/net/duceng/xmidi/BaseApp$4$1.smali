.class Lnet/duceng/xmidi/BaseApp$4$1;
.super Ljava/lang/Object;
.source "BaseApp.java"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/BaseApp$4;->onLongClick(Landroid/view/View;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/BaseApp$4;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/BaseApp$4;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/BaseApp$4;

    .line 135
    iput-object p1, p0, Lnet/duceng/xmidi/BaseApp$4$1;->this$1:Lnet/duceng/xmidi/BaseApp$4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDismiss(Landroid/content/DialogInterface;)V
    .locals 1
    .param p1, "dialog"    # Landroid/content/DialogInterface;

    .line 138
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$4$1;->this$1:Lnet/duceng/xmidi/BaseApp$4;

    iget-object v0, v0, Lnet/duceng/xmidi/BaseApp$4;->this$0:Lnet/duceng/xmidi/BaseApp;

    invoke-virtual {v0}, Lnet/duceng/xmidi/BaseApp;->onTrackChanged()V

    .line 139
    return-void
.end method
