.class Lnet/duceng/xmidi/BaseApp$4;
.super Ljava/lang/Object;
.source "BaseApp.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/BaseApp;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private dialogTrack:Lnet/duceng/xmidi/ui/DialogTrack;

.field final synthetic this$0:Lnet/duceng/xmidi/BaseApp;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/BaseApp;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/BaseApp;

    .line 127
    iput-object p1, p0, Lnet/duceng/xmidi/BaseApp$4;->this$0:Lnet/duceng/xmidi/BaseApp;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 132
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$4;->this$0:Lnet/duceng/xmidi/BaseApp;

    iget-object v0, v0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getFile()Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 133
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$4;->dialogTrack:Lnet/duceng/xmidi/ui/DialogTrack;

    if-nez v0, :cond_0

    .line 134
    new-instance v0, Lnet/duceng/xmidi/ui/DialogTrack;

    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp$4;->this$0:Lnet/duceng/xmidi/BaseApp;

    iget-object v2, p0, Lnet/duceng/xmidi/BaseApp$4;->this$0:Lnet/duceng/xmidi/BaseApp;

    iget-object v2, v2, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/ui/DialogTrack;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/BaseApp$4;->dialogTrack:Lnet/duceng/xmidi/ui/DialogTrack;

    .line 135
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$4;->dialogTrack:Lnet/duceng/xmidi/ui/DialogTrack;

    new-instance v1, Lnet/duceng/xmidi/BaseApp$4$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/BaseApp$4$1;-><init>(Lnet/duceng/xmidi/BaseApp$4;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogTrack;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 142
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$4;->dialogTrack:Lnet/duceng/xmidi/ui/DialogTrack;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogTrack;->show()V

    .line 144
    :cond_1
    const/4 v0, 0x1

    return v0
.end method
