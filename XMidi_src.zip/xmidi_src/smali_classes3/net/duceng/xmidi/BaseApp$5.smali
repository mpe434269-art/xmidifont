.class Lnet/duceng/xmidi/BaseApp$5;
.super Ljava/lang/Object;
.source "BaseApp.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/BaseApp;->showMidi()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/BaseApp;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/BaseApp;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/BaseApp;

    .line 261
    iput-object p1, p0, Lnet/duceng/xmidi/BaseApp$5;->this$0:Lnet/duceng/xmidi/BaseApp;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(Ljava/io/File;)V
    .locals 1
    .param p1, "f"    # Ljava/io/File;

    .line 264
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$5;->this$0:Lnet/duceng/xmidi/BaseApp;

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/BaseApp;->onMidiChanged(Ljava/io/File;)V

    .line 265
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp$5;->this$0:Lnet/duceng/xmidi/BaseApp;

    invoke-static {v0}, Lnet/duceng/xmidi/BaseApp;->access$000(Lnet/duceng/xmidi/BaseApp;)Lnet/duceng/xmidi/ui/DialogExplorer;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogExplorer;->dismiss()V

    .line 266
    return-void
.end method
