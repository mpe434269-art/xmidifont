.class public abstract Lnet/duceng/xmidi/BaseApp;
.super Lnet/duceng/xmidi/Base;
.source "BaseApp.java"


# instance fields
.field private dialogFile:Lnet/duceng/xmidi/ui/DialogExplorer;

.field protected drums:[Ljava/lang/String;

.field protected instruments:[Ljava/lang/String;

.field protected synth:Lnet/duceng/xsynth/Synth;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 27
    invoke-direct {p0}, Lnet/duceng/xmidi/Base;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/BaseApp;)Lnet/duceng/xmidi/ui/DialogExplorer;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/BaseApp;

    .line 27
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->dialogFile:Lnet/duceng/xmidi/ui/DialogExplorer;

    return-object v0
.end method

.method private showMidi()V
    .locals 2

    .line 259
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->dialogFile:Lnet/duceng/xmidi/ui/DialogExplorer;

    if-nez v0, :cond_0

    .line 260
    new-instance v0, Lnet/duceng/xmidi/ui/DialogExplorer;

    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, p0, v1}, Lnet/duceng/xmidi/ui/DialogExplorer;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/BaseApp;->dialogFile:Lnet/duceng/xmidi/ui/DialogExplorer;

    .line 261
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->dialogFile:Lnet/duceng/xmidi/ui/DialogExplorer;

    new-instance v1, Lnet/duceng/xmidi/BaseApp$5;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/BaseApp$5;-><init>(Lnet/duceng/xmidi/BaseApp;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogExplorer;->setOnSelectListener(Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;)V

    .line 269
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->dialogFile:Lnet/duceng/xmidi/ui/DialogExplorer;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogExplorer;->show()V

    .line 270
    return-void
.end method


# virtual methods
.method protected getPresetName(I)Ljava/lang/String;
    .locals 5
    .param p1, "ch"    # I

    .line 250
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0, p1}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v0

    .line 251
    .local v0, "p":I
    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1, p1}, Lnet/duceng/xsynth/Synth;->getBank(I)I

    move-result v1

    sget v2, Lnet/duceng/xsynth/Synth;->DRUMS_BANK:I

    const/4 v3, 0x1

    if-ne v1, v2, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    .line 252
    .local v1, "isdrum":Z
    :goto_0
    invoke-virtual {p0}, Lnet/duceng/xmidi/BaseApp;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v2

    iget v2, v2, Landroid/content/res/Configuration;->orientation:I

    const-string v4, ":"

    if-ne v2, v3, :cond_2

    .line 253
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    if-eqz v1, :cond_1

    iget-object v3, p0, Lnet/duceng/xmidi/BaseApp;->drums:[Ljava/lang/String;

    div-int/lit8 v4, v0, 0x8

    aget-object v3, v3, v4

    goto :goto_1

    :cond_1
    iget-object v3, p0, Lnet/duceng/xmidi/BaseApp;->instruments:[Ljava/lang/String;

    aget-object v3, v3, v0

    :goto_1
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2

    .line 255
    :cond_2
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    if-eqz v1, :cond_3

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "X"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_2

    :cond_3
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    :goto_2
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method protected onActionClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 180
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const/4 v1, 0x1

    sparse-switch v0, :sswitch_data_0

    .line 228
    invoke-super {p0, p1}, Lnet/duceng/xmidi/Base;->onActionClick(Landroid/view/View;)V

    goto/16 :goto_2

    .line 205
    :sswitch_0
    invoke-direct {p0}, Lnet/duceng/xmidi/BaseApp;->showMidi()V

    .line 206
    goto/16 :goto_2

    .line 187
    :sswitch_1
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v2, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->isRecording()Z

    move-result v2

    xor-int/2addr v1, v2

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setRecording(Z)V

    .line 188
    const v0, 0x7f040009

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/BaseApp;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    .line 189
    .local v0, "ibRecord":Landroid/widget/ImageButton;
    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->isRecording()Z

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 190
    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->isRecording()Z

    move-result v1

    if-nez v1, :cond_2

    .line 191
    invoke-virtual {v0}, Landroid/widget/ImageButton;->getTag()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View$OnLongClickListener;

    .line 192
    .local v1, "lcl":Landroid/view/View$OnLongClickListener;
    invoke-interface {v1, v0}, Landroid/view/View$OnLongClickListener;->onLongClick(Landroid/view/View;)Z

    .line 193
    .end local v1    # "lcl":Landroid/view/View$OnLongClickListener;
    goto/16 :goto_2

    .line 196
    .end local v0    # "ibRecord":Landroid/widget/ImageButton;
    :sswitch_2
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 197
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->pause()V

    goto :goto_0

    .line 199
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->play()V

    .line 201
    :goto_0
    const v0, 0x7f040008

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/BaseApp;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    .line 202
    .local v0, "ibMidi":Landroid/widget/ImageButton;
    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v3}, Lnet/duceng/xsynth/Synth;->isPlaying()Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_1

    :cond_1
    const/4 v1, 0x2

    :goto_1
    invoke-virtual {v2, v1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 203
    goto :goto_2

    .line 223
    .end local v0    # "ibMidi":Landroid/widget/ImageButton;
    :sswitch_3
    invoke-virtual {p0}, Lnet/duceng/xmidi/BaseApp;->finish()V

    .line 224
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lnet/duceng/xmidi/Metronome;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 225
    .local v0, "intent4":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/BaseApp;->startActivity(Landroid/content/Intent;)V

    .line 226
    goto :goto_2

    .line 208
    .end local v0    # "intent4":Landroid/content/Intent;
    :sswitch_4
    invoke-virtual {p0}, Lnet/duceng/xmidi/BaseApp;->finish()V

    .line 209
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lnet/duceng/xmidi/Keyboard;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 210
    .local v0, "intent":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/BaseApp;->startActivity(Landroid/content/Intent;)V

    .line 211
    goto :goto_2

    .line 213
    .end local v0    # "intent":Landroid/content/Intent;
    :sswitch_5
    invoke-virtual {p0}, Lnet/duceng/xmidi/BaseApp;->finish()V

    .line 214
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lnet/duceng/xmidi/Guitar;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 215
    .local v0, "intent2":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/BaseApp;->startActivity(Landroid/content/Intent;)V

    .line 216
    goto :goto_2

    .line 218
    .end local v0    # "intent2":Landroid/content/Intent;
    :sswitch_6
    invoke-virtual {p0}, Lnet/duceng/xmidi/BaseApp;->finish()V

    .line 219
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lnet/duceng/xmidi/Drums;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 220
    .local v0, "intent3":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/BaseApp;->startActivity(Landroid/content/Intent;)V

    .line 221
    goto :goto_2

    .line 182
    .end local v0    # "intent3":Landroid/content/Intent;
    :sswitch_7
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v2, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->isBeating()Z

    move-result v2

    xor-int/2addr v1, v2

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setBeating(Z)V

    .line 183
    const v0, 0x7f040002

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/BaseApp;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    .line 184
    .local v0, "ibBeat":Landroid/widget/ImageButton;
    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->isBeating()Z

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 185
    nop

    .line 231
    .end local v0    # "ibBeat":Landroid/widget/ImageButton;
    :cond_2
    :goto_2
    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0x7f040002 -> :sswitch_7
        0x7f040003 -> :sswitch_6
        0x7f040005 -> :sswitch_5
        0x7f040006 -> :sswitch_4
        0x7f040007 -> :sswitch_3
        0x7f040008 -> :sswitch_2
        0x7f040009 -> :sswitch_1
        0x7f0400c1 -> :sswitch_0
    .end sparse-switch
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 7
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 35
    invoke-super {p0, p1}, Lnet/duceng/xmidi/Base;->onCreate(Landroid/os/Bundle;)V

    .line 36
    invoke-static {}, Lnet/duceng/xsynth/Synth;->getInstance()Lnet/duceng/xsynth/Synth;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    .line 37
    invoke-virtual {p0}, Lnet/duceng/xmidi/BaseApp;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010004

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/BaseApp;->instruments:[Ljava/lang/String;

    .line 38
    invoke-virtual {p0}, Lnet/duceng/xmidi/BaseApp;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010002

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/BaseApp;->drums:[Ljava/lang/String;

    .line 39
    invoke-virtual {p0}, Lnet/duceng/xmidi/BaseApp;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050020

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    .line 40
    .local v0, "layout":Landroid/widget/LinearLayout;
    :goto_0
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v2

    const/4 v3, 0x0

    if-lez v2, :cond_0

    .line 41
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    .line 42
    .local v2, "child":Landroid/view/View;
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->removeView(Landroid/view/View;)V

    .line 43
    iget-object v3, p0, Lnet/duceng/xmidi/BaseApp;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 44
    iget-object v3, p0, Lnet/duceng/xmidi/BaseApp;->menuClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 45
    .end local v2    # "child":Landroid/view/View;
    goto :goto_0

    .line 46
    :cond_0
    invoke-virtual {p0}, Lnet/duceng/xmidi/BaseApp;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v2

    const v4, 0x7f050009

    invoke-virtual {v2, v4, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    .line 47
    .local v2, "layout2":Landroid/widget/LinearLayout;
    :goto_1
    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v4

    if-lez v4, :cond_2

    .line 48
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    .line 49
    .local v4, "child2":Landroid/view/View;
    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->removeView(Landroid/view/View;)V

    .line 50
    iget-object v5, p0, Lnet/duceng/xmidi/BaseApp;->listTop:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 51
    iget-object v5, p0, Lnet/duceng/xmidi/BaseApp;->actionClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 52
    invoke-virtual {v4}, Landroid/view/View;->getId()I

    move-result v5

    const v6, 0x7f040008

    if-ne v5, v6, :cond_1

    .line 53
    new-instance v5, Lnet/duceng/xmidi/BaseApp$1;

    invoke-direct {v5, p0}, Lnet/duceng/xmidi/BaseApp$1;-><init>(Lnet/duceng/xmidi/BaseApp;)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 63
    .end local v4    # "child2":Landroid/view/View;
    :cond_1
    goto :goto_1

    .line 64
    :cond_2
    invoke-virtual {p0}, Lnet/duceng/xmidi/BaseApp;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v4

    const v5, 0x7f050002

    invoke-virtual {v4, v5, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    .line 65
    .local v1, "layout3":Landroid/widget/LinearLayout;
    :goto_2
    invoke-virtual {v1}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v4

    if-lez v4, :cond_5

    .line 66
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    .line 67
    .local v4, "child3":Landroid/view/View;
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->removeView(Landroid/view/View;)V

    .line 68
    iget-object v5, p0, Lnet/duceng/xmidi/BaseApp;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 69
    iget-object v5, p0, Lnet/duceng/xmidi/BaseApp;->actionClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 70
    invoke-virtual {v4}, Landroid/view/View;->getId()I

    move-result v5

    const v6, 0x7f040002

    if-ne v5, v6, :cond_3

    .line 71
    move-object v5, v4

    check-cast v5, Landroid/widget/ImageButton;

    invoke-virtual {v5}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v5

    iget-object v6, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v6}, Lnet/duceng/xsynth/Synth;->isBeating()Z

    move-result v6

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 72
    new-instance v5, Lnet/duceng/xmidi/BaseApp$2;

    invoke-direct {v5, p0}, Lnet/duceng/xmidi/BaseApp$2;-><init>(Lnet/duceng/xmidi/BaseApp;)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    goto :goto_3

    .line 84
    :cond_3
    invoke-virtual {v4}, Landroid/view/View;->getId()I

    move-result v5

    const v6, 0x7f040009

    if-ne v5, v6, :cond_4

    .line 85
    new-instance v5, Lnet/duceng/xmidi/BaseApp$3;

    invoke-direct {v5, p0}, Lnet/duceng/xmidi/BaseApp$3;-><init>(Lnet/duceng/xmidi/BaseApp;)V

    .line 119
    .local v5, "lcl":Landroid/view/View$OnLongClickListener;
    invoke-virtual {v4, v5}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 120
    invoke-virtual {v4, v5}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 122
    .end local v4    # "child3":Landroid/view/View;
    .end local v5    # "lcl":Landroid/view/View$OnLongClickListener;
    :cond_4
    :goto_3
    goto :goto_2

    .line 123
    :cond_5
    iget-object v4, p0, Lnet/duceng/xmidi/BaseApp;->title:Landroid/widget/Button;

    const v5, 0x7f03000b

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setBackgroundResource(I)V

    .line 124
    iget-object v4, p0, Lnet/duceng/xmidi/BaseApp;->title:Landroid/widget/Button;

    const/4 v5, 0x4

    const/16 v6, 0x8

    invoke-virtual {v4, v5, v3, v6, v3}, Landroid/widget/Button;->setPadding(IIII)V

    .line 125
    iget-object v3, p0, Lnet/duceng/xmidi/BaseApp;->title:Landroid/widget/Button;

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setClickable(Z)V

    .line 126
    iget-object v3, p0, Lnet/duceng/xmidi/BaseApp;->title:Landroid/widget/Button;

    iget-object v4, p0, Lnet/duceng/xmidi/BaseApp;->actionClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 127
    iget-object v3, p0, Lnet/duceng/xmidi/BaseApp;->title:Landroid/widget/Button;

    new-instance v4, Lnet/duceng/xmidi/BaseApp$4;

    invoke-direct {v4, p0}, Lnet/duceng/xmidi/BaseApp$4;-><init>(Lnet/duceng/xmidi/BaseApp;)V

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 147
    return-void
.end method

.method protected onDestroy()V
    .locals 2

    .line 165
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->stop()V

    .line 166
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setBeating(Z)V

    .line 167
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->freeInstance()V

    .line 168
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 169
    invoke-super {p0}, Lnet/duceng/xmidi/Base;->onDestroy()V

    .line 170
    return-void
.end method

.method protected onMidiChanged(Ljava/io/File;)V
    .locals 2
    .param p1, "f"    # Ljava/io/File;

    .line 273
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getFile()Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getFile()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/io/File;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 274
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0, p1}, Lnet/duceng/xsynth/Synth;->setFile(Ljava/io/File;)V

    .line 276
    :cond_1
    if-eqz p1, :cond_2

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 277
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->title:Landroid/widget/Button;

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 278
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->title:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_3

    .line 279
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->title:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp;->title:Landroid/widget/Button;

    invoke-virtual {v1}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 281
    :cond_3
    :goto_0
    return-void
.end method

.method public onPrepareOptionsMenu(Landroid/view/Menu;)Z
    .locals 1
    .param p1, "menu"    # Landroid/view/Menu;

    .line 174
    invoke-virtual {p0}, Lnet/duceng/xmidi/BaseApp;->showMenu()V

    .line 175
    const/4 v0, 0x0

    return v0
.end method

.method protected onStart()V
    .locals 2

    .line 151
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->title:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp;->title:Landroid/widget/Button;

    invoke-virtual {v1}, Landroid/widget/Button;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 152
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getFile()Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 153
    iget-object v0, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getFile()Ljava/io/File;

    move-result-object v0

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/BaseApp;->onMidiChanged(Ljava/io/File;)V

    .line 155
    :cond_0
    invoke-super {p0}, Lnet/duceng/xmidi/Base;->onStart()V

    .line 156
    return-void
.end method

.method protected onStop()V
    .locals 0

    .line 160
    invoke-super {p0}, Lnet/duceng/xmidi/Base;->onStop()V

    .line 161
    return-void
.end method

.method protected onTrackChanged()V
    .locals 0

    .line 284
    return-void
.end method

.method public saveFile(Ljava/lang/String;)V
    .locals 3
    .param p1, "fileName"    # Ljava/lang/String;

    .line 235
    new-instance v0, Ljava/io/File;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Lnet/duceng/xsynth/Synth;->PATH_RECORD:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 236
    .local v0, "f":Ljava/io/File;
    iget-object v1, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v1

    .line 237
    .local v1, "mf":Lnet/duceng/midi/MidiFile;
    iget-object v2, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->getRecordTrack()Lnet/duceng/midi/MidiTrack;

    move-result-object v2

    if-eqz v2, :cond_0

    .line 238
    iget-object v2, p0, Lnet/duceng/xmidi/BaseApp;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->getRecordTrack()Lnet/duceng/midi/MidiTrack;

    move-result-object v2

    invoke-virtual {v1, v2}, Lnet/duceng/midi/MidiFile;->addTrack(Lnet/duceng/midi/MidiTrack;)V

    .line 241
    :cond_0
    :try_start_0
    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 242
    .local v2, "fos":Ljava/io/FileOutputStream;
    invoke-virtual {v1, v2}, Lnet/duceng/midi/MidiFile;->write(Ljava/io/OutputStream;)V

    .line 243
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 246
    .end local v2    # "fos":Ljava/io/FileOutputStream;
    goto :goto_0

    .line 244
    :catch_0
    move-exception v2

    .line 245
    .local v2, "e":Ljava/io/IOException;
    invoke-virtual {v2}, Ljava/io/IOException;->printStackTrace()V

    .line 247
    .end local v2    # "e":Ljava/io/IOException;
    :goto_0
    return-void
.end method
