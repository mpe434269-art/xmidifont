.class Lnet/duceng/xmidi/Drums$1;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Drums;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 102
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$1;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKeysChanged(II)V
    .locals 2
    .param p1, "note"    # I
    .param p2, "val"    # I

    .line 105
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$1;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$000(Lnet/duceng/xmidi/Drums;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 106
    return-void

    .line 108
    :cond_0
    const/4 v0, 0x0

    if-lez p2, :cond_1

    .line 109
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$1;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1, v0, p1, p2}, Lnet/duceng/xsynth/Synth;->keyOn(III)V

    goto :goto_0

    .line 111
    :cond_1
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$1;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1, v0, p1}, Lnet/duceng/xsynth/Synth;->keyOff(II)V

    .line 113
    :goto_0
    return-void
.end method
