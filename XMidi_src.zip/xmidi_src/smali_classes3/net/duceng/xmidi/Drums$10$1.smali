.class Lnet/duceng/xmidi/Drums$10$1;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums$10;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/Drums$10;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums$10;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/Drums$10;

    .line 320
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(I)Z
    .locals 4
    .param p1, "id"    # I

    .line 323
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$300(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/Chords;

    move-result-object v0

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/util/Chords;->getGChords16(I)[Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v0

    .line 324
    .local v0, "chords":[Lnet/duceng/xmidi/util/Chords$Chord;
    const/4 v1, 0x0

    .local v1, "i2":I
    :goto_0
    array-length v2, v0

    if-ge v1, v2, :cond_0

    .line 325
    iget-object v2, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v2, v2, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v2}, Lnet/duceng/xmidi/Drums;->access$1600(Lnet/duceng/xmidi/Drums;)[Landroid/widget/Button;

    move-result-object v2

    aget-object v2, v2, v1

    aget-object v3, v0, v1

    iget-object v3, v3, Lnet/duceng/xmidi/util/Chords$Chord;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 326
    iget-object v2, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v2, v2, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v2}, Lnet/duceng/xmidi/Drums;->access$1600(Lnet/duceng/xmidi/Drums;)[Landroid/widget/Button;

    move-result-object v2

    aget-object v2, v2, v1

    aget-object v3, v0, v1

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 324
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 328
    .end local v1    # "i2":I
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$1900(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;

    move-result-object v1

    const/4 v2, 0x0

    aget-object v2, v0, v2

    iget-object v2, v2, Lnet/duceng/xmidi/util/Chords$Chord;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 329
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1, p1}, Lnet/duceng/xmidi/Drums;->access$2002(Lnet/duceng/xmidi/Drums;I)I

    .line 330
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$400(Lnet/duceng/xmidi/Drums;)V

    .line 331
    const/4 v1, 0x0

    .local v1, "i3":I
    :goto_1
    iget-object v2, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v2, v2, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v2}, Lnet/duceng/xmidi/Drums;->access$1600(Lnet/duceng/xmidi/Drums;)[Landroid/widget/Button;

    move-result-object v2

    array-length v2, v2

    if-ge v1, v2, :cond_2

    .line 332
    iget-object v2, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v2, v2, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v2}, Lnet/duceng/xmidi/Drums;->access$1600(Lnet/duceng/xmidi/Drums;)[Landroid/widget/Button;

    move-result-object v2

    aget-object v2, v2, v1

    invoke-virtual {v2}, Landroid/widget/Button;->isSelected()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 333
    iget-object v2, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v2, v2, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v3, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v3, v3, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v3}, Lnet/duceng/xmidi/Drums;->access$1600(Lnet/duceng/xmidi/Drums;)[Landroid/widget/Button;

    move-result-object v3

    aget-object v3, v3, v1

    invoke-virtual {v3}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-static {v2, v3}, Lnet/duceng/xmidi/Drums;->access$502(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/util/Chords$Chord;)Lnet/duceng/xmidi/util/Chords$Chord;

    .line 334
    iget-object v2, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v2, v2, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v2}, Lnet/duceng/xmidi/Drums;->access$600(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/StyleEngine;

    move-result-object v2

    if-eqz v2, :cond_1

    .line 335
    iget-object v2, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v2, v2, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v2}, Lnet/duceng/xmidi/Drums;->access$600(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/StyleEngine;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v3, v3, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v3}, Lnet/duceng/xmidi/Drums;->access$500(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v3

    invoke-virtual {v2, v3}, Lnet/duceng/xmidi/util/StyleEngine;->setChord(Lnet/duceng/xmidi/util/Chords$Chord;)V

    .line 331
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 339
    .end local v1    # "i3":I
    :cond_2
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$10$1;->this$1:Lnet/duceng/xmidi/Drums$10;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$1800(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogTonality;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/xmidi/ui/DialogTonality;->dismiss()V

    .line 340
    const/4 v1, 0x1

    return v1
.end method
