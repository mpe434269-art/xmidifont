.class Lnet/duceng/xmidi/Drums$10;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 315
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 318
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1800(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogTonality;

    move-result-object v0

    if-nez v0, :cond_0

    .line 319
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    new-instance v1, Lnet/duceng/xmidi/ui/DialogTonality;

    iget-object v2, p0, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v3, p0, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v3}, Lnet/duceng/xmidi/Drums;->access$300(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/Chords;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Lnet/duceng/xmidi/ui/DialogTonality;-><init>(Landroid/content/Context;Lnet/duceng/xmidi/util/Chords;)V

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Drums;->access$1802(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/ui/DialogTonality;)Lnet/duceng/xmidi/ui/DialogTonality;

    .line 320
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1800(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogTonality;

    move-result-object v0

    new-instance v1, Lnet/duceng/xmidi/Drums$10$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Drums$10$1;-><init>(Lnet/duceng/xmidi/Drums$10;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogTonality;->setOnSelectListener(Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;)V

    .line 344
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$10;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1800(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogTonality;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogTonality;->show()V

    .line 345
    return-void
.end method
