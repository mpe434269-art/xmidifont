.class Lnet/duceng/xmidi/Drums$11;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Lnet/duceng/xsynth/Synth$BeatListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 402
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$11;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onBeating(J)V
    .locals 3
    .param p1, "ticks"    # J

    .line 405
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$11;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$600(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/StyleEngine;

    move-result-object v0

    .line 406
    .local v0, "en":Lnet/duceng/xmidi/util/StyleEngine;
    if-eqz v0, :cond_3

    iget-object v1, p0, Lnet/duceng/xmidi/Drums$11;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$2100(Lnet/duceng/xmidi/Drums;)Z

    move-result v1

    if-eqz v1, :cond_3

    iget-object v1, p0, Lnet/duceng/xmidi/Drums$11;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$1500(Lnet/duceng/xmidi/Drums;)Lnet/duceng/midi/StySection;

    move-result-object v1

    if-nez v1, :cond_0

    goto :goto_1

    .line 409
    :cond_0
    invoke-virtual {v0}, Lnet/duceng/xmidi/util/StyleEngine;->isRunning()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 410
    invoke-virtual {v0}, Lnet/duceng/xmidi/util/StyleEngine;->sync()V

    goto :goto_0

    .line 411
    :cond_1
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$11;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->isPlaying()Z

    move-result v1

    if-eqz v1, :cond_2

    .line 412
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$11;->this$0:Lnet/duceng/xmidi/Drums;

    const/4 v2, 0x1

    invoke-static {v1, v2}, Lnet/duceng/xmidi/Drums;->access$2202(Lnet/duceng/xmidi/Drums;Z)Z

    .line 413
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$11;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$2300(Lnet/duceng/xmidi/Drums;)Landroid/os/Handler;

    move-result-object v1

    new-instance v2, Lnet/duceng/xmidi/Drums$11$1;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/Drums$11$1;-><init>(Lnet/duceng/xmidi/Drums$11;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 420
    :cond_2
    :goto_0
    return-void

    .line 407
    :cond_3
    :goto_1
    return-void
.end method
