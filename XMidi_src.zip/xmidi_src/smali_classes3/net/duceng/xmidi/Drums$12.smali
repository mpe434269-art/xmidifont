.class Lnet/duceng/xmidi/Drums$12;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Lnet/duceng/xmidi/util/Importer$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->onActivityResult(IILandroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 551
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$12;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onResult(Ljava/io/File;ZLjava/lang/String;)V
    .locals 4
    .param p1, "dest"    # Ljava/io/File;
    .param p2, "originalRemoved"    # Z
    .param p3, "error"    # Ljava/lang/String;

    .line 554
    const/4 v0, 0x1

    if-nez p3, :cond_2

    if-nez p1, :cond_0

    goto :goto_1

    .line 558
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$12;->this$0:Lnet/duceng/xmidi/Drums;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Estilo importado: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    if-eqz p2, :cond_1

    const-string v3, " (movido a la carpeta de estilos de la app)"

    goto :goto_0

    :cond_1
    const-string v3, " (copiado; el original no se pudo borrar)"

    :goto_0
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 559
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$12;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/Drums;->loadStyFile(Ljava/io/File;)V

    .line 560
    return-void

    .line 555
    :cond_2
    :goto_1
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$12;->this$0:Lnet/duceng/xmidi/Drums;

    if-eqz p3, :cond_3

    move-object v2, p3

    goto :goto_2

    :cond_3
    const-string v2, "No se pudo importar el estilo."

    :goto_2
    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 556
    return-void
.end method
