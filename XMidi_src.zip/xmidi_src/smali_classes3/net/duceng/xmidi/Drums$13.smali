.class Lnet/duceng/xmidi/Drums$13;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Lnet/duceng/xmidi/util/StyleEngine$Sink;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->buildEngine()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 716
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$13;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public send(Lnet/duceng/midi/EventChannel;)V
    .locals 1
    .param p1, "e"    # Lnet/duceng/midi/EventChannel;

    .line 719
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$13;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$000(Lnet/duceng/xmidi/Drums;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 720
    return-void

    .line 722
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$13;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0, p1}, Lnet/duceng/xsynth/Synth;->execEvent(Lnet/duceng/midi/MidiEvent;)V

    .line 723
    return-void
.end method

.method public silence()V
    .locals 3

    .line 727
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$13;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$000(Lnet/duceng/xmidi/Drums;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 728
    return-void

    .line 730
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$13;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    const/16 v1, 0x8

    const/16 v2, 0xf

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->silenceChannels(II)V

    .line 731
    return-void
.end method
