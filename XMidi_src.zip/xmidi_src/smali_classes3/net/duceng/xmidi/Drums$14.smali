.class Lnet/duceng/xmidi/Drums$14;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Lnet/duceng/xmidi/util/StyleEngine$Host;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->buildEngine()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 732
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$14;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public mpqn()I
    .locals 1

    .line 735
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$14;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MetaTempo;->getMpqn()I

    move-result v0

    return v0
.end method
