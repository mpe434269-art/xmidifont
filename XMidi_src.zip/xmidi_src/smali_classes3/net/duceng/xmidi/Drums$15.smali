.class Lnet/duceng/xmidi/Drums$15;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Ljava/util/concurrent/ThreadFactory;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->buildEngine()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 737
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$15;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 3
    .param p1, "r"    # Ljava/lang/Runnable;

    .line 740
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lnet/duceng/xmidi/Drums$15$1;

    invoke-direct {v1, p0, p1}, Lnet/duceng/xmidi/Drums$15$1;-><init>(Lnet/duceng/xmidi/Drums$15;Ljava/lang/Runnable;)V

    const-string v2, "XMidi-StyleEngine"

    invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    return-object v0
.end method
