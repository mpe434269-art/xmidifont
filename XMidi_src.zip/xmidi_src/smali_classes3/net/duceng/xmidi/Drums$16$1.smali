.class Lnet/duceng/xmidi/Drums$16$1;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums$16;->onSection(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/Drums$16;

.field final synthetic val$name:Ljava/lang/String;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums$16;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/Drums$16;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 756
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$16$1;->this$1:Lnet/duceng/xmidi/Drums$16;

    iput-object p2, p0, Lnet/duceng/xmidi/Drums$16$1;->val$name:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 759
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$16$1;->this$1:Lnet/duceng/xmidi/Drums$16;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$16;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v1, p0, Lnet/duceng/xmidi/Drums$16$1;->val$name:Ljava/lang/String;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Drums;->access$2400(Lnet/duceng/xmidi/Drums;Ljava/lang/String;)V

    .line 760
    return-void
.end method
