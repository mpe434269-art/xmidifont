.class Lnet/duceng/xmidi/Drums$16$2;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums$16;->onStopped()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/Drums$16;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums$16;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/Drums$16;

    .line 767
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$16$2;->this$1:Lnet/duceng/xmidi/Drums$16;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 770
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$16$2;->this$1:Lnet/duceng/xmidi/Drums$16;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$16;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$2500(Lnet/duceng/xmidi/Drums;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/Drums$16$2;->this$1:Lnet/duceng/xmidi/Drums$16;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$16;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$000(Lnet/duceng/xmidi/Drums;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 771
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$16$2;->this$1:Lnet/duceng/xmidi/Drums$16;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$16;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setBeating(Z)V

    .line 773
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$16$2;->this$1:Lnet/duceng/xmidi/Drums$16;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$16;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$2600(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 774
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$16$2;->this$1:Lnet/duceng/xmidi/Drums$16;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$16;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1900(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 775
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$16$2;->this$1:Lnet/duceng/xmidi/Drums$16;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$16;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$2700(Lnet/duceng/xmidi/Drums;)Landroid/widget/ImageButton;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 776
    return-void
.end method
