.class Lnet/duceng/xmidi/Drums$16;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Lnet/duceng/xmidi/util/StyleEngine$Listener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->buildEngine()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 753
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$16;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSection(Ljava/lang/String;)V
    .locals 2
    .param p1, "name"    # Ljava/lang/String;

    .line 756
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$16;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$2300(Lnet/duceng/xmidi/Drums;)Landroid/os/Handler;

    move-result-object v0

    new-instance v1, Lnet/duceng/xmidi/Drums$16$1;

    invoke-direct {v1, p0, p1}, Lnet/duceng/xmidi/Drums$16$1;-><init>(Lnet/duceng/xmidi/Drums$16;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 762
    return-void
.end method

.method public onStopped()V
    .locals 2

    .line 766
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$16;->this$0:Lnet/duceng/xmidi/Drums;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Drums;->access$1702(Lnet/duceng/xmidi/Drums;Z)Z

    .line 767
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$16;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$2300(Lnet/duceng/xmidi/Drums;)Landroid/os/Handler;

    move-result-object v0

    new-instance v1, Lnet/duceng/xmidi/Drums$16$2;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Drums$16$2;-><init>(Lnet/duceng/xmidi/Drums$16;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 778
    return-void
.end method
