.class Lnet/duceng/xmidi/Drums$17;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->onActionClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 843
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$17;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDismiss(Landroid/content/DialogInterface;)V
    .locals 1
    .param p1, "dialog"    # Landroid/content/DialogInterface;

    .line 846
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$17;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$2800(Lnet/duceng/xmidi/Drums;)V

    .line 847
    return-void
.end method
