.class Lnet/duceng/xmidi/Drums$18;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->onActionClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 876
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$18;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(IILjava/lang/String;)V
    .locals 2
    .param p1, "chan"    # I
    .param p2, "preset"    # I
    .param p3, "instrument"    # Ljava/lang/String;

    .line 879
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$18;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    int-to-byte v1, p1

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setRecordChan(B)V

    .line 880
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$18;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1200(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Drums$18;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-virtual {v1, p1}, Lnet/duceng/xmidi/Drums;->getPresetName(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 881
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$18;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$2900(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogChannel;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogChannel;->dismiss()V

    .line 882
    return-void
.end method
