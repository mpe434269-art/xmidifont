.class Lnet/duceng/xmidi/Drums$4$1;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogChord$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums$4;->onLongClick(Landroid/view/View;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/Drums$4;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums$4;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/Drums$4;

    .line 148
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$4$1;->this$1:Lnet/duceng/xmidi/Drums$4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(I)Z
    .locals 3
    .param p1, "idx"    # I

    .line 151
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$4$1;->this$1:Lnet/duceng/xmidi/Drums$4;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$4;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$300(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/Chords;

    move-result-object v0

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/util/Chords;->getChord(I)Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v0

    .line 152
    .local v0, "c":Lnet/duceng/xmidi/util/Chords$Chord;
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$4$1;->this$1:Lnet/duceng/xmidi/Drums$4;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$4;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$100(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;

    move-result-object v1

    iget-object v2, v0, Lnet/duceng/xmidi/util/Chords$Chord;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 153
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$4$1;->this$1:Lnet/duceng/xmidi/Drums$4;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$4;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$100(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 154
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$4$1;->this$1:Lnet/duceng/xmidi/Drums$4;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$4;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$400(Lnet/duceng/xmidi/Drums;)V

    .line 155
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$4$1;->this$1:Lnet/duceng/xmidi/Drums$4;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$4;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$100(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Button;->isSelected()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 156
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$4$1;->this$1:Lnet/duceng/xmidi/Drums$4;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$4;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1, v0}, Lnet/duceng/xmidi/Drums;->access$502(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/util/Chords$Chord;)Lnet/duceng/xmidi/util/Chords$Chord;

    .line 157
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$4$1;->this$1:Lnet/duceng/xmidi/Drums$4;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$4;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$600(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/StyleEngine;

    move-result-object v1

    if-eqz v1, :cond_0

    .line 158
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$4$1;->this$1:Lnet/duceng/xmidi/Drums$4;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$4;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$600(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/StyleEngine;

    move-result-object v1

    invoke-virtual {v1, v0}, Lnet/duceng/xmidi/util/StyleEngine;->setChord(Lnet/duceng/xmidi/util/Chords$Chord;)V

    .line 161
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$4$1;->this$1:Lnet/duceng/xmidi/Drums$4;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$4;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$200(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogChord;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/xmidi/ui/DialogChord;->dismiss()V

    .line 162
    const/4 v1, 0x1

    return v1
.end method
