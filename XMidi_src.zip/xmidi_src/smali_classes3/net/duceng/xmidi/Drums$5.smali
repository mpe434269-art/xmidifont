.class Lnet/duceng/xmidi/Drums$5;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Drums;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 170
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$5;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 5
    .param p1, "v"    # Landroid/view/View;
    .param p2, "event"    # Landroid/view/MotionEvent;

    .line 173
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    and-int/lit16 v0, v0, 0xff

    .line 174
    .local v0, "action":I
    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 175
    iget-object v2, p0, Lnet/duceng/xmidi/Drums$5;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v2, v2, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->byteValue()B

    move-result v3

    const/16 v4, 0x64

    invoke-virtual {v2, v3, v4}, Lnet/duceng/xsynth/Synth;->noteOn(BB)V

    .line 176
    return v1

    .line 178
    :cond_0
    const/4 v2, 0x1

    if-ne v0, v2, :cond_1

    .line 179
    iget-object v2, p0, Lnet/duceng/xmidi/Drums$5;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v2, v2, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->byteValue()B

    move-result v3

    invoke-virtual {v2, v3}, Lnet/duceng/xsynth/Synth;->noteOff(B)V

    .line 180
    return v1

    .line 182
    :cond_1
    return v1
.end method
