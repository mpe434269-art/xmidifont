.class Lnet/duceng/xmidi/Drums$6$1;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogPercussion$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums$6;->onLongClick(Landroid/view/View;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/Drums$6;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums$6;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/Drums$6;

    .line 191
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$6$1;->this$1:Lnet/duceng/xmidi/Drums$6;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(I)Z
    .locals 2
    .param p1, "idx"    # I

    .line 194
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$6$1;->this$1:Lnet/duceng/xmidi/Drums$6;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$700(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Drums$6$1;->this$1:Lnet/duceng/xmidi/Drums$6;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$900(Lnet/duceng/xmidi/Drums;)[Ljava/lang/String;

    move-result-object v1

    aget-object v1, v1, p1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 195
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$6$1;->this$1:Lnet/duceng/xmidi/Drums$6;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$700(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;

    move-result-object v0

    invoke-static {}, Lnet/duceng/xmidi/Drums;->access$1000()B

    move-result v1

    add-int/2addr v1, p1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 196
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$6$1;->this$1:Lnet/duceng/xmidi/Drums$6;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$800(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogPercussion;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogPercussion;->dismiss()V

    .line 197
    const/4 v0, 0x1

    return v0
.end method
