.class Lnet/duceng/xmidi/Drums$6;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Drums;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 185
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 188
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    move-object v1, p1

    check-cast v1, Landroid/widget/Button;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Drums;->access$702(Lnet/duceng/xmidi/Drums;Landroid/widget/Button;)Landroid/widget/Button;

    .line 189
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$800(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogPercussion;

    move-result-object v0

    if-nez v0, :cond_0

    .line 190
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    new-instance v1, Lnet/duceng/xmidi/ui/DialogPercussion;

    iget-object v2, p0, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v3, p0, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v3}, Lnet/duceng/xmidi/Drums;->access$900(Lnet/duceng/xmidi/Drums;)[Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Lnet/duceng/xmidi/ui/DialogPercussion;-><init>(Landroid/content/Context;[Ljava/lang/String;)V

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Drums;->access$802(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/ui/DialogPercussion;)Lnet/duceng/xmidi/ui/DialogPercussion;

    .line 191
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$800(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogPercussion;

    move-result-object v0

    new-instance v1, Lnet/duceng/xmidi/Drums$6$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Drums$6$1;-><init>(Lnet/duceng/xmidi/Drums$6;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogPercussion;->setOnSelectListener(Lnet/duceng/xmidi/ui/DialogPercussion$OnSelectListener;)V

    .line 201
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$6;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$800(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogPercussion;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogPercussion;->show()V

    .line 202
    const/4 v0, 0x1

    return v0
.end method
