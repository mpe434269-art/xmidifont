.class Lnet/duceng/xmidi/Drums$7$1;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums$7;->onLongClick(Landroid/view/View;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/Drums$7;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums$7;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/Drums$7;

    .line 218
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$7$1;->this$1:Lnet/duceng/xmidi/Drums$7;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDismiss(Landroid/content/DialogInterface;)V
    .locals 3
    .param p1, "dialog"    # Landroid/content/DialogInterface;

    .line 221
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$7$1;->this$1:Lnet/duceng/xmidi/Drums$7;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1200(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Drums$7$1;->this$1:Lnet/duceng/xmidi/Drums$7;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v2, p0, Lnet/duceng/xmidi/Drums$7$1;->this$1:Lnet/duceng/xmidi/Drums$7;

    iget-object v2, v2, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v2, v2, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v2

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/Drums;->getPresetName(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 222
    return-void
.end method
