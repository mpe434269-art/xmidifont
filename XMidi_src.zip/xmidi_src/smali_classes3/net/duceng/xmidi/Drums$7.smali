.class Lnet/duceng/xmidi/Drums$7;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 213
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 216
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1100(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogPreset;

    move-result-object v0

    if-nez v0, :cond_0

    .line 217
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    new-instance v1, Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v2, p0, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v3, p0, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v3, v3, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v1, v2, v3}, Lnet/duceng/xmidi/ui/DialogPreset;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Drums;->access$1102(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/ui/DialogPreset;)Lnet/duceng/xmidi/ui/DialogPreset;

    .line 218
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1100(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogPreset;

    move-result-object v0

    new-instance v1, Lnet/duceng/xmidi/Drums$7$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Drums$7$1;-><init>(Lnet/duceng/xmidi/Drums$7;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogPreset;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 225
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1100(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogPreset;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogPreset;->setChannel(I)V

    .line 226
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$7;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1100(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogPreset;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogPreset;->show()V

    .line 227
    const/4 v0, 0x1

    return v0
.end method
