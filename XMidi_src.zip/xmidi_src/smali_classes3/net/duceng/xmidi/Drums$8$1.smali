.class Lnet/duceng/xmidi/Drums$8$1;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums$8;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/Drums$8;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums$8;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/Drums$8;

    .line 281
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$8$1;->this$1:Lnet/duceng/xmidi/Drums$8;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(Ljava/io/File;)V
    .locals 4
    .param p1, "f"    # Ljava/io/File;

    .line 284
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$8$1;->this$1:Lnet/duceng/xmidi/Drums$8;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/Drums;->loadStyFile(Ljava/io/File;)V

    .line 285
    const/4 v0, 0x0

    .local v0, "i2":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$8$1;->this$1:Lnet/duceng/xmidi/Drums$8;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$1400(Lnet/duceng/xmidi/Drums;)[Landroid/widget/Button;

    move-result-object v1

    array-length v1, v1

    const/4 v2, 0x0

    if-ge v0, v1, :cond_0

    .line 286
    iget-object v1, p0, Lnet/duceng/xmidi/Drums$8$1;->this$1:Lnet/duceng/xmidi/Drums$8;

    iget-object v1, v1, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v1}, Lnet/duceng/xmidi/Drums;->access$1400(Lnet/duceng/xmidi/Drums;)[Landroid/widget/Button;

    move-result-object v1

    aget-object v1, v1, v0

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setSelected(Z)V

    .line 285
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 288
    .end local v0    # "i2":I
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$8$1;->this$1:Lnet/duceng/xmidi/Drums$8;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Drums;->access$1502(Lnet/duceng/xmidi/Drums;Lnet/duceng/midi/StySection;)Lnet/duceng/midi/StySection;

    .line 289
    const/4 v0, 0x0

    .local v0, "i3":I
    :goto_1
    iget-object v3, p0, Lnet/duceng/xmidi/Drums$8$1;->this$1:Lnet/duceng/xmidi/Drums$8;

    iget-object v3, v3, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v3}, Lnet/duceng/xmidi/Drums;->access$1600(Lnet/duceng/xmidi/Drums;)[Landroid/widget/Button;

    move-result-object v3

    array-length v3, v3

    if-ge v0, v3, :cond_1

    .line 290
    iget-object v3, p0, Lnet/duceng/xmidi/Drums$8$1;->this$1:Lnet/duceng/xmidi/Drums$8;

    iget-object v3, v3, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v3}, Lnet/duceng/xmidi/Drums;->access$1600(Lnet/duceng/xmidi/Drums;)[Landroid/widget/Button;

    move-result-object v3

    aget-object v3, v3, v0

    invoke-virtual {v3, v2}, Landroid/widget/Button;->setSelected(Z)V

    .line 289
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 292
    .end local v0    # "i3":I
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$8$1;->this$1:Lnet/duceng/xmidi/Drums$8;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Drums;->access$502(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/util/Chords$Chord;)Lnet/duceng/xmidi/util/Chords$Chord;

    .line 293
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$8$1;->this$1:Lnet/duceng/xmidi/Drums$8;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$600(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/StyleEngine;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 294
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$8$1;->this$1:Lnet/duceng/xmidi/Drums$8;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$600(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/StyleEngine;

    move-result-object v0

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->setChord(Lnet/duceng/xmidi/util/Chords$Chord;)V

    .line 296
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$8$1;->this$1:Lnet/duceng/xmidi/Drums$8;

    iget-object v0, v0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1300(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogSty;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogSty;->dismiss()V

    .line 297
    return-void
.end method
