.class Lnet/duceng/xmidi/Drums$8;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 276
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 279
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1300(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogSty;

    move-result-object v0

    if-nez v0, :cond_0

    .line 280
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    new-instance v1, Lnet/duceng/xmidi/ui/DialogSty;

    iget-object v2, p0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {v1, v2}, Lnet/duceng/xmidi/ui/DialogSty;-><init>(Landroid/content/Context;)V

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Drums;->access$1302(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/ui/DialogSty;)Lnet/duceng/xmidi/ui/DialogSty;

    .line 281
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1300(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogSty;

    move-result-object v0

    new-instance v1, Lnet/duceng/xmidi/Drums$8$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Drums$8$1;-><init>(Lnet/duceng/xmidi/Drums$8;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogSty;->setOnSelectListener(Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;)V

    .line 300
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$8;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1300(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogSty;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogSty;->show()V

    .line 301
    return-void
.end method
