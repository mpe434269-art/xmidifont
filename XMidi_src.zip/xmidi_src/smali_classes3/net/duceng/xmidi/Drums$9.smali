.class Lnet/duceng/xmidi/Drums$9;
.super Ljava/lang/Object;
.source "Drums.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Drums;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Drums;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Drums;

    .line 304
    iput-object p1, p0, Lnet/duceng/xmidi/Drums$9;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 307
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$9;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-static {v0}, Lnet/duceng/xmidi/Drums;->access$1700(Lnet/duceng/xmidi/Drums;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 308
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$9;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-virtual {v0}, Lnet/duceng/xmidi/Drums;->play()V

    goto :goto_0

    .line 310
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums$9;->this$0:Lnet/duceng/xmidi/Drums;

    invoke-virtual {v0}, Lnet/duceng/xmidi/Drums;->stop()V

    .line 312
    :goto_0
    return-void
.end method
