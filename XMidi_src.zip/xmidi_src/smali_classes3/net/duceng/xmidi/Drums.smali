.class public Lnet/duceng/xmidi/Drums;
.super Lnet/duceng/xmidi/BaseApp;
.source "Drums.java"


# static fields
.field private static final KEY_CHAN:I = 0x0

.field private static NOTE_BASE:B = 0x0t

.field private static NOTE_CHAN:B = 0x0t

.field private static final PREF_CHORDS:Ljava/lang/String; = "drums_chords"

.field private static final PREF_STY:Ljava/lang/String; = "drums_sty_path"

.field private static final PREF_TONALITY:Ljava/lang/String; = "drums_tonality"

.field private static STY_DEFAULT:Ljava/lang/String;


# instance fields
.field private auto:Z

.field private bAuto:Landroid/widget/ImageButton;

.field private bKeyboard:Landroid/widget/Button;

.field private bLock:Landroid/widget/ImageButton;

.field private bPreset:Landroid/widget/Button;

.field private bSustain:Landroid/widget/Button;

.field private baseApplied:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/EventChannel;",
            ">;"
        }
    .end annotation
.end field

.field private btnChords:[Landroid/widget/Button;

.field private btnDrums:[Landroid/widget/Button;

.field private btnFile:Landroid/widget/Button;

.field private btnPlay:Landroid/widget/ImageButton;

.field private btnSections:[Landroid/widget/Button;

.field private btnTonality:Landroid/widget/Button;

.field private channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

.field private chord:Lnet/duceng/xmidi/util/Chords$Chord;

.field private chordLongBtn:Landroid/widget/Button;

.field private chordLongClickListener:Landroid/view/View$OnLongClickListener;

.field private chordTouchListener:Landroid/view/View$OnTouchListener;

.field private volatile destroyed:Z

.field private dialogChordRef:Lnet/duceng/xmidi/ui/DialogChord;

.field private dialogPercRef:Lnet/duceng/xmidi/ui/DialogPercussion;

.field private dialogStyRef:Lnet/duceng/xmidi/ui/DialogSty;

.field private dialogTonalityRef:Lnet/duceng/xmidi/ui/DialogTonality;

.field private divh:Landroid/view/View;

.field private divv:Landroid/view/View;

.field private drumLongBtn:Landroid/widget/Button;

.field private drumLongClickListener:Landroid/view/View$OnLongClickListener;

.field private drumTouchListener:Landroid/view/View$OnTouchListener;

.field private engine:Lnet/duceng/xmidi/util/StyleEngine;

.field private gChords:Lnet/duceng/xmidi/util/Chords;

.field private handler:Landroid/os/Handler;

.field private idxBar:I

.field private idxBeat:I

.field private final keyListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

.field private keyboardPreset:Lnet/duceng/xmidi/ui/DialogPreset;

.field private layoutAuto:Landroid/widget/LinearLayout;

.field private layoutBtns:[Landroid/widget/LinearLayout;

.field private layoutDrums:Landroid/widget/LinearLayout;

.field private layoutKeys:Landroid/widget/LinearLayout;

.field private layoutManual:Landroid/widget/LinearLayout;

.field private layoutStys:[Landroid/widget/LinearLayout;

.field private layoutTop:Landroid/widget/LinearLayout;

.field private mExecutor:Ljava/util/concurrent/ExecutorService;

.field private mRunnable:Ljava/lang/Runnable;

.field private metroOn:Z

.field private notes:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lnet/duceng/midi/EventChannel;",
            ">;"
        }
    .end annotation
.end field

.field private notes15:[I

.field private notes8:[I

.field private percussions:[Ljava/lang/String;

.field private piano:Lnet/duceng/xmidi/widgets/PianoBoard;

.field private playing:Z

.field private rhythmPreset:Lnet/duceng/xmidi/ui/DialogPreset;

.field private sectionTouchListener:Landroid/view/View$OnTouchListener;

.field private startedBySynth:Z

.field private styFile:Lnet/duceng/midi/StyFile;

.field private stySection:Lnet/duceng/midi/StySection;

.field private sustainBg:Landroid/graphics/drawable/Drawable;

.field private sustainOn:Z

.field private tonalityIndex:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 47
    const/16 v0, 0x1b

    sput-byte v0, Lnet/duceng/xmidi/Drums;->NOTE_BASE:B

    .line 48
    const/16 v0, 0x9

    sput-byte v0, Lnet/duceng/xmidi/Drums;->NOTE_CHAN:B

    .line 49
    const-string v0, "Sample4.sty"

    sput-object v0, Lnet/duceng/xmidi/Drums;->STY_DEFAULT:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 46
    invoke-direct {p0}, Lnet/duceng/xmidi/BaseApp;-><init>()V

    .line 70
    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->notes8:[I

    .line 71
    const/16 v0, 0xf

    new-array v1, v0, [I

    fill-array-data v1, :array_1

    iput-object v1, p0, Lnet/duceng/xmidi/Drums;->notes15:[I

    .line 72
    const/4 v1, 0x5

    new-array v2, v1, [Landroid/widget/LinearLayout;

    iput-object v2, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    .line 73
    new-array v1, v1, [Landroid/widget/LinearLayout;

    iput-object v1, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    .line 74
    const/16 v1, 0x14

    new-array v1, v1, [Landroid/widget/Button;

    iput-object v1, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    .line 75
    const/16 v1, 0x10

    new-array v1, v1, [Landroid/widget/Button;

    iput-object v1, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    .line 76
    new-array v0, v0, [Landroid/widget/Button;

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    .line 84
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->startedBySynth:Z

    .line 85
    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->destroyed:Z

    .line 95
    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->sustainOn:Z

    .line 96
    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->metroOn:Z

    .line 97
    iput v0, p0, Lnet/duceng/xmidi/Drums;->tonalityIndex:I

    .line 101
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lnet/duceng/xmidi/Drums;->baseApplied:Ljava/util/ArrayList;

    .line 102
    new-instance v1, Lnet/duceng/xmidi/Drums$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Drums$1;-><init>(Lnet/duceng/xmidi/Drums;)V

    iput-object v1, p0, Lnet/duceng/xmidi/Drums;->keyListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    .line 115
    const/4 v1, 0x1

    iput-boolean v1, p0, Lnet/duceng/xmidi/Drums;->auto:Z

    .line 116
    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->playing:Z

    .line 117
    iput v0, p0, Lnet/duceng/xmidi/Drums;->idxBeat:I

    .line 118
    iput v0, p0, Lnet/duceng/xmidi/Drums;->idxBar:I

    .line 119
    new-instance v0, Lnet/duceng/xmidi/util/Chords;

    invoke-direct {v0}, Lnet/duceng/xmidi/util/Chords;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->gChords:Lnet/duceng/xmidi/util/Chords;

    .line 120
    new-instance v0, Lnet/duceng/xmidi/Drums$2;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Drums$2;-><init>(Lnet/duceng/xmidi/Drums;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->sectionTouchListener:Landroid/view/View$OnTouchListener;

    .line 131
    new-instance v0, Lnet/duceng/xmidi/Drums$3;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Drums$3;-><init>(Lnet/duceng/xmidi/Drums;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->chordTouchListener:Landroid/view/View$OnTouchListener;

    .line 142
    new-instance v0, Lnet/duceng/xmidi/Drums$4;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Drums$4;-><init>(Lnet/duceng/xmidi/Drums;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->chordLongClickListener:Landroid/view/View$OnLongClickListener;

    .line 170
    new-instance v0, Lnet/duceng/xmidi/Drums$5;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Drums$5;-><init>(Lnet/duceng/xmidi/Drums;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->drumTouchListener:Landroid/view/View$OnTouchListener;

    .line 185
    new-instance v0, Lnet/duceng/xmidi/Drums$6;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Drums$6;-><init>(Lnet/duceng/xmidi/Drums;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->drumLongClickListener:Landroid/view/View$OnLongClickListener;

    return-void

    nop

    :array_0
    .array-data 4
        0x9
        0xa
        0xb
        0x12
        0x15
        0x13
        0x16
        0x18
    .end array-data

    :array_1
    .array-data 4
        0x9
        0xa
        0xb
        0xe
        0x10
        0x12
        0x14
        0x15
        0x17
        0xf
        0x11
        0x13
        0x16
        0x18
        0x1a
    .end array-data
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/Drums;)Z
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->destroyed:Z

    return v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->chordLongBtn:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$1000()B
    .locals 1

    .line 46
    sget-byte v0, Lnet/duceng/xmidi/Drums;->NOTE_BASE:B

    return v0
.end method

.method static synthetic access$102(Lnet/duceng/xmidi/Drums;Landroid/widget/Button;)Landroid/widget/Button;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Landroid/widget/Button;

    .line 46
    iput-object p1, p0, Lnet/duceng/xmidi/Drums;->chordLongBtn:Landroid/widget/Button;

    return-object p1
.end method

.method static synthetic access$1100(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogPreset;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->rhythmPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    return-object v0
.end method

.method static synthetic access$1102(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/ui/DialogPreset;)Lnet/duceng/xmidi/ui/DialogPreset;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 46
    iput-object p1, p0, Lnet/duceng/xmidi/Drums;->rhythmPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    return-object p1
.end method

.method static synthetic access$1200(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bPreset:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$1300(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogSty;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->dialogStyRef:Lnet/duceng/xmidi/ui/DialogSty;

    return-object v0
.end method

.method static synthetic access$1302(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/ui/DialogSty;)Lnet/duceng/xmidi/ui/DialogSty;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Lnet/duceng/xmidi/ui/DialogSty;

    .line 46
    iput-object p1, p0, Lnet/duceng/xmidi/Drums;->dialogStyRef:Lnet/duceng/xmidi/ui/DialogSty;

    return-object p1
.end method

.method static synthetic access$1400(Lnet/duceng/xmidi/Drums;)[Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$1500(Lnet/duceng/xmidi/Drums;)Lnet/duceng/midi/StySection;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->stySection:Lnet/duceng/midi/StySection;

    return-object v0
.end method

.method static synthetic access$1502(Lnet/duceng/xmidi/Drums;Lnet/duceng/midi/StySection;)Lnet/duceng/midi/StySection;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Lnet/duceng/midi/StySection;

    .line 46
    iput-object p1, p0, Lnet/duceng/xmidi/Drums;->stySection:Lnet/duceng/midi/StySection;

    return-object p1
.end method

.method static synthetic access$1600(Lnet/duceng/xmidi/Drums;)[Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$1700(Lnet/duceng/xmidi/Drums;)Z
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->playing:Z

    return v0
.end method

.method static synthetic access$1702(Lnet/duceng/xmidi/Drums;Z)Z
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Z

    .line 46
    iput-boolean p1, p0, Lnet/duceng/xmidi/Drums;->playing:Z

    return p1
.end method

.method static synthetic access$1800(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogTonality;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->dialogTonalityRef:Lnet/duceng/xmidi/ui/DialogTonality;

    return-object v0
.end method

.method static synthetic access$1802(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/ui/DialogTonality;)Lnet/duceng/xmidi/ui/DialogTonality;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Lnet/duceng/xmidi/ui/DialogTonality;

    .line 46
    iput-object p1, p0, Lnet/duceng/xmidi/Drums;->dialogTonalityRef:Lnet/duceng/xmidi/ui/DialogTonality;

    return-object p1
.end method

.method static synthetic access$1900(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnTonality:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$200(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogChord;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->dialogChordRef:Lnet/duceng/xmidi/ui/DialogChord;

    return-object v0
.end method

.method static synthetic access$2002(Lnet/duceng/xmidi/Drums;I)I
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # I

    .line 46
    iput p1, p0, Lnet/duceng/xmidi/Drums;->tonalityIndex:I

    return p1
.end method

.method static synthetic access$202(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/ui/DialogChord;)Lnet/duceng/xmidi/ui/DialogChord;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Lnet/duceng/xmidi/ui/DialogChord;

    .line 46
    iput-object p1, p0, Lnet/duceng/xmidi/Drums;->dialogChordRef:Lnet/duceng/xmidi/ui/DialogChord;

    return-object p1
.end method

.method static synthetic access$2100(Lnet/duceng/xmidi/Drums;)Z
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->auto:Z

    return v0
.end method

.method static synthetic access$2202(Lnet/duceng/xmidi/Drums;Z)Z
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Z

    .line 46
    iput-boolean p1, p0, Lnet/duceng/xmidi/Drums;->startedBySynth:Z

    return p1
.end method

.method static synthetic access$2300(Lnet/duceng/xmidi/Drums;)Landroid/os/Handler;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->handler:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic access$2400(Lnet/duceng/xmidi/Drums;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Ljava/lang/String;

    .line 46
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/Drums;->highlight(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$2500(Lnet/duceng/xmidi/Drums;)Z
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->metroOn:Z

    return v0
.end method

.method static synthetic access$2600(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnFile:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$2700(Lnet/duceng/xmidi/Drums;)Landroid/widget/ImageButton;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnPlay:Landroid/widget/ImageButton;

    return-object v0
.end method

.method static synthetic access$2800(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->updateKeyboardUi()V

    return-void
.end method

.method static synthetic access$2900(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogChannel;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    return-object v0
.end method

.method static synthetic access$300(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/Chords;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->gChords:Lnet/duceng/xmidi/util/Chords;

    return-object v0
.end method

.method static synthetic access$400(Lnet/duceng/xmidi/Drums;)V
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->saveChords()V

    return-void
.end method

.method static synthetic access$500(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/Chords$Chord;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    return-object v0
.end method

.method static synthetic access$502(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/util/Chords$Chord;)Lnet/duceng/xmidi/util/Chords$Chord;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Lnet/duceng/xmidi/util/Chords$Chord;

    .line 46
    iput-object p1, p0, Lnet/duceng/xmidi/Drums;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    return-object p1
.end method

.method static synthetic access$600(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/util/StyleEngine;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    return-object v0
.end method

.method static synthetic access$700(Lnet/duceng/xmidi/Drums;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->drumLongBtn:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$702(Lnet/duceng/xmidi/Drums;Landroid/widget/Button;)Landroid/widget/Button;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Landroid/widget/Button;

    .line 46
    iput-object p1, p0, Lnet/duceng/xmidi/Drums;->drumLongBtn:Landroid/widget/Button;

    return-object p1
.end method

.method static synthetic access$800(Lnet/duceng/xmidi/Drums;)Lnet/duceng/xmidi/ui/DialogPercussion;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->dialogPercRef:Lnet/duceng/xmidi/ui/DialogPercussion;

    return-object v0
.end method

.method static synthetic access$802(Lnet/duceng/xmidi/Drums;Lnet/duceng/xmidi/ui/DialogPercussion;)Lnet/duceng/xmidi/ui/DialogPercussion;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;
    .param p1, "x1"    # Lnet/duceng/xmidi/ui/DialogPercussion;

    .line 46
    iput-object p1, p0, Lnet/duceng/xmidi/Drums;->dialogPercRef:Lnet/duceng/xmidi/ui/DialogPercussion;

    return-object p1
.end method

.method static synthetic access$900(Lnet/duceng/xmidi/Drums;)[Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Drums;

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->percussions:[Ljava/lang/String;

    return-object v0
.end method

.method private applyKeysVisibility()V
    .locals 3

    .line 505
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutKeys:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_5

    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutManual:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_5

    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutTop:Landroid/widget/LinearLayout;

    if-nez v0, :cond_0

    goto :goto_1

    .line 508
    :cond_0
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->auto:Z

    const/4 v1, 0x0

    const/16 v2, 0x8

    if-eqz v0, :cond_1

    .line 509
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutTop:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 510
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutKeys:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 511
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutManual:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 512
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->divh:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    goto :goto_0

    .line 514
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->piano:Lnet/duceng/xmidi/widgets/PianoBoard;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/PianoBoard;->releaseAll()V

    .line 515
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutTop:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 516
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutKeys:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 517
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutManual:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 518
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->divh:Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 520
    :goto_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->divv:Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 521
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bLock:Landroid/widget/ImageButton;

    if-eqz v0, :cond_2

    .line 522
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bLock:Landroid/widget/ImageButton;

    iget-boolean v1, p0, Lnet/duceng/xmidi/Drums;->auto:Z

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setEnabled(Z)V

    .line 524
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bSustain:Landroid/widget/Button;

    if-eqz v0, :cond_3

    .line 525
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bSustain:Landroid/widget/Button;

    iget-boolean v1, p0, Lnet/duceng/xmidi/Drums;->auto:Z

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 527
    :cond_3
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bKeyboard:Landroid/widget/Button;

    if-eqz v0, :cond_4

    .line 528
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bKeyboard:Landroid/widget/Button;

    iget-boolean v1, p0, Lnet/duceng/xmidi/Drums;->auto:Z

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 530
    :cond_4
    return-void

    .line 506
    :cond_5
    :goto_1
    return-void
.end method

.method private applyMetronome()V
    .locals 5

    .line 533
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    if-eqz v0, :cond_0

    .line 534
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    iget-boolean v1, p0, Lnet/duceng/xmidi/Drums;->metroOn:Z

    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->getBeatNote1()B

    move-result v2

    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v3}, Lnet/duceng/xsynth/Synth;->getBeatNote2()B

    move-result v3

    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v4}, Lnet/duceng/xsynth/Synth;->getBeatVelocity()B

    move-result v4

    invoke-virtual {v0, v1, v2, v3, v4}, Lnet/duceng/xmidi/util/StyleEngine;->setMetronome(ZIII)V

    .line 536
    :cond_0
    return-void
.end method

.method private applyStyleSetup()V
    .locals 10

    .line 666
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setStyleMix(Z)V

    .line 667
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    const/16 v1, 0x8

    const/16 v2, 0xf

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->clearOverrides(II)V

    .line 668
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->resetChannels(II)V

    .line 669
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->baseApplied:Ljava/util/ArrayList;

    .line 670
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 671
    .local v0, "init":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->styFile:Lnet/duceng/midi/StyFile;

    invoke-virtual {v2}, Lnet/duceng/midi/StyFile;->getHead()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/MidiEvent;

    .line 672
    .local v3, "e":Lnet/duceng/midi/MidiEvent;
    instance-of v4, v3, Lnet/duceng/midi/EventChannel;

    if-eqz v4, :cond_0

    move-object v4, v3

    check-cast v4, Lnet/duceng/midi/EventChannel;

    invoke-virtual {v4}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v4

    if-lt v4, v1, :cond_0

    .line 673
    move-object v4, v3

    check-cast v4, Lnet/duceng/midi/EventChannel;

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 675
    .end local v3    # "e":Lnet/duceng/midi/MidiEvent;
    :cond_0
    goto :goto_0

    .line 676
    :cond_1
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->styFile:Lnet/duceng/midi/StyFile;

    invoke-virtual {v2}, Lnet/duceng/midi/StyFile;->getSint()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/MidiEvent;

    .line 677
    .local v3, "e2":Lnet/duceng/midi/MidiEvent;
    instance-of v4, v3, Lnet/duceng/midi/EventChannel;

    if-eqz v4, :cond_2

    move-object v4, v3

    check-cast v4, Lnet/duceng/midi/EventChannel;

    invoke-virtual {v4}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v4

    if-lt v4, v1, :cond_2

    .line 678
    move-object v4, v3

    check-cast v4, Lnet/duceng/midi/EventChannel;

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 680
    .end local v3    # "e2":Lnet/duceng/midi/MidiEvent;
    :cond_2
    goto :goto_1

    .line 683
    :cond_3
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_4
    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/16 v4, 0x20

    const/16 v5, 0xb

    const/16 v6, 0x9

    if-eqz v3, :cond_9

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/EventChannel;

    .line 684
    .local v3, "e3":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v7

    .line 685
    .local v7, "ch":I
    if-eq v7, v1, :cond_4

    if-eq v7, v6, :cond_4

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v6

    if-eq v6, v5, :cond_5

    .line 686
    goto :goto_2

    .line 688
    :cond_5
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v5

    if-nez v5, :cond_6

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v5

    const/16 v6, 0x7f

    if-ne v5, v6, :cond_7

    :cond_6
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v5

    if-ne v5, v4, :cond_8

    .line 689
    :cond_7
    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v4, v3}, Lnet/duceng/xsynth/Synth;->execEvent(Lnet/duceng/midi/MidiEvent;)V

    .line 690
    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->baseApplied:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 692
    .end local v3    # "e3":Lnet/duceng/midi/EventChannel;
    .end local v7    # "ch":I
    :cond_8
    goto :goto_2

    .line 694
    :cond_9
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/EventChannel;

    .line 695
    .local v3, "e4":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v7

    .line 696
    .local v7, "ch2":I
    if-eq v7, v1, :cond_a

    if-eq v7, v6, :cond_a

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v8

    const/16 v9, 0xc

    if-ne v8, v9, :cond_a

    .line 697
    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v8, v3}, Lnet/duceng/xsynth/Synth;->execEvent(Lnet/duceng/midi/MidiEvent;)V

    .line 698
    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->baseApplied:Ljava/util/ArrayList;

    invoke-virtual {v8, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 700
    .end local v3    # "e4":Lnet/duceng/midi/EventChannel;
    .end local v7    # "ch2":I
    :cond_a
    goto :goto_3

    .line 702
    :cond_b
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_c
    :goto_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_e

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/EventChannel;

    .line 703
    .local v3, "e5":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v6

    .line 704
    .local v6, "ch3":I
    if-eq v6, v1, :cond_c

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v7

    if-ne v7, v5, :cond_c

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v7

    if-eqz v7, :cond_c

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v7

    if-ne v7, v4, :cond_d

    .line 705
    goto :goto_4

    .line 707
    :cond_d
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v7, v3}, Lnet/duceng/xsynth/Synth;->execEvent(Lnet/duceng/midi/MidiEvent;)V

    .line 708
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->baseApplied:Ljava/util/ArrayList;

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 709
    .end local v3    # "e5":Lnet/duceng/midi/EventChannel;
    .end local v6    # "ch3":I
    goto :goto_4

    .line 710
    :cond_e
    return-void
.end method

.method private buildEngine()V
    .locals 5

    .line 713
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    if-eqz v0, :cond_0

    .line 714
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/StyleEngine;->stop()V

    .line 716
    :cond_0
    new-instance v0, Lnet/duceng/xmidi/util/StyleEngine;

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->styFile:Lnet/duceng/midi/StyFile;

    new-instance v2, Lnet/duceng/xmidi/Drums$13;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/Drums$13;-><init>(Lnet/duceng/xmidi/Drums;)V

    new-instance v3, Lnet/duceng/xmidi/Drums$14;

    invoke-direct {v3, p0}, Lnet/duceng/xmidi/Drums$14;-><init>(Lnet/duceng/xmidi/Drums;)V

    new-instance v4, Lnet/duceng/xmidi/Drums$15;

    invoke-direct {v4, p0}, Lnet/duceng/xmidi/Drums$15;-><init>(Lnet/duceng/xmidi/Drums;)V

    invoke-direct {v0, v1, v2, v3, v4}, Lnet/duceng/xmidi/util/StyleEngine;-><init>(Lnet/duceng/midi/StyFile;Lnet/duceng/xmidi/util/StyleEngine$Sink;Lnet/duceng/xmidi/util/StyleEngine$Host;Ljava/util/concurrent/ThreadFactory;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    .line 753
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    new-instance v1, Lnet/duceng/xmidi/Drums$16;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Drums$16;-><init>(Lnet/duceng/xmidi/Drums;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->setListener(Lnet/duceng/xmidi/util/StyleEngine$Listener;)V

    .line 780
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->baseApplied:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->setBaseSetup(Ljava/util/List;)V

    .line 781
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->applyMetronome()V

    .line 782
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->setChord(Lnet/duceng/xmidi/util/Chords$Chord;)V

    .line 783
    return-void
.end method

.method private highlight(Ljava/lang/String;)V
    .locals 4
    .param p1, "name"    # Ljava/lang/String;

    .line 787
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    array-length v1, v1

    if-ge v0, v1, :cond_2

    .line 788
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/StySection;

    .line 789
    .local v1, "ss":Lnet/duceng/midi/StySection;
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    aget-object v2, v2, v0

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x1

    goto :goto_1

    :cond_0
    const/4 v3, 0x0

    :goto_1
    invoke-virtual {v2, v3}, Landroid/widget/Button;->setSelected(Z)V

    .line 790
    if-eqz v1, :cond_1

    invoke-virtual {v1}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 791
    iput-object v1, p0, Lnet/duceng/xmidi/Drums;->stySection:Lnet/duceng/midi/StySection;

    .line 787
    .end local v1    # "ss":Lnet/duceng/midi/StySection;
    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 794
    .end local v0    # "i":I
    :cond_2
    return-void
.end method

.method private restoreChords()V
    .locals 10

    .line 452
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 453
    .local v0, "pref":Landroid/content/SharedPreferences;
    const-string v1, "drums_tonality"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    const/16 v3, 0xb

    invoke-static {v3, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, p0, Lnet/duceng/xmidi/Drums;->tonalityIndex:I

    .line 454
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->gChords:Lnet/duceng/xmidi/util/Chords;

    iget v3, p0, Lnet/duceng/xmidi/Drums;->tonalityIndex:I

    invoke-virtual {v1, v3}, Lnet/duceng/xmidi/util/Chords;->getGChords16(I)[Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v1

    .line 455
    .local v1, "chords":[Lnet/duceng/xmidi/util/Chords$Chord;
    const-string v3, "drums_chords"

    const/4 v4, 0x0

    invoke-interface {v0, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 456
    .local v3, "saved":Ljava/lang/String;
    if-eqz v3, :cond_2

    .line 457
    const-string v4, ","

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 458
    .local v4, "parts":[Ljava/lang/String;
    array-length v5, v4

    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    array-length v6, v6

    if-ne v5, v6, :cond_2

    .line 460
    :try_start_0
    array-length v5, v4

    new-array v5, v5, [Lnet/duceng/xmidi/util/Chords$Chord;

    .line 461
    .local v5, "restored":[Lnet/duceng/xmidi/util/Chords$Chord;
    const/4 v6, 0x0

    .local v6, "i":I
    :goto_0
    array-length v7, v4

    if-ge v6, v7, :cond_1

    .line 462
    aget-object v7, v4, v6

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    .line 463
    .local v7, "id":I
    if-ltz v7, :cond_0

    const/16 v8, 0x2f

    if-gt v7, v8, :cond_0

    .line 466
    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->gChords:Lnet/duceng/xmidi/util/Chords;

    invoke-virtual {v8, v7}, Lnet/duceng/xmidi/util/Chords;->getChord(I)Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v8

    aput-object v8, v5, v6

    .line 461
    .end local v7    # "id":I
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    .line 464
    .restart local v7    # "id":I
    :cond_0
    new-instance v8, Ljava/lang/NumberFormatException;

    const-string v9, "acorde fuera de rango"

    invoke-direct {v8, v9}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    .end local v0    # "pref":Landroid/content/SharedPreferences;
    .end local v1    # "chords":[Lnet/duceng/xmidi/util/Chords$Chord;
    .end local v3    # "saved":Ljava/lang/String;
    .end local v4    # "parts":[Ljava/lang/String;
    throw v8
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 468
    .end local v6    # "i":I
    .end local v7    # "id":I
    .restart local v0    # "pref":Landroid/content/SharedPreferences;
    .restart local v1    # "chords":[Lnet/duceng/xmidi/util/Chords$Chord;
    .restart local v3    # "saved":Ljava/lang/String;
    .restart local v4    # "parts":[Ljava/lang/String;
    :cond_1
    move-object v1, v5

    .line 471
    .end local v5    # "restored":[Lnet/duceng/xmidi/util/Chords$Chord;
    goto :goto_1

    .line 469
    :catch_0
    move-exception v5

    .line 470
    .local v5, "e":Ljava/lang/RuntimeException;
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->gChords:Lnet/duceng/xmidi/util/Chords;

    iget v7, p0, Lnet/duceng/xmidi/Drums;->tonalityIndex:I

    invoke-virtual {v6, v7}, Lnet/duceng/xmidi/util/Chords;->getGChords16(I)[Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v1

    .line 474
    .end local v4    # "parts":[Ljava/lang/String;
    .end local v5    # "e":Ljava/lang/RuntimeException;
    :cond_2
    :goto_1
    const/4 v4, 0x0

    .local v4, "i2":I
    :goto_2
    array-length v5, v1

    if-ge v4, v5, :cond_3

    iget-object v5, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    array-length v5, v5

    if-ge v4, v5, :cond_3

    .line 475
    iget-object v5, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    aget-object v5, v5, v4

    aget-object v6, v1, v4

    iget-object v6, v6, Lnet/duceng/xmidi/util/Chords$Chord;->name:Ljava/lang/String;

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 476
    iget-object v5, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    aget-object v5, v5, v4

    aget-object v6, v1, v4

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 474
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    .line 478
    .end local v4    # "i2":I
    :cond_3
    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->btnTonality:Landroid/widget/Button;

    iget-object v5, p0, Lnet/duceng/xmidi/Drums;->gChords:Lnet/duceng/xmidi/util/Chords;

    iget v6, p0, Lnet/duceng/xmidi/Drums;->tonalityIndex:I

    invoke-virtual {v5, v6}, Lnet/duceng/xmidi/util/Chords;->getGChords16(I)[Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v5

    aget-object v2, v5, v2

    iget-object v2, v2, Lnet/duceng/xmidi/util/Chords$Chord;->name:Ljava/lang/String;

    invoke-virtual {v4, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 479
    return-void
.end method

.method private saveChords()V
    .locals 4

    .line 436
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 437
    .local v0, "sb":Ljava/lang/StringBuilder;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    array-length v2, v2

    if-ge v1, v2, :cond_2

    .line 438
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    aget-object v2, v2, v1

    invoke-virtual {v2}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/xmidi/util/Chords$Chord;

    .line 439
    .local v2, "c":Lnet/duceng/xmidi/util/Chords$Chord;
    if-nez v2, :cond_0

    .line 440
    return-void

    .line 442
    :cond_0
    if-lez v1, :cond_1

    .line 443
    const/16 v3, 0x2c

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 445
    :cond_1
    iget v3, v2, Lnet/duceng/xmidi/util/Chords$Chord;->id:I

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 437
    .end local v2    # "c":Lnet/duceng/xmidi/util/Chords$Chord;
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 447
    .end local v1    # "i":I
    :cond_2
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "drums_chords"

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "drums_tonality"

    iget v3, p0, Lnet/duceng/xmidi/Drums;->tonalityIndex:I

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 448
    return-void
.end method

.method private setupKeyboard()V
    .locals 2

    .line 482
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->piano:Lnet/duceng/xmidi/widgets/PianoBoard;

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->keyListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/PianoBoard;->setPianoBoardListener(Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;)V

    .line 483
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->piano:Lnet/duceng/xmidi/widgets/PianoBoard;

    const/16 v1, 0xe

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/PianoBoard;->setVisibleWhiteKeys(I)V

    .line 484
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->piano:Lnet/duceng/xmidi/widgets/PianoBoard;

    const/16 v1, 0x3c

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/PianoBoard;->setScroll(I)V

    .line 485
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->updateKeyboardUi()V

    .line 486
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->applyKeysVisibility()V

    .line 487
    return-void
.end method

.method private updateBeatIcon()V
    .locals 3

    .line 539
    const v0, 0x7f040002

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    .line 540
    .local v0, "ib":Landroid/widget/ImageButton;
    if-eqz v0, :cond_0

    .line 541
    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iget-boolean v2, p0, Lnet/duceng/xmidi/Drums;->metroOn:Z

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 543
    :cond_0
    return-void
.end method

.method private updateKeyboardUi()V
    .locals 3

    .line 490
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bKeyboard:Landroid/widget/Button;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 491
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bKeyboard:Landroid/widget/Button;

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Drums;->getPresetName(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 493
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->getSustain(I)I

    move-result v0

    const/16 v2, 0x40

    if-lt v0, v2, :cond_1

    const/4 v1, 0x1

    :cond_1
    iput-boolean v1, p0, Lnet/duceng/xmidi/Drums;->sustainOn:Z

    .line 494
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bSustain:Landroid/widget/Button;

    if-eqz v0, :cond_3

    .line 495
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->sustainOn:Z

    if-eqz v0, :cond_2

    .line 496
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bSustain:Landroid/widget/Button;

    const v1, 0x7f020007

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setBackgroundResource(I)V

    goto :goto_0

    .line 497
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->sustainBg:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_3

    .line 498
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bSustain:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->sustainBg:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 501
    :cond_3
    :goto_0
    return-void
.end method


# virtual methods
.method public chordSelect(Landroid/widget/Button;)V
    .locals 3
    .param p1, "b"    # Landroid/widget/Button;

    .line 798
    invoke-virtual {p1}, Landroid/widget/Button;->isSelected()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 799
    invoke-virtual {p1, v1}, Landroid/widget/Button;->setSelected(Z)V

    .line 800
    const/4 v0, 0x0

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    goto :goto_1

    .line 802
    :cond_0
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    array-length v2, v2

    if-ge v0, v2, :cond_1

    .line 803
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    aget-object v2, v2, v0

    invoke-virtual {v2, v1}, Landroid/widget/Button;->setSelected(Z)V

    .line 802
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 805
    .end local v0    # "i":I
    :cond_1
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setSelected(Z)V

    .line 806
    invoke-virtual {p1}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/Chords$Chord;

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    .line 808
    :goto_1
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    if-eqz v0, :cond_2

    .line 809
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->setChord(Lnet/duceng/xmidi/util/Chords$Chord;)V

    .line 811
    :cond_2
    return-void
.end method

.method public loadStyFile(Ljava/io/File;)V
    .locals 10
    .param p1, "f"    # Ljava/io/File;

    .line 615
    :try_start_0
    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 618
    .local v0, "in":Ljava/io/FileInputStream;
    :try_start_1
    new-instance v1, Lnet/duceng/midi/StyFile;

    invoke-direct {v1, v0}, Lnet/duceng/midi/StyFile;-><init>(Ljava/io/InputStream;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 620
    .local v1, "sf":Lnet/duceng/midi/StyFile;
    :try_start_2
    invoke-virtual {v0}, Ljava/io/FileInputStream;->close()V

    .line 621
    nop

    .line 622
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    if-eqz v2, :cond_0

    .line 623
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-virtual {v2}, Lnet/duceng/xmidi/util/StyleEngine;->stop()V

    .line 625
    :cond_0
    iput-object v1, p0, Lnet/duceng/xmidi/Drums;->styFile:Lnet/duceng/midi/StyFile;

    .line 626
    const/4 v2, 0x0

    iput-object v2, p0, Lnet/duceng/xmidi/Drums;->stySection:Lnet/duceng/midi/StySection;

    .line 627
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "drums_sty_path"

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 628
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->btnFile:Landroid/widget/Button;

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 629
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v3}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v3

    invoke-virtual {v3}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v3

    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->styFile:Lnet/duceng/midi/StyFile;

    invoke-virtual {v4}, Lnet/duceng/midi/StyFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v4

    invoke-virtual {v4}, Lnet/duceng/midi/MetaTempo;->getMpqn()I

    move-result v4

    invoke-virtual {v3, v4}, Lnet/duceng/midi/MetaTempo;->setMpqn(I)V

    .line 630
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->applyStyleSetup()V

    .line 631
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    array-length v4, v4

    const/16 v5, 0x8

    if-ge v3, v4, :cond_1

    .line 632
    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    aget-object v4, v4, v3

    move-object v6, v2

    check-cast v6, Ljava/lang/CharSequence;

    invoke-virtual {v4, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 633
    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    aget-object v4, v4, v3

    invoke-virtual {v4, v2}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 634
    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    aget-object v4, v4, v3

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 631
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 636
    .end local v3    # "i":I
    :cond_1
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->styFile:Lnet/duceng/midi/StyFile;

    invoke-virtual {v2}, Lnet/duceng/midi/StyFile;->getSections()Ljava/util/Map;

    move-result-object v2

    .line 637
    .local v2, "sections":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Lnet/duceng/midi/StySection;>;"
    const/4 v3, 0x0

    .line 638
    .local v3, "idx":I
    invoke-interface {v2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v7, 0x0

    if-eqz v6, :cond_3

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .line 639
    .local v6, "key":Ljava/lang/String;
    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    array-length v8, v8

    if-lt v3, v8, :cond_2

    .line 640
    goto :goto_2

    .line 642
    :cond_2
    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    aget-object v8, v8, v3

    invoke-interface {v2, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/midi/StySection;

    invoke-virtual {v9}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 643
    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    aget-object v8, v8, v3

    invoke-interface {v2, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 644
    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    aget-object v8, v8, v3

    invoke-virtual {v8, v7}, Landroid/widget/Button;->setVisibility(I)V

    .line 645
    nop

    .end local v6    # "key":Ljava/lang/String;
    add-int/lit8 v3, v3, 0x1

    .line 646
    goto :goto_1

    .line 647
    :cond_3
    :goto_2
    const/4 v4, 0x0

    .local v4, "i2":I
    :goto_3
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    array-length v6, v6

    if-ge v4, v6, :cond_5

    .line 648
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    aget-object v6, v6, v4

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v6

    if-eqz v6, :cond_4

    .line 649
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    aget-object v6, v6, v4

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setVisibility(I)V

    goto :goto_4

    .line 651
    :cond_4
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    aget-object v6, v6, v4

    invoke-virtual {v6, v5}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 647
    :goto_4
    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    .line 654
    .end local v4    # "i2":I
    :cond_5
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->buildEngine()V

    .line 657
    .end local v0    # "in":Ljava/io/FileInputStream;
    .end local v1    # "sf":Lnet/duceng/midi/StyFile;
    .end local v2    # "sections":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Lnet/duceng/midi/StySection;>;"
    .end local v3    # "idx":I
    goto :goto_5

    .line 620
    .restart local v0    # "in":Ljava/io/FileInputStream;
    :catchall_0
    move-exception v1

    invoke-virtual {v0}, Ljava/io/FileInputStream;->close()V

    .line 621
    nop

    .end local p1    # "f":Ljava/io/File;
    throw v1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 655
    .end local v0    # "in":Ljava/io/FileInputStream;
    .restart local p1    # "f":Ljava/io/File;
    :catch_0
    move-exception v0

    .line 656
    .local v0, "e1":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 658
    .end local v0    # "e1":Ljava/lang/Exception;
    :goto_5
    return-void
.end method

.method protected onActionClick(Landroid/view/View;)V
    .locals 9
    .param p1, "v"    # Landroid/view/View;

    .line 838
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    sparse-switch v0, :sswitch_data_0

    goto/16 :goto_a

    .line 874
    :sswitch_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    if-nez v0, :cond_0

    .line 875
    new-instance v0, Lnet/duceng/xmidi/ui/DialogChannel;

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, p0, v1}, Lnet/duceng/xmidi/ui/DialogChannel;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    .line 876
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    new-instance v1, Lnet/duceng/xmidi/Drums$18;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Drums$18;-><init>(Lnet/duceng/xmidi/Drums;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogChannel;->setOnSelectListener(Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;)V

    .line 885
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogChannel;->show()V

    .line 886
    return-void

    .line 854
    :sswitch_1
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->sustainOn:Z

    xor-int/2addr v0, v2

    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->sustainOn:Z

    .line 855
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    iget-boolean v2, p0, Lnet/duceng/xmidi/Drums;->sustainOn:Z

    if-eqz v2, :cond_1

    const/16 v2, 0x7f

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->setSustain(II)V

    .line 856
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->sustainOn:Z

    if-nez v0, :cond_2

    .line 857
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->keysOff(I)V

    .line 859
    :cond_2
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->updateKeyboardUi()V

    .line 860
    return-void

    .line 862
    :sswitch_2
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->piano:Lnet/duceng/xmidi/widgets/PianoBoard;

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->piano:Lnet/duceng/xmidi/widgets/PianoBoard;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/PianoBoard;->isLocked()Z

    move-result v1

    xor-int/2addr v1, v2

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/PianoBoard;->setLocked(Z)V

    .line 863
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bLock:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->piano:Lnet/duceng/xmidi/widgets/PianoBoard;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/PianoBoard;->isLocked()Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 864
    return-void

    .line 840
    :sswitch_3
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->keyboardPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    if-nez v0, :cond_3

    .line 841
    new-instance v0, Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, p0, v3}, Lnet/duceng/xmidi/ui/DialogPreset;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->keyboardPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    .line 842
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->keyboardPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-virtual {v0, v2}, Lnet/duceng/xmidi/ui/DialogPreset;->setAbsoluteVolume(Z)V

    .line 843
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->keyboardPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    new-instance v2, Lnet/duceng/xmidi/Drums$17;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/Drums$17;-><init>(Lnet/duceng/xmidi/Drums;)V

    invoke-virtual {v0, v2}, Lnet/duceng/xmidi/ui/DialogPreset;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 850
    :cond_3
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->keyboardPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogPreset;->setChannel(I)V

    .line 851
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->keyboardPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogPreset;->show()V

    .line 852
    return-void

    .line 888
    :sswitch_4
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->auto:Z

    xor-int/2addr v0, v2

    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->auto:Z

    .line 889
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->applyKeysVisibility()V

    .line 890
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->auto:Z

    const/16 v3, 0x8

    if-eqz v0, :cond_8

    .line 891
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bAuto:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 892
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutTop:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 893
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->divh:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 894
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->divv:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 895
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_1
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    array-length v2, v2

    if-ge v0, v2, :cond_4

    .line 896
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 895
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 898
    .end local v0    # "i":I
    :cond_4
    const/4 v0, 0x0

    .line 899
    .local v0, "idx":I
    const/4 v2, 0x0

    .local v2, "i2":I
    :goto_2
    const/4 v4, 0x2

    if-ge v2, v4, :cond_5

    .line 900
    add-int/lit8 v4, v0, 0x1

    .line 901
    .local v4, "idx2":I
    iget-object v5, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v5, v5, v2

    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v6, v6, v0

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 902
    add-int/lit8 v5, v4, 0x1

    .line 903
    .local v5, "idx3":I
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v6, v6, v2

    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v7, v7, v4

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 904
    add-int/lit8 v6, v5, 0x1

    .line 905
    .local v6, "idx4":I
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v7, v7, v2

    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v8, v8, v5

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 906
    add-int/lit8 v0, v6, 0x1

    .line 907
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v7, v7, v2

    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v8, v8, v6

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 908
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v7, v7, v2

    invoke-virtual {v7, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 899
    .end local v4    # "idx2":I
    .end local v5    # "idx3":I
    .end local v6    # "idx4":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    .line 910
    .end local v2    # "i2":I
    :cond_5
    const/4 v1, 0x2

    .local v1, "i3":I
    :goto_3
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    array-length v2, v2

    if-ge v1, v2, :cond_6

    .line 911
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v2, v2, v1

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 910
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    .line 913
    .end local v1    # "i3":I
    :cond_6
    const/4 v1, 0x0

    .local v1, "i4":I
    :goto_4
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->notes8:[I

    array-length v2, v2

    if-ge v1, v2, :cond_7

    .line 914
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v2, v2, v1

    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->percussions:[Ljava/lang/String;

    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->notes8:[I

    aget v4, v4, v1

    aget-object v3, v3, v4

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 915
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v2, v2, v1

    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->notes8:[I

    aget v3, v3, v1

    sget-byte v4, Lnet/duceng/xmidi/Drums;->NOTE_BASE:B

    add-int/2addr v3, v4

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 913
    add-int/lit8 v1, v1, 0x1

    goto :goto_4

    .line 917
    .end local v1    # "i4":I
    :cond_7
    return-void

    .line 919
    .end local v0    # "idx":I
    :cond_8
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bAuto:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 920
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutTop:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 921
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->divh:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 922
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->divv:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 923
    const/4 v0, 0x0

    .local v0, "i5":I
    :goto_5
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    array-length v3, v3

    if-ge v0, v3, :cond_9

    .line 924
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v3, v3, v0

    invoke-virtual {v3}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 923
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    .line 926
    .end local v0    # "i5":I
    :cond_9
    const/4 v0, 0x0

    .line 927
    .local v0, "i6":I
    const/4 v3, 0x0

    .line 928
    .local v3, "idx5":I
    :goto_6
    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    array-length v4, v4

    if-ge v0, v4, :cond_a

    .line 929
    add-int/lit8 v4, v3, 0x1

    .line 930
    .local v4, "idx6":I
    iget-object v5, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v5, v5, v0

    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v6, v6, v3

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 931
    add-int/lit8 v5, v4, 0x1

    .line 932
    .local v5, "idx7":I
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v6, v6, v0

    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v7, v7, v4

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 933
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v6, v6, v0

    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v7, v7, v5

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 934
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v6, v6, v0

    invoke-virtual {v6, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 935
    add-int/lit8 v0, v0, 0x1

    .line 936
    add-int/lit8 v3, v5, 0x1

    .line 937
    .end local v4    # "idx6":I
    .end local v5    # "idx7":I
    goto :goto_6

    .line 938
    :cond_a
    const/4 v1, 0x0

    .local v1, "i7":I
    :goto_7
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->notes15:[I

    array-length v2, v2

    if-ge v1, v2, :cond_b

    .line 939
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v2, v2, v1

    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->percussions:[Ljava/lang/String;

    iget-object v5, p0, Lnet/duceng/xmidi/Drums;->notes15:[I

    aget v5, v5, v1

    aget-object v4, v4, v5

    invoke-virtual {v2, v4}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 940
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v2, v2, v1

    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->notes15:[I

    aget v4, v4, v1

    sget-byte v5, Lnet/duceng/xmidi/Drums;->NOTE_BASE:B

    add-int/2addr v4, v5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 938
    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    .line 942
    .end local v1    # "i7":I
    :cond_b
    return-void

    .line 944
    .end local v0    # "i6":I
    .end local v3    # "idx5":I
    :sswitch_5
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_c

    .line 945
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnFile:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setEnabled(Z)V

    .line 946
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnTonality:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setEnabled(Z)V

    .line 947
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnPlay:Landroid/widget/ImageButton;

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setEnabled(Z)V

    goto :goto_8

    .line 949
    :cond_c
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnFile:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 950
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnTonality:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 951
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnPlay:Landroid/widget/ImageButton;

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setEnabled(Z)V

    .line 953
    :goto_8
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->auto:Z

    if-eqz v0, :cond_e

    .line 954
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->stySection:Lnet/duceng/midi/StySection;

    if-nez v0, :cond_e

    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->styFile:Lnet/duceng/midi/StyFile;

    if-eqz v0, :cond_e

    .line 955
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->styFile:Lnet/duceng/midi/StyFile;

    const-string v2, "Intro A"

    invoke-virtual {v0, v2}, Lnet/duceng/midi/StyFile;->containsSection(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_9

    :cond_d
    const-string v2, "Main A"

    :goto_9
    move-object v0, v2

    .line 956
    .local v0, "mark":Ljava/lang/String;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Drums;->sectionSelect(Ljava/lang/String;)V

    goto :goto_a

    .line 866
    .end local v0    # "mark":Ljava/lang/String;
    :sswitch_6
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    if-eqz v0, :cond_e

    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/StyleEngine;->isRunning()Z

    move-result v0

    if-eqz v0, :cond_e

    .line 867
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->metroOn:Z

    xor-int/2addr v0, v2

    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->metroOn:Z

    .line 868
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->applyMetronome()V

    .line 869
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->updateBeatIcon()V

    .line 870
    return-void

    .line 961
    :cond_e
    :goto_a
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onActionClick(Landroid/view/View;)V

    .line 962
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const v2, 0x7f040002

    if-ne v0, v2, :cond_f

    .line 963
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->isBeating()Z

    move-result v0

    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->metroOn:Z

    .line 965
    :cond_f
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const v2, 0x7f040008

    if-ne v0, v2, :cond_10

    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->isPlaying()Z

    move-result v0

    if-nez v0, :cond_10

    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->startedBySynth:Z

    if-eqz v0, :cond_10

    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    if-eqz v0, :cond_10

    .line 966
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/StyleEngine;->stop()V

    .line 967
    iput-boolean v1, p0, Lnet/duceng/xmidi/Drums;->startedBySynth:Z

    .line 969
    :cond_10
    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0x7f040002 -> :sswitch_6
        0x7f040008 -> :sswitch_5
        0x7f04001b -> :sswitch_4
        0x7f04003f -> :sswitch_3
        0x7f040054 -> :sswitch_2
        0x7f04006c -> :sswitch_1
        0x7f0400c1 -> :sswitch_0
    .end sparse-switch
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 7
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .line 547
    invoke-super {p0, p1, p2, p3}, Lnet/duceng/xmidi/BaseApp;->onActivityResult(IILandroid/content/Intent;)V

    .line 548
    const/16 v0, 0x1005

    if-ne p1, v0, :cond_1

    const/4 v0, -0x1

    if-ne p2, v0, :cond_1

    if-eqz p3, :cond_1

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 551
    :cond_0
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v2

    new-instance v3, Ljava/io/File;

    sget-object v0, Lnet/duceng/xsynth/Synth;->PATH_STY:Ljava/lang/String;

    invoke-direct {v3, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const-string v0, "sty"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v4

    new-instance v6, Lnet/duceng/xmidi/Drums$12;

    invoke-direct {v6, p0}, Lnet/duceng/xmidi/Drums$12;-><init>(Lnet/duceng/xmidi/Drums;)V

    const-string v5, "sty"

    move-object v1, p0

    invoke-static/range {v1 .. v6}, Lnet/duceng/xmidi/util/Importer;->importAsync(Landroid/app/Activity;Landroid/net/Uri;Ljava/io/File;[Ljava/lang/String;Ljava/lang/String;Lnet/duceng/xmidi/util/Importer$Callback;)V

    .line 562
    return-void

    .line 549
    :cond_1
    :goto_0
    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 4
    .param p1, "newConfig"    # Landroid/content/res/Configuration;

    .line 596
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 599
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->layoutManual:Landroid/widget/LinearLayout;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 600
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    array-length v1, v1

    const/4 v2, -0x1

    const/4 v3, 0x0

    if-ge v0, v1, :cond_0

    .line 601
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v1, v1, v0

    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 602
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    iput v3, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 603
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 600
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 605
    .end local v0    # "i":I
    :cond_0
    const/4 v0, 0x0

    .local v0, "i2":I
    :goto_1
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    array-length v1, v1

    if-ge v0, v1, :cond_1

    .line 606
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 607
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    iput v3, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 605
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 609
    .end local v0    # "i2":I
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->divv:Landroid/view/View;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 610
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 11
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 208
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onCreate(Landroid/os/Bundle;)V

    .line 209
    const v0, 0x7f050010

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Drums;->setContentView(I)V

    .line 210
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setStyleMix(Z)V

    .line 211
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->title:Landroid/widget/Button;

    const v2, 0x7f06000c

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setText(I)V

    .line 212
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->title:Landroid/widget/Button;

    iput-object v0, p0, Lnet/duceng/xmidi/Drums;->bPreset:Landroid/widget/Button;

    .line 213
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->title:Landroid/widget/Button;

    new-instance v2, Lnet/duceng/xmidi/Drums$7;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/Drums$7;-><init>(Lnet/duceng/xmidi/Drums;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 230
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_1

    .line 231
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getId()I

    move-result v2

    const v3, 0x7f040003

    if-ne v2, v3, :cond_0

    .line 232
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    const v3, 0x7f020007

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setBackgroundResource(I)V

    .line 233
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    .line 234
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->listMore:Ljava/util/ArrayList;

    add-int/lit8 v4, v0, 0x1

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    .line 235
    goto :goto_1

    .line 230
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 238
    .end local v0    # "i":I
    :cond_1
    :goto_1
    invoke-virtual {p0}, Lnet/duceng/xmidi/Drums;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v2, 0x0

    move-object v3, v2

    check-cast v3, Landroid/view/ViewGroup;

    const v3, 0x7f050003

    invoke-virtual {v0, v3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    .line 239
    .local v0, "layout":Landroid/widget/LinearLayout;
    :goto_2
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v3

    const/4 v4, 0x0

    if-lez v3, :cond_6

    .line 240
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    .line 241
    .local v3, "child":Landroid/view/View;
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->removeView(Landroid/view/View;)V

    .line 242
    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 243
    iget-object v4, p0, Lnet/duceng/xmidi/Drums;->actionClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v3, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 244
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    move-result v4

    const v5, 0x7f04003f

    if-ne v4, v5, :cond_2

    .line 245
    move-object v4, v3

    check-cast v4, Landroid/widget/Button;

    iput-object v4, p0, Lnet/duceng/xmidi/Drums;->bKeyboard:Landroid/widget/Button;

    goto :goto_3

    .line 246
    :cond_2
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    move-result v4

    const v5, 0x7f04006c

    if-ne v4, v5, :cond_3

    .line 247
    move-object v4, v3

    check-cast v4, Landroid/widget/Button;

    iput-object v4, p0, Lnet/duceng/xmidi/Drums;->bSustain:Landroid/widget/Button;

    .line 248
    invoke-virtual {v3}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    if-eqz v4, :cond_5

    invoke-virtual {v3}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v4

    if-eqz v4, :cond_5

    .line 249
    invoke-virtual {v3}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v4

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    iput-object v4, p0, Lnet/duceng/xmidi/Drums;->sustainBg:Landroid/graphics/drawable/Drawable;

    goto :goto_3

    .line 251
    :cond_3
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    move-result v4

    const v5, 0x7f040054

    if-ne v4, v5, :cond_4

    .line 252
    move-object v4, v3

    check-cast v4, Landroid/widget/ImageButton;

    iput-object v4, p0, Lnet/duceng/xmidi/Drums;->bLock:Landroid/widget/ImageButton;

    goto :goto_3

    .line 253
    :cond_4
    invoke-virtual {v3}, Landroid/view/View;->getId()I

    move-result v4

    const v5, 0x7f04001b

    if-ne v4, v5, :cond_5

    .line 254
    move-object v4, v3

    check-cast v4, Landroid/widget/ImageButton;

    iput-object v4, p0, Lnet/duceng/xmidi/Drums;->bAuto:Landroid/widget/ImageButton;

    .line 256
    .end local v3    # "child":Landroid/view/View;
    :cond_5
    :goto_3
    goto :goto_2

    .line 257
    :cond_6
    new-instance v3, Landroid/os/Handler;

    invoke-direct {v3}, Landroid/os/Handler;-><init>()V

    iput-object v3, p0, Lnet/duceng/xmidi/Drums;->handler:Landroid/os/Handler;

    .line 258
    const v3, 0x7f040040

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    iput-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutDrums:Landroid/widget/LinearLayout;

    .line 259
    const v3, 0x7f040041

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    iput-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutAuto:Landroid/widget/LinearLayout;

    .line 260
    const v3, 0x7f040053

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    iput-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutTop:Landroid/widget/LinearLayout;

    .line 261
    const v3, 0x7f04004d

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    iput-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutManual:Landroid/widget/LinearLayout;

    .line 262
    const v3, 0x7f04004c

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    iput-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutKeys:Landroid/widget/LinearLayout;

    .line 263
    const v3, 0x7f040055

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/PianoBoard;

    iput-object v3, p0, Lnet/duceng/xmidi/Drums;->piano:Lnet/duceng/xmidi/widgets/PianoBoard;

    .line 264
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    const v5, 0x7f04004e

    invoke-virtual {p0, v5}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    aput-object v5, v3, v4

    .line 265
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    const v5, 0x7f04004f

    invoke-virtual {p0, v5}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    aput-object v5, v3, v1

    .line 266
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    const v5, 0x7f040050

    invoke-virtual {p0, v5}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    const/4 v6, 0x2

    aput-object v5, v3, v6

    .line 267
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    const v5, 0x7f040051

    invoke-virtual {p0, v5}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    const/4 v7, 0x3

    aput-object v5, v3, v7

    .line 268
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    const v5, 0x7f040052

    invoke-virtual {p0, v5}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    const/4 v8, 0x4

    aput-object v5, v3, v8

    .line 269
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    const v5, 0x7f040042

    invoke-virtual {p0, v5}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    aput-object v5, v3, v4

    .line 270
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    const v5, 0x7f040043

    invoke-virtual {p0, v5}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    aput-object v5, v3, v1

    .line 271
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    const v5, 0x7f040044

    invoke-virtual {p0, v5}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    aput-object v5, v3, v6

    .line 272
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    const v5, 0x7f040045

    invoke-virtual {p0, v5}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    aput-object v5, v3, v7

    .line 273
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    const v5, 0x7f040046

    invoke-virtual {p0, v5}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    aput-object v5, v3, v8

    .line 274
    const v3, 0x7f040047

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    const v5, 0x7f040048

    invoke-virtual {p0, v5}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    const v9, 0x7f040049

    invoke-virtual {p0, v9}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v9

    check-cast v9, Landroid/widget/LinearLayout;

    const v10, 0x7f04004a

    invoke-virtual {p0, v10}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    new-array v8, v8, [Landroid/widget/LinearLayout;

    aput-object v3, v8, v4

    aput-object v5, v8, v1

    aput-object v9, v8, v6

    aput-object v10, v8, v7

    move-object v1, v8

    .line 275
    .local v1, "layoutChords":[Landroid/widget/LinearLayout;
    const v3, 0x7f04006b

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    iput-object v3, p0, Lnet/duceng/xmidi/Drums;->btnFile:Landroid/widget/Button;

    .line 276
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->btnFile:Landroid/widget/Button;

    new-instance v4, Lnet/duceng/xmidi/Drums$8;

    invoke-direct {v4, p0}, Lnet/duceng/xmidi/Drums$8;-><init>(Lnet/duceng/xmidi/Drums;)V

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 303
    const v3, 0x7f040056

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageButton;

    iput-object v3, p0, Lnet/duceng/xmidi/Drums;->btnPlay:Landroid/widget/ImageButton;

    .line 304
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->btnPlay:Landroid/widget/ImageButton;

    new-instance v4, Lnet/duceng/xmidi/Drums$9;

    invoke-direct {v4, p0}, Lnet/duceng/xmidi/Drums$9;-><init>(Lnet/duceng/xmidi/Drums;)V

    invoke-virtual {v3, v4}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 314
    const v3, 0x7f04006d

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    iput-object v3, p0, Lnet/duceng/xmidi/Drums;->btnTonality:Landroid/widget/Button;

    .line 315
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->btnTonality:Landroid/widget/Button;

    new-instance v4, Lnet/duceng/xmidi/Drums$10;

    invoke-direct {v4, p0}, Lnet/duceng/xmidi/Drums$10;-><init>(Lnet/duceng/xmidi/Drums;)V

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 347
    const/4 v3, 0x0

    .line 348
    .local v3, "idx":I
    const/4 v4, 0x0

    .local v4, "i2":I
    :goto_4
    iget-object v5, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    array-length v5, v5

    if-ge v4, v5, :cond_8

    .line 349
    const/4 v5, 0x0

    .line 350
    .local v5, "k":I
    :goto_5
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    aget-object v6, v6, v4

    invoke-virtual {v6}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v6

    if-ge v5, v6, :cond_7

    .line 351
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->layoutStys:[Landroid/widget/LinearLayout;

    aget-object v7, v7, v4

    invoke-virtual {v7, v5}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/Button;

    aput-object v7, v6, v3

    .line 352
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    aget-object v6, v6, v3

    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->sectionTouchListener:Landroid/view/View$OnTouchListener;

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 353
    add-int/lit8 v5, v5, 0x1

    .line 354
    add-int/lit8 v3, v3, 0x1

    goto :goto_5

    .line 348
    .end local v5    # "k":I
    :cond_7
    add-int/lit8 v4, v4, 0x1

    goto :goto_4

    .line 357
    .end local v4    # "i2":I
    :cond_8
    const/4 v4, 0x0

    .line 358
    .local v4, "idx2":I
    const/4 v5, 0x0

    .local v5, "i3":I
    :goto_6
    array-length v6, v1

    if-ge v5, v6, :cond_a

    .line 359
    const/4 v6, 0x0

    .line 360
    .local v6, "k2":I
    :goto_7
    aget-object v7, v1, v5

    invoke-virtual {v7}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v7

    if-ge v6, v7, :cond_9

    .line 361
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    aget-object v8, v1, v5

    invoke-virtual {v8, v6}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v8

    check-cast v8, Landroid/widget/Button;

    aput-object v8, v7, v4

    .line 362
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    aget-object v7, v7, v4

    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->chordTouchListener:Landroid/view/View$OnTouchListener;

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 363
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->btnChords:[Landroid/widget/Button;

    aget-object v7, v7, v4

    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->chordLongClickListener:Landroid/view/View$OnLongClickListener;

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 364
    add-int/lit8 v6, v6, 0x1

    .line 365
    add-int/lit8 v4, v4, 0x1

    goto :goto_7

    .line 358
    .end local v6    # "k2":I
    :cond_9
    add-int/lit8 v5, v5, 0x1

    goto :goto_6

    .line 368
    .end local v5    # "i3":I
    :cond_a
    const/4 v5, 0x0

    .line 369
    .local v5, "idx3":I
    const/4 v6, 0x0

    .local v6, "i4":I
    :goto_8
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    array-length v7, v7

    if-ge v6, v7, :cond_c

    .line 370
    const/4 v7, 0x0

    .line 371
    .local v7, "k3":I
    :goto_9
    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v8, v8, v6

    invoke-virtual {v8}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v8

    if-ge v7, v8, :cond_b

    .line 372
    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    iget-object v9, p0, Lnet/duceng/xmidi/Drums;->layoutBtns:[Landroid/widget/LinearLayout;

    aget-object v9, v9, v6

    invoke-virtual {v9, v7}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v9

    check-cast v9, Landroid/widget/Button;

    aput-object v9, v8, v5

    .line 373
    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v8, v8, v5

    iget-object v9, p0, Lnet/duceng/xmidi/Drums;->drumTouchListener:Landroid/view/View$OnTouchListener;

    invoke-virtual {v8, v9}, Landroid/widget/Button;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 374
    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v8, v8, v5

    iget-object v9, p0, Lnet/duceng/xmidi/Drums;->drumLongClickListener:Landroid/view/View$OnLongClickListener;

    invoke-virtual {v8, v9}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 375
    add-int/lit8 v7, v7, 0x1

    .line 376
    add-int/lit8 v5, v5, 0x1

    goto :goto_9

    .line 369
    .end local v7    # "k3":I
    :cond_b
    add-int/lit8 v6, v6, 0x1

    goto :goto_8

    .line 379
    .end local v6    # "i4":I
    :cond_c
    const v6, 0x7f04002e

    invoke-virtual {p0, v6}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v6

    iput-object v6, p0, Lnet/duceng/xmidi/Drums;->divh:Landroid/view/View;

    .line 380
    const v6, 0x7f04002f

    invoke-virtual {p0, v6}, Lnet/duceng/xmidi/Drums;->findViewById(I)Landroid/view/View;

    move-result-object v6

    iput-object v6, p0, Lnet/duceng/xmidi/Drums;->divv:Landroid/view/View;

    .line 381
    invoke-virtual {p0}, Lnet/duceng/xmidi/Drums;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    const v7, 0x7f010005

    invoke-virtual {v6, v7}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v6

    iput-object v6, p0, Lnet/duceng/xmidi/Drums;->percussions:[Ljava/lang/String;

    .line 383
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v6

    const-string v7, "drums_sty_path"

    invoke-interface {v6, v7, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 384
    .local v2, "savedSty":Ljava/lang/String;
    if-eqz v2, :cond_d

    new-instance v6, Ljava/io/File;

    invoke-direct {v6, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/io/File;->isFile()Z

    move-result v6

    if-eqz v6, :cond_d

    .line 385
    new-instance v6, Ljava/io/File;

    invoke-direct {v6, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v6}, Lnet/duceng/xmidi/Drums;->loadStyFile(Ljava/io/File;)V

    .line 387
    :cond_d
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->styFile:Lnet/duceng/midi/StyFile;

    if-nez v6, :cond_e

    .line 388
    new-instance v6, Ljava/io/File;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v8, Lnet/duceng/xsynth/Synth;->PATH_STY:Ljava/lang/String;

    invoke-static {v8}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "/"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    sget-object v8, Lnet/duceng/xmidi/Drums;->STY_DEFAULT:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v6}, Lnet/duceng/xmidi/Drums;->loadStyFile(Ljava/io/File;)V

    .line 390
    :cond_e
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->restoreChords()V

    .line 391
    iget-boolean v6, p0, Lnet/duceng/xmidi/Drums;->auto:Z

    if-eqz v6, :cond_10

    .line 392
    const/4 v6, 0x0

    .local v6, "i6":I
    :goto_a
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->notes8:[I

    array-length v7, v7

    if-ge v6, v7, :cond_f

    .line 393
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v7, v7, v6

    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->percussions:[Ljava/lang/String;

    iget-object v9, p0, Lnet/duceng/xmidi/Drums;->notes8:[I

    aget v9, v9, v6

    aget-object v8, v8, v9

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 394
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v7, v7, v6

    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->notes8:[I

    aget v8, v8, v6

    sget-byte v9, Lnet/duceng/xmidi/Drums;->NOTE_BASE:B

    add-int/2addr v8, v9

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 392
    add-int/lit8 v6, v6, 0x1

    goto :goto_a

    .end local v6    # "i6":I
    :cond_f
    goto :goto_c

    .line 397
    :cond_10
    const/4 v6, 0x0

    .local v6, "i7":I
    :goto_b
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->notes15:[I

    array-length v7, v7

    if-ge v6, v7, :cond_11

    .line 398
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v7, v7, v6

    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->percussions:[Ljava/lang/String;

    iget-object v9, p0, Lnet/duceng/xmidi/Drums;->notes15:[I

    aget v9, v9, v6

    aget-object v8, v8, v9

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 399
    iget-object v7, p0, Lnet/duceng/xmidi/Drums;->btnDrums:[Landroid/widget/Button;

    aget-object v7, v7, v6

    iget-object v8, p0, Lnet/duceng/xmidi/Drums;->notes15:[I

    aget v8, v8, v6

    sget-byte v9, Lnet/duceng/xmidi/Drums;->NOTE_BASE:B

    add-int/2addr v8, v9

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 397
    add-int/lit8 v6, v6, 0x1

    goto :goto_b

    .line 402
    .end local v6    # "i7":I
    :cond_11
    :goto_c
    iget-object v6, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    new-instance v7, Lnet/duceng/xmidi/Drums$11;

    invoke-direct {v7, p0}, Lnet/duceng/xmidi/Drums$11;-><init>(Lnet/duceng/xmidi/Drums;)V

    invoke-virtual {v6, v7}, Lnet/duceng/xsynth/Synth;->setBeatListener(Lnet/duceng/xsynth/Synth$BeatListener;)V

    .line 422
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->setupKeyboard()V

    .line 423
    return-void
.end method

.method protected onDestroy()V
    .locals 3

    .line 575
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->destroyed:Z

    .line 576
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->playing:Z

    .line 577
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setBeatListener(Lnet/duceng/xsynth/Synth$BeatListener;)V

    .line 578
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    if-eqz v0, :cond_0

    .line 579
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    const-wide/16 v1, 0x1f4

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xmidi/util/StyleEngine;->stopAndWait(J)V

    .line 581
    :cond_0
    invoke-super {p0}, Lnet/duceng/xmidi/BaseApp;->onDestroy()V

    .line 582
    return-void
.end method

.method protected onMidiChanged(Ljava/io/File;)V
    .locals 2
    .param p1, "f"    # Ljava/io/File;

    .line 428
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bPreset:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v1

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Drums;->getPresetName(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 429
    return-void
.end method

.method protected onPause()V
    .locals 2

    .line 566
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->piano:Lnet/duceng/xmidi/widgets/PianoBoard;

    if-eqz v0, :cond_0

    .line 567
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->piano:Lnet/duceng/xmidi/widgets/PianoBoard;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/PianoBoard;->releaseAll()V

    .line 569
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->keysOff(I)V

    .line 570
    invoke-super {p0}, Lnet/duceng/xmidi/BaseApp;->onPause()V

    .line 571
    return-void
.end method

.method protected onStart()V
    .locals 2

    .line 586
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    sget-byte v1, Lnet/duceng/xmidi/Drums;->NOTE_CHAN:B

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setRecordChan(B)V

    .line 587
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setStyleMix(Z)V

    .line 588
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->isBeating()Z

    move-result v0

    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->metroOn:Z

    .line 589
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->bPreset:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v1

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Drums;->getPresetName(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 590
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->updateKeyboardUi()V

    .line 591
    invoke-super {p0}, Lnet/duceng/xmidi/BaseApp;->onStart()V

    .line 592
    return-void
.end method

.method public play()V
    .locals 4

    .line 973
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->styFile:Lnet/duceng/midi/StyFile;

    if-eqz v0, :cond_4

    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    if-eqz v0, :cond_4

    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/StyleEngine;->isRunning()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_2

    .line 976
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnFile:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 977
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnTonality:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 978
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->btnPlay:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x3

    invoke-virtual {v0, v2}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 980
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->stySection:Lnet/duceng/midi/StySection;

    if-eqz v0, :cond_1

    .line 981
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->stySection:Lnet/duceng/midi/StySection;

    invoke-virtual {v0}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v0

    .local v0, "name":Ljava/lang/String;
    goto :goto_1

    .line 983
    .end local v0    # "name":Ljava/lang/String;
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->styFile:Lnet/duceng/midi/StyFile;

    const-string v2, "Intro A"

    invoke-virtual {v0, v2}, Lnet/duceng/midi/StyFile;->containsSection(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    goto :goto_0

    :cond_2
    const-string v2, "Main A"

    :goto_0
    move-object v0, v2

    .line 984
    .restart local v0    # "name":Ljava/lang/String;
    invoke-direct {p0, v0}, Lnet/duceng/xmidi/Drums;->highlight(Ljava/lang/String;)V

    .line 986
    :goto_1
    const/4 v2, 0x1

    iput-boolean v2, p0, Lnet/duceng/xmidi/Drums;->playing:Z

    .line 987
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v3}, Lnet/duceng/xsynth/Synth;->isBeating()Z

    move-result v3

    if-eqz v3, :cond_3

    .line 988
    iget-object v3, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v3, v1}, Lnet/duceng/xsynth/Synth;->setBeating(Z)V

    .line 989
    iput-boolean v2, p0, Lnet/duceng/xmidi/Drums;->metroOn:Z

    .line 991
    :cond_3
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->applyMetronome()V

    .line 992
    invoke-direct {p0}, Lnet/duceng/xmidi/Drums;->updateBeatIcon()V

    .line 993
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/util/StyleEngine;->setChord(Lnet/duceng/xmidi/util/Chords$Chord;)V

    .line 994
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-virtual {v1, v0}, Lnet/duceng/xmidi/util/StyleEngine;->start(Ljava/lang/String;)V

    .line 995
    return-void

    .line 974
    .end local v0    # "name":Ljava/lang/String;
    :cond_4
    :goto_2
    return-void
.end method

.method public sectionSelect(Landroid/widget/Button;)V
    .locals 3
    .param p1, "b"    # Landroid/widget/Button;

    .line 826
    invoke-virtual {p1}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/midi/StySection;

    .line 827
    .local v0, "ss":Lnet/duceng/midi/StySection;
    if-nez v0, :cond_0

    .line 828
    return-void

    .line 830
    :cond_0
    invoke-virtual {v0}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lnet/duceng/xmidi/Drums;->highlight(Ljava/lang/String;)V

    .line 831
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    if-eqz v1, :cond_1

    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-virtual {v1}, Lnet/duceng/xmidi/util/StyleEngine;->isRunning()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 832
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-virtual {v0}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/util/StyleEngine;->requestSection(Ljava/lang/String;)V

    .line 834
    :cond_1
    return-void
.end method

.method public sectionSelect(Ljava/lang/String;)V
    .locals 3
    .param p1, "k"    # Ljava/lang/String;

    .line 815
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    array-length v1, v1

    if-ge v0, v1, :cond_1

    .line 816
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/StySection;

    .line 817
    .local v1, "ss":Lnet/duceng/midi/StySection;
    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 818
    iget-object v2, p0, Lnet/duceng/xmidi/Drums;->btnSections:[Landroid/widget/Button;

    aget-object v2, v2, v0

    invoke-virtual {p0, v2}, Lnet/duceng/xmidi/Drums;->sectionSelect(Landroid/widget/Button;)V

    .line 819
    return-void

    .line 815
    .end local v1    # "ss":Lnet/duceng/midi/StySection;
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 822
    .end local v0    # "i":I
    :cond_1
    return-void
.end method

.method public stop()V
    .locals 3

    .line 999
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->startedBySynth:Z

    .line 1000
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    if-eqz v1, :cond_0

    .line 1001
    iget-object v1, p0, Lnet/duceng/xmidi/Drums;->engine:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-virtual {v1}, Lnet/duceng/xmidi/util/StyleEngine;->stop()V

    .line 1003
    :cond_0
    iput-boolean v0, p0, Lnet/duceng/xmidi/Drums;->playing:Z

    .line 1004
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    const/16 v1, 0x8

    const/16 v2, 0xf

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->silenceChannels(II)V

    .line 1005
    iget-boolean v0, p0, Lnet/duceng/xmidi/Drums;->metroOn:Z

    if-eqz v0, :cond_1

    .line 1006
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->synth:Lnet/duceng/xsynth/Synth;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setBeating(Z)V

    .line 1008
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Drums;->handler:Landroid/os/Handler;

    new-instance v1, Lnet/duceng/xmidi/Drums$19;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Drums$19;-><init>(Lnet/duceng/xmidi/Drums;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1016
    return-void
.end method
