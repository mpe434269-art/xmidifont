.class Lnet/duceng/xmidi/Explorer$1;
.super Ljava/lang/Object;
.source "Explorer.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Explorer;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Explorer;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Explorer;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Explorer;

    .line 51
    iput-object p1, p0, Lnet/duceng/xmidi/Explorer$1;->this$0:Lnet/duceng/xmidi/Explorer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 4
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 54
    .local p1, "arg0":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer$1;->this$0:Lnet/duceng/xmidi/Explorer;

    invoke-static {v0}, Lnet/duceng/xmidi/Explorer;->access$000(Lnet/duceng/xmidi/Explorer;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v0

    invoke-virtual {v0, p3}, Lnet/duceng/xmidi/util/AdapterExplorer;->getItem(I)Ljava/io/File;

    move-result-object v0

    .line 55
    .local v0, "f":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->isDirectory()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->canExecute()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 56
    iget-object v1, p0, Lnet/duceng/xmidi/Explorer$1;->this$0:Lnet/duceng/xmidi/Explorer;

    invoke-static {v1}, Lnet/duceng/xmidi/Explorer;->access$000(Lnet/duceng/xmidi/Explorer;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v1

    invoke-virtual {v1, v0}, Lnet/duceng/xmidi/util/AdapterExplorer;->setCurrentPath(Ljava/io/File;)V

    goto :goto_0

    .line 57
    :cond_0
    invoke-virtual {v0}, Ljava/io/File;->isFile()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Ljava/io/File;->canRead()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 58
    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lnet/duceng/xmidi/Explorer$1;->this$0:Lnet/duceng/xmidi/Explorer;

    const-class v3, Lnet/duceng/xmidi/Keyboard;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 59
    .local v1, "intent":Landroid/content/Intent;
    const-string v2, "file"

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 60
    iget-object v2, p0, Lnet/duceng/xmidi/Explorer$1;->this$0:Lnet/duceng/xmidi/Explorer;

    invoke-virtual {v2, v1}, Lnet/duceng/xmidi/Explorer;->startActivity(Landroid/content/Intent;)V

    .line 62
    .end local v1    # "intent":Landroid/content/Intent;
    :cond_1
    :goto_0
    return-void
.end method
