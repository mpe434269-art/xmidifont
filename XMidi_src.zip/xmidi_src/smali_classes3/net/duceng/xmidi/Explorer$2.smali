.class Lnet/duceng/xmidi/Explorer$2;
.super Ljava/lang/Object;
.source "Explorer.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Explorer;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private df:Lnet/duceng/xmidi/ui/DialogFile;

.field final synthetic this$0:Lnet/duceng/xmidi/Explorer;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Explorer;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Explorer;

    .line 64
    iput-object p1, p0, Lnet/duceng/xmidi/Explorer$2;->this$0:Lnet/duceng/xmidi/Explorer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemLongClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)Z
    .locals 3
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)Z"
        }
    .end annotation

    .line 69
    .local p1, "av":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer$2;->df:Lnet/duceng/xmidi/ui/DialogFile;

    if-nez v0, :cond_0

    .line 70
    new-instance v0, Lnet/duceng/xmidi/ui/DialogFile;

    iget-object v1, p0, Lnet/duceng/xmidi/Explorer$2;->this$0:Lnet/duceng/xmidi/Explorer;

    iget-object v2, p0, Lnet/duceng/xmidi/Explorer$2;->this$0:Lnet/duceng/xmidi/Explorer;

    invoke-static {v2}, Lnet/duceng/xmidi/Explorer;->access$000(Lnet/duceng/xmidi/Explorer;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/ui/DialogFile;-><init>(Landroid/content/Context;Lnet/duceng/xmidi/util/AdapterExplorer;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Explorer$2;->df:Lnet/duceng/xmidi/ui/DialogFile;

    .line 72
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer$2;->df:Lnet/duceng/xmidi/ui/DialogFile;

    iget-object v1, p0, Lnet/duceng/xmidi/Explorer$2;->this$0:Lnet/duceng/xmidi/Explorer;

    invoke-static {v1}, Lnet/duceng/xmidi/Explorer;->access$000(Lnet/duceng/xmidi/Explorer;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v1

    invoke-virtual {v1, p3}, Lnet/duceng/xmidi/util/AdapterExplorer;->getItem(I)Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogFile;->setFile(Ljava/io/File;)V

    .line 73
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer$2;->df:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogFile;->show()V

    .line 74
    const/4 v0, 0x1

    return v0
.end method
