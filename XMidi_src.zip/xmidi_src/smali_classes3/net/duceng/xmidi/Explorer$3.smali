.class Lnet/duceng/xmidi/Explorer$3;
.super Ljava/lang/Object;
.source "Explorer.java"

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Explorer;->startUp()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Explorer;

.field final synthetic val$progress:Landroid/app/ProgressDialog;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Explorer;Landroid/app/ProgressDialog;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Explorer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 122
    iput-object p1, p0, Lnet/duceng/xmidi/Explorer$3;->this$0:Lnet/duceng/xmidi/Explorer;

    iput-object p2, p0, Lnet/duceng/xmidi/Explorer$3;->val$progress:Landroid/app/ProgressDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)Z
    .locals 5
    .param p1, "msg"    # Landroid/os/Message;

    .line 125
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer$3;->this$0:Lnet/duceng/xmidi/Explorer;

    new-instance v1, Lnet/duceng/xmidi/util/AdapterExplorer;

    iget-object v2, p0, Lnet/duceng/xmidi/Explorer$3;->this$0:Lnet/duceng/xmidi/Explorer;

    new-instance v3, Ljava/io/File;

    sget-object v4, Lnet/duceng/xsynth/Synth;->PATH_MIDI:Ljava/lang/String;

    invoke-direct {v3, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {v1, v2, v3}, Lnet/duceng/xmidi/util/AdapterExplorer;-><init>(Landroid/content/Context;Ljava/io/File;)V

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Explorer;->access$002(Lnet/duceng/xmidi/Explorer;Lnet/duceng/xmidi/util/AdapterExplorer;)Lnet/duceng/xmidi/util/AdapterExplorer;

    .line 126
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer$3;->this$0:Lnet/duceng/xmidi/Explorer;

    invoke-static {v0}, Lnet/duceng/xmidi/Explorer;->access$100(Lnet/duceng/xmidi/Explorer;)Landroid/widget/ListView;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Explorer$3;->this$0:Lnet/duceng/xmidi/Explorer;

    invoke-static {v1}, Lnet/duceng/xmidi/Explorer;->access$000(Lnet/duceng/xmidi/Explorer;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 127
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer$3;->val$progress:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->dismiss()V

    .line 128
    const/4 v0, 0x1

    return v0
.end method
