.class Lnet/duceng/xmidi/Explorer$4;
.super Ljava/lang/Object;
.source "Explorer.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Explorer;->startUp()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Explorer;

.field final synthetic val$handler:Landroid/os/Handler;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Explorer;Landroid/os/Handler;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Explorer;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 131
    iput-object p1, p0, Lnet/duceng/xmidi/Explorer$4;->this$0:Lnet/duceng/xmidi/Explorer;

    iput-object p2, p0, Lnet/duceng/xmidi/Explorer$4;->val$handler:Landroid/os/Handler;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 134
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer$4;->this$0:Lnet/duceng/xmidi/Explorer;

    iget-object v0, v0, Lnet/duceng/xmidi/Explorer;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v1, p0, Lnet/duceng/xmidi/Explorer$4;->this$0:Lnet/duceng/xmidi/Explorer;

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->init(Landroid/content/Context;)V

    .line 135
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer$4;->val$handler:Landroid/os/Handler;

    invoke-virtual {v0}, Landroid/os/Handler;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 136
    .local v0, "msg":Landroid/os/Message;
    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    .line 137
    return-void
.end method
