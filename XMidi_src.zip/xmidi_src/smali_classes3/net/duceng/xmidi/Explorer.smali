.class public Lnet/duceng/xmidi/Explorer;
.super Lnet/duceng/xmidi/Base;
.source "Explorer.java"


# instance fields
.field private askedAccess:Z

.field private fileAdapter:Lnet/duceng/xmidi/util/AdapterExplorer;

.field private listv:Landroid/widget/ListView;

.field private startedUp:Z

.field protected synth:Lnet/duceng/xsynth/Synth;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 24
    invoke-direct {p0}, Lnet/duceng/xmidi/Base;-><init>()V

    .line 79
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/Explorer;->startedUp:Z

    .line 80
    iput-boolean v0, p0, Lnet/duceng/xmidi/Explorer;->askedAccess:Z

    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/Explorer;)Lnet/duceng/xmidi/util/AdapterExplorer;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Explorer;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer;->fileAdapter:Lnet/duceng/xmidi/util/AdapterExplorer;

    return-object v0
.end method

.method static synthetic access$002(Lnet/duceng/xmidi/Explorer;Lnet/duceng/xmidi/util/AdapterExplorer;)Lnet/duceng/xmidi/util/AdapterExplorer;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Explorer;
    .param p1, "x1"    # Lnet/duceng/xmidi/util/AdapterExplorer;

    .line 24
    iput-object p1, p0, Lnet/duceng/xmidi/Explorer;->fileAdapter:Lnet/duceng/xmidi/util/AdapterExplorer;

    return-object p1
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/Explorer;)Landroid/widget/ListView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Explorer;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer;->listv:Landroid/widget/ListView;

    return-object v0
.end method

.method private requestStorageAccess()V
    .locals 4

    .line 99
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_0

    .line 101
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "package:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 102
    invoke-virtual {p0}, Lnet/duceng/xmidi/Explorer;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 103
    .local v0, "i":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Explorer;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .end local v0    # "i":Landroid/content/Intent;
    goto :goto_0

    .line 104
    :catch_0
    move-exception v0

    .line 105
    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Explorer;->startActivity(Landroid/content/Intent;)V

    .line 106
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    goto :goto_1

    .line 107
    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-lt v0, v1, :cond_1

    .line 108
    const-string v0, "android.permission.WRITE_EXTERNAL_STORAGE"

    const-string v1, "android.permission.READ_EXTERNAL_STORAGE"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {p0, v0, v1}, Lnet/duceng/xmidi/Explorer;->requestPermissions([Ljava/lang/String;I)V

    .line 110
    :cond_1
    :goto_1
    return-void
.end method

.method private startUp()V
    .locals 5

    .line 113
    invoke-static {p0}, Lnet/duceng/xsynth/Synth;->isInitialized(Landroid/content/Context;)Z

    move-result v0

    .line 114
    .local v0, "synth_init":Z
    if-eqz v0, :cond_0

    .line 115
    iget-object v1, p0, Lnet/duceng/xmidi/Explorer;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1, p0}, Lnet/duceng/xsynth/Synth;->init(Landroid/content/Context;)V

    .line 116
    new-instance v1, Lnet/duceng/xmidi/util/AdapterExplorer;

    new-instance v2, Ljava/io/File;

    sget-object v3, Lnet/duceng/xsynth/Synth;->PATH_MIDI:Ljava/lang/String;

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {v1, p0, v2}, Lnet/duceng/xmidi/util/AdapterExplorer;-><init>(Landroid/content/Context;Ljava/io/File;)V

    iput-object v1, p0, Lnet/duceng/xmidi/Explorer;->fileAdapter:Lnet/duceng/xmidi/util/AdapterExplorer;

    .line 117
    iget-object v1, p0, Lnet/duceng/xmidi/Explorer;->listv:Landroid/widget/ListView;

    iget-object v2, p0, Lnet/duceng/xmidi/Explorer;->fileAdapter:Lnet/duceng/xmidi/util/AdapterExplorer;

    invoke-virtual {v1, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    goto :goto_0

    .line 119
    :cond_0
    new-instance v1, Landroid/app/ProgressDialog;

    invoke-direct {v1, p0}, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V

    .line 120
    .local v1, "progress":Landroid/app/ProgressDialog;
    const v2, 0x7f06001d

    invoke-virtual {p0, v2}, Lnet/duceng/xmidi/Explorer;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V

    .line 121
    invoke-virtual {v1}, Landroid/app/ProgressDialog;->show()V

    .line 122
    new-instance v2, Landroid/os/Handler;

    new-instance v3, Lnet/duceng/xmidi/Explorer$3;

    invoke-direct {v3, p0, v1}, Lnet/duceng/xmidi/Explorer$3;-><init>(Lnet/duceng/xmidi/Explorer;Landroid/app/ProgressDialog;)V

    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Handler$Callback;)V

    .line 131
    .local v2, "handler":Landroid/os/Handler;
    new-instance v3, Ljava/lang/Thread;

    new-instance v4, Lnet/duceng/xmidi/Explorer$4;

    invoke-direct {v4, p0, v2}, Lnet/duceng/xmidi/Explorer$4;-><init>(Lnet/duceng/xmidi/Explorer;Landroid/os/Handler;)V

    invoke-direct {v3, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 139
    .local v3, "t":Ljava/lang/Thread;
    invoke-virtual {v3}, Ljava/lang/Thread;->start()V

    .line 141
    .end local v1    # "progress":Landroid/app/ProgressDialog;
    .end local v2    # "handler":Landroid/os/Handler;
    .end local v3    # "t":Ljava/lang/Thread;
    :goto_0
    return-void
.end method


# virtual methods
.method protected onActionClick(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 167
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    packed-switch v0, :pswitch_data_0

    .line 185
    :pswitch_0
    invoke-super {p0, p1}, Lnet/duceng/xmidi/Base;->onActionClick(Landroid/view/View;)V

    goto :goto_0

    .line 181
    :pswitch_1
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lnet/duceng/xmidi/Metronome;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 182
    .local v0, "intent4":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Explorer;->startActivity(Landroid/content/Intent;)V

    .line 183
    goto :goto_0

    .line 169
    .end local v0    # "intent4":Landroid/content/Intent;
    :pswitch_2
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lnet/duceng/xmidi/Keyboard;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 170
    .local v0, "intent":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Explorer;->startActivity(Landroid/content/Intent;)V

    .line 171
    goto :goto_0

    .line 173
    .end local v0    # "intent":Landroid/content/Intent;
    :pswitch_3
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lnet/duceng/xmidi/Guitar;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 174
    .local v0, "intent2":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Explorer;->startActivity(Landroid/content/Intent;)V

    .line 175
    goto :goto_0

    .line 177
    .end local v0    # "intent2":Landroid/content/Intent;
    :pswitch_4
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lnet/duceng/xmidi/Drums;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 178
    .local v0, "intent3":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Explorer;->startActivity(Landroid/content/Intent;)V

    .line 179
    nop

    .line 188
    .end local v0    # "intent3":Landroid/content/Intent;
    :goto_0
    return-void

    :pswitch_data_0
    .packed-switch 0x7f04006e
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 31
    invoke-super {p0, p1}, Lnet/duceng/xmidi/Base;->onCreate(Landroid/os/Bundle;)V

    .line 32
    invoke-static {p0}, Lnet/duceng/xsynth/Synth;->configurePaths(Landroid/content/Context;)V

    .line 33
    invoke-static {}, Lnet/duceng/xsynth/Synth;->getInstance()Lnet/duceng/xsynth/Synth;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/Explorer;->synth:Lnet/duceng/xsynth/Synth;

    .line 34
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Explorer;->setTop(Z)V

    .line 35
    const v0, 0x7f050011

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Explorer;->setContentView(I)V

    .line 36
    invoke-virtual {p0}, Lnet/duceng/xmidi/Explorer;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050020

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    .line 37
    .local v0, "layout":Landroid/widget/LinearLayout;
    :goto_0
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v2

    const/4 v3, 0x0

    if-lez v2, :cond_0

    .line 38
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    .line 39
    .local v2, "child":Landroid/view/View;
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->removeView(Landroid/view/View;)V

    .line 40
    iget-object v3, p0, Lnet/duceng/xmidi/Explorer;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 41
    iget-object v3, p0, Lnet/duceng/xmidi/Explorer;->menuClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 42
    .end local v2    # "child":Landroid/view/View;
    goto :goto_0

    .line 43
    :cond_0
    invoke-virtual {p0}, Lnet/duceng/xmidi/Explorer;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v2

    const v4, 0x7f050004

    invoke-virtual {v2, v4, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    .line 44
    .local v1, "mainLayout":Landroid/widget/LinearLayout;
    :goto_1
    invoke-virtual {v1}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v2

    if-lez v2, :cond_1

    .line 45
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    .line 46
    .local v2, "child2":Landroid/view/View;
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->removeView(Landroid/view/View;)V

    .line 47
    iget-object v4, p0, Lnet/duceng/xmidi/Explorer;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 48
    iget-object v4, p0, Lnet/duceng/xmidi/Explorer;->actionClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 49
    .end local v2    # "child2":Landroid/view/View;
    goto :goto_1

    .line 50
    :cond_1
    const v2, 0x7f040071

    invoke-virtual {p0, v2}, Lnet/duceng/xmidi/Explorer;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ListView;

    iput-object v2, p0, Lnet/duceng/xmidi/Explorer;->listv:Landroid/widget/ListView;

    .line 51
    iget-object v2, p0, Lnet/duceng/xmidi/Explorer;->listv:Landroid/widget/ListView;

    new-instance v3, Lnet/duceng/xmidi/Explorer$1;

    invoke-direct {v3, p0}, Lnet/duceng/xmidi/Explorer$1;-><init>(Lnet/duceng/xmidi/Explorer;)V

    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 64
    iget-object v2, p0, Lnet/duceng/xmidi/Explorer;->listv:Landroid/widget/ListView;

    new-instance v3, Lnet/duceng/xmidi/Explorer$2;

    invoke-direct {v3, p0}, Lnet/duceng/xmidi/Explorer$2;-><init>(Lnet/duceng/xmidi/Explorer;)V

    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setOnItemLongClickListener(Landroid/widget/AdapterView$OnItemLongClickListener;)V

    .line 77
    return-void
.end method

.method protected onDestroy()V
    .locals 1

    .line 145
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->freeInstance()V

    .line 146
    invoke-super {p0}, Lnet/duceng/xmidi/Base;->onDestroy()V

    .line 147
    return-void
.end method

.method public onPrepareOptionsMenu(Landroid/view/Menu;)Z
    .locals 1
    .param p1, "menu"    # Landroid/view/Menu;

    .line 161
    invoke-virtual {p0}, Lnet/duceng/xmidi/Explorer;->showMenu()V

    .line 162
    const/4 v0, 0x0

    return v0
.end method

.method protected onResume()V
    .locals 2

    .line 84
    invoke-super {p0}, Lnet/duceng/xmidi/Base;->onResume()V

    .line 85
    iget-boolean v0, p0, Lnet/duceng/xmidi/Explorer;->startedUp:Z

    if-eqz v0, :cond_0

    .line 86
    return-void

    .line 88
    :cond_0
    invoke-static {p0}, Lnet/duceng/xsynth/Synth;->configurePaths(Landroid/content/Context;)V

    .line 89
    invoke-static {p0}, Lnet/duceng/xsynth/Synth;->hasSharedStorageAccess(Landroid/content/Context;)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lnet/duceng/xmidi/Explorer;->askedAccess:Z

    if-nez v0, :cond_1

    .line 90
    iput-boolean v1, p0, Lnet/duceng/xmidi/Explorer;->askedAccess:Z

    .line 91
    invoke-direct {p0}, Lnet/duceng/xmidi/Explorer;->requestStorageAccess()V

    .line 92
    return-void

    .line 94
    :cond_1
    iput-boolean v1, p0, Lnet/duceng/xmidi/Explorer;->startedUp:Z

    .line 95
    invoke-direct {p0}, Lnet/duceng/xmidi/Explorer;->startUp()V

    .line 96
    return-void
.end method

.method protected onStart()V
    .locals 2

    .line 151
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getFile()Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 152
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer;->title:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/Explorer;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getFile()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 154
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Explorer;->title:Landroid/widget/Button;

    const v1, 0x7f060002

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(I)V

    .line 156
    :goto_0
    invoke-super {p0}, Lnet/duceng/xmidi/Base;->onStart()V

    .line 157
    return-void
.end method
