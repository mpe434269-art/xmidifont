.class Lnet/duceng/xmidi/Guitar$1;
.super Ljava/lang/Object;
.source "Guitar.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Guitar;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Guitar;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Guitar;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Guitar;

    .line 63
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar$1;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 5
    .param p1, "v"    # Landroid/view/View;
    .param p2, "event"    # Landroid/view/MotionEvent;

    .line 66
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    and-int/lit16 v0, v0, 0xff

    .line 67
    .local v0, "action":I
    const/4 v1, 0x0

    if-nez v0, :cond_1

    .line 68
    move-object v2, p1

    check-cast v2, Landroid/widget/Button;

    .line 69
    .local v2, "b":Landroid/widget/Button;
    invoke-virtual {v2}, Landroid/widget/Button;->isSelected()Z

    move-result v3

    if-nez v3, :cond_0

    .line 70
    iget-object v3, p0, Lnet/duceng/xmidi/Guitar$1;->this$0:Lnet/duceng/xmidi/Guitar;

    move-object v4, p1

    check-cast v4, Landroid/widget/Button;

    invoke-virtual {v3, v4}, Lnet/duceng/xmidi/Guitar;->chordSelect(Landroid/widget/Button;)V

    .line 71
    return v1

    .line 73
    :cond_0
    return v1

    .line 75
    .end local v2    # "b":Landroid/widget/Button;
    :cond_1
    return v1
.end method
