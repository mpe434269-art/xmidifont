.class Lnet/duceng/xmidi/Guitar$10;
.super Ljava/lang/Object;
.source "Guitar.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Guitar;->onActionClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Guitar;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Guitar;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Guitar;

    .line 427
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar$10;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(I)Z
    .locals 4
    .param p1, "id"    # I

    .line 430
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$10;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$200(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/util/Chords;

    move-result-object v0

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/util/Chords;->getGChords(I)[Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v0

    .line 431
    .local v0, "chords":[Lnet/duceng/xmidi/util/Chords$Chord;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    array-length v2, v0

    if-ge v1, v2, :cond_0

    .line 432
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar$10;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v2}, Lnet/duceng/xmidi/Guitar;->access$1300(Lnet/duceng/xmidi/Guitar;)[Landroid/widget/Button;

    move-result-object v2

    aget-object v2, v2, v1

    aget-object v3, v0, v1

    iget-object v3, v3, Lnet/duceng/xmidi/util/Chords$Chord;->name:Ljava/lang/String;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 433
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar$10;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v2}, Lnet/duceng/xmidi/Guitar;->access$1300(Lnet/duceng/xmidi/Guitar;)[Landroid/widget/Button;

    move-result-object v2

    aget-object v2, v2, v1

    aget-object v3, v0, v1

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 431
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 435
    .end local v1    # "i":I
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$10;->this$0:Lnet/duceng/xmidi/Guitar;

    iget-object v2, p0, Lnet/duceng/xmidi/Guitar$10;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v2}, Lnet/duceng/xmidi/Guitar;->access$1300(Lnet/duceng/xmidi/Guitar;)[Landroid/widget/Button;

    move-result-object v2

    const/4 v3, 0x0

    aget-object v2, v2, v3

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/Guitar;->chordSelect(Landroid/widget/Button;)V

    .line 436
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$10;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v1}, Lnet/duceng/xmidi/Guitar;->access$1400(Lnet/duceng/xmidi/Guitar;)Landroid/widget/Button;

    move-result-object v1

    aget-object v2, v0, v3

    iget-object v2, v2, Lnet/duceng/xmidi/util/Chords$Chord;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 437
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$10;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v1}, Lnet/duceng/xmidi/Guitar;->access$1500(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogTonality;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/xmidi/ui/DialogTonality;->dismiss()V

    .line 438
    const/4 v1, 0x1

    return v1
.end method
