.class Lnet/duceng/xmidi/Guitar$2$1;
.super Ljava/lang/Object;
.source "Guitar.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogChord$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Guitar$2;->onLongClick(Landroid/view/View;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/Guitar$2;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Guitar$2;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/Guitar$2;

    .line 85
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar$2$1;->this$1:Lnet/duceng/xmidi/Guitar$2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(I)Z
    .locals 3
    .param p1, "idx"    # I

    .line 88
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$2$1;->this$1:Lnet/duceng/xmidi/Guitar$2;

    iget-object v0, v0, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$200(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/util/Chords;

    move-result-object v0

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/util/Chords;->getChord(I)Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v0

    .line 89
    .local v0, "c":Lnet/duceng/xmidi/util/Chords$Chord;
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$2$1;->this$1:Lnet/duceng/xmidi/Guitar$2;

    iget-object v1, v1, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v1}, Lnet/duceng/xmidi/Guitar;->access$000(Lnet/duceng/xmidi/Guitar;)Landroid/widget/Button;

    move-result-object v1

    iget-object v2, v0, Lnet/duceng/xmidi/util/Chords$Chord;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 90
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$2$1;->this$1:Lnet/duceng/xmidi/Guitar$2;

    iget-object v1, v1, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v1}, Lnet/duceng/xmidi/Guitar;->access$000(Lnet/duceng/xmidi/Guitar;)Landroid/widget/Button;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 91
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$2$1;->this$1:Lnet/duceng/xmidi/Guitar$2;

    iget-object v1, v1, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    iget-object v2, p0, Lnet/duceng/xmidi/Guitar$2$1;->this$1:Lnet/duceng/xmidi/Guitar$2;

    iget-object v2, v2, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v2}, Lnet/duceng/xmidi/Guitar;->access$000(Lnet/duceng/xmidi/Guitar;)Landroid/widget/Button;

    move-result-object v2

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/Guitar;->chordSelect(Landroid/widget/Button;)V

    .line 92
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$2$1;->this$1:Lnet/duceng/xmidi/Guitar$2;

    iget-object v1, v1, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v1}, Lnet/duceng/xmidi/Guitar;->access$100(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogChord;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/xmidi/ui/DialogChord;->dismiss()V

    .line 93
    const/4 v1, 0x1

    return v1
.end method
