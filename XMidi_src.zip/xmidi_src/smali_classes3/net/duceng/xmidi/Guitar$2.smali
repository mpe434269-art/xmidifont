.class Lnet/duceng/xmidi/Guitar$2;
.super Ljava/lang/Object;
.source "Guitar.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Guitar;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Guitar;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Guitar;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Guitar;

    .line 78
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 82
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    move-object v1, p1

    check-cast v1, Landroid/widget/Button;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Guitar;->access$002(Lnet/duceng/xmidi/Guitar;Landroid/widget/Button;)Landroid/widget/Button;

    .line 83
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$100(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogChord;

    move-result-object v0

    if-nez v0, :cond_0

    .line 84
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    new-instance v1, Lnet/duceng/xmidi/ui/DialogChord;

    iget-object v2, p0, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    iget-object v3, p0, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v3}, Lnet/duceng/xmidi/Guitar;->access$200(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/util/Chords;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Lnet/duceng/xmidi/ui/DialogChord;-><init>(Landroid/content/Context;Lnet/duceng/xmidi/util/Chords;)V

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Guitar;->access$102(Lnet/duceng/xmidi/Guitar;Lnet/duceng/xmidi/ui/DialogChord;)Lnet/duceng/xmidi/ui/DialogChord;

    .line 85
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$100(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogChord;

    move-result-object v0

    new-instance v1, Lnet/duceng/xmidi/Guitar$2$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Guitar$2$1;-><init>(Lnet/duceng/xmidi/Guitar$2;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogChord;->setOnSelectListener(Lnet/duceng/xmidi/ui/DialogChord$OnSelectListener;)V

    .line 97
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$2;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$100(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogChord;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogChord;->show()V

    .line 98
    const/4 v0, 0x1

    return v0
.end method
