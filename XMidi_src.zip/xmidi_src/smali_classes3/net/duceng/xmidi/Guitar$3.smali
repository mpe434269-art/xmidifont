.class Lnet/duceng/xmidi/Guitar$3;
.super Ljava/lang/Object;
.source "Guitar.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Guitar;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Guitar;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Guitar;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Guitar;

    .line 101
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar$3;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 5
    .param p1, "v"    # Landroid/view/View;
    .param p2, "event"    # Landroid/view/MotionEvent;

    .line 104
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    and-int/lit16 v0, v0, 0xff

    .line 105
    .local v0, "action":I
    const/4 v1, 0x0

    if-nez v0, :cond_1

    .line 106
    move-object v2, p1

    check-cast v2, Lnet/duceng/xmidi/widgets/GRhythm;

    .line 107
    .local v2, "g":Lnet/duceng/xmidi/widgets/GRhythm;
    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/GRhythm;->isSelected()Z

    move-result v3

    if-nez v3, :cond_0

    .line 108
    iget-object v3, p0, Lnet/duceng/xmidi/Guitar$3;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-virtual {v3, v2}, Lnet/duceng/xmidi/Guitar;->rhythmSelect(Lnet/duceng/xmidi/widgets/GRhythm;)V

    goto :goto_0

    .line 110
    :cond_0
    invoke-virtual {v2, v1}, Lnet/duceng/xmidi/widgets/GRhythm;->setSelected(Z)V

    .line 111
    iget-object v3, p0, Lnet/duceng/xmidi/Guitar$3;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v3, v1}, Lnet/duceng/xmidi/Guitar;->access$302(Lnet/duceng/xmidi/Guitar;Z)Z

    .line 112
    iget-object v3, p0, Lnet/duceng/xmidi/Guitar$3;->this$0:Lnet/duceng/xmidi/Guitar;

    const/4 v4, 0x0

    invoke-static {v3, v4}, Lnet/duceng/xmidi/Guitar;->access$402(Lnet/duceng/xmidi/Guitar;Lnet/duceng/xmidi/util/Rhythm;)Lnet/duceng/xmidi/util/Rhythm;

    .line 113
    iget-object v3, p0, Lnet/duceng/xmidi/Guitar$3;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v3, v4}, Lnet/duceng/xmidi/Guitar;->access$502(Lnet/duceng/xmidi/Guitar;Ljava/util/List;)Ljava/util/List;

    .line 116
    .end local v2    # "g":Lnet/duceng/xmidi/widgets/GRhythm;
    :cond_1
    :goto_0
    return v1
.end method
