.class Lnet/duceng/xmidi/Guitar$4$1;
.super Ljava/lang/Object;
.source "Guitar.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Guitar$4;->onLongClick(Landroid/view/View;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/Guitar$4;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Guitar$4;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/Guitar$4;

    .line 124
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar$4$1;->this$1:Lnet/duceng/xmidi/Guitar$4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(Lnet/duceng/xmidi/util/Rhythm;)Z
    .locals 2
    .param p1, "r"    # Lnet/duceng/xmidi/util/Rhythm;

    .line 127
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$4$1;->this$1:Lnet/duceng/xmidi/Guitar$4;

    iget-object v0, v0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$600(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/widgets/GRhythm;

    move-result-object v0

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/widgets/GRhythm;->setRhythm(Lnet/duceng/xmidi/util/Rhythm;)V

    .line 128
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$4$1;->this$1:Lnet/duceng/xmidi/Guitar$4;

    iget-object v0, v0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$600(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/widgets/GRhythm;

    move-result-object v0

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/widgets/GRhythm;->setTag(Ljava/lang/Object;)V

    .line 129
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$4$1;->this$1:Lnet/duceng/xmidi/Guitar$4;

    iget-object v0, v0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$4$1;->this$1:Lnet/duceng/xmidi/Guitar$4;

    iget-object v1, v1, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v1}, Lnet/duceng/xmidi/Guitar;->access$600(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/widgets/GRhythm;

    move-result-object v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/Guitar;->rhythmSelect(Lnet/duceng/xmidi/widgets/GRhythm;)V

    .line 130
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$4$1;->this$1:Lnet/duceng/xmidi/Guitar$4;

    iget-object v0, v0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$700(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogRhythm;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogRhythm;->dismiss()V

    .line 131
    const/4 v0, 0x1

    return v0
.end method
