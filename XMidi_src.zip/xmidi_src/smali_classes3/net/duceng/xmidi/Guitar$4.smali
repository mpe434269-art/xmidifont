.class Lnet/duceng/xmidi/Guitar$4;
.super Ljava/lang/Object;
.source "Guitar.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Guitar;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Guitar;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Guitar;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Guitar;

    .line 119
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 123
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    move-object v1, p1

    check-cast v1, Lnet/duceng/xmidi/widgets/GRhythm;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Guitar;->access$602(Lnet/duceng/xmidi/Guitar;Lnet/duceng/xmidi/widgets/GRhythm;)Lnet/duceng/xmidi/widgets/GRhythm;

    .line 124
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$700(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogRhythm;

    move-result-object v0

    new-instance v1, Lnet/duceng/xmidi/Guitar$4$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Guitar$4$1;-><init>(Lnet/duceng/xmidi/Guitar$4;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogRhythm;->setOnSelectListener(Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;)V

    .line 134
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$600(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/widgets/GRhythm;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/GRhythm;->setSelected(Z)V

    .line 135
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Guitar;->access$302(Lnet/duceng/xmidi/Guitar;Z)Z

    .line 136
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Guitar;->access$402(Lnet/duceng/xmidi/Guitar;Lnet/duceng/xmidi/util/Rhythm;)Lnet/duceng/xmidi/util/Rhythm;

    .line 137
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Guitar;->access$502(Lnet/duceng/xmidi/Guitar;Ljava/util/List;)Ljava/util/List;

    .line 138
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$4;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$700(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogRhythm;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogRhythm;->show()V

    .line 139
    const/4 v0, 0x1

    return v0
.end method
