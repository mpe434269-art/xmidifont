.class Lnet/duceng/xmidi/Guitar$6;
.super Ljava/lang/Object;
.source "Guitar.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Guitar;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Guitar;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Guitar;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Guitar;

    .line 227
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 230
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Guitar;->access$302(Lnet/duceng/xmidi/Guitar;Z)Z

    .line 231
    :cond_0
    :goto_0
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$300(Lnet/duceng/xmidi/Guitar;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    iget-object v0, v0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->isPlaying()Z

    move-result v0

    if-nez v0, :cond_2

    .line 232
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Guitar;->access$902(Lnet/duceng/xmidi/Guitar;I)I

    .line 233
    :goto_1
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$900(Lnet/duceng/xmidi/Guitar;)I

    move-result v0

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    iget-object v1, v1, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getNumerator()I

    move-result v1

    if-ge v0, v1, :cond_0

    .line 234
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-virtual {v0}, Lnet/duceng/xmidi/Guitar;->playNotes()V

    .line 235
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$300(Lnet/duceng/xmidi/Guitar;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    iget-object v0, v0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 236
    goto :goto_0

    .line 238
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$908(Lnet/duceng/xmidi/Guitar;)I

    goto :goto_1

    .line 241
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$6;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Guitar;->access$302(Lnet/duceng/xmidi/Guitar;Z)Z

    .line 242
    return-void
.end method
