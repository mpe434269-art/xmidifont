.class Lnet/duceng/xmidi/Guitar$7;
.super Ljava/lang/Object;
.source "Guitar.java"

# interfaces
.implements Lnet/duceng/xsynth/Synth$BeatListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Guitar;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private executor:Ljava/util/concurrent/ExecutorService;

.field pre:J

.field private run:Ljava/lang/Runnable;

.field final synthetic this$0:Lnet/duceng/xmidi/Guitar;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Guitar;)V
    .locals 2
    .param p1, "this$0"    # Lnet/duceng/xmidi/Guitar;

    .line 244
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar$7;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 245
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lnet/duceng/xmidi/Guitar$7;->pre:J

    .line 246
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar$7;->executor:Ljava/util/concurrent/ExecutorService;

    .line 247
    new-instance v0, Lnet/duceng/xmidi/Guitar$7$1;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Guitar$7$1;-><init>(Lnet/duceng/xmidi/Guitar$7;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar$7;->run:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public onBeating(J)V
    .locals 4
    .param p1, "ticks"    # J

    .line 256
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$7;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$1000(Lnet/duceng/xmidi/Guitar;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 257
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$7;->executor:Ljava/util/concurrent/ExecutorService;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$7;->run:Ljava/lang/Runnable;

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 258
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$7;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$908(Lnet/duceng/xmidi/Guitar;)I

    .line 259
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$7;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$900(Lnet/duceng/xmidi/Guitar;)I

    move-result v0

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$7;->this$0:Lnet/duceng/xmidi/Guitar;

    iget-object v1, v1, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getNumerator()I

    move-result v1

    if-lt v0, v1, :cond_0

    .line 260
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$7;->this$0:Lnet/duceng/xmidi/Guitar;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Guitar;->access$902(Lnet/duceng/xmidi/Guitar;I)I

    .line 262
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$7;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$1100(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/widgets/MusicScore;

    move-result-object v0

    long-to-int v1, p1

    iget-wide v2, p0, Lnet/duceng/xmidi/Guitar$7;->pre:J

    long-to-int v3, v2

    const/4 v2, 0x2

    invoke-virtual {v0, v1, v3, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->shadeNotes(III)V

    .line 263
    iput-wide p1, p0, Lnet/duceng/xmidi/Guitar$7;->pre:J

    .line 265
    :cond_1
    return-void
.end method
