.class Lnet/duceng/xmidi/Guitar$8;
.super Ljava/lang/Object;
.source "Guitar.java"

# interfaces
.implements Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Guitar;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Guitar;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Guitar;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Guitar;

    .line 267
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar$8;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKeysChanged(II)V
    .locals 3
    .param p1, "note"    # I
    .param p2, "val"    # I

    .line 270
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$8;->this$0:Lnet/duceng/xmidi/Guitar;

    iget-object v0, v0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    int-to-byte v1, p1

    int-to-byte v2, p2

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->noteOn(BB)V

    .line 271
    return-void
.end method
