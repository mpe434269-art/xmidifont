.class Lnet/duceng/xmidi/Guitar$9;
.super Ljava/lang/Object;
.source "Guitar.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Guitar;->onActionClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Guitar;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Guitar;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Guitar;

    .line 413
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar$9;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(IILjava/lang/String;)V
    .locals 2
    .param p1, "chan"    # I
    .param p2, "preset"    # I
    .param p3, "instrument"    # Ljava/lang/String;

    .line 416
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$9;->this$0:Lnet/duceng/xmidi/Guitar;

    iget-object v0, v0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    int-to-byte v1, p1

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setRecordChan(B)V

    .line 417
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$9;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$800(Lnet/duceng/xmidi/Guitar;)Landroid/widget/Button;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar$9;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-virtual {v1, p1}, Lnet/duceng/xmidi/Guitar;->getPresetName(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 418
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar$9;->this$0:Lnet/duceng/xmidi/Guitar;

    invoke-static {v0}, Lnet/duceng/xmidi/Guitar;->access$1200(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogChannel;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogChannel;->dismiss()V

    .line 419
    return-void
.end method
