.class public Lnet/duceng/xmidi/Guitar;
.super Lnet/duceng/xmidi/BaseApp;
.source "Guitar.java"


# static fields
.field private static INSTRUMENT:I


# instance fields
.field private auto:Z

.field private bAuto:Landroid/widget/ImageButton;

.field private bPreset:Landroid/widget/Button;

.field private bTonality:Landroid/widget/Button;

.field private chord:Lnet/duceng/xmidi/util/Chords$Chord;

.field private chordLongBtn:Landroid/widget/Button;

.field private chordLongClickListener:Landroid/view/View$OnLongClickListener;

.field private chordTouchListener:Landroid/view/View$OnTouchListener;

.field private dialogChann:Lnet/duceng/xmidi/ui/DialogChannel;

.field private dialogChord:Lnet/duceng/xmidi/ui/DialogChord;

.field private dialogRhythm:Lnet/duceng/xmidi/ui/DialogRhythm;

.field private dialogTonality:Lnet/duceng/xmidi/ui/DialogTonality;

.field private dih0:Landroid/view/View;

.field private div0:Landroid/view/View;

.field private gBoard:Lnet/duceng/xmidi/widgets/GuitarBoard;

.field private gScore:Lnet/duceng/xmidi/widgets/MusicScore;

.field private gchords:[Landroid/widget/Button;

.field private glayout:Landroid/widget/LinearLayout;

.field private glchords0:Landroid/widget/LinearLayout;

.field private glchords1:Landroid/widget/LinearLayout;

.field private glrhythms:Landroid/widget/LinearLayout;

.field private grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

.field private guitarChords:Lnet/duceng/xmidi/util/Chords;

.field private idxBeat:I

.field private mExecutor:Ljava/util/concurrent/ExecutorService;

.field private mRunnable:Ljava/lang/Runnable;

.field private notes:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lnet/duceng/midi/EventChannel;",
            ">;"
        }
    .end annotation
.end field

.field private playing:Z

.field private rhythm:Lnet/duceng/xmidi/util/Rhythm;

.field private rhythmLongClickListener:Landroid/view/View$OnLongClickListener;

.field private rhythmLongGr:Lnet/duceng/xmidi/widgets/GRhythm;

.field private rhythmTouchListener:Landroid/view/View$OnTouchListener;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 36
    const/16 v0, 0x18

    sput v0, Lnet/duceng/xmidi/Guitar;->INSTRUMENT:I

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 33
    invoke-direct {p0}, Lnet/duceng/xmidi/BaseApp;-><init>()V

    .line 57
    const/16 v0, 0x8

    new-array v0, v0, [Landroid/widget/Button;

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    .line 58
    const/4 v0, 0x3

    new-array v0, v0, [Lnet/duceng/xmidi/widgets/GRhythm;

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    .line 59
    new-instance v0, Lnet/duceng/xmidi/util/Chords;

    invoke-direct {v0}, Lnet/duceng/xmidi/util/Chords;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->guitarChords:Lnet/duceng/xmidi/util/Chords;

    .line 60
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/Guitar;->auto:Z

    .line 61
    iput-boolean v0, p0, Lnet/duceng/xmidi/Guitar;->playing:Z

    .line 62
    iput v0, p0, Lnet/duceng/xmidi/Guitar;->idxBeat:I

    .line 63
    new-instance v0, Lnet/duceng/xmidi/Guitar$1;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Guitar$1;-><init>(Lnet/duceng/xmidi/Guitar;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->chordTouchListener:Landroid/view/View$OnTouchListener;

    .line 78
    new-instance v0, Lnet/duceng/xmidi/Guitar$2;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Guitar$2;-><init>(Lnet/duceng/xmidi/Guitar;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->chordLongClickListener:Landroid/view/View$OnLongClickListener;

    .line 101
    new-instance v0, Lnet/duceng/xmidi/Guitar$3;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Guitar$3;-><init>(Lnet/duceng/xmidi/Guitar;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->rhythmTouchListener:Landroid/view/View$OnTouchListener;

    .line 119
    new-instance v0, Lnet/duceng/xmidi/Guitar$4;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Guitar$4;-><init>(Lnet/duceng/xmidi/Guitar;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->rhythmLongClickListener:Landroid/view/View$OnLongClickListener;

    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/Guitar;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->chordLongBtn:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$002(Lnet/duceng/xmidi/Guitar;Landroid/widget/Button;)Landroid/widget/Button;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;
    .param p1, "x1"    # Landroid/widget/Button;

    .line 33
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar;->chordLongBtn:Landroid/widget/Button;

    return-object p1
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogChord;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogChord:Lnet/duceng/xmidi/ui/DialogChord;

    return-object v0
.end method

.method static synthetic access$1000(Lnet/duceng/xmidi/Guitar;)Z
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-boolean v0, p0, Lnet/duceng/xmidi/Guitar;->auto:Z

    return v0
.end method

.method static synthetic access$102(Lnet/duceng/xmidi/Guitar;Lnet/duceng/xmidi/ui/DialogChord;)Lnet/duceng/xmidi/ui/DialogChord;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;
    .param p1, "x1"    # Lnet/duceng/xmidi/ui/DialogChord;

    .line 33
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar;->dialogChord:Lnet/duceng/xmidi/ui/DialogChord;

    return-object p1
.end method

.method static synthetic access$1100(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/widgets/MusicScore;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gScore:Lnet/duceng/xmidi/widgets/MusicScore;

    return-object v0
.end method

.method static synthetic access$1200(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogChannel;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogChann:Lnet/duceng/xmidi/ui/DialogChannel;

    return-object v0
.end method

.method static synthetic access$1300(Lnet/duceng/xmidi/Guitar;)[Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$1400(Lnet/duceng/xmidi/Guitar;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->bTonality:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$1500(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogTonality;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogTonality:Lnet/duceng/xmidi/ui/DialogTonality;

    return-object v0
.end method

.method static synthetic access$200(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/util/Chords;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->guitarChords:Lnet/duceng/xmidi/util/Chords;

    return-object v0
.end method

.method static synthetic access$300(Lnet/duceng/xmidi/Guitar;)Z
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-boolean v0, p0, Lnet/duceng/xmidi/Guitar;->playing:Z

    return v0
.end method

.method static synthetic access$302(Lnet/duceng/xmidi/Guitar;Z)Z
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;
    .param p1, "x1"    # Z

    .line 33
    iput-boolean p1, p0, Lnet/duceng/xmidi/Guitar;->playing:Z

    return p1
.end method

.method static synthetic access$402(Lnet/duceng/xmidi/Guitar;Lnet/duceng/xmidi/util/Rhythm;)Lnet/duceng/xmidi/util/Rhythm;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;
    .param p1, "x1"    # Lnet/duceng/xmidi/util/Rhythm;

    .line 33
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    return-object p1
.end method

.method static synthetic access$502(Lnet/duceng/xmidi/Guitar;Ljava/util/List;)Ljava/util/List;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;
    .param p1, "x1"    # Ljava/util/List;

    .line 33
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar;->notes:Ljava/util/List;

    return-object p1
.end method

.method static synthetic access$600(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/widgets/GRhythm;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->rhythmLongGr:Lnet/duceng/xmidi/widgets/GRhythm;

    return-object v0
.end method

.method static synthetic access$602(Lnet/duceng/xmidi/Guitar;Lnet/duceng/xmidi/widgets/GRhythm;)Lnet/duceng/xmidi/widgets/GRhythm;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;
    .param p1, "x1"    # Lnet/duceng/xmidi/widgets/GRhythm;

    .line 33
    iput-object p1, p0, Lnet/duceng/xmidi/Guitar;->rhythmLongGr:Lnet/duceng/xmidi/widgets/GRhythm;

    return-object p1
.end method

.method static synthetic access$700(Lnet/duceng/xmidi/Guitar;)Lnet/duceng/xmidi/ui/DialogRhythm;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogRhythm:Lnet/duceng/xmidi/ui/DialogRhythm;

    return-object v0
.end method

.method static synthetic access$800(Lnet/duceng/xmidi/Guitar;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->bPreset:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$900(Lnet/duceng/xmidi/Guitar;)I
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget v0, p0, Lnet/duceng/xmidi/Guitar;->idxBeat:I

    return v0
.end method

.method static synthetic access$902(Lnet/duceng/xmidi/Guitar;I)I
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;
    .param p1, "x1"    # I

    .line 33
    iput p1, p0, Lnet/duceng/xmidi/Guitar;->idxBeat:I

    return p1
.end method

.method static synthetic access$908(Lnet/duceng/xmidi/Guitar;)I
    .locals 2
    .param p0, "x0"    # Lnet/duceng/xmidi/Guitar;

    .line 33
    iget v0, p0, Lnet/duceng/xmidi/Guitar;->idxBeat:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lnet/duceng/xmidi/Guitar;->idxBeat:I

    return v0
.end method


# virtual methods
.method public chordSelect(Landroid/widget/Button;)V
    .locals 3
    .param p1, "b"    # Landroid/widget/Button;

    .line 464
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    array-length v1, v1

    if-ge v0, v1, :cond_0

    .line 465
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    aget-object v1, v1, v0

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setSelected(Z)V

    .line 464
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 467
    .end local v0    # "i":I
    :cond_0
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setSelected(Z)V

    .line 468
    invoke-virtual {p1}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/Chords$Chord;

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    .line 469
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gBoard:Lnet/duceng/xmidi/widgets/GuitarBoard;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    iget-object v1, v1, Lnet/duceng/xmidi/util/Chords$Chord;->gfingers:[B

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/GuitarBoard;->setFingers([B)V

    .line 470
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    if-eqz v0, :cond_1

    .line 471
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/util/Rhythm;->getNotes(Lnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->notes:Ljava/util/List;

    .line 473
    :cond_1
    return-void
.end method

.method protected onActionClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 409
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    sparse-switch v0, :sswitch_data_0

    .line 457
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onActionClick(Landroid/view/View;)V

    goto :goto_0

    .line 425
    :sswitch_0
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogTonality:Lnet/duceng/xmidi/ui/DialogTonality;

    if-nez v0, :cond_0

    .line 426
    new-instance v0, Lnet/duceng/xmidi/ui/DialogTonality;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->guitarChords:Lnet/duceng/xmidi/util/Chords;

    invoke-direct {v0, p0, v1}, Lnet/duceng/xmidi/ui/DialogTonality;-><init>(Landroid/content/Context;Lnet/duceng/xmidi/util/Chords;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogTonality:Lnet/duceng/xmidi/ui/DialogTonality;

    .line 427
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogTonality:Lnet/duceng/xmidi/ui/DialogTonality;

    new-instance v1, Lnet/duceng/xmidi/Guitar$10;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Guitar$10;-><init>(Lnet/duceng/xmidi/Guitar;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogTonality;->setOnSelectListener(Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;)V

    .line 442
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogTonality:Lnet/duceng/xmidi/ui/DialogTonality;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogTonality;->show()V

    .line 443
    goto :goto_0

    .line 411
    :sswitch_1
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogChann:Lnet/duceng/xmidi/ui/DialogChannel;

    if-nez v0, :cond_1

    .line 412
    new-instance v0, Lnet/duceng/xmidi/ui/DialogChannel;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, p0, v1}, Lnet/duceng/xmidi/ui/DialogChannel;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogChann:Lnet/duceng/xmidi/ui/DialogChannel;

    .line 413
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogChann:Lnet/duceng/xmidi/ui/DialogChannel;

    new-instance v1, Lnet/duceng/xmidi/Guitar$9;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Guitar$9;-><init>(Lnet/duceng/xmidi/Guitar;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogChannel;->setOnSelectListener(Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;)V

    .line 422
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dialogChann:Lnet/duceng/xmidi/ui/DialogChannel;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogChannel;->show()V

    .line 423
    goto :goto_0

    .line 445
    :sswitch_2
    iget-boolean v0, p0, Lnet/duceng/xmidi/Guitar;->auto:Z

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    iput-boolean v0, p0, Lnet/duceng/xmidi/Guitar;->auto:Z

    .line 446
    iget-boolean v0, p0, Lnet/duceng/xmidi/Guitar;->auto:Z

    const/16 v2, 0x8

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    .line 447
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->bAuto:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 448
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v0, v3}, Lnet/duceng/xmidi/widgets/MusicScore;->setVisibility(I)V

    .line 449
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gBoard:Lnet/duceng/xmidi/widgets/GuitarBoard;

    invoke-virtual {v0, v2}, Lnet/duceng/xmidi/widgets/GuitarBoard;->setVisibility(I)V

    goto :goto_0

    .line 451
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->bAuto:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 452
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v0, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->setVisibility(I)V

    .line 453
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gBoard:Lnet/duceng/xmidi/widgets/GuitarBoard;

    invoke-virtual {v0, v3}, Lnet/duceng/xmidi/widgets/GuitarBoard;->setVisibility(I)V

    .line 455
    nop

    .line 460
    :goto_0
    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0x7f040077 -> :sswitch_2
        0x7f040086 -> :sswitch_1
        0x7f04008c -> :sswitch_0
    .end sparse-switch
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 6
    .param p1, "newConfig"    # Landroid/content/res/Configuration;

    .line 350
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 351
    iget-boolean v0, p0, Lnet/duceng/xmidi/Guitar;->isPortRait:Z

    const/16 v1, 0x8

    const/4 v2, 0x1

    const/4 v3, -0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    .line 352
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glayout:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 353
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/MusicScore;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v3, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 354
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/MusicScore;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v4, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 355
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gBoard:Lnet/duceng/xmidi/widgets/GuitarBoard;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v3, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 356
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gBoard:Lnet/duceng/xmidi/widgets/GuitarBoard;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v4, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 357
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords0:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 358
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords0:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v3, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 359
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords0:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v4, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 360
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords1:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 361
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords1:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v3, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 362
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords1:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v4, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 363
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glrhythms:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 364
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glrhythms:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v3, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 365
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glrhythms:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v4, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 366
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    array-length v2, v2

    if-ge v0, v2, :cond_0

    .line 367
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    aget-object v2, v2, v0

    invoke-virtual {v2, v4}, Lnet/duceng/xmidi/widgets/GRhythm;->setDegree(I)V

    .line 368
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/GRhythm;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    iput v4, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 369
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/GRhythm;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    iput v3, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 366
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 371
    .end local v0    # "i":I
    :cond_0
    const/4 v0, 0x0

    .local v0, "i2":I
    :goto_1
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    array-length v2, v2

    if-ge v0, v2, :cond_1

    .line 372
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    iput v4, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 373
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    iput v3, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 371
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 375
    .end local v0    # "i2":I
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dih0:Landroid/view/View;

    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    .line 376
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->div0:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    goto/16 :goto_4

    .line 378
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glayout:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 379
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/MusicScore;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v4, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 380
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/MusicScore;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v3, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 381
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gBoard:Lnet/duceng/xmidi/widgets/GuitarBoard;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v4, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 382
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gBoard:Lnet/duceng/xmidi/widgets/GuitarBoard;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/GuitarBoard;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v3, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 383
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords0:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 384
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords0:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v4, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 385
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords0:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v3, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 386
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords1:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 387
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords1:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v4, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 388
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glchords1:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v3, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 389
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glrhythms:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 390
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glrhythms:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v4, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 391
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->glrhythms:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput v3, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 392
    const/4 v0, 0x0

    .local v0, "i3":I
    :goto_2
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    array-length v2, v2

    if-ge v0, v2, :cond_3

    .line 393
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    aget-object v2, v2, v0

    const/16 v5, -0x5a

    invoke-virtual {v2, v5}, Lnet/duceng/xmidi/widgets/GRhythm;->setDegree(I)V

    .line 394
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/GRhythm;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    iput v3, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 395
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/GRhythm;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    iput v4, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 392
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    .line 397
    .end local v0    # "i3":I
    :cond_3
    const/4 v0, 0x0

    .local v0, "i4":I
    :goto_3
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    array-length v2, v2

    if-ge v0, v2, :cond_4

    .line 398
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    iput v3, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 399
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Landroid/widget/Button;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    iput v4, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 397
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    .line 401
    .end local v0    # "i4":I
    :cond_4
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->dih0:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 402
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->div0:Landroid/view/View;

    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    .line 404
    :goto_4
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->bPreset:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v1

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Guitar;->getPresetName(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 405
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 7
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 145
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onCreate(Landroid/os/Bundle;)V

    .line 146
    const v0, 0x7f050013

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Guitar;->setContentView(I)V

    .line 147
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->title:Landroid/widget/Button;

    const v1, 0x7f060010

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(I)V

    .line 148
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    .line 149
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v1

    const v2, 0x7f040005

    if-ne v1, v2, :cond_0

    .line 150
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    const v2, 0x7f020005

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setBackgroundResource(I)V

    .line 151
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 152
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->listMore:Ljava/util/ArrayList;

    add-int/lit8 v3, v0, 0x1

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 153
    goto :goto_1

    .line 148
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 156
    .end local v0    # "i":I
    :cond_1
    :goto_1
    invoke-virtual {p0}, Lnet/duceng/xmidi/Guitar;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050006

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    .line 157
    .local v0, "layout":Landroid/widget/LinearLayout;
    :goto_2
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v1

    const/4 v2, 0x0

    if-lez v1, :cond_5

    .line 158
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 159
    .local v1, "child":Landroid/view/View;
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->removeView(Landroid/view/View;)V

    .line 160
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 161
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->actionClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 162
    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v2

    const v3, 0x7f04008c

    if-ne v2, v3, :cond_2

    .line 163
    move-object v2, v1

    check-cast v2, Landroid/widget/Button;

    iput-object v2, p0, Lnet/duceng/xmidi/Guitar;->bTonality:Landroid/widget/Button;

    goto :goto_3

    .line 164
    :cond_2
    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v2

    const v3, 0x7f040086

    if-ne v2, v3, :cond_3

    .line 165
    move-object v2, v1

    check-cast v2, Landroid/widget/Button;

    iput-object v2, p0, Lnet/duceng/xmidi/Guitar;->bPreset:Landroid/widget/Button;

    .line 166
    new-instance v2, Lnet/duceng/xmidi/Guitar$5;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/Guitar$5;-><init>(Lnet/duceng/xmidi/Guitar;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    goto :goto_3

    .line 185
    :cond_3
    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v2

    const v3, 0x7f040077

    if-ne v2, v3, :cond_4

    .line 186
    move-object v2, v1

    check-cast v2, Landroid/widget/ImageButton;

    iput-object v2, p0, Lnet/duceng/xmidi/Guitar;->bAuto:Landroid/widget/ImageButton;

    .line 188
    .end local v1    # "child":Landroid/view/View;
    :cond_4
    :goto_3
    goto :goto_2

    .line 189
    :cond_5
    const v1, 0x7f040085

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    iput-object v1, p0, Lnet/duceng/xmidi/Guitar;->glayout:Landroid/widget/LinearLayout;

    .line 190
    const v1, 0x7f040081

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    iput-object v1, p0, Lnet/duceng/xmidi/Guitar;->glchords0:Landroid/widget/LinearLayout;

    .line 191
    const v1, 0x7f040082

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    iput-object v1, p0, Lnet/duceng/xmidi/Guitar;->glchords1:Landroid/widget/LinearLayout;

    .line 192
    const v1, 0x7f04008a

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    iput-object v1, p0, Lnet/duceng/xmidi/Guitar;->glrhythms:Landroid/widget/LinearLayout;

    .line 193
    const v1, 0x7f040083

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/Guitar;->dih0:Landroid/view/View;

    .line 194
    const v1, 0x7f040084

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/Guitar;->div0:Landroid/view/View;

    .line 195
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    const v3, 0x7f040079

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    aput-object v3, v1, v2

    .line 196
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    const v3, 0x7f04007a

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    const/4 v4, 0x1

    aput-object v3, v1, v4

    .line 197
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    const v3, 0x7f04007b

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    const/4 v5, 0x2

    aput-object v3, v1, v5

    .line 198
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    const v3, 0x7f04007c

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    const/4 v6, 0x3

    aput-object v3, v1, v6

    .line 199
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    const v3, 0x7f04007d

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    const/4 v6, 0x4

    aput-object v3, v1, v6

    .line 200
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    const v3, 0x7f04007e

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    const/4 v6, 0x5

    aput-object v3, v1, v6

    .line 201
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    const v3, 0x7f04007f

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    const/4 v6, 0x6

    aput-object v3, v1, v6

    .line 202
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    const v3, 0x7f040080

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    const/4 v6, 0x7

    aput-object v3, v1, v6

    .line 203
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    const v3, 0x7f040087

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/GRhythm;

    aput-object v3, v1, v2

    .line 204
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    const v3, 0x7f040088

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/GRhythm;

    aput-object v3, v1, v4

    .line 205
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    const v3, 0x7f040089

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/GRhythm;

    aput-object v3, v1, v5

    .line 206
    const v1, 0x7f040078

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Lnet/duceng/xmidi/widgets/GuitarBoard;

    iput-object v1, p0, Lnet/duceng/xmidi/Guitar;->gBoard:Lnet/duceng/xmidi/widgets/GuitarBoard;

    .line 207
    const v1, 0x7f04008b

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Guitar;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Lnet/duceng/xmidi/widgets/MusicScore;

    iput-object v1, p0, Lnet/duceng/xmidi/Guitar;->gScore:Lnet/duceng/xmidi/widgets/MusicScore;

    .line 208
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->gScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v1, v4}, Lnet/duceng/xmidi/widgets/MusicScore;->setScrollVert(Z)V

    .line 209
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->guitarChords:Lnet/duceng/xmidi/util/Chords;

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/util/Chords;->getGChords(I)[Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v1

    .line 210
    .local v1, "chords":[Lnet/duceng/xmidi/util/Chords$Chord;
    const/4 v3, 0x0

    .local v3, "i2":I
    :goto_4
    array-length v4, v1

    if-ge v3, v4, :cond_6

    .line 211
    iget-object v4, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    aget-object v4, v4, v3

    aget-object v5, v1, v3

    iget-object v5, v5, Lnet/duceng/xmidi/util/Chords$Chord;->name:Ljava/lang/String;

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 212
    iget-object v4, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    aget-object v4, v4, v3

    aget-object v5, v1, v3

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 213
    iget-object v4, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    aget-object v4, v4, v3

    iget-object v5, p0, Lnet/duceng/xmidi/Guitar;->chordTouchListener:Landroid/view/View$OnTouchListener;

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 214
    iget-object v4, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    aget-object v4, v4, v3

    iget-object v5, p0, Lnet/duceng/xmidi/Guitar;->chordLongClickListener:Landroid/view/View$OnLongClickListener;

    invoke-virtual {v4, v5}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 210
    add-int/lit8 v3, v3, 0x1

    goto :goto_4

    .line 216
    .end local v3    # "i2":I
    :cond_6
    new-instance v3, Lnet/duceng/xmidi/ui/DialogRhythm;

    iget-object v4, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v3, p0, v4}, Lnet/duceng/xmidi/ui/DialogRhythm;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v3, p0, Lnet/duceng/xmidi/Guitar;->dialogRhythm:Lnet/duceng/xmidi/ui/DialogRhythm;

    .line 217
    iget-object v3, p0, Lnet/duceng/xmidi/Guitar;->dialogRhythm:Lnet/duceng/xmidi/ui/DialogRhythm;

    invoke-virtual {v3}, Lnet/duceng/xmidi/ui/DialogRhythm;->getAdapter()Lnet/duceng/xmidi/util/AdapterRhythm;

    move-result-object v3

    iget-object v4, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v4}, Lnet/duceng/xsynth/Synth;->getNumerator()I

    move-result v4

    invoke-virtual {v3, v4}, Lnet/duceng/xmidi/util/AdapterRhythm;->setBeat(I)V

    .line 218
    const/4 v3, 0x0

    .local v3, "i3":I
    :goto_5
    iget-object v4, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    array-length v4, v4

    if-ge v3, v4, :cond_7

    .line 219
    iget-object v4, p0, Lnet/duceng/xmidi/Guitar;->dialogRhythm:Lnet/duceng/xmidi/ui/DialogRhythm;

    invoke-virtual {v4}, Lnet/duceng/xmidi/ui/DialogRhythm;->getAdapter()Lnet/duceng/xmidi/util/AdapterRhythm;

    move-result-object v4

    invoke-virtual {v4, v3}, Lnet/duceng/xmidi/util/AdapterRhythm;->getItem(I)Lnet/duceng/xmidi/util/Rhythm;

    move-result-object v4

    .line 220
    .local v4, "r":Lnet/duceng/xmidi/util/Rhythm;
    iget-object v5, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    aget-object v5, v5, v3

    invoke-virtual {v5, v4}, Lnet/duceng/xmidi/widgets/GRhythm;->setRhythm(Lnet/duceng/xmidi/util/Rhythm;)V

    .line 221
    iget-object v5, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    aget-object v5, v5, v3

    invoke-virtual {v5, v4}, Lnet/duceng/xmidi/widgets/GRhythm;->setTag(Ljava/lang/Object;)V

    .line 222
    iget-object v5, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    aget-object v5, v5, v3

    iget-object v6, p0, Lnet/duceng/xmidi/Guitar;->rhythmTouchListener:Landroid/view/View$OnTouchListener;

    invoke-virtual {v5, v6}, Lnet/duceng/xmidi/widgets/GRhythm;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 223
    iget-object v5, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    aget-object v5, v5, v3

    iget-object v6, p0, Lnet/duceng/xmidi/Guitar;->rhythmLongClickListener:Landroid/view/View$OnLongClickListener;

    invoke-virtual {v5, v6}, Lnet/duceng/xmidi/widgets/GRhythm;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 218
    .end local v4    # "r":Lnet/duceng/xmidi/util/Rhythm;
    add-int/lit8 v3, v3, 0x1

    goto :goto_5

    .line 225
    .end local v3    # "i3":I
    :cond_7
    iget-object v3, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    aget-object v2, v3, v2

    invoke-virtual {p0, v2}, Lnet/duceng/xmidi/Guitar;->chordSelect(Landroid/widget/Button;)V

    .line 226
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v2

    iput-object v2, p0, Lnet/duceng/xmidi/Guitar;->mExecutor:Ljava/util/concurrent/ExecutorService;

    .line 227
    new-instance v2, Lnet/duceng/xmidi/Guitar$6;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/Guitar$6;-><init>(Lnet/duceng/xmidi/Guitar;)V

    iput-object v2, p0, Lnet/duceng/xmidi/Guitar;->mRunnable:Ljava/lang/Runnable;

    .line 244
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    new-instance v3, Lnet/duceng/xmidi/Guitar$7;

    invoke-direct {v3, p0}, Lnet/duceng/xmidi/Guitar$7;-><init>(Lnet/duceng/xmidi/Guitar;)V

    invoke-virtual {v2, v3}, Lnet/duceng/xsynth/Synth;->setBeatListener(Lnet/duceng/xsynth/Synth$BeatListener;)V

    .line 267
    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->gBoard:Lnet/duceng/xmidi/widgets/GuitarBoard;

    new-instance v3, Lnet/duceng/xmidi/Guitar$8;

    invoke-direct {v3, p0}, Lnet/duceng/xmidi/Guitar$8;-><init>(Lnet/duceng/xmidi/Guitar;)V

    invoke-virtual {v2, v3}, Lnet/duceng/xmidi/widgets/GuitarBoard;->setGuitarBoardListener(Lnet/duceng/xmidi/widgets/GuitarBoard$GuitarBoardListener;)V

    .line 273
    return-void
.end method

.method protected onDestroy()V
    .locals 1

    .line 343
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/Guitar;->playing:Z

    .line 344
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->mExecutor:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    .line 345
    invoke-super {p0}, Lnet/duceng/xmidi/BaseApp;->onDestroy()V

    .line 346
    return-void
.end method

.method protected onMidiChanged(Ljava/io/File;)V
    .locals 3
    .param p1, "f"    # Ljava/io/File;

    .line 493
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onMidiChanged(Ljava/io/File;)V

    .line 494
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gScore:Lnet/duceng/xmidi/widgets/MusicScore;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->getScores()[Z

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->setMidiFile(Lnet/duceng/midi/MidiFile;[Z)V

    .line 495
    return-void
.end method

.method protected onStart()V
    .locals 3

    .line 334
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setRecordChan(B)V

    .line 335
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v1

    sget v2, Lnet/duceng/xmidi/Guitar;->INSTRUMENT:I

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->setPreset(II)V

    .line 336
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v1

    const/16 v2, 0x40

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->setSustain(II)V

    .line 337
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->bPreset:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v1

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Guitar;->getPresetName(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 338
    invoke-super {p0}, Lnet/duceng/xmidi/BaseApp;->onStart()V

    .line 339
    return-void
.end method

.method protected onTrackChanged()V
    .locals 3

    .line 499
    invoke-super {p0}, Lnet/duceng/xmidi/BaseApp;->onTrackChanged()V

    .line 500
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gScore:Lnet/duceng/xmidi/widgets/MusicScore;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->getScores()[Z

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->setMidiFile(Lnet/duceng/midi/MidiFile;[Z)V

    .line 501
    return-void
.end method

.method public playNotes()V
    .locals 19

    .line 277
    move-object/from16 v1, p0

    iget-object v0, v1, Lnet/duceng/xmidi/Guitar;->notes:Ljava/util/List;

    if-eqz v0, :cond_8

    .line 278
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    .line 279
    .local v2, "lastSleep":J
    iget-object v0, v1, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MetaTempo;->getMpqn()I

    move-result v4

    .line 280
    .local v4, "mpqn":I
    iget-object v0, v1, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getResolution()I

    move-result v5

    .line 281
    .local v5, "res":I
    iget v0, v1, Lnet/duceng/xmidi/Guitar;->idxBeat:I

    iget-object v6, v1, Lnet/duceng/xmidi/Guitar;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    invoke-virtual {v6}, Lnet/duceng/xmidi/util/Rhythm;->getBeat()B

    move-result v6

    rem-int/2addr v0, v6

    mul-int/lit16 v6, v0, 0x1e0

    .line 282
    .local v6, "tickStart":I
    add-int/lit16 v7, v6, 0x1e0

    .line 283
    .local v7, "tickEnd":I
    move v0, v6

    .line 284
    .local v0, "lastTick":I
    iget-object v8, v1, Lnet/duceng/xmidi/Guitar;->notes:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v8

    move-wide v9, v2

    move v2, v0

    .end local v0    # "lastTick":I
    .local v2, "lastTick":I
    .local v9, "lastSleep":J
    :goto_0
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Lnet/duceng/midi/EventChannel;

    .line 285
    .local v3, "note":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v0

    if-lt v0, v6, :cond_6

    .line 286
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v0

    const-string v11, "Interrupted during guitar sleep."

    if-gt v0, v7, :cond_4

    .line 287
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v0

    if-ne v0, v6, :cond_0

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v0

    const/16 v14, 0x8

    if-eq v0, v14, :cond_4

    .line 288
    :cond_0
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v0

    if-ne v0, v7, :cond_1

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v0

    const/16 v14, 0x9

    if-eq v0, v14, :cond_4

    .line 289
    :cond_1
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v0

    sub-int/2addr v0, v2

    mul-int v0, v0, v5

    div-int/lit16 v14, v0, 0x1e0

    .line 290
    .local v14, "delta":I
    if-lez v14, :cond_3

    .line 291
    invoke-static {v14, v4, v5}, Lnet/duceng/midi/MidiUtil;->ticksToMs(III)I

    move-result v0

    int-to-long v12, v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v17

    sub-long v17, v17, v9

    sub-long v12, v12, v17

    .line 292
    .local v12, "deltamillis":J
    const-wide/16 v15, 0x0

    cmp-long v0, v12, v15

    if-lez v0, :cond_2

    .line 294
    :try_start_0
    invoke-static {v12, v13}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 297
    goto :goto_1

    .line 295
    :catch_0
    move-exception v0

    move-object v8, v0

    move-object v0, v8

    .line 296
    .local v0, "e":Ljava/lang/InterruptedException;
    new-instance v8, Ljava/lang/RuntimeException;

    invoke-direct {v8, v11}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v8

    .line 299
    .end local v0    # "e":Ljava/lang/InterruptedException;
    :cond_2
    :goto_1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v9

    .line 301
    .end local v12    # "deltamillis":J
    :cond_3
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v0

    packed-switch v0, :pswitch_data_0

    goto :goto_2

    .line 306
    :pswitch_0
    iget-object v0, v1, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v12

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v13

    invoke-virtual {v0, v12, v13}, Lnet/duceng/xsynth/Synth;->noteOn(BB)V

    goto :goto_2

    .line 303
    :pswitch_1
    iget-object v0, v1, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v12

    invoke-virtual {v0, v12}, Lnet/duceng/xsynth/Synth;->noteOff(B)V

    .line 304
    nop

    .line 309
    :goto_2
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v2

    .line 313
    .end local v14    # "delta":I
    :cond_4
    iget-object v0, v1, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_6

    if-le v7, v2, :cond_6

    .line 314
    sub-int v0, v7, v2

    mul-int v0, v0, v5

    div-int/lit16 v0, v0, 0x1e0

    invoke-static {v0, v4, v5}, Lnet/duceng/midi/MidiUtil;->ticksToMs(III)I

    move-result v0

    int-to-long v12, v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v17

    sub-long v17, v17, v9

    sub-long v12, v12, v17

    .line 315
    .local v12, "deltamillis2":J
    const-wide/16 v14, 0x0

    cmp-long v0, v12, v14

    if-lez v0, :cond_5

    .line 317
    :try_start_1
    invoke-static {v12, v13}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1

    .line 318
    return-void

    .line 319
    :catch_1
    move-exception v0

    move-object v8, v0

    move-object v0, v8

    .line 320
    .local v0, "e2":Ljava/lang/InterruptedException;
    new-instance v8, Ljava/lang/RuntimeException;

    invoke-direct {v8, v11}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v8

    .line 323
    .end local v0    # "e2":Ljava/lang/InterruptedException;
    :cond_5
    return-void

    .line 326
    .end local v3    # "note":Lnet/duceng/midi/EventChannel;
    .end local v12    # "deltamillis2":J
    :cond_6
    goto/16 :goto_0

    .line 327
    :cond_7
    iget-object v0, v1, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->isPlaying()Z

    .line 330
    .end local v2    # "lastTick":I
    .end local v4    # "mpqn":I
    .end local v5    # "res":I
    .end local v6    # "tickStart":I
    .end local v7    # "tickEnd":I
    .end local v9    # "lastSleep":J
    :cond_8
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x8
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public rhythmSelect(Lnet/duceng/xmidi/widgets/GRhythm;)V
    .locals 3
    .param p1, "b"    # Lnet/duceng/xmidi/widgets/GRhythm;

    .line 477
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    array-length v1, v1

    const/4 v2, 0x0

    if-ge v0, v1, :cond_0

    .line 478
    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->grhythms:[Lnet/duceng/xmidi/widgets/GRhythm;

    aget-object v1, v1, v0

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/widgets/GRhythm;->setSelected(Z)V

    .line 477
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 480
    .end local v0    # "i":I
    :cond_0
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lnet/duceng/xmidi/widgets/GRhythm;->setSelected(Z)V

    .line 481
    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/GRhythm;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/Rhythm;

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    .line 482
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    if-nez v0, :cond_1

    .line 483
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->gchords:[Landroid/widget/Button;

    aget-object v0, v0, v2

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Guitar;->chordSelect(Landroid/widget/Button;)V

    .line 485
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->rhythm:Lnet/duceng/xmidi/util/Rhythm;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->chord:Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/util/Rhythm;->getNotes(Lnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/Guitar;->notes:Ljava/util/List;

    .line 486
    iget-boolean v0, p0, Lnet/duceng/xmidi/Guitar;->auto:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->isPlaying()Z

    move-result v0

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lnet/duceng/xmidi/Guitar;->playing:Z

    if-nez v0, :cond_2

    .line 487
    iget-object v0, p0, Lnet/duceng/xmidi/Guitar;->mExecutor:Ljava/util/concurrent/ExecutorService;

    iget-object v1, p0, Lnet/duceng/xmidi/Guitar;->mRunnable:Ljava/lang/Runnable;

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 489
    :cond_2
    return-void
.end method
