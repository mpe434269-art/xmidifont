.class Lnet/duceng/xmidi/Keyboard$1;
.super Ljava/lang/Object;
.source "Keyboard.java"

# interfaces
.implements Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Keyboard;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Keyboard;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Keyboard;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Keyboard;

    .line 28
    iput-object p1, p0, Lnet/duceng/xmidi/Keyboard$1;->this$0:Lnet/duceng/xmidi/Keyboard;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKeysChanged(II)V
    .locals 3
    .param p1, "note"    # I
    .param p2, "val"    # I

    .line 31
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard$1;->this$0:Lnet/duceng/xmidi/Keyboard;

    iget-object v0, v0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    int-to-byte v1, p1

    int-to-byte v2, p2

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->noteOn(BB)V

    .line 32
    return-void
.end method
