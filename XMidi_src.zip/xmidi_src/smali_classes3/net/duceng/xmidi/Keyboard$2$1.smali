.class Lnet/duceng/xmidi/Keyboard$2$1;
.super Ljava/lang/Object;
.source "Keyboard.java"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Keyboard$2;->onLongClick(Landroid/view/View;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/Keyboard$2;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Keyboard$2;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/Keyboard$2;

    .line 63
    iput-object p1, p0, Lnet/duceng/xmidi/Keyboard$2$1;->this$1:Lnet/duceng/xmidi/Keyboard$2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDismiss(Landroid/content/DialogInterface;)V
    .locals 3
    .param p1, "dialog"    # Landroid/content/DialogInterface;

    .line 66
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard$2$1;->this$1:Lnet/duceng/xmidi/Keyboard$2;

    iget-object v0, v0, Lnet/duceng/xmidi/Keyboard$2;->this$0:Lnet/duceng/xmidi/Keyboard;

    invoke-static {v0}, Lnet/duceng/xmidi/Keyboard;->access$000(Lnet/duceng/xmidi/Keyboard;)Landroid/widget/Button;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard$2$1;->this$1:Lnet/duceng/xmidi/Keyboard$2;

    iget-object v1, v1, Lnet/duceng/xmidi/Keyboard$2;->this$0:Lnet/duceng/xmidi/Keyboard;

    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard$2$1;->this$1:Lnet/duceng/xmidi/Keyboard$2;

    iget-object v2, v2, Lnet/duceng/xmidi/Keyboard$2;->this$0:Lnet/duceng/xmidi/Keyboard;

    iget-object v2, v2, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v2

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/Keyboard;->getPresetName(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 67
    return-void
.end method
