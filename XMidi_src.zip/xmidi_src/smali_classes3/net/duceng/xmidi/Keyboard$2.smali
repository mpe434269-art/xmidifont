.class Lnet/duceng/xmidi/Keyboard$2;
.super Ljava/lang/Object;
.source "Keyboard.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Keyboard;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

.field final synthetic this$0:Lnet/duceng/xmidi/Keyboard;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Keyboard;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Keyboard;

    .line 56
    iput-object p1, p0, Lnet/duceng/xmidi/Keyboard$2;->this$0:Lnet/duceng/xmidi/Keyboard;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 61
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard$2;->dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    if-nez v0, :cond_0

    .line 62
    new-instance v0, Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard$2;->this$0:Lnet/duceng/xmidi/Keyboard;

    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard$2;->this$0:Lnet/duceng/xmidi/Keyboard;

    iget-object v2, v2, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/ui/DialogPreset;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Keyboard$2;->dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    .line 63
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard$2;->dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    new-instance v1, Lnet/duceng/xmidi/Keyboard$2$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Keyboard$2$1;-><init>(Lnet/duceng/xmidi/Keyboard$2;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogPreset;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 70
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard$2;->dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard$2;->this$0:Lnet/duceng/xmidi/Keyboard;

    iget-object v1, v1, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogPreset;->setChannel(I)V

    .line 71
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard$2;->dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogPreset;->show()V

    .line 72
    const/4 v0, 0x1

    return v0
.end method
