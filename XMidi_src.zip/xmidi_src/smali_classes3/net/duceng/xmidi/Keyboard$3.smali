.class Lnet/duceng/xmidi/Keyboard$3;
.super Ljava/lang/Object;
.source "Keyboard.java"

# interfaces
.implements Lnet/duceng/xsynth/Synth$BeatListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Keyboard;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field pre:J

.field final synthetic this$0:Lnet/duceng/xmidi/Keyboard;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Keyboard;)V
    .locals 2
    .param p1, "this$0"    # Lnet/duceng/xmidi/Keyboard;

    .line 92
    iput-object p1, p0, Lnet/duceng/xmidi/Keyboard$3;->this$0:Lnet/duceng/xmidi/Keyboard;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 93
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lnet/duceng/xmidi/Keyboard$3;->pre:J

    return-void
.end method


# virtual methods
.method public onBeating(J)V
    .locals 4
    .param p1, "ticks"    # J

    .line 97
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard$3;->this$0:Lnet/duceng/xmidi/Keyboard;

    invoke-static {v0}, Lnet/duceng/xmidi/Keyboard;->access$100(Lnet/duceng/xmidi/Keyboard;)Lnet/duceng/xmidi/widgets/MusicScore;

    move-result-object v0

    long-to-int v1, p1

    iget-wide v2, p0, Lnet/duceng/xmidi/Keyboard$3;->pre:J

    long-to-int v3, v2

    const/4 v2, 0x2

    invoke-virtual {v0, v1, v3, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->shadeNotes(III)V

    .line 98
    iput-wide p1, p0, Lnet/duceng/xmidi/Keyboard$3;->pre:J

    .line 99
    return-void
.end method
