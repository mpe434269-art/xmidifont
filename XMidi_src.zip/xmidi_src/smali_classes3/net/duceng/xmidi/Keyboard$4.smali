.class Lnet/duceng/xmidi/Keyboard$4;
.super Ljava/lang/Object;
.source "Keyboard.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Keyboard;->onActionClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Keyboard;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Keyboard;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Keyboard;

    .line 123
    iput-object p1, p0, Lnet/duceng/xmidi/Keyboard$4;->this$0:Lnet/duceng/xmidi/Keyboard;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(IILjava/lang/String;)V
    .locals 2
    .param p1, "chan"    # I
    .param p2, "preset"    # I
    .param p3, "instrument"    # Ljava/lang/String;

    .line 126
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard$4;->this$0:Lnet/duceng/xmidi/Keyboard;

    iget-object v0, v0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    int-to-byte v1, p1

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setRecordChan(B)V

    .line 127
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard$4;->this$0:Lnet/duceng/xmidi/Keyboard;

    invoke-static {v0}, Lnet/duceng/xmidi/Keyboard;->access$000(Lnet/duceng/xmidi/Keyboard;)Landroid/widget/Button;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard$4;->this$0:Lnet/duceng/xmidi/Keyboard;

    invoke-virtual {v1, p1}, Lnet/duceng/xmidi/Keyboard;->getPresetName(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 128
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard$4;->this$0:Lnet/duceng/xmidi/Keyboard;

    invoke-static {v0}, Lnet/duceng/xmidi/Keyboard;->access$200(Lnet/duceng/xmidi/Keyboard;)Lnet/duceng/xmidi/ui/DialogChannel;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogChannel;->dismiss()V

    .line 129
    return-void
.end method
