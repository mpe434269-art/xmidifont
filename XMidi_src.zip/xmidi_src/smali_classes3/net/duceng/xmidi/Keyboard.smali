.class public Lnet/duceng/xmidi/Keyboard;
.super Lnet/duceng/xmidi/BaseApp;
.source "Keyboard.java"


# instance fields
.field private bPreset:Landroid/widget/Button;

.field private buttonLock:Landroid/widget/ImageButton;

.field private channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

.field private musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

.field private pianoBoard:Lnet/duceng/xmidi/widgets/PianoBoard;

.field private pianoBoardFix:Lnet/duceng/xmidi/widgets/PianoBoard;

.field private pianoListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

.field private scoreStatus:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 20
    invoke-direct {p0}, Lnet/duceng/xmidi/BaseApp;-><init>()V

    .line 27
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    .line 28
    new-instance v0, Lnet/duceng/xmidi/Keyboard$1;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Keyboard$1;-><init>(Lnet/duceng/xmidi/Keyboard;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Keyboard;->pianoListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/Keyboard;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Keyboard;

    .line 20
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->bPreset:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/Keyboard;)Lnet/duceng/xmidi/widgets/MusicScore;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Keyboard;

    .line 20
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    return-object v0
.end method

.method static synthetic access$200(Lnet/duceng/xmidi/Keyboard;)Lnet/duceng/xmidi/ui/DialogChannel;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Keyboard;

    .line 20
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    return-object v0
.end method

.method private changeScore()V
    .locals 6

    .line 169
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/MusicScore;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 170
    .local v0, "lp":Landroid/widget/LinearLayout$LayoutParams;
    iget-boolean v1, p0, Lnet/duceng/xmidi/Keyboard;->isPortRait:Z

    const/high16 v2, 0x3f800000    # 1.0f

    const/16 v3, 0x8

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v1, :cond_4

    .line 171
    iget v1, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    if-ne v1, v4, :cond_0

    const/high16 v2, 0x40000000    # 2.0f

    :cond_0
    iput v2, v0, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 172
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v1, v5}, Lnet/duceng/xmidi/widgets/MusicScore;->setVisibility(I)V

    .line 173
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    iget v2, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    if-eqz v2, :cond_1

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->setScrollVert(Z)V

    .line 174
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoard:Lnet/duceng/xmidi/widgets/PianoBoard;

    iget v2, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    if-lez v2, :cond_2

    const/16 v2, 0x8

    goto :goto_1

    :cond_2
    const/4 v2, 0x0

    :goto_1
    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/widgets/PianoBoard;->setVisibility(I)V

    .line 175
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoardFix:Lnet/duceng/xmidi/widgets/PianoBoard;

    iget v2, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    if-gt v2, v4, :cond_3

    const/4 v3, 0x0

    :cond_3
    invoke-virtual {v1, v3}, Lnet/duceng/xmidi/widgets/PianoBoard;->setVisibility(I)V

    .line 176
    return-void

    .line 178
    :cond_4
    iput v2, v0, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 179
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    iget v2, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    if-le v2, v4, :cond_5

    const/16 v2, 0x8

    goto :goto_2

    :cond_5
    const/4 v2, 0x0

    :goto_2
    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->setVisibility(I)V

    .line 180
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    iget v2, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    if-eqz v2, :cond_6

    const/4 v2, 0x1

    goto :goto_3

    :cond_6
    const/4 v2, 0x0

    :goto_3
    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->setScrollVert(Z)V

    .line 181
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoard:Lnet/duceng/xmidi/widgets/PianoBoard;

    iget v2, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    if-le v2, v4, :cond_7

    const/4 v2, 0x0

    goto :goto_4

    :cond_7
    const/16 v2, 0x8

    :goto_4
    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/widgets/PianoBoard;->setVisibility(I)V

    .line 182
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoardFix:Lnet/duceng/xmidi/widgets/PianoBoard;

    iget v2, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    if-eq v2, v4, :cond_8

    const/4 v3, 0x0

    :cond_8
    invoke-virtual {v1, v3}, Lnet/duceng/xmidi/widgets/PianoBoard;->setVisibility(I)V

    .line 183
    return-void
.end method


# virtual methods
.method protected onActionClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 119
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    packed-switch v0, :pswitch_data_0

    .line 151
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onActionClick(Landroid/view/View;)V

    goto :goto_0

    .line 135
    :pswitch_0
    iget v0, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    add-int/2addr v0, v2

    iput v0, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    .line 136
    iget v0, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    const/4 v2, 0x2

    if-le v0, v2, :cond_0

    .line 137
    iput v1, p0, Lnet/duceng/xmidi/Keyboard;->scoreStatus:I

    .line 139
    :cond_0
    invoke-direct {p0}, Lnet/duceng/xmidi/Keyboard;->changeScore()V

    .line 140
    goto :goto_0

    .line 121
    :pswitch_1
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    if-nez v0, :cond_1

    .line 122
    new-instance v0, Lnet/duceng/xmidi/ui/DialogChannel;

    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, p0, v1}, Lnet/duceng/xmidi/ui/DialogChannel;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Keyboard;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    .line 123
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    new-instance v1, Lnet/duceng/xmidi/Keyboard$4;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Keyboard$4;-><init>(Lnet/duceng/xmidi/Keyboard;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogChannel;->setOnSelectListener(Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;)V

    .line 132
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogChannel;->show()V

    .line 133
    goto :goto_0

    .line 142
    :pswitch_2
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoard:Lnet/duceng/xmidi/widgets/PianoBoard;

    iget-object v3, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoard:Lnet/duceng/xmidi/widgets/PianoBoard;

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/PianoBoard;->isLocked()Z

    move-result v3

    xor-int/2addr v3, v2

    invoke-virtual {v0, v3}, Lnet/duceng/xmidi/widgets/PianoBoard;->setLocked(Z)V

    .line 143
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoardFix:Lnet/duceng/xmidi/widgets/PianoBoard;

    iget-object v3, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoardFix:Lnet/duceng/xmidi/widgets/PianoBoard;

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/PianoBoard;->isLocked()Z

    move-result v3

    xor-int/2addr v3, v2

    invoke-virtual {v0, v3}, Lnet/duceng/xmidi/widgets/PianoBoard;->setLocked(Z)V

    .line 144
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoard:Lnet/duceng/xmidi/widgets/PianoBoard;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/PianoBoard;->isLocked()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 145
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->buttonLock:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    goto :goto_0

    .line 147
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->buttonLock:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 149
    nop

    .line 154
    :goto_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x7f04008e
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2
    .param p1, "newConfig"    # Landroid/content/res/Configuration;

    .line 112
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 113
    invoke-direct {p0}, Lnet/duceng/xmidi/Keyboard;->changeScore()V

    .line 114
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->bPreset:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v1

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Keyboard;->getPresetName(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 115
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 37
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onCreate(Landroid/os/Bundle;)V

    .line 38
    const v0, 0x7f050014

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Keyboard;->setContentView(I)V

    .line 39
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->title:Landroid/widget/Button;

    const v1, 0x7f060015

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(I)V

    .line 40
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    .line 41
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v1

    const v2, 0x7f040006

    if-ne v1, v2, :cond_0

    .line 42
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    const v2, 0x7f020005

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setBackgroundResource(I)V

    .line 43
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 44
    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->listMore:Ljava/util/ArrayList;

    add-int/lit8 v3, v0, 0x1

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 45
    goto :goto_1

    .line 40
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 48
    .end local v0    # "i":I
    :cond_1
    :goto_1
    invoke-virtual {p0}, Lnet/duceng/xmidi/Keyboard;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050007

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    .line 49
    .local v0, "layout":Landroid/widget/LinearLayout;
    :goto_2
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v1

    if-lez v1, :cond_4

    .line 50
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 51
    .local v1, "child":Landroid/view/View;
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->removeView(Landroid/view/View;)V

    .line 52
    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 53
    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard;->actionClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 54
    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v2

    const v3, 0x7f04008f

    if-ne v2, v3, :cond_2

    .line 55
    move-object v2, v1

    check-cast v2, Landroid/widget/Button;

    iput-object v2, p0, Lnet/duceng/xmidi/Keyboard;->bPreset:Landroid/widget/Button;

    .line 56
    new-instance v2, Lnet/duceng/xmidi/Keyboard$2;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/Keyboard$2;-><init>(Lnet/duceng/xmidi/Keyboard;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    goto :goto_3

    .line 75
    :cond_2
    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v2

    const v3, 0x7f04008e

    if-ne v2, v3, :cond_3

    .line 76
    move-object v2, v1

    check-cast v2, Landroid/widget/ImageButton;

    iput-object v2, p0, Lnet/duceng/xmidi/Keyboard;->buttonLock:Landroid/widget/ImageButton;

    .line 78
    .end local v1    # "child":Landroid/view/View;
    :cond_3
    :goto_3
    goto :goto_2

    .line 79
    :cond_4
    invoke-virtual {p0}, Lnet/duceng/xmidi/Keyboard;->getIntent()Landroid/content/Intent;

    move-result-object v1

    const-string v2, "file"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object v1

    check-cast v1, Ljava/io/File;

    .line 80
    .local v1, "f":Ljava/io/File;
    if-eqz v1, :cond_5

    .line 81
    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2, v1}, Lnet/duceng/xsynth/Synth;->setFile(Ljava/io/File;)V

    .line 83
    :cond_5
    const v2, 0x7f04009d

    invoke-virtual {p0, v2}, Lnet/duceng/xmidi/Keyboard;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lnet/duceng/xmidi/widgets/MusicScore;

    iput-object v2, p0, Lnet/duceng/xmidi/Keyboard;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    .line 84
    const v2, 0x7f04009e

    invoke-virtual {p0, v2}, Lnet/duceng/xmidi/Keyboard;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lnet/duceng/xmidi/widgets/PianoBoard;

    iput-object v2, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoard:Lnet/duceng/xmidi/widgets/PianoBoard;

    .line 85
    const v2, 0x7f04009f

    invoke-virtual {p0, v2}, Lnet/duceng/xmidi/Keyboard;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lnet/duceng/xmidi/widgets/PianoBoard;

    iput-object v2, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoardFix:Lnet/duceng/xmidi/widgets/PianoBoard;

    .line 86
    invoke-virtual {p0}, Lnet/duceng/xmidi/Keyboard;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f010004

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lnet/duceng/xmidi/Keyboard;->instruments:[Ljava/lang/String;

    .line 87
    invoke-virtual {p0}, Lnet/duceng/xmidi/Keyboard;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f010002

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lnet/duceng/xmidi/Keyboard;->drums:[Ljava/lang/String;

    .line 88
    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoard:Lnet/duceng/xmidi/widgets/PianoBoard;

    const/16 v3, 0x43

    invoke-virtual {v2, v3}, Lnet/duceng/xmidi/widgets/PianoBoard;->setScroll(I)V

    .line 89
    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoardFix:Lnet/duceng/xmidi/widgets/PianoBoard;

    const/16 v3, 0x37

    invoke-virtual {v2, v3}, Lnet/duceng/xmidi/widgets/PianoBoard;->setScroll(I)V

    .line 90
    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoard:Lnet/duceng/xmidi/widgets/PianoBoard;

    iget-object v3, p0, Lnet/duceng/xmidi/Keyboard;->pianoListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    invoke-virtual {v2, v3}, Lnet/duceng/xmidi/widgets/PianoBoard;->setPianoBoardListener(Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;)V

    .line 91
    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard;->pianoBoardFix:Lnet/duceng/xmidi/widgets/PianoBoard;

    iget-object v3, p0, Lnet/duceng/xmidi/Keyboard;->pianoListener:Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;

    invoke-virtual {v2, v3}, Lnet/duceng/xmidi/widgets/PianoBoard;->setPianoBoardListener(Lnet/duceng/xmidi/widgets/PianoBoard$PianoBoardListener;)V

    .line 92
    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    new-instance v3, Lnet/duceng/xmidi/Keyboard$3;

    invoke-direct {v3, p0}, Lnet/duceng/xmidi/Keyboard$3;-><init>(Lnet/duceng/xmidi/Keyboard;)V

    invoke-virtual {v2, v3}, Lnet/duceng/xsynth/Synth;->setBeatListener(Lnet/duceng/xsynth/Synth$BeatListener;)V

    .line 101
    return-void
.end method

.method protected onMidiChanged(Ljava/io/File;)V
    .locals 3
    .param p1, "f"    # Ljava/io/File;

    .line 158
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onMidiChanged(Ljava/io/File;)V

    .line 159
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->getScores()[Z

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->setMidiFile(Lnet/duceng/midi/MidiFile;[Z)V

    .line 160
    return-void
.end method

.method protected onStart()V
    .locals 2

    .line 105
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setRecordChan(B)V

    .line 106
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->bPreset:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v1

    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/Keyboard;->getPresetName(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 107
    invoke-super {p0}, Lnet/duceng/xmidi/BaseApp;->onStart()V

    .line 108
    return-void
.end method

.method protected onTrackChanged()V
    .locals 3

    .line 164
    invoke-super {p0}, Lnet/duceng/xmidi/BaseApp;->onTrackChanged()V

    .line 165
    iget-object v0, p0, Lnet/duceng/xmidi/Keyboard;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    iget-object v1, p0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/Keyboard;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->getScores()[Z

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xmidi/widgets/MusicScore;->setMidiFile(Lnet/duceng/midi/MidiFile;[Z)V

    .line 166
    return-void
.end method
