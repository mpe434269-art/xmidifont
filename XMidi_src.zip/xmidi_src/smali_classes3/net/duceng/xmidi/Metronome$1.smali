.class Lnet/duceng/xmidi/Metronome$1;
.super Ljava/lang/Object;
.source "Metronome.java"

# interfaces
.implements Lnet/duceng/xmidi/widgets/MetronomeHand$SpeedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Metronome;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Metronome;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Metronome;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Metronome;

    .line 54
    iput-object p1, p0, Lnet/duceng/xmidi/Metronome$1;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSpeedChanged(I)V
    .locals 3
    .param p1, "sp"    # I

    .line 57
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$1;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-static {v0}, Lnet/duceng/xmidi/Metronome;->access$000(Lnet/duceng/xmidi/Metronome;)Landroid/widget/TextView;

    move-result-object v0

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 58
    const/4 v0, 0x0

    .line 59
    .local v0, "idx":I
    const/4 v1, 0x0

    .local v1, "i2":I
    :goto_0
    invoke-static {}, Lnet/duceng/xmidi/Metronome;->access$100()[I

    move-result-object v2

    array-length v2, v2

    if-ge v1, v2, :cond_0

    invoke-static {}, Lnet/duceng/xmidi/Metronome;->access$100()[I

    move-result-object v2

    aget v2, v2, v1

    if-le p1, v2, :cond_0

    .line 60
    move v0, v1

    .line 59
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 62
    .end local v1    # "i2":I
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/Metronome$1;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-static {v1}, Lnet/duceng/xmidi/Metronome;->access$300(Lnet/duceng/xmidi/Metronome;)Landroid/widget/TextView;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/Metronome$1;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-static {v2}, Lnet/duceng/xmidi/Metronome;->access$200(Lnet/duceng/xmidi/Metronome;)[Ljava/lang/String;

    move-result-object v2

    aget-object v2, v2, v0

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 63
    iget-object v1, p0, Lnet/duceng/xmidi/Metronome$1;->this$0:Lnet/duceng/xmidi/Metronome;

    iget-object v1, v1, Lnet/duceng/xmidi/Metronome;->synth:Lnet/duceng/xsynth/Synth;

    if-eqz v1, :cond_1

    .line 64
    iget-object v1, p0, Lnet/duceng/xmidi/Metronome$1;->this$0:Lnet/duceng/xmidi/Metronome;

    iget-object v1, v1, Lnet/duceng/xmidi/Metronome;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v1

    invoke-virtual {v1, p1}, Lnet/duceng/midi/MetaTempo;->setBpm(I)V

    .line 66
    :cond_1
    return-void
.end method
