.class Lnet/duceng/xmidi/Metronome$2;
.super Ljava/lang/Object;
.source "Metronome.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Metronome;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Metronome;

.field final synthetic val$textTempo:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Metronome;Landroid/widget/TextView;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Metronome;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 69
    iput-object p1, p0, Lnet/duceng/xmidi/Metronome$2;->this$0:Lnet/duceng/xmidi/Metronome;

    iput-object p2, p0, Lnet/duceng/xmidi/Metronome$2;->val$textTempo:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 72
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$2;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-static {v0}, Lnet/duceng/xmidi/Metronome;->access$408(Lnet/duceng/xmidi/Metronome;)I

    .line 73
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$2;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-static {v0}, Lnet/duceng/xmidi/Metronome;->access$400(Lnet/duceng/xmidi/Metronome;)I

    move-result v0

    const/16 v1, 0xc

    if-le v0, v1, :cond_0

    .line 74
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$2;->this$0:Lnet/duceng/xmidi/Metronome;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Metronome;->access$402(Lnet/duceng/xmidi/Metronome;I)I

    .line 76
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$2;->val$textTempo:Landroid/widget/TextView;

    iget-object v1, p0, Lnet/duceng/xmidi/Metronome$2;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-static {v1}, Lnet/duceng/xmidi/Metronome;->access$400(Lnet/duceng/xmidi/Metronome;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 77
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$2;->this$0:Lnet/duceng/xmidi/Metronome;

    iget-object v0, v0, Lnet/duceng/xmidi/Metronome;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTimeSignature()Lnet/duceng/midi/MetaTimeSignature;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Metronome$2;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-static {v1}, Lnet/duceng/xmidi/Metronome;->access$400(Lnet/duceng/xmidi/Metronome;)I

    move-result v1

    int-to-byte v1, v1

    invoke-virtual {v0, v1}, Lnet/duceng/midi/MetaTimeSignature;->setNumerator(B)V

    .line 78
    return-void
.end method
