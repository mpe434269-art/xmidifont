.class Lnet/duceng/xmidi/Metronome$3;
.super Ljava/lang/Object;
.source "Metronome.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Metronome;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Metronome;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Metronome;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Metronome;

    .line 80
    iput-object p1, p0, Lnet/duceng/xmidi/Metronome$3;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 83
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$3;->this$0:Lnet/duceng/xmidi/Metronome;

    iget-object v0, v0, Lnet/duceng/xmidi/Metronome;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 84
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$3;->this$0:Lnet/duceng/xmidi/Metronome;

    iget-object v0, v0, Lnet/duceng/xmidi/Metronome;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->stop()V

    .line 85
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$3;->this$0:Lnet/duceng/xmidi/Metronome;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Metronome;->access$502(Lnet/duceng/xmidi/Metronome;Z)Z

    goto :goto_0

    .line 87
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$3;->this$0:Lnet/duceng/xmidi/Metronome;

    iget-object v0, v0, Lnet/duceng/xmidi/Metronome;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->play()V

    .line 88
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$3;->this$0:Lnet/duceng/xmidi/Metronome;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lnet/duceng/xmidi/Metronome;->access$502(Lnet/duceng/xmidi/Metronome;Z)Z

    .line 89
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$3;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-static {v0}, Lnet/duceng/xmidi/Metronome;->access$700(Lnet/duceng/xmidi/Metronome;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Metronome$3;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-static {v1}, Lnet/duceng/xmidi/Metronome;->access$600(Lnet/duceng/xmidi/Metronome;)Ljava/lang/Runnable;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 91
    :goto_0
    return-void
.end method
