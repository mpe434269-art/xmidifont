.class Lnet/duceng/xmidi/Metronome$4;
.super Ljava/lang/Object;
.source "Metronome.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Metronome;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Metronome;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Metronome;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Metronome;

    .line 94
    iput-object p1, p0, Lnet/duceng/xmidi/Metronome$4;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 97
    nop

    :goto_0
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$4;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-static {v0}, Lnet/duceng/xmidi/Metronome;->access$500(Lnet/duceng/xmidi/Metronome;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 98
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$4;->this$0:Lnet/duceng/xmidi/Metronome;

    iget-object v0, v0, Lnet/duceng/xmidi/Metronome;->synth:Lnet/duceng/xsynth/Synth;

    if-eqz v0, :cond_0

    .line 99
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$4;->this$0:Lnet/duceng/xmidi/Metronome;

    iget-object v1, p0, Lnet/duceng/xmidi/Metronome$4;->this$0:Lnet/duceng/xmidi/Metronome;

    iget-object v1, v1, Lnet/duceng/xmidi/Metronome;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getBeatPercent()F

    move-result v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/Metronome;->setPercent(F)V

    .line 102
    :cond_0
    const-wide/16 v0, 0x32

    :try_start_0
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 105
    :goto_1
    goto :goto_0

    .line 103
    :catch_0
    move-exception v0

    .line 104
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .end local v0    # "e":Ljava/lang/Exception;
    goto :goto_1

    .line 107
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$4;->this$0:Lnet/duceng/xmidi/Metronome;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/Metronome;->setPercent(F)V

    .line 108
    return-void
.end method
