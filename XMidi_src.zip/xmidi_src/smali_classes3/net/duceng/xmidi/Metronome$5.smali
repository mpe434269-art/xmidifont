.class Lnet/duceng/xmidi/Metronome$5;
.super Ljava/lang/Object;
.source "Metronome.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Metronome;->setPercent(F)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Metronome;

.field final synthetic val$percent:F


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Metronome;F)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Metronome;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 114
    iput-object p1, p0, Lnet/duceng/xmidi/Metronome$5;->this$0:Lnet/duceng/xmidi/Metronome;

    iput p2, p0, Lnet/duceng/xmidi/Metronome$5;->val$percent:F

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 117
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome$5;->this$0:Lnet/duceng/xmidi/Metronome;

    invoke-static {v0}, Lnet/duceng/xmidi/Metronome;->access$800(Lnet/duceng/xmidi/Metronome;)Lnet/duceng/xmidi/widgets/MetronomeHand;

    move-result-object v0

    iget v1, p0, Lnet/duceng/xmidi/Metronome$5;->val$percent:F

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/MetronomeHand;->setPercent(F)V

    .line 118
    return-void
.end method
