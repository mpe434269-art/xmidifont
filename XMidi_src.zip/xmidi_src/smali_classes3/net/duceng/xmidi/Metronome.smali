.class public Lnet/duceng/xmidi/Metronome;
.super Lnet/duceng/xmidi/BaseApp;
.source "Metronome.java"


# static fields
.field private static SPEED:[I


# instance fields
.field private bk:Lnet/duceng/xmidi/widgets/BImage;

.field private hand:Lnet/duceng/xmidi/widgets/MetronomeHand;

.field private mExecutor:Ljava/util/concurrent/ExecutorService;

.field private mRunnable:Ljava/lang/Runnable;

.field private running:Z

.field private speed:Landroid/widget/TextView;

.field private speedName:Landroid/widget/TextView;

.field private speeds:[Ljava/lang/String;

.field private start_btn:Landroid/widget/ImageButton;

.field private tempo:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 17
    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lnet/duceng/xmidi/Metronome;->SPEED:[I

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x3c
        0x42
        0x4c
        0x6c
        0x78
        0xa8
    .end array-data
.end method

.method public constructor <init>()V
    .locals 1

    .line 16
    invoke-direct {p0}, Lnet/duceng/xmidi/BaseApp;-><init>()V

    .line 26
    const/4 v0, 0x4

    iput v0, p0, Lnet/duceng/xmidi/Metronome;->tempo:I

    .line 27
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/Metronome;->running:Z

    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/Metronome;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Metronome;

    .line 16
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->speed:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$100()[I
    .locals 1

    .line 16
    sget-object v0, Lnet/duceng/xmidi/Metronome;->SPEED:[I

    return-object v0
.end method

.method static synthetic access$200(Lnet/duceng/xmidi/Metronome;)[Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Metronome;

    .line 16
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->speeds:[Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$300(Lnet/duceng/xmidi/Metronome;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Metronome;

    .line 16
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->speedName:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$400(Lnet/duceng/xmidi/Metronome;)I
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Metronome;

    .line 16
    iget v0, p0, Lnet/duceng/xmidi/Metronome;->tempo:I

    return v0
.end method

.method static synthetic access$402(Lnet/duceng/xmidi/Metronome;I)I
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Metronome;
    .param p1, "x1"    # I

    .line 16
    iput p1, p0, Lnet/duceng/xmidi/Metronome;->tempo:I

    return p1
.end method

.method static synthetic access$408(Lnet/duceng/xmidi/Metronome;)I
    .locals 2
    .param p0, "x0"    # Lnet/duceng/xmidi/Metronome;

    .line 16
    iget v0, p0, Lnet/duceng/xmidi/Metronome;->tempo:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, Lnet/duceng/xmidi/Metronome;->tempo:I

    return v0
.end method

.method static synthetic access$500(Lnet/duceng/xmidi/Metronome;)Z
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Metronome;

    .line 16
    iget-boolean v0, p0, Lnet/duceng/xmidi/Metronome;->running:Z

    return v0
.end method

.method static synthetic access$502(Lnet/duceng/xmidi/Metronome;Z)Z
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Metronome;
    .param p1, "x1"    # Z

    .line 16
    iput-boolean p1, p0, Lnet/duceng/xmidi/Metronome;->running:Z

    return p1
.end method

.method static synthetic access$600(Lnet/duceng/xmidi/Metronome;)Ljava/lang/Runnable;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Metronome;

    .line 16
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->mRunnable:Ljava/lang/Runnable;

    return-object v0
.end method

.method static synthetic access$700(Lnet/duceng/xmidi/Metronome;)Ljava/util/concurrent/ExecutorService;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Metronome;

    .line 16
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->mExecutor:Ljava/util/concurrent/ExecutorService;

    return-object v0
.end method

.method static synthetic access$800(Lnet/duceng/xmidi/Metronome;)Lnet/duceng/xmidi/widgets/MetronomeHand;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Metronome;

    .line 16
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->hand:Lnet/duceng/xmidi/widgets/MetronomeHand;

    return-object v0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 31
    invoke-super {p0, p1}, Lnet/duceng/xmidi/BaseApp;->onCreate(Landroid/os/Bundle;)V

    .line 32
    const v0, 0x7f050022

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Metronome;->setContentView(I)V

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->title:Landroid/widget/Button;

    const v1, 0x7f060016

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(I)V

    .line 34
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/Metronome;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    .line 35
    iget-object v1, p0, Lnet/duceng/xmidi/Metronome;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v1

    const v2, 0x7f040007

    if-ne v1, v2, :cond_0

    .line 36
    iget-object v1, p0, Lnet/duceng/xmidi/Metronome;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    const v2, 0x7f020007

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setBackgroundResource(I)V

    .line 37
    iget-object v1, p0, Lnet/duceng/xmidi/Metronome;->listMore:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 38
    iget-object v1, p0, Lnet/duceng/xmidi/Metronome;->listMore:Ljava/util/ArrayList;

    add-int/lit8 v3, v0, 0x1

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 39
    goto :goto_1

    .line 34
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 42
    .end local v0    # "i":I
    :cond_1
    :goto_1
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->listTop:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 43
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 44
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->title:Landroid/widget/Button;

    invoke-virtual {p0}, Lnet/duceng/xmidi/Metronome;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x106000d

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setBackgroundColor(I)V

    .line 45
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->title:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setClickable(Z)V

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->title:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setLongClickable(Z)V

    .line 47
    invoke-virtual {p0}, Lnet/duceng/xmidi/Metronome;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010001

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/Metronome;->speeds:[Ljava/lang/String;

    .line 48
    const v0, 0x7f040095

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Metronome;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/widgets/BImage;

    iput-object v0, p0, Lnet/duceng/xmidi/Metronome;->bk:Lnet/duceng/xmidi/widgets/BImage;

    .line 49
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->bk:Lnet/duceng/xmidi/widgets/BImage;

    const v1, 0x7f03004b

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/BImage;->setImageResource(I)V

    .line 50
    const v0, 0x7f04009a

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Metronome;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    iput-object v0, p0, Lnet/duceng/xmidi/Metronome;->start_btn:Landroid/widget/ImageButton;

    .line 51
    const v0, 0x7f040098

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Metronome;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lnet/duceng/xmidi/Metronome;->speed:Landroid/widget/TextView;

    .line 52
    const v0, 0x7f040099

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Metronome;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lnet/duceng/xmidi/Metronome;->speedName:Landroid/widget/TextView;

    .line 53
    const v0, 0x7f040096

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Metronome;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/widgets/MetronomeHand;

    iput-object v0, p0, Lnet/duceng/xmidi/Metronome;->hand:Lnet/duceng/xmidi/widgets/MetronomeHand;

    .line 54
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->hand:Lnet/duceng/xmidi/widgets/MetronomeHand;

    new-instance v1, Lnet/duceng/xmidi/Metronome$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Metronome$1;-><init>(Lnet/duceng/xmidi/Metronome;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/MetronomeHand;->setSpeedListener(Lnet/duceng/xmidi/widgets/MetronomeHand$SpeedListener;)V

    .line 68
    const v0, 0x7f04009b

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Metronome;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 69
    .local v0, "textTempo":Landroid/widget/TextView;
    iget-object v1, p0, Lnet/duceng/xmidi/Metronome;->start_btn:Landroid/widget/ImageButton;

    new-instance v2, Lnet/duceng/xmidi/Metronome$2;

    invoke-direct {v2, p0, v0}, Lnet/duceng/xmidi/Metronome$2;-><init>(Lnet/duceng/xmidi/Metronome;Landroid/widget/TextView;)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 80
    iget-object v1, p0, Lnet/duceng/xmidi/Metronome;->hand:Lnet/duceng/xmidi/widgets/MetronomeHand;

    new-instance v2, Lnet/duceng/xmidi/Metronome$3;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/Metronome$3;-><init>(Lnet/duceng/xmidi/Metronome;)V

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/widgets/MetronomeHand;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 93
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/Metronome;->mExecutor:Ljava/util/concurrent/ExecutorService;

    .line 94
    new-instance v1, Lnet/duceng/xmidi/Metronome$4;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/Metronome$4;-><init>(Lnet/duceng/xmidi/Metronome;)V

    iput-object v1, p0, Lnet/duceng/xmidi/Metronome;->mRunnable:Ljava/lang/Runnable;

    .line 110
    return-void
.end method

.method protected onDestroy()V
    .locals 1

    .line 124
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/Metronome;->running:Z

    .line 125
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->mExecutor:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    .line 126
    invoke-super {p0}, Lnet/duceng/xmidi/BaseApp;->onDestroy()V

    .line 127
    return-void
.end method

.method protected onStart()V
    .locals 4

    .line 131
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->synth:Lnet/duceng/xsynth/Synth;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setFile(Ljava/io/File;)V

    .line 132
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->synth:Lnet/duceng/xsynth/Synth;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setBeating(Z)V

    .line 133
    iget-object v0, p0, Lnet/duceng/xmidi/Metronome;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MetaTempo;->getBpm()I

    move-result v0

    .line 134
    .local v0, "bpm":I
    iget-object v1, p0, Lnet/duceng/xmidi/Metronome;->speed:Landroid/widget/TextView;

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 135
    const/4 v1, 0x0

    .line 136
    .local v1, "idx":I
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    sget-object v3, Lnet/duceng/xmidi/Metronome;->SPEED:[I

    array-length v3, v3

    if-ge v2, v3, :cond_0

    sget-object v3, Lnet/duceng/xmidi/Metronome;->SPEED:[I

    aget v3, v3, v2

    if-le v0, v3, :cond_0

    .line 137
    move v1, v2

    .line 136
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 139
    .end local v2    # "i":I
    :cond_0
    iget-object v2, p0, Lnet/duceng/xmidi/Metronome;->speedName:Landroid/widget/TextView;

    iget-object v3, p0, Lnet/duceng/xmidi/Metronome;->speeds:[Ljava/lang/String;

    aget-object v3, v3, v1

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 140
    invoke-super {p0}, Lnet/duceng/xmidi/BaseApp;->onStart()V

    .line 141
    return-void
.end method

.method public setPercent(F)V
    .locals 1
    .param p1, "percent"    # F

    .line 114
    new-instance v0, Lnet/duceng/xmidi/Metronome$5;

    invoke-direct {v0, p0, p1}, Lnet/duceng/xmidi/Metronome$5;-><init>(Lnet/duceng/xmidi/Metronome;F)V

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/Metronome;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 120
    return-void
.end method
