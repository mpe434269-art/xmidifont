.class Lnet/duceng/xmidi/Settings$1$1;
.super Ljava/lang/Object;
.source "Settings.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogPercussion$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Settings$1;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/Settings$1;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Settings$1;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/Settings$1;

    .line 70
    iput-object p1, p0, Lnet/duceng/xmidi/Settings$1$1;->this$1:Lnet/duceng/xmidi/Settings$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(I)Z
    .locals 4
    .param p1, "idx"    # I

    .line 73
    iget-object v0, p0, Lnet/duceng/xmidi/Settings$1$1;->this$1:Lnet/duceng/xmidi/Settings$1;

    iget-object v0, v0, Lnet/duceng/xmidi/Settings$1;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v0}, Lnet/duceng/xmidi/Settings;->access$000(Lnet/duceng/xmidi/Settings;)Landroid/widget/Button;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/Settings$1$1;->this$1:Lnet/duceng/xmidi/Settings$1;

    iget-object v1, v1, Lnet/duceng/xmidi/Settings$1;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v1}, Lnet/duceng/xmidi/Settings;->access$200(Lnet/duceng/xmidi/Settings;)[Ljava/lang/String;

    move-result-object v1

    aget-object v1, v1, p1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 74
    sget-byte v0, Lnet/duceng/xmidi/Settings;->DRUMS_BASE:B

    add-int/2addr v0, p1

    int-to-byte v0, v0

    .line 75
    .local v0, "n":B
    iget-object v1, p0, Lnet/duceng/xmidi/Settings$1$1;->this$1:Lnet/duceng/xmidi/Settings$1;

    iget-object v1, v1, Lnet/duceng/xmidi/Settings$1;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v1}, Lnet/duceng/xmidi/Settings;->access$300(Lnet/duceng/xmidi/Settings;)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    .line 76
    .local v1, "editor":Landroid/content/SharedPreferences$Editor;
    iget-object v2, p0, Lnet/duceng/xmidi/Settings$1$1;->this$1:Lnet/duceng/xmidi/Settings$1;

    iget-object v2, v2, Lnet/duceng/xmidi/Settings$1;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v2}, Lnet/duceng/xmidi/Settings;->access$000(Lnet/duceng/xmidi/Settings;)Landroid/widget/Button;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Button;->getId()I

    move-result v2

    const v3, 0x7f0400b3

    if-ne v2, v3, :cond_0

    .line 77
    iget-object v2, p0, Lnet/duceng/xmidi/Settings$1$1;->this$1:Lnet/duceng/xmidi/Settings$1;

    iget-object v2, v2, Lnet/duceng/xmidi/Settings$1;->this$0:Lnet/duceng/xmidi/Settings;

    iget-object v2, v2, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2, v0}, Lnet/duceng/xsynth/Synth;->setBeatNote1(B)V

    .line 78
    sget-object v2, Lnet/duceng/xmidi/Settings;->SYNTH_BEATNOTE1:Ljava/lang/String;

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_0

    .line 80
    :cond_0
    iget-object v2, p0, Lnet/duceng/xmidi/Settings$1$1;->this$1:Lnet/duceng/xmidi/Settings$1;

    iget-object v2, v2, Lnet/duceng/xmidi/Settings$1;->this$0:Lnet/duceng/xmidi/Settings;

    iget-object v2, v2, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2, v0}, Lnet/duceng/xsynth/Synth;->setBeatNote2(B)V

    .line 81
    sget-object v2, Lnet/duceng/xmidi/Settings;->SYNTH_BEATNOTE2:Ljava/lang/String;

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 83
    :goto_0
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 84
    iget-object v2, p0, Lnet/duceng/xmidi/Settings$1$1;->this$1:Lnet/duceng/xmidi/Settings$1;

    iget-object v2, v2, Lnet/duceng/xmidi/Settings$1;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v2}, Lnet/duceng/xmidi/Settings;->access$100(Lnet/duceng/xmidi/Settings;)Lnet/duceng/xmidi/ui/DialogPercussion;

    move-result-object v2

    invoke-virtual {v2}, Lnet/duceng/xmidi/ui/DialogPercussion;->dismiss()V

    .line 85
    const/4 v2, 0x1

    return v2
.end method
