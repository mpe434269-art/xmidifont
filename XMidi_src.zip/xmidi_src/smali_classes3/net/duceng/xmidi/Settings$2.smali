.class Lnet/duceng/xmidi/Settings$2;
.super Ljava/lang/Object;
.source "Settings.java"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Settings;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Settings;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Settings;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Settings;

    .line 92
    iput-object p1, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 6
    .param p1, "v"    # Landroid/widget/CompoundButton;
    .param p2, "isChecked"    # Z

    .line 95
    const/4 v0, 0x0

    .line 96
    .local v0, "idx":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v1}, Lnet/duceng/xmidi/Settings;->access$400(Lnet/duceng/xmidi/Settings;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v1}, Lnet/duceng/xmidi/Settings;->access$400(Lnet/duceng/xmidi/Settings;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 97
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 99
    :cond_0
    invoke-virtual {p1}, Landroid/widget/CompoundButton;->getTag()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/io/File;

    .line 100
    .local v1, "sfont":Ljava/io/File;
    iget-object v2, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v2}, Lnet/duceng/xmidi/Settings;->access$300(Lnet/duceng/xmidi/Settings;)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    .line 101
    .local v2, "editor":Landroid/content/SharedPreferences$Editor;
    if-eqz p2, :cond_1

    .line 102
    iget-object v3, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v3}, Lnet/duceng/xmidi/Settings;->access$500(Lnet/duceng/xmidi/Settings;)Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/widget/RadioButton;

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Landroid/widget/RadioButton;->setEnabled(Z)V

    .line 103
    iget-object v3, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v3}, Lnet/duceng/xmidi/Settings;->access$600(Lnet/duceng/xmidi/Settings;)Ljava/util/Set;

    move-result-object v3

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 105
    :cond_1
    iget-object v3, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v3}, Lnet/duceng/xmidi/Settings;->access$500(Lnet/duceng/xmidi/Settings;)Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/widget/RadioButton;

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroid/widget/RadioButton;->setEnabled(Z)V

    .line 106
    iget-object v3, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v3}, Lnet/duceng/xmidi/Settings;->access$600(Lnet/duceng/xmidi/Settings;)Ljava/util/Set;

    move-result-object v3

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 108
    :goto_1
    sget-object v3, Lnet/duceng/xmidi/Settings;->SYNTH_SFONTS:Ljava/lang/String;

    iget-object v4, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    iget-object v5, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v5}, Lnet/duceng/xmidi/Settings;->access$600(Lnet/duceng/xmidi/Settings;)Ljava/util/Set;

    move-result-object v5

    invoke-virtual {v4, v5}, Lnet/duceng/xmidi/Settings;->join(Ljava/util/Set;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 109
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 110
    iget-object v3, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    iget-object v3, v3, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v3}, Lnet/duceng/xsynth/Synth;->getSFonts()Lnet/duceng/xmidi/util/MyArray;

    move-result-object v3

    .line 111
    .local v3, "synthfonts":Lnet/duceng/xmidi/util/MyArray;, "Lnet/duceng/xmidi/util/MyArray<Ljava/io/File;>;"
    invoke-virtual {v3, v1}, Lnet/duceng/xmidi/util/MyArray;->indexOfValue(Ljava/lang/Object;)I

    move-result v4

    .line 112
    .local v4, "index":I
    if-eqz p2, :cond_2

    if-gez v4, :cond_2

    .line 113
    iget-object v5, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    iget-object v5, v5, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v5, v1}, Lnet/duceng/xsynth/Synth;->loadSFont(Ljava/io/File;)I

    goto :goto_2

    .line 114
    :cond_2
    if-nez p2, :cond_3

    if-ltz v4, :cond_3

    .line 115
    iget-object v5, p0, Lnet/duceng/xmidi/Settings$2;->this$0:Lnet/duceng/xmidi/Settings;

    iget-object v5, v5, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v5, v1}, Lnet/duceng/xsynth/Synth;->unloadSFont(Ljava/io/File;)V

    .line 117
    :cond_3
    :goto_2
    return-void
.end method
