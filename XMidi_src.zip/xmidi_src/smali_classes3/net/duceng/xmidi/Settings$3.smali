.class Lnet/duceng/xmidi/Settings$3;
.super Ljava/lang/Object;
.source "Settings.java"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Settings;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Settings;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Settings;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Settings;

    .line 119
    iput-object p1, p0, Lnet/duceng/xmidi/Settings$3;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 7
    .param p1, "v"    # Landroid/widget/CompoundButton;
    .param p2, "isChecked"    # Z

    .line 122
    if-eqz p2, :cond_0

    .line 123
    invoke-virtual {p1}, Landroid/widget/CompoundButton;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/io/File;

    .line 124
    .local v0, "sfont":Ljava/io/File;
    iget-object v1, p0, Lnet/duceng/xmidi/Settings$3;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v1}, Lnet/duceng/xmidi/Settings;->access$300(Lnet/duceng/xmidi/Settings;)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    .line 125
    .local v1, "editor":Landroid/content/SharedPreferences$Editor;
    sget-object v2, Lnet/duceng/xmidi/Settings;->SYNTH_SFONT_DEFAULT:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 126
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 127
    iget-object v2, p0, Lnet/duceng/xmidi/Settings$3;->this$0:Lnet/duceng/xmidi/Settings;

    iget-object v2, v2, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->getSFonts()Lnet/duceng/xmidi/util/MyArray;

    move-result-object v2

    .line 128
    .local v2, "synthfonts":Lnet/duceng/xmidi/util/MyArray;, "Lnet/duceng/xmidi/util/MyArray<Ljava/io/File;>;"
    invoke-virtual {v2, v0}, Lnet/duceng/xmidi/util/MyArray;->indexOfValue(Ljava/lang/Object;)I

    move-result v3

    .line 129
    .local v3, "idx":I
    if-ltz v3, :cond_0

    .line 130
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_0
    const/16 v5, 0x10

    if-ge v4, v5, :cond_0

    .line 131
    iget-object v5, p0, Lnet/duceng/xmidi/Settings$3;->this$0:Lnet/duceng/xmidi/Settings;

    iget-object v5, v5, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2, v3}, Lnet/duceng/xmidi/util/MyArray;->keyAt(I)I

    move-result v6

    invoke-virtual {v5, v4, v6}, Lnet/duceng/xsynth/Synth;->setSFont(II)V

    .line 130
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 135
    .end local v0    # "sfont":Ljava/io/File;
    .end local v1    # "editor":Landroid/content/SharedPreferences$Editor;
    .end local v2    # "synthfonts":Lnet/duceng/xmidi/util/MyArray;, "Lnet/duceng/xmidi/util/MyArray<Ljava/io/File;>;"
    .end local v3    # "idx":I
    .end local v4    # "i":I
    :cond_0
    return-void
.end method
