.class Lnet/duceng/xmidi/Settings$3;
.super Ljava/lang/Object;
.source "Settings.java"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Settings;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Settings;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Settings;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Settings;

    .line 119
    iput-object p1, p0, Lnet/duceng/xmidi/Settings$3;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 0
    .param p1, "v"    # Landroid/widget/CompoundButton;
    .param p2, "isChecked"    # Z

    return-void
.end method
