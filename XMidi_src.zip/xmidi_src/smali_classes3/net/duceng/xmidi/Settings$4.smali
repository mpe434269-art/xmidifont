.class Lnet/duceng/xmidi/Settings$4;
.super Ljava/lang/Object;
.source "Settings.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/Settings;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Settings;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Settings;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Settings;

    .line 137
    iput-object p1, p0, Lnet/duceng/xmidi/Settings$4;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    iget-object v0, p0, Lnet/duceng/xmidi/Settings$4;->this$0:Lnet/duceng/xmidi/Settings;

    check-cast p1, Landroid/widget/RadioButton;

    invoke-static {v0, p1}, Lnet/duceng/xmidi/Settings;->xmRadioClick(Lnet/duceng/xmidi/Settings;Landroid/widget/RadioButton;)V

    return-void
.end method
