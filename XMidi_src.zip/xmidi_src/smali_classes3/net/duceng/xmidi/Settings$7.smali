.class Lnet/duceng/xmidi/Settings$7;
.super Ljava/lang/Object;
.source "Settings.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Settings;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Settings;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Settings;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Settings;

    .line 204
    iput-object p1, p0, Lnet/duceng/xmidi/Settings$7;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 3
    .param p1, "arg0"    # Landroid/widget/SeekBar;
    .param p2, "progress"    # I
    .param p3, "arg2"    # Z

    .line 207
    add-int/lit8 v0, p2, 0x10

    .line 208
    .local v0, "v":I
    iget-object v1, p0, Lnet/duceng/xmidi/Settings$7;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v1}, Lnet/duceng/xmidi/Settings;->access$800(Lnet/duceng/xmidi/Settings;)Landroid/widget/TextView;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 209
    iget-object v1, p0, Lnet/duceng/xmidi/Settings$7;->this$0:Lnet/duceng/xmidi/Settings;

    iget-object v1, v1, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1, v0}, Lnet/duceng/xsynth/Synth;->setPolyphony(I)V

    .line 210
    iget-object v1, p0, Lnet/duceng/xmidi/Settings$7;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v1}, Lnet/duceng/xmidi/Settings;->access$300(Lnet/duceng/xmidi/Settings;)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    .line 211
    .local v1, "editor":Landroid/content/SharedPreferences$Editor;
    sget-object v2, Lnet/duceng/xmidi/Settings;->SYNTH_POLYPHONY:Ljava/lang/String;

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 212
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 213
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 217
    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 221
    return-void
.end method
