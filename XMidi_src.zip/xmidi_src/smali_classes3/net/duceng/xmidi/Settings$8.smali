.class Lnet/duceng/xmidi/Settings$8;
.super Ljava/lang/Object;
.source "Settings.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Settings;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Settings;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Settings;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Settings;

    .line 236
    iput-object p1, p0, Lnet/duceng/xmidi/Settings$8;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 2
    .param p1, "arg0"    # Landroid/widget/SeekBar;
    .param p2, "progress"    # I
    .param p3, "arg2"    # Z

    .line 239
    iget-object v0, p0, Lnet/duceng/xmidi/Settings$8;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v0}, Lnet/duceng/xmidi/Settings;->access$900(Lnet/duceng/xmidi/Settings;)Landroid/widget/TextView;

    move-result-object v0

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 240
    iget-object v0, p0, Lnet/duceng/xmidi/Settings$8;->this$0:Lnet/duceng/xmidi/Settings;

    iget-object v0, v0, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    int-to-byte v1, p2

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setBeatVelocity(B)V

    .line 241
    iget-object v0, p0, Lnet/duceng/xmidi/Settings$8;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {v0}, Lnet/duceng/xmidi/Settings;->access$300(Lnet/duceng/xmidi/Settings;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 242
    .local v0, "editor":Landroid/content/SharedPreferences$Editor;
    sget-object v1, Lnet/duceng/xmidi/Settings;->SYNTH_BEATVEL:Ljava/lang/String;

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 243
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 244
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 248
    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 252
    return-void
.end method
