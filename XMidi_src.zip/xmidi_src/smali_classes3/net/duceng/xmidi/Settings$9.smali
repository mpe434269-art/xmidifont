.class Lnet/duceng/xmidi/Settings$9;
.super Ljava/lang/Object;
.source "Settings.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/Settings;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/Settings;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/Settings;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/Settings;

    .line 262
    iput-object p1, p0, Lnet/duceng/xmidi/Settings$9;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 265
    iget-object v0, p0, Lnet/duceng/xmidi/Settings$9;->this$0:Lnet/duceng/xmidi/Settings;

    invoke-static {}, Lnet/duceng/xmidi/util/Importer;->pickIntent()Landroid/content/Intent;

    move-result-object v1

    const/16 v2, 0x1006

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xmidi/Settings;->startActivityForResult(Landroid/content/Intent;I)V

    .line 266
    return-void
.end method
