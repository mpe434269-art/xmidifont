.class public Lnet/duceng/xmidi/Settings;
.super Lnet/duceng/xmidi/Base;
.source "Settings.java"


# static fields
.field public static DRUMS_BASE:B

.field public static SYNTH_BEATNOTE1:Ljava/lang/String;

.field public static SYNTH_BEATNOTE2:Ljava/lang/String;

.field public static SYNTH_BEATVEL:Ljava/lang/String;

.field public static SYNTH_GAIN:Ljava/lang/String;

.field public static SYNTH_INIT:Ljava/lang/String;

.field public static SYNTH_POLYPHONY:Ljava/lang/String;

.field public static SYNTH_SFONTS:Ljava/lang/String;

.field public static SYNTH_SFONT_DEFAULT:Ljava/lang/String;

.field public static SYNTH_SFONT_DEFAULT_VAL:Ljava/lang/String;


# instance fields
.field private channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

.field private checkChangeListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

.field private dialogSynth:Lnet/duceng/xmidi/ui/DialogMidi;

.field private gain_seek:Landroid/widget/SeekBar;

.field private gain_value:Landroid/widget/TextView;

.field private metroBtn:Landroid/widget/Button;

.field private metroDialog:Lnet/duceng/xmidi/ui/DialogPercussion;

.field private metronome1:Landroid/widget/Button;

.field private metronome2:Landroid/widget/Button;

.field private metronomeClickListener:Landroid/view/View$OnClickListener;

.field private metronome_seek:Landroid/widget/SeekBar;

.field private metronome_velocity:Landroid/widget/TextView;

.field private percussions:[Ljava/lang/String;

.field private polyphony_seek:Landroid/widget/SeekBar;

.field private polyphony_value:Landroid/widget/TextView;

.field private pref:Landroid/content/SharedPreferences;

.field private radioChangeListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

.field private radioClickListener:Landroid/view/View$OnClickListener;

.field private sfonts:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private sfonts_check:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/widget/CheckBox;",
            ">;"
        }
    .end annotation
.end field

.field private sfonts_radio:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/widget/RadioButton;",
            ">;"
        }
    .end annotation
.end field

.field protected synth:Lnet/duceng/xsynth/Synth;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 51
    const-string v0, "synth_init"

    sput-object v0, Lnet/duceng/xmidi/Settings;->SYNTH_INIT:Ljava/lang/String;

    .line 52
    const-string v0, "synth_gain"

    sput-object v0, Lnet/duceng/xmidi/Settings;->SYNTH_GAIN:Ljava/lang/String;

    .line 53
    const-string v0, "synth_polyphony"

    sput-object v0, Lnet/duceng/xmidi/Settings;->SYNTH_POLYPHONY:Ljava/lang/String;

    .line 54
    const-string v0, "synth_beatNote1"

    sput-object v0, Lnet/duceng/xmidi/Settings;->SYNTH_BEATNOTE1:Ljava/lang/String;

    .line 55
    const-string v0, "synth_beatNote2"

    sput-object v0, Lnet/duceng/xmidi/Settings;->SYNTH_BEATNOTE2:Ljava/lang/String;

    .line 56
    const-string v0, "synth_beatVelocity"

    sput-object v0, Lnet/duceng/xmidi/Settings;->SYNTH_BEATVEL:Ljava/lang/String;

    .line 57
    const-string v0, "synth_sfonts"

    sput-object v0, Lnet/duceng/xmidi/Settings;->SYNTH_SFONTS:Ljava/lang/String;

    .line 58
    const-string v0, "synth_sfont_default"

    sput-object v0, Lnet/duceng/xmidi/Settings;->SYNTH_SFONT_DEFAULT:Ljava/lang/String;

    .line 59
    const-string v0, "TimGM6mb.sf2"

    sput-object v0, Lnet/duceng/xmidi/Settings;->SYNTH_SFONT_DEFAULT_VAL:Ljava/lang/String;

    .line 60
    const/16 v0, 0x1b

    sput-byte v0, Lnet/duceng/xmidi/Settings;->DRUMS_BASE:B

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 34
    invoke-direct {p0}, Lnet/duceng/xmidi/Base;-><init>()V

    .line 61
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/Settings;->sfonts_check:Ljava/util/ArrayList;

    .line 62
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/Settings;->sfonts_radio:Ljava/util/ArrayList;

    .line 63
    new-instance v0, Lnet/duceng/xmidi/Settings$1;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Settings$1;-><init>(Lnet/duceng/xmidi/Settings;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Settings;->metronomeClickListener:Landroid/view/View$OnClickListener;

    .line 92
    new-instance v0, Lnet/duceng/xmidi/Settings$2;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Settings$2;-><init>(Lnet/duceng/xmidi/Settings;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Settings;->checkChangeListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    .line 119
    new-instance v0, Lnet/duceng/xmidi/Settings$3;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Settings$3;-><init>(Lnet/duceng/xmidi/Settings;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Settings;->radioChangeListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    .line 137
    new-instance v0, Lnet/duceng/xmidi/Settings$4;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/Settings$4;-><init>(Lnet/duceng/xmidi/Settings;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Settings;->radioClickListener:Landroid/view/View$OnClickListener;

    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/Settings;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->metroBtn:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$002(Lnet/duceng/xmidi/Settings;Landroid/widget/Button;)Landroid/widget/Button;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;
    .param p1, "x1"    # Landroid/widget/Button;

    .line 34
    iput-object p1, p0, Lnet/duceng/xmidi/Settings;->metroBtn:Landroid/widget/Button;

    return-object p1
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/Settings;)Lnet/duceng/xmidi/ui/DialogPercussion;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->metroDialog:Lnet/duceng/xmidi/ui/DialogPercussion;

    return-object v0
.end method

.method static synthetic access$102(Lnet/duceng/xmidi/Settings;Lnet/duceng/xmidi/ui/DialogPercussion;)Lnet/duceng/xmidi/ui/DialogPercussion;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;
    .param p1, "x1"    # Lnet/duceng/xmidi/ui/DialogPercussion;

    .line 34
    iput-object p1, p0, Lnet/duceng/xmidi/Settings;->metroDialog:Lnet/duceng/xmidi/ui/DialogPercussion;

    return-object p1
.end method

.method static synthetic access$200(Lnet/duceng/xmidi/Settings;)[Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->percussions:[Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$300(Lnet/duceng/xmidi/Settings;)Landroid/content/SharedPreferences;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->pref:Landroid/content/SharedPreferences;

    return-object v0
.end method

.method static synthetic access$400(Lnet/duceng/xmidi/Settings;)Ljava/util/ArrayList;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->sfonts_check:Ljava/util/ArrayList;

    return-object v0
.end method

.method static synthetic access$500(Lnet/duceng/xmidi/Settings;)Ljava/util/ArrayList;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->sfonts_radio:Ljava/util/ArrayList;

    return-object v0
.end method

.method static synthetic access$600(Lnet/duceng/xmidi/Settings;)Ljava/util/Set;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->sfonts:Ljava/util/Set;

    return-object v0
.end method

.method static synthetic access$700(Lnet/duceng/xmidi/Settings;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->gain_value:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$800(Lnet/duceng/xmidi/Settings;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->polyphony_value:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$900(Lnet/duceng/xmidi/Settings;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/Settings;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->metronome_velocity:Landroid/widget/TextView;

    return-object v0
.end method

.method private split(Ljava/lang/String;)Ljava/util/Set;
    .locals 4
    .param p1, "str"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 311
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 313
    .local v0, "set":Ljava/util/HashSet;, "Ljava/util/HashSet<Ljava/lang/String;>;"
    :try_start_0
    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1, p1}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 314
    .local v1, "ja":Lorg/json/JSONArray;
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_0

    .line 315
    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 314
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 319
    .end local v1    # "ja":Lorg/json/JSONArray;
    .end local v2    # "i":I
    :cond_0
    goto :goto_1

    .line 317
    :catch_0
    move-exception v1

    .line 318
    .local v1, "e":Lorg/json/JSONException;
    invoke-virtual {v1}, Lorg/json/JSONException;->printStackTrace()V

    .line 320
    .end local v1    # "e":Lorg/json/JSONException;
    :goto_1
    return-object v0
.end method


# virtual methods
.method public join(Ljava/util/Set;)Ljava/lang/String;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 306
    .local p1, "set":Ljava/util/Set;, "Ljava/util/Set<Ljava/lang/String;>;"
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0, p1}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    .line 307
    .local v0, "ja":Lorg/json/JSONArray;
    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method protected onActionClick(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 336
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    packed-switch v0, :pswitch_data_0

    .line 350
    invoke-super {p0, p1}, Lnet/duceng/xmidi/Base;->onActionClick(Landroid/view/View;)V

    goto :goto_0

    .line 344
    :pswitch_0
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->dialogSynth:Lnet/duceng/xmidi/ui/DialogMidi;

    if-nez v0, :cond_0

    .line 345
    new-instance v0, Lnet/duceng/xmidi/ui/DialogMidi;

    iget-object v1, p0, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, p0, v1}, Lnet/duceng/xmidi/ui/DialogMidi;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Settings;->dialogSynth:Lnet/duceng/xmidi/ui/DialogMidi;

    .line 347
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->dialogSynth:Lnet/duceng/xmidi/ui/DialogMidi;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogMidi;->show()V

    .line 348
    goto :goto_0

    .line 338
    :pswitch_1
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    if-nez v0, :cond_1

    .line 339
    new-instance v0, Lnet/duceng/xmidi/ui/DialogChannel;

    iget-object v1, p0, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, p0, v1}, Lnet/duceng/xmidi/ui/DialogChannel;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/Settings;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    .line 341
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->channDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogChannel;->show()V

    .line 342
    nop

    .line 353
    :goto_0
    return-void

    :pswitch_data_0
    .packed-switch 0x7f040011
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 7
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .line 150
    invoke-super {p0, p1, p2, p3}, Lnet/duceng/xmidi/Base;->onActivityResult(IILandroid/content/Intent;)V

    .line 151
    const/16 v0, 0x1006

    if-ne p1, v0, :cond_1

    const/4 v0, -0x1

    if-ne p2, v0, :cond_1

    if-eqz p3, :cond_1

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 154
    :cond_0
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v2

    new-instance v3, Ljava/io/File;

    sget-object v0, Lnet/duceng/xsynth/Synth;->PATH_FONT:Ljava/lang/String;

    invoke-direct {v3, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const-string v0, "sf2"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v4

    new-instance v6, Lnet/duceng/xmidi/Settings$5;

    invoke-direct {v6, p0}, Lnet/duceng/xmidi/Settings$5;-><init>(Lnet/duceng/xmidi/Settings;)V

    const-string v5, "sf2"

    move-object v1, p0

    invoke-static/range {v1 .. v6}, Lnet/duceng/xmidi/util/Importer;->importAsync(Landroid/app/Activity;Landroid/net/Uri;Ljava/io/File;[Ljava/lang/String;Ljava/lang/String;Lnet/duceng/xmidi/util/Importer$Callback;)V

    .line 165
    return-void

    .line 152
    :cond_1
    :goto_0
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 20
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 169
    move-object/from16 v0, p0

    invoke-super/range {p0 .. p1}, Lnet/duceng/xmidi/Base;->onCreate(Landroid/os/Bundle;)V

    .line 170
    invoke-static {}, Lnet/duceng/xsynth/Synth;->getInstance()Lnet/duceng/xsynth/Synth;

    move-result-object v1

    iput-object v1, v0, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    .line 171
    const v1, 0x7f050023

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/Settings;->setContentView(I)V

    .line 172
    iget-object v1, v0, Lnet/duceng/xmidi/Settings;->title:Landroid/widget/Button;

    const v2, 0x7f060024

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(I)V

    .line 173
    invoke-static/range {p0 .. p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v1

    iput-object v1, v0, Lnet/duceng/xmidi/Settings;->pref:Landroid/content/SharedPreferences;

    .line 174
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/Settings;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f010005

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lnet/duceng/xmidi/Settings;->percussions:[Ljava/lang/String;

    .line 175
    const v1, 0x7f0400b2

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/Settings;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, v0, Lnet/duceng/xmidi/Settings;->gain_value:Landroid/widget/TextView;

    .line 176
    const v1, 0x7f0400b1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/Settings;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    iput-object v1, v0, Lnet/duceng/xmidi/Settings;->gain_seek:Landroid/widget/SeekBar;

    .line 177
    iget-object v1, v0, Lnet/duceng/xmidi/Settings;->pref:Landroid/content/SharedPreferences;

    sget-object v2, Lnet/duceng/xmidi/Settings;->SYNTH_GAIN:Ljava/lang/String;

    const/4 v3, 0x3

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    .line 178
    .local v1, "gain":I
    iget-object v2, v0, Lnet/duceng/xmidi/Settings;->gain_value:Landroid/widget/TextView;

    int-to-float v3, v1

    const/high16 v4, 0x41200000    # 10.0f

    div-float/2addr v3, v4

    invoke-static {v3}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 179
    iget-object v2, v0, Lnet/duceng/xmidi/Settings;->gain_seek:Landroid/widget/SeekBar;

    invoke-virtual {v2, v1}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 180
    iget-object v2, v0, Lnet/duceng/xmidi/Settings;->gain_seek:Landroid/widget/SeekBar;

    new-instance v3, Lnet/duceng/xmidi/Settings$6;

    invoke-direct {v3, v0}, Lnet/duceng/xmidi/Settings$6;-><init>(Lnet/duceng/xmidi/Settings;)V

    invoke-virtual {v2, v3}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 199
    const v2, 0x7f0400b8

    invoke-virtual {v0, v2}, Lnet/duceng/xmidi/Settings;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Lnet/duceng/xmidi/Settings;->polyphony_value:Landroid/widget/TextView;

    .line 200
    const v2, 0x7f0400b7

    invoke-virtual {v0, v2}, Lnet/duceng/xmidi/Settings;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/SeekBar;

    iput-object v2, v0, Lnet/duceng/xmidi/Settings;->polyphony_seek:Landroid/widget/SeekBar;

    .line 201
    iget-object v2, v0, Lnet/duceng/xmidi/Settings;->pref:Landroid/content/SharedPreferences;

    sget-object v3, Lnet/duceng/xmidi/Settings;->SYNTH_POLYPHONY:Ljava/lang/String;

    const/16 v4, 0x80

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    .line 202
    .local v2, "polyphony":I
    iget-object v3, v0, Lnet/duceng/xmidi/Settings;->polyphony_value:Landroid/widget/TextView;

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 203
    iget-object v3, v0, Lnet/duceng/xmidi/Settings;->polyphony_seek:Landroid/widget/SeekBar;

    add-int/lit8 v4, v2, -0x10

    invoke-virtual {v3, v4}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 204
    iget-object v3, v0, Lnet/duceng/xmidi/Settings;->polyphony_seek:Landroid/widget/SeekBar;

    new-instance v4, Lnet/duceng/xmidi/Settings$7;

    invoke-direct {v4, v0}, Lnet/duceng/xmidi/Settings$7;-><init>(Lnet/duceng/xmidi/Settings;)V

    invoke-virtual {v3, v4}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 223
    const v3, 0x7f0400b3

    invoke-virtual {v0, v3}, Lnet/duceng/xmidi/Settings;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    iput-object v3, v0, Lnet/duceng/xmidi/Settings;->metronome1:Landroid/widget/Button;

    .line 224
    const v3, 0x7f0400b4

    invoke-virtual {v0, v3}, Lnet/duceng/xmidi/Settings;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    iput-object v3, v0, Lnet/duceng/xmidi/Settings;->metronome2:Landroid/widget/Button;

    .line 225
    iget-object v3, v0, Lnet/duceng/xmidi/Settings;->pref:Landroid/content/SharedPreferences;

    sget-object v4, Lnet/duceng/xmidi/Settings;->SYNTH_BEATNOTE1:Ljava/lang/String;

    const/16 v5, 0x22

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    .line 226
    .local v3, "bnote1":I
    iget-object v4, v0, Lnet/duceng/xmidi/Settings;->pref:Landroid/content/SharedPreferences;

    sget-object v5, Lnet/duceng/xmidi/Settings;->SYNTH_BEATNOTE2:Ljava/lang/String;

    const/16 v6, 0x21

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    .line 227
    .local v4, "bnote2":I
    iget-object v5, v0, Lnet/duceng/xmidi/Settings;->metronome1:Landroid/widget/Button;

    iget-object v6, v0, Lnet/duceng/xmidi/Settings;->percussions:[Ljava/lang/String;

    sget-byte v7, Lnet/duceng/xmidi/Settings;->DRUMS_BASE:B

    sub-int v7, v3, v7

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 228
    iget-object v5, v0, Lnet/duceng/xmidi/Settings;->metronome2:Landroid/widget/Button;

    iget-object v6, v0, Lnet/duceng/xmidi/Settings;->percussions:[Ljava/lang/String;

    sget-byte v7, Lnet/duceng/xmidi/Settings;->DRUMS_BASE:B

    sub-int v7, v4, v7

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 229
    iget-object v5, v0, Lnet/duceng/xmidi/Settings;->metronome1:Landroid/widget/Button;

    iget-object v6, v0, Lnet/duceng/xmidi/Settings;->metronomeClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 230
    iget-object v5, v0, Lnet/duceng/xmidi/Settings;->metronome2:Landroid/widget/Button;

    iget-object v6, v0, Lnet/duceng/xmidi/Settings;->metronomeClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 231
    const v5, 0x7f0400b6

    invoke-virtual {v0, v5}, Lnet/duceng/xmidi/Settings;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    iput-object v5, v0, Lnet/duceng/xmidi/Settings;->metronome_velocity:Landroid/widget/TextView;

    .line 232
    const v5, 0x7f0400b5

    invoke-virtual {v0, v5}, Lnet/duceng/xmidi/Settings;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/SeekBar;

    iput-object v5, v0, Lnet/duceng/xmidi/Settings;->metronome_seek:Landroid/widget/SeekBar;

    .line 233
    iget-object v5, v0, Lnet/duceng/xmidi/Settings;->pref:Landroid/content/SharedPreferences;

    sget-object v6, Lnet/duceng/xmidi/Settings;->SYNTH_BEATVEL:Ljava/lang/String;

    const/16 v7, 0x4b

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v5

    .line 234
    .local v5, "velocity":I
    iget-object v6, v0, Lnet/duceng/xmidi/Settings;->metronome_velocity:Landroid/widget/TextView;

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 235
    iget-object v6, v0, Lnet/duceng/xmidi/Settings;->metronome_seek:Landroid/widget/SeekBar;

    invoke-virtual {v6, v5}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 236
    iget-object v6, v0, Lnet/duceng/xmidi/Settings;->metronome_seek:Landroid/widget/SeekBar;

    new-instance v7, Lnet/duceng/xmidi/Settings$8;

    invoke-direct {v7, v0}, Lnet/duceng/xmidi/Settings$8;-><init>(Lnet/duceng/xmidi/Settings;)V

    invoke-virtual {v6, v7}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 254
    const v6, 0x7f0400b9

    invoke-virtual {v0, v6}, Lnet/duceng/xmidi/Settings;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/LinearLayout;

    .line 255
    .local v6, "sfonts_file":Landroid/widget/LinearLayout;
    new-instance v7, Ljava/io/File;

    sget-object v8, Lnet/duceng/xsynth/Synth;->PATH_FONT:Ljava/lang/String;

    invoke-direct {v7, v8}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 256
    .local v7, "path":Ljava/io/File;
    invoke-virtual {v7}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v8

    .line 257
    .local v8, "files":[Ljava/io/File;
    const/4 v9, 0x0

    if-nez v8, :cond_0

    .line 258
    new-array v8, v9, [Ljava/io/File;

    .line 260
    :cond_0
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/Settings;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v10

    const v11, 0x7f05000b

    invoke-virtual {v10, v11, v6, v9}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/Button;

    .line 261
    .local v10, "importButton":Landroid/widget/Button;
    const v11, 0x7f060011

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setText(I)V

    .line 262
    new-instance v11, Lnet/duceng/xmidi/Settings$9;

    invoke-direct {v11, v0}, Lnet/duceng/xmidi/Settings$9;-><init>(Lnet/duceng/xmidi/Settings;)V

    invoke-virtual {v10, v11}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 268
    invoke-virtual {v6, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 269
    new-instance v11, Lorg/json/JSONArray;

    invoke-direct {v11}, Lorg/json/JSONArray;-><init>()V

    .line 270
    .local v11, "ja":Lorg/json/JSONArray;
    sget-object v12, Lnet/duceng/xmidi/Settings;->SYNTH_SFONT_DEFAULT_VAL:Ljava/lang/String;

    invoke-virtual {v11, v12}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 271
    iget-object v12, v0, Lnet/duceng/xmidi/Settings;->pref:Landroid/content/SharedPreferences;

    sget-object v13, Lnet/duceng/xmidi/Settings;->SYNTH_SFONTS:Ljava/lang/String;

    invoke-virtual {v11}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-interface {v12, v13, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-direct {v0, v12}, Lnet/duceng/xmidi/Settings;->split(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v12

    iput-object v12, v0, Lnet/duceng/xmidi/Settings;->sfonts:Ljava/util/Set;

    .line 272
    iget-object v12, v0, Lnet/duceng/xmidi/Settings;->pref:Landroid/content/SharedPreferences;

    sget-object v13, Lnet/duceng/xmidi/Settings;->SYNTH_SFONT_DEFAULT:Ljava/lang/String;

    sget-object v14, Lnet/duceng/xmidi/Settings;->SYNTH_SFONT_DEFAULT_VAL:Ljava/lang/String;

    invoke-interface {v12, v13, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 273
    .local v12, "sfont_default":Ljava/lang/String;
    const/4 v13, 0x0

    .local v13, "i":I
    :goto_0
    array-length v14, v8

    const/4 v15, 0x0

    if-ge v13, v14, :cond_3

    .line 274
    invoke-static/range {p0 .. p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v14

    move-object/from16 v16, v15

    check-cast v16, Landroid/view/ViewGroup;

    const v9, 0x7f05001c

    invoke-virtual {v14, v9, v15}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v9

    .line 275
    .local v9, "item":Landroid/view/View;
    const v14, 0x7f040075

    invoke-virtual {v9, v14}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/CheckBox;

    .line 276
    .local v14, "cb":Landroid/widget/CheckBox;
    const v15, 0x7f040076

    invoke-virtual {v9, v15}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/RadioButton;

    .line 277
    .local v15, "rb":Landroid/widget/RadioButton;
    aget-object v17, v8, v13

    move/from16 v18, v1

    .end local v1    # "gain":I
    .local v18, "gain":I
    invoke-virtual/range {v17 .. v17}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v14, v1}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    .line 278
    aget-object v1, v8, v13

    invoke-virtual {v14, v1}, Landroid/widget/CheckBox;->setTag(Ljava/lang/Object;)V

    .line 279
    aget-object v1, v8, v13

    invoke-virtual {v15, v1}, Landroid/widget/RadioButton;->setTag(Ljava/lang/Object;)V

    .line 280
    iget-object v1, v0, Lnet/duceng/xmidi/Settings;->sfonts:Ljava/util/Set;

    aget-object v17, v8, v13

    move/from16 v19, v2

    .end local v2    # "polyphony":I
    .local v19, "polyphony":I
    invoke-virtual/range {v17 .. v17}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    .line 281
    invoke-virtual {v14, v2}, Landroid/widget/CheckBox;->setChecked(Z)V

    goto :goto_1

    .line 283
    :cond_1
    const/4 v1, 0x0

    invoke-virtual {v15, v1}, Landroid/widget/RadioButton;->setEnabled(Z)V

    .line 285
    :goto_1
    aget-object v1, v8, v13

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v12, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 286
    invoke-virtual {v15, v2}, Landroid/widget/RadioButton;->setChecked(Z)V

    .line 288
    :cond_2
    iget-object v1, v0, Lnet/duceng/xmidi/Settings;->checkChangeListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    invoke-virtual {v14, v1}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 289
    iget-object v1, v0, Lnet/duceng/xmidi/Settings;->radioChangeListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    invoke-virtual {v15, v1}, Landroid/widget/RadioButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 290
    iget-object v1, v0, Lnet/duceng/xmidi/Settings;->radioClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v15, v1}, Landroid/widget/RadioButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 291
    invoke-virtual {v6, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 292
    iget-object v1, v0, Lnet/duceng/xmidi/Settings;->sfonts_check:Ljava/util/ArrayList;

    invoke-virtual {v1, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 293
    iget-object v1, v0, Lnet/duceng/xmidi/Settings;->sfonts_radio:Ljava/util/ArrayList;

    invoke-virtual {v1, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 273
    .end local v9    # "item":Landroid/view/View;
    .end local v14    # "cb":Landroid/widget/CheckBox;
    .end local v15    # "rb":Landroid/widget/RadioButton;
    add-int/lit8 v13, v13, 0x1

    move/from16 v1, v18

    move/from16 v2, v19

    const/4 v9, 0x0

    goto/16 :goto_0

    .end local v18    # "gain":I
    .end local v19    # "polyphony":I
    .restart local v1    # "gain":I
    .restart local v2    # "polyphony":I
    :cond_3
    move/from16 v18, v1

    move/from16 v19, v2

    .line 295
    .end local v1    # "gain":I
    .end local v2    # "polyphony":I
    .end local v13    # "i":I
    .restart local v18    # "gain":I
    .restart local v19    # "polyphony":I
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/Settings;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v1

    move-object v2, v15

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050008

    invoke-virtual {v1, v2, v15}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    .line 296
    .local v1, "layout":Landroid/widget/LinearLayout;
    :goto_2
    invoke-virtual {v1}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v2

    if-lez v2, :cond_4

    .line 297
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v9

    .line 298
    .local v9, "child":Landroid/view/View;
    invoke-virtual {v1, v9}, Landroid/widget/LinearLayout;->removeView(Landroid/view/View;)V

    .line 299
    iget-object v13, v0, Lnet/duceng/xmidi/Settings;->listBottom:Ljava/util/ArrayList;

    invoke-virtual {v13, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 300
    iget-object v13, v0, Lnet/duceng/xmidi/Settings;->actionClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v9, v13}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 301
    .end local v9    # "child":Landroid/view/View;
    goto :goto_2

    .line 302
    :cond_4
    return-void
.end method

.method protected onDestroy()V
    .locals 1

    .line 325
    iget-object v0, p0, Lnet/duceng/xmidi/Settings;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->freeInstance()V

    .line 326
    invoke-super {p0}, Lnet/duceng/xmidi/Base;->onDestroy()V

    .line 327
    return-void
.end method

.method protected onStart()V
    .locals 0

    .line 331
    invoke-super {p0}, Lnet/duceng/xmidi/Base;->onStart()V

    .line 332
    return-void
.end method
