.class Lnet/duceng/xmidi/ui/DialogChannel$1;
.super Ljava/lang/Object;
.source "DialogChannel.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogChannel;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogChannel;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogChannel;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogChannel;

    .line 37
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogChannel$1;->this$0:Lnet/duceng/xmidi/ui/DialogChannel;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 3
    .param p2, "v"    # Landroid/view/View;
    .param p3, "pos"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 40
    .local p1, "av":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogChannel$1;->this$0:Lnet/duceng/xmidi/ui/DialogChannel;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogChannel;->access$000(Lnet/duceng/xmidi/ui/DialogChannel;)Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 41
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogChannel$1;->this$0:Lnet/duceng/xmidi/ui/DialogChannel;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogChannel;->access$000(Lnet/duceng/xmidi/ui/DialogChannel;)Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;

    move-result-object v0

    long-to-int v1, p4

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogChannel$1;->this$0:Lnet/duceng/xmidi/ui/DialogChannel;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogChannel;->access$100(Lnet/duceng/xmidi/ui/DialogChannel;)Lnet/duceng/xmidi/util/AdapterChannel;

    move-result-object v2

    invoke-virtual {v2, p3}, Lnet/duceng/xmidi/util/AdapterChannel;->getItem(I)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, p3, v1, v2}, Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;->onSelect(IILjava/lang/String;)V

    goto :goto_0

    .line 43
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogChannel$1;->this$0:Lnet/duceng/xmidi/ui/DialogChannel;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogChannel;->synth:Lnet/duceng/xsynth/Synth;

    int-to-byte v1, p3

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->setRecordChan(B)V

    .line 44
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogChannel$1;->this$0:Lnet/duceng/xmidi/ui/DialogChannel;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogChannel;->access$100(Lnet/duceng/xmidi/ui/DialogChannel;)Lnet/duceng/xmidi/util/AdapterChannel;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/AdapterChannel;->notifyDataSetChanged()V

    .line 46
    :goto_0
    return-void
.end method
