.class public interface abstract Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;
.super Ljava/lang/Object;
.source "DialogChannel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/ui/DialogChannel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnSelectListener"
.end annotation


# virtual methods
.method public abstract onSelect(IILjava/lang/String;)V
.end method
