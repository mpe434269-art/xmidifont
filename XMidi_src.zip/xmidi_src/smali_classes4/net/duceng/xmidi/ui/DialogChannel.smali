.class public Lnet/duceng/xmidi/ui/DialogChannel;
.super Lnet/duceng/xmidi/ui/XDialog;
.source "DialogChannel.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;
    }
.end annotation


# instance fields
.field private ac:Lnet/duceng/xmidi/util/AdapterChannel;

.field private onSelectListener:Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;

.field protected synth:Lnet/duceng/xsynth/Synth;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "s"    # Lnet/duceng/xsynth/Synth;

    .line 25
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    .line 26
    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogChannel;->synth:Lnet/duceng/xsynth/Synth;

    .line 27
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/ui/DialogChannel;)Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogChannel;

    .line 15
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogChannel;->onSelectListener:Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;

    return-object v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/ui/DialogChannel;)Lnet/duceng/xmidi/util/AdapterChannel;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogChannel;

    .line 15
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogChannel;->ac:Lnet/duceng/xmidi/util/AdapterChannel;

    return-object v0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 31
    invoke-super {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;->onCreate(Landroid/os/Bundle;)V

    .line 32
    const v0, 0x7f060025

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogChannel;->setTitle(I)V

    .line 33
    const v0, 0x7f030041

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogChannel;->setIcon(I)V

    .line 34
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogChannel;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050015

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    .line 35
    .local v0, "lv":Landroid/widget/ListView;
    new-instance v1, Lnet/duceng/xmidi/util/AdapterChannel;

    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogChannel;->getContext()Landroid/content/Context;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogChannel;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v1, v2, v3}, Lnet/duceng/xmidi/util/AdapterChannel;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogChannel;->ac:Lnet/duceng/xmidi/util/AdapterChannel;

    .line 36
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogChannel;->ac:Lnet/duceng/xmidi/util/AdapterChannel;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 37
    new-instance v1, Lnet/duceng/xmidi/ui/DialogChannel$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/ui/DialogChannel$1;-><init>(Lnet/duceng/xmidi/ui/DialogChannel;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 48
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogChannel;->setContentView(Landroid/view/View;)V

    .line 49
    return-void
.end method

.method protected onStart()V
    .locals 1

    .line 53
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogChannel;->ac:Lnet/duceng/xmidi/util/AdapterChannel;

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/AdapterChannel;->notifyDataSetChanged()V

    .line 54
    invoke-super {p0}, Lnet/duceng/xmidi/ui/XDialog;->onStart()V

    .line 55
    return-void
.end method

.method public setOnSelectListener(Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;

    .line 58
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogChannel;->onSelectListener:Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;

    .line 59
    return-void
.end method
