.class Lnet/duceng/xmidi/ui/DialogExplorer$1;
.super Ljava/lang/Object;
.source "DialogExplorer.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogExplorer;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogExplorer;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogExplorer;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogExplorer;

    .line 39
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogExplorer$1;->this$0:Lnet/duceng/xmidi/ui/DialogExplorer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 2
    .param p2, "view"    # Landroid/view/View;
    .param p3, "pos"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 42
    .local p1, "arg0":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer$1;->this$0:Lnet/duceng/xmidi/ui/DialogExplorer;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogExplorer;->access$000(Lnet/duceng/xmidi/ui/DialogExplorer;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v0

    invoke-virtual {v0, p3}, Lnet/duceng/xmidi/util/AdapterExplorer;->getItem(I)Ljava/io/File;

    move-result-object v0

    .line 43
    .local v0, "f":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->isDirectory()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->canExecute()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 44
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogExplorer$1;->this$0:Lnet/duceng/xmidi/ui/DialogExplorer;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogExplorer;->access$000(Lnet/duceng/xmidi/ui/DialogExplorer;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v1

    invoke-virtual {v1, v0}, Lnet/duceng/xmidi/util/AdapterExplorer;->setCurrentPath(Ljava/io/File;)V

    .line 45
    return-void

    .line 47
    :cond_0
    invoke-virtual {v0}, Ljava/io/File;->isFile()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Ljava/io/File;->canRead()Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogExplorer$1;->this$0:Lnet/duceng/xmidi/ui/DialogExplorer;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogExplorer;->access$100(Lnet/duceng/xmidi/ui/DialogExplorer;)Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;

    move-result-object v1

    if-eqz v1, :cond_1

    .line 48
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogExplorer$1;->this$0:Lnet/duceng/xmidi/ui/DialogExplorer;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogExplorer;->access$100(Lnet/duceng/xmidi/ui/DialogExplorer;)Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;

    move-result-object v1

    invoke-interface {v1, v0}, Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;->onSelect(Ljava/io/File;)V

    .line 50
    :cond_1
    const/4 v1, 0x1

    invoke-virtual {p1, v1}, Landroid/widget/AdapterView;->setSelected(Z)V

    .line 51
    return-void
.end method
