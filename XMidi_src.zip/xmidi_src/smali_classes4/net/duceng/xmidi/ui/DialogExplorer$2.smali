.class Lnet/duceng/xmidi/ui/DialogExplorer$2;
.super Ljava/lang/Object;
.source "DialogExplorer.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogExplorer;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogExplorer;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogExplorer;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogExplorer;

    .line 56
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogExplorer$2;->this$0:Lnet/duceng/xmidi/ui/DialogExplorer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2
    .param p1, "arg0"    # Landroid/view/View;

    .line 59
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer$2;->this$0:Lnet/duceng/xmidi/ui/DialogExplorer;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogExplorer;->access$100(Lnet/duceng/xmidi/ui/DialogExplorer;)Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;

    move-result-object v0

    if-nez v0, :cond_0

    .line 60
    return-void

    .line 62
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer$2;->this$0:Lnet/duceng/xmidi/ui/DialogExplorer;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogExplorer;->access$100(Lnet/duceng/xmidi/ui/DialogExplorer;)Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;->onSelect(Ljava/io/File;)V

    .line 63
    return-void
.end method
