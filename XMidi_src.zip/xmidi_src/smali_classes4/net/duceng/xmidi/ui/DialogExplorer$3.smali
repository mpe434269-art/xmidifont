.class Lnet/duceng/xmidi/ui/DialogExplorer$3;
.super Ljava/lang/Object;
.source "DialogExplorer.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogExplorer;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private dialogTrack:Lnet/duceng/xmidi/ui/DialogTrack;

.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogExplorer;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogExplorer;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogExplorer;

    .line 67
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogExplorer$3;->this$0:Lnet/duceng/xmidi/ui/DialogExplorer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v2"    # Landroid/view/View;

    .line 72
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer$3;->dialogTrack:Lnet/duceng/xmidi/ui/DialogTrack;

    if-nez v0, :cond_0

    .line 73
    new-instance v0, Lnet/duceng/xmidi/ui/DialogTrack;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogExplorer$3;->this$0:Lnet/duceng/xmidi/ui/DialogExplorer;

    invoke-virtual {v1}, Lnet/duceng/xmidi/ui/DialogExplorer;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogExplorer$3;->this$0:Lnet/duceng/xmidi/ui/DialogExplorer;

    iget-object v2, v2, Lnet/duceng/xmidi/ui/DialogExplorer;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/ui/DialogTrack;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer$3;->dialogTrack:Lnet/duceng/xmidi/ui/DialogTrack;

    .line 75
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer$3;->dialogTrack:Lnet/duceng/xmidi/ui/DialogTrack;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogTrack;->show()V

    .line 76
    return-void
.end method
