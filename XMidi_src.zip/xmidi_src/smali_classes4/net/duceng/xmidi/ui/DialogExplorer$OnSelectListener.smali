.class public interface abstract Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;
.super Ljava/lang/Object;
.source "DialogExplorer.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/ui/DialogExplorer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnSelectListener"
.end annotation


# virtual methods
.method public abstract onSelect(Ljava/io/File;)V
.end method
