.class public Lnet/duceng/xmidi/ui/DialogExplorer;
.super Lnet/duceng/xmidi/ui/XDialog;
.source "DialogExplorer.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;
    }
.end annotation


# instance fields
.field private af:Lnet/duceng/xmidi/util/AdapterExplorer;

.field private onSelectListener:Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;

.field private settings:Landroid/widget/ImageButton;

.field protected synth:Lnet/duceng/xsynth/Synth;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "s"    # Lnet/duceng/xsynth/Synth;

    .line 28
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    .line 29
    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->synth:Lnet/duceng/xsynth/Synth;

    .line 30
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/ui/DialogExplorer;)Lnet/duceng/xmidi/util/AdapterExplorer;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogExplorer;

    .line 17
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->af:Lnet/duceng/xmidi/util/AdapterExplorer;

    return-object v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/ui/DialogExplorer;)Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogExplorer;

    .line 17
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->onSelectListener:Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;

    return-object v0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 34
    invoke-super {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;->onCreate(Landroid/os/Bundle;)V

    .line 35
    const v0, 0x7f060023

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogExplorer;->setTitle(I)V

    .line 36
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogExplorer;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050015

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    .line 37
    .local v0, "lv":Landroid/widget/ListView;
    new-instance v2, Lnet/duceng/xmidi/util/AdapterExplorer;

    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogExplorer;->getContext()Landroid/content/Context;

    move-result-object v3

    new-instance v4, Ljava/io/File;

    sget-object v5, Lnet/duceng/xsynth/Synth;->PATH_MIDI:Ljava/lang/String;

    invoke-direct {v4, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {v2, v3, v4}, Lnet/duceng/xmidi/util/AdapterExplorer;-><init>(Landroid/content/Context;Ljava/io/File;)V

    iput-object v2, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->af:Lnet/duceng/xmidi/util/AdapterExplorer;

    .line 38
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->af:Lnet/duceng/xmidi/util/AdapterExplorer;

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 39
    new-instance v2, Lnet/duceng/xmidi/ui/DialogExplorer$1;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogExplorer$1;-><init>(Lnet/duceng/xmidi/ui/DialogExplorer;)V

    invoke-virtual {v0, v2}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 53
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogExplorer;->setContentView(Landroid/view/View;)V

    .line 54
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogExplorer;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v2

    const v3, 0x7f050005

    invoke-virtual {v2, v3, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v1

    .line 55
    .local v1, "v":Landroid/view/View;
    const v2, 0x7f040073

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageButton;

    .line 56
    .local v2, "im":Landroid/widget/ImageButton;
    new-instance v3, Lnet/duceng/xmidi/ui/DialogExplorer$2;

    invoke-direct {v3, p0}, Lnet/duceng/xmidi/ui/DialogExplorer$2;-><init>(Lnet/duceng/xmidi/ui/DialogExplorer;)V

    invoke-virtual {v2, v3}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 65
    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/ui/DialogExplorer;->addAction(Landroid/view/View;)V

    .line 66
    const v3, 0x7f040074

    invoke-virtual {p0, v3}, Lnet/duceng/xmidi/ui/DialogExplorer;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageButton;

    iput-object v3, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->settings:Landroid/widget/ImageButton;

    .line 67
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->settings:Landroid/widget/ImageButton;

    new-instance v4, Lnet/duceng/xmidi/ui/DialogExplorer$3;

    invoke-direct {v4, p0}, Lnet/duceng/xmidi/ui/DialogExplorer$3;-><init>(Lnet/duceng/xmidi/ui/DialogExplorer;)V

    invoke-virtual {v3, v4}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 78
    return-void
.end method

.method protected onStart()V
    .locals 2

    .line 82
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->af:Lnet/duceng/xmidi/util/AdapterExplorer;

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/AdapterExplorer;->notifyDataSetChanged()V

    .line 83
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getFile()Ljava/io/File;

    move-result-object v0

    if-nez v0, :cond_0

    .line 84
    const v0, 0x7f060023

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogExplorer;->setTitle(I)V

    .line 85
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->settings:Landroid/widget/ImageButton;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setVisibility(I)V

    goto :goto_0

    .line 87
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getFile()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogExplorer;->setTitle(Ljava/lang/CharSequence;)V

    .line 88
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->settings:Landroid/widget/ImageButton;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 90
    :goto_0
    invoke-super {p0}, Lnet/duceng/xmidi/ui/XDialog;->onStart()V

    .line 91
    return-void
.end method

.method public setOnSelectListener(Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;

    .line 94
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogExplorer;->onSelectListener:Lnet/duceng/xmidi/ui/DialogExplorer$OnSelectListener;

    .line 95
    return-void
.end method
