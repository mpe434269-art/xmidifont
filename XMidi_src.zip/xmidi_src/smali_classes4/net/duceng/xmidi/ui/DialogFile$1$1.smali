.class Lnet/duceng/xmidi/ui/DialogFile$1$1;
.super Ljava/lang/Object;
.source "DialogFile.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogFile$1;->onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/ui/DialogFile$1;

.field final synthetic val$etFinal:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogFile$1;Landroid/widget/EditText;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/ui/DialogFile$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 50
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogFile$1$1;->this$1:Lnet/duceng/xmidi/ui/DialogFile$1;

    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogFile$1$1;->val$etFinal:Landroid/widget/EditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v2"    # Landroid/view/View;

    .line 53
    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogFile$1$1;->this$1:Lnet/duceng/xmidi/ui/DialogFile$1;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogFile;->access$100(Lnet/duceng/xmidi/ui/DialogFile;)Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getParent()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogFile$1$1;->val$etFinal:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 54
    .local v0, "nf":Ljava/io/File;
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogFile$1$1;->this$1:Lnet/duceng/xmidi/ui/DialogFile$1;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogFile;->access$100(Lnet/duceng/xmidi/ui/DialogFile;)Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    .line 55
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogFile$1$1;->this$1:Lnet/duceng/xmidi/ui/DialogFile$1;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogFile;->access$200(Lnet/duceng/xmidi/ui/DialogFile;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/xmidi/util/AdapterExplorer;->notifyDataSetChanged()V

    .line 56
    return-void
.end method
