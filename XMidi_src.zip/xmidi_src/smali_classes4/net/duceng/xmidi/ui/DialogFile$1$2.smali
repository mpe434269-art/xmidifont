.class Lnet/duceng/xmidi/ui/DialogFile$1$2;
.super Ljava/lang/Object;
.source "DialogFile.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogFile$1;->onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/ui/DialogFile$1;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogFile$1;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/ui/DialogFile$1;

    .line 71
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogFile$1$2;->this$1:Lnet/duceng/xmidi/ui/DialogFile$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v2"    # Landroid/view/View;

    .line 74
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile$1$2;->this$1:Lnet/duceng/xmidi/ui/DialogFile$1;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogFile;->access$100(Lnet/duceng/xmidi/ui/DialogFile;)Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 75
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile$1$2;->this$1:Lnet/duceng/xmidi/ui/DialogFile$1;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogFile;->access$200(Lnet/duceng/xmidi/ui/DialogFile;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/AdapterExplorer;->notifyDataSetChanged()V

    .line 76
    return-void
.end method
