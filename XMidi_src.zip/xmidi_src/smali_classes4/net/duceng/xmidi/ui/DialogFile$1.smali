.class Lnet/duceng/xmidi/ui/DialogFile$1;
.super Ljava/lang/Object;
.source "DialogFile.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogFile;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private delete:Lnet/duceng/xmidi/ui/XDialog;

.field private edit:Lnet/duceng/xmidi/ui/XDialog;

.field private et:Landroid/widget/EditText;

.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogFile;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogFile;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogFile;

    .line 30
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 6
    .param p2, "v"    # Landroid/view/View;
    .param p3, "pos"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 37
    .local p1, "av":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    const/4 v0, 0x0

    const v1, 0x7f060003

    const/16 v2, 0xc

    packed-switch p3, :pswitch_data_0

    goto/16 :goto_0

    .line 65
    :pswitch_0
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->delete:Lnet/duceng/xmidi/ui/XDialog;

    if-nez v3, :cond_0

    .line 66
    new-instance v3, Lnet/duceng/xmidi/ui/XDialog;

    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v4}, Lnet/duceng/xmidi/ui/DialogFile;->access$000(Lnet/duceng/xmidi/ui/DialogFile;)Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    iput-object v3, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->delete:Lnet/duceng/xmidi/ui/XDialog;

    .line 67
    new-instance v3, Landroid/widget/TextView;

    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v4}, Lnet/duceng/xmidi/ui/DialogFile;->access$000(Lnet/duceng/xmidi/ui/DialogFile;)Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 68
    .local v3, "tv":Landroid/widget/TextView;
    const v4, 0x7f060029

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(I)V

    .line 69
    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->delete:Lnet/duceng/xmidi/ui/XDialog;

    invoke-virtual {v4, v3}, Lnet/duceng/xmidi/ui/XDialog;->setContentView(Landroid/view/View;)V

    .line 70
    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->delete:Lnet/duceng/xmidi/ui/XDialog;

    invoke-virtual {v4}, Lnet/duceng/xmidi/ui/XDialog;->getWapper()Landroid/widget/FrameLayout;

    move-result-object v4

    invoke-virtual {v4, v2, v2, v2, v2}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 71
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->delete:Lnet/duceng/xmidi/ui/XDialog;

    new-instance v4, Lnet/duceng/xmidi/ui/DialogFile$1$2;

    invoke-direct {v4, p0}, Lnet/duceng/xmidi/ui/DialogFile$1$2;-><init>(Lnet/duceng/xmidi/ui/DialogFile$1;)V

    const v5, 0x7f06000a

    invoke-virtual {v2, v5, v4}, Lnet/duceng/xmidi/ui/XDialog;->addButton(ILandroid/view/View$OnClickListener;)V

    .line 78
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->delete:Lnet/duceng/xmidi/ui/XDialog;

    invoke-virtual {v2, v1, v0}, Lnet/duceng/xmidi/ui/XDialog;->addButton(ILandroid/view/View$OnClickListener;)V

    .line 80
    .end local v3    # "tv":Landroid/widget/TextView;
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->delete:Lnet/duceng/xmidi/ui/XDialog;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogFile;->access$100(Lnet/duceng/xmidi/ui/DialogFile;)Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/XDialog;->setTitle(Ljava/lang/CharSequence;)V

    .line 81
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->delete:Lnet/duceng/xmidi/ui/XDialog;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/XDialog;->show()V

    goto/16 :goto_0

    .line 44
    :pswitch_1
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->edit:Lnet/duceng/xmidi/ui/XDialog;

    if-nez v3, :cond_1

    .line 45
    new-instance v3, Lnet/duceng/xmidi/ui/XDialog;

    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v4}, Lnet/duceng/xmidi/ui/DialogFile;->access$000(Lnet/duceng/xmidi/ui/DialogFile;)Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    iput-object v3, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->edit:Lnet/duceng/xmidi/ui/XDialog;

    .line 46
    new-instance v3, Landroid/widget/EditText;

    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v4}, Lnet/duceng/xmidi/ui/DialogFile;->access$000(Lnet/duceng/xmidi/ui/DialogFile;)Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    iput-object v3, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->et:Landroid/widget/EditText;

    .line 47
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->et:Landroid/widget/EditText;

    .line 48
    .local v3, "etFinal":Landroid/widget/EditText;
    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->edit:Lnet/duceng/xmidi/ui/XDialog;

    iget-object v5, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->et:Landroid/widget/EditText;

    invoke-virtual {v4, v5}, Lnet/duceng/xmidi/ui/XDialog;->setContentView(Landroid/view/View;)V

    .line 49
    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->edit:Lnet/duceng/xmidi/ui/XDialog;

    invoke-virtual {v4}, Lnet/duceng/xmidi/ui/XDialog;->getWapper()Landroid/widget/FrameLayout;

    move-result-object v4

    invoke-virtual {v4, v2, v2, v2, v2}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 50
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->edit:Lnet/duceng/xmidi/ui/XDialog;

    new-instance v4, Lnet/duceng/xmidi/ui/DialogFile$1$1;

    invoke-direct {v4, p0, v3}, Lnet/duceng/xmidi/ui/DialogFile$1$1;-><init>(Lnet/duceng/xmidi/ui/DialogFile$1;Landroid/widget/EditText;)V

    const v5, 0x7f06001e

    invoke-virtual {v2, v5, v4}, Lnet/duceng/xmidi/ui/XDialog;->addButton(ILandroid/view/View$OnClickListener;)V

    .line 58
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->edit:Lnet/duceng/xmidi/ui/XDialog;

    invoke-virtual {v2, v1, v0}, Lnet/duceng/xmidi/ui/XDialog;->addButton(ILandroid/view/View$OnClickListener;)V

    .line 60
    .end local v3    # "etFinal":Landroid/widget/EditText;
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->edit:Lnet/duceng/xmidi/ui/XDialog;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogFile;->access$100(Lnet/duceng/xmidi/ui/DialogFile;)Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/XDialog;->setTitle(Ljava/lang/CharSequence;)V

    .line 61
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->et:Landroid/widget/EditText;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogFile;->access$100(Lnet/duceng/xmidi/ui/DialogFile;)Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 62
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->edit:Lnet/duceng/xmidi/ui/XDialog;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/XDialog;->show()V

    .line 63
    goto :goto_0

    .line 39
    :pswitch_2
    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogFile;->access$000(Lnet/duceng/xmidi/ui/DialogFile;)Landroid/content/Context;

    move-result-object v1

    const-class v2, Lnet/duceng/xmidi/Keyboard;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 40
    .local v0, "intent":Landroid/content/Intent;
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogFile;->access$100(Lnet/duceng/xmidi/ui/DialogFile;)Ljava/io/File;

    move-result-object v1

    const-string v2, "file"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 41
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogFile;->access$000(Lnet/duceng/xmidi/ui/DialogFile;)Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 42
    nop

    .line 84
    .end local v0    # "intent":Landroid/content/Intent;
    :goto_0
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile$1;->this$0:Lnet/duceng/xmidi/ui/DialogFile;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogFile;->dismiss()V

    .line 85
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
