.class public Lnet/duceng/xmidi/ui/DialogFile;
.super Lnet/duceng/xmidi/ui/XDialog;
.source "DialogFile.java"


# instance fields
.field private ae:Lnet/duceng/xmidi/util/AdapterExplorer;

.field private context:Landroid/content/Context;

.field private file:Ljava/io/File;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xmidi/util/AdapterExplorer;)V
    .locals 0
    .param p1, "c"    # Landroid/content/Context;
    .param p2, "a"    # Lnet/duceng/xmidi/util/AdapterExplorer;

    .line 22
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    .line 23
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogFile;->context:Landroid/content/Context;

    .line 24
    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogFile;->ae:Lnet/duceng/xmidi/util/AdapterExplorer;

    .line 25
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/ui/DialogFile;)Landroid/content/Context;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogFile;

    .line 16
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile;->context:Landroid/content/Context;

    return-object v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/ui/DialogFile;)Ljava/io/File;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogFile;

    .line 16
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile;->file:Ljava/io/File;

    return-object v0
.end method

.method static synthetic access$200(Lnet/duceng/xmidi/ui/DialogFile;)Lnet/duceng/xmidi/util/AdapterExplorer;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogFile;

    .line 16
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile;->ae:Lnet/duceng/xmidi/util/AdapterExplorer;

    return-object v0
.end method


# virtual methods
.method public getFile()Ljava/io/File;
    .locals 1

    .line 96
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile;->file:Ljava/io/File;

    return-object v0
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 29
    invoke-super {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;->onCreate(Landroid/os/Bundle;)V

    .line 30
    new-instance v0, Lnet/duceng/xmidi/ui/DialogFile$1;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/ui/DialogFile$1;-><init>(Lnet/duceng/xmidi/ui/DialogFile;)V

    const/high16 v1, 0x7f010000

    invoke-virtual {p0, v1, v0}, Lnet/duceng/xmidi/ui/DialogFile;->setItems(ILandroid/widget/AdapterView$OnItemClickListener;)V

    .line 87
    return-void
.end method

.method protected onStart()V
    .locals 1

    .line 91
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogFile;->file:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogFile;->setTitle(Ljava/lang/CharSequence;)V

    .line 92
    invoke-super {p0}, Lnet/duceng/xmidi/ui/XDialog;->onStart()V

    .line 93
    return-void
.end method

.method public setFile(Ljava/io/File;)V
    .locals 0
    .param p1, "file"    # Ljava/io/File;

    .line 100
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogFile;->file:Ljava/io/File;

    .line 101
    return-void
.end method
