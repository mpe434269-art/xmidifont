.class Lnet/duceng/xmidi/ui/DialogMidi$1;
.super Ljava/lang/Object;
.source "DialogMidi.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogMidi;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogMidi;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogMidi;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogMidi;

    .line 38
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogMidi$1;->this$0:Lnet/duceng/xmidi/ui/DialogMidi;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 3
    .param p1, "arg0"    # Landroid/widget/SeekBar;
    .param p2, "progress"    # I
    .param p3, "arg2"    # Z

    .line 41
    add-int/lit8 v0, p2, 0x28

    .line 42
    .local v0, "bpm":I
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi$1;->this$0:Lnet/duceng/xmidi/ui/DialogMidi;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogMidi;->access$000(Lnet/duceng/xmidi/ui/DialogMidi;)Landroid/widget/TextView;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 43
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi$1;->this$0:Lnet/duceng/xmidi/ui/DialogMidi;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogMidi;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v1

    invoke-virtual {v1, v0}, Lnet/duceng/midi/MetaTempo;->setBpm(I)V

    .line 44
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 48
    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 52
    return-void
.end method
