.class Lnet/duceng/xmidi/ui/DialogMidi$2;
.super Ljava/lang/Object;
.source "DialogMidi.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogMidi;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogMidi;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogMidi;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogMidi;

    .line 57
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogMidi$2;->this$0:Lnet/duceng/xmidi/ui/DialogMidi;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 7
    .param p1, "arg0"    # Landroid/widget/SeekBar;
    .param p2, "progress"    # I
    .param p3, "arg2"    # Z

    .line 60
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogMidi$2;->this$0:Lnet/duceng/xmidi/ui/DialogMidi;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogMidi;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTimeSignature()Lnet/duceng/midi/MetaTimeSignature;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MetaTimeSignature;->getDenominator()B

    move-result v0

    .line 61
    .local v0, "denominator":I
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi$2;->this$0:Lnet/duceng/xmidi/ui/DialogMidi;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogMidi;->access$100(Lnet/duceng/xmidi/ui/DialogMidi;)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-wide/high16 v3, 0x4000000000000000L    # 2.0

    int-to-double v5, v0

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v3

    double-to-int v3, v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 62
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi$2;->this$0:Lnet/duceng/xmidi/ui/DialogMidi;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogMidi;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/midi/MidiFile;->getTimeSignature()Lnet/duceng/midi/MetaTimeSignature;

    move-result-object v1

    int-to-byte v2, p2

    invoke-virtual {v1, v2}, Lnet/duceng/midi/MetaTimeSignature;->setNumerator(B)V

    .line 63
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 67
    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 71
    return-void
.end method
