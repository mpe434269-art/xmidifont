.class Lnet/duceng/xmidi/ui/DialogMidi$4;
.super Ljava/lang/Object;
.source "DialogMidi.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogMidi;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogMidi;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogMidi;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogMidi;

    .line 91
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogMidi$4;->this$0:Lnet/duceng/xmidi/ui/DialogMidi;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 2
    .param p1, "arg0"    # Landroid/widget/SeekBar;
    .param p2, "progress"    # I
    .param p3, "arg2"    # Z

    .line 94
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogMidi$4;->this$0:Lnet/duceng/xmidi/ui/DialogMidi;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogMidi;->access$200(Lnet/duceng/xmidi/ui/DialogMidi;)Landroid/widget/TextView;

    move-result-object v0

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 95
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogMidi$4;->this$0:Lnet/duceng/xmidi/ui/DialogMidi;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogMidi;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v0

    invoke-virtual {v0, p2}, Lnet/duceng/midi/MidiFile;->setResolution(I)V

    .line 96
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 100
    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 104
    return-void
.end method
