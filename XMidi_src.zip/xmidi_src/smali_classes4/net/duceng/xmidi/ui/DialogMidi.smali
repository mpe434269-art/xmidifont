.class public Lnet/duceng/xmidi/ui/DialogMidi;
.super Lnet/duceng/xmidi/ui/XDialog;
.source "DialogMidi.java"


# instance fields
.field private bpm_seek:Landroid/widget/SeekBar;

.field private bpm_value:Landroid/widget/TextView;

.field private resolution_seek:Landroid/widget/SeekBar;

.field private resolution_value:Landroid/widget/TextView;

.field protected synth:Lnet/duceng/xsynth/Synth;

.field private time_denominator:Landroid/widget/SeekBar;

.field private time_numerator:Landroid/widget/SeekBar;

.field private time_value:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "s"    # Lnet/duceng/xsynth/Synth;

    .line 25
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    .line 26
    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogMidi;->synth:Lnet/duceng/xsynth/Synth;

    .line 27
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/ui/DialogMidi;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogMidi;

    .line 14
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogMidi;->bpm_value:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/ui/DialogMidi;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogMidi;

    .line 14
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogMidi;->time_value:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$200(Lnet/duceng/xmidi/ui/DialogMidi;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogMidi;

    .line 14
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogMidi;->resolution_value:Landroid/widget/TextView;

    return-object v0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 31
    invoke-super {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;->onCreate(Landroid/os/Bundle;)V

    .line 32
    const v0, 0x7f060026

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogMidi;->setTitle(I)V

    .line 33
    const v0, 0x7f030042

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogMidi;->setIcon(I)V

    .line 34
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogMidi;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f05000c

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    .line 35
    .local v0, "v":Landroid/view/View;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogMidi;->setContentView(Landroid/view/View;)V

    .line 36
    const v1, 0x7f0400bb

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->bpm_value:Landroid/widget/TextView;

    .line 37
    const v1, 0x7f0400ba

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->bpm_seek:Landroid/widget/SeekBar;

    .line 38
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->bpm_seek:Landroid/widget/SeekBar;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogMidi$1;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogMidi$1;-><init>(Lnet/duceng/xmidi/ui/DialogMidi;)V

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 54
    const v1, 0x7f0400c0

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->time_value:Landroid/widget/TextView;

    .line 55
    const v1, 0x7f0400bf

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->time_numerator:Landroid/widget/SeekBar;

    .line 56
    const v1, 0x7f0400be

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->time_denominator:Landroid/widget/SeekBar;

    .line 57
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->time_numerator:Landroid/widget/SeekBar;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogMidi$2;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogMidi$2;-><init>(Lnet/duceng/xmidi/ui/DialogMidi;)V

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 73
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->time_denominator:Landroid/widget/SeekBar;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogMidi$3;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogMidi$3;-><init>(Lnet/duceng/xmidi/ui/DialogMidi;)V

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 89
    const v1, 0x7f0400bd

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->resolution_value:Landroid/widget/TextView;

    .line 90
    const v1, 0x7f0400bc

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->resolution_seek:Landroid/widget/SeekBar;

    .line 91
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->resolution_seek:Landroid/widget/SeekBar;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogMidi$4;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogMidi$4;-><init>(Lnet/duceng/xmidi/ui/DialogMidi;)V

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 106
    return-void
.end method

.method protected onStart()V
    .locals 8

    .line 110
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogMidi;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MetaTempo;->getBpm()I

    move-result v0

    .line 111
    .local v0, "bpm":I
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->bpm_value:Landroid/widget/TextView;

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 112
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->bpm_seek:Landroid/widget/SeekBar;

    add-int/lit8 v2, v0, -0x28

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 113
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogMidi;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/midi/MidiFile;->getTimeSignature()Lnet/duceng/midi/MetaTimeSignature;

    move-result-object v1

    .line 114
    .local v1, "timeSignature":Lnet/duceng/midi/MetaTimeSignature;
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogMidi;->time_value:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1}, Lnet/duceng/midi/MetaTimeSignature;->getNumerator()B

    move-result v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Lnet/duceng/midi/MetaTimeSignature;->getDenominator()B

    move-result v4

    int-to-double v4, v4

    const-wide/high16 v6, 0x4000000000000000L    # 2.0

    invoke-static {v6, v7, v4, v5}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v4

    double-to-int v4, v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 115
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogMidi;->time_numerator:Landroid/widget/SeekBar;

    invoke-virtual {v1}, Lnet/duceng/midi/MetaTimeSignature;->getNumerator()B

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 116
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogMidi;->time_denominator:Landroid/widget/SeekBar;

    invoke-virtual {v1}, Lnet/duceng/midi/MetaTimeSignature;->getDenominator()B

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 117
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogMidi;->resolution_value:Landroid/widget/TextView;

    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogMidi;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v3}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v3

    invoke-virtual {v3}, Lnet/duceng/midi/MidiFile;->getResolution()I

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 118
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogMidi;->resolution_seek:Landroid/widget/SeekBar;

    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogMidi;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v3}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v3

    invoke-virtual {v3}, Lnet/duceng/midi/MidiFile;->getResolution()I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 119
    invoke-super {p0}, Lnet/duceng/xmidi/ui/XDialog;->onStart()V

    .line 120
    return-void
.end method
