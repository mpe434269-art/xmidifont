.class public interface abstract Lnet/duceng/xmidi/ui/DialogPercussion$OnSelectListener;
.super Ljava/lang/Object;
.source "DialogPercussion.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/ui/DialogPercussion;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnSelectListener"
.end annotation


# virtual methods
.method public abstract onSelect(I)Z
.end method
