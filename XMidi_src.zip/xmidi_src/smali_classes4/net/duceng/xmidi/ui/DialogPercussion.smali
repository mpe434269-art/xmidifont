.class public Lnet/duceng/xmidi/ui/DialogPercussion;
.super Lnet/duceng/xmidi/ui/XDialog;
.source "DialogPercussion.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/ui/DialogPercussion$OnSelectListener;
    }
.end annotation


# instance fields
.field private onSelectListener:Lnet/duceng/xmidi/ui/DialogPercussion$OnSelectListener;

.field private percussions:[Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;[Ljava/lang/String;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "p"    # [Ljava/lang/String;

    .line 23
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    .line 24
    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogPercussion;->percussions:[Ljava/lang/String;

    .line 25
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/ui/DialogPercussion;)Lnet/duceng/xmidi/ui/DialogPercussion$OnSelectListener;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPercussion;

    .line 14
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPercussion;->onSelectListener:Lnet/duceng/xmidi/ui/DialogPercussion$OnSelectListener;

    return-object v0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 29
    invoke-super {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;->onCreate(Landroid/os/Bundle;)V

    .line 30
    const v0, 0x7f06001b

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogPercussion;->setTitle(I)V

    .line 31
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogPercussion;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050012

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/GridView;

    .line 32
    .local v0, "gv":Landroid/widget/GridView;
    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/widget/GridView;->setNumColumns(I)V

    .line 33
    new-instance v1, Landroid/widget/ArrayAdapter;

    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogPercussion;->getContext()Landroid/content/Context;

    move-result-object v2

    const v3, 0x7f050019

    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogPercussion;->percussions:[Ljava/lang/String;

    invoke-direct {v1, v2, v3, v4}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    .line 34
    .local v1, "arrayAdapter":Landroid/widget/ArrayAdapter;, "Landroid/widget/ArrayAdapter<Ljava/lang/String;>;"
    invoke-virtual {v0, v1}, Landroid/widget/GridView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 35
    new-instance v2, Lnet/duceng/xmidi/ui/DialogPercussion$1;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPercussion$1;-><init>(Lnet/duceng/xmidi/ui/DialogPercussion;)V

    invoke-virtual {v0, v2}, Landroid/widget/GridView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 44
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogPercussion;->setContentView(Landroid/view/View;)V

    .line 45
    return-void
.end method

.method public setOnSelectListener(Lnet/duceng/xmidi/ui/DialogPercussion$OnSelectListener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xmidi/ui/DialogPercussion$OnSelectListener;

    .line 48
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogPercussion;->onSelectListener:Lnet/duceng/xmidi/ui/DialogPercussion$OnSelectListener;

    .line 49
    return-void
.end method
