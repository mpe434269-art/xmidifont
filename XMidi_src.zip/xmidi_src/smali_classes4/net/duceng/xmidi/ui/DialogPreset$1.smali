.class Lnet/duceng/xmidi/ui/DialogPreset$1;
.super Ljava/lang/Object;
.source "DialogPreset.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogPreset;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogPreset;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogPreset;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 87
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogPreset$1;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v2"    # Landroid/view/View;

    .line 90
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$1;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$1;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v1

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$1;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$100(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/CheckBox;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v2

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->setMute(IZ)V

    .line 91
    return-void
.end method
