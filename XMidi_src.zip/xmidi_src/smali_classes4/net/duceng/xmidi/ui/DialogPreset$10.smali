.class Lnet/duceng/xmidi/ui/DialogPreset$10;
.super Ljava/lang/Object;
.source "DialogPreset.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogPreset;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogPreset;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogPreset;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 227
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogPreset$10;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5
    .param p1, "v2"    # Landroid/view/View;

    .line 230
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$10;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogPreset;->access$1500(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/CheckBox;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 231
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$10;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$10;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v1

    sget-byte v2, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH3:B

    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$10;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v3, v3, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogPreset$10;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v4}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v4

    invoke-virtual {v3, v4}, Lnet/duceng/xsynth/Synth;->getChorus(I)I

    move-result v3

    invoke-virtual {v0, v1, v2, v3}, Lnet/duceng/xsynth/Synth;->setControl(III)V

    goto :goto_0

    .line 233
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$10;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$10;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v1

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->getControls(I)Lnet/duceng/xmidi/util/MyArray;

    move-result-object v0

    sget-byte v1, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH3:B

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/util/MyArray;->remove(I)V

    .line 235
    :goto_0
    return-void
.end method
