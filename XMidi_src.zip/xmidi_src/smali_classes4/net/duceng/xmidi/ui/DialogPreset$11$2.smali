.class Lnet/duceng/xmidi/ui/DialogPreset$11$2;
.super Ljava/lang/Object;
.source "DialogPreset.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogPreset$11;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/ui/DialogPreset$11;

.field final synthetic val$dpFinal:Lnet/duceng/xmidi/ui/DialogProgram;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogPreset$11;Lnet/duceng/xmidi/ui/DialogProgram;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/ui/DialogPreset$11;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 271
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogPreset$11$2;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$11;

    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogPreset$11$2;->val$dpFinal:Lnet/duceng/xmidi/ui/DialogProgram;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(I)Z
    .locals 4
    .param p1, "id"    # I

    .line 274
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11$2;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$11;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$11$2;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$11;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v1

    invoke-virtual {v0, v1, p1}, Lnet/duceng/xsynth/Synth;->setPreset(II)V

    .line 275
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11$2;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$11;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogPreset;->access$300(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/Button;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$11$2;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$11;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$400(Lnet/duceng/xmidi/ui/DialogPreset;)[Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$11$2;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$11;

    iget-object v2, v2, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v2, v2, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$11$2;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$11;

    iget-object v3, v3, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v3}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v3

    invoke-virtual {v2, v3}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v2

    aget-object v1, v1, v2

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 276
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11$2;->val$dpFinal:Lnet/duceng/xmidi/ui/DialogProgram;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogProgram;->dismiss()V

    .line 277
    const/4 v0, 0x1

    return v0
.end method
