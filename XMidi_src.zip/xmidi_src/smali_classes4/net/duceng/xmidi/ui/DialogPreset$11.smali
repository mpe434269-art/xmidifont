.class Lnet/duceng/xmidi/ui/DialogPreset$11;
.super Ljava/lang/Object;
.source "DialogPreset.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogPreset;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private dialogProgram:Lnet/duceng/xmidi/ui/DialogProgram;

.field private populProgram:Landroid/widget/PopupWindow;

.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogPreset;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogPreset;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 237
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 8
    .param p1, "v2"    # Landroid/view/View;

    .line 243
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogPreset;->access$200(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/CheckBox;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 244
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->populProgram:Landroid/widget/PopupWindow;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 245
    const/4 v0, 0x1

    new-array v2, v0, [Landroid/widget/PopupWindow;

    .line 246
    .local v2, "ph":[Landroid/widget/PopupWindow;
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-virtual {v3}, Lnet/duceng/xmidi/ui/DialogPreset;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v3

    const/4 v4, 0x0

    move-object v5, v4

    check-cast v5, Landroid/view/ViewGroup;

    const v5, 0x7f050015

    invoke-virtual {v3, v5, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ListView;

    .line 247
    .local v3, "lv":Landroid/widget/ListView;
    const v4, 0x7f020002

    invoke-virtual {v3, v4}, Landroid/widget/ListView;->setBackgroundResource(I)V

    .line 248
    invoke-virtual {v3, v1, v1, v1, v1}, Landroid/widget/ListView;->setPadding(IIII)V

    .line 249
    new-instance v4, Landroid/widget/ArrayAdapter;

    iget-object v5, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-virtual {v5}, Lnet/duceng/xmidi/ui/DialogPreset;->getContext()Landroid/content/Context;

    move-result-object v5

    iget-object v6, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v6}, Lnet/duceng/xmidi/ui/DialogPreset;->access$500(Lnet/duceng/xmidi/ui/DialogPreset;)[Ljava/lang/String;

    move-result-object v6

    const v7, 0x7f050018

    invoke-direct {v4, v5, v7, v6}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    .line 250
    .local v4, "aa":Landroid/widget/ArrayAdapter;, "Landroid/widget/ArrayAdapter<Ljava/lang/String;>;"
    invoke-virtual {v3, v4}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 251
    new-instance v5, Lnet/duceng/xmidi/ui/DialogPreset$11$1;

    invoke-direct {v5, p0, v2}, Lnet/duceng/xmidi/ui/DialogPreset$11$1;-><init>(Lnet/duceng/xmidi/ui/DialogPreset$11;[Landroid/widget/PopupWindow;)V

    invoke-virtual {v3, v5}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 259
    new-instance v5, Landroid/widget/PopupWindow;

    const/4 v6, -0x2

    invoke-direct {v5, v3, v6, v6}, Landroid/widget/PopupWindow;-><init>(Landroid/view/View;II)V

    iput-object v5, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->populProgram:Landroid/widget/PopupWindow;

    .line 260
    iget-object v5, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->populProgram:Landroid/widget/PopupWindow;

    aput-object v5, v2, v1

    .line 261
    iget-object v5, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->populProgram:Landroid/widget/PopupWindow;

    new-instance v6, Landroid/graphics/drawable/ColorDrawable;

    const v7, 0x106000d

    invoke-direct {v6, v7}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v5, v6}, Landroid/widget/PopupWindow;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 262
    iget-object v5, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->populProgram:Landroid/widget/PopupWindow;

    invoke-virtual {v5, v0}, Landroid/widget/PopupWindow;->setFocusable(Z)V

    .line 264
    .end local v2    # "ph":[Landroid/widget/PopupWindow;
    .end local v3    # "lv":Landroid/widget/ListView;
    .end local v4    # "aa":Landroid/widget/ArrayAdapter;, "Landroid/widget/ArrayAdapter<Ljava/lang/String;>;"
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->populProgram:Landroid/widget/PopupWindow;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$300(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/Button;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Button;->getWidth()I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/PopupWindow;->setWidth(I)V

    .line 265
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->populProgram:Landroid/widget/PopupWindow;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$300(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/Button;

    move-result-object v2

    invoke-virtual {v0, v2, v1, v1}, Landroid/widget/PopupWindow;->showAsDropDown(Landroid/view/View;II)V

    .line 266
    return-void

    .line 268
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->dialogProgram:Lnet/duceng/xmidi/ui/DialogProgram;

    if-nez v0, :cond_2

    .line 269
    new-instance v0, Lnet/duceng/xmidi/ui/DialogProgram;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-virtual {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v2, v2, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/ui/DialogProgram;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->dialogProgram:Lnet/duceng/xmidi/ui/DialogProgram;

    .line 270
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->dialogProgram:Lnet/duceng/xmidi/ui/DialogProgram;

    .line 271
    .local v0, "dpFinal":Lnet/duceng/xmidi/ui/DialogProgram;
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->dialogProgram:Lnet/duceng/xmidi/ui/DialogProgram;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$11$2;

    invoke-direct {v2, p0, v0}, Lnet/duceng/xmidi/ui/DialogPreset$11$2;-><init>(Lnet/duceng/xmidi/ui/DialogPreset$11;Lnet/duceng/xmidi/ui/DialogProgram;)V

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/ui/DialogProgram;->setOnClickListener(Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;)V

    .line 281
    .end local v0    # "dpFinal":Lnet/duceng/xmidi/ui/DialogProgram;
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->dialogProgram:Lnet/duceng/xmidi/ui/DialogProgram;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogProgram;->show()V

    .line 282
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->dialogProgram:Lnet/duceng/xmidi/ui/DialogProgram;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$11;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v2

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogProgram;->setSelected(I)V

    .line 283
    return-void
.end method
