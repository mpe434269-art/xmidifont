.class Lnet/duceng/xmidi/ui/DialogPreset$12$1;
.super Ljava/lang/Object;
.source "DialogPreset.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogPreset$12;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/ui/DialogPreset$12;

.field final synthetic val$psf:[Landroid/widget/PopupWindow;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogPreset$12;[Landroid/widget/PopupWindow;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/ui/DialogPreset$12;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 299
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogPreset$12$1;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$12;

    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogPreset$12$1;->val$psf:[Landroid/widget/PopupWindow;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 3
    .param p2, "v3"    # Landroid/view/View;
    .param p3, "pos"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 302
    .local p1, "arg0":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$12$1;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$12;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$12$1;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$12;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v1

    long-to-int v2, p4

    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->setSFont(II)V

    .line 303
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$12$1;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$12;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogPreset;->access$1600(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/Button;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$12$1;->this$1:Lnet/duceng/xmidi/ui/DialogPreset$12;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getSFonts()Lnet/duceng/xmidi/util/MyArray;

    move-result-object v1

    invoke-virtual {v1, p3}, Lnet/duceng/xmidi/util/MyArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 304
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$12$1;->val$psf:[Landroid/widget/PopupWindow;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->dismiss()V

    .line 305
    return-void
.end method
