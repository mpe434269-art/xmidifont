.class Lnet/duceng/xmidi/ui/DialogPreset$12;
.super Ljava/lang/Object;
.source "DialogPreset.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogPreset;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private as:Lnet/duceng/xmidi/util/AdapterSFont;

.field private lv:Landroid/widget/ListView;

.field private populSFont:Landroid/widget/PopupWindow;

.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogPreset;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogPreset;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 285
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6
    .param p1, "v2"    # Landroid/view/View;

    .line 292
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->populSFont:Landroid/widget/PopupWindow;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 293
    const/4 v0, 0x1

    new-array v2, v0, [Landroid/widget/PopupWindow;

    .line 294
    .local v2, "psf":[Landroid/widget/PopupWindow;
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-virtual {v3}, Lnet/duceng/xmidi/ui/DialogPreset;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v3

    const/4 v4, 0x0

    move-object v5, v4

    check-cast v5, Landroid/view/ViewGroup;

    const v5, 0x7f050015

    invoke-virtual {v3, v5, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ListView;

    iput-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->lv:Landroid/widget/ListView;

    .line 295
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->lv:Landroid/widget/ListView;

    const v4, 0x7f020002

    invoke-virtual {v3, v4}, Landroid/widget/ListView;->setBackgroundResource(I)V

    .line 296
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->lv:Landroid/widget/ListView;

    invoke-virtual {v3, v1, v1, v1, v1}, Landroid/widget/ListView;->setPadding(IIII)V

    .line 297
    new-instance v3, Lnet/duceng/xmidi/util/AdapterSFont;

    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-virtual {v4}, Lnet/duceng/xmidi/ui/DialogPreset;->getContext()Landroid/content/Context;

    move-result-object v4

    iget-object v5, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v5, v5, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v5}, Lnet/duceng/xsynth/Synth;->getSFonts()Lnet/duceng/xmidi/util/MyArray;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Lnet/duceng/xmidi/util/AdapterSFont;-><init>(Landroid/content/Context;Lnet/duceng/xmidi/util/MyArray;)V

    iput-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->as:Lnet/duceng/xmidi/util/AdapterSFont;

    .line 298
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->lv:Landroid/widget/ListView;

    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->as:Lnet/duceng/xmidi/util/AdapterSFont;

    invoke-virtual {v3, v4}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 299
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->lv:Landroid/widget/ListView;

    new-instance v4, Lnet/duceng/xmidi/ui/DialogPreset$12$1;

    invoke-direct {v4, p0, v2}, Lnet/duceng/xmidi/ui/DialogPreset$12$1;-><init>(Lnet/duceng/xmidi/ui/DialogPreset$12;[Landroid/widget/PopupWindow;)V

    invoke-virtual {v3, v4}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 307
    new-instance v3, Landroid/widget/PopupWindow;

    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->lv:Landroid/widget/ListView;

    const/4 v5, -0x2

    invoke-direct {v3, v4, v5, v5}, Landroid/widget/PopupWindow;-><init>(Landroid/view/View;II)V

    iput-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->populSFont:Landroid/widget/PopupWindow;

    .line 308
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->populSFont:Landroid/widget/PopupWindow;

    aput-object v3, v2, v1

    .line 309
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->populSFont:Landroid/widget/PopupWindow;

    new-instance v4, Landroid/graphics/drawable/ColorDrawable;

    const v5, 0x106000d

    invoke-direct {v4, v5}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v3, v4}, Landroid/widget/PopupWindow;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 310
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->populSFont:Landroid/widget/PopupWindow;

    invoke-virtual {v3, v0}, Landroid/widget/PopupWindow;->setFocusable(Z)V

    .line 312
    .end local v2    # "psf":[Landroid/widget/PopupWindow;
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->as:Lnet/duceng/xmidi/util/AdapterSFont;

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/AdapterSFont;->notifyDataSetChanged()V

    .line 313
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->as:Lnet/duceng/xmidi/util/AdapterSFont;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v2, v2, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2}, Lnet/duceng/xsynth/Synth;->getSFonts()Lnet/duceng/xmidi/util/MyArray;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v3, v3, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v4, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v4}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v4

    invoke-virtual {v3, v4}, Lnet/duceng/xsynth/Synth;->getSFont(I)I

    move-result v3

    invoke-virtual {v2, v3}, Lnet/duceng/xmidi/util/MyArray;->indexOfKey(I)I

    move-result v2

    invoke-virtual {v0, v2}, Lnet/duceng/xmidi/util/AdapterSFont;->setSelected(I)V

    .line 314
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->populSFont:Landroid/widget/PopupWindow;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$1600(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/Button;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Button;->getWidth()I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/PopupWindow;->setWidth(I)V

    .line 315
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->populSFont:Landroid/widget/PopupWindow;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$12;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$1600(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/Button;

    move-result-object v2

    invoke-virtual {v0, v2, v1, v1}, Landroid/widget/PopupWindow;->showAsDropDown(Landroid/view/View;II)V

    .line 316
    return-void
.end method
