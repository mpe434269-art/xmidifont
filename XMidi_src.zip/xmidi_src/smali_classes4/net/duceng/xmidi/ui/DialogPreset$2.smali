.class Lnet/duceng/xmidi/ui/DialogPreset$2;
.super Ljava/lang/Object;
.source "DialogPreset.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogPreset;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogPreset;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogPreset;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 93
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v2"    # Landroid/view/View;

    .line 97
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v1

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$200(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/CheckBox;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v2

    if-eqz v2, :cond_0

    sget v2, Lnet/duceng/xsynth/Synth;->DRUMS_BANK:I

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    invoke-virtual {v0, v1, v2}, Lnet/duceng/xsynth/Synth;->setBank(II)V

    .line 98
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogPreset;->access$300(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 99
    .local v0, "p":I
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$300(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/Button;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v2, v2, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v3}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v3

    invoke-virtual {v2, v3}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 100
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v2

    invoke-virtual {v1, v2, v0}, Lnet/duceng/xsynth/Synth;->setPreset(II)V

    .line 101
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$300(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/Button;

    move-result-object v1

    .line 102
    .local v1, "button":Landroid/widget/Button;
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$200(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/CheckBox;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v2

    if-nez v2, :cond_1

    .line 103
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$400(Lnet/duceng/xmidi/ui/DialogPreset;)[Ljava/lang/String;

    move-result-object v2

    aget-object v2, v2, v0

    .local v2, "str":Ljava/lang/String;
    goto :goto_1

    .line 105
    .end local v2    # "str":Ljava/lang/String;
    :cond_1
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$2;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$500(Lnet/duceng/xmidi/ui/DialogPreset;)[Ljava/lang/String;

    move-result-object v2

    invoke-static {}, Lnet/duceng/xmidi/ui/DialogPreset;->access$600()I

    move-result v3

    div-int v3, v0, v3

    aget-object v2, v2, v3

    .line 107
    .restart local v2    # "str":Ljava/lang/String;
    :goto_1
    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 108
    return-void
.end method
