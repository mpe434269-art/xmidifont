.class Lnet/duceng/xmidi/ui/DialogPreset$3;
.super Ljava/lang/Object;
.source "DialogPreset.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogPreset;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogPreset;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogPreset;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 110
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 4
    .param p1, "arg0"    # Landroid/widget/SeekBar;
    .param p2, "progress"    # I
    .param p3, "arg2"    # Z

    .line 113
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogPreset;->access$700(Lnet/duceng/xmidi/ui/DialogPreset;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 114
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogPreset;->access$800(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/TextView;

    move-result-object v0

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 115
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v0, v0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v1

    invoke-virtual {v0, v1, p2}, Lnet/duceng/xsynth/Synth;->setKeyVolume(II)V

    .line 116
    return-void

    .line 118
    :cond_0
    add-int/lit8 v0, p2, -0x32

    .line 119
    .local v0, "v2":I
    if-nez v0, :cond_1

    .line 120
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$800(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/TextView;

    move-result-object v1

    const-string v2, "0"

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 121
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v2

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getControls(I)Lnet/duceng/xmidi/util/MyArray;

    move-result-object v1

    sget-byte v2, Lnet/duceng/xsynth/XSynth;->VOLUME_MSB:B

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/util/MyArray;->remove(I)V

    .line 122
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v2

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->refreshVolume(I)V

    goto :goto_1

    .line 124
    :cond_1
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->access$800(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    if-lez v0, :cond_2

    const-string v3, "+"

    goto :goto_0

    :cond_2
    const-string v3, ""

    :goto_0
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "%"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 125
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v2

    sget-byte v3, Lnet/duceng/xsynth/XSynth;->VOLUME_MSB:B

    invoke-virtual {v1, v2, v3, v0}, Lnet/duceng/xsynth/Synth;->setControl(III)V

    .line 126
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v1, v1, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset$3;->this$0:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I

    move-result v2

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->refreshVolume(I)V

    .line 128
    :goto_1
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 132
    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0
    .param p1, "arg0"    # Landroid/widget/SeekBar;

    .line 136
    return-void
.end method
