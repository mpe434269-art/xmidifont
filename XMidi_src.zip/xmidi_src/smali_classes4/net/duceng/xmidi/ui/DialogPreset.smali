.class public Lnet/duceng/xmidi/ui/DialogPreset;
.super Lnet/duceng/xmidi/ui/XDialog;
.source "DialogPreset.java"


# static fields
.field private static DFix:I


# instance fields
.field private absoluteVolume:Z

.field private chan:I

.field private chorus_locked:Landroid/widget/CheckBox;

.field private chorus_seek:Landroid/widget/SeekBar;

.field private chorus_value:Landroid/widget/TextView;

.field private drums:[Ljava/lang/String;

.field private ifdrums:Landroid/widget/CheckBox;

.field private ifmute:Landroid/widget/CheckBox;

.field private instruments:[Ljava/lang/String;

.field private pan_seek:Landroid/widget/SeekBar;

.field private pan_value:Landroid/widget/TextView;

.field private program:Landroid/widget/Button;

.field private reverb_locked:Landroid/widget/CheckBox;

.field private reverb_seek:Landroid/widget/SeekBar;

.field private reverb_value:Landroid/widget/TextView;

.field private sfont:Landroid/widget/Button;

.field private sustain_locked:Landroid/widget/CheckBox;

.field private sustain_seek:Landroid/widget/SeekBar;

.field private sustain_value:Landroid/widget/TextView;

.field protected synth:Lnet/duceng/xsynth/Synth;

.field private volume_seek:Landroid/widget/SeekBar;

.field private volume_value:Landroid/widget/TextView;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 32
    const/16 v0, 0x8

    sput v0, Lnet/duceng/xmidi/ui/DialogPreset;->DFix:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "s"    # Lnet/duceng/xsynth/Synth;

    .line 56
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    .line 26
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->absoluteVolume:Z

    .line 57
    iput v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    .line 58
    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    .line 59
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/ui/DialogPreset;)I
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    return v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/CheckBox;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->ifmute:Landroid/widget/CheckBox;

    return-object v0
.end method

.method static synthetic access$1000(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sustain_value:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$1100(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/CheckBox;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sustain_locked:Landroid/widget/CheckBox;

    return-object v0
.end method

.method static synthetic access$1200(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->reverb_value:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$1300(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/CheckBox;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->reverb_locked:Landroid/widget/CheckBox;

    return-object v0
.end method

.method static synthetic access$1400(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chorus_value:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$1500(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/CheckBox;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chorus_locked:Landroid/widget/CheckBox;

    return-object v0
.end method

.method static synthetic access$1600(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sfont:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$200(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/CheckBox;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->ifdrums:Landroid/widget/CheckBox;

    return-object v0
.end method

.method static synthetic access$300(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->program:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$400(Lnet/duceng/xmidi/ui/DialogPreset;)[Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->instruments:[Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$500(Lnet/duceng/xmidi/ui/DialogPreset;)[Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->drums:[Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$600()I
    .locals 1

    .line 24
    sget v0, Lnet/duceng/xmidi/ui/DialogPreset;->DFix:I

    return v0
.end method

.method static synthetic access$700(Lnet/duceng/xmidi/ui/DialogPreset;)Z
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-boolean v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->absoluteVolume:Z

    return v0
.end method

.method static synthetic access$800(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->volume_value:Landroid/widget/TextView;

    return-object v0
.end method

.method static synthetic access$900(Lnet/duceng/xmidi/ui/DialogPreset;)Landroid/widget/TextView;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 24
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->pan_value:Landroid/widget/TextView;

    return-object v0
.end method


# virtual methods
.method public getChannel()I
    .locals 1

    .line 361
    iget v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    return v0
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 63
    invoke-super {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;->onCreate(Landroid/os/Bundle;)V

    .line 64
    const v0, 0x7f030041

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogPreset;->setIcon(I)V

    .line 65
    const v0, 0x7f060025

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogPreset;->setTitle(I)V

    .line 66
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogPreset;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f05000d

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    .line 67
    .local v0, "v":Landroid/view/View;
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogPreset;->setContentView(Landroid/view/View;)V

    .line 68
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogPreset;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f010004

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->instruments:[Ljava/lang/String;

    .line 69
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogPreset;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f010002

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->drums:[Ljava/lang/String;

    .line 70
    const v1, 0x7f0400a4

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->ifmute:Landroid/widget/CheckBox;

    .line 71
    const v1, 0x7f0400a3

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->ifdrums:Landroid/widget/CheckBox;

    .line 72
    const v1, 0x7f0400a7

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->program:Landroid/widget/Button;

    .line 73
    const v1, 0x7f0400ab

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sfont:Landroid/widget/Button;

    .line 74
    const v1, 0x7f0400b0

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->volume_value:Landroid/widget/TextView;

    .line 75
    const v1, 0x7f0400af

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->volume_seek:Landroid/widget/SeekBar;

    .line 76
    const v1, 0x7f0400a6

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->pan_value:Landroid/widget/TextView;

    .line 77
    const v1, 0x7f0400a5

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->pan_seek:Landroid/widget/SeekBar;

    .line 78
    const v1, 0x7f0400ae

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sustain_value:Landroid/widget/TextView;

    .line 79
    const v1, 0x7f0400ad

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sustain_seek:Landroid/widget/SeekBar;

    .line 80
    const v1, 0x7f0400ac

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sustain_locked:Landroid/widget/CheckBox;

    .line 81
    const v1, 0x7f0400aa

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->reverb_value:Landroid/widget/TextView;

    .line 82
    const v1, 0x7f0400a9

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->reverb_seek:Landroid/widget/SeekBar;

    .line 83
    const v1, 0x7f0400a8

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->reverb_locked:Landroid/widget/CheckBox;

    .line 84
    const v1, 0x7f0400a2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chorus_value:Landroid/widget/TextView;

    .line 85
    const v1, 0x7f0400a1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/SeekBar;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chorus_seek:Landroid/widget/SeekBar;

    .line 86
    const v1, 0x7f0400a0

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chorus_locked:Landroid/widget/CheckBox;

    .line 87
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->ifmute:Landroid/widget/CheckBox;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$1;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$1;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 93
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->ifdrums:Landroid/widget/CheckBox;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$2;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$2;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 110
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->volume_seek:Landroid/widget/SeekBar;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$3;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$3;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 138
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->pan_seek:Landroid/widget/SeekBar;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$4;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$4;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 153
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sustain_seek:Landroid/widget/SeekBar;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$5;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$5;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 171
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sustain_locked:Landroid/widget/CheckBox;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$6;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$6;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 181
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->reverb_seek:Landroid/widget/SeekBar;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$7;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$7;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 199
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->reverb_locked:Landroid/widget/CheckBox;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$8;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$8;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 209
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chorus_seek:Landroid/widget/SeekBar;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$9;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$9;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 227
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chorus_locked:Landroid/widget/CheckBox;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$10;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$10;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 237
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->program:Landroid/widget/Button;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$11;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$11;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 285
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sfont:Landroid/widget/Button;

    new-instance v2, Lnet/duceng/xmidi/ui/DialogPreset$12;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogPreset$12;-><init>(Lnet/duceng/xmidi/ui/DialogPreset;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 318
    return-void
.end method

.method protected onStart()V
    .locals 6

    .line 322
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogPreset;->getContext()Landroid/content/Context;

    move-result-object v1

    const v2, 0x7f060025

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogPreset;->setTitle(Ljava/lang/CharSequence;)V

    .line 323
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->ifmute:Landroid/widget/CheckBox;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->isMute(I)Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 324
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->ifdrums:Landroid/widget/CheckBox;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getBank(I)I

    move-result v1

    sget v2, Lnet/duceng/xsynth/Synth;->DRUMS_BANK:I

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-ne v1, v2, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 325
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->program:Landroid/widget/Button;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 326
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->program:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->ifdrums:Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->drums:[Ljava/lang/String;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v5, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v2, v5}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v2

    sget v5, Lnet/duceng/xmidi/ui/DialogPreset;->DFix:I

    div-int/2addr v2, v5

    aget-object v1, v1, v2

    goto :goto_1

    :cond_1
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->instruments:[Ljava/lang/String;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v5, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v2, v5}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v2

    aget-object v1, v1, v2

    :goto_1
    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 327
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sfont:Landroid/widget/Button;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getFontFile(I)Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 328
    iget-boolean v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->absoluteVolume:Z

    if-eqz v0, :cond_2

    .line 329
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->volume_seek:Landroid/widget/SeekBar;

    const/16 v1, 0x7f

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setMax(I)V

    .line 330
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v0, v1}, Lnet/duceng/xsynth/Synth;->getBaseVolume(I)I

    move-result v0

    .line 331
    .local v0, "base":I
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->volume_seek:Landroid/widget/SeekBar;

    invoke-virtual {v1, v0}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 332
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->volume_value:Landroid/widget/TextView;

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 333
    .end local v0    # "base":I
    goto :goto_3

    .line 334
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->volume_seek:Landroid/widget/SeekBar;

    const/16 v1, 0x64

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setMax(I)V

    .line 335
    const/4 v0, 0x0

    .line 336
    .local v0, "v":I
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getControls(I)Lnet/duceng/xmidi/util/MyArray;

    move-result-object v1

    sget-byte v2, Lnet/duceng/xsynth/XSynth;->VOLUME_MSB:B

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/util/MyArray;->indexOfKey(I)I

    move-result v1

    if-ltz v1, :cond_3

    .line 337
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getControls(I)Lnet/duceng/xmidi/util/MyArray;

    move-result-object v1

    sget-byte v2, Lnet/duceng/xsynth/XSynth;->VOLUME_MSB:B

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/util/MyArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 339
    :cond_3
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->volume_seek:Landroid/widget/SeekBar;

    add-int/lit8 v2, v0, 0x32

    invoke-virtual {v1, v2}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 340
    if-nez v0, :cond_4

    .line 341
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->volume_value:Landroid/widget/TextView;

    const-string v2, "0"

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_3

    .line 343
    :cond_4
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->volume_value:Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    if-lez v0, :cond_5

    const-string v5, "+"

    goto :goto_2

    :cond_5
    const-string v5, ""

    :goto_2
    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, "%"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 346
    .end local v0    # "v":I
    :goto_3
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->pan_value:Landroid/widget/TextView;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getPan(I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 347
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->pan_seek:Landroid/widget/SeekBar;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getPan(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 348
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sustain_value:Landroid/widget/TextView;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getSustain(I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 349
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sustain_seek:Landroid/widget/SeekBar;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getSustain(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 350
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->sustain_locked:Landroid/widget/CheckBox;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    sget-byte v5, Lnet/duceng/xsynth/XSynth;->SUSTAIN_SWITCH:B

    invoke-virtual {v1, v2, v5}, Lnet/duceng/xsynth/Synth;->getControl(II)I

    move-result v1

    if-ltz v1, :cond_6

    const/4 v1, 0x1

    goto :goto_4

    :cond_6
    const/4 v1, 0x0

    :goto_4
    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 351
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->reverb_value:Landroid/widget/TextView;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getReverb(I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 352
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->reverb_seek:Landroid/widget/SeekBar;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getReverb(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 353
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->reverb_locked:Landroid/widget/CheckBox;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    sget-byte v5, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH1:B

    invoke-virtual {v1, v2, v5}, Lnet/duceng/xsynth/Synth;->getControl(II)I

    move-result v1

    if-ltz v1, :cond_7

    const/4 v1, 0x1

    goto :goto_5

    :cond_7
    const/4 v1, 0x0

    :goto_5
    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 354
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chorus_value:Landroid/widget/TextView;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getChorus(I)I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 355
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chorus_seek:Landroid/widget/SeekBar;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getChorus(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 356
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chorus_locked:Landroid/widget/CheckBox;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->synth:Lnet/duceng/xsynth/Synth;

    iget v2, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    sget-byte v5, Lnet/duceng/xsynth/XSynth;->EFFECTS_DEPTH3:B

    invoke-virtual {v1, v2, v5}, Lnet/duceng/xsynth/Synth;->getControl(II)I

    move-result v1

    if-ltz v1, :cond_8

    goto :goto_6

    :cond_8
    const/4 v3, 0x0

    :goto_6
    invoke-virtual {v0, v3}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 357
    invoke-super {p0}, Lnet/duceng/xmidi/ui/XDialog;->onStart()V

    .line 358
    return-void
.end method

.method public setAbsoluteVolume(Z)V
    .locals 0
    .param p1, "absolute"    # Z

    .line 29
    iput-boolean p1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->absoluteVolume:Z

    .line 30
    return-void
.end method

.method public setChannel(I)V
    .locals 0
    .param p1, "c"    # I

    .line 365
    iput p1, p0, Lnet/duceng/xmidi/ui/DialogPreset;->chan:I

    .line 366
    return-void
.end method
