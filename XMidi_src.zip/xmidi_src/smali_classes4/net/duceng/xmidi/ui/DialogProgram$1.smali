.class Lnet/duceng/xmidi/ui/DialogProgram$1;
.super Ljava/lang/Object;
.source "DialogProgram.java"

# interfaces
.implements Landroid/widget/ExpandableListView$OnChildClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogProgram;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogProgram;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogProgram;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogProgram;

    .line 36
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogProgram$1;->this$0:Lnet/duceng/xmidi/ui/DialogProgram;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onChildClick(Landroid/widget/ExpandableListView;Landroid/view/View;IIJ)Z
    .locals 2
    .param p1, "parent"    # Landroid/widget/ExpandableListView;
    .param p2, "v"    # Landroid/view/View;
    .param p3, "gPos"    # I
    .param p4, "cPos"    # I
    .param p5, "id"    # J

    .line 39
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogProgram$1;->this$0:Lnet/duceng/xmidi/ui/DialogProgram;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogProgram;->access$000(Lnet/duceng/xmidi/ui/DialogProgram;)Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 40
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogProgram$1;->this$0:Lnet/duceng/xmidi/ui/DialogProgram;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogProgram;->access$000(Lnet/duceng/xmidi/ui/DialogProgram;)Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;

    move-result-object v0

    long-to-int v1, p5

    invoke-interface {v0, v1}, Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;->onClick(I)Z

    move-result v0

    return v0

    .line 42
    :cond_0
    const/4 v0, 0x0

    return v0
.end method
