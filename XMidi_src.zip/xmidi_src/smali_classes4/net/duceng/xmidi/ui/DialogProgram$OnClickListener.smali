.class public interface abstract Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;
.super Ljava/lang/Object;
.source "DialogProgram.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/ui/DialogProgram;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnClickListener"
.end annotation


# virtual methods
.method public abstract onClick(I)Z
.end method
