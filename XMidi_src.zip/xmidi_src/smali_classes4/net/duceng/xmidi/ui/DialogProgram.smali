.class public Lnet/duceng/xmidi/ui/DialogProgram;
.super Lnet/duceng/xmidi/ui/XDialog;
.source "DialogProgram.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;
    }
.end annotation


# instance fields
.field private ap:Lnet/duceng/xmidi/util/AdapterProgram;

.field private elv:Landroid/widget/ExpandableListView;

.field private onClickListener:Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;

.field protected synth:Lnet/duceng/xsynth/Synth;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "s"    # Lnet/duceng/xsynth/Synth;

    .line 24
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    .line 25
    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogProgram;->synth:Lnet/duceng/xsynth/Synth;

    .line 26
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/ui/DialogProgram;)Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogProgram;

    .line 13
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogProgram;->onClickListener:Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;

    return-object v0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 30
    invoke-super {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;->onCreate(Landroid/os/Bundle;)V

    .line 31
    const v0, 0x7f030041

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogProgram;->setIcon(I)V

    .line 32
    const v0, 0x7f060013

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogProgram;->setTitle(I)V

    .line 33
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogProgram;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050016

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ExpandableListView;

    iput-object v0, p0, Lnet/duceng/xmidi/ui/DialogProgram;->elv:Landroid/widget/ExpandableListView;

    .line 34
    new-instance v0, Lnet/duceng/xmidi/util/AdapterProgram;

    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogProgram;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lnet/duceng/xmidi/util/AdapterProgram;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lnet/duceng/xmidi/ui/DialogProgram;->ap:Lnet/duceng/xmidi/util/AdapterProgram;

    .line 35
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogProgram;->elv:Landroid/widget/ExpandableListView;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogProgram;->ap:Lnet/duceng/xmidi/util/AdapterProgram;

    invoke-virtual {v0, v1}, Landroid/widget/ExpandableListView;->setAdapter(Landroid/widget/ExpandableListAdapter;)V

    .line 36
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogProgram;->elv:Landroid/widget/ExpandableListView;

    new-instance v1, Lnet/duceng/xmidi/ui/DialogProgram$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/ui/DialogProgram$1;-><init>(Lnet/duceng/xmidi/ui/DialogProgram;)V

    invoke-virtual {v0, v1}, Landroid/widget/ExpandableListView;->setOnChildClickListener(Landroid/widget/ExpandableListView$OnChildClickListener;)V

    .line 45
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogProgram;->elv:Landroid/widget/ExpandableListView;

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogProgram;->setContentView(Landroid/view/View;)V

    .line 46
    return-void
.end method

.method public setOnClickListener(Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;

    .line 49
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogProgram;->onClickListener:Lnet/duceng/xmidi/ui/DialogProgram$OnClickListener;

    .line 50
    return-void
.end method

.method public setSelected(I)V
    .locals 4
    .param p1, "pos"    # I

    .line 53
    div-int/lit8 v0, p1, 0x8

    .line 54
    .local v0, "gpos":I
    rem-int/lit8 v1, p1, 0x8

    .line 55
    .local v1, "cpos":I
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogProgram;->ap:Lnet/duceng/xmidi/util/AdapterProgram;

    invoke-virtual {v2, p1}, Lnet/duceng/xmidi/util/AdapterProgram;->setSelected(I)V

    .line 56
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogProgram;->ap:Lnet/duceng/xmidi/util/AdapterProgram;

    invoke-virtual {v2}, Lnet/duceng/xmidi/util/AdapterProgram;->notifyDataSetChanged()V

    .line 57
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogProgram;->ap:Lnet/duceng/xmidi/util/AdapterProgram;

    invoke-virtual {v3}, Lnet/duceng/xmidi/util/AdapterProgram;->getGroupCount()I

    move-result v3

    if-ge v2, v3, :cond_0

    .line 58
    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogProgram;->elv:Landroid/widget/ExpandableListView;

    invoke-virtual {v3, v2}, Landroid/widget/ExpandableListView;->collapseGroup(I)Z

    .line 57
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 60
    .end local v2    # "i":I
    :cond_0
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogProgram;->elv:Landroid/widget/ExpandableListView;

    invoke-virtual {v2, v0}, Landroid/widget/ExpandableListView;->expandGroup(I)Z

    .line 61
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogProgram;->elv:Landroid/widget/ExpandableListView;

    const/4 v3, 0x1

    invoke-virtual {v2, v0, v1, v3}, Landroid/widget/ExpandableListView;->setSelectedChild(IIZ)Z

    .line 62
    return-void
.end method
