.class Lnet/duceng/xmidi/ui/DialogRhythm$1;
.super Ljava/lang/Object;
.source "DialogRhythm.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogRhythm;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogRhythm;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogRhythm;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogRhythm;

    .line 38
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogRhythm$1;->this$0:Lnet/duceng/xmidi/ui/DialogRhythm;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 2
    .param p2, "v"    # Landroid/view/View;
    .param p3, "pos"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 41
    .local p1, "arg0":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogRhythm$1;->this$0:Lnet/duceng/xmidi/ui/DialogRhythm;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogRhythm;->access$000(Lnet/duceng/xmidi/ui/DialogRhythm;)Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 42
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogRhythm$1;->this$0:Lnet/duceng/xmidi/ui/DialogRhythm;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogRhythm;->access$000(Lnet/duceng/xmidi/ui/DialogRhythm;)Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogRhythm$1;->this$0:Lnet/duceng/xmidi/ui/DialogRhythm;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogRhythm;->access$100(Lnet/duceng/xmidi/ui/DialogRhythm;)Lnet/duceng/xmidi/util/AdapterRhythm;

    move-result-object v1

    invoke-virtual {v1, p3}, Lnet/duceng/xmidi/util/AdapterRhythm;->getItem(I)Lnet/duceng/xmidi/util/Rhythm;

    move-result-object v1

    invoke-interface {v0, v1}, Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;->onSelect(Lnet/duceng/xmidi/util/Rhythm;)Z

    .line 44
    :cond_0
    return-void
.end method
