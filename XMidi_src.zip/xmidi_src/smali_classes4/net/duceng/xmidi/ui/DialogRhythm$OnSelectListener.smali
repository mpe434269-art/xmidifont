.class public interface abstract Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;
.super Ljava/lang/Object;
.source "DialogRhythm.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/ui/DialogRhythm;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnSelectListener"
.end annotation


# virtual methods
.method public abstract onSelect(Lnet/duceng/xmidi/util/Rhythm;)Z
.end method
