.class public Lnet/duceng/xmidi/ui/DialogRhythm;
.super Lnet/duceng/xmidi/ui/XDialog;
.source "DialogRhythm.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;
    }
.end annotation


# instance fields
.field private ar:Lnet/duceng/xmidi/util/AdapterRhythm;

.field private onSelectListener:Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;

.field protected synth:Lnet/duceng/xsynth/Synth;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V
    .locals 2
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "s"    # Lnet/duceng/xsynth/Synth;

    .line 26
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    .line 27
    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogRhythm;->synth:Lnet/duceng/xsynth/Synth;

    .line 28
    new-instance v0, Lnet/duceng/xmidi/util/AdapterRhythm;

    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogRhythm;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lnet/duceng/xmidi/util/AdapterRhythm;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lnet/duceng/xmidi/ui/DialogRhythm;->ar:Lnet/duceng/xmidi/util/AdapterRhythm;

    .line 29
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/ui/DialogRhythm;)Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogRhythm;

    .line 16
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogRhythm;->onSelectListener:Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;

    return-object v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/ui/DialogRhythm;)Lnet/duceng/xmidi/util/AdapterRhythm;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogRhythm;

    .line 16
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogRhythm;->ar:Lnet/duceng/xmidi/util/AdapterRhythm;

    return-object v0
.end method


# virtual methods
.method public getAdapter()Lnet/duceng/xmidi/util/AdapterRhythm;
    .locals 1

    .line 56
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogRhythm;->ar:Lnet/duceng/xmidi/util/AdapterRhythm;

    return-object v0
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 33
    invoke-super {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;->onCreate(Landroid/os/Bundle;)V

    .line 34
    const v0, 0x7f060021

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogRhythm;->setTitle(I)V

    .line 35
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogRhythm;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050012

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/GridView;

    .line 36
    .local v0, "gv":Landroid/widget/GridView;
    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/widget/GridView;->setNumColumns(I)V

    .line 37
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogRhythm;->ar:Lnet/duceng/xmidi/util/AdapterRhythm;

    invoke-virtual {v0, v1}, Landroid/widget/GridView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 38
    new-instance v1, Lnet/duceng/xmidi/ui/DialogRhythm$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/ui/DialogRhythm$1;-><init>(Lnet/duceng/xmidi/ui/DialogRhythm;)V

    invoke-virtual {v0, v1}, Landroid/widget/GridView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 46
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogRhythm;->setContentView(Landroid/view/View;)V

    .line 47
    return-void
.end method

.method protected onStart()V
    .locals 2

    .line 51
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogRhythm;->ar:Lnet/duceng/xmidi/util/AdapterRhythm;

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogRhythm;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1}, Lnet/duceng/xsynth/Synth;->getNumerator()I

    move-result v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/util/AdapterRhythm;->setBeat(I)V

    .line 52
    invoke-super {p0}, Lnet/duceng/xmidi/ui/XDialog;->onStart()V

    .line 53
    return-void
.end method

.method public setOnSelectListener(Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;

    .line 60
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogRhythm;->onSelectListener:Lnet/duceng/xmidi/ui/DialogRhythm$OnSelectListener;

    .line 61
    return-void
.end method
