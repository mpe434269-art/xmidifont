.class Lnet/duceng/xmidi/ui/DialogSty$1;
.super Ljava/lang/Object;
.source "DialogSty.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogSty;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogSty;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogSty;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogSty;

    .line 42
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogSty$1;->this$0:Lnet/duceng/xmidi/ui/DialogSty;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogSty$1;->this$0:Lnet/duceng/xmidi/ui/DialogSty;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogSty;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lnet/duceng/xmidi/util/Importer;->activityOf(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogSty$1;->this$0:Lnet/duceng/xmidi/ui/DialogSty;

    invoke-virtual {v1}, Lnet/duceng/xmidi/ui/DialogSty;->dismiss()V

    invoke-static {}, Lnet/duceng/xmidi/util/Importer;->pickIntent()Landroid/content/Intent;

    move-result-object v1

    const/16 v2, 0x1005

    invoke-virtual {v0, v1, v2}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    :cond_0
    return-void
.end method
