.class Lnet/duceng/xmidi/ui/DialogSty$2;
.super Ljava/lang/Object;
.source "DialogSty.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogSty;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogSty;

.field final synthetic val$lv:Landroid/widget/ListView;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogSty;Landroid/widget/ListView;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogSty;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 54
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogSty$2;->this$0:Lnet/duceng/xmidi/ui/DialogSty;

    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogSty$2;->val$lv:Landroid/widget/ListView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 3
    .param p2, "view"    # Landroid/view/View;
    .param p3, "pos"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 57
    .local p1, "arg0":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogSty$2;->val$lv:Landroid/widget/ListView;

    invoke-virtual {v0}, Landroid/widget/ListView;->getHeaderViewsCount()I

    move-result v0

    sub-int v0, p3, v0

    .line 58
    .local v0, "idx":I
    if-ltz v0, :cond_4

    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogSty$2;->this$0:Lnet/duceng/xmidi/ui/DialogSty;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogSty;->access$000(Lnet/duceng/xmidi/ui/DialogSty;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/xmidi/util/AdapterExplorer;->getCount()I

    move-result v1

    if-lt v0, v1, :cond_0

    goto :goto_2

    .line 61
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogSty$2;->this$0:Lnet/duceng/xmidi/ui/DialogSty;

    invoke-static {v1}, Lnet/duceng/xmidi/ui/DialogSty;->access$000(Lnet/duceng/xmidi/ui/DialogSty;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v1

    invoke-virtual {v1, v0}, Lnet/duceng/xmidi/util/AdapterExplorer;->getItem(I)Ljava/io/File;

    move-result-object v1

    .line 62
    .local v1, "f":Ljava/io/File;
    invoke-virtual {v1}, Ljava/io/File;->isDirectory()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {v1}, Ljava/io/File;->canExecute()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 63
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogSty$2;->this$0:Lnet/duceng/xmidi/ui/DialogSty;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogSty;->access$000(Lnet/duceng/xmidi/ui/DialogSty;)Lnet/duceng/xmidi/util/AdapterExplorer;

    move-result-object v2

    invoke-virtual {v2, v1}, Lnet/duceng/xmidi/util/AdapterExplorer;->setCurrentPath(Ljava/io/File;)V

    goto :goto_0

    .line 65
    :cond_1
    invoke-virtual {v1}, Ljava/io/File;->isFile()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-virtual {v1}, Ljava/io/File;->canRead()Z

    move-result v2

    if-eqz v2, :cond_3

    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogSty$2;->this$0:Lnet/duceng/xmidi/ui/DialogSty;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogSty;->access$100(Lnet/duceng/xmidi/ui/DialogSty;)Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;

    move-result-object v2

    if-nez v2, :cond_2

    goto :goto_1

    .line 68
    :cond_2
    iget-object v2, p0, Lnet/duceng/xmidi/ui/DialogSty$2;->this$0:Lnet/duceng/xmidi/ui/DialogSty;

    invoke-static {v2}, Lnet/duceng/xmidi/ui/DialogSty;->access$100(Lnet/duceng/xmidi/ui/DialogSty;)Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;

    move-result-object v2

    invoke-interface {v2, v1}, Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;->onSelect(Ljava/io/File;)V

    .line 70
    :goto_0
    return-void

    .line 66
    :cond_3
    :goto_1
    return-void

    .line 59
    .end local v1    # "f":Ljava/io/File;
    :cond_4
    :goto_2
    return-void
.end method
