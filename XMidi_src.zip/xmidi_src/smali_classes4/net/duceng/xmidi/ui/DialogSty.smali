.class public Lnet/duceng/xmidi/ui/DialogSty;
.super Lnet/duceng/xmidi/ui/XDialog;
.source "DialogSty.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;
    }
.end annotation


# instance fields
.field private af:Lnet/duceng/xmidi/util/AdapterExplorer;

.field private onSelectListener:Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;

    .line 29
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    .line 30
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/ui/DialogSty;)Lnet/duceng/xmidi/util/AdapterExplorer;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogSty;

    .line 20
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogSty;->af:Lnet/duceng/xmidi/util/AdapterExplorer;

    return-object v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/ui/DialogSty;)Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogSty;

    .line 20
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogSty;->onSelectListener:Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;

    return-object v0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 7
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 34
    invoke-super {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;->onCreate(Landroid/os/Bundle;)V

    .line 35
    const v0, 0x7f060023

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogSty;->setTitle(I)V

    .line 36
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogSty;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050015

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    .line 38
    .local v0, "lv":Landroid/widget/ListView;
    new-instance v2, Landroid/widget/Button;

    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogSty;->getContext()Landroid/content/Context;

    move-result-object v3

    const v4, 0x7f070003

    const/4 v5, 0x0

    invoke-direct {v2, v3, v1, v5, v4}, Landroid/widget/Button;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    .line 39
    .local v2, "imp":Landroid/widget/Button;
    const v3, 0x7f060012

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setText(I)V

    .line 40
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogSty;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v3, v3, Landroid/util/DisplayMetrics;->density:F

    const/high16 v4, 0x42380000    # 46.0f

    mul-float v3, v3, v4

    float-to-int v3, v3

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setMinimumHeight(I)V

    .line 41
    new-instance v3, Landroid/widget/AbsListView$LayoutParams;

    const/4 v4, -0x1

    const/4 v6, -0x2

    invoke-direct {v3, v4, v6}, Landroid/widget/AbsListView$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 42
    new-instance v3, Lnet/duceng/xmidi/ui/DialogSty$1;

    invoke-direct {v3, p0}, Lnet/duceng/xmidi/ui/DialogSty$1;-><init>(Lnet/duceng/xmidi/ui/DialogSty;)V

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 51
    invoke-virtual {v0, v2, v1, v5}, Landroid/widget/ListView;->addHeaderView(Landroid/view/View;Ljava/lang/Object;Z)V

    .line 52
    new-instance v1, Lnet/duceng/xmidi/util/AdapterExplorer;

    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogSty;->getContext()Landroid/content/Context;

    move-result-object v3

    new-instance v4, Ljava/io/File;

    sget-object v5, Lnet/duceng/xsynth/Synth;->PATH_STY:Ljava/lang/String;

    invoke-direct {v4, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {v1, v3, v4}, Lnet/duceng/xmidi/util/AdapterExplorer;-><init>(Landroid/content/Context;Ljava/io/File;)V

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogSty;->af:Lnet/duceng/xmidi/util/AdapterExplorer;

    .line 53
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogSty;->af:Lnet/duceng/xmidi/util/AdapterExplorer;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 54
    new-instance v1, Lnet/duceng/xmidi/ui/DialogSty$2;

    invoke-direct {v1, p0, v0}, Lnet/duceng/xmidi/ui/DialogSty$2;-><init>(Lnet/duceng/xmidi/ui/DialogSty;Landroid/widget/ListView;)V

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 72
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogSty;->setContentView(Landroid/view/View;)V

    .line 73
    return-void
.end method

.method protected onStart()V
    .locals 1

    .line 77
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogSty;->af:Lnet/duceng/xmidi/util/AdapterExplorer;

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/AdapterExplorer;->notifyDataSetChanged()V

    .line 78
    invoke-super {p0}, Lnet/duceng/xmidi/ui/XDialog;->onStart()V

    .line 79
    return-void
.end method

.method public setOnSelectListener(Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;

    .line 82
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogSty;->onSelectListener:Lnet/duceng/xmidi/ui/DialogSty$OnSelectListener;

    .line 83
    return-void
.end method
