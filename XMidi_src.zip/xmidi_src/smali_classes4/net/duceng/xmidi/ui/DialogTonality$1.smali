.class Lnet/duceng/xmidi/ui/DialogTonality$1;
.super Ljava/lang/Object;
.source "DialogTonality.java"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/DialogTonality;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/DialogTonality;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/DialogTonality;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/DialogTonality;

    .line 36
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogTonality$1;->this$0:Lnet/duceng/xmidi/ui/DialogTonality;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 1
    .param p2, "v"    # Landroid/view/View;
    .param p3, "pos"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .line 39
    .local p1, "arg0":Landroid/widget/AdapterView;, "Landroid/widget/AdapterView<*>;"
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogTonality$1;->this$0:Lnet/duceng/xmidi/ui/DialogTonality;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogTonality;->access$000(Lnet/duceng/xmidi/ui/DialogTonality;)Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;

    move-result-object v0

    if-nez v0, :cond_0

    .line 40
    return-void

    .line 42
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogTonality$1;->this$0:Lnet/duceng/xmidi/ui/DialogTonality;

    invoke-static {v0}, Lnet/duceng/xmidi/ui/DialogTonality;->access$000(Lnet/duceng/xmidi/ui/DialogTonality;)Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;

    move-result-object v0

    invoke-interface {v0, p3}, Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;->onSelect(I)Z

    .line 43
    return-void
.end method
