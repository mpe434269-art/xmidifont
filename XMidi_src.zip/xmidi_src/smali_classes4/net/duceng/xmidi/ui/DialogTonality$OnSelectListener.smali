.class public interface abstract Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;
.super Ljava/lang/Object;
.source "DialogTonality.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/ui/DialogTonality;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnSelectListener"
.end annotation


# virtual methods
.method public abstract onSelect(I)Z
.end method
