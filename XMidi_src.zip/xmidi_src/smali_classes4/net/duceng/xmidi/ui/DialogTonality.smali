.class public Lnet/duceng/xmidi/ui/DialogTonality;
.super Lnet/duceng/xmidi/ui/XDialog;
.source "DialogTonality.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;
    }
.end annotation


# instance fields
.field private gc:Lnet/duceng/xmidi/util/Chords;

.field private onSelectListener:Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xmidi/util/Chords;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "g"    # Lnet/duceng/xmidi/util/Chords;

    .line 24
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    .line 25
    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogTonality;->gc:Lnet/duceng/xmidi/util/Chords;

    .line 26
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/ui/DialogTonality;)Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/ui/DialogTonality;

    .line 15
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogTonality;->onSelectListener:Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;

    return-object v0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 30
    invoke-super {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;->onCreate(Landroid/os/Bundle;)V

    .line 31
    const v0, 0x7f06002f

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogTonality;->setTitle(I)V

    .line 32
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogTonality;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050012

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/GridView;

    .line 33
    .local v0, "gv":Landroid/widget/GridView;
    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/widget/GridView;->setNumColumns(I)V

    .line 34
    new-instance v1, Landroid/widget/ArrayAdapter;

    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogTonality;->getContext()Landroid/content/Context;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogTonality;->gc:Lnet/duceng/xmidi/util/Chords;

    invoke-virtual {v3}, Lnet/duceng/xmidi/util/Chords;->getTonalities()[Ljava/lang/String;

    move-result-object v3

    const v4, 0x7f050019

    invoke-direct {v1, v2, v4, v3}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    .line 35
    .local v1, "arrayAdapter":Landroid/widget/ArrayAdapter;, "Landroid/widget/ArrayAdapter<Ljava/lang/String;>;"
    invoke-virtual {v0, v1}, Landroid/widget/GridView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 36
    new-instance v2, Lnet/duceng/xmidi/ui/DialogTonality$1;

    invoke-direct {v2, p0}, Lnet/duceng/xmidi/ui/DialogTonality$1;-><init>(Lnet/duceng/xmidi/ui/DialogTonality;)V

    invoke-virtual {v0, v2}, Landroid/widget/GridView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 45
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogTonality;->setContentView(Landroid/view/View;)V

    .line 46
    return-void
.end method

.method public setOnSelectListener(Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;

    .line 49
    iput-object p1, p0, Lnet/duceng/xmidi/ui/DialogTonality;->onSelectListener:Lnet/duceng/xmidi/ui/DialogTonality$OnSelectListener;

    .line 50
    return-void
.end method
