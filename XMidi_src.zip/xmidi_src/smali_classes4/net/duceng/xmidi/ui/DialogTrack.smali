.class public Lnet/duceng/xmidi/ui/DialogTrack;
.super Lnet/duceng/xmidi/ui/XDialog;
.source "DialogTrack.java"


# instance fields
.field private at:Lnet/duceng/xmidi/util/AdapterTrack;

.field protected synth:Lnet/duceng/xsynth/Synth;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V
    .locals 0
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "s"    # Lnet/duceng/xsynth/Synth;

    .line 18
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;-><init>(Landroid/content/Context;)V

    .line 19
    iput-object p2, p0, Lnet/duceng/xmidi/ui/DialogTrack;->synth:Lnet/duceng/xsynth/Synth;

    .line 20
    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 24
    invoke-super {p0, p1}, Lnet/duceng/xmidi/ui/XDialog;->onCreate(Landroid/os/Bundle;)V

    .line 25
    const v0, 0x7f030041

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogTrack;->setIcon(I)V

    .line 26
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogTrack;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050015

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    .line 27
    .local v0, "lv":Landroid/widget/ListView;
    new-instance v1, Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/DialogTrack;->getContext()Landroid/content/Context;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/ui/DialogTrack;->synth:Lnet/duceng/xsynth/Synth;

    invoke-direct {v1, v2, v3}, Lnet/duceng/xmidi/util/AdapterTrack;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v1, p0, Lnet/duceng/xmidi/ui/DialogTrack;->at:Lnet/duceng/xmidi/util/AdapterTrack;

    .line 28
    iget-object v1, p0, Lnet/duceng/xmidi/ui/DialogTrack;->at:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 29
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogTrack;->setContentView(Landroid/view/View;)V

    .line 30
    return-void
.end method

.method protected onStart()V
    .locals 1

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogTrack;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getFile()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/DialogTrack;->setTitle(Ljava/lang/CharSequence;)V

    .line 35
    iget-object v0, p0, Lnet/duceng/xmidi/ui/DialogTrack;->at:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/AdapterTrack;->notifyDataSetChanged()V

    .line 36
    invoke-super {p0}, Lnet/duceng/xmidi/ui/XDialog;->onStart()V

    .line 37
    return-void
.end method
