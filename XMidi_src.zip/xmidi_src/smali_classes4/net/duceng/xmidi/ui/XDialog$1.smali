.class Lnet/duceng/xmidi/ui/XDialog$1;
.super Ljava/lang/Object;
.source "XDialog.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/ui/XDialog;->addButton(ILandroid/view/View$OnClickListener;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/ui/XDialog;

.field final synthetic val$listener:Landroid/view/View$OnClickListener;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/ui/XDialog;Landroid/view/View$OnClickListener;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/ui/XDialog;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 104
    iput-object p1, p0, Lnet/duceng/xmidi/ui/XDialog$1;->this$0:Lnet/duceng/xmidi/ui/XDialog;

    iput-object p2, p0, Lnet/duceng/xmidi/ui/XDialog$1;->val$listener:Landroid/view/View$OnClickListener;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 107
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog$1;->val$listener:Landroid/view/View$OnClickListener;

    if-eqz v0, :cond_0

    .line 108
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog$1;->val$listener:Landroid/view/View$OnClickListener;

    invoke-interface {v0, p1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    .line 110
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog$1;->this$0:Lnet/duceng/xmidi/ui/XDialog;

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/XDialog;->dismiss()V

    .line 111
    return-void
.end method
