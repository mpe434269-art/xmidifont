.class public Lnet/duceng/xmidi/ui/XDialog;
.super Landroid/app/Dialog;
.source "XDialog.java"


# instance fields
.field private bottom:Landroid/widget/LinearLayout;

.field private context:Landroid/content/Context;

.field private dialog:Landroid/view/View;

.field private icon:Landroid/widget/ImageView;

.field private title:Landroid/widget/Button;

.field private tools:Landroid/widget/LinearLayout;

.field private wapper:Landroid/widget/FrameLayout;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1, "c"    # Landroid/content/Context;

    .line 31
    const v0, 0x7f070008

    invoke-direct {p0, p1, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    .line 32
    iput-object p1, p0, Lnet/duceng/xmidi/ui/XDialog;->context:Landroid/content/Context;

    .line 33
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/XDialog;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f05000e

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->dialog:Landroid/view/View;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->dialog:Landroid/view/View;

    const v1, 0x7f04001a

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout;

    iput-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->wapper:Landroid/widget/FrameLayout;

    .line 35
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->dialog:Landroid/view/View;

    const v1, 0x7f040019

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->tools:Landroid/widget/LinearLayout;

    .line 36
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->dialog:Landroid/view/View;

    const v1, 0x7f040018

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->title:Landroid/widget/Button;

    .line 37
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->dialog:Landroid/view/View;

    const v1, 0x7f040017

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->icon:Landroid/widget/ImageView;

    .line 38
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->dialog:Landroid/view/View;

    const v1, 0x7f040016

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->bottom:Landroid/widget/LinearLayout;

    .line 39
    return-void
.end method


# virtual methods
.method public addAction(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 94
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->tools:Landroid/widget/LinearLayout;

    invoke-virtual {v0, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 95
    return-void
.end method

.method public addButton(ILandroid/view/View$OnClickListener;)V
    .locals 4
    .param p1, "id"    # I
    .param p2, "listener"    # Landroid/view/View$OnClickListener;

    .line 98
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->bottom:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_0

    .line 99
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/XDialog;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const v2, 0x7f05000f

    iget-object v3, p0, Lnet/duceng/xmidi/ui/XDialog;->bottom:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2, v3, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    .line 100
    .local v0, "d":Landroid/view/View;
    iget-object v2, p0, Lnet/duceng/xmidi/ui/XDialog;->bottom:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 102
    .end local v0    # "d":Landroid/view/View;
    :cond_0
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/XDialog;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const v2, 0x7f05000b

    iget-object v3, p0, Lnet/duceng/xmidi/ui/XDialog;->bottom:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2, v3, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    .line 103
    .local v0, "b":Landroid/widget/Button;
    invoke-virtual {v0, p1}, Landroid/widget/Button;->setText(I)V

    .line 104
    new-instance v1, Lnet/duceng/xmidi/ui/XDialog$1;

    invoke-direct {v1, p0, p2}, Lnet/duceng/xmidi/ui/XDialog$1;-><init>(Lnet/duceng/xmidi/ui/XDialog;Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 113
    iget-object v1, p0, Lnet/duceng/xmidi/ui/XDialog;->bottom:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 114
    return-void
.end method

.method public getWapper()Landroid/widget/FrameLayout;
    .locals 1

    .line 72
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->wapper:Landroid/widget/FrameLayout;

    return-object v0
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 43
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/ui/XDialog;->requestWindowFeature(I)Z

    .line 44
    invoke-super {p0, p1}, Landroid/app/Dialog;->onCreate(Landroid/os/Bundle;)V

    .line 45
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->dialog:Landroid/view/View;

    invoke-super {p0, v0}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 46
    return-void
.end method

.method protected onStart()V
    .locals 7

    .line 50
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/XDialog;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 51
    .local v0, "width":I
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/XDialog;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 52
    .local v1, "height":I
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/XDialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    int-to-double v3, v0

    if-le v0, v1, :cond_0

    const-wide v5, 0x3fe3333333333333L    # 0.6

    goto :goto_0

    :cond_0
    const-wide v5, 0x3feccccccccccccdL    # 0.9

    :goto_0
    mul-double v3, v3, v5

    double-to-int v3, v3

    const/4 v4, -0x2

    invoke-virtual {v2, v3, v4}, Landroid/view/Window;->setLayout(II)V

    .line 53
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/XDialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    invoke-static {v2}, Lnet/duceng/xmidi/util/Immersive;->apply(Landroid/view/Window;)V

    .line 54
    iget-object v2, p0, Lnet/duceng/xmidi/ui/XDialog;->bottom:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v2

    if-nez v2, :cond_1

    .line 55
    iget-object v2, p0, Lnet/duceng/xmidi/ui/XDialog;->bottom:Landroid/widget/LinearLayout;

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 57
    :cond_1
    invoke-super {p0}, Landroid/app/Dialog;->onStart()V

    .line 58
    return-void
.end method

.method public setContentView(I)V
    .locals 3
    .param p1, "id"    # I

    .line 62
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/XDialog;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/ui/XDialog;->wapper:Landroid/widget/FrameLayout;

    const/4 v2, 0x0

    invoke-virtual {v0, p1, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    .line 63
    .local v0, "child":Landroid/view/View;
    iget-object v1, p0, Lnet/duceng/xmidi/ui/XDialog;->wapper:Landroid/widget/FrameLayout;

    invoke-virtual {v1, v0}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 64
    return-void
.end method

.method public setContentView(Landroid/view/View;)V
    .locals 1
    .param p1, "view"    # Landroid/view/View;

    .line 68
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->wapper:Landroid/widget/FrameLayout;

    invoke-virtual {v0, p1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 69
    return-void
.end method

.method public setIcon(I)V
    .locals 1
    .param p1, "resId"    # I

    .line 90
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->icon:Landroid/widget/ImageView;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 91
    return-void
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 1
    .param p1, "d"    # Landroid/graphics/drawable/Drawable;

    .line 86
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->icon:Landroid/widget/ImageView;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 87
    return-void
.end method

.method public setItems(ILandroid/widget/AdapterView$OnItemClickListener;)V
    .locals 5
    .param p1, "id"    # I
    .param p2, "listener"    # Landroid/widget/AdapterView$OnItemClickListener;

    .line 117
    invoke-virtual {p0}, Lnet/duceng/xmidi/ui/XDialog;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050015

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ListView;

    .line 118
    .local v0, "lv":Landroid/widget/ListView;
    new-instance v1, Landroid/widget/ArrayAdapter;

    iget-object v2, p0, Lnet/duceng/xmidi/ui/XDialog;->context:Landroid/content/Context;

    iget-object v3, p0, Lnet/duceng/xmidi/ui/XDialog;->context:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v3

    const v4, 0x7f050018

    invoke-direct {v1, v2, v4, v3}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    .line 119
    .local v1, "arrayAdapter":Landroid/widget/ArrayAdapter;, "Landroid/widget/ArrayAdapter<Ljava/lang/String;>;"
    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 120
    invoke-virtual {v0, p2}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 121
    iget-object v2, p0, Lnet/duceng/xmidi/ui/XDialog;->wapper:Landroid/widget/FrameLayout;

    invoke-virtual {v2, v0}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 122
    return-void
.end method

.method public setTitle(I)V
    .locals 1
    .param p1, "titleId"    # I

    .line 82
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->title:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setText(I)V

    .line 83
    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 1
    .param p1, "t"    # Ljava/lang/CharSequence;

    .line 77
    iget-object v0, p0, Lnet/duceng/xmidi/ui/XDialog;->title:Landroid/widget/Button;

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 78
    return-void
.end method
