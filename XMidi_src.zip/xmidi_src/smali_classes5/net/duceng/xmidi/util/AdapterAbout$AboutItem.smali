.class Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;
.super Ljava/lang/Object;
.source "AdapterAbout.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/AdapterAbout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "AboutItem"
.end annotation


# instance fields
.field private desc:Ljava/lang/String;

.field private name:Ljava/lang/String;

.field final synthetic this$0:Lnet/duceng/xmidi/util/AdapterAbout;


# direct methods
.method private constructor <init>(Lnet/duceng/xmidi/util/AdapterAbout;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p2, "n"    # Ljava/lang/String;
    .param p3, "d"    # Ljava/lang/String;

    .line 60
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;->this$0:Lnet/duceng/xmidi/util/AdapterAbout;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 61
    iput-object p2, p0, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;->name:Ljava/lang/String;

    .line 62
    iput-object p3, p0, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;->desc:Ljava/lang/String;

    .line 63
    return-void
.end method

.method constructor <init>(Lnet/duceng/xmidi/util/AdapterAbout;Lnet/duceng/xmidi/util/AdapterAbout;Ljava/lang/String;Ljava/lang/String;Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;)V
    .locals 0
    .param p2, "adapterAbout"    # Lnet/duceng/xmidi/util/AdapterAbout;
    .param p3, "str"    # Ljava/lang/String;
    .param p4, "str2"    # Ljava/lang/String;
    .param p5, "aboutItem"    # Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;

    .line 66
    invoke-direct {p0, p1, p3, p4}, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;-><init>(Lnet/duceng/xmidi/util/AdapterAbout;Ljava/lang/String;Ljava/lang/String;)V

    .line 67
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;

    .line 56
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;->name:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;

    .line 56
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;->desc:Ljava/lang/String;

    return-object v0
.end method
