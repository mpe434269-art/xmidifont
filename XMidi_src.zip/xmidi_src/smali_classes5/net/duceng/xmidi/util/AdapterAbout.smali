.class public Lnet/duceng/xmidi/util/AdapterAbout;
.super Landroid/widget/BaseAdapter;
.source "AdapterAbout.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;
    }
.end annotation


# instance fields
.field private context:Landroid/content/Context;

.field private items:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 9
    .param p1, "c"    # Landroid/content/Context;

    .line 19
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 17
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterAbout;->items:Ljava/util/ArrayList;

    .line 20
    const/4 v0, 0x0

    .line 21
    .local v0, "aboutItem":Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterAbout;->context:Landroid/content/Context;

    .line 22
    iget-object v7, p0, Lnet/duceng/xmidi/util/AdapterAbout;->items:Ljava/util/ArrayList;

    new-instance v8, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterAbout;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f060002

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterAbout;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f060001

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    move-object v1, v8

    move-object v2, p0

    move-object v3, p0

    move-object v6, v0

    invoke-direct/range {v1 .. v6}, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;-><init>(Lnet/duceng/xmidi/util/AdapterAbout;Lnet/duceng/xmidi/util/AdapterAbout;Ljava/lang/String;Ljava/lang/String;Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;)V

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 23
    iget-object v7, p0, Lnet/duceng/xmidi/util/AdapterAbout;->items:Ljava/util/ArrayList;

    new-instance v8, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterAbout;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f060006

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterAbout;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f060007

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    move-object v1, v8

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;-><init>(Lnet/duceng/xmidi/util/AdapterAbout;Lnet/duceng/xmidi/util/AdapterAbout;Ljava/lang/String;Ljava/lang/String;Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;)V

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 24
    iget-object v7, p0, Lnet/duceng/xmidi/util/AdapterAbout;->items:Ljava/util/ArrayList;

    new-instance v8, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterAbout;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f060008

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterAbout;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f060009

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    move-object v1, v8

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;-><init>(Lnet/duceng/xmidi/util/AdapterAbout;Lnet/duceng/xmidi/util/AdapterAbout;Ljava/lang/String;Ljava/lang/String;Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;)V

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 25
    iget-object v7, p0, Lnet/duceng/xmidi/util/AdapterAbout;->items:Ljava/util/ArrayList;

    new-instance v8, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterAbout;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f06002c

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterAbout;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f06002d

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    move-object v1, v8

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;-><init>(Lnet/duceng/xmidi/util/AdapterAbout;Lnet/duceng/xmidi/util/AdapterAbout;Ljava/lang/String;Ljava/lang/String;Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;)V

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 26
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 30
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterAbout;->items:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public bridge synthetic getItem(I)Ljava/lang/Object;
    .locals 0

    .line 15
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/AdapterAbout;->getItem(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public getItem(I)Ljava/lang/String;
    .locals 1
    .param p1, "pos"    # I

    .line 35
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterAbout;->items:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;

    invoke-static {v0}, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;->access$000(Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "pos"    # I

    .line 40
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 4
    .param p1, "pos"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 45
    const v0, 0x1020015

    if-nez p2, :cond_0

    .line 46
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterAbout;->context:Landroid/content/Context;

    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const/4 v2, 0x0

    move-object v3, v2

    check-cast v3, Landroid/view/ViewGroup;

    const v3, 0x1090004

    invoke-virtual {v1, v3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p2

    .line 47
    invoke-virtual {p2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-static {}, Landroid/text/method/LinkMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    .line 49
    :cond_0
    const v1, 0x1020014

    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    .line 50
    .local v1, "name":Landroid/widget/TextView;
    invoke-virtual {p2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    .line 51
    .local v0, "desc":Landroid/widget/TextView;
    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterAbout;->items:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;

    invoke-static {v2}, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;->access$000(Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 52
    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterAbout;->items:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;

    invoke-static {v2}, Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;->access$100(Lnet/duceng/xmidi/util/AdapterAbout$AboutItem;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 53
    return-object p2
.end method
