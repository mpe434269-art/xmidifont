.class Lnet/duceng/xmidi/util/AdapterChannel$1;
.super Ljava/lang/Object;
.source "AdapterChannel.java"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/AdapterChannel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/util/AdapterChannel;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/AdapterChannel;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/AdapterChannel;

    .line 22
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterChannel$1;->this$0:Lnet/duceng/xmidi/util/AdapterChannel;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 3
    .param p1, "cb"    # Landroid/widget/CompoundButton;
    .param p2, "arg1"    # Z

    .line 25
    invoke-virtual {p1}, Landroid/widget/CompoundButton;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 26
    .local v0, "chan":I
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterChannel$1;->this$0:Lnet/duceng/xmidi/util/AdapterChannel;

    invoke-static {v1}, Lnet/duceng/xmidi/util/AdapterChannel;->access$000(Lnet/duceng/xmidi/util/AdapterChannel;)Lnet/duceng/xsynth/Synth;

    move-result-object v1

    xor-int/lit8 v2, p2, 0x1

    invoke-virtual {v1, v0, v2}, Lnet/duceng/xsynth/Synth;->setMute(IZ)V

    .line 27
    return-void
.end method
