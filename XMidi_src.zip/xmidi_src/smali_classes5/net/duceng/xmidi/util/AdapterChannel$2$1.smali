.class Lnet/duceng/xmidi/util/AdapterChannel$2$1;
.super Ljava/lang/Object;
.source "AdapterChannel.java"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/util/AdapterChannel$2;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/util/AdapterChannel$2;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/AdapterChannel$2;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/util/AdapterChannel$2;

    .line 36
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterChannel$2$1;->this$1:Lnet/duceng/xmidi/util/AdapterChannel$2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDismiss(Landroid/content/DialogInterface;)V
    .locals 1
    .param p1, "arg0"    # Landroid/content/DialogInterface;

    .line 39
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel$2$1;->this$1:Lnet/duceng/xmidi/util/AdapterChannel$2;

    iget-object v0, v0, Lnet/duceng/xmidi/util/AdapterChannel$2;->this$0:Lnet/duceng/xmidi/util/AdapterChannel;

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/AdapterChannel;->notifyDataSetChanged()V

    .line 40
    return-void
.end method
