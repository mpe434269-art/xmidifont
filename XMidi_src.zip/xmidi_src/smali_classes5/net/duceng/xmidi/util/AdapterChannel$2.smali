.class Lnet/duceng/xmidi/util/AdapterChannel$2;
.super Ljava/lang/Object;
.source "AdapterChannel.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/AdapterChannel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

.field final synthetic this$0:Lnet/duceng/xmidi/util/AdapterChannel;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/AdapterChannel;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/AdapterChannel;

    .line 29
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterChannel$2;->this$0:Lnet/duceng/xmidi/util/AdapterChannel;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 34
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel$2;->dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    if-nez v0, :cond_0

    .line 35
    new-instance v0, Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterChannel$2;->this$0:Lnet/duceng/xmidi/util/AdapterChannel;

    invoke-static {v1}, Lnet/duceng/xmidi/util/AdapterChannel;->access$100(Lnet/duceng/xmidi/util/AdapterChannel;)Landroid/content/Context;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterChannel$2;->this$0:Lnet/duceng/xmidi/util/AdapterChannel;

    invoke-static {v2}, Lnet/duceng/xmidi/util/AdapterChannel;->access$000(Lnet/duceng/xmidi/util/AdapterChannel;)Lnet/duceng/xsynth/Synth;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/ui/DialogPreset;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel$2;->dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    .line 36
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel$2;->dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    new-instance v1, Lnet/duceng/xmidi/util/AdapterChannel$2$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/util/AdapterChannel$2$1;-><init>(Lnet/duceng/xmidi/util/AdapterChannel$2;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogPreset;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 43
    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 44
    .local v0, "chan":I
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterChannel$2;->dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-virtual {v1, v0}, Lnet/duceng/xmidi/ui/DialogPreset;->setChannel(I)V

    .line 45
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterChannel$2;->dialogPreset:Lnet/duceng/xmidi/ui/DialogPreset;

    invoke-virtual {v1}, Lnet/duceng/xmidi/ui/DialogPreset;->show()V

    .line 46
    return-void
.end method
