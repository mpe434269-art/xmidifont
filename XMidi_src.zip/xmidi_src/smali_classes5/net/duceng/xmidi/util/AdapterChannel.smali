.class public Lnet/duceng/xmidi/util/AdapterChannel;
.super Landroid/widget/BaseAdapter;
.source "AdapterChannel.java"


# instance fields
.field private context:Landroid/content/Context;

.field private drums:[Ljava/lang/String;

.field private instruments:[Ljava/lang/String;

.field private onCheckedChangeListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

.field private onClickListener:Landroid/view/View$OnClickListener;

.field private synth:Lnet/duceng/xsynth/Synth;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V
    .locals 2
    .param p1, "c"    # Landroid/content/Context;
    .param p2, "s"    # Lnet/duceng/xsynth/Synth;

    .line 50
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 22
    new-instance v0, Lnet/duceng/xmidi/util/AdapterChannel$1;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/util/AdapterChannel$1;-><init>(Lnet/duceng/xmidi/util/AdapterChannel;)V

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->onCheckedChangeListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    .line 29
    new-instance v0, Lnet/duceng/xmidi/util/AdapterChannel$2;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/util/AdapterChannel$2;-><init>(Lnet/duceng/xmidi/util/AdapterChannel;)V

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->onClickListener:Landroid/view/View$OnClickListener;

    .line 51
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterChannel;->context:Landroid/content/Context;

    .line 52
    iput-object p2, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    .line 53
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010004

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->instruments:[Ljava/lang/String;

    .line 54
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010002

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->drums:[Ljava/lang/String;

    .line 55
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/util/AdapterChannel;)Lnet/duceng/xsynth/Synth;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterChannel;

    .line 18
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    return-object v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/util/AdapterChannel;)Landroid/content/Context;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterChannel;

    .line 18
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->context:Landroid/content/Context;

    return-object v0
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 59
    const/16 v0, 0x10

    return v0
.end method

.method public bridge synthetic getItem(I)Ljava/lang/Object;
    .locals 0

    .line 18
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/AdapterChannel;->getItem(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public getItem(I)Ljava/lang/String;
    .locals 2
    .param p1, "pos"    # I

    .line 64
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0, p1}, Lnet/duceng/xsynth/Synth;->getBank(I)I

    move-result v0

    sget v1, Lnet/duceng/xsynth/Synth;->DRUMS_BANK:I

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->drums:[Ljava/lang/String;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1, p1}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v1

    div-int/lit8 v1, v1, 0x8

    aget-object v0, v0, v1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->instruments:[Ljava/lang/String;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v1, p1}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v1

    aget-object v0, v0, v1

    :goto_0
    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "pos"    # I

    .line 69
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0, p1}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v0

    int-to-long v0, v0

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 5
    .param p1, "position"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 79
    const v0, 0x7f040015

    const v1, 0x7f040013

    if-nez p2, :cond_0

    .line 80
    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterChannel;->context:Landroid/content/Context;

    invoke-static {v2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v2

    const/4 v3, 0x0

    move-object v4, v3

    check-cast v4, Landroid/view/ViewGroup;

    const v4, 0x7f05001a

    invoke-virtual {v2, v4, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p2

    .line 81
    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/CheckBox;

    iget-object v3, p0, Lnet/duceng/xmidi/util/AdapterChannel;->onCheckedChangeListener:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    invoke-virtual {v2, v3}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 82
    invoke-virtual {p2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageButton;

    iget-object v3, p0, Lnet/duceng/xmidi/util/AdapterChannel;->onClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v2, v3}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 84
    :cond_0
    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    .line 85
    .local v1, "cb":Landroid/widget/CheckBox;
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setTag(Ljava/lang/Object;)V

    .line 86
    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v2, p1}, Lnet/duceng/xsynth/Synth;->isMute(I)Z

    move-result v2

    xor-int/lit8 v2, v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 87
    invoke-virtual {p2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setTag(Ljava/lang/Object;)V

    .line 88
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0, p1}, Lnet/duceng/xsynth/Synth;->getBank(I)I

    move-result v0

    sget v2, Lnet/duceng/xsynth/Synth;->DRUMS_BANK:I

    const-string v3, ": "

    const v4, 0x7f040014

    if-ne v0, v2, :cond_1

    .line 89
    invoke-virtual {p2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/util/AdapterChannel;->drums:[Ljava/lang/String;

    iget-object v4, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v4, p1}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v4

    div-int/lit8 v4, v4, 0x8

    aget-object v3, v3, v4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 91
    :cond_1
    invoke-virtual {p2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/util/AdapterChannel;->instruments:[Ljava/lang/String;

    iget-object v4, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v4, p1}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v4

    aget-object v3, v3, v4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 93
    :goto_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getRecordChan()I

    move-result v0

    if-ne p1, v0, :cond_2

    .line 94
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v2, 0x7f02000a

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p2, v0}, Landroid/view/View;->setBackgroundColor(I)V

    goto :goto_1

    .line 96
    :cond_2
    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Landroid/view/View;->setBackgroundColor(I)V

    .line 98
    :goto_1
    return-object p2
.end method

.method public isEnabled(I)Z
    .locals 1
    .param p1, "position"    # I

    .line 74
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterChannel;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0, p1}, Lnet/duceng/xsynth/Synth;->isMute(I)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method
