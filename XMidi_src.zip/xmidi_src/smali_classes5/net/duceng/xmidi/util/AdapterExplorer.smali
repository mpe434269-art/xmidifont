.class public Lnet/duceng/xmidi/util/AdapterExplorer;
.super Landroid/widget/BaseAdapter;
.source "AdapterExplorer.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/util/AdapterExplorer$CompratorFileByName;
    }
.end annotation


# instance fields
.field private context:Landroid/content/Context;

.field private currentPath:Ljava/io/File;

.field private df:Ljava/text/DateFormat;

.field private files:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/io/File;",
            ">;"
        }
    .end annotation
.end field

.field private isRoot:Z

.field private rootPath:Ljava/io/File;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/io/File;)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "rootPath"    # Ljava/io/File;

    .line 50
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 26
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->isRoot:Z

    .line 27
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    .line 28
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "yyyy-MM-dd HH:mm"

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->df:Ljava/text/DateFormat;

    .line 51
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->context:Landroid/content/Context;

    .line 52
    iput-object p2, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->rootPath:Ljava/io/File;

    .line 53
    iput-object p2, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->currentPath:Ljava/io/File;

    .line 54
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->currentPath:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    .line 55
    .local v0, "fs":[Ljava/io/File;
    if-eqz v0, :cond_0

    .line 56
    new-instance v1, Lnet/duceng/xmidi/util/AdapterExplorer$CompratorFileByName;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Lnet/duceng/xmidi/util/AdapterExplorer$CompratorFileByName;-><init>(Lnet/duceng/xmidi/util/AdapterExplorer$CompratorFileByName;)V

    invoke-static {v0, v1}, Ljava/util/Arrays;->sort([Ljava/lang/Object;Ljava/util/Comparator;)V

    .line 57
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 59
    :cond_0
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 80
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/io/File;
    .locals 1
    .param p1, "position"    # I

    .line 85
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/io/File;

    return-object v0
.end method

.method public bridge synthetic getItem(I)Ljava/lang/Object;
    .locals 0

    .line 22
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/AdapterExplorer;->getItem(I)Ljava/io/File;

    move-result-object p1

    return-object p1
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 90
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 9
    .param p1, "position"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 95
    if-nez p2, :cond_0

    .line 96
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->context:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f05001b

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p2

    .line 98
    :cond_0
    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    .line 99
    .local v0, "detail":Ljava/lang/StringBuffer;
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->isDirectory()Z

    move-result v1

    const v2, 0x7f040093

    const v3, 0x7f040094

    if-eqz v1, :cond_2

    .line 100
    if-nez p1, :cond_1

    iget-boolean v1, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->isRoot:Z

    if-nez v1, :cond_1

    .line 101
    invoke-virtual {p2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    const-string v3, ".."

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 103
    :cond_1
    invoke-virtual {p2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v3, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/io/File;

    invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 105
    :goto_0
    invoke-virtual {p2, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    const v2, 0x7f030016

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_1

    .line 107
    :cond_2
    invoke-virtual {p2, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    const v2, 0x7f030015

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 108
    invoke-virtual {p2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/io/File;

    invoke-virtual {v2}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 109
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->length()J

    move-result-wide v1

    .line 110
    .local v1, "fileS":J
    new-instance v3, Ljava/text/DecimalFormat;

    const-string v4, "#"

    invoke-direct {v3, v4}, Ljava/text/DecimalFormat;-><init>(Ljava/lang/String;)V

    .line 111
    .local v3, "df":Ljava/text/DecimalFormat;
    const-wide/16 v4, 0x400

    cmp-long v6, v1, v4

    if-gez v6, :cond_3

    .line 112
    const-string v4, "1KB "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto :goto_1

    .line 114
    :cond_3
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    long-to-double v5, v1

    const-wide/high16 v7, 0x4090000000000000L    # 1024.0

    div-double/2addr v5, v7

    invoke-virtual {v3, v5, v6}, Ljava/text/DecimalFormat;->format(D)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "KB "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 117
    .end local v1    # "fileS":J
    .end local v3    # "df":Ljava/text/DecimalFormat;
    :goto_1
    new-instance v1, Ljava/util/Date;

    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/io/File;

    invoke-virtual {v2}, Ljava/io/File;->lastModified()J

    move-result-wide v2

    invoke-direct {v1, v2, v3}, Ljava/util/Date;-><init>(J)V

    .line 118
    .local v1, "d":Ljava/util/Date;
    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->df:Ljava/text/DateFormat;

    invoke-virtual {v2, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 119
    const v2, 0x7f040092

    invoke-virtual {p2, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 120
    return-object p2
.end method

.method public notifyDataSetChanged()V
    .locals 1

    .line 125
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->currentPath:Ljava/io/File;

    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/util/AdapterExplorer;->setCurrentPath(Ljava/io/File;)V

    .line 126
    return-void
.end method

.method public setCurrentPath(Ljava/io/File;)V
    .locals 3
    .param p1, "f"    # Ljava/io/File;

    .line 62
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->currentPath:Ljava/io/File;

    .line 63
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 64
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->rootPath:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->currentPath:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 65
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->currentPath:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 66
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->isRoot:Z

    goto :goto_0

    .line 68
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->isRoot:Z

    .line 70
    :goto_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->currentPath:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    .line 71
    .local v0, "fs":[Ljava/io/File;
    if-eqz v0, :cond_1

    .line 72
    new-instance v1, Lnet/duceng/xmidi/util/AdapterExplorer$CompratorFileByName;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Lnet/duceng/xmidi/util/AdapterExplorer$CompratorFileByName;-><init>(Lnet/duceng/xmidi/util/AdapterExplorer$CompratorFileByName;)V

    invoke-static {v0, v1}, Ljava/util/Arrays;->sort([Ljava/lang/Object;Ljava/util/Comparator;)V

    .line 73
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterExplorer;->files:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 75
    :cond_1
    invoke-super {p0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    .line 76
    return-void
.end method
