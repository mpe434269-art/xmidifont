.class public Lnet/duceng/xmidi/util/AdapterProgram;
.super Landroid/widget/BaseExpandableListAdapter;
.source "AdapterProgram.java"


# instance fields
.field private context:Landroid/content/Context;

.field private groups:[Ljava/lang/String;

.field private presets:[[Ljava/lang/String;

.field private selected:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 7
    .param p1, "context"    # Landroid/content/Context;

    .line 19
    invoke-direct {p0}, Landroid/widget/BaseExpandableListAdapter;-><init>()V

    .line 16
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/util/AdapterProgram;->selected:I

    .line 17
    const-class v0, Ljava/lang/String;

    const/16 v1, 0x10

    const/16 v2, 0x8

    filled-new-array {v1, v2}, [I

    move-result-object v3

    invoke-static {v0, v3}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Ljava/lang/String;

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterProgram;->presets:[[Ljava/lang/String;

    .line 20
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterProgram;->context:Landroid/content/Context;

    .line 21
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v3, 0x7f010003

    invoke-virtual {v0, v3}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterProgram;->groups:[Ljava/lang/String;

    .line 22
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v3, 0x7f010004

    invoke-virtual {v0, v3}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    .line 23
    .local v0, "instruments":[Ljava/lang/String;
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    if-ge v3, v1, :cond_1

    .line 24
    const/4 v4, 0x0

    .local v4, "j":I
    :goto_1
    if-ge v4, v2, :cond_0

    .line 25
    iget-object v5, p0, Lnet/duceng/xmidi/util/AdapterProgram;->presets:[[Ljava/lang/String;

    aget-object v5, v5, v3

    mul-int/lit8 v6, v3, 0x8

    add-int/2addr v6, v4

    aget-object v6, v0, v6

    aput-object v6, v5, v4

    .line 24
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    .line 23
    .end local v4    # "j":I
    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 28
    .end local v3    # "i":I
    :cond_1
    return-void
.end method


# virtual methods
.method public bridge synthetic getChild(II)Ljava/lang/Object;
    .locals 0

    .line 13
    invoke-virtual {p0, p1, p2}, Lnet/duceng/xmidi/util/AdapterProgram;->getChild(II)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public getChild(II)Ljava/lang/String;
    .locals 1
    .param p1, "gpos"    # I
    .param p2, "cpos"    # I

    .line 61
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterProgram;->presets:[[Ljava/lang/String;

    aget-object v0, v0, p1

    aget-object v0, v0, p2

    return-object v0
.end method

.method public getChildId(II)J
    .locals 2
    .param p1, "gpos"    # I
    .param p2, "cpos"    # I

    .line 66
    mul-int/lit8 v0, p1, 0x8

    add-int/2addr v0, p2

    int-to-long v0, v0

    return-wide v0
.end method

.method public getChildView(IIZLandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 3
    .param p1, "gpos"    # I
    .param p2, "cpos"    # I
    .param p3, "isLastChild"    # Z
    .param p4, "convertView"    # Landroid/view/View;
    .param p5, "parent"    # Landroid/view/ViewGroup;

    .line 46
    if-nez p4, :cond_0

    .line 47
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterProgram;->context:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    .line 48
    .local v0, "inflater":Landroid/view/LayoutInflater;
    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050017

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p4

    .line 50
    .end local v0    # "inflater":Landroid/view/LayoutInflater;
    :cond_0
    move-object v0, p4

    check-cast v0, Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, p1, p2}, Lnet/duceng/xmidi/util/AdapterProgram;->getChild(II)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " ("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    mul-int/lit8 v2, p1, 0x8

    add-int/2addr v2, p2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 51
    mul-int/lit8 v0, p1, 0x8

    add-int/2addr v0, p2

    iget v1, p0, Lnet/duceng/xmidi/util/AdapterProgram;->selected:I

    if-ne v0, v1, :cond_1

    .line 52
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterProgram;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f02000a

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p4, v0}, Landroid/view/View;->setBackgroundColor(I)V

    goto :goto_0

    .line 54
    :cond_1
    const/4 v0, 0x0

    invoke-virtual {p4, v0}, Landroid/view/View;->setBackgroundColor(I)V

    .line 56
    :goto_0
    return-object p4
.end method

.method public getChildrenCount(I)I
    .locals 1
    .param p1, "gpos"    # I

    .line 71
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterProgram;->presets:[[Ljava/lang/String;

    aget-object v0, v0, p1

    array-length v0, v0

    return v0
.end method

.method public bridge synthetic getGroup(I)Ljava/lang/Object;
    .locals 0

    .line 13
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/AdapterProgram;->getGroup(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public getGroup(I)Ljava/lang/String;
    .locals 1
    .param p1, "gpos"    # I

    .line 76
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterProgram;->groups:[Ljava/lang/String;

    aget-object v0, v0, p1

    return-object v0
.end method

.method public getGroupCount()I
    .locals 1

    .line 86
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterProgram;->groups:[Ljava/lang/String;

    array-length v0, v0

    return v0
.end method

.method public getGroupId(I)J
    .locals 2
    .param p1, "gpos"    # I

    .line 81
    int-to-long v0, p1

    return-wide v0
.end method

.method public getGroupView(IZLandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 3
    .param p1, "groupPosition"    # I
    .param p2, "isExpanded"    # Z
    .param p3, "convertView"    # Landroid/view/View;
    .param p4, "parent"    # Landroid/view/ViewGroup;

    .line 36
    if-nez p3, :cond_0

    .line 37
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterProgram;->context:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    .line 38
    .local v0, "inflater":Landroid/view/LayoutInflater;
    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050017

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p3

    .line 40
    .end local v0    # "inflater":Landroid/view/LayoutInflater;
    :cond_0
    move-object v0, p3

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/AdapterProgram;->getGroup(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 41
    return-object p3
.end method

.method public hasStableIds()Z
    .locals 1

    .line 91
    const/4 v0, 0x1

    return v0
.end method

.method public isChildSelectable(II)Z
    .locals 1
    .param p1, "groupPosition"    # I
    .param p2, "childPosition"    # I

    .line 96
    const/4 v0, 0x1

    return v0
.end method

.method public setSelected(I)V
    .locals 0
    .param p1, "pos"    # I

    .line 31
    iput p1, p0, Lnet/duceng/xmidi/util/AdapterProgram;->selected:I

    .line 32
    return-void
.end method
