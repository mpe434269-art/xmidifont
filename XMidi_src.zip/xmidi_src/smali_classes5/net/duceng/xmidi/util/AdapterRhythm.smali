.class public Lnet/duceng/xmidi/util/AdapterRhythm;
.super Landroid/widget/BaseAdapter;
.source "AdapterRhythm.java"


# instance fields
.field private beat:I

.field private context:Landroid/content/Context;

.field private items:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/util/Rhythm;",
            ">;"
        }
    .end annotation
.end field

.field private rhythms:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/util/Rhythm;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 11
    .param p1, "c"    # Landroid/content/Context;

    .line 25
    const-string v0, "chord"

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 18
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->items:Ljava/util/ArrayList;

    .line 19
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    .line 20
    const/4 v1, 0x4

    iput v1, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->beat:I

    .line 27
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->context:Landroid/content/Context;

    .line 28
    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->context:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const/high16 v3, 0x7f080000

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object v2

    .line 30
    .local v2, "parser":Landroid/content/res/XmlResourceParser;
    :try_start_0
    invoke-interface {v2}, Landroid/content/res/XmlResourceParser;->getEventType()I

    move-result v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 31
    .local v3, "event":I
    const/4 v4, 0x0

    .line 32
    .local v4, "rhythm2":Lnet/duceng/xmidi/util/Rhythm;
    :goto_0
    const/4 v5, 0x1

    if-eq v3, v5, :cond_5

    .line 33
    const-string v6, "rhythm"

    packed-switch v3, :pswitch_data_0

    .line 41
    :pswitch_0
    move-object v5, v4

    .line 42
    .local v5, "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    :try_start_1
    invoke-interface {v2}, Landroid/content/res/XmlResourceParser;->next()I

    move-result v6

    goto/16 :goto_4

    .line 77
    .end local v5    # "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    :pswitch_1
    invoke-interface {v2}, Landroid/content/res/XmlResourceParser;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    .line 78
    iget-object v5, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    iget-byte v6, v4, Lnet/duceng/xmidi/util/Rhythm;->beat:B

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_0

    .line 79
    iget-object v5, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    iget-byte v6, v4, Lnet/duceng/xmidi/util/Rhythm;->beat:B

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v5, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    :cond_0
    iget-object v5, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    iget-byte v6, v4, Lnet/duceng/xmidi/util/Rhythm;->beat:B

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 82
    const/4 v5, 0x0

    .restart local v5    # "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    goto :goto_1

    .line 84
    .end local v5    # "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    :cond_1
    move-object v5, v4

    .line 86
    .restart local v5    # "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    :goto_1
    invoke-interface {v2}, Landroid/content/res/XmlResourceParser;->next()I

    move-result v6
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    move v3, v6

    .line 87
    move-object v4, v5

    goto/16 :goto_5

    .line 47
    .end local v5    # "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    :pswitch_2
    :try_start_2
    invoke-interface {v2}, Landroid/content/res/XmlResourceParser;->getName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-eqz v6, :cond_2

    .line 48
    new-instance v6, Lnet/duceng/xmidi/util/Rhythm;

    invoke-direct {v6}, Lnet/duceng/xmidi/util/Rhythm;-><init>()V

    .line 49
    .local v6, "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    const-string v9, "id"

    invoke-interface {v2, v8, v9, v7}, Landroid/content/res/XmlResourceParser;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v9

    iput v9, v6, Lnet/duceng/xmidi/util/Rhythm;->id:I

    .line 50
    const-string v9, "beat"

    invoke-interface {v2, v8, v9, v1}, Landroid/content/res/XmlResourceParser;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v9

    int-to-byte v9, v9

    iput-byte v9, v6, Lnet/duceng/xmidi/util/Rhythm;->beat:B

    .line 51
    const-string v9, "durs"

    invoke-interface {v2, v8, v9, v1}, Landroid/content/res/XmlResourceParser;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v9

    int-to-byte v9, v9

    iput-byte v9, v6, Lnet/duceng/xmidi/util/Rhythm;->durs:B

    goto :goto_2

    .line 53
    .end local v6    # "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    :cond_2
    move-object v6, v4

    .line 55
    .restart local v6    # "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    :goto_2
    if-eqz v6, :cond_4

    invoke-interface {v2}, Landroid/content/res/XmlResourceParser;->getName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_4

    .line 56
    invoke-virtual {v6}, Lnet/duceng/xmidi/util/Rhythm;->addChord()Lnet/duceng/xmidi/util/Rhythm$RChord;

    move-result-object v9

    .line 57
    .local v9, "chord":Lnet/duceng/xmidi/util/Rhythm$RChord;
    const-string v10, "dur"

    invoke-interface {v2, v8, v10, v5}, Landroid/content/res/XmlResourceParser;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v10

    int-to-byte v10, v10

    iput-byte v10, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    .line 58
    const-string v10, "mod"

    invoke-interface {v2, v8, v10, v7}, Landroid/content/res/XmlResourceParser;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v10

    int-to-byte v10, v10

    iput-byte v10, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    .line 59
    const-string v10, "keep"

    invoke-interface {v2, v8, v10, v7}, Landroid/content/res/XmlResourceParser;->getAttributeBooleanValue(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v10

    iput-boolean v10, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->keep:Z

    .line 60
    invoke-interface {v2, v8, v0, v7}, Landroid/content/res/XmlResourceParser;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v7

    .line 61
    .local v7, "val":I
    invoke-static {v7}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    new-array v8, v8, [B

    .line 62
    .local v8, "vals":[B
    array-length v10, v8

    sub-int/2addr v10, v5

    .local v10, "i":I
    :goto_3
    if-ltz v10, :cond_3

    .line 63
    rem-int/lit8 v5, v7, 0xa

    int-to-byte v5, v5

    aput-byte v5, v8, v10

    .line 64
    div-int/lit8 v5, v7, 0xa

    move v7, v5

    .line 62
    add-int/lit8 v10, v10, -0x1

    goto :goto_3

    .line 66
    .end local v10    # "i":I
    :cond_3
    iput-object v8, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    .line 68
    .end local v7    # "val":I
    .end local v8    # "vals":[B
    .end local v9    # "chord":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_4
    invoke-interface {v2}, Landroid/content/res/XmlResourceParser;->next()I

    move-result v5
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    move v3, v5

    .line 69
    move-object v4, v6

    .line 74
    goto :goto_5

    .line 70
    .end local v6    # "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    :catch_0
    move-exception v5

    .line 71
    .local v5, "e":Ljava/lang/Exception;
    :try_start_3
    invoke-virtual {v5}, Ljava/lang/Exception;->printStackTrace()V

    .line 72
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 73
    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/util/AdapterRhythm;->setBeat(I)V

    .line 75
    .end local v5    # "e":Ljava/lang/Exception;
    goto :goto_5

    .line 35
    :pswitch_3
    move-object v5, v4

    .line 36
    .local v5, "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    invoke-interface {v2}, Landroid/content/res/XmlResourceParser;->next()I

    move-result v6

    move v3, v6

    .line 37
    move-object v4, v5

    .line 38
    goto :goto_5

    .line 42
    :goto_4
    move v3, v6

    .line 43
    move-object v4, v5

    .line 44
    nop

    .line 90
    .end local v5    # "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    :goto_5
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 91
    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/util/AdapterRhythm;->setBeat(I)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    goto/16 :goto_0

    .line 95
    .end local v3    # "event":I
    .end local v4    # "rhythm2":Lnet/duceng/xmidi/util/Rhythm;
    :cond_5
    goto :goto_6

    .line 93
    :catch_1
    move-exception v0

    .line 94
    .local v0, "e2":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 96
    .end local v0    # "e2":Ljava/lang/Exception;
    :goto_6
    invoke-static {}, Ljava/lang/System;->gc()V

    .line 97
    invoke-virtual {p0, v1}, Lnet/duceng/xmidi/util/AdapterRhythm;->setBeat(I)V

    .line 98
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method


# virtual methods
.method public getBeat()I
    .locals 1

    .line 101
    iget v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->beat:I

    return v0
.end method

.method public getCount()I
    .locals 1

    .line 140
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->items:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public bridge synthetic getItem(I)Ljava/lang/Object;
    .locals 0

    .line 16
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/AdapterRhythm;->getItem(I)Lnet/duceng/xmidi/util/Rhythm;

    move-result-object p1

    return-object p1
.end method

.method public getItem(I)Lnet/duceng/xmidi/util/Rhythm;
    .locals 1
    .param p1, "position"    # I

    .line 145
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->items:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/Rhythm;

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 150
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->items:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/Rhythm;

    iget v0, v0, Lnet/duceng/xmidi/util/Rhythm;->id:I

    int-to-long v0, v0

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 3
    .param p1, "position"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 155
    if-nez p2, :cond_0

    .line 156
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->context:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f05001d

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p2

    .line 157
    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Landroid/view/View;->setFocusable(Z)V

    .line 159
    :cond_0
    move-object v0, p2

    check-cast v0, Lnet/duceng/xmidi/widgets/GRhythm;

    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/AdapterRhythm;->getItem(I)Lnet/duceng/xmidi/util/Rhythm;

    move-result-object v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/GRhythm;->setRhythm(Lnet/duceng/xmidi/util/Rhythm;)V

    .line 160
    return-object p2
.end method

.method public setBeat(I)V
    .locals 3
    .param p1, "b"    # I

    .line 105
    iput p1, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->beat:I

    .line 106
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->items:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 107
    iget v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->beat:I

    const/4 v1, 0x3

    .line 114
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    .line 107
    const/4 v2, 0x2

    .line 109
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    .line 107
    packed-switch v0, :pswitch_data_0

    :pswitch_0
    goto/16 :goto_0

    .line 127
    :pswitch_1
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 128
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->items:Ljava/util/ArrayList;

    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 130
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    const/4 v1, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 131
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->items:Ljava/util/ArrayList;

    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    .line 119
    :pswitch_2
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 120
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->items:Ljava/util/ArrayList;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 122
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    const/4 v1, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 123
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->items:Ljava/util/ArrayList;

    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    .line 114
    :pswitch_3
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 115
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->items:Ljava/util/ArrayList;

    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    .line 109
    :pswitch_4
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 110
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->items:Ljava/util/ArrayList;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterRhythm;->rhythms:Ljava/util/Map;

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 135
    :cond_2
    :goto_0
    invoke-virtual {p0}, Lnet/duceng/xmidi/util/AdapterRhythm;->notifyDataSetChanged()V

    .line 136
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method
