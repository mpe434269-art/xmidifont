.class public Lnet/duceng/xmidi/util/AdapterSFont;
.super Landroid/widget/BaseAdapter;
.source "AdapterSFont.java"


# instance fields
.field private context:Landroid/content/Context;

.field private selected:I

.field private sfonts:Lnet/duceng/xmidi/util/MyArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lnet/duceng/xmidi/util/MyArray<",
            "Ljava/io/File;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xmidi/util/MyArray;)V
    .locals 1
    .param p1, "c"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lnet/duceng/xmidi/util/MyArray<",
            "Ljava/io/File;",
            ">;)V"
        }
    .end annotation

    .line 18
    .local p2, "s":Lnet/duceng/xmidi/util/MyArray;, "Lnet/duceng/xmidi/util/MyArray<Ljava/io/File;>;"
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 15
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/util/AdapterSFont;->selected:I

    .line 19
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterSFont;->context:Landroid/content/Context;

    .line 20
    iput-object p2, p0, Lnet/duceng/xmidi/util/AdapterSFont;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    .line 21
    return-void
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 25
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterSFont;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v0}, Lnet/duceng/xmidi/util/MyArray;->size()I

    move-result v0

    return v0
.end method

.method public getItem(I)Ljava/io/File;
    .locals 1
    .param p1, "position"    # I

    .line 30
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterSFont;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/util/MyArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/io/File;

    return-object v0
.end method

.method public bridge synthetic getItem(I)Ljava/lang/Object;
    .locals 0

    .line 13
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/AdapterSFont;->getItem(I)Ljava/io/File;

    move-result-object p1

    return-object p1
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "position"    # I

    .line 35
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterSFont;->sfonts:Lnet/duceng/xmidi/util/MyArray;

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/util/MyArray;->keyAt(I)I

    move-result v0

    int-to-long v0, v0

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 3
    .param p1, "position"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 45
    if-nez p2, :cond_0

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterSFont;->context:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/view/ViewGroup;

    const v2, 0x7f050018

    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p2

    .line 48
    :cond_0
    move-object v0, p2

    check-cast v0, Landroid/widget/TextView;

    .line 49
    .local v0, "tv":Landroid/widget/TextView;
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/AdapterSFont;->getItem(I)Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 50
    iget v1, p0, Lnet/duceng/xmidi/util/AdapterSFont;->selected:I

    if-ne p1, v1, :cond_1

    .line 51
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterSFont;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f02000a

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v1

    invoke-virtual {p2, v1}, Landroid/view/View;->setBackgroundColor(I)V

    goto :goto_0

    .line 53
    :cond_1
    const/4 v1, 0x0

    invoke-virtual {p2, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 55
    :goto_0
    return-object p2
.end method

.method public isEnabled(I)Z
    .locals 1
    .param p1, "position"    # I

    .line 40
    const/4 v0, 0x1

    return v0
.end method

.method public setSelected(I)V
    .locals 0
    .param p1, "pos"    # I

    .line 59
    iput p1, p0, Lnet/duceng/xmidi/util/AdapterSFont;->selected:I

    .line 60
    return-void
.end method
