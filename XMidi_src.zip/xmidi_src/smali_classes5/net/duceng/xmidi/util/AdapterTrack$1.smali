.class Lnet/duceng/xmidi/util/AdapterTrack$1;
.super Ljava/lang/Object;
.source "AdapterTrack.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/AdapterTrack;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/util/AdapterTrack;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/AdapterTrack;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/AdapterTrack;

    .line 30
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterTrack$1;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 33
    move-object v0, p1

    check-cast v0, Landroid/widget/CheckBox;

    .line 34
    .local v0, "cb":Landroid/widget/CheckBox;
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterTrack$1;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-virtual {v0}, Landroid/widget/CheckBox;->getTag()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/util/AdapterTrack;->getItemId(I)J

    move-result-wide v1

    long-to-int v2, v1

    .line 35
    .local v2, "t":I
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterTrack$1;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v1}, Lnet/duceng/xmidi/util/AdapterTrack;->access$000(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xsynth/Synth;

    move-result-object v1

    invoke-virtual {v0}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v3

    invoke-virtual {v1, v2, v3}, Lnet/duceng/xsynth/Synth;->setScore(IZ)V

    .line 36
    return-void
.end method
