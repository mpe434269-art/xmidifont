.class Lnet/duceng/xmidi/util/AdapterTrack$2$1;
.super Ljava/lang/Object;
.source "AdapterTrack.java"

# interfaces
.implements Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/util/AdapterTrack$2;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/util/AdapterTrack$2;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/AdapterTrack$2;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/util/AdapterTrack$2;

    .line 45
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterTrack$2$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSelect(IILjava/lang/String;)V
    .locals 2
    .param p1, "chan"    # I
    .param p2, "preset"    # I
    .param p3, "instrument"    # Ljava/lang/String;

    .line 48
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$2$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$2;

    iget-object v0, v0, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterTrack$2$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$2;

    iget-object v1, v1, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v1}, Lnet/duceng/xmidi/util/AdapterTrack;->access$100(Lnet/duceng/xmidi/util/AdapterTrack;)Landroid/widget/Button;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/util/AdapterTrack;->getItem(I)Lnet/duceng/midi/MidiTrack;

    move-result-object v0

    .line 49
    .local v0, "midiTrack":Lnet/duceng/midi/MidiTrack;
    int-to-byte v1, p1

    invoke-virtual {v0, v1}, Lnet/duceng/midi/MidiTrack;->setChannel(B)V

    .line 50
    int-to-byte v1, p2

    invoke-virtual {v0, v1}, Lnet/duceng/midi/MidiTrack;->setProgram(B)V

    .line 51
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterTrack$2$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$2;

    iget-object v1, v1, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-virtual {v1}, Lnet/duceng/xmidi/util/AdapterTrack;->notifyDataSetChanged()V

    .line 52
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterTrack$2$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$2;

    iget-object v1, v1, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v1}, Lnet/duceng/xmidi/util/AdapterTrack;->access$200(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xmidi/ui/DialogChannel;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/xmidi/ui/DialogChannel;->dismiss()V

    .line 53
    return-void
.end method
