.class Lnet/duceng/xmidi/util/AdapterTrack$2;
.super Ljava/lang/Object;
.source "AdapterTrack.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/AdapterTrack;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/util/AdapterTrack;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/AdapterTrack;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/AdapterTrack;

    .line 38
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 42
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    move-object v1, p1

    check-cast v1, Landroid/widget/Button;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/util/AdapterTrack;->access$102(Lnet/duceng/xmidi/util/AdapterTrack;Landroid/widget/Button;)Landroid/widget/Button;

    .line 43
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v0}, Lnet/duceng/xmidi/util/AdapterTrack;->access$200(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xmidi/ui/DialogChannel;

    move-result-object v0

    if-nez v0, :cond_0

    .line 44
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    new-instance v1, Lnet/duceng/xmidi/ui/DialogChannel;

    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v2}, Lnet/duceng/xmidi/util/AdapterTrack;->access$300(Lnet/duceng/xmidi/util/AdapterTrack;)Landroid/content/Context;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v3}, Lnet/duceng/xmidi/util/AdapterTrack;->access$000(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xsynth/Synth;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Lnet/duceng/xmidi/ui/DialogChannel;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    invoke-static {v0, v1}, Lnet/duceng/xmidi/util/AdapterTrack;->access$202(Lnet/duceng/xmidi/util/AdapterTrack;Lnet/duceng/xmidi/ui/DialogChannel;)Lnet/duceng/xmidi/ui/DialogChannel;

    .line 45
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v0}, Lnet/duceng/xmidi/util/AdapterTrack;->access$200(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xmidi/ui/DialogChannel;

    move-result-object v0

    new-instance v1, Lnet/duceng/xmidi/util/AdapterTrack$2$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/util/AdapterTrack$2$1;-><init>(Lnet/duceng/xmidi/util/AdapterTrack$2;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogChannel;->setOnSelectListener(Lnet/duceng/xmidi/ui/DialogChannel$OnSelectListener;)V

    .line 56
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$2;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v0}, Lnet/duceng/xmidi/util/AdapterTrack;->access$200(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xmidi/ui/DialogChannel;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogChannel;->show()V

    .line 57
    return-void
.end method
