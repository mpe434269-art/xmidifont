.class Lnet/duceng/xmidi/util/AdapterTrack$3$1;
.super Ljava/lang/Object;
.source "AdapterTrack.java"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/util/AdapterTrack$3;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lnet/duceng/xmidi/util/AdapterTrack$3;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/AdapterTrack$3;)V
    .locals 0
    .param p1, "this$1"    # Lnet/duceng/xmidi/util/AdapterTrack$3;

    .line 66
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterTrack$3$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDismiss(Landroid/content/DialogInterface;)V
    .locals 6
    .param p1, "d"    # Landroid/content/DialogInterface;

    .line 69
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$3$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$3;

    iget-object v0, v0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterTrack$3$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$3;

    iget-object v1, v1, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v1}, Lnet/duceng/xmidi/util/AdapterTrack;->access$400(Lnet/duceng/xmidi/util/AdapterTrack;)Landroid/widget/Button;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/util/AdapterTrack;->getItem(I)Lnet/duceng/midi/MidiTrack;

    move-result-object v0

    .line 70
    .local v0, "midiTrack":Lnet/duceng/midi/MidiTrack;
    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterTrack$3$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$3;

    iget-object v1, v1, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v1}, Lnet/duceng/xmidi/util/AdapterTrack;->access$000(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xsynth/Synth;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterTrack$3$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$3;

    iget-object v2, v2, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v2}, Lnet/duceng/xmidi/util/AdapterTrack;->access$500(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xmidi/ui/DialogPreset;

    move-result-object v2

    invoke-virtual {v2}, Lnet/duceng/xmidi/ui/DialogPreset;->getChannel()I

    move-result v2

    invoke-virtual {v1, v2}, Lnet/duceng/xsynth/Synth;->getPreset(I)I

    move-result v1

    int-to-byte v1, v1

    .line 71
    .local v1, "p":B
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    iget-object v3, p0, Lnet/duceng/xmidi/util/AdapterTrack$3$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$3;

    iget-object v3, v3, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v3}, Lnet/duceng/xmidi/util/AdapterTrack;->access$600(Lnet/duceng/xmidi/util/AdapterTrack;)Landroid/util/SparseArray;

    move-result-object v3

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    .line 72
    iget-object v3, p0, Lnet/duceng/xmidi/util/AdapterTrack$3$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$3;

    iget-object v3, v3, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v3}, Lnet/duceng/xmidi/util/AdapterTrack;->access$600(Lnet/duceng/xmidi/util/AdapterTrack;)Landroid/util/SparseArray;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/MidiTrack;

    .line 73
    .local v3, "t":Lnet/duceng/midi/MidiTrack;
    invoke-virtual {v3}, Lnet/duceng/midi/MidiTrack;->getChannel()B

    move-result v4

    invoke-virtual {v0}, Lnet/duceng/midi/MidiTrack;->getChannel()B

    move-result v5

    if-ne v4, v5, :cond_0

    .line 74
    invoke-virtual {v3, v1}, Lnet/duceng/midi/MidiTrack;->setProgram(B)V

    .line 71
    .end local v3    # "t":Lnet/duceng/midi/MidiTrack;
    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 77
    .end local v2    # "i":I
    :cond_1
    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterTrack$3$1;->this$1:Lnet/duceng/xmidi/util/AdapterTrack$3;

    iget-object v2, v2, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-virtual {v2}, Lnet/duceng/xmidi/util/AdapterTrack;->notifyDataSetChanged()V

    .line 78
    return-void
.end method
