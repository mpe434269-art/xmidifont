.class Lnet/duceng/xmidi/util/AdapterTrack$3;
.super Ljava/lang/Object;
.source "AdapterTrack.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/AdapterTrack;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/util/AdapterTrack;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/AdapterTrack;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/AdapterTrack;

    .line 59
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .param p1, "v"    # Landroid/view/View;

    .line 63
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    move-object v1, p1

    check-cast v1, Landroid/widget/Button;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/util/AdapterTrack;->access$402(Lnet/duceng/xmidi/util/AdapterTrack;Landroid/widget/Button;)Landroid/widget/Button;

    .line 64
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v0}, Lnet/duceng/xmidi/util/AdapterTrack;->access$500(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xmidi/ui/DialogPreset;

    move-result-object v0

    if-nez v0, :cond_0

    .line 65
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    new-instance v1, Lnet/duceng/xmidi/ui/DialogPreset;

    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v2}, Lnet/duceng/xmidi/util/AdapterTrack;->access$300(Lnet/duceng/xmidi/util/AdapterTrack;)Landroid/content/Context;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v3}, Lnet/duceng/xmidi/util/AdapterTrack;->access$000(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xsynth/Synth;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Lnet/duceng/xmidi/ui/DialogPreset;-><init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V

    invoke-static {v0, v1}, Lnet/duceng/xmidi/util/AdapterTrack;->access$502(Lnet/duceng/xmidi/util/AdapterTrack;Lnet/duceng/xmidi/ui/DialogPreset;)Lnet/duceng/xmidi/ui/DialogPreset;

    .line 66
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v0}, Lnet/duceng/xmidi/util/AdapterTrack;->access$500(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xmidi/ui/DialogPreset;

    move-result-object v0

    new-instance v1, Lnet/duceng/xmidi/util/AdapterTrack$3$1;

    invoke-direct {v1, p0}, Lnet/duceng/xmidi/util/AdapterTrack$3$1;-><init>(Lnet/duceng/xmidi/util/AdapterTrack$3;)V

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogPreset;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 81
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v0}, Lnet/duceng/xmidi/util/AdapterTrack;->access$500(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xmidi/ui/DialogPreset;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v2}, Lnet/duceng/xmidi/util/AdapterTrack;->access$400(Lnet/duceng/xmidi/util/AdapterTrack;)Landroid/widget/Button;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Button;->getTag()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v1, v2}, Lnet/duceng/xmidi/util/AdapterTrack;->getItem(I)Lnet/duceng/midi/MidiTrack;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/midi/MidiTrack;->getChannel()B

    move-result v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/ui/DialogPreset;->setChannel(I)V

    .line 82
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack$3;->this$0:Lnet/duceng/xmidi/util/AdapterTrack;

    invoke-static {v0}, Lnet/duceng/xmidi/util/AdapterTrack;->access$500(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xmidi/ui/DialogPreset;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/ui/DialogPreset;->show()V

    .line 83
    return-void
.end method
