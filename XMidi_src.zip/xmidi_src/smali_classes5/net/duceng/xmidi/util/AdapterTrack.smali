.class public Lnet/duceng/xmidi/util/AdapterTrack;
.super Landroid/widget/BaseAdapter;
.source "AdapterTrack.java"


# instance fields
.field private chB:Landroid/widget/Button;

.field private chDialog:Lnet/duceng/xmidi/ui/DialogChannel;

.field private context:Landroid/content/Context;

.field private drums:[Ljava/lang/String;

.field private instruments:[Ljava/lang/String;

.field private onChannelClickListener:Landroid/view/View$OnClickListener;

.field private onCheckClickListener:Landroid/view/View$OnClickListener;

.field private onPresetClickListener:Landroid/view/View$OnClickListener;

.field private prB:Landroid/widget/Button;

.field private prDialog:Lnet/duceng/xmidi/ui/DialogPreset;

.field private synth:Lnet/duceng/xsynth/Synth;

.field private tracks:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lnet/duceng/midi/MidiTrack;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnet/duceng/xsynth/Synth;)V
    .locals 2
    .param p1, "c"    # Landroid/content/Context;
    .param p2, "s"    # Lnet/duceng/xsynth/Synth;

    .line 87
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 30
    new-instance v0, Lnet/duceng/xmidi/util/AdapterTrack$1;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/util/AdapterTrack$1;-><init>(Lnet/duceng/xmidi/util/AdapterTrack;)V

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->onCheckClickListener:Landroid/view/View$OnClickListener;

    .line 38
    new-instance v0, Lnet/duceng/xmidi/util/AdapterTrack$2;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/util/AdapterTrack$2;-><init>(Lnet/duceng/xmidi/util/AdapterTrack;)V

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->onChannelClickListener:Landroid/view/View$OnClickListener;

    .line 59
    new-instance v0, Lnet/duceng/xmidi/util/AdapterTrack$3;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/util/AdapterTrack$3;-><init>(Lnet/duceng/xmidi/util/AdapterTrack;)V

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->onPresetClickListener:Landroid/view/View$OnClickListener;

    .line 85
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->tracks:Landroid/util/SparseArray;

    .line 88
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterTrack;->context:Landroid/content/Context;

    .line 89
    iput-object p2, p0, Lnet/duceng/xmidi/util/AdapterTrack;->synth:Lnet/duceng/xsynth/Synth;

    .line 90
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010004

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->instruments:[Ljava/lang/String;

    .line 91
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f010002

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->drums:[Ljava/lang/String;

    .line 92
    invoke-virtual {p0}, Lnet/duceng/xmidi/util/AdapterTrack;->notifyDataSetChanged()V

    .line 93
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xsynth/Synth;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterTrack;

    .line 21
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->synth:Lnet/duceng/xsynth/Synth;

    return-object v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/util/AdapterTrack;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterTrack;

    .line 21
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->chB:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$102(Lnet/duceng/xmidi/util/AdapterTrack;Landroid/widget/Button;)Landroid/widget/Button;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterTrack;
    .param p1, "x1"    # Landroid/widget/Button;

    .line 21
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterTrack;->chB:Landroid/widget/Button;

    return-object p1
.end method

.method static synthetic access$200(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xmidi/ui/DialogChannel;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterTrack;

    .line 21
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->chDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    return-object v0
.end method

.method static synthetic access$202(Lnet/duceng/xmidi/util/AdapterTrack;Lnet/duceng/xmidi/ui/DialogChannel;)Lnet/duceng/xmidi/ui/DialogChannel;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterTrack;
    .param p1, "x1"    # Lnet/duceng/xmidi/ui/DialogChannel;

    .line 21
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterTrack;->chDialog:Lnet/duceng/xmidi/ui/DialogChannel;

    return-object p1
.end method

.method static synthetic access$300(Lnet/duceng/xmidi/util/AdapterTrack;)Landroid/content/Context;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterTrack;

    .line 21
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->context:Landroid/content/Context;

    return-object v0
.end method

.method static synthetic access$400(Lnet/duceng/xmidi/util/AdapterTrack;)Landroid/widget/Button;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterTrack;

    .line 21
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->prB:Landroid/widget/Button;

    return-object v0
.end method

.method static synthetic access$402(Lnet/duceng/xmidi/util/AdapterTrack;Landroid/widget/Button;)Landroid/widget/Button;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterTrack;
    .param p1, "x1"    # Landroid/widget/Button;

    .line 21
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterTrack;->prB:Landroid/widget/Button;

    return-object p1
.end method

.method static synthetic access$500(Lnet/duceng/xmidi/util/AdapterTrack;)Lnet/duceng/xmidi/ui/DialogPreset;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterTrack;

    .line 21
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->prDialog:Lnet/duceng/xmidi/ui/DialogPreset;

    return-object v0
.end method

.method static synthetic access$502(Lnet/duceng/xmidi/util/AdapterTrack;Lnet/duceng/xmidi/ui/DialogPreset;)Lnet/duceng/xmidi/ui/DialogPreset;
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterTrack;
    .param p1, "x1"    # Lnet/duceng/xmidi/ui/DialogPreset;

    .line 21
    iput-object p1, p0, Lnet/duceng/xmidi/util/AdapterTrack;->prDialog:Lnet/duceng/xmidi/ui/DialogPreset;

    return-object p1
.end method

.method static synthetic access$600(Lnet/duceng/xmidi/util/AdapterTrack;)Landroid/util/SparseArray;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/AdapterTrack;

    .line 21
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->tracks:Landroid/util/SparseArray;

    return-object v0
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 109
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->tracks:Landroid/util/SparseArray;

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    return v0
.end method

.method public bridge synthetic getItem(I)Ljava/lang/Object;
    .locals 0

    .line 21
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/AdapterTrack;->getItem(I)Lnet/duceng/midi/MidiTrack;

    move-result-object p1

    return-object p1
.end method

.method public getItem(I)Lnet/duceng/midi/MidiTrack;
    .locals 1
    .param p1, "pos"    # I

    .line 114
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->tracks:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/midi/MidiTrack;

    return-object v0
.end method

.method public getItemId(I)J
    .locals 2
    .param p1, "pos"    # I

    .line 119
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->tracks:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v0

    int-to-long v0, v0

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 7
    .param p1, "pos"    # I
    .param p2, "view"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .line 124
    const v0, 0x7f0400c3

    const v1, 0x7f0400c5

    const v2, 0x7f0400c4

    if-nez p2, :cond_0

    .line 125
    iget-object v3, p0, Lnet/duceng/xmidi/util/AdapterTrack;->context:Landroid/content/Context;

    invoke-static {v3}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v3

    const/4 v4, 0x0

    move-object v5, v4

    check-cast v5, Landroid/view/ViewGroup;

    const v5, 0x7f05001f

    invoke-virtual {v3, v5, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p2

    .line 126
    invoke-virtual {p2, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/CheckBox;

    iget-object v4, p0, Lnet/duceng/xmidi/util/AdapterTrack;->onCheckClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v3, v4}, Landroid/widget/CheckBox;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 127
    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    iget-object v4, p0, Lnet/duceng/xmidi/util/AdapterTrack;->onPresetClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 128
    invoke-virtual {p2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/Button;

    iget-object v4, p0, Lnet/duceng/xmidi/util/AdapterTrack;->onChannelClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v3, v4}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 130
    :cond_0
    invoke-virtual {p2, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/CheckBox;

    .line 131
    .local v2, "cb":Landroid/widget/CheckBox;
    const v3, 0x7f0400c6

    invoke-virtual {p2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    .line 132
    .local v3, "num":Landroid/widget/TextView;
    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/Button;

    .line 133
    .local v1, "name":Landroid/widget/Button;
    invoke-virtual {p2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    .line 134
    .local v0, "channel":Landroid/widget/Button;
    iget-object v4, p0, Lnet/duceng/xmidi/util/AdapterTrack;->synth:Lnet/duceng/xsynth/Synth;

    iget-object v5, p0, Lnet/duceng/xmidi/util/AdapterTrack;->tracks:Landroid/util/SparseArray;

    invoke-virtual {v5, p1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v5

    invoke-virtual {v4, v5}, Lnet/duceng/xsynth/Synth;->isScore(I)Z

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 135
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/CheckBox;->setTag(Ljava/lang/Object;)V

    .line 136
    iget-object v4, p0, Lnet/duceng/xmidi/util/AdapterTrack;->tracks:Landroid/util/SparseArray;

    invoke-virtual {v4, p1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 137
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/AdapterTrack;->getItem(I)Lnet/duceng/midi/MidiTrack;

    move-result-object v4

    .line 138
    .local v4, "midiTrack":Lnet/duceng/midi/MidiTrack;
    iget-object v5, p0, Lnet/duceng/xmidi/util/AdapterTrack;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v4}, Lnet/duceng/midi/MidiTrack;->getChannel()B

    move-result v6

    invoke-virtual {v5, v6}, Lnet/duceng/xsynth/Synth;->getBank(I)I

    move-result v5

    sget v6, Lnet/duceng/xsynth/Synth;->DRUMS_BANK:I

    if-ne v5, v6, :cond_1

    .line 139
    iget-object v5, p0, Lnet/duceng/xmidi/util/AdapterTrack;->drums:[Ljava/lang/String;

    invoke-virtual {v4}, Lnet/duceng/midi/MidiTrack;->getProgram()B

    move-result v6

    div-int/lit8 v6, v6, 0x8

    aget-object v5, v5, v6

    invoke-virtual {v1, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 141
    :cond_1
    iget-object v5, p0, Lnet/duceng/xmidi/util/AdapterTrack;->instruments:[Ljava/lang/String;

    invoke-virtual {v4}, Lnet/duceng/midi/MidiTrack;->getProgram()B

    move-result v6

    aget-object v5, v5, v6

    invoke-virtual {v1, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 143
    :goto_0
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 144
    invoke-virtual {v4}, Lnet/duceng/midi/MidiTrack;->getChannel()B

    move-result v5

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 145
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/widget/Button;->setTag(Ljava/lang/Object;)V

    .line 146
    return-object p2
.end method

.method public notifyDataSetChanged()V
    .locals 4

    .line 97
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->tracks:Landroid/util/SparseArray;

    invoke-virtual {v0}, Landroid/util/SparseArray;->clear()V

    .line 98
    iget-object v0, p0, Lnet/duceng/xmidi/util/AdapterTrack;->synth:Lnet/duceng/xsynth/Synth;

    invoke-virtual {v0}, Lnet/duceng/xsynth/Synth;->getMidiFile()Lnet/duceng/midi/MidiFile;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MidiFile;->getTracks()Ljava/util/ArrayList;

    move-result-object v0

    .line 99
    .local v0, "mts":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiTrack;>;"
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    .line 100
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/midi/MidiTrack;

    invoke-virtual {v2}, Lnet/duceng/midi/MidiTrack;->getChannel()B

    move-result v2

    if-ltz v2, :cond_0

    .line 101
    iget-object v2, p0, Lnet/duceng/xmidi/util/AdapterTrack;->tracks:Landroid/util/SparseArray;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/MidiTrack;

    invoke-virtual {v2, v1, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 99
    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 104
    .end local v1    # "i":I
    :cond_1
    invoke-super {p0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    .line 105
    return-void
.end method
