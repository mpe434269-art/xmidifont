.class public Lnet/duceng/xmidi/util/Chords$Chord;
.super Ljava/lang/Object;
.source "Chords.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/Chords;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "Chord"
.end annotation


# instance fields
.field public chords:[B

.field public gfingers:[B

.field public gnotes:[B

.field public id:I

.field public name:Ljava/lang/String;

.field public root:B

.field final synthetic this$0:Lnet/duceng/xmidi/util/Chords;

.field public tonality:B


# direct methods
.method public constructor <init>(Lnet/duceng/xmidi/util/Chords;)V
    .locals 1
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/Chords;

    .line 24
    iput-object p1, p0, Lnet/duceng/xmidi/util/Chords$Chord;->this$0:Lnet/duceng/xmidi/util/Chords;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    const/4 v0, 0x7

    new-array v0, v0, [B

    iput-object v0, p0, Lnet/duceng/xmidi/util/Chords$Chord;->gfingers:[B

    .line 18
    const/4 v0, 0x6

    new-array v0, v0, [B

    iput-object v0, p0, Lnet/duceng/xmidi/util/Chords$Chord;->gnotes:[B

    .line 25
    return-void
.end method
