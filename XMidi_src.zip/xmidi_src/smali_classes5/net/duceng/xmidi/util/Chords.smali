.class public Lnet/duceng/xmidi/util/Chords;
.super Ljava/lang/Object;
.source "Chords.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/util/Chords$Chord;
    }
.end annotation


# static fields
.field public static final CBASES:[[B

.field public static final CNAMES:[Ljava/lang/String;

.field private static GCHORD_BASES:[B

.field private static GCHORD_FINGERS:[[B

.field private static GCHORD_GROUP:[B

.field private static final GCHORD_GROUP16:[B

.field private static GCHORD_NAME:[Ljava/lang/String;

.field public static final TONALITIES:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 90

    .line 11
    const-string v10, "bB"

    const-string v11, "B"

    const-string v0, "C"

    const-string v1, "bD"

    const-string v2, "D"

    const-string v3, "bE"

    const-string v4, "E"

    const-string v5, "F"

    const-string v6, "#F"

    const-string v7, "G"

    const-string v8, "bA"

    const-string v9, "A"

    filled-new-array/range {v0 .. v11}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lnet/duceng/xmidi/util/Chords;->TONALITIES:[Ljava/lang/String;

    .line 12
    const/16 v0, 0x8

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    sput-object v1, Lnet/duceng/xmidi/util/Chords;->GCHORD_GROUP:[B

    .line 13
    const-string v48, "bBm7"

    const-string v49, "Bm7"

    const-string v2, "C"

    const-string v3, "bD"

    const-string v4, "D"

    const-string v5, "bE"

    const-string v6, "E"

    const-string v7, "F"

    const-string v8, "#F"

    const-string v9, "G"

    const-string v10, "bA"

    const-string v11, "A"

    const-string v12, "bB"

    const-string v13, "B"

    const-string v14, "Cm"

    const-string v15, "bDm"

    const-string v16, "Dm"

    const-string v17, "bEm"

    const-string v18, "Em"

    const-string v19, "Fm"

    const-string v20, "#Fm"

    const-string v21, "Gm"

    const-string v22, "bAm"

    const-string v23, "Am"

    const-string v24, "bBm"

    const-string v25, "Bm"

    const-string v26, "C7"

    const-string v27, "bD7"

    const-string v28, "D7"

    const-string v29, "bE7"

    const-string v30, "E7"

    const-string v31, "F7"

    const-string v32, "#F7"

    const-string v33, "G7"

    const-string v34, "bA7"

    const-string v35, "A7"

    const-string v36, "bB7"

    const-string v37, "B7"

    const-string v38, "Cm7"

    const-string v39, "bDm7"

    const-string v40, "Dm7"

    const-string v41, "bEm7"

    const-string v42, "Em7"

    const-string v43, "Fm7"

    const-string v44, "#Fm7"

    const-string v45, "Gm7"

    const-string v46, "bAm7"

    const-string v47, "Am7"

    filled-new-array/range {v2 .. v49}, [Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lnet/duceng/xmidi/util/Chords;->GCHORD_NAME:[Ljava/lang/String;

    .line 72
    const/16 v1, 0x10

    new-array v2, v1, [B

    fill-array-data v2, :array_1

    sput-object v2, Lnet/duceng/xmidi/util/Chords;->GCHORD_GROUP16:[B

    .line 112
    const/4 v2, 0x7

    new-array v3, v2, [B

    .line 113
    .local v3, "bArr":[B
    const/4 v4, 0x2

    aput-byte v4, v3, v4

    .line 114
    const/4 v5, 0x3

    aput-byte v4, v3, v5

    .line 115
    new-array v6, v2, [B

    .line 116
    .local v6, "bArr2":[B
    aput-byte v4, v6, v4

    .line 117
    const/4 v7, 0x4

    const/4 v8, 0x1

    aput-byte v8, v6, v7

    .line 118
    new-array v9, v2, [B

    .line 119
    .local v9, "bArr3":[B
    const/4 v10, 0x0

    aput-byte v8, v9, v10

    .line 120
    aput-byte v4, v9, v4

    .line 121
    new-array v11, v2, [B

    .line 122
    .local v11, "bArr4":[B
    aput-byte v4, v11, v10

    .line 123
    aput-byte v4, v11, v4

    .line 124
    new-array v12, v2, [B

    .line 125
    .local v12, "bArr5":[B
    aput-byte v5, v12, v10

    .line 126
    aput-byte v4, v12, v4

    .line 127
    new-array v13, v2, [B

    .line 128
    .local v13, "bArr6":[B
    aput-byte v7, v13, v10

    .line 129
    aput-byte v4, v13, v4

    .line 130
    new-array v14, v2, [B

    fill-array-data v14, :array_2

    new-array v15, v2, [B

    fill-array-data v15, :array_3

    new-array v1, v2, [B

    fill-array-data v1, :array_4

    new-array v0, v2, [B

    fill-array-data v0, :array_5

    new-array v7, v2, [B

    fill-array-data v7, :array_6

    new-array v5, v2, [B

    fill-array-data v5, :array_7

    new-array v4, v2, [B

    fill-array-data v4, :array_8

    new-array v8, v2, [B

    fill-array-data v8, :array_9

    new-array v10, v2, [B

    fill-array-data v10, :array_a

    move-object/from16 v23, v13

    .end local v13    # "bArr6":[B
    .local v23, "bArr6":[B
    new-array v13, v2, [B

    fill-array-data v13, :array_b

    move-object/from16 v24, v12

    .end local v12    # "bArr5":[B
    .local v24, "bArr5":[B
    new-array v12, v2, [B

    fill-array-data v12, :array_c

    move-object/from16 v25, v11

    .end local v11    # "bArr4":[B
    .local v25, "bArr4":[B
    new-array v11, v2, [B

    fill-array-data v11, :array_d

    move-object/from16 v26, v9

    .end local v9    # "bArr3":[B
    .local v26, "bArr3":[B
    new-array v9, v2, [B

    fill-array-data v9, :array_e

    move-object/from16 v27, v6

    .end local v6    # "bArr2":[B
    .local v27, "bArr2":[B
    new-array v6, v2, [B

    fill-array-data v6, :array_f

    move-object/from16 v28, v3

    .end local v3    # "bArr":[B
    .local v28, "bArr":[B
    new-array v3, v2, [B

    fill-array-data v3, :array_10

    move-object/from16 v29, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_11

    move-object/from16 v30, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_12

    move-object/from16 v31, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_13

    move-object/from16 v32, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_14

    move-object/from16 v33, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_15

    move-object/from16 v34, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_16

    move-object/from16 v35, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_17

    move-object/from16 v36, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_18

    move-object/from16 v37, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_19

    move-object/from16 v38, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_1a

    move-object/from16 v39, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_1b

    move-object/from16 v40, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_1c

    move-object/from16 v41, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_1d

    move-object/from16 v42, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_1e

    move-object/from16 v43, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_1f

    move-object/from16 v44, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_20

    move-object/from16 v45, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_21

    move-object/from16 v46, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_22

    move-object/from16 v47, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_23

    move-object/from16 v48, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_24

    move-object/from16 v49, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_25

    move-object/from16 v50, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_26

    move-object/from16 v51, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_27

    move-object/from16 v52, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_28

    move-object/from16 v53, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_29

    move-object/from16 v54, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_2a

    move-object/from16 v55, v3

    new-array v3, v2, [B

    fill-array-data v3, :array_2b

    const/16 v2, 0x30

    new-array v2, v2, [[B

    const/16 v22, 0x0

    aput-object v14, v2, v22

    const/4 v14, 0x1

    aput-object v15, v2, v14

    const/4 v14, 0x2

    aput-object v1, v2, v14

    const/4 v1, 0x3

    aput-object v0, v2, v1

    const/4 v0, 0x4

    aput-object v7, v2, v0

    const/4 v0, 0x5

    aput-object v5, v2, v0

    const/4 v1, 0x6

    aput-object v4, v2, v1

    const/4 v4, 0x7

    aput-object v8, v2, v4

    const/16 v4, 0x8

    aput-object v10, v2, v4

    const/16 v4, 0x9

    aput-object v13, v2, v4

    const/16 v5, 0xa

    aput-object v12, v2, v5

    const/16 v7, 0xb

    aput-object v11, v2, v7

    const/16 v8, 0xc

    aput-object v9, v2, v8

    const/16 v9, 0xd

    aput-object v6, v2, v9

    const/16 v6, 0xe

    aput-object v29, v2, v6

    const/16 v9, 0xf

    aput-object v30, v2, v9

    const/16 v9, 0x10

    aput-object v28, v2, v9

    const/16 v9, 0x11

    aput-object v31, v2, v9

    const/16 v10, 0x12

    aput-object v32, v2, v10

    const/16 v11, 0x13

    aput-object v33, v2, v11

    const/16 v12, 0x14

    aput-object v34, v2, v12

    const/16 v12, 0x15

    aput-object v35, v2, v12

    const/16 v13, 0x16

    aput-object v36, v2, v13

    const/16 v13, 0x17

    aput-object v37, v2, v13

    const/16 v13, 0x18

    aput-object v38, v2, v13

    const/16 v13, 0x19

    aput-object v39, v2, v13

    const/16 v13, 0x1a

    aput-object v40, v2, v13

    const/16 v13, 0x1b

    aput-object v41, v2, v13

    const/16 v13, 0x1c

    aput-object v27, v2, v13

    const/16 v13, 0x1d

    aput-object v42, v2, v13

    const/16 v13, 0x1e

    aput-object v43, v2, v13

    const/16 v13, 0x1f

    aput-object v44, v2, v13

    const/16 v14, 0x20

    aput-object v45, v2, v14

    const/16 v14, 0x21

    aput-object v46, v2, v14

    const/16 v14, 0x22

    aput-object v47, v2, v14

    const/16 v14, 0x23

    aput-object v48, v2, v14

    const/16 v14, 0x24

    aput-object v49, v2, v14

    const/16 v14, 0x25

    aput-object v50, v2, v14

    const/16 v14, 0x26

    aput-object v51, v2, v14

    const/16 v14, 0x27

    aput-object v52, v2, v14

    const/16 v14, 0x28

    aput-object v53, v2, v14

    const/16 v14, 0x29

    aput-object v26, v2, v14

    const/16 v14, 0x2a

    aput-object v25, v2, v14

    const/16 v14, 0x2b

    aput-object v24, v2, v14

    const/16 v14, 0x2c

    aput-object v23, v2, v14

    const/16 v14, 0x2d

    aput-object v54, v2, v14

    const/16 v14, 0x2e

    aput-object v55, v2, v14

    const/16 v14, 0x2f

    aput-object v3, v2, v14

    sput-object v2, Lnet/duceng/xmidi/util/Chords;->GCHORD_FINGERS:[[B

    .line 131
    new-array v2, v1, [B

    fill-array-data v2, :array_2c

    sput-object v2, Lnet/duceng/xmidi/util/Chords;->GCHORD_BASES:[B

    .line 132
    const-string v88, "sus4"

    const-string v89, "1+2+5"

    const-string v56, "Maj"

    const-string v57, "Maj6"

    const-string v58, "Maj7"

    const-string v59, "M7#11"

    const-string v60, "Madd9"

    const-string v61, "M7(9)"

    const-string v62, "M6(9)"

    const-string v63, "aug"

    const-string v64, "m"

    const-string v65, "m6"

    const-string v66, "m7"

    const-string v67, "m7b5"

    const-string v68, "m(9)"

    const-string v69, "m7(9)"

    const-string v70, "m7(11)"

    const-string v71, "mM7"

    const-string v72, "mM7(9)"

    const-string v73, "dim"

    const-string v74, "dim7"

    const-string v75, "7"

    const-string v76, "7sus"

    const-string v77, "7b5"

    const-string v78, "7(9)"

    const-string v79, "7(#11)"

    const-string v80, "7(13)"

    const-string v81, "7(b9)"

    const-string v82, "7(b13)"

    const-string v83, "7(#9)"

    const-string v84, "M7aug"

    const-string v85, "7aug"

    const-string v86, "1+8"

    const-string v87, "1+5"

    filled-new-array/range {v56 .. v89}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, Lnet/duceng/xmidi/util/Chords;->CNAMES:[Ljava/lang/String;

    .line 133
    const/4 v2, 0x3

    new-array v3, v2, [B

    fill-array-data v3, :array_2d

    const/4 v2, 0x4

    new-array v14, v2, [B

    fill-array-data v14, :array_2e

    new-array v15, v2, [B

    fill-array-data v15, :array_2f

    new-array v13, v0, [B

    fill-array-data v13, :array_30

    new-array v12, v2, [B

    fill-array-data v12, :array_31

    new-array v11, v0, [B

    fill-array-data v11, :array_32

    new-array v10, v0, [B

    fill-array-data v10, :array_33

    const/4 v9, 0x3

    new-array v6, v9, [B

    fill-array-data v6, :array_34

    new-array v8, v9, [B

    fill-array-data v8, :array_35

    new-array v9, v2, [B

    fill-array-data v9, :array_36

    new-array v7, v2, [B

    fill-array-data v7, :array_37

    new-array v5, v2, [B

    fill-array-data v5, :array_38

    new-array v4, v2, [B

    fill-array-data v4, :array_39

    new-array v1, v0, [B

    fill-array-data v1, :array_3a

    move-object/from16 v40, v1

    new-array v1, v0, [B

    fill-array-data v1, :array_3b

    move-object/from16 v41, v1

    new-array v1, v2, [B

    fill-array-data v1, :array_3c

    new-array v2, v0, [B

    fill-array-data v2, :array_3d

    move-object/from16 v43, v2

    const/4 v0, 0x3

    new-array v2, v0, [B

    fill-array-data v2, :array_3e

    move-object/from16 v44, v2

    const/4 v0, 0x4

    new-array v2, v0, [B

    fill-array-data v2, :array_3f

    move-object/from16 v45, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_40

    move-object/from16 v46, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_41

    move-object/from16 v47, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_42

    move-object/from16 v48, v2

    const/4 v0, 0x5

    new-array v2, v0, [B

    fill-array-data v2, :array_43

    move-object/from16 v49, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_44

    move-object/from16 v50, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_45

    move-object/from16 v51, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_46

    move-object/from16 v52, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_47

    move-object/from16 v53, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_48

    move-object/from16 v54, v2

    const/4 v0, 0x4

    new-array v2, v0, [B

    fill-array-data v2, :array_49

    move-object/from16 v55, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_4a

    move-object/from16 v20, v2

    const/4 v0, 0x2

    new-array v2, v0, [B

    fill-array-data v2, :array_4b

    move-object/from16 v56, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_4c

    move-object/from16 v19, v2

    const/4 v0, 0x3

    new-array v2, v0, [B

    fill-array-data v2, :array_4d

    move-object/from16 v58, v2

    new-array v2, v0, [B

    fill-array-data v2, :array_4e

    const/16 v0, 0x22

    new-array v0, v0, [[B

    const/16 v22, 0x0

    aput-object v3, v0, v22

    const/4 v3, 0x1

    aput-object v14, v0, v3

    const/4 v3, 0x2

    aput-object v15, v0, v3

    const/4 v3, 0x3

    aput-object v13, v0, v3

    const/4 v3, 0x4

    aput-object v12, v0, v3

    const/4 v3, 0x5

    aput-object v11, v0, v3

    const/4 v3, 0x6

    aput-object v10, v0, v3

    const/4 v3, 0x7

    aput-object v6, v0, v3

    const/16 v3, 0x8

    aput-object v8, v0, v3

    const/16 v3, 0x9

    aput-object v9, v0, v3

    const/16 v3, 0xa

    aput-object v7, v0, v3

    const/16 v3, 0xb

    aput-object v5, v0, v3

    const/16 v3, 0xc

    aput-object v4, v0, v3

    const/16 v3, 0xd

    aput-object v40, v0, v3

    const/16 v3, 0xe

    aput-object v41, v0, v3

    const/16 v3, 0xf

    aput-object v1, v0, v3

    const/16 v1, 0x10

    aput-object v43, v0, v1

    const/16 v1, 0x11

    aput-object v44, v0, v1

    const/16 v1, 0x12

    aput-object v45, v0, v1

    const/16 v1, 0x13

    aput-object v46, v0, v1

    const/16 v1, 0x14

    aput-object v47, v0, v1

    const/16 v1, 0x15

    aput-object v48, v0, v1

    const/16 v1, 0x16

    aput-object v49, v0, v1

    const/16 v1, 0x17

    aput-object v50, v0, v1

    const/16 v1, 0x18

    aput-object v51, v0, v1

    const/16 v1, 0x19

    aput-object v52, v0, v1

    const/16 v1, 0x1a

    aput-object v53, v0, v1

    const/16 v1, 0x1b

    aput-object v54, v0, v1

    const/16 v1, 0x1c

    aput-object v55, v0, v1

    const/16 v1, 0x1d

    aput-object v20, v0, v1

    const/16 v1, 0x1e

    aput-object v56, v0, v1

    const/16 v1, 0x1f

    aput-object v19, v0, v1

    const/16 v1, 0x20

    aput-object v58, v0, v1

    const/16 v1, 0x21

    aput-object v2, v0, v1

    sput-object v0, Lnet/duceng/xmidi/util/Chords;->CBASES:[[B

    .line 134
    .end local v23    # "bArr6":[B
    .end local v24    # "bArr5":[B
    .end local v25    # "bArr4":[B
    .end local v26    # "bArr3":[B
    .end local v27    # "bArr2":[B
    .end local v28    # "bArr":[B
    return-void

    nop

    :array_0
    .array-data 1
        0x0t
        0x5t
        0x7t
        0x1ft
        0x15t
        0xet
        0x10t
        0x28t
    .end array-data

    :array_1
    .array-data 1
        0x0t
        0x5t
        0x7t
        0x1ft
        0x15t
        0xet
        0x10t
        0x28t
        0xat
        0x2t
        0x4t
        0x9t
        0xct
        0x11t
        0x13t
        0x2dt
    .end array-data

    :array_2
    .array-data 1
        0x0t
        0x3t
        0x3t
        0x2t
        0x0t
        0x1t
        0x0t
    .end array-data

    :array_3
    .array-data 1
        0x1t
        -0x1t
        0x3t
        0x2t
        0x0t
        0x1t
        0x0t
    .end array-data

    :array_4
    .array-data 1
        0x0t
        -0x1t
        -0x1t
        0x0t
        0x2t
        0x3t
        0x2t
    .end array-data

    :array_5
    .array-data 1
        0x0t
        -0x1t
        -0x1t
        0x1t
        0x3t
        0x4t
        0x3t
    .end array-data

    :array_6
    .array-data 1
        0x0t
        0x0t
        0x2t
        0x2t
        0x1t
        0x0t
        0x0t
    .end array-data

    :array_7
    .array-data 1
        0x1t
        0x0t
        0x2t
        0x2t
        0x1t
        0x0t
        0x0t
    .end array-data

    :array_8
    .array-data 1
        0x2t
        0x0t
        0x2t
        0x2t
        0x1t
        0x0t
        0x0t
    .end array-data

    :array_9
    .array-data 1
        0x0t
        0x3t
        0x2t
        0x0t
        0x0t
        0x0t
        0x3t
    .end array-data

    :array_a
    .array-data 1
        0x1t
        0x3t
        0x2t
        0x0t
        0x0t
        0x0t
        0x3t
    .end array-data

    :array_b
    .array-data 1
        0x0t
        -0x1t
        0x0t
        0x2t
        0x2t
        0x2t
        0x0t
    .end array-data

    :array_c
    .array-data 1
        0x1t
        -0x1t
        0x0t
        0x2t
        0x2t
        0x2t
        0x0t
    .end array-data

    :array_d
    .array-data 1
        0x2t
        -0x1t
        0x0t
        0x2t
        0x2t
        0x2t
        0x0t
    .end array-data

    :array_e
    .array-data 1
        0x3t
        -0x1t
        0x0t
        0x2t
        0x2t
        0x1t
        0x0t
    .end array-data

    :array_f
    .array-data 1
        0x0t
        -0x1t
        0x4t
        0x2t
        0x1t
        0x2t
        -0x1t
    .end array-data

    :array_10
    .array-data 1
        0x0t
        -0x1t
        0x0t
        0x0t
        0x2t
        0x3t
        0x1t
    .end array-data

    :array_11
    .array-data 1
        0x0t
        -0x1t
        -0x1t
        0x1t
        0x3t
        0x4t
        0x2t
    .end array-data

    :array_12
    .array-data 1
        0x1t
        0x0t
        0x2t
        0x2t
        0x0t
        0x0t
        0x0t
    .end array-data

    :array_13
    .array-data 1
        0x2t
        0x0t
        0x2t
        0x2t
        0x0t
        0x0t
        0x0t
    .end array-data

    :array_14
    .array-data 1
        0x3t
        0x0t
        0x2t
        0x2t
        0x0t
        0x0t
        0x0t
    .end array-data

    :array_15
    .array-data 1
        0x0t
        0x4t
        0x2t
        0x1t
        0x1t
        -0x1t
        -0x1t
    .end array-data

    :array_16
    .array-data 1
        0x0t
        0x0t
        0x0t
        0x2t
        0x2t
        0x1t
        0x0t
    .end array-data

    :array_17
    .array-data 1
        0x1t
        -0x1t
        0x0t
        0x2t
        0x2t
        0x1t
        0x0t
    .end array-data

    :array_18
    .array-data 1
        0x2t
        -0x1t
        0x0t
        0x2t
        0x2t
        0x1t
        0x0t
    .end array-data

    :array_19
    .array-data 1
        0x3t
        -0x1t
        0x0t
        0x2t
        0x0t
        0x2t
        0x0t
    .end array-data

    :array_1a
    .array-data 1
        0x0t
        -0x1t
        0x4t
        0x3t
        0x4t
        0x2t
        -0x1t
    .end array-data

    :array_1b
    .array-data 1
        0x0t
        -0x1t
        -0x1t
        0x0t
        0x2t
        0x1t
        0x2t
    .end array-data

    :array_1c
    .array-data 1
        0x0t
        -0x1t
        -0x1t
        0x1t
        0x3t
        0x2t
        0x3t
    .end array-data

    :array_1d
    .array-data 1
        0x1t
        0x0t
        0x2t
        0x0t
        0x1t
        0x0t
        0x0t
    .end array-data

    :array_1e
    .array-data 1
        0x2t
        0x0t
        0x2t
        0x0t
        0x1t
        0x0t
        0x0t
    .end array-data

    :array_1f
    .array-data 1
        0x0t
        0x3t
        0x2t
        0x0t
        0x0t
        0x0t
        0x1t
    .end array-data

    :array_20
    .array-data 1
        0x1t
        0x3t
        -0x1t
        0x0t
        0x0t
        0x0t
        0x1t
    .end array-data

    :array_21
    .array-data 1
        0x0t
        -0x1t
        0x0t
        0x2t
        0x0t
        0x2t
        0x0t
    .end array-data

    :array_22
    .array-data 1
        0x1t
        -0x1t
        0x0t
        0x2t
        0x0t
        0x2t
        0x0t
    .end array-data

    :array_23
    .array-data 1
        0x2t
        -0x1t
        0x0t
        0x2t
        0x0t
        0x2t
        0x0t
    .end array-data

    :array_24
    .array-data 1
        0x3t
        -0x1t
        0x0t
        0x2t
        0x0t
        0x1t
        0x0t
    .end array-data

    :array_25
    .array-data 1
        0x4t
        -0x1t
        0x0t
        0x2t
        0x0t
        0x1t
        0x0t
    .end array-data

    :array_26
    .array-data 1
        0x0t
        -0x1t
        -0x1t
        0x0t
        0x2t
        0x1t
        0x1t
    .end array-data

    :array_27
    .array-data 1
        0x0t
        -0x1t
        -0x1t
        0x1t
        0x3t
        0x2t
        0x2t
    .end array-data

    :array_28
    .array-data 1
        0x0t
        0x0t
        0x2t
        0x2t
        0x0t
        0x3t
        0x0t
    .end array-data

    :array_29
    .array-data 1
        0x0t
        -0x1t
        0x0t
        0x2t
        0x0t
        0x1t
        0x0t
    .end array-data

    :array_2a
    .array-data 1
        0x1t
        -0x1t
        0x0t
        0x2t
        0x0t
        0x1t
        0x0t
    .end array-data

    :array_2b
    .array-data 1
        0x2t
        -0x1t
        0x0t
        0x2t
        0x0t
        0x1t
        0x0t
    .end array-data

    :array_2c
    .array-data 1
        0x28t
        0x2dt
        0x32t
        0x37t
        0x3bt
        0x40t
    .end array-data

    nop

    :array_2d
    .array-data 1
        0x0t
        0x4t
        0x7t
    .end array-data

    :array_2e
    .array-data 1
        0x0t
        0x4t
        0x7t
        0x9t
    .end array-data

    :array_2f
    .array-data 1
        0x0t
        0x4t
        0x7t
        0xbt
    .end array-data

    :array_30
    .array-data 1
        0x0t
        0x4t
        0x7t
        0xbt
        0x12t
    .end array-data

    nop

    :array_31
    .array-data 1
        0x0t
        0x4t
        0x7t
        0xet
    .end array-data

    :array_32
    .array-data 1
        0x0t
        0x4t
        0x7t
        0xbt
        0xet
    .end array-data

    nop

    :array_33
    .array-data 1
        0x0t
        0x4t
        0x7t
        0x9t
        0xet
    .end array-data

    nop

    :array_34
    .array-data 1
        0x0t
        0x4t
        0x8t
    .end array-data

    :array_35
    .array-data 1
        0x0t
        0x3t
        0x7t
    .end array-data

    :array_36
    .array-data 1
        0x0t
        0x3t
        0x7t
        0x9t
    .end array-data

    :array_37
    .array-data 1
        0x0t
        0x3t
        0x7t
        0xat
    .end array-data

    :array_38
    .array-data 1
        0x0t
        0x3t
        0x6t
        0xat
    .end array-data

    :array_39
    .array-data 1
        0x0t
        0x3t
        0x7t
        0xet
    .end array-data

    :array_3a
    .array-data 1
        0x0t
        0x3t
        0x7t
        0xat
        0xet
    .end array-data

    nop

    :array_3b
    .array-data 1
        0x0t
        0x3t
        0x7t
        0xat
        0x11t
    .end array-data

    nop

    :array_3c
    .array-data 1
        0x0t
        0x3t
        0x7t
        0xbt
    .end array-data

    :array_3d
    .array-data 1
        0x0t
        0x3t
        0x7t
        0xbt
        0xet
    .end array-data

    nop

    :array_3e
    .array-data 1
        0x0t
        0x3t
        0x6t
    .end array-data

    :array_3f
    .array-data 1
        0x0t
        0x3t
        0x6t
        0x8t
    .end array-data

    :array_40
    .array-data 1
        0x0t
        0x4t
        0x7t
        0xat
    .end array-data

    :array_41
    .array-data 1
        0x0t
        0x5t
        0x7t
        0xat
    .end array-data

    :array_42
    .array-data 1
        0x0t
        0x4t
        0x6t
        0xat
    .end array-data

    :array_43
    .array-data 1
        0x0t
        0x4t
        0x7t
        0xat
        0xet
    .end array-data

    nop

    :array_44
    .array-data 1
        0x0t
        0x4t
        0x7t
        0xat
        0x12t
    .end array-data

    nop

    :array_45
    .array-data 1
        0x0t
        0x4t
        0x7t
        0xat
        0x15t
    .end array-data

    nop

    :array_46
    .array-data 1
        0x0t
        0x4t
        0x7t
        0xat
        0xdt
    .end array-data

    nop

    :array_47
    .array-data 1
        0x0t
        0x4t
        0x7t
        0xat
        0x14t
    .end array-data

    nop

    :array_48
    .array-data 1
        0x0t
        0x4t
        0x7t
        0xat
        0xft
    .end array-data

    nop

    :array_49
    .array-data 1
        0x0t
        0x4t
        0x8t
        0xbt
    .end array-data

    :array_4a
    .array-data 1
        0x0t
        0x4t
        0x8t
        0xat
    .end array-data

    :array_4b
    .array-data 1
        0x0t
        0xct
    .end array-data

    nop

    :array_4c
    .array-data 1
        0x0t
        0x7t
    .end array-data

    nop

    :array_4d
    .array-data 1
        0x0t
        0x5t
        0x7t
    .end array-data

    :array_4e
    .array-data 1
        0x0t
        0x2t
        0x7t
    .end array-data
.end method

.method public constructor <init>()V
    .locals 0

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getChord(I)Lnet/duceng/xmidi/util/Chords$Chord;
    .locals 7
    .param p1, "index"    # I

    .line 30
    new-instance v0, Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/util/Chords$Chord;-><init>(Lnet/duceng/xmidi/util/Chords;)V

    .line 31
    .local v0, "chord":Lnet/duceng/xmidi/util/Chords$Chord;
    iput p1, v0, Lnet/duceng/xmidi/util/Chords$Chord;->id:I

    .line 32
    rem-int/lit8 v1, p1, 0xc

    int-to-byte v1, v1

    iput-byte v1, v0, Lnet/duceng/xmidi/util/Chords$Chord;->root:B

    .line 33
    sget-object v1, Lnet/duceng/xmidi/util/Chords;->GCHORD_NAME:[Ljava/lang/String;

    aget-object v1, v1, p1

    iput-object v1, v0, Lnet/duceng/xmidi/util/Chords$Chord;->name:Ljava/lang/String;

    .line 34
    sget-object v1, Lnet/duceng/xmidi/util/Chords;->GCHORD_FINGERS:[[B

    int-to-byte v2, p1

    aget-object v1, v1, v2

    iput-object v1, v0, Lnet/duceng/xmidi/util/Chords$Chord;->gfingers:[B

    .line 35
    sget-object v1, Lnet/duceng/xmidi/util/Chords;->GCHORD_BASES:[B

    array-length v1, v1

    new-array v1, v1, [B

    iput-object v1, v0, Lnet/duceng/xmidi/util/Chords$Chord;->gnotes:[B

    .line 36
    const/4 v1, 0x0

    .local v1, "i":B
    :goto_0
    sget-object v2, Lnet/duceng/xmidi/util/Chords;->GCHORD_BASES:[B

    array-length v2, v2

    const/4 v3, 0x0

    if-ge v1, v2, :cond_1

    .line 37
    sget-object v2, Lnet/duceng/xmidi/util/Chords;->GCHORD_FINGERS:[[B

    aget-object v2, v2, p1

    add-int/lit8 v4, v1, 0x1

    aget-byte v2, v2, v4

    if-ltz v2, :cond_0

    .line 38
    iget-object v2, v0, Lnet/duceng/xmidi/util/Chords$Chord;->gnotes:[B

    sget-object v4, Lnet/duceng/xmidi/util/Chords;->GCHORD_BASES:[B

    aget-byte v4, v4, v1

    sget-object v5, Lnet/duceng/xmidi/util/Chords;->GCHORD_FINGERS:[[B

    aget-object v5, v5, p1

    add-int/lit8 v6, v1, 0x1

    aget-byte v5, v5, v6

    add-int/2addr v4, v5

    sget-object v5, Lnet/duceng/xmidi/util/Chords;->GCHORD_FINGERS:[[B

    aget-object v5, v5, p1

    aget-byte v3, v5, v3

    add-int/2addr v4, v3

    int-to-byte v3, v4

    aput-byte v3, v2, v1

    goto :goto_1

    .line 40
    :cond_0
    iget-object v2, v0, Lnet/duceng/xmidi/util/Chords$Chord;->gnotes:[B

    aput-byte v3, v2, v1

    .line 36
    :goto_1
    add-int/lit8 v2, v1, 0x1

    int-to-byte v1, v2

    goto :goto_0

    .line 43
    .end local v1    # "i":B
    :cond_1
    div-int/lit8 v1, p1, 0xc

    .line 44
    .local v1, "b":I
    packed-switch v1, :pswitch_data_0

    .line 58
    return-object v0

    .line 55
    :pswitch_0
    sget-object v2, Lnet/duceng/xmidi/util/Chords;->CBASES:[[B

    const/16 v3, 0xa

    aget-object v2, v2, v3

    iput-object v2, v0, Lnet/duceng/xmidi/util/Chords$Chord;->chords:[B

    .line 56
    return-object v0

    .line 52
    :pswitch_1
    sget-object v2, Lnet/duceng/xmidi/util/Chords;->CBASES:[[B

    const/16 v3, 0x13

    aget-object v2, v2, v3

    iput-object v2, v0, Lnet/duceng/xmidi/util/Chords$Chord;->chords:[B

    .line 53
    return-object v0

    .line 49
    :pswitch_2
    sget-object v2, Lnet/duceng/xmidi/util/Chords;->CBASES:[[B

    const/16 v3, 0x8

    aget-object v2, v2, v3

    iput-object v2, v0, Lnet/duceng/xmidi/util/Chords$Chord;->chords:[B

    .line 50
    return-object v0

    .line 46
    :pswitch_3
    sget-object v2, Lnet/duceng/xmidi/util/Chords;->CBASES:[[B

    aget-object v2, v2, v3

    iput-object v2, v0, Lnet/duceng/xmidi/util/Chords$Chord;->chords:[B

    .line 47
    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public getChord(Ljava/lang/String;)Lnet/duceng/xmidi/util/Chords$Chord;
    .locals 2
    .param p1, "name"    # Ljava/lang/String;

    .line 63
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    sget-object v1, Lnet/duceng/xmidi/util/Chords;->GCHORD_NAME:[Ljava/lang/String;

    array-length v1, v1

    if-ge v0, v1, :cond_1

    .line 64
    sget-object v1, Lnet/duceng/xmidi/util/Chords;->GCHORD_NAME:[Ljava/lang/String;

    aget-object v1, v1, v0

    invoke-virtual {v1, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 65
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/util/Chords;->getChord(I)Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v1

    return-object v1

    .line 63
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 68
    .end local v0    # "i":I
    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public getGChords()[Ljava/lang/String;
    .locals 1

    .line 108
    sget-object v0, Lnet/duceng/xmidi/util/Chords;->GCHORD_NAME:[Ljava/lang/String;

    return-object v0
.end method

.method public getGChords(I)[Lnet/duceng/xmidi/util/Chords$Chord;
    .locals 5
    .param p1, "index"    # I

    .line 85
    const/16 v0, 0x8

    new-array v0, v0, [Lnet/duceng/xmidi/util/Chords$Chord;

    .line 86
    .local v0, "chords":[Lnet/duceng/xmidi/util/Chords$Chord;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    array-length v2, v0

    if-ge v1, v2, :cond_0

    .line 87
    sget-object v2, Lnet/duceng/xmidi/util/Chords;->GCHORD_GROUP:[B

    aget-byte v2, v2, v1

    div-int/lit8 v2, v2, 0xc

    mul-int/lit8 v2, v2, 0xc

    sget-object v3, Lnet/duceng/xmidi/util/Chords;->GCHORD_GROUP:[B

    aget-byte v3, v3, v1

    add-int/2addr v3, p1

    rem-int/lit8 v3, v3, 0xc

    add-int/2addr v2, v3

    .line 88
    .local v2, "idx":I
    invoke-virtual {p0, v2}, Lnet/duceng/xmidi/util/Chords;->getChord(I)Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v3

    aput-object v3, v0, v1

    .line 89
    aget-object v3, v0, v1

    int-to-byte v4, p1

    iput-byte v4, v3, Lnet/duceng/xmidi/util/Chords$Chord;->tonality:B

    .line 86
    .end local v2    # "idx":I
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 91
    .end local v1    # "i":I
    :cond_0
    return-object v0
.end method

.method public getGChords(Ljava/lang/String;)[Lnet/duceng/xmidi/util/Chords$Chord;
    .locals 2
    .param p1, "name"    # Ljava/lang/String;

    .line 95
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    sget-object v1, Lnet/duceng/xmidi/util/Chords;->TONALITIES:[Ljava/lang/String;

    array-length v1, v1

    if-ge v0, v1, :cond_1

    .line 96
    sget-object v1, Lnet/duceng/xmidi/util/Chords;->TONALITIES:[Ljava/lang/String;

    aget-object v1, v1, v0

    invoke-virtual {v1, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 97
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/util/Chords;->getGChords(I)[Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v1

    return-object v1

    .line 95
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 100
    .end local v0    # "i":I
    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public getGChords16(I)[Lnet/duceng/xmidi/util/Chords$Chord;
    .locals 5
    .param p1, "index"    # I

    .line 75
    sget-object v0, Lnet/duceng/xmidi/util/Chords;->GCHORD_GROUP16:[B

    array-length v0, v0

    new-array v0, v0, [Lnet/duceng/xmidi/util/Chords$Chord;

    .line 76
    .local v0, "chords":[Lnet/duceng/xmidi/util/Chords$Chord;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    array-length v2, v0

    if-ge v1, v2, :cond_0

    .line 77
    sget-object v2, Lnet/duceng/xmidi/util/Chords;->GCHORD_GROUP16:[B

    aget-byte v2, v2, v1

    div-int/lit8 v2, v2, 0xc

    mul-int/lit8 v2, v2, 0xc

    sget-object v3, Lnet/duceng/xmidi/util/Chords;->GCHORD_GROUP16:[B

    aget-byte v3, v3, v1

    add-int/2addr v3, p1

    rem-int/lit8 v3, v3, 0xc

    add-int/2addr v2, v3

    .line 78
    .local v2, "idx":I
    invoke-virtual {p0, v2}, Lnet/duceng/xmidi/util/Chords;->getChord(I)Lnet/duceng/xmidi/util/Chords$Chord;

    move-result-object v3

    aput-object v3, v0, v1

    .line 79
    aget-object v3, v0, v1

    int-to-byte v4, p1

    iput-byte v4, v3, Lnet/duceng/xmidi/util/Chords$Chord;->tonality:B

    .line 76
    .end local v2    # "idx":I
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 81
    .end local v1    # "i":I
    :cond_0
    return-object v0
.end method

.method public getTonalities()[Ljava/lang/String;
    .locals 1

    .line 104
    sget-object v0, Lnet/duceng/xmidi/util/Chords;->TONALITIES:[Ljava/lang/String;

    return-object v0
.end method
