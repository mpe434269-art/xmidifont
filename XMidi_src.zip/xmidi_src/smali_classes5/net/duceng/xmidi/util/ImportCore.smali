.class public final Lnet/duceng/xmidi/util/ImportCore;
.super Ljava/lang/Object;
.source "ImportCore.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    return-void
.end method

.method public static copy(Ljava/io/InputStream;Ljava/io/File;)J
    .locals 8
    .param p0, "in"    # Ljava/io/InputStream;
    .param p1, "dest"    # Ljava/io/File;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 58
    const-wide/16 v0, 0x0

    .line 59
    .local v0, "total":J
    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, p1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 61
    .local v2, "out":Ljava/io/FileOutputStream;
    const/high16 v3, 0x10000

    :try_start_0
    new-array v3, v3, [B

    .line 63
    .local v3, "buf":[B
    :goto_0
    invoke-virtual {p0, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    move v5, v4

    .local v5, "n":I
    if-lez v4, :cond_0

    .line 64
    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4, v5}, Ljava/io/FileOutputStream;->write([BII)V

    .line 65
    int-to-long v6, v5

    add-long/2addr v0, v6

    goto :goto_0

    .line 67
    :cond_0
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->flush()V

    .line 68
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v4

    invoke-virtual {v4}, Ljava/io/FileDescriptor;->sync()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 70
    .end local v3    # "buf":[B
    .end local v5    # "n":I
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V

    .line 71
    nop

    .line 72
    return-wide v0

    .line 70
    :catchall_0
    move-exception v3

    invoke-virtual {v2}, Ljava/io/FileOutputStream;->close()V

    .line 71
    throw v3
.end method

.method public static hasExtension(Ljava/lang/String;[Ljava/lang/String;)Z
    .locals 7
    .param p0, "name"    # Ljava/lang/String;
    .param p1, "exts"    # [Ljava/lang/String;

    .line 30
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    .line 31
    .local v0, "lower":Ljava/lang/String;
    array-length v1, p1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_1

    aget-object v4, p1, v3

    .line 32
    .local v4, "e":Ljava/lang/String;
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "."

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    sget-object v6, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v4, v6}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_0

    .line 33
    const/4 v1, 0x1

    return v1

    .line 31
    .end local v4    # "e":Ljava/lang/String;
    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 36
    :cond_1
    return v2
.end method

.method public static sanitizeName(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "name"    # Ljava/lang/String;

    .line 19
    const-string v0, "importado.bin"

    if-nez p0, :cond_0

    .line 20
    return-object v0

    .line 22
    :cond_0
    const-string v1, "[\\\\/:*?\"<>|\\p{Cntrl}]"

    const-string v2, "_"

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 23
    .local v1, "n":Ljava/lang/String;
    :goto_0
    const-string v2, "."

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 24
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    .line 26
    :cond_1
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-nez v2, :cond_2

    goto :goto_1

    :cond_2
    move-object v0, v1

    :goto_1
    return-object v0
.end method

.method public static uniqueFile(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;
    .locals 8
    .param p0, "dir"    # Ljava/io/File;
    .param p1, "name"    # Ljava/lang/String;

    .line 41
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 42
    .local v0, "f":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_0

    .line 43
    return-object v0

    .line 45
    :cond_0
    const/16 v1, 0x2e

    invoke-virtual {p1, v1}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v1

    .line 46
    .local v1, "dot":I
    if-lez v1, :cond_1

    const/4 v2, 0x0

    invoke-virtual {p1, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :cond_1
    move-object v2, p1

    .line 47
    .local v2, "base":Ljava/lang/String;
    :goto_0
    if-lez v1, :cond_2

    invoke-virtual {p1, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_1

    :cond_2
    const-string v3, ""

    .line 48
    .local v3, "ext":Ljava/lang/String;
    :goto_1
    const/4 v4, 0x1

    .local v4, "i":I
    :goto_2
    const/16 v5, 0x3e8

    if-ge v4, v5, :cond_4

    .line 49
    new-instance v5, Ljava/io/File;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " ("

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ")"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, p0, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 50
    .local v5, "c":Ljava/io/File;
    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v6

    if-nez v6, :cond_3

    .line 51
    return-object v5

    .line 48
    .end local v5    # "c":Ljava/io/File;
    :cond_3
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    .line 54
    .end local v4    # "i":I
    :cond_4
    new-instance v4, Ljava/io/File;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "_"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, p0, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v4
.end method

.method public static validate(Ljava/io/File;Ljava/lang/String;)Ljava/lang/String;
    .locals 8
    .param p0, "f"    # Ljava/io/File;
    .param p1, "kind"    # Ljava/lang/String;

    .line 77
    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v0

    const-wide/16 v2, 0x40

    cmp-long v4, v0, v2

    if-gez v4, :cond_0

    .line 78
    const-string v0, "El archivo esta vacio o es demasiado pequeno."

    return-object v0

    .line 80
    :cond_0
    const/16 v0, 0xc

    new-array v1, v0, [B

    .line 81
    .local v1, "h":[B
    const/4 v2, 0x0

    .line 83
    .local v2, "in":Ljava/io/FileInputStream;
    :try_start_0
    new-instance v3, Ljava/io/FileInputStream;

    invoke-direct {v3, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    move-object v2, v3

    .line 84
    invoke-virtual {v2, v1}, Ljava/io/FileInputStream;->read([B)I

    move-result v3

    if-ge v3, v0, :cond_1

    .line 85
    const-string v0, "El archivo no se pudo leer."
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 90
    nop

    .line 92
    :try_start_1
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    .line 95
    goto :goto_0

    .line 93
    :catch_0
    move-exception v3

    .line 85
    :goto_0
    return-object v0

    .line 90
    :cond_1
    nop

    .line 92
    :try_start_2
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    .line 95
    :goto_1
    goto :goto_2

    .line 93
    :catch_1
    move-exception v0

    goto :goto_1

    .line 98
    :goto_2
    const-string v0, "sty"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v0, :cond_3

    .line 99
    aget-byte v0, v1, v6

    const/16 v6, 0x4d

    if-ne v0, v6, :cond_2

    aget-byte v0, v1, v5

    const/16 v5, 0x54

    if-ne v0, v5, :cond_2

    aget-byte v0, v1, v4

    const/16 v4, 0x68

    if-ne v0, v4, :cond_2

    aget-byte v0, v1, v3

    const/16 v3, 0x64

    if-ne v0, v3, :cond_2

    .line 100
    return-object v7

    .line 102
    :cond_2
    const-string v0, "No parece un estilo Yamaha (.sty) valido."

    return-object v0

    .line 104
    :cond_3
    const-string v0, "sf2"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 105
    aget-byte v0, v1, v6

    const/16 v6, 0x52

    if-ne v0, v6, :cond_4

    aget-byte v0, v1, v5

    const/16 v5, 0x49

    if-ne v0, v5, :cond_4

    aget-byte v0, v1, v4

    const/16 v4, 0x46

    if-ne v0, v4, :cond_4

    aget-byte v0, v1, v3

    if-ne v0, v4, :cond_4

    const/16 v0, 0x8

    aget-byte v0, v1, v0

    const/16 v3, 0x73

    if-ne v0, v3, :cond_4

    const/16 v0, 0x9

    aget-byte v0, v1, v0

    const/16 v3, 0x66

    if-ne v0, v3, :cond_4

    const/16 v0, 0xa

    aget-byte v0, v1, v0

    const/16 v3, 0x62

    if-ne v0, v3, :cond_4

    const/16 v0, 0xb

    aget-byte v0, v1, v0

    const/16 v3, 0x6b

    if-ne v0, v3, :cond_4

    .line 106
    return-object v7

    .line 108
    :cond_4
    const-string v0, "No parece un soundfont (.sf2) valido."

    return-object v0

    .line 110
    :cond_5
    return-object v7

    .line 90
    :catchall_0
    move-exception v0

    goto :goto_4

    .line 87
    :catch_2
    move-exception v0

    .line 88
    .local v0, "e":Ljava/io/IOException;
    :try_start_3
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "El archivo no se pudo leer: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 90
    if-eqz v2, :cond_6

    .line 92
    :try_start_4
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3

    .line 95
    goto :goto_3

    .line 93
    :catch_3
    move-exception v4

    .line 88
    :cond_6
    :goto_3
    return-object v3

    .line 90
    .end local v0    # "e":Ljava/io/IOException;
    :goto_4
    if-eqz v2, :cond_7

    .line 92
    :try_start_5
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_4

    .line 95
    goto :goto_5

    .line 93
    :catch_4
    move-exception v3

    .line 97
    :cond_7
    :goto_5
    throw v0
.end method
