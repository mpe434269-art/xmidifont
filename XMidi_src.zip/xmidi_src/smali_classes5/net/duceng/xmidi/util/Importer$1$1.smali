.class Lnet/duceng/xmidi/util/Importer$1$1;
.super Ljava/lang/Object;
.source "Importer.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/util/Importer$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/util/Importer$1;

.field final synthetic val$fDest:Ljava/io/File;

.field final synthetic val$fError:Ljava/lang/String;

.field final synthetic val$fRemoved:Z


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/Importer$1;Ljava/io/File;ZLjava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/Importer$1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 144
    iput-object p1, p0, Lnet/duceng/xmidi/util/Importer$1$1;->this$0:Lnet/duceng/xmidi/util/Importer$1;

    iput-object p2, p0, Lnet/duceng/xmidi/util/Importer$1$1;->val$fDest:Ljava/io/File;

    iput-boolean p3, p0, Lnet/duceng/xmidi/util/Importer$1$1;->val$fRemoved:Z

    iput-object p4, p0, Lnet/duceng/xmidi/util/Importer$1$1;->val$fError:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 148
    :try_start_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/Importer$1$1;->this$0:Lnet/duceng/xmidi/util/Importer$1;

    iget-object v0, v0, Lnet/duceng/xmidi/util/Importer$1;->val$progress:Landroid/app/AlertDialog;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/util/Importer$1$1;->this$0:Lnet/duceng/xmidi/util/Importer$1;

    iget-object v0, v0, Lnet/duceng/xmidi/util/Importer$1;->val$progress:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 149
    iget-object v0, p0, Lnet/duceng/xmidi/util/Importer$1$1;->this$0:Lnet/duceng/xmidi/util/Importer$1;

    iget-object v0, v0, Lnet/duceng/xmidi/util/Importer$1;->val$progress:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->dismiss()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 153
    :cond_0
    goto :goto_0

    .line 151
    :catch_0
    move-exception v0

    .line 154
    :goto_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/Importer$1$1;->this$0:Lnet/duceng/xmidi/util/Importer$1;

    iget-object v0, v0, Lnet/duceng/xmidi/util/Importer$1;->val$cb:Lnet/duceng/xmidi/util/Importer$Callback;

    iget-object v1, p0, Lnet/duceng/xmidi/util/Importer$1$1;->val$fDest:Ljava/io/File;

    iget-boolean v2, p0, Lnet/duceng/xmidi/util/Importer$1$1;->val$fRemoved:Z

    iget-object v3, p0, Lnet/duceng/xmidi/util/Importer$1$1;->val$fError:Ljava/lang/String;

    invoke-interface {v0, v1, v2, v3}, Lnet/duceng/xmidi/util/Importer$Callback;->onResult(Ljava/io/File;ZLjava/lang/String;)V

    .line 155
    return-void
.end method
