.class Lnet/duceng/xmidi/util/Importer$1;
.super Ljava/lang/Object;
.source "Importer.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/util/Importer;->importAsync(Landroid/app/Activity;Landroid/net/Uri;Ljava/io/File;[Ljava/lang/String;Ljava/lang/String;Lnet/duceng/xmidi/util/Importer$Callback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$act:Landroid/app/Activity;

.field final synthetic val$cb:Lnet/duceng/xmidi/util/Importer$Callback;

.field final synthetic val$dir:Ljava/io/File;

.field final synthetic val$kind:Ljava/lang/String;

.field final synthetic val$name:Ljava/lang/String;

.field final synthetic val$progress:Landroid/app/AlertDialog;

.field final synthetic val$uri:Landroid/net/Uri;


# direct methods
.method constructor <init>(Ljava/io/File;Landroid/app/Activity;Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Landroid/app/AlertDialog;Lnet/duceng/xmidi/util/Importer$Callback;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 90
    iput-object p1, p0, Lnet/duceng/xmidi/util/Importer$1;->val$dir:Ljava/io/File;

    iput-object p2, p0, Lnet/duceng/xmidi/util/Importer$1;->val$act:Landroid/app/Activity;

    iput-object p3, p0, Lnet/duceng/xmidi/util/Importer$1;->val$uri:Landroid/net/Uri;

    iput-object p4, p0, Lnet/duceng/xmidi/util/Importer$1;->val$kind:Ljava/lang/String;

    iput-object p5, p0, Lnet/duceng/xmidi/util/Importer$1;->val$name:Ljava/lang/String;

    iput-object p6, p0, Lnet/duceng/xmidi/util/Importer$1;->val$progress:Landroid/app/AlertDialog;

    iput-object p7, p0, Lnet/duceng/xmidi/util/Importer$1;->val$cb:Lnet/duceng/xmidi/util/Importer$Callback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 10

    .line 93
    const/4 v0, 0x0

    .line 94
    .local v0, "dest":Ljava/io/File;
    const/4 v1, 0x0

    .line 95
    .local v1, "part":Ljava/io/File;
    const/4 v2, 0x0

    .line 96
    .local v2, "error":Ljava/lang/String;
    const/4 v3, 0x0

    .line 97
    .local v3, "removed":Z
    const/4 v4, 0x0

    .line 99
    .local v4, "in":Ljava/io/InputStream;
    :try_start_0
    iget-object v5, p0, Lnet/duceng/xmidi/util/Importer$1;->val$dir:Ljava/io/File;

    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v5

    if-nez v5, :cond_1

    iget-object v5, p0, Lnet/duceng/xmidi/util/Importer$1;->val$dir:Ljava/io/File;

    invoke-virtual {v5}, Ljava/io/File;->mkdirs()Z

    move-result v5

    if-eqz v5, :cond_0

    goto :goto_0

    .line 100
    :cond_0
    new-instance v5, Ljava/io/IOException;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "No hay acceso a la carpeta de la app ("

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lnet/duceng/xmidi/util/Importer$1;->val$dir:Ljava/io/File;

    invoke-virtual {v7}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ")."

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local v0    # "dest":Ljava/io/File;
    .end local v1    # "part":Ljava/io/File;
    .end local v2    # "error":Ljava/lang/String;
    .end local v3    # "removed":Z
    .end local v4    # "in":Ljava/io/InputStream;
    throw v5

    .line 102
    .restart local v0    # "dest":Ljava/io/File;
    .restart local v1    # "part":Ljava/io/File;
    .restart local v2    # "error":Ljava/lang/String;
    .restart local v3    # "removed":Z
    .restart local v4    # "in":Ljava/io/InputStream;
    :cond_1
    :goto_0
    iget-object v5, p0, Lnet/duceng/xmidi/util/Importer$1;->val$act:Landroid/app/Activity;

    invoke-virtual {v5}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    iget-object v6, p0, Lnet/duceng/xmidi/util/Importer$1;->val$uri:Landroid/net/Uri;

    invoke-virtual {v5, v6}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v5

    move-object v4, v5

    .line 103
    if-eqz v4, :cond_7

    .line 106
    new-instance v5, Ljava/io/File;

    iget-object v6, p0, Lnet/duceng/xmidi/util/Importer$1;->val$dir:Ljava/io/File;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, ".importando_"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v8

    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ".part"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v5, v6, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v1, v5

    .line 107
    invoke-static {v4, v1}, Lnet/duceng/xmidi/util/ImportCore;->copy(Ljava/io/InputStream;Ljava/io/File;)J

    .line 108
    iget-object v5, p0, Lnet/duceng/xmidi/util/Importer$1;->val$kind:Ljava/lang/String;

    invoke-static {v1, v5}, Lnet/duceng/xmidi/util/ImportCore;->validate(Ljava/io/File;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 109
    .local v5, "bad":Ljava/lang/String;
    if-eqz v5, :cond_2

    .line 110
    move-object v2, v5

    goto :goto_2

    .line 112
    :cond_2
    iget-object v6, p0, Lnet/duceng/xmidi/util/Importer$1;->val$dir:Ljava/io/File;

    iget-object v7, p0, Lnet/duceng/xmidi/util/Importer$1;->val$name:Ljava/lang/String;

    invoke-static {v6, v7}, Lnet/duceng/xmidi/util/ImportCore;->uniqueFile(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    move-result-object v6

    move-object v0, v6

    .line 113
    invoke-virtual {v1, v0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v6
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v6, :cond_6

    .line 116
    const/4 v1, 0x0

    .line 118
    :try_start_1
    iget-object v6, p0, Lnet/duceng/xmidi/util/Importer$1;->val$act:Landroid/app/Activity;

    iget-object v7, p0, Lnet/duceng/xmidi/util/Importer$1;->val$uri:Landroid/net/Uri;

    invoke-static {v6, v7}, Landroid/provider/DocumentsContract;->isDocumentUri(Landroid/content/Context;Landroid/net/Uri;)Z

    move-result v6

    if-eqz v6, :cond_3

    .line 119
    iget-object v6, p0, Lnet/duceng/xmidi/util/Importer$1;->val$act:Landroid/app/Activity;

    invoke-virtual {v6}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v6

    iget-object v7, p0, Lnet/duceng/xmidi/util/Importer$1;->val$uri:Landroid/net/Uri;

    invoke-static {v6, v7}, Landroid/provider/DocumentsContract;->deleteDocument(Landroid/content/ContentResolver;Landroid/net/Uri;)Z

    move-result v6

    move v3, v6

    goto :goto_1

    .line 120
    :cond_3
    const-string v6, "file"

    iget-object v7, p0, Lnet/duceng/xmidi/util/Importer$1;->val$uri:Landroid/net/Uri;

    invoke-virtual {v7}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4

    iget-object v6, p0, Lnet/duceng/xmidi/util/Importer$1;->val$uri:Landroid/net/Uri;

    invoke-virtual {v6}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_4

    .line 121
    new-instance v6, Ljava/io/File;

    iget-object v7, p0, Lnet/duceng/xmidi/util/Importer$1;->val$uri:Landroid/net/Uri;

    invoke-virtual {v7}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/io/File;->delete()Z

    move-result v6
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move v3, v6

    .line 125
    :cond_4
    :goto_1
    goto :goto_2

    .line 123
    :catch_0
    move-exception v6

    .line 124
    .local v6, "ignored":Ljava/lang/Exception;
    const/4 v3, 0x0

    .line 131
    .end local v5    # "bad":Ljava/lang/String;
    .end local v6    # "ignored":Ljava/lang/Exception;
    :goto_2
    if-eqz v4, :cond_5

    .line 132
    :try_start_2
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_3

    .line 134
    :catch_1
    move-exception v5

    goto :goto_4

    .line 136
    :cond_5
    :goto_3
    nop

    .line 137
    :goto_4
    if-eqz v1, :cond_9

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v5

    if-eqz v5, :cond_9

    .line 138
    :goto_5
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    goto :goto_8

    .line 114
    .restart local v5    # "bad":Ljava/lang/String;
    :cond_6
    :try_start_3
    new-instance v6, Ljava/io/IOException;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "No se pudo guardar "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local v0    # "dest":Ljava/io/File;
    .end local v1    # "part":Ljava/io/File;
    .end local v2    # "error":Ljava/lang/String;
    .end local v3    # "removed":Z
    .end local v4    # "in":Ljava/io/InputStream;
    throw v6

    .line 104
    .end local v5    # "bad":Ljava/lang/String;
    .restart local v0    # "dest":Ljava/io/File;
    .restart local v1    # "part":Ljava/io/File;
    .restart local v2    # "error":Ljava/lang/String;
    .restart local v3    # "removed":Z
    .restart local v4    # "in":Ljava/io/InputStream;
    :cond_7
    new-instance v5, Ljava/io/IOException;

    const-string v6, "No se pudo abrir el archivo elegido."

    invoke-direct {v5, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local v0    # "dest":Ljava/io/File;
    .end local v1    # "part":Ljava/io/File;
    .end local v2    # "error":Ljava/lang/String;
    .end local v3    # "removed":Z
    .end local v4    # "in":Ljava/io/InputStream;
    throw v5
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 130
    .restart local v0    # "dest":Ljava/io/File;
    .restart local v1    # "part":Ljava/io/File;
    .restart local v2    # "error":Ljava/lang/String;
    .restart local v3    # "removed":Z
    .restart local v4    # "in":Ljava/io/InputStream;
    :catchall_0
    move-exception v5

    goto :goto_a

    .line 127
    :catch_2
    move-exception v5

    .line 128
    .local v5, "e":Ljava/lang/Exception;
    :try_start_4
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "No se pudo importar: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    move-object v2, v6

    .line 131
    .end local v5    # "e":Ljava/lang/Exception;
    if-eqz v4, :cond_8

    .line 132
    :try_start_5
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    goto :goto_6

    .line 134
    :catch_3
    move-exception v5

    goto :goto_7

    .line 136
    :cond_8
    :goto_6
    nop

    .line 137
    :goto_7
    if-eqz v1, :cond_9

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v5

    if-eqz v5, :cond_9

    .line 138
    goto :goto_5

    .line 141
    :cond_9
    :goto_8
    if-nez v2, :cond_a

    move-object v5, v0

    goto :goto_9

    :cond_a
    const/4 v5, 0x0

    .line 142
    .local v5, "fDest":Ljava/io/File;
    :goto_9
    move v6, v3

    .line 143
    .local v6, "fRemoved":Z
    move-object v7, v2

    .line 144
    .local v7, "fError":Ljava/lang/String;
    iget-object v8, p0, Lnet/duceng/xmidi/util/Importer$1;->val$act:Landroid/app/Activity;

    new-instance v9, Lnet/duceng/xmidi/util/Importer$1$1;

    invoke-direct {v9, p0, v5, v6, v7}, Lnet/duceng/xmidi/util/Importer$1$1;-><init>(Lnet/duceng/xmidi/util/Importer$1;Ljava/io/File;ZLjava/lang/String;)V

    invoke-virtual {v8, v9}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 157
    return-void

    .line 131
    .end local v5    # "fDest":Ljava/io/File;
    .end local v6    # "fRemoved":Z
    .end local v7    # "fError":Ljava/lang/String;
    :goto_a
    if-eqz v4, :cond_b

    .line 132
    :try_start_6
    invoke-virtual {v4}, Ljava/io/InputStream;->close()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4

    goto :goto_b

    .line 134
    :catch_4
    move-exception v6

    goto :goto_c

    .line 136
    :cond_b
    :goto_b
    nop

    .line 137
    :goto_c
    if-eqz v1, :cond_c

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v6

    if-eqz v6, :cond_c

    .line 138
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    .line 140
    :cond_c
    throw v5
.end method
