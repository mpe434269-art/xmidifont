.class public interface abstract Lnet/duceng/xmidi/util/Importer$Callback;
.super Ljava/lang/Object;
.source "Importer.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/Importer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Callback"
.end annotation


# virtual methods
.method public abstract onResult(Ljava/io/File;ZLjava/lang/String;)V
.end method
