.class public final Lnet/duceng/xmidi/util/Importer;
.super Ljava/lang/Object;
.source "Importer.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/util/Importer$Callback;
    }
.end annotation


# static fields
.field public static final REQ_SF2:I = 0x1006

.field public static final REQ_STY:I = 0x1005


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    return-void
.end method

.method private static displayName(Landroid/app/Activity;Landroid/net/Uri;)Ljava/lang/String;
    .locals 8
    .param p0, "act"    # Landroid/app/Activity;
    .param p1, "uri"    # Landroid/net/Uri;

    .line 43
    const/4 v0, 0x0

    .line 44
    .local v0, "name":Ljava/lang/String;
    const/4 v1, 0x0

    .line 46
    .local v1, "c":Landroid/database/Cursor;
    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const-string v3, "_display_name"

    filled-new-array {v3}, [Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v5, 0x0

    move-object v3, p1

    invoke-virtual/range {v2 .. v7}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    move-object v1, v2

    .line 47
    if-eqz v1, :cond_0

    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 48
    const/4 v2, 0x0

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v0, v2

    .line 53
    :cond_0
    if-eqz v1, :cond_2

    .line 54
    :goto_0
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    goto :goto_1

    .line 53
    :catchall_0
    move-exception v2

    if-eqz v1, :cond_1

    .line 54
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 56
    :cond_1
    throw v2

    .line 50
    :catch_0
    move-exception v2

    .line 53
    if-eqz v1, :cond_2

    .line 54
    goto :goto_0

    .line 57
    :cond_2
    :goto_1
    if-nez v0, :cond_4

    .line 58
    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object v2

    .line 59
    .local v2, "p":Ljava/lang/String;
    if-eqz v2, :cond_4

    .line 60
    const/16 v3, 0x2f

    invoke-virtual {v2, v3}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v3

    .line 61
    .local v3, "i":I
    if-ltz v3, :cond_3

    add-int/lit8 v4, v3, 0x1

    invoke-virtual {v2, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    goto :goto_2

    :cond_3
    move-object v4, v2

    :goto_2
    move-object v0, v4

    .line 64
    .end local v2    # "p":Ljava/lang/String;
    .end local v3    # "i":I
    :cond_4
    return-object v0
.end method

.method public static importAsync(Landroid/app/Activity;Landroid/net/Uri;Ljava/io/File;[Ljava/lang/String;Ljava/lang/String;Lnet/duceng/xmidi/util/Importer$Callback;)V
    .locals 17
    .param p0, "act"    # Landroid/app/Activity;
    .param p1, "uri"    # Landroid/net/Uri;
    .param p2, "dir"    # Ljava/io/File;
    .param p3, "exts"    # [Ljava/lang/String;
    .param p4, "kind"    # Ljava/lang/String;
    .param p5, "cb"    # Lnet/duceng/xmidi/util/Importer$Callback;

    .line 68
    move-object/from16 v9, p0

    invoke-static/range {p0 .. p1}, Lnet/duceng/xmidi/util/Importer;->displayName(Landroid/app/Activity;Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lnet/duceng/xmidi/util/ImportCore;->sanitizeName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    move-object/from16 v0, p4

    invoke-static {v10, v0}, Lnet/duceng/xmidi/util/ImportCore;->styleName(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 69
    .local v10, "name":Ljava/lang/String;
    move-object/from16 v11, p3

    invoke-static {v10, v11}, Lnet/duceng/xmidi/util/ImportCore;->hasExtension(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 70
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Tipo de archivo no valido: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    move-object/from16 v12, p5

    invoke-interface {v12, v2, v1, v0}, Lnet/duceng/xmidi/util/Importer$Callback;->onResult(Ljava/io/File;ZLjava/lang/String;)V

    .line 71
    return-void

    .line 73
    :cond_0
    move-object/from16 v12, p5

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v13, v0

    .line 74
    .local v13, "box":Landroid/widget/LinearLayout;
    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 75
    const/16 v0, 0x10

    invoke-virtual {v13, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 76
    const/16 v0, 0x28

    const/16 v2, 0x1e

    invoke-virtual {v13, v0, v2, v0, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 77
    new-instance v0, Landroid/widget/ProgressBar;

    invoke-direct {v0, v9}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;)V

    invoke-virtual {v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 78
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v9}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v14, v0

    .line 79
    .local v14, "tv":Landroid/widget/TextView;
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "  Importando "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "..."

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v14, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 80
    const/high16 v0, 0x41800000    # 16.0f

    invoke-virtual {v14, v0}, Landroid/widget/TextView;->setTextSize(F)V

    .line 81
    invoke-virtual {v13, v14}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 82
    const/4 v2, 0x0

    .line 84
    .local v2, "tmp":Landroid/app/AlertDialog;
    :try_start_0
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, v9}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, v13}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    move-object v2, v0

    .line 85
    invoke-virtual {v2}, Landroid/app/AlertDialog;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 88
    move-object v0, v2

    goto :goto_0

    .line 86
    :catch_0
    move-exception v0

    .line 87
    .local v0, "e":Ljava/lang/Exception;
    const/4 v2, 0x0

    move-object v0, v2

    .line 89
    .end local v2    # "tmp":Landroid/app/AlertDialog;
    .local v0, "tmp":Landroid/app/AlertDialog;
    :goto_0
    move-object v7, v0

    .line 90
    .local v7, "progress":Landroid/app/AlertDialog;
    new-instance v15, Ljava/lang/Thread;

    new-instance v8, Lnet/duceng/xmidi/util/Importer$1;

    move-object v1, v8

    move-object/from16 v2, p2

    move-object/from16 v3, p0

    move-object/from16 v4, p1

    move-object/from16 v5, p4

    move-object v6, v10

    move-object/from16 v16, v0

    move-object v0, v8

    .end local v0    # "tmp":Landroid/app/AlertDialog;
    .local v16, "tmp":Landroid/app/AlertDialog;
    move-object/from16 v8, p5

    invoke-direct/range {v1 .. v8}, Lnet/duceng/xmidi/util/Importer$1;-><init>(Ljava/io/File;Landroid/app/Activity;Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Landroid/app/AlertDialog;Lnet/duceng/xmidi/util/Importer$Callback;)V

    const-string v1, "XMidi-Import"

    invoke-direct {v15, v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 158
    invoke-virtual {v15}, Ljava/lang/Thread;->start()V

    .line 159
    return-void
.end method

.method public static pickIntent()Landroid/content/Intent;
    .locals 2

    .line 35
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.OPEN_DOCUMENT"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 36
    .local v0, "i":Landroid/content/Intent;
    const-string v1, "android.intent.category.OPENABLE"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 37
    const-string v1, "*/*"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 38
    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 39
    return-object v0
.end method

# Busca la Activity dentro de un contexto envuelto (los dialogos suelen usar ContextThemeWrapper).
.method public static activityOf(Landroid/content/Context;)Landroid/app/Activity;
    .locals 2

    :xm_loop
    instance-of v0, p0, Landroid/app/Activity;

    if-eqz v0, :xm_next

    check-cast p0, Landroid/app/Activity;

    return-object p0

    :xm_next
    instance-of v0, p0, Landroid/content/ContextWrapper;

    if-eqz v0, :xm_none

    check-cast p0, Landroid/content/ContextWrapper;

    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object p0

    goto :xm_loop

    :xm_none
    const/4 v0, 0x0

    return-object v0
.end method
