.class public Lnet/duceng/xmidi/util/MyArray;
.super Landroid/util/SparseArray;
.source "MyArray.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Landroid/util/SparseArray<",
        "TE;>;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 6
    .local p0, "this":Lnet/duceng/xmidi/util/MyArray;, "Lnet/duceng/xmidi/util/MyArray<TE;>;"
    invoke-direct {p0}, Landroid/util/SparseArray;-><init>()V

    return-void
.end method


# virtual methods
.method public indexOfValue(Ljava/lang/Object;)I
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)I"
        }
    .end annotation

    .line 9
    .local p0, "this":Lnet/duceng/xmidi/util/MyArray;, "Lnet/duceng/xmidi/util/MyArray<TE;>;"
    .local p1, "value":Ljava/lang/Object;, "TE;"
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    invoke-virtual {p0}, Lnet/duceng/xmidi/util/MyArray;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    .line 10
    invoke-virtual {p0, v0}, Lnet/duceng/xmidi/util/MyArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 11
    return v0

    .line 9
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 14
    .end local v0    # "i":I
    :cond_1
    const/4 v0, -0x1

    return v0
.end method
