.class public Lnet/duceng/xmidi/util/Rhythm$RChord;
.super Ljava/lang/Object;
.source "Rhythm.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/Rhythm;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4
    name = "RChord"
.end annotation


# instance fields
.field protected chord:[B

.field protected dur:B

.field protected keep:Z

.field protected mod:B

.field final synthetic this$0:Lnet/duceng/xmidi/util/Rhythm;


# direct methods
.method protected constructor <init>(Lnet/duceng/xmidi/util/Rhythm;)V
    .locals 1
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/Rhythm;

    .line 333
    iput-object p1, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->this$0:Lnet/duceng/xmidi/util/Rhythm;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 330
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->keep:Z

    .line 331
    iput-byte v0, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    .line 334
    return-void
.end method

.method protected constructor <init>(Lnet/duceng/xmidi/util/Rhythm;B)V
    .locals 1
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/Rhythm;
    .param p2, "d"    # B

    .line 336
    iput-object p1, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->this$0:Lnet/duceng/xmidi/util/Rhythm;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 330
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->keep:Z

    .line 331
    iput-byte v0, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    .line 337
    iput-byte p2, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    .line 338
    return-void
.end method

.method protected constructor <init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V
    .locals 1
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/Rhythm;
    .param p2, "d"    # B
    .param p3, "c"    # [B

    .line 340
    iput-object p1, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->this$0:Lnet/duceng/xmidi/util/Rhythm;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 330
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->keep:Z

    .line 331
    iput-byte v0, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    .line 341
    iput-byte p2, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    .line 342
    iput-object p3, p0, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    .line 343
    return-void
.end method
