.class public Lnet/duceng/xmidi/util/Rhythm;
.super Ljava/lang/Object;
.source "Rhythm.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/util/Rhythm$RChord;
    }
.end annotation


# instance fields
.field protected beat:B

.field protected chords:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/util/Rhythm$RChord;",
            ">;"
        }
    .end annotation
.end field

.field protected durs:B

.field protected id:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/util/Rhythm;->id:I

    .line 18
    const/4 v0, 0x4

    iput-byte v0, p0, Lnet/duceng/xmidi/util/Rhythm;->beat:B

    .line 19
    iput-byte v0, p0, Lnet/duceng/xmidi/util/Rhythm;->durs:B

    .line 20
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    return-void
.end method

.method public static getDefault()Lnet/duceng/xmidi/util/Rhythm;
    .locals 1

    .line 322
    new-instance v0, Lnet/duceng/xmidi/util/Rhythm;

    invoke-direct {v0}, Lnet/duceng/xmidi/util/Rhythm;-><init>()V

    .line 323
    .local v0, "rhythm":Lnet/duceng/xmidi/util/Rhythm;
    invoke-direct {v0}, Lnet/duceng/xmidi/util/Rhythm;->initDefault()V

    .line 324
    return-object v0
.end method

.method private initDefault()V
    .locals 13

    .line 289
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/util/Rhythm;->id:I

    .line 290
    const/4 v1, 0x4

    iput-byte v1, p0, Lnet/duceng/xmidi/util/Rhythm;->beat:B

    .line 291
    const/16 v2, 0x10

    iput-byte v2, p0, Lnet/duceng/xmidi/util/Rhythm;->durs:B

    .line 292
    new-instance v2, Lnet/duceng/xmidi/util/Rhythm$RChord;

    const/4 v3, 0x1

    new-array v4, v3, [B

    const/4 v5, 0x5

    aput-byte v5, v4, v0

    const/4 v6, 0x2

    invoke-direct {v2, p0, v6, v4}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V

    .line 293
    .local v2, "c":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v4, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 294
    new-instance v4, Lnet/duceng/xmidi/util/Rhythm$RChord;

    new-array v7, v3, [B

    const/4 v8, 0x3

    aput-byte v8, v7, v0

    invoke-direct {v4, p0, v3, v7}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V

    .line 295
    .local v4, "c2":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v7, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 296
    new-instance v7, Lnet/duceng/xmidi/util/Rhythm$RChord;

    new-array v9, v3, [B

    aput-byte v6, v9, v0

    invoke-direct {v7, p0, v3, v9}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V

    .line 297
    .local v7, "c3":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v9, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 298
    new-instance v9, Lnet/duceng/xmidi/util/Rhythm$RChord;

    new-array v10, v0, [B

    invoke-direct {v9, p0, v3, v10}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V

    .line 299
    .local v9, "c4":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iput-boolean v3, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->keep:Z

    .line 300
    iget-object v10, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 301
    new-instance v10, Lnet/duceng/xmidi/util/Rhythm$RChord;

    new-array v11, v3, [B

    aput-byte v3, v11, v0

    invoke-direct {v10, p0, v3, v11}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V

    .line 302
    .local v10, "c5":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v11, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v11, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 303
    new-instance v11, Lnet/duceng/xmidi/util/Rhythm$RChord;

    new-array v12, v3, [B

    aput-byte v8, v12, v0

    invoke-direct {v11, p0, v3, v12}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V

    move-object v0, v11

    .line 304
    .local v0, "c6":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v11, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v11, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 305
    new-instance v11, Lnet/duceng/xmidi/util/Rhythm$RChord;

    new-array v12, v8, [B

    fill-array-data v12, :array_0

    invoke-direct {v11, p0, v3, v12}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V

    .line 306
    .local v11, "c7":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v12, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v12, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 307
    new-instance v12, Lnet/duceng/xmidi/util/Rhythm$RChord;

    new-array v5, v5, [B

    fill-array-data v5, :array_1

    invoke-direct {v12, p0, v1, v5}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V

    move-object v1, v12

    .line 308
    .local v1, "c8":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iput-byte v6, v1, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    .line 309
    iget-object v5, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 310
    new-instance v5, Lnet/duceng/xmidi/util/Rhythm$RChord;

    new-array v12, v8, [B

    fill-array-data v12, :array_2

    invoke-direct {v5, p0, v6, v12}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V

    .line 311
    .local v5, "c9":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iput-byte v3, v5, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    .line 312
    iget-object v6, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 313
    new-instance v6, Lnet/duceng/xmidi/util/Rhythm$RChord;

    new-array v12, v8, [B

    fill-array-data v12, :array_3

    invoke-direct {v6, p0, v3, v12}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V

    .line 314
    .local v6, "c10":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iput-byte v3, v6, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    .line 315
    iget-object v12, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v12, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 316
    new-instance v12, Lnet/duceng/xmidi/util/Rhythm$RChord;

    new-array v8, v8, [B

    fill-array-data v8, :array_4

    invoke-direct {v12, p0, v3, v8}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;B[B)V

    move-object v8, v12

    .line 317
    .local v8, "c11":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iput-byte v3, v8, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    .line 318
    iget-object v3, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 319
    return-void

    nop

    :array_0
    .array-data 1
        0x3t
        0x2t
        0x1t
    .end array-data

    :array_1
    .array-data 1
        0x5t
        0x4t
        0x3t
        0x2t
        0x1t
    .end array-data

    nop

    :array_2
    .array-data 1
        0x6t
        0x5t
        0x4t
    .end array-data

    :array_3
    .array-data 1
        0x3t
        0x2t
        0x1t
    .end array-data

    :array_4
    .array-data 1
        0x1t
        0x2t
        0x3t
    .end array-data
.end method


# virtual methods
.method public addChord()Lnet/duceng/xmidi/util/Rhythm$RChord;
    .locals 2

    .line 55
    new-instance v0, Lnet/duceng/xmidi/util/Rhythm$RChord;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/util/Rhythm$RChord;-><init>(Lnet/duceng/xmidi/util/Rhythm;)V

    .line 56
    .local v0, "c":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v1, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 57
    return-object v0
.end method

.method public draw(Landroid/graphics/Canvas;II)V
    .locals 32
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "w"    # I
    .param p3, "h"    # I

    .line 95
    move-object/from16 v0, p0

    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1}, Landroid/graphics/Paint;-><init>()V

    .line 96
    .local v1, "paint":Landroid/graphics/Paint;
    const/4 v8, 0x1

    invoke-virtual {v1, v8}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 97
    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 98
    const/16 v2, 0xff

    const/16 v3, 0x90

    invoke-static {v2, v3, v3, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 99
    mul-int/lit8 v2, p3, 0xa

    div-int/lit8 v9, v2, 0x30

    mul-int/lit8 v2, p3, 0xf

    div-int/lit8 v10, v2, 0x30

    mul-int/lit8 v2, p3, 0x14

    div-int/lit8 v11, v2, 0x30

    mul-int/lit8 v2, p3, 0x19

    div-int/lit8 v12, v2, 0x30

    mul-int/lit8 v2, p3, 0x1e

    div-int/lit8 v13, v2, 0x30

    mul-int/lit8 v2, p3, 0x23

    div-int/lit8 v14, v2, 0x30

    filled-new-array/range {v9 .. v14}, [I

    move-result-object v2

    move-object v9, v2

    .line 100
    .local v9, "ly":[I
    mul-int/lit8 v2, p3, 0x5

    div-int/lit8 v10, v2, 0x30

    .line 101
    .local v10, "lh":I
    mul-int/lit8 v2, p2, 0x8

    div-int/lit8 v11, v2, 0x60

    .line 102
    .local v11, "lx1":I
    mul-int/lit8 v2, p2, 0x58

    div-int/lit8 v12, v2, 0x60

    .line 103
    .local v12, "lx2":I
    mul-int/lit8 v2, p2, 0x50

    div-int/lit8 v2, v2, 0x60

    iget-object v3, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    div-int v13, v2, v3

    .line 104
    .local v13, "dur_len":I
    div-int/lit8 v2, v13, 0x2

    add-int v14, v11, v2

    .line 105
    .local v14, "dur_x":I
    iget-byte v2, v0, Lnet/duceng/xmidi/util/Rhythm;->durs:B

    iget-byte v3, v0, Lnet/duceng/xmidi/util/Rhythm;->beat:B

    div-int v15, v2, v3

    .line 106
    .local v15, "beat_durs":I
    const/4 v2, 0x0

    move v7, v2

    .local v7, "i":I
    :goto_0
    const/4 v2, 0x6

    if-ge v7, v2, :cond_0

    .line 107
    int-to-float v3, v11

    aget v2, v9, v7

    int-to-float v4, v2

    int-to-float v5, v12

    aget v2, v9, v7

    int-to-float v6, v2

    move-object/from16 v2, p1

    move/from16 v16, v7

    .end local v7    # "i":I
    .local v16, "i":I
    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 106
    add-int/lit8 v7, v16, 0x1

    .end local v16    # "i":I
    .restart local v7    # "i":I
    goto :goto_0

    :cond_0
    move/from16 v16, v7

    .line 109
    .end local v7    # "i":I
    int-to-float v3, v11

    const/16 v16, 0x0

    aget v2, v9, v16

    int-to-float v4, v2

    int-to-float v5, v11

    const/16 v17, 0x5

    aget v2, v9, v17

    int-to-float v6, v2

    move-object/from16 v2, p1

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 110
    int-to-float v3, v12

    aget v2, v9, v16

    int-to-float v4, v2

    int-to-float v5, v12

    aget v2, v9, v17

    int-to-float v6, v2

    move-object/from16 v2, p1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 111
    const/4 v2, 0x0

    .line 112
    .local v2, "dur_n":I
    const/4 v3, 0x0

    .line 113
    .local v3, "lining":Z
    const/4 v4, 0x0

    move/from16 v18, v3

    move v7, v4

    move v6, v14

    move v14, v2

    .line 114
    .end local v2    # "dur_n":I
    .end local v3    # "lining":Z
    .local v6, "dur_x":I
    .local v7, "i2":I
    .local v14, "dur_n":I
    .local v18, "lining":Z
    :goto_1
    iget-object v2, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v7, v2, :cond_16

    .line 115
    iget-object v2, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    move-object v5, v2

    check-cast v5, Lnet/duceng/xmidi/util/Rhythm$RChord;

    .line 116
    .local v5, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    if-lez v7, :cond_1

    iget-object v2, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    add-int/lit8 v3, v7, -0x1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/xmidi/util/Rhythm$RChord;

    goto :goto_2

    :cond_1
    const/4 v2, 0x0

    :goto_2
    move-object v3, v2

    .line 117
    .local v3, "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v2, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    if-ge v7, v2, :cond_2

    iget-object v2, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    add-int/lit8 v4, v7, 0x1

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/xmidi/util/Rhythm$RChord;

    goto :goto_3

    :cond_2
    const/4 v2, 0x0

    :goto_3
    move-object v4, v2

    .line 118
    .local v4, "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-boolean v2, v5, Lnet/duceng/xmidi/util/Rhythm$RChord;->keep:Z

    if-eqz v2, :cond_3

    .line 119
    iget-object v2, v3, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    iput-object v2, v5, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    .line 120
    iget-byte v2, v3, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    iput-byte v2, v5, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    .line 122
    :cond_3
    iget-object v2, v5, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v2, v2, v16

    iget-object v8, v5, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    move-object/from16 v21, v3

    .end local v3    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v21, "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v3, v5, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    array-length v3, v3

    const/16 v20, 0x1

    add-int/lit8 v3, v3, -0x1

    aget-byte v3, v8, v3

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v8

    .line 123
    .local v8, "lmax":I
    iget-object v2, v5, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v2, v2, v16

    iget-object v3, v5, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    move-object/from16 v22, v4

    .end local v4    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v22, "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v4, v5, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    array-length v4, v4

    add-int/lit8 v4, v4, -0x1

    aget-byte v3, v3, v4

    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v23

    .line 124
    .local v23, "lmin":I
    iget-boolean v2, v5, Lnet/duceng/xmidi/util/Rhythm$RChord;->keep:Z

    if-eqz v2, :cond_4

    .line 125
    new-instance v3, Landroid/graphics/RectF;

    sub-int v2, v6, v13

    int-to-float v2, v2

    add-int/lit8 v4, v23, -0x1

    aget v4, v9, v4

    mul-int/lit8 v24, v13, 0x2

    div-int/lit8 v24, v24, 0x3

    sub-int v4, v4, v24

    int-to-float v4, v4

    move-object/from16 v24, v5

    .end local v5    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v24, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    int-to-float v5, v6

    add-int/lit8 v25, v23, -0x1

    aget v25, v9, v25

    mul-int/lit8 v26, v13, 0x1

    div-int/lit8 v26, v26, 0x3

    move/from16 v27, v6

    .end local v6    # "dur_x":I
    .local v27, "dur_x":I
    add-int v6, v25, v26

    int-to-float v6, v6

    invoke-direct {v3, v2, v4, v5, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v5, 0x43160000    # 150.0f

    const/4 v6, 0x0

    const/high16 v4, 0x43430000    # 195.0f

    move-object/from16 v2, p1

    move-object/from16 v28, v21

    .end local v21    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v28, "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    move-object/from16 v29, v22

    .end local v22    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v29, "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    move-object/from16 v30, v24

    .end local v24    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v30, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    move/from16 v31, v27

    .end local v27    # "dur_x":I
    .local v31, "dur_x":I
    move/from16 v19, v11

    move v11, v7

    .end local v7    # "i2":I
    .local v11, "i2":I
    .local v19, "lx1":I
    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    goto :goto_4

    .line 124
    .end local v19    # "lx1":I
    .end local v28    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v29    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v30    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v31    # "dur_x":I
    .restart local v5    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v6    # "dur_x":I
    .restart local v7    # "i2":I
    .local v11, "lx1":I
    .restart local v21    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v22    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_4
    move-object/from16 v30, v5

    move/from16 v31, v6

    move/from16 v19, v11

    move-object/from16 v28, v21

    move-object/from16 v29, v22

    move v11, v7

    .line 127
    .end local v5    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v6    # "dur_x":I
    .end local v7    # "i2":I
    .end local v21    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v22    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v11, "i2":I
    .restart local v19    # "lx1":I
    .restart local v28    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v29    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v30    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v31    # "dur_x":I
    :goto_4
    const/4 v2, 0x0

    move v7, v2

    .local v7, "c":I
    :goto_5
    move-object/from16 v6, v30

    .end local v30    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v6, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v2, v6, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    array-length v2, v2

    const/4 v5, 0x2

    if-ge v7, v2, :cond_a

    .line 128
    iget-byte v2, v6, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    if-nez v2, :cond_5

    .line 129
    div-int/lit8 v2, v10, 0x2

    move/from16 v5, v31

    .end local v31    # "dur_x":I
    .local v5, "dur_x":I
    sub-int v2, v5, v2

    int-to-float v3, v2

    iget-object v2, v6, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v2, v2, v7

    const/4 v4, 0x1

    sub-int/2addr v2, v4

    aget v2, v9, v2

    div-int/lit8 v4, v10, 0x2

    sub-int/2addr v2, v4

    int-to-float v4, v2

    div-int/lit8 v2, v10, 0x2

    add-int/2addr v2, v5

    int-to-float v2, v2

    move/from16 v21, v2

    iget-object v2, v6, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v2, v2, v7

    const/16 v20, 0x1

    add-int/lit8 v2, v2, -0x1

    aget v2, v9, v2

    div-int/lit8 v22, v10, 0x2

    add-int v2, v2, v22

    int-to-float v2, v2

    move/from16 v22, v2

    move-object/from16 v2, p1

    move/from16 v24, v12

    move v12, v5

    .end local v5    # "dur_x":I
    .local v12, "dur_x":I
    .local v24, "lx2":I
    move/from16 v5, v21

    move/from16 v21, v13

    move-object v13, v6

    .end local v6    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v13, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v21, "dur_len":I
    move/from16 v6, v22

    move/from16 v22, v7

    .end local v7    # "c":I
    .local v22, "c":I
    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 130
    div-int/lit8 v2, v10, 0x2

    sub-int v6, v12, v2

    int-to-float v3, v6

    iget-object v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v2, v2, v22

    const/4 v4, 0x1

    sub-int/2addr v2, v4

    aget v2, v9, v2

    div-int/lit8 v4, v10, 0x2

    add-int/2addr v2, v4

    int-to-float v4, v2

    div-int/lit8 v2, v10, 0x2

    add-int/2addr v2, v12

    int-to-float v5, v2

    iget-object v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v2, v2, v22

    const/4 v6, 0x1

    sub-int/2addr v2, v6

    aget v2, v9, v2

    div-int/lit8 v6, v10, 0x2

    sub-int/2addr v2, v6

    int-to-float v6, v2

    move-object/from16 v2, p1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const/16 v25, 0x0

    goto/16 :goto_8

    .line 131
    .end local v21    # "dur_len":I
    .end local v22    # "c":I
    .end local v24    # "lx2":I
    .restart local v6    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v7    # "c":I
    .local v12, "lx2":I
    .local v13, "dur_len":I
    .restart local v31    # "dur_x":I
    :cond_5
    move/from16 v22, v7

    move/from16 v24, v12

    move/from16 v21, v13

    move/from16 v12, v31

    move-object v13, v6

    .end local v6    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v7    # "c":I
    .end local v31    # "dur_x":I
    .local v12, "dur_x":I
    .local v13, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v21    # "dur_len":I
    .restart local v22    # "c":I
    .restart local v24    # "lx2":I
    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    const/4 v3, 0x1

    if-eq v2, v3, :cond_7

    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    if-ne v2, v5, :cond_6

    goto :goto_6

    :cond_6
    const/16 v25, 0x0

    goto/16 :goto_8

    .line 132
    :cond_7
    :goto_6
    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    if-ne v2, v5, :cond_8

    .line 133
    new-instance v2, Landroid/graphics/DashPathEffect;

    new-array v3, v5, [F

    fill-array-data v3, :array_0

    const/4 v4, 0x0

    invoke-direct {v2, v3, v4}, Landroid/graphics/DashPathEffect;-><init>([FF)V

    .line 134
    .local v2, "effects":Landroid/graphics/PathEffect;
    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    .line 135
    new-instance v3, Landroid/graphics/Path;

    invoke-direct {v3}, Landroid/graphics/Path;-><init>()V

    .line 136
    .local v3, "p":Landroid/graphics/Path;
    int-to-float v4, v12

    add-int/lit8 v5, v23, -0x1

    aget v5, v9, v5

    const/4 v6, 0x1

    sub-int/2addr v5, v6

    int-to-float v5, v5

    invoke-virtual {v3, v4, v5}, Landroid/graphics/Path;->moveTo(FF)V

    .line 137
    int-to-float v4, v12

    add-int/lit8 v5, v8, -0x1

    aget v5, v9, v5

    add-int/2addr v5, v6

    int-to-float v5, v5

    invoke-virtual {v3, v4, v5}, Landroid/graphics/Path;->lineTo(FF)V

    .line 138
    move-object/from16 v7, p1

    invoke-virtual {v7, v3, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 139
    const/4 v6, 0x0

    invoke-virtual {v1, v6}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    .line 140
    .end local v2    # "effects":Landroid/graphics/PathEffect;
    .end local v3    # "p":Landroid/graphics/Path;
    move-object/from16 v25, v6

    goto :goto_7

    .line 141
    :cond_8
    move-object/from16 v7, p1

    const/4 v6, 0x0

    int-to-float v3, v12

    add-int/lit8 v2, v23, -0x1

    aget v2, v9, v2

    const/4 v4, 0x1

    sub-int/2addr v2, v4

    int-to-float v5, v2

    int-to-float v2, v12

    add-int/lit8 v20, v8, -0x1

    aget v20, v9, v20

    add-int/lit8 v6, v20, 0x1

    int-to-float v6, v6

    move/from16 v25, v2

    move-object/from16 v2, p1

    move v4, v5

    move/from16 v5, v25

    const/16 v25, 0x0

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 143
    :goto_7
    iget-object v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v2, v2, v16

    iget-object v3, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    iget-object v4, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    array-length v4, v4

    const/4 v5, 0x1

    sub-int/2addr v4, v5

    aget-byte v3, v3, v4

    if-le v2, v3, :cond_9

    .line 144
    div-int/lit8 v2, v10, 0x2

    sub-int v6, v12, v2

    int-to-float v3, v6

    add-int/lit8 v2, v23, -0x1

    aget v2, v9, v2

    sub-int/2addr v2, v5

    div-int/lit8 v4, v10, 0x2

    add-int/2addr v2, v4

    int-to-float v4, v2

    int-to-float v6, v12

    add-int/lit8 v2, v23, -0x1

    aget v2, v9, v2

    sub-int/2addr v2, v5

    int-to-float v7, v2

    move-object/from16 v2, p1

    move v5, v6

    move v6, v7

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 145
    int-to-float v3, v12

    add-int/lit8 v2, v23, -0x1

    aget v2, v9, v2

    const/4 v4, 0x1

    sub-int/2addr v2, v4

    int-to-float v5, v2

    div-int/lit8 v2, v10, 0x2

    add-int/2addr v2, v12

    int-to-float v6, v2

    add-int/lit8 v2, v23, -0x1

    aget v2, v9, v2

    sub-int/2addr v2, v4

    div-int/lit8 v4, v10, 0x2

    add-int/2addr v2, v4

    int-to-float v7, v2

    move-object/from16 v2, p1

    move v4, v5

    move v5, v6

    move v6, v7

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_8

    .line 147
    :cond_9
    div-int/lit8 v2, v10, 0x2

    sub-int v6, v12, v2

    int-to-float v3, v6

    add-int/lit8 v2, v8, -0x1

    aget v2, v9, v2

    const/4 v4, 0x1

    add-int/2addr v2, v4

    div-int/lit8 v5, v10, 0x2

    sub-int/2addr v2, v5

    int-to-float v5, v2

    int-to-float v6, v12

    add-int/lit8 v2, v8, -0x1

    aget v2, v9, v2

    add-int/2addr v2, v4

    int-to-float v7, v2

    move-object/from16 v2, p1

    move v4, v5

    move v5, v6

    move v6, v7

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 148
    int-to-float v3, v12

    add-int/lit8 v2, v8, -0x1

    aget v2, v9, v2

    const/4 v4, 0x1

    add-int/2addr v2, v4

    int-to-float v5, v2

    div-int/lit8 v2, v10, 0x2

    add-int/2addr v2, v12

    int-to-float v6, v2

    add-int/lit8 v2, v8, -0x1

    aget v2, v9, v2

    add-int/2addr v2, v4

    div-int/lit8 v4, v10, 0x2

    sub-int/2addr v2, v4

    int-to-float v7, v2

    move-object/from16 v2, p1

    move v4, v5

    move v5, v6

    move v6, v7

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 127
    :goto_8
    add-int/lit8 v7, v22, 0x1

    move/from16 v31, v12

    move-object/from16 v30, v13

    move/from16 v13, v21

    move/from16 v12, v24

    .end local v22    # "c":I
    .restart local v7    # "c":I
    goto/16 :goto_5

    .end local v21    # "dur_len":I
    .end local v24    # "lx2":I
    .restart local v6    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v12, "lx2":I
    .local v13, "dur_len":I
    .restart local v31    # "dur_x":I
    :cond_a
    move/from16 v22, v7

    move/from16 v24, v12

    move/from16 v21, v13

    move/from16 v12, v31

    move-object v13, v6

    .line 152
    .end local v6    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v7    # "c":I
    .end local v31    # "dur_x":I
    .local v12, "dur_x":I
    .local v13, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v21    # "dur_len":I
    .restart local v24    # "lx2":I
    int-to-float v3, v12

    add-int/lit8 v2, v8, -0x1

    aget v2, v9, v2

    mul-int/lit8 v4, v10, 0x2

    div-int/lit8 v4, v4, 0x3

    add-int/2addr v2, v4

    int-to-float v4, v2

    int-to-float v6, v12

    aget v2, v9, v17

    add-int/2addr v2, v10

    int-to-float v7, v2

    move-object/from16 v2, p1

    const/16 v22, 0x2

    move v5, v6

    move v6, v7

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 153
    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    add-int/2addr v14, v2

    .line 154
    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    if-ge v2, v15, :cond_15

    .line 155
    rem-int v2, v14, v15

    if-eqz v2, :cond_10

    .line 156
    iget-object v2, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v20, 0x1

    add-int/lit8 v2, v2, -0x1

    if-ge v11, v2, :cond_f

    .line 157
    move-object/from16 v7, v29

    .end local v29    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v7, "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-byte v2, v7, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    if-gt v2, v15, :cond_d

    .line 158
    int-to-float v3, v12

    aget v2, v9, v17

    add-int/2addr v2, v10

    int-to-float v4, v2

    add-int v6, v12, v21

    int-to-float v5, v6

    aget v2, v9, v17

    add-int/2addr v2, v10

    int-to-float v6, v2

    move-object/from16 v2, p1

    move-object v0, v7

    .end local v7    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v0, "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 159
    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    mul-int/lit8 v2, v2, 0x2

    if-ge v2, v15, :cond_c

    .line 160
    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    iget-byte v3, v0, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    if-ne v2, v3, :cond_b

    .line 161
    int-to-float v3, v12

    aget v2, v9, v17

    add-int/2addr v2, v10

    mul-int/lit8 v4, v10, 0x2

    div-int/lit8 v4, v4, 0x5

    sub-int/2addr v2, v4

    int-to-float v4, v2

    add-int v6, v12, v21

    int-to-float v5, v6

    aget v2, v9, v17

    add-int/2addr v2, v10

    mul-int/lit8 v6, v10, 0x2

    div-int/lit8 v6, v6, 0x5

    sub-int/2addr v2, v6

    int-to-float v6, v2

    move-object/from16 v2, p1

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_9

    .line 162
    :cond_b
    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    iget-byte v3, v0, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    if-ge v2, v3, :cond_c

    .line 163
    int-to-float v3, v12

    aget v2, v9, v17

    add-int/2addr v2, v10

    mul-int/lit8 v4, v10, 0x2

    div-int/lit8 v4, v4, 0x5

    sub-int/2addr v2, v4

    int-to-float v4, v2

    div-int/lit8 v2, v21, 0x3

    add-int/2addr v2, v12

    int-to-float v5, v2

    aget v2, v9, v17

    add-int/2addr v2, v10

    mul-int/lit8 v6, v10, 0x2

    div-int/lit8 v6, v6, 0x5

    sub-int/2addr v2, v6

    int-to-float v6, v2

    move-object/from16 v2, p1

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 166
    :cond_c
    :goto_9
    const/4 v2, 0x1

    move/from16 v18, v2

    move-object/from16 v22, v28

    .end local v18    # "lining":Z
    .local v2, "lining":Z
    goto/16 :goto_b

    .line 168
    .end local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v2    # "lining":Z
    .restart local v7    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v18    # "lining":Z
    :cond_d
    move-object v0, v7

    .end local v7    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    int-to-float v3, v12

    aget v2, v9, v17

    add-int/2addr v2, v10

    int-to-float v4, v2

    div-int/lit8 v2, v10, 0x2

    add-int/2addr v2, v12

    int-to-float v5, v2

    aget v2, v9, v17

    add-int/2addr v2, v10

    div-int/lit8 v6, v10, 0x2

    sub-int/2addr v2, v6

    int-to-float v6, v2

    move-object/from16 v2, p1

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 169
    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    mul-int/lit8 v2, v2, 0x2

    if-ge v2, v15, :cond_e

    .line 170
    int-to-float v3, v12

    aget v2, v9, v17

    add-int/2addr v2, v10

    mul-int/lit8 v4, v10, 0x2

    div-int/lit8 v4, v4, 0x5

    sub-int/2addr v2, v4

    int-to-float v4, v2

    div-int/lit8 v2, v10, 0x2

    add-int/2addr v2, v12

    int-to-float v5, v2

    aget v2, v9, v17

    add-int/2addr v2, v10

    div-int/lit8 v6, v10, 0x2

    sub-int/2addr v2, v6

    mul-int/lit8 v6, v10, 0x2

    div-int/lit8 v6, v6, 0x5

    sub-int/2addr v2, v6

    int-to-float v6, v2

    move-object/from16 v2, p1

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move-object/from16 v22, v28

    goto/16 :goto_b

    .line 169
    :cond_e
    move-object/from16 v22, v28

    goto/16 :goto_b

    .line 156
    .end local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v29    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_f
    move-object/from16 v0, v29

    .end local v29    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    move-object/from16 v22, v28

    goto/16 :goto_b

    .line 175
    .end local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v29    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_10
    move-object/from16 v0, v29

    const/16 v20, 0x1

    .end local v29    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    if-nez v18, :cond_12

    .line 176
    int-to-float v3, v12

    aget v2, v9, v17

    add-int/2addr v2, v10

    int-to-float v4, v2

    div-int/lit8 v2, v10, 0x2

    add-int/2addr v2, v12

    int-to-float v5, v2

    aget v2, v9, v17

    add-int/2addr v2, v10

    div-int/lit8 v6, v10, 0x2

    sub-int/2addr v2, v6

    int-to-float v6, v2

    move-object/from16 v2, p1

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 177
    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    mul-int/lit8 v2, v2, 0x2

    if-ge v2, v15, :cond_11

    .line 178
    int-to-float v3, v12

    aget v2, v9, v17

    add-int/2addr v2, v10

    mul-int/lit8 v4, v10, 0x2

    div-int/lit8 v4, v4, 0x5

    sub-int/2addr v2, v4

    int-to-float v4, v2

    div-int/lit8 v2, v10, 0x2

    add-int/2addr v2, v12

    int-to-float v5, v2

    aget v2, v9, v17

    add-int/2addr v2, v10

    div-int/lit8 v6, v10, 0x2

    sub-int/2addr v2, v6

    mul-int/lit8 v6, v10, 0x2

    div-int/lit8 v6, v6, 0x5

    sub-int/2addr v2, v6

    int-to-float v6, v2

    move-object/from16 v2, p1

    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move-object/from16 v22, v28

    goto :goto_a

    .line 177
    :cond_11
    move-object/from16 v22, v28

    goto :goto_a

    .line 180
    :cond_12
    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    mul-int/lit8 v2, v2, 0x2

    if-ge v2, v15, :cond_14

    iget-byte v2, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    move-object/from16 v7, v28

    .end local v28    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v7, "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-byte v3, v7, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    if-ge v2, v3, :cond_13

    .line 181
    int-to-float v3, v12

    aget v2, v9, v17

    add-int/2addr v2, v10

    mul-int/lit8 v4, v10, 0x2

    div-int/lit8 v4, v4, 0x5

    sub-int/2addr v2, v4

    int-to-float v4, v2

    div-int/lit8 v2, v21, 0x3

    sub-int v6, v12, v2

    int-to-float v5, v6

    aget v2, v9, v17

    add-int/2addr v2, v10

    mul-int/lit8 v6, v10, 0x2

    div-int/lit8 v6, v6, 0x5

    sub-int/2addr v2, v6

    int-to-float v6, v2

    move-object/from16 v2, p1

    move-object/from16 v22, v7

    .end local v7    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v22, "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    move-object v7, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_a

    .line 180
    .end local v22    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v7    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_13
    move-object/from16 v22, v7

    .end local v7    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v22    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    goto :goto_a

    .end local v22    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v28    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_14
    move-object/from16 v22, v28

    .line 183
    .end local v28    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v22    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :goto_a
    const/4 v2, 0x0

    move/from16 v18, v2

    .end local v18    # "lining":Z
    .restart local v2    # "lining":Z
    goto :goto_b

    .line 154
    .end local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v2    # "lining":Z
    .end local v22    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v18    # "lining":Z
    .restart local v28    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v29    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_15
    move-object/from16 v22, v28

    move-object/from16 v0, v29

    const/16 v20, 0x1

    .line 186
    .end local v28    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v29    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v22    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :goto_b
    add-int v6, v12, v21

    .line 187
    .end local v12    # "dur_x":I
    .local v6, "dur_x":I
    nop

    .end local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v8    # "lmax":I
    .end local v13    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v22    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v23    # "lmin":I
    add-int/lit8 v7, v11, 0x1

    .line 188
    .end local v11    # "i2":I
    .local v7, "i2":I
    move-object/from16 v0, p0

    move/from16 v11, v19

    move/from16 v13, v21

    move/from16 v12, v24

    const/4 v8, 0x1

    goto/16 :goto_1

    .line 189
    .end local v19    # "lx1":I
    .end local v21    # "dur_len":I
    .end local v24    # "lx2":I
    .local v11, "lx1":I
    .local v12, "lx2":I
    .local v13, "dur_len":I
    :cond_16
    return-void

    :array_0
    .array-data 4
        0x40800000    # 4.0f
        0x40800000    # 4.0f
    .end array-data
.end method

.method public getBeat()B
    .locals 1

    .line 31
    iget-byte v0, p0, Lnet/duceng/xmidi/util/Rhythm;->beat:B

    return v0
.end method

.method public getBitmap(II)Landroid/graphics/Bitmap;
    .locals 34
    .param p1, "w"    # I
    .param p2, "h"    # I

    .line 192
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v1, v2, v3}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v3

    .line 193
    .local v3, "bitmap":Landroid/graphics/Bitmap;
    new-instance v4, Landroid/graphics/Paint;

    invoke-direct {v4}, Landroid/graphics/Paint;-><init>()V

    .line 194
    .local v4, "paint":Landroid/graphics/Paint;
    new-instance v5, Landroid/graphics/Canvas;

    invoke-direct {v5, v3}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 195
    .local v5, "canvas":Landroid/graphics/Canvas;
    const/4 v12, 0x1

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 196
    sget-object v6, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 197
    const/16 v6, 0xff

    const/16 v7, 0x90

    invoke-static {v6, v7, v7, v7}, Landroid/graphics/Color;->argb(IIII)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 198
    mul-int/lit8 v6, v2, 0xa

    div-int/lit8 v13, v6, 0x30

    mul-int/lit8 v6, v2, 0xf

    div-int/lit8 v14, v6, 0x30

    mul-int/lit8 v6, v2, 0x14

    div-int/lit8 v15, v6, 0x30

    mul-int/lit8 v6, v2, 0x19

    div-int/lit8 v16, v6, 0x30

    mul-int/lit8 v6, v2, 0x1e

    div-int/lit8 v17, v6, 0x30

    mul-int/lit8 v6, v2, 0x23

    div-int/lit8 v18, v6, 0x30

    filled-new-array/range {v13 .. v18}, [I

    move-result-object v6

    move-object v13, v6

    .line 199
    .local v13, "ly":[I
    mul-int/lit8 v6, v2, 0x5

    div-int/lit8 v14, v6, 0x30

    .line 200
    .local v14, "lh":I
    mul-int/lit8 v6, v1, 0x8

    div-int/lit8 v15, v6, 0x60

    .line 201
    .local v15, "lx1":I
    mul-int/lit8 v6, v1, 0x58

    div-int/lit8 v11, v6, 0x60

    .line 202
    .local v11, "lx2":I
    mul-int/lit8 v6, v1, 0x50

    div-int/lit8 v6, v6, 0x60

    iget-object v7, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    div-int v16, v6, v7

    .line 203
    .local v16, "dur_len":I
    div-int/lit8 v6, v16, 0x2

    add-int v17, v15, v6

    .line 204
    .local v17, "dur_x":I
    iget-byte v6, v0, Lnet/duceng/xmidi/util/Rhythm;->durs:B

    iget-byte v7, v0, Lnet/duceng/xmidi/util/Rhythm;->beat:B

    div-int v10, v6, v7

    .line 205
    .local v10, "beat_durs":I
    const/4 v6, 0x0

    move v9, v6

    .local v9, "i":I
    :goto_0
    const/4 v6, 0x6

    if-ge v9, v6, :cond_0

    .line 206
    int-to-float v6, v15

    aget v7, v13, v9

    int-to-float v7, v7

    int-to-float v8, v11

    aget v12, v13, v9

    int-to-float v12, v12

    move/from16 v19, v9

    .end local v9    # "i":I
    .local v19, "i":I
    move v9, v12

    move v12, v10

    .end local v10    # "beat_durs":I
    .local v12, "beat_durs":I
    move-object v10, v4

    invoke-virtual/range {v5 .. v10}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 205
    add-int/lit8 v9, v19, 0x1

    move v10, v12

    const/4 v12, 0x1

    .end local v19    # "i":I
    .restart local v9    # "i":I
    goto :goto_0

    .end local v12    # "beat_durs":I
    .restart local v10    # "beat_durs":I
    :cond_0
    move/from16 v19, v9

    move v12, v10

    .line 208
    .end local v9    # "i":I
    .end local v10    # "beat_durs":I
    .restart local v12    # "beat_durs":I
    int-to-float v7, v15

    const/16 v19, 0x0

    aget v6, v13, v19

    int-to-float v8, v6

    int-to-float v9, v15

    const/16 v20, 0x5

    aget v6, v13, v20

    int-to-float v10, v6

    move-object v6, v5

    move v1, v11

    .end local v11    # "lx2":I
    .local v1, "lx2":I
    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 209
    int-to-float v7, v1

    aget v6, v13, v19

    int-to-float v8, v6

    int-to-float v9, v1

    aget v6, v13, v20

    int-to-float v10, v6

    move-object v6, v5

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 210
    const/4 v6, 0x0

    .line 211
    .local v6, "dur_n":I
    const/4 v7, 0x0

    .line 212
    .local v7, "lining":Z
    const/4 v8, 0x0

    move/from16 v21, v7

    move v11, v8

    move/from16 v10, v17

    move/from16 v17, v6

    .line 213
    .end local v6    # "dur_n":I
    .end local v7    # "lining":Z
    .local v10, "dur_x":I
    .local v11, "i2":I
    .local v17, "dur_n":I
    .local v21, "lining":Z
    :goto_1
    iget-object v6, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v11, v6, :cond_17

    .line 214
    iget-object v6, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v6, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    move-object v9, v6

    check-cast v9, Lnet/duceng/xmidi/util/Rhythm$RChord;

    .line 215
    .local v9, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    if-lez v11, :cond_1

    iget-object v6, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    add-int/lit8 v7, v11, -0x1

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/util/Rhythm$RChord;

    goto :goto_2

    :cond_1
    const/4 v6, 0x0

    :goto_2
    move-object v7, v6

    .line 216
    .local v7, "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v6, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    add-int/lit8 v6, v6, -0x1

    if-ge v11, v6, :cond_2

    iget-object v6, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    add-int/lit8 v8, v11, 0x1

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/util/Rhythm$RChord;

    goto :goto_3

    :cond_2
    const/4 v6, 0x0

    :goto_3
    move-object v8, v6

    .line 217
    .local v8, "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-boolean v6, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->keep:Z

    if-eqz v6, :cond_3

    .line 218
    iget-object v6, v7, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    iput-object v6, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    .line 219
    iget-byte v6, v7, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    iput-byte v6, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    .line 221
    :cond_3
    iget-object v6, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v6, v6, v19

    move/from16 v23, v1

    .end local v1    # "lx2":I
    .local v23, "lx2":I
    iget-object v1, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    iget-object v2, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    array-length v2, v2

    const/16 v18, 0x1

    add-int/lit8 v2, v2, -0x1

    aget-byte v1, v1, v2

    invoke-static {v6, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 222
    .local v1, "lmax":I
    iget-object v2, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v2, v2, v19

    iget-object v6, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    move-object/from16 v24, v7

    .end local v7    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v24, "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v7, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    array-length v7, v7

    add-int/lit8 v7, v7, -0x1

    aget-byte v6, v6, v7

    invoke-static {v2, v6}, Ljava/lang/Math;->min(II)I

    move-result v2

    .line 223
    .local v2, "lmin":I
    iget-boolean v6, v9, Lnet/duceng/xmidi/util/Rhythm$RChord;->keep:Z

    if-eqz v6, :cond_4

    .line 224
    new-instance v7, Landroid/graphics/RectF;

    sub-int v6, v10, v16

    int-to-float v6, v6

    add-int/lit8 v25, v2, -0x1

    aget v25, v13, v25

    mul-int/lit8 v26, v16, 0x2

    div-int/lit8 v26, v26, 0x3

    move-object/from16 v27, v8

    .end local v8    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v27, "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    sub-int v8, v25, v26

    int-to-float v8, v8

    move-object/from16 v25, v9

    .end local v9    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v25, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    int-to-float v9, v10

    add-int/lit8 v26, v2, -0x1

    aget v26, v13, v26

    mul-int/lit8 v28, v16, 0x1

    div-int/lit8 v28, v28, 0x3

    move/from16 v29, v10

    .end local v10    # "dur_x":I
    .local v29, "dur_x":I
    add-int v10, v26, v28

    int-to-float v10, v10

    invoke-direct {v7, v6, v8, v9, v10}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v9, 0x43160000    # 150.0f

    const/4 v10, 0x0

    const/high16 v8, 0x43430000    # 195.0f

    move-object v6, v5

    move-object/from16 v30, v24

    .end local v24    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v30, "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    move-object/from16 v31, v27

    .end local v27    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v31, "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    move-object/from16 v32, v25

    .end local v25    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v32, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    move/from16 v33, v29

    .end local v29    # "dur_x":I
    .local v33, "dur_x":I
    move/from16 v22, v15

    move v15, v11

    .end local v11    # "i2":I
    .local v15, "i2":I
    .local v22, "lx1":I
    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    goto :goto_4

    .line 223
    .end local v22    # "lx1":I
    .end local v30    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v31    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v32    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v33    # "dur_x":I
    .restart local v8    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v9    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v10    # "dur_x":I
    .restart local v11    # "i2":I
    .local v15, "lx1":I
    .restart local v24    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_4
    move-object/from16 v31, v8

    move-object/from16 v32, v9

    move/from16 v33, v10

    move/from16 v22, v15

    move-object/from16 v30, v24

    move v15, v11

    .line 226
    .end local v8    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v9    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v10    # "dur_x":I
    .end local v11    # "i2":I
    .end local v24    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v15, "i2":I
    .restart local v22    # "lx1":I
    .restart local v30    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v31    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v32    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v33    # "dur_x":I
    :goto_4
    const/4 v6, 0x0

    move v11, v6

    .local v11, "c":I
    :goto_5
    move-object/from16 v10, v32

    .end local v32    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v10, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-object v6, v10, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    array-length v6, v6

    const/4 v9, 0x2

    if-ge v11, v6, :cond_b

    .line 227
    iget-byte v6, v10, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    if-nez v6, :cond_5

    .line 228
    div-int/lit8 v6, v14, 0x2

    move/from16 v9, v33

    .end local v33    # "dur_x":I
    .local v9, "dur_x":I
    sub-int v6, v9, v6

    int-to-float v7, v6

    iget-object v6, v10, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v6, v6, v11

    const/4 v8, 0x1

    sub-int/2addr v6, v8

    aget v6, v13, v6

    div-int/lit8 v8, v14, 0x2

    sub-int/2addr v6, v8

    int-to-float v8, v6

    div-int/lit8 v6, v14, 0x2

    add-int/2addr v6, v9

    int-to-float v6, v6

    move/from16 v24, v6

    iget-object v6, v10, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v6, v6, v11

    const/16 v18, 0x1

    add-int/lit8 v6, v6, -0x1

    aget v6, v13, v6

    div-int/lit8 v25, v14, 0x2

    add-int v6, v6, v25

    int-to-float v6, v6

    move/from16 v25, v6

    move-object v6, v5

    move-object/from16 v26, v3

    move v3, v9

    .end local v9    # "dur_x":I
    .local v3, "dur_x":I
    .local v26, "bitmap":Landroid/graphics/Bitmap;
    move/from16 v9, v24

    move/from16 v24, v15

    move-object v15, v10

    .end local v10    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v15, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v24, "i2":I
    move/from16 v10, v25

    move/from16 v25, v11

    .end local v11    # "c":I
    .local v25, "c":I
    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 229
    div-int/lit8 v6, v14, 0x2

    sub-int v10, v3, v6

    int-to-float v7, v10

    iget-object v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v6, v6, v25

    const/4 v8, 0x1

    sub-int/2addr v6, v8

    aget v6, v13, v6

    div-int/lit8 v8, v14, 0x2

    add-int/2addr v6, v8

    int-to-float v8, v6

    div-int/lit8 v6, v14, 0x2

    add-int/2addr v6, v3

    int-to-float v9, v6

    iget-object v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v6, v6, v25

    const/4 v10, 0x1

    sub-int/2addr v6, v10

    aget v6, v13, v6

    div-int/lit8 v10, v14, 0x2

    sub-int/2addr v6, v10

    int-to-float v10, v6

    move-object v6, v5

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const/4 v0, 0x0

    goto/16 :goto_8

    .line 230
    .end local v24    # "i2":I
    .end local v25    # "c":I
    .end local v26    # "bitmap":Landroid/graphics/Bitmap;
    .local v3, "bitmap":Landroid/graphics/Bitmap;
    .restart local v10    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v11    # "c":I
    .local v15, "i2":I
    .restart local v33    # "dur_x":I
    :cond_5
    move-object/from16 v26, v3

    move/from16 v25, v11

    move/from16 v24, v15

    move/from16 v3, v33

    move-object v15, v10

    .end local v10    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v11    # "c":I
    .end local v33    # "dur_x":I
    .local v3, "dur_x":I
    .local v15, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v24    # "i2":I
    .restart local v25    # "c":I
    .restart local v26    # "bitmap":Landroid/graphics/Bitmap;
    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    const/4 v7, 0x1

    if-eq v6, v7, :cond_7

    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    if-ne v6, v9, :cond_6

    goto :goto_6

    :cond_6
    const/4 v0, 0x0

    goto/16 :goto_8

    .line 231
    :cond_7
    :goto_6
    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    if-ne v6, v9, :cond_8

    .line 232
    new-instance v6, Landroid/graphics/DashPathEffect;

    new-array v7, v9, [F

    fill-array-data v7, :array_0

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v6, v7, v8}, Landroid/graphics/DashPathEffect;-><init>([FF)V

    .line 233
    .local v6, "effects":Landroid/graphics/PathEffect;
    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    .line 235
    .end local v6    # "effects":Landroid/graphics/PathEffect;
    :cond_8
    int-to-float v7, v3

    add-int/lit8 v6, v2, -0x1

    aget v6, v13, v6

    const/4 v8, 0x1

    sub-int/2addr v6, v8

    int-to-float v10, v6

    int-to-float v11, v3

    add-int/lit8 v6, v1, -0x1

    aget v6, v13, v6

    add-int/2addr v6, v8

    int-to-float v8, v6

    move-object v6, v5

    move/from16 v27, v8

    move v8, v10

    const/4 v10, 0x2

    move v9, v11

    const/4 v11, 0x2

    move/from16 v10, v27

    const/4 v0, 0x2

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 236
    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    if-ne v6, v0, :cond_9

    .line 237
    const/4 v0, 0x0

    invoke-virtual {v4, v0}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    goto :goto_7

    .line 236
    :cond_9
    const/4 v0, 0x0

    .line 239
    :goto_7
    iget-object v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v6, v6, v19

    iget-object v7, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    iget-object v8, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    array-length v8, v8

    const/4 v9, 0x1

    sub-int/2addr v8, v9

    aget-byte v7, v7, v8

    if-le v6, v7, :cond_a

    .line 240
    div-int/lit8 v6, v14, 0x2

    sub-int v10, v3, v6

    int-to-float v7, v10

    add-int/lit8 v6, v2, -0x1

    aget v6, v13, v6

    sub-int/2addr v6, v9

    div-int/lit8 v8, v14, 0x2

    add-int/2addr v6, v8

    int-to-float v8, v6

    int-to-float v10, v3

    add-int/lit8 v6, v2, -0x1

    aget v6, v13, v6

    sub-int/2addr v6, v9

    int-to-float v11, v6

    move-object v6, v5

    move v9, v10

    move v10, v11

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 241
    int-to-float v7, v3

    add-int/lit8 v6, v2, -0x1

    aget v6, v13, v6

    const/4 v8, 0x1

    sub-int/2addr v6, v8

    int-to-float v9, v6

    div-int/lit8 v6, v14, 0x2

    add-int/2addr v6, v3

    int-to-float v10, v6

    add-int/lit8 v6, v2, -0x1

    aget v6, v13, v6

    sub-int/2addr v6, v8

    div-int/lit8 v8, v14, 0x2

    add-int/2addr v6, v8

    int-to-float v11, v6

    move-object v6, v5

    move v8, v9

    move v9, v10

    move v10, v11

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_8

    .line 243
    :cond_a
    div-int/lit8 v6, v14, 0x2

    sub-int v10, v3, v6

    int-to-float v7, v10

    add-int/lit8 v6, v1, -0x1

    aget v6, v13, v6

    const/4 v8, 0x1

    add-int/2addr v6, v8

    div-int/lit8 v9, v14, 0x2

    sub-int/2addr v6, v9

    int-to-float v9, v6

    int-to-float v10, v3

    add-int/lit8 v6, v1, -0x1

    aget v6, v13, v6

    add-int/2addr v6, v8

    int-to-float v11, v6

    move-object v6, v5

    move v8, v9

    move v9, v10

    move v10, v11

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 244
    int-to-float v7, v3

    add-int/lit8 v6, v1, -0x1

    aget v6, v13, v6

    const/4 v8, 0x1

    add-int/2addr v6, v8

    int-to-float v9, v6

    div-int/lit8 v6, v14, 0x2

    add-int/2addr v6, v3

    int-to-float v10, v6

    add-int/lit8 v6, v1, -0x1

    aget v6, v13, v6

    add-int/2addr v6, v8

    div-int/lit8 v8, v14, 0x2

    sub-int/2addr v6, v8

    int-to-float v11, v6

    move-object v6, v5

    move v8, v9

    move v9, v10

    move v10, v11

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 226
    :goto_8
    add-int/lit8 v11, v25, 0x1

    move-object/from16 v0, p0

    move/from16 v33, v3

    move-object/from16 v32, v15

    move/from16 v15, v24

    move-object/from16 v3, v26

    .end local v25    # "c":I
    .restart local v11    # "c":I
    goto/16 :goto_5

    .end local v24    # "i2":I
    .end local v26    # "bitmap":Landroid/graphics/Bitmap;
    .local v3, "bitmap":Landroid/graphics/Bitmap;
    .restart local v10    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v15, "i2":I
    .restart local v33    # "dur_x":I
    :cond_b
    move-object/from16 v26, v3

    move/from16 v25, v11

    move/from16 v24, v15

    move/from16 v3, v33

    const/4 v0, 0x2

    move-object v15, v10

    .line 248
    .end local v10    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v11    # "c":I
    .end local v33    # "dur_x":I
    .local v3, "dur_x":I
    .local v15, "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v24    # "i2":I
    .restart local v26    # "bitmap":Landroid/graphics/Bitmap;
    int-to-float v7, v3

    add-int/lit8 v6, v1, -0x1

    aget v6, v13, v6

    mul-int/lit8 v8, v14, 0x2

    div-int/lit8 v8, v8, 0x5

    add-int/2addr v6, v8

    int-to-float v8, v6

    int-to-float v9, v3

    aget v6, v13, v20

    add-int/2addr v6, v14

    int-to-float v10, v6

    move-object v6, v5

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 249
    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    add-int v17, v17, v6

    .line 250
    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    if-ge v6, v12, :cond_16

    .line 251
    rem-int v6, v17, v12

    if-eqz v6, :cond_11

    .line 252
    const/16 v25, 0x2

    move-object/from16 v0, p0

    iget-object v6, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    const/16 v18, 0x1

    add-int/lit8 v6, v6, -0x1

    move/from16 v11, v24

    .end local v24    # "i2":I
    .local v11, "i2":I
    if-ge v11, v6, :cond_10

    .line 253
    move-object/from16 v10, v31

    .end local v31    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v10, "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-byte v6, v10, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    if-gt v6, v12, :cond_e

    .line 254
    int-to-float v7, v3

    aget v6, v13, v20

    add-int/2addr v6, v14

    int-to-float v8, v6

    add-int v6, v3, v16

    int-to-float v9, v6

    aget v6, v13, v20

    add-int/2addr v6, v14

    int-to-float v6, v6

    move/from16 v24, v6

    move-object v6, v5

    move-object v0, v10

    .end local v10    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v0, "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    move/from16 v10, v24

    move/from16 v24, v11

    .end local v11    # "i2":I
    .restart local v24    # "i2":I
    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 255
    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    mul-int/lit8 v6, v6, 0x2

    if-ge v6, v12, :cond_d

    .line 256
    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    iget-byte v7, v0, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    if-ne v6, v7, :cond_c

    .line 257
    int-to-float v7, v3

    aget v6, v13, v20

    add-int/2addr v6, v14

    mul-int/lit8 v8, v14, 0x2

    div-int/lit8 v8, v8, 0x5

    sub-int/2addr v6, v8

    int-to-float v8, v6

    add-int v10, v3, v16

    int-to-float v9, v10

    aget v6, v13, v20

    add-int/2addr v6, v14

    mul-int/lit8 v10, v14, 0x2

    div-int/lit8 v10, v10, 0x5

    sub-int/2addr v6, v10

    int-to-float v10, v6

    move-object v6, v5

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_9

    .line 258
    :cond_c
    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    iget-byte v7, v0, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    if-ge v6, v7, :cond_d

    .line 259
    int-to-float v7, v3

    aget v6, v13, v20

    add-int/2addr v6, v14

    mul-int/lit8 v8, v14, 0x2

    div-int/lit8 v8, v8, 0x5

    sub-int/2addr v6, v8

    int-to-float v8, v6

    div-int/lit8 v6, v16, 0x3

    add-int/2addr v6, v3

    int-to-float v9, v6

    aget v6, v13, v20

    add-int/2addr v6, v14

    mul-int/lit8 v10, v14, 0x2

    div-int/lit8 v10, v10, 0x5

    sub-int/2addr v6, v10

    int-to-float v10, v6

    move-object v6, v5

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 262
    :cond_d
    :goto_9
    const/4 v6, 0x1

    move/from16 v21, v6

    move-object/from16 v25, v30

    .end local v21    # "lining":Z
    .local v6, "lining":Z
    goto/16 :goto_b

    .line 264
    .end local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v6    # "lining":Z
    .end local v24    # "i2":I
    .restart local v10    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v11    # "i2":I
    .restart local v21    # "lining":Z
    :cond_e
    move-object v0, v10

    move/from16 v24, v11

    .end local v10    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v11    # "i2":I
    .restart local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v24    # "i2":I
    int-to-float v7, v3

    aget v6, v13, v20

    add-int/2addr v6, v14

    int-to-float v8, v6

    div-int/lit8 v6, v14, 0x2

    add-int/2addr v6, v3

    int-to-float v9, v6

    aget v6, v13, v20

    add-int/2addr v6, v14

    div-int/lit8 v10, v14, 0x2

    sub-int/2addr v6, v10

    int-to-float v10, v6

    move-object v6, v5

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 265
    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    mul-int/lit8 v6, v6, 0x2

    if-ge v6, v12, :cond_f

    .line 266
    int-to-float v7, v3

    aget v6, v13, v20

    add-int/2addr v6, v14

    mul-int/lit8 v8, v14, 0x2

    div-int/lit8 v8, v8, 0x5

    sub-int/2addr v6, v8

    int-to-float v8, v6

    div-int/lit8 v6, v14, 0x2

    add-int/2addr v6, v3

    int-to-float v9, v6

    aget v6, v13, v20

    add-int/2addr v6, v14

    div-int/lit8 v10, v14, 0x2

    sub-int/2addr v6, v10

    mul-int/lit8 v10, v14, 0x2

    div-int/lit8 v10, v10, 0x5

    sub-int/2addr v6, v10

    int-to-float v10, v6

    move-object v6, v5

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move-object/from16 v25, v30

    goto/16 :goto_b

    .line 265
    :cond_f
    move-object/from16 v25, v30

    goto/16 :goto_b

    .line 252
    .end local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v24    # "i2":I
    .restart local v11    # "i2":I
    .restart local v31    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_10
    move/from16 v24, v11

    move-object/from16 v0, v31

    .end local v11    # "i2":I
    .end local v31    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v24    # "i2":I
    move-object/from16 v25, v30

    goto/16 :goto_b

    .line 271
    .end local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v31    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_11
    move-object/from16 v0, v31

    const/16 v18, 0x1

    const/16 v25, 0x2

    .end local v31    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    if-nez v21, :cond_13

    .line 272
    int-to-float v7, v3

    aget v6, v13, v20

    add-int/2addr v6, v14

    int-to-float v8, v6

    div-int/lit8 v6, v14, 0x2

    add-int/2addr v6, v3

    int-to-float v9, v6

    aget v6, v13, v20

    add-int/2addr v6, v14

    div-int/lit8 v10, v14, 0x2

    sub-int/2addr v6, v10

    int-to-float v10, v6

    move-object v6, v5

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 273
    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    mul-int/lit8 v6, v6, 0x2

    if-ge v6, v12, :cond_12

    .line 274
    int-to-float v7, v3

    aget v6, v13, v20

    add-int/2addr v6, v14

    mul-int/lit8 v8, v14, 0x2

    div-int/lit8 v8, v8, 0x5

    sub-int/2addr v6, v8

    int-to-float v8, v6

    div-int/lit8 v6, v14, 0x2

    add-int/2addr v6, v3

    int-to-float v9, v6

    aget v6, v13, v20

    add-int/2addr v6, v14

    div-int/lit8 v10, v14, 0x2

    sub-int/2addr v6, v10

    mul-int/lit8 v10, v14, 0x2

    div-int/lit8 v10, v10, 0x5

    sub-int/2addr v6, v10

    int-to-float v10, v6

    move-object v6, v5

    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move-object/from16 v25, v30

    goto :goto_a

    .line 273
    :cond_12
    move-object/from16 v25, v30

    goto :goto_a

    .line 276
    :cond_13
    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    mul-int/lit8 v6, v6, 0x2

    if-ge v6, v12, :cond_15

    iget-byte v6, v15, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    move-object/from16 v11, v30

    .end local v30    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v11, "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-byte v7, v11, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    if-ge v6, v7, :cond_14

    .line 277
    int-to-float v7, v3

    aget v6, v13, v20

    add-int/2addr v6, v14

    mul-int/lit8 v8, v14, 0x2

    div-int/lit8 v8, v8, 0x5

    sub-int/2addr v6, v8

    int-to-float v8, v6

    div-int/lit8 v6, v16, 0x3

    sub-int v10, v3, v6

    int-to-float v9, v10

    aget v6, v13, v20

    add-int/2addr v6, v14

    mul-int/lit8 v10, v14, 0x2

    div-int/lit8 v10, v10, 0x5

    sub-int/2addr v6, v10

    int-to-float v10, v6

    move-object v6, v5

    move-object/from16 v25, v11

    .end local v11    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .local v25, "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    move-object v11, v4

    invoke-virtual/range {v6 .. v11}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_a

    .line 276
    .end local v25    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v11    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_14
    move-object/from16 v25, v11

    .end local v11    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v25    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    goto :goto_a

    .end local v25    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v30    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_15
    move-object/from16 v25, v30

    .line 279
    .end local v30    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v25    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :goto_a
    const/4 v6, 0x0

    move/from16 v21, v6

    .end local v21    # "lining":Z
    .restart local v6    # "lining":Z
    goto :goto_b

    .line 250
    .end local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v6    # "lining":Z
    .end local v25    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v21    # "lining":Z
    .restart local v30    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v31    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :cond_16
    move-object/from16 v25, v30

    move-object/from16 v0, v31

    const/16 v18, 0x1

    .line 282
    .end local v30    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v31    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .restart local v25    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :goto_b
    add-int v10, v3, v16

    .line 283
    .end local v3    # "dur_x":I
    .local v10, "dur_x":I
    nop

    .end local v0    # "next":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v1    # "lmax":I
    .end local v2    # "lmin":I
    .end local v15    # "curr":Lnet/duceng/xmidi/util/Rhythm$RChord;
    .end local v25    # "prev":Lnet/duceng/xmidi/util/Rhythm$RChord;
    add-int/lit8 v11, v24, 0x1

    .line 284
    .end local v24    # "i2":I
    .local v11, "i2":I
    move-object/from16 v0, p0

    move/from16 v2, p2

    move/from16 v15, v22

    move/from16 v1, v23

    move-object/from16 v3, v26

    goto/16 :goto_1

    .line 285
    .end local v22    # "lx1":I
    .end local v23    # "lx2":I
    .end local v26    # "bitmap":Landroid/graphics/Bitmap;
    .local v1, "lx2":I
    .local v3, "bitmap":Landroid/graphics/Bitmap;
    .local v15, "lx1":I
    :cond_17
    move-object/from16 v26, v3

    .end local v3    # "bitmap":Landroid/graphics/Bitmap;
    .restart local v26    # "bitmap":Landroid/graphics/Bitmap;
    return-object v26

    :array_0
    .array-data 4
        0x40000000    # 2.0f
        0x40400000    # 3.0f
    .end array-data
.end method

.method public getChord(I)Lnet/duceng/xmidi/util/Rhythm$RChord;
    .locals 1
    .param p1, "i"    # I

    .line 51
    iget-object v0, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/util/Rhythm$RChord;

    return-object v0
.end method

.method public getChords()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/util/Rhythm$RChord;",
            ">;"
        }
    .end annotation

    .line 47
    iget-object v0, p0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    return-object v0
.end method

.method public getDurs()B
    .locals 1

    .line 39
    iget-byte v0, p0, Lnet/duceng/xmidi/util/Rhythm;->durs:B

    return v0
.end method

.method public getId()I
    .locals 1

    .line 23
    iget v0, p0, Lnet/duceng/xmidi/util/Rhythm;->id:I

    return v0
.end method

.method public getNotes(Lnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/List;
    .locals 20
    .param p1, "chord"    # Lnet/duceng/xmidi/util/Chords$Chord;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lnet/duceng/xmidi/util/Chords$Chord;",
            ")",
            "Ljava/util/List<",
            "Lnet/duceng/midi/EventChannel;",
            ">;"
        }
    .end annotation

    .line 62
    move-object/from16 v0, p0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 63
    .local v1, "notes":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    iget-byte v2, v0, Lnet/duceng/xmidi/util/Rhythm;->beat:B

    mul-int/lit16 v2, v2, 0x1e0

    .line 64
    .local v2, "totalTick":I
    iget-byte v3, v0, Lnet/duceng/xmidi/util/Rhythm;->durs:B

    div-int v3, v2, v3

    .line 65
    .local v3, "durTick":I
    const/4 v4, 0x0

    .line 66
    .local v4, "tick":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 67
    .local v5, "notesTmp":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    iget-object v6, v0, Lnet/duceng/xmidi/util/Rhythm;->chords:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_5

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    move-object v13, v7

    check-cast v13, Lnet/duceng/xmidi/util/Rhythm$RChord;

    .line 68
    .local v13, "rchord":Lnet/duceng/xmidi/util/Rhythm$RChord;
    iget-boolean v7, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->keep:Z

    if-eqz v7, :cond_0

    .line 69
    iget-byte v7, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    mul-int v7, v7, v3

    add-int/2addr v4, v7

    move-object/from16 v12, p1

    goto/16 :goto_4

    .line 71
    :cond_0
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_1
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_1

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    move-object v15, v7

    check-cast v15, Lnet/duceng/midi/EventChannel;

    .line 72
    .local v15, "note":Lnet/duceng/midi/EventChannel;
    new-instance v12, Lnet/duceng/midi/EventChannel;

    invoke-virtual {v15}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v11

    const/16 v16, 0x0

    const/16 v9, 0x8

    const/4 v10, 0x0

    move-object v7, v12

    move v8, v4

    move-object v0, v12

    move/from16 v12, v16

    invoke-direct/range {v7 .. v12}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 73
    .end local v15    # "note":Lnet/duceng/midi/EventChannel;
    move-object/from16 v0, p0

    goto :goto_1

    .line 74
    :cond_1
    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    .line 75
    iget-byte v0, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    const/4 v7, 0x1

    if-ne v0, v7, :cond_2

    .line 76
    const/4 v0, 0x5

    .local v0, "tickAdd":I
    goto :goto_2

    .line 78
    .end local v0    # "tickAdd":I
    :cond_2
    iget-byte v0, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->mod:B

    const/4 v7, 0x2

    if-ne v0, v7, :cond_3

    const/16 v0, 0x28

    goto :goto_2

    :cond_3
    const/4 v0, 0x0

    .line 80
    .restart local v0    # "tickAdd":I
    :goto_2
    const/4 v7, 0x0

    .local v7, "i":I
    :goto_3
    iget-object v8, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    array-length v8, v8

    if-ge v7, v8, :cond_4

    .line 81
    new-instance v8, Lnet/duceng/midi/EventChannel;

    mul-int v9, v0, v7

    add-int v15, v4, v9

    move-object/from16 v12, p1

    iget-object v9, v12, Lnet/duceng/xmidi/util/Chords$Chord;->gnotes:[B

    iget-object v10, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->chord:[B

    aget-byte v10, v10, v7

    rsub-int/lit8 v10, v10, 0x6

    aget-byte v18, v9, v10

    const/16 v19, 0x50

    const/16 v16, 0x9

    const/16 v17, 0x0

    move-object v14, v8

    invoke-direct/range {v14 .. v19}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    .line 82
    .local v8, "e":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 83
    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 80
    .end local v8    # "e":Lnet/duceng/midi/EventChannel;
    add-int/lit8 v7, v7, 0x1

    goto :goto_3

    :cond_4
    move-object/from16 v12, p1

    .line 85
    .end local v7    # "i":I
    iget-byte v7, v13, Lnet/duceng/xmidi/util/Rhythm$RChord;->dur:B

    mul-int v7, v7, v3

    add-int/2addr v4, v7

    .line 87
    .end local v0    # "tickAdd":I
    .end local v13    # "rchord":Lnet/duceng/xmidi/util/Rhythm$RChord;
    :goto_4
    move-object/from16 v0, p0

    goto/16 :goto_0

    .line 88
    :cond_5
    move-object/from16 v12, p1

    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_5
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/midi/EventChannel;

    .line 89
    .local v6, "note2":Lnet/duceng/midi/EventChannel;
    new-instance v13, Lnet/duceng/midi/EventChannel;

    invoke-virtual {v6}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v11

    const/4 v14, 0x0

    const/16 v9, 0x8

    const/4 v10, 0x0

    move-object v7, v13

    move v8, v4

    move v12, v14

    invoke-direct/range {v7 .. v12}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    invoke-virtual {v1, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 90
    .end local v6    # "note2":Lnet/duceng/midi/EventChannel;
    move-object/from16 v12, p1

    goto :goto_5

    .line 91
    :cond_6
    return-object v1
.end method

.method public setBeat(B)V
    .locals 0
    .param p1, "beat"    # B

    .line 35
    iput-byte p1, p0, Lnet/duceng/xmidi/util/Rhythm;->beat:B

    .line 36
    return-void
.end method

.method public setDurs(B)V
    .locals 0
    .param p1, "durs"    # B

    .line 43
    iput-byte p1, p0, Lnet/duceng/xmidi/util/Rhythm;->durs:B

    .line 44
    return-void
.end method

.method public setId(I)V
    .locals 0
    .param p1, "id"    # I

    .line 27
    iput p1, p0, Lnet/duceng/xmidi/util/Rhythm;->id:I

    .line 28
    return-void
.end method
