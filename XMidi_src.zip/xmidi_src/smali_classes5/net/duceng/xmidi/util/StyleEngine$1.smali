.class Lnet/duceng/xmidi/util/StyleEngine$1;
.super Ljava/lang/Object;
.source "StyleEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/util/StyleEngine;->setBaseSetup(Ljava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/util/StyleEngine;

.field final synthetic val$copy:Ljava/util/ArrayList;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/StyleEngine;Ljava/util/ArrayList;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/StyleEngine;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 140
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine$1;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    iput-object p2, p0, Lnet/duceng/xmidi/util/StyleEngine$1;->val$copy:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 143
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine$1;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->access$000(Lnet/duceng/xmidi/util/StyleEngine;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 144
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine$1;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->access$000(Lnet/duceng/xmidi/util/StyleEngine;)Ljava/util/ArrayList;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine$1;->val$copy:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 145
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine$1;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->access$100(Lnet/duceng/xmidi/util/StyleEngine;)Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    .line 146
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine$1;->val$copy:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/EventChannel;

    .line 147
    .local v1, "e":Lnet/duceng/midi/EventChannel;
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine$1;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-static {v2}, Lnet/duceng/xmidi/util/StyleEngine;->access$100(Lnet/duceng/xmidi/util/StyleEngine;)Ljava/util/Map;

    move-result-object v2

    invoke-static {v1}, Lnet/duceng/xmidi/util/StyleEngine;->access$200(Lnet/duceng/midi/EventChannel;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v1}, Lnet/duceng/xmidi/util/StyleEngine;->access$300(Lnet/duceng/midi/EventChannel;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 148
    .end local v1    # "e":Lnet/duceng/midi/EventChannel;
    goto :goto_0

    .line 149
    :cond_0
    return-void
.end method
