.class Lnet/duceng/xmidi/util/StyleEngine$2;
.super Ljava/lang/Object;
.source "StyleEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/util/StyleEngine;->setChord(Lnet/duceng/xmidi/util/Chords$Chord;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/util/StyleEngine;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/StyleEngine;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/StyleEngine;

    .line 188
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine$2;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 191
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine$2;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->access$400(Lnet/duceng/xmidi/util/StyleEngine;)V

    .line 192
    return-void
.end method
