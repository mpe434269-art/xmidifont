.class Lnet/duceng/xmidi/util/StyleEngine$3;
.super Ljava/lang/Object;
.source "StyleEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/util/StyleEngine;->requestSection(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/util/StyleEngine;

.field final synthetic val$name:Ljava/lang/String;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/StyleEngine;Ljava/lang/String;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/StyleEngine;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 197
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine$3;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    iput-object p2, p0, Lnet/duceng/xmidi/util/StyleEngine$3;->val$name:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 200
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine$3;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine$3;->val$name:Ljava/lang/String;

    invoke-static {v0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->access$500(Lnet/duceng/xmidi/util/StyleEngine;Ljava/lang/String;)V

    .line 201
    return-void
.end method
