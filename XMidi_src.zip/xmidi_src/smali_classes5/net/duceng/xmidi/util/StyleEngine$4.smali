.class Lnet/duceng/xmidi/util/StyleEngine$4;
.super Ljava/lang/Object;
.source "StyleEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/xmidi/util/StyleEngine;->sync()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/xmidi/util/StyleEngine;


# direct methods
.method constructor <init>(Lnet/duceng/xmidi/util/StyleEngine;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/xmidi/util/StyleEngine;

    .line 207
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine$4;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    .line 210
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine$4;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->access$600(Lnet/duceng/xmidi/util/StyleEngine;)D

    move-result-wide v0

    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine$4;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-static {v2}, Lnet/duceng/xmidi/util/StyleEngine;->access$700(Lnet/duceng/xmidi/util/StyleEngine;)I

    move-result v2

    int-to-double v2, v2

    rem-double/2addr v0, v2

    .line 211
    .local v0, "p":D
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine$4;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-static {v2}, Lnet/duceng/xmidi/util/StyleEngine;->access$700(Lnet/duceng/xmidi/util/StyleEngine;)I

    move-result v2

    int-to-double v2, v2

    const-wide/high16 v4, 0x4000000000000000L    # 2.0

    div-double/2addr v2, v4

    cmpl-double v4, v0, v2

    if-lez v4, :cond_0

    .line 212
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine$4;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-static {v2}, Lnet/duceng/xmidi/util/StyleEngine;->access$700(Lnet/duceng/xmidi/util/StyleEngine;)I

    move-result v2

    int-to-double v2, v2

    sub-double/2addr v0, v2

    .line 214
    :cond_0
    invoke-static {v0, v1}, Ljava/lang/Math;->abs(D)D

    move-result-wide v2

    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine$4;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-static {v4}, Lnet/duceng/xmidi/util/StyleEngine;->access$700(Lnet/duceng/xmidi/util/StyleEngine;)I

    move-result v4

    int-to-double v4, v4

    const-wide/high16 v6, 0x4020000000000000L    # 8.0

    div-double/2addr v4, v6

    cmpg-double v6, v2, v4

    if-gtz v6, :cond_1

    .line 215
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine$4;->this$0:Lnet/duceng/xmidi/util/StyleEngine;

    invoke-static {v2, v0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->access$626(Lnet/duceng/xmidi/util/StyleEngine;D)D

    .line 217
    :cond_1
    return-void
.end method
