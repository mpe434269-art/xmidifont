.class Lnet/duceng/xmidi/util/StyleEngine$5;
.super Ljava/lang/Object;
.source "StyleEngine.java"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/StyleEngine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lnet/duceng/midi/EventChannel;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 718
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    .line 718
    check-cast p1, Lnet/duceng/midi/EventChannel;

    check-cast p2, Lnet/duceng/midi/EventChannel;

    invoke-virtual {p0, p1, p2}, Lnet/duceng/xmidi/util/StyleEngine$5;->compare(Lnet/duceng/midi/EventChannel;Lnet/duceng/midi/EventChannel;)I

    move-result p1

    return p1
.end method

.method public compare(Lnet/duceng/midi/EventChannel;Lnet/duceng/midi/EventChannel;)I
    .locals 6
    .param p1, "x"    # Lnet/duceng/midi/EventChannel;
    .param p2, "y"    # Lnet/duceng/midi/EventChannel;

    .line 721
    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v0

    invoke-virtual {p2}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v1

    const/4 v2, 0x1

    if-eq v0, v1, :cond_1

    .line 722
    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v0

    invoke-virtual {p2}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v1

    if-ge v0, v1, :cond_0

    const/4 v2, -0x1

    :cond_0
    return v2

    .line 724
    :cond_1
    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v0

    const/16 v1, 0x9

    const/4 v3, 0x0

    const/16 v4, 0x8

    if-eq v0, v4, :cond_3

    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v0

    if-ne v0, v1, :cond_2

    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v0

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    const/4 v0, 0x1

    goto :goto_1

    :cond_3
    :goto_0
    const/4 v0, 0x0

    .line 725
    .local v0, "rx":I
    :goto_1
    invoke-virtual {p2}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v5

    if-eq v5, v4, :cond_4

    invoke-virtual {p2}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v4

    if-ne v4, v1, :cond_5

    invoke-virtual {p2}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v1

    if-nez v1, :cond_5

    :cond_4
    const/4 v2, 0x0

    :cond_5
    move v1, v2

    .line 726
    .local v1, "ry":I
    sub-int v2, v0, v1

    return v2
.end method
