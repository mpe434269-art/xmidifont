.class public interface abstract Lnet/duceng/xmidi/util/StyleEngine$Host;
.super Ljava/lang/Object;
.source "StyleEngine.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/StyleEngine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Host"
.end annotation


# virtual methods
.method public abstract mpqn()I
.end method
