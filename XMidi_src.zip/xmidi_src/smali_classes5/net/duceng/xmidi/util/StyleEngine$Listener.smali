.class public interface abstract Lnet/duceng/xmidi/util/StyleEngine$Listener;
.super Ljava/lang/Object;
.source "StyleEngine.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/StyleEngine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Listener"
.end annotation


# virtual methods
.method public abstract onSection(Ljava/lang/String;)V
.end method

.method public abstract onStopped()V
.end method
