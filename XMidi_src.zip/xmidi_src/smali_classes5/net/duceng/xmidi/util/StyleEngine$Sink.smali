.class public interface abstract Lnet/duceng/xmidi/util/StyleEngine$Sink;
.super Ljava/lang/Object;
.source "StyleEngine.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnet/duceng/xmidi/util/StyleEngine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Sink"
.end annotation


# virtual methods
.method public abstract send(Lnet/duceng/midi/EventChannel;)V
.end method

.method public abstract silence()V
.end method
