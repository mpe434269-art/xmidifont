.class public final Lnet/duceng/xmidi/util/StyleEngine;
.super Ljava/lang/Object;
.source "StyleEngine.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/xmidi/util/StyleEngine$Sink;,
        Lnet/duceng/xmidi/util/StyleEngine$Host;,
        Lnet/duceng/xmidi/util/StyleEngine$Listener;
    }
.end annotation


# static fields
.field private static final BAR_ORDER:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lnet/duceng/midi/EventChannel;",
            ">;"
        }
    .end annotation
.end field

.field private static final DRUM:I = 0x9

.field private static final MAX_PARK_NS:J = 0x4c4b40L

.field private static final MIN_PARK_NS:J = 0x4e20L


# instance fields
.field private afterName:Ljava/lang/String;

.field private bar:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/EventChannel;",
            ">;"
        }
    .end annotation
.end field

.field private barIdx:I

.field private final barTicks:I

.field private final baseSetup:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/EventChannel;",
            ">;"
        }
    .end annotation
.end field

.field private beatCount:I

.field private final beatTicks:I

.field private final ccTouched:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private chordApplied:Lnet/duceng/xmidi/util/Chords$Chord;

.field private volatile chordV:Lnet/duceng/xmidi/util/Chords$Chord;

.field private final cmds:Ljava/util/concurrent/ConcurrentLinkedQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentLinkedQueue<",
            "Ljava/lang/Runnable;",
            ">;"
        }
    .end annotation
.end field

.field private cursor:I

.field private final factory:Ljava/util/concurrent/ThreadFactory;

.field private final host:Lnet/duceng/xmidi/util/StyleEngine$Host;

.field private lastMain:Ljava/lang/String;

.field private lastNotified:Ljava/lang/String;

.field private final lastOnNs:[J

.field private lastResyncNs:J

.field private final lastSent:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final lateOffs:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "[J>;"
        }
    .end annotation
.end field

.field private volatile listener:Lnet/duceng/xmidi/util/StyleEngine$Listener;

.field private final mergeDefined:[Z

.field private mergePrev:Z

.field private volatile metroNote:I

.field private volatile metroNoteAccent:I

.field private volatile metroOn:Z

.field private volatile metroVel:I

.field private nextBeatTick:D

.field private final pbTouched:[Z

.field private pendingAfter:Ljava/lang/String;

.field private pendingName:Ljava/lang/String;

.field private prevBarIdx:I

.field private prevSection:Lnet/duceng/midi/StySection;

.field private final res:I

.field private volatile running:Z

.field private section:Lnet/duceng/midi/StySection;

.field private final sink:Lnet/duceng/xmidi/util/StyleEngine$Sink;

.field private final sounding:[Z

.field private volatile startName:Ljava/lang/String;

.field private final sty:Lnet/duceng/midi/StyFile;

.field private volatile thread:Ljava/lang/Thread;

.field private tickPos:D


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 718
    new-instance v0, Lnet/duceng/xmidi/util/StyleEngine$5;

    invoke-direct {v0}, Lnet/duceng/xmidi/util/StyleEngine$5;-><init>()V

    sput-object v0, Lnet/duceng/xmidi/util/StyleEngine;->BAR_ORDER:Ljava/util/Comparator;

    return-void
.end method

.method public constructor <init>(Lnet/duceng/midi/StyFile;Lnet/duceng/xmidi/util/StyleEngine$Sink;Lnet/duceng/xmidi/util/StyleEngine$Host;Ljava/util/concurrent/ThreadFactory;)V
    .locals 4
    .param p1, "sty"    # Lnet/duceng/midi/StyFile;
    .param p2, "sink"    # Lnet/duceng/xmidi/util/StyleEngine$Sink;
    .param p3, "host"    # Lnet/duceng/xmidi/util/StyleEngine$Host;
    .param p4, "factory"    # Ljava/util/concurrent/ThreadFactory;

    .line 101
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 59
    new-instance v0, Ljava/util/concurrent/ConcurrentLinkedQueue;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->cmds:Ljava/util/concurrent/ConcurrentLinkedQueue;

    .line 60
    const/16 v0, 0x800

    new-array v1, v0, [Z

    iput-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sounding:[Z

    .line 62
    const/4 v1, 0x0

    iput-boolean v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->running:Z

    .line 71
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    .line 79
    const-wide/16 v2, 0x0

    iput-wide v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastResyncNs:J

    .line 81
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->baseSetup:Ljava/util/ArrayList;

    .line 82
    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastSent:Ljava/util/Map;

    .line 84
    iput-boolean v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroOn:Z

    .line 85
    const/16 v2, 0x22

    iput v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroNoteAccent:I

    .line 86
    const/16 v2, 0x21

    iput v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroNote:I

    .line 87
    const/16 v2, 0x4b

    iput v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroVel:I

    .line 88
    const-wide/16 v2, 0x0

    iput-wide v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->nextBeatTick:D

    .line 89
    iput v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->beatCount:I

    .line 93
    iput-boolean v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->mergePrev:Z

    .line 94
    const/4 v1, 0x0

    iput-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastMain:Ljava/lang/String;

    .line 95
    const/16 v1, 0x10

    new-array v2, v1, [Z

    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->pbTouched:[Z

    .line 96
    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->ccTouched:Ljava/util/HashSet;

    .line 97
    new-array v1, v1, [Z

    iput-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->mergeDefined:[Z

    .line 98
    new-array v0, v0, [J

    iput-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastOnNs:[J

    .line 99
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->lateOffs:Ljava/util/ArrayList;

    .line 102
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    .line 103
    iput-object p2, p0, Lnet/duceng/xmidi/util/StyleEngine;->sink:Lnet/duceng/xmidi/util/StyleEngine$Sink;

    .line 104
    iput-object p3, p0, Lnet/duceng/xmidi/util/StyleEngine;->host:Lnet/duceng/xmidi/util/StyleEngine$Host;

    .line 105
    iput-object p4, p0, Lnet/duceng/xmidi/util/StyleEngine;->factory:Ljava/util/concurrent/ThreadFactory;

    .line 106
    invoke-virtual {p1}, Lnet/duceng/midi/StyFile;->getResolution()I

    move-result v0

    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->res:I

    .line 107
    invoke-virtual {p1}, Lnet/duceng/midi/StyFile;->getBarTicks()I

    move-result v0

    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->barTicks:I

    .line 108
    invoke-virtual {p1}, Lnet/duceng/midi/StyFile;->getBeatTicks()I

    move-result v0

    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->beatTicks:I

    .line 109
    return-void
.end method

.method static synthetic access$000(Lnet/duceng/xmidi/util/StyleEngine;)Ljava/util/ArrayList;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/StyleEngine;

    .line 31
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->baseSetup:Ljava/util/ArrayList;

    return-object v0
.end method

.method static synthetic access$100(Lnet/duceng/xmidi/util/StyleEngine;)Ljava/util/Map;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/StyleEngine;

    .line 31
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastSent:Ljava/util/Map;

    return-object v0
.end method

.method static synthetic access$200(Lnet/duceng/midi/EventChannel;)Ljava/lang/String;
    .locals 1
    .param p0, "x0"    # Lnet/duceng/midi/EventChannel;

    .line 31
    invoke-static {p0}, Lnet/duceng/xmidi/util/StyleEngine;->keyOf(Lnet/duceng/midi/EventChannel;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$300(Lnet/duceng/midi/EventChannel;)I
    .locals 1
    .param p0, "x0"    # Lnet/duceng/midi/EventChannel;

    .line 31
    invoke-static {p0}, Lnet/duceng/xmidi/util/StyleEngine;->valueOf(Lnet/duceng/midi/EventChannel;)I

    move-result v0

    return v0
.end method

.method static synthetic access$400(Lnet/duceng/xmidi/util/StyleEngine;)V
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/util/StyleEngine;

    .line 31
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->applyChord()V

    return-void
.end method

.method static synthetic access$500(Lnet/duceng/xmidi/util/StyleEngine;Ljava/lang/String;)V
    .locals 0
    .param p0, "x0"    # Lnet/duceng/xmidi/util/StyleEngine;
    .param p1, "x1"    # Ljava/lang/String;

    .line 31
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/util/StyleEngine;->applySectionRequest(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$600(Lnet/duceng/xmidi/util/StyleEngine;)D
    .locals 2
    .param p0, "x0"    # Lnet/duceng/xmidi/util/StyleEngine;

    .line 31
    iget-wide v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    return-wide v0
.end method

.method static synthetic access$626(Lnet/duceng/xmidi/util/StyleEngine;D)D
    .locals 2
    .param p0, "x0"    # Lnet/duceng/xmidi/util/StyleEngine;
    .param p1, "x1"    # D

    .line 31
    iget-wide v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    sub-double/2addr v0, p1

    iput-wide v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    return-wide v0
.end method

.method static synthetic access$700(Lnet/duceng/xmidi/util/StyleEngine;)I
    .locals 1
    .param p0, "x0"    # Lnet/duceng/xmidi/util/StyleEngine;

    .line 31
    iget v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->beatTicks:I

    return v0
.end method

.method private advanceBar()V
    .locals 5

    .line 530
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->mergePrev:Z

    .line 531
    iget v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    .line 532
    const/4 v1, 0x0

    .line 533
    .local v1, "sectionChanged":Z
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingName:Ljava/lang/String;

    const/4 v3, 0x0

    if-eqz v2, :cond_1

    .line 534
    const/4 v1, 0x1

    .line 535
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingName:Ljava/lang/String;

    invoke-direct {p0, v2}, Lnet/duceng/xmidi/util/StyleEngine;->pick(Ljava/lang/String;)Lnet/duceng/midi/StySection;

    move-result-object v2

    .line 536
    .local v2, "s":Lnet/duceng/midi/StySection;
    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingAfter:Ljava/lang/String;

    iput-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->afterName:Ljava/lang/String;

    .line 537
    iput-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingName:Ljava/lang/String;

    .line 538
    iput-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingAfter:Ljava/lang/String;

    .line 539
    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    .line 540
    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    .line 541
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->notifySection()V

    .line 542
    .end local v2    # "s":Lnet/duceng/midi/StySection;
    :cond_0
    goto :goto_1

    :cond_1
    iget v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    invoke-virtual {v4}, Lnet/duceng/midi/StySection;->sizeBars()I

    move-result v4

    if-lt v2, v4, :cond_0

    .line 543
    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    .line 544
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    invoke-virtual {v2}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v2

    .line 545
    .local v2, "cur":Ljava/lang/String;
    invoke-static {v2}, Lnet/duceng/xmidi/util/StyleEngine;->isEnding(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_2

    .line 546
    iput-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->running:Z

    .line 547
    return-void

    .line 549
    :cond_2
    invoke-static {v2}, Lnet/duceng/xmidi/util/StyleEngine;->isIntro(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_3

    invoke-static {v2}, Lnet/duceng/xmidi/util/StyleEngine;->isFill(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_6

    .line 550
    :cond_3
    const/4 v1, 0x1

    .line 551
    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->afterName:Ljava/lang/String;

    if-eqz v4, :cond_4

    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->afterName:Ljava/lang/String;

    goto :goto_0

    :cond_4
    invoke-static {v2}, Lnet/duceng/xmidi/util/StyleEngine;->isFill(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-direct {p0, v2}, Lnet/duceng/xmidi/util/StyleEngine;->destMainFor(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_0

    :cond_5
    invoke-static {v2}, Lnet/duceng/xmidi/util/StyleEngine;->last(Ljava/lang/String;)C

    move-result v4

    invoke-direct {p0, v4}, Lnet/duceng/xmidi/util/StyleEngine;->mainFor(C)Ljava/lang/String;

    move-result-object v4

    .line 552
    .local v4, "dest":Ljava/lang/String;
    :goto_0
    iput-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->afterName:Ljava/lang/String;

    .line 553
    invoke-direct {p0, v4}, Lnet/duceng/xmidi/util/StyleEngine;->pick(Ljava/lang/String;)Lnet/duceng/midi/StySection;

    move-result-object v3

    iput-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    .line 554
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->notifySection()V

    .line 557
    .end local v2    # "cur":Ljava/lang/String;
    .end local v4    # "dest":Ljava/lang/String;
    :cond_6
    :goto_1
    if-eqz v1, :cond_7

    .line 558
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->silenceMelodic()V

    .line 559
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->applySectionSetup()V

    .line 561
    :cond_7
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    iget v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordApplied:Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-virtual {v2, v3, v4}, Lnet/duceng/midi/StySection;->getEvents(ILnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/ArrayList;

    move-result-object v2

    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    .line 562
    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    .line 563
    return-void
.end method

.method private applyChord()V
    .locals 2

    .line 566
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordV:Lnet/duceng/xmidi/util/Chords$Chord;

    .line 567
    .local v0, "c":Lnet/duceng/xmidi/util/Chords$Chord;
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    if-eqz v1, :cond_1

    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordApplied:Lnet/duceng/xmidi/util/Chords$Chord;

    if-ne v0, v1, :cond_0

    goto :goto_0

    .line 570
    :cond_0
    iput-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordApplied:Lnet/duceng/xmidi/util/Chords$Chord;

    .line 571
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->resync()V

    .line 572
    return-void

    .line 568
    :cond_1
    :goto_0
    return-void
.end method

.method private applySectionRequest(Ljava/lang/String;)V
    .locals 7
    .param p1, "name"    # Ljava/lang/String;

    .line 647
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    if-eqz v0, :cond_a

    if-eqz p1, :cond_a

    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    invoke-virtual {v0, p1}, Lnet/duceng/midi/StyFile;->getSection(Ljava/lang/String;)Lnet/duceng/midi/StySection;

    move-result-object v0

    if-nez v0, :cond_0

    goto/16 :goto_3

    .line 650
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    invoke-virtual {v0}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v0

    .line 651
    .local v0, "cur":Ljava/lang/String;
    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->isEnding(Ljava/lang/String;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    invoke-static {p1}, Lnet/duceng/xmidi/util/StyleEngine;->isEnding(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 652
    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->last(Ljava/lang/String;)C

    move-result v1

    invoke-direct {p0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->mainFor(C)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->pick(Ljava/lang/String;)Lnet/duceng/midi/StySection;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    .line 653
    const/4 v1, 0x0

    iput v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    .line 654
    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->afterName:Ljava/lang/String;

    .line 655
    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingName:Ljava/lang/String;

    .line 656
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->silenceMelodic()V

    .line 657
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->applySectionSetup()V

    .line 658
    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordApplied:Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-virtual {v3, v1, v4}, Lnet/duceng/midi/StySection;->getEvents(ILnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/ArrayList;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    .line 659
    iget-wide v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    invoke-direct {p0, v3, v4}, Lnet/duceng/xmidi/util/StyleEngine;->firstIndexAfter(D)I

    move-result v1

    iput v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    .line 660
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->notifySection()V

    .line 661
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    invoke-virtual {v1}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v0

    .line 663
    :cond_1
    invoke-static {p1}, Lnet/duceng/xmidi/util/StyleEngine;->isFill(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 664
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/util/StyleEngine;->destMainFor(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, p1, v1}, Lnet/duceng/xmidi/util/StyleEngine;->fillNow(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_2

    .line 665
    :cond_2
    invoke-static {p1}, Lnet/duceng/xmidi/util/StyleEngine;->isMain(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_8

    .line 666
    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->isIntro(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_7

    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->isFill(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3

    goto :goto_1

    .line 668
    :cond_3
    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->isMain(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_6

    .line 669
    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->last(Ljava/lang/String;)C

    move-result v1

    .line 670
    .local v1, "a":C
    invoke-static {p1}, Lnet/duceng/xmidi/util/StyleEngine;->last(Ljava/lang/String;)C

    move-result v3

    .line 671
    .local v3, "b":C
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Fill In "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 672
    .local v4, "f":Ljava/lang/String;
    iget-object v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    invoke-virtual {v6, v4}, Lnet/duceng/midi/StyFile;->containsSection(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_4

    .line 673
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 675
    :cond_4
    iget-object v5, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    invoke-virtual {v5, v4}, Lnet/duceng/midi/StyFile;->containsSection(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_5

    .line 676
    invoke-direct {p0, v4, p1}, Lnet/duceng/xmidi/util/StyleEngine;->fillNow(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 678
    :cond_5
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingName:Ljava/lang/String;

    .line 679
    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingAfter:Ljava/lang/String;

    .line 681
    .end local v1    # "a":C
    .end local v3    # "b":C
    .end local v4    # "f":Ljava/lang/String;
    :goto_0
    goto :goto_2

    .line 682
    :cond_6
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingName:Ljava/lang/String;

    .line 683
    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingAfter:Ljava/lang/String;

    goto :goto_2

    .line 667
    :cond_7
    :goto_1
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine;->afterName:Ljava/lang/String;

    goto :goto_2

    .line 686
    :cond_8
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingName:Ljava/lang/String;

    .line 688
    invoke-static {p1}, Lnet/duceng/xmidi/util/StyleEngine;->isIntro(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_9

    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastMain:Ljava/lang/String;

    if-eqz v1, :cond_9

    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastMain:Ljava/lang/String;

    :cond_9
    iput-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingAfter:Ljava/lang/String;

    .line 690
    :goto_2
    return-void

    .line 648
    .end local v0    # "cur":Ljava/lang/String;
    :cond_a
    :goto_3
    return-void
.end method

.method private applySectionSetup()V
    .locals 15

    .line 409
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    if-nez v0, :cond_0

    .line 410
    return-void

    .line 412
    :cond_0
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->resetAutomation()V

    .line 413
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 414
    .local v0, "banks":Ljava/util/LinkedHashMap;, "Ljava/util/LinkedHashMap<Ljava/lang/String;Lnet/duceng/midi/EventChannel;>;"
    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 415
    .local v1, "progs":Ljava/util/LinkedHashMap;, "Ljava/util/LinkedHashMap<Ljava/lang/String;Lnet/duceng/midi/EventChannel;>;"
    new-instance v2, Ljava/util/LinkedHashMap;

    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 416
    .local v2, "ctrls":Ljava/util/LinkedHashMap;, "Ljava/util/LinkedHashMap<Ljava/lang/String;Lnet/duceng/midi/EventChannel;>;"
    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->baseSetup:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/midi/EventChannel;

    .line 417
    .local v4, "e":Lnet/duceng/midi/EventChannel;
    invoke-static {v4, v0, v1, v2}, Lnet/duceng/xmidi/util/StyleEngine;->classify(Lnet/duceng/midi/EventChannel;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V

    .line 418
    .end local v4    # "e":Lnet/duceng/midi/EventChannel;
    goto :goto_0

    .line 419
    :cond_1
    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    invoke-virtual {v3}, Lnet/duceng/midi/StySection;->getSetupEvents()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/midi/EventChannel;

    .line 420
    .local v4, "e2":Lnet/duceng/midi/EventChannel;
    invoke-static {v4, v0, v1, v2}, Lnet/duceng/xmidi/util/StyleEngine;->classify(Lnet/duceng/midi/EventChannel;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V

    .line 421
    .end local v4    # "e2":Lnet/duceng/midi/EventChannel;
    goto :goto_1

    .line 422
    :cond_2
    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->ccTouched:Ljava/util/HashSet;

    invoke-virtual {v3}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    .line 423
    .local v4, "k":Ljava/lang/Integer;
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v5

    shr-int/lit8 v5, v5, 0x8

    .line 424
    .local v5, "ch":I
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v6

    and-int/lit16 v6, v6, 0xff

    .line 425
    .local v6, "cc":I
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "C"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ":"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 426
    .local v7, "key":Ljava/lang/String;
    invoke-virtual {v2, v7}, Ljava/util/LinkedHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_3

    .line 427
    new-instance v8, Lnet/duceng/midi/EventChannel;

    int-to-byte v12, v5

    int-to-byte v13, v6

    invoke-static {v6}, Lnet/duceng/xmidi/util/StyleEngine;->neutralCC(I)I

    move-result v9

    int-to-byte v14, v9

    const/4 v10, 0x0

    const/16 v11, 0xb

    move-object v9, v8

    invoke-direct/range {v9 .. v14}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    invoke-virtual {v2, v7, v8}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 429
    .end local v4    # "k":Ljava/lang/Integer;
    .end local v5    # "ch":I
    .end local v6    # "cc":I
    .end local v7    # "key":Ljava/lang/String;
    :cond_3
    goto :goto_2

    .line 430
    :cond_4
    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->ccTouched:Ljava/util/HashSet;

    invoke-virtual {v3}, Ljava/util/HashSet;->clear()V

    .line 431
    invoke-direct {p0, v0}, Lnet/duceng/xmidi/util/StyleEngine;->sendChanged(Ljava/util/Map;)V

    .line 432
    invoke-direct {p0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->sendChanged(Ljava/util/Map;)V

    .line 433
    invoke-direct {p0, v2}, Lnet/duceng/xmidi/util/StyleEngine;->sendChanged(Ljava/util/Map;)V

    .line 434
    return-void
.end method

.method private begin(Ljava/lang/String;)V
    .locals 3
    .param p1, "name"    # Ljava/lang/String;

    .line 502
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordV:Lnet/duceng/xmidi/util/Chords$Chord;

    iput-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordApplied:Lnet/duceng/xmidi/util/Chords$Chord;

    .line 503
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/util/StyleEngine;->pick(Ljava/lang/String;)Lnet/duceng/midi/StySection;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    .line 504
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    .line 505
    const-wide/16 v1, 0x0

    iput-wide v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    .line 506
    iput-wide v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->nextBeatTick:D

    .line 507
    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->beatCount:I

    .line 508
    const/4 v1, 0x0

    iput-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->afterName:Ljava/lang/String;

    .line 509
    iput-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingName:Ljava/lang/String;

    .line 510
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    if-nez v1, :cond_0

    .line 511
    return-void

    .line 513
    :cond_0
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->applySectionSetup()V

    .line 514
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordApplied:Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-virtual {v1, v0, v2}, Lnet/duceng/midi/StySection;->getEvents(ILnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/ArrayList;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    .line 515
    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    .line 516
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->notifySection()V

    .line 517
    return-void
.end method

.method private buildBar()Ljava/util/ArrayList;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/EventChannel;",
            ">;"
        }
    .end annotation

    .line 735
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    iget v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordApplied:Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-virtual {v0, v1, v2}, Lnet/duceng/midi/StySection;->getEvents(ILnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/ArrayList;

    move-result-object v0

    .line 736
    .local v0, "b":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    iget-boolean v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->mergePrev:Z

    if-eqz v1, :cond_4

    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->prevSection:Lnet/duceng/midi/StySection;

    if-eqz v1, :cond_4

    .line 737
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 738
    .local v1, "own":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/EventChannel;

    .line 739
    .local v3, "e":Lnet/duceng/midi/EventChannel;
    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->mergeDefined:[Z

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v5

    and-int/lit8 v5, v5, 0xf

    aget-boolean v4, v4, v5

    if-eqz v4, :cond_0

    .line 740
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 742
    .end local v3    # "e":Lnet/duceng/midi/EventChannel;
    :cond_0
    goto :goto_0

    .line 743
    :cond_1
    move-object v0, v1

    .line 744
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->prevSection:Lnet/duceng/midi/StySection;

    iget v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->prevBarIdx:I

    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordApplied:Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-virtual {v2, v3, v4}, Lnet/duceng/midi/StySection;->getEvents(ILnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/EventChannel;

    .line 745
    .local v3, "e2":Lnet/duceng/midi/EventChannel;
    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->mergeDefined:[Z

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v5

    and-int/lit8 v5, v5, 0xf

    aget-boolean v4, v4, v5

    if-nez v4, :cond_2

    .line 746
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 748
    .end local v3    # "e2":Lnet/duceng/midi/EventChannel;
    :cond_2
    goto :goto_1

    .line 749
    :cond_3
    sget-object v2, Lnet/duceng/xmidi/util/StyleEngine;->BAR_ORDER:Ljava/util/Comparator;

    invoke-static {v0, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 751
    .end local v1    # "own":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    :cond_4
    return-object v0
.end method

.method private static classify(Lnet/duceng/midi/EventChannel;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V
    .locals 3
    .param p0, "e"    # Lnet/duceng/midi/EventChannel;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lnet/duceng/midi/EventChannel;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lnet/duceng/midi/EventChannel;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lnet/duceng/midi/EventChannel;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lnet/duceng/midi/EventChannel;",
            ">;)V"
        }
    .end annotation

    .line 437
    .local p1, "banks":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Lnet/duceng/midi/EventChannel;>;"
    .local p2, "progs":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Lnet/duceng/midi/EventChannel;>;"
    .local p3, "ctrls":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Lnet/duceng/midi/EventChannel;>;"
    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v0

    const/16 v1, 0xc

    if-ne v0, v1, :cond_0

    .line 438
    invoke-static {p0}, Lnet/duceng/xmidi/util/StyleEngine;->keyOf(Lnet/duceng/midi/EventChannel;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p2, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    .line 439
    :cond_0
    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v0

    const/16 v1, 0xb

    if-ne v0, v1, :cond_2

    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v0

    const/16 v2, 0x20

    if-ne v0, v2, :cond_2

    .line 440
    :cond_1
    invoke-static {p0}, Lnet/duceng/xmidi/util/StyleEngine;->keyOf(Lnet/duceng/midi/EventChannel;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    .line 441
    :cond_2
    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v0

    if-ne v0, v1, :cond_3

    .line 442
    invoke-static {p0}, Lnet/duceng/xmidi/util/StyleEngine;->keyOf(Lnet/duceng/midi/EventChannel;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p3, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 444
    :cond_3
    :goto_0
    return-void
.end method

.method private continuesNextBar()Z
    .locals 3

    .line 472
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingName:Ljava/lang/String;

    if-nez v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    if-eqz v0, :cond_0

    iget v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    invoke-virtual {v2}, Lnet/duceng/midi/StySection;->sizeBars()I

    move-result v2

    if-ge v0, v2, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method private destMainFor(Ljava/lang/String;)Ljava/lang/String;
    .locals 5
    .param p1, "fillName"    # Ljava/lang/String;

    .line 271
    invoke-static {p1}, Lnet/duceng/xmidi/util/StyleEngine;->last(Ljava/lang/String;)C

    move-result v0

    .line 272
    .local v0, "c":C
    const/16 v1, 0x41

    if-lt v0, v1, :cond_0

    const/16 v2, 0x44

    if-gt v0, v2, :cond_0

    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Main "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lnet/duceng/midi/StyFile;->containsSection(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    const-string v2, "Fill In"

    invoke-virtual {p1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 273
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 275
    :cond_0
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastMain:Ljava/lang/String;

    if-eqz v2, :cond_1

    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastMain:Ljava/lang/String;

    goto :goto_0

    :cond_1
    invoke-direct {p0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->mainFor(C)Ljava/lang/String;

    move-result-object v1

    :goto_0
    return-object v1
.end method

.method private drain()V
    .locals 2

    .line 459
    nop

    :goto_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->cmds:Ljava/util/concurrent/ConcurrentLinkedQueue;

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Runnable;

    move-object v1, v0

    .local v1, "r":Ljava/lang/Runnable;
    if-eqz v0, :cond_0

    .line 460
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    goto :goto_0

    .line 462
    :cond_0
    return-void
.end method

.method private fillNow(Ljava/lang/String;Ljava/lang/String;)V
    .locals 9
    .param p1, "fillName"    # Ljava/lang/String;
    .param p2, "after"    # Ljava/lang/String;

    .line 693
    iget v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->barTicks:I

    int-to-double v0, v0

    iget-wide v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    sub-double/2addr v0, v2

    iget v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->beatTicks:I

    int-to-double v2, v2

    const-wide/high16 v4, 0x4000000000000000L    # 2.0

    div-double/2addr v2, v4

    cmpg-double v4, v0, v2

    if-gez v4, :cond_0

    .line 694
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingName:Ljava/lang/String;

    .line 695
    iput-object p2, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingAfter:Ljava/lang/String;

    .line 696
    return-void

    .line 698
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    iput-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->prevSection:Lnet/duceng/midi/StySection;

    .line 699
    iget v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->prevBarIdx:I

    .line 700
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->mergePrev:Z

    .line 701
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/util/StyleEngine;->pick(Ljava/lang/String;)Lnet/duceng/midi/StySection;

    move-result-object v1

    iput-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    .line 704
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->mergeDefined:[Z

    const/4 v2, 0x0

    invoke-static {v1, v2}, Ljava/util/Arrays;->fill([ZZ)V

    .line 705
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordApplied:Lnet/duceng/xmidi/util/Chords$Chord;

    invoke-virtual {v1, v2, v3}, Lnet/duceng/midi/StySection;->getEvents(ILnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/EventChannel;

    .line 706
    .local v3, "fe":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v4

    const/16 v5, 0x9

    if-ne v4, v5, :cond_1

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v4

    if-lez v4, :cond_1

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v4

    int-to-double v4, v4

    iget-wide v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    cmpl-double v8, v4, v6

    if-lez v8, :cond_1

    .line 707
    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->mergeDefined:[Z

    invoke-virtual {v3}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v5

    and-int/lit8 v5, v5, 0xf

    aput-boolean v0, v4, v5

    .line 709
    .end local v3    # "fe":Lnet/duceng/midi/EventChannel;
    :cond_1
    goto :goto_0

    .line 710
    :cond_2
    iput v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->barIdx:I

    .line 711
    iput-object p2, p0, Lnet/duceng/xmidi/util/StyleEngine;->afterName:Ljava/lang/String;

    .line 712
    const/4 v0, 0x0

    iput-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->pendingName:Ljava/lang/String;

    .line 713
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->applySectionSetup()V

    .line 714
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->resync()V

    .line 715
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->notifySection()V

    .line 716
    return-void
.end method

.method private fire(Lnet/duceng/midi/EventChannel;)V
    .locals 6
    .param p1, "e"    # Lnet/duceng/midi/EventChannel;

    .line 476
    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v0

    and-int/lit8 v0, v0, 0xf

    .line 477
    .local v0, "ch":I
    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v1

    const/16 v2, 0xe

    const/4 v3, 0x1

    if-ne v1, v2, :cond_0

    .line 478
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->pbTouched:[Z

    aput-boolean v3, v1, v0

    goto :goto_0

    .line 479
    :cond_0
    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v1

    const/16 v2, 0xb

    if-ne v1, v2, :cond_1

    .line 480
    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v1

    and-int/lit8 v1, v1, 0x7f

    .line 481
    .local v1, "cc":I
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->ccTouched:Ljava/util/HashSet;

    shl-int/lit8 v4, v0, 0x8

    or-int/2addr v4, v1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 482
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastSent:Ljava/util/Map;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "C"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ":"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v2, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 484
    .end local v1    # "cc":I
    :cond_1
    :goto_0
    iget-byte v1, p1, Lnet/duceng/midi/EventChannel;->carry:B

    if-ne v1, v3, :cond_2

    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->continuesNextBar()Z

    move-result v1

    if-eqz v1, :cond_2

    .line 485
    return-void

    .line 487
    :cond_2
    iget-byte v1, p1, Lnet/duceng/midi/EventChannel;->carry:B

    const/4 v2, 0x2

    const/16 v4, 0x9

    if-ne v1, v2, :cond_3

    if-eq v0, v4, :cond_3

    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sounding:[Z

    shl-int/lit8 v2, v0, 0x7

    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v5

    and-int/lit8 v5, v5, 0x7f

    or-int/2addr v2, v5

    aget-boolean v1, v1, v2

    if-eqz v1, :cond_3

    .line 488
    return-void

    .line 490
    :cond_3
    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v1

    if-ne v1, v4, :cond_4

    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v1

    if-lez v1, :cond_4

    .line 491
    if-eq v0, v4, :cond_6

    .line 492
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sounding:[Z

    shl-int/lit8 v2, v0, 0x7

    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v4

    and-int/lit8 v4, v4, 0x7f

    or-int/2addr v2, v4

    aput-boolean v3, v1, v2

    .line 493
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastOnNs:[J

    shl-int/lit8 v2, v0, 0x7

    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v3

    and-int/lit8 v3, v3, 0x7f

    or-int/2addr v2, v3

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v3

    aput-wide v3, v1, v2

    goto :goto_1

    .line 495
    :cond_4
    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v1

    const/16 v2, 0x8

    if-eq v1, v2, :cond_5

    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v1

    if-ne v1, v4, :cond_6

    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v1

    if-nez v1, :cond_6

    .line 496
    :cond_5
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sounding:[Z

    shl-int/lit8 v2, v0, 0x7

    invoke-virtual {p1}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v3

    and-int/lit8 v3, v3, 0x7f

    or-int/2addr v2, v3

    const/4 v3, 0x0

    aput-boolean v3, v1, v2

    .line 498
    :cond_6
    :goto_1
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sink:Lnet/duceng/xmidi/util/StyleEngine$Sink;

    invoke-interface {v1, p1}, Lnet/duceng/xmidi/util/StyleEngine$Sink;->send(Lnet/duceng/midi/EventChannel;)V

    .line 499
    return-void
.end method

.method private fireDue()V
    .locals 5

    .line 465
    nop

    :goto_0
    iget v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    iget v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/midi/EventChannel;

    invoke-virtual {v0}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v0

    int-to-double v0, v0

    iget-wide v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    cmpg-double v4, v0, v2

    if-gtz v4, :cond_0

    .line 466
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    iget v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/midi/EventChannel;

    invoke-direct {p0, v0}, Lnet/duceng/xmidi/util/StyleEngine;->fire(Lnet/duceng/midi/EventChannel;)V

    goto :goto_0

    .line 468
    :cond_0
    return-void
.end method

.method private fireLateOffs(J)V
    .locals 13
    .param p1, "now"    # J

    .line 364
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->lateOffs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    .local v0, "i":I
    :goto_0
    if-ltz v0, :cond_2

    .line 365
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->lateOffs:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [J

    .line 366
    .local v2, "o":[J
    const/4 v3, 0x0

    aget-wide v4, v2, v3

    cmp-long v6, p1, v4

    if-ltz v6, :cond_1

    .line 367
    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->lateOffs:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 368
    aget-wide v4, v2, v1

    long-to-int v5, v4

    shl-int/lit8 v4, v5, 0x7

    const/4 v5, 0x2

    aget-wide v6, v2, v5

    long-to-int v7, v6

    or-int/2addr v4, v7

    .line 369
    .local v4, "k":I
    iget-object v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastOnNs:[J

    aget-wide v7, v6, v4

    const/4 v6, 0x3

    aget-wide v9, v2, v6

    cmp-long v6, v7, v9

    if-lez v6, :cond_0

    .line 370
    goto :goto_1

    .line 372
    :cond_0
    iget-object v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->sounding:[Z

    aput-boolean v3, v6, v4

    .line 373
    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->sink:Lnet/duceng/xmidi/util/StyleEngine$Sink;

    new-instance v12, Lnet/duceng/midi/EventChannel;

    aget-wide v6, v2, v1

    long-to-int v7, v6

    int-to-byte v9, v7

    aget-wide v5, v2, v5

    long-to-int v6, v5

    int-to-byte v10, v6

    const/4 v11, 0x0

    const/4 v7, 0x0

    const/16 v8, 0x8

    move-object v6, v12

    invoke-direct/range {v6 .. v11}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    invoke-interface {v3, v12}, Lnet/duceng/xmidi/util/StyleEngine$Sink;->send(Lnet/duceng/midi/EventChannel;)V

    .line 364
    .end local v2    # "o":[J
    .end local v4    # "k":I
    :cond_1
    :goto_1
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    .line 376
    .end local v0    # "i":I
    :cond_2
    return-void
.end method

.method private fireMetronome()V
    .locals 10

    .line 353
    nop

    :goto_0
    iget-wide v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->nextBeatTick:D

    iget v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->barTicks:I

    int-to-double v2, v2

    cmpg-double v4, v0, v2

    if-gez v4, :cond_3

    iget-wide v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    iget-wide v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->nextBeatTick:D

    cmpl-double v4, v0, v2

    if-ltz v4, :cond_3

    .line 354
    iget-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroOn:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_2

    .line 355
    iget v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->beatCount:I

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_1

    :cond_0
    const/4 v0, 0x0

    .line 356
    .local v0, "accent":Z
    :goto_1
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->sink:Lnet/duceng/xmidi/util/StyleEngine$Sink;

    new-instance v9, Lnet/duceng/midi/EventChannel;

    if-eqz v0, :cond_1

    iget v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroNoteAccent:I

    goto :goto_2

    :cond_1
    iget v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroNote:I

    :goto_2
    int-to-byte v7, v3

    iget v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroVel:I

    int-to-byte v8, v3

    const/4 v4, 0x0

    const/16 v5, 0x9

    const/16 v6, 0x9

    move-object v3, v9

    invoke-direct/range {v3 .. v8}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    invoke-interface {v2, v9}, Lnet/duceng/xmidi/util/StyleEngine$Sink;->send(Lnet/duceng/midi/EventChannel;)V

    .line 358
    .end local v0    # "accent":Z
    :cond_2
    iget v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->beatCount:I

    add-int/2addr v0, v1

    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->beatCount:I

    .line 359
    iget-wide v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->nextBeatTick:D

    iget v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->beatTicks:I

    int-to-double v2, v2

    add-double/2addr v0, v2

    iput-wide v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->nextBeatTick:D

    goto :goto_0

    .line 361
    :cond_3
    return-void
.end method

.method private firstIndexAfter(D)I
    .locals 4
    .param p1, "t"    # D

    .line 755
    const/4 v0, 0x0

    .line 756
    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/EventChannel;

    invoke-virtual {v1}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v1

    int-to-double v1, v1

    cmpg-double v3, v1, p1

    if-gtz v3, :cond_0

    .line 757
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 759
    :cond_0
    return v0
.end method

.method private static isEnding(Ljava/lang/String;)Z
    .locals 1
    .param p0, "n"    # Ljava/lang/String;

    .line 243
    const-string v0, "Ending"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method private static isFill(Ljava/lang/String;)Z
    .locals 1
    .param p0, "n"    # Ljava/lang/String;

    .line 235
    const-string v0, "Fill In"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "Break"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method private static isIntro(Ljava/lang/String;)Z
    .locals 1
    .param p0, "n"    # Ljava/lang/String;

    .line 239
    const-string v0, "Intro"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method private static isMain(Ljava/lang/String;)Z
    .locals 1
    .param p0, "n"    # Ljava/lang/String;

    .line 247
    const-string v0, "Main"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method private static keyOf(Lnet/duceng/midi/EventChannel;)Ljava/lang/String;
    .locals 2
    .param p0, "e"    # Lnet/duceng/midi/EventChannel;

    .line 165
    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v0

    const/16 v1, 0xc

    if-ne v0, v1, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "P"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v1

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "C"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v1

    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static last(Ljava/lang/String;)C
    .locals 1
    .param p0, "n"    # Ljava/lang/String;

    .line 251
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    return v0
.end method

.method private mainFor(C)Ljava/lang/String;
    .locals 4
    .param p1, "letter"    # C

    .line 255
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Main "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 256
    .local v0, "m":Ljava/lang/String;
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    invoke-virtual {v1, v0}, Lnet/duceng/midi/StyFile;->containsSection(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 257
    return-object v0

    .line 259
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    const-string v2, "Main A"

    invoke-virtual {v1, v2}, Lnet/duceng/midi/StyFile;->containsSection(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 260
    return-object v2

    .line 262
    :cond_1
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    invoke-virtual {v1}, Lnet/duceng/midi/StyFile;->getSections()Ljava/util/Map;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 263
    .local v2, "k":Ljava/lang/String;
    invoke-static {v2}, Lnet/duceng/xmidi/util/StyleEngine;->isMain(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_2

    .line 264
    return-object v2

    .line 266
    .end local v2    # "k":Ljava/lang/String;
    :cond_2
    goto :goto_0

    .line 267
    :cond_3
    const/4 v1, 0x0

    return-object v1
.end method

.method private static neutralCC(I)I
    .locals 2
    .param p0, "cc"    # I

    .line 386
    const/16 v0, 0x40

    const/4 v1, 0x0

    sparse-switch p0, :sswitch_data_0

    .line 394
    return v0

    .line 393
    :sswitch_0
    return v1

    .line 392
    :sswitch_1
    const/16 v0, 0x28

    return v0

    .line 391
    :sswitch_2
    return v1

    .line 390
    :sswitch_3
    const/16 v0, 0x7f

    return v0

    .line 389
    :sswitch_4
    return v0

    .line 388
    :sswitch_5
    const/16 v0, 0x64

    return v0

    .line 387
    :sswitch_6
    return v1

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_6
        0x7 -> :sswitch_5
        0xa -> :sswitch_4
        0xb -> :sswitch_3
        0x40 -> :sswitch_2
        0x5b -> :sswitch_1
        0x5d -> :sswitch_0
    .end sparse-switch
.end method

.method private notifySection()V
    .locals 2

    .line 520
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    invoke-virtual {v0}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lnet/duceng/xmidi/util/StyleEngine;->isMain(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 521
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    invoke-virtual {v0}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastMain:Ljava/lang/String;

    .line 523
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->listener:Lnet/duceng/xmidi/util/StyleEngine$Listener;

    .line 524
    .local v0, "l":Lnet/duceng/xmidi/util/StyleEngine$Listener;
    if-eqz v0, :cond_1

    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    if-eqz v1, :cond_1

    .line 525
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    invoke-virtual {v1}, Lnet/duceng/midi/StySection;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Lnet/duceng/xmidi/util/StyleEngine$Listener;->onSection(Ljava/lang/String;)V

    .line 527
    :cond_1
    return-void
.end method

.method private pick(Ljava/lang/String;)Lnet/duceng/midi/StySection;
    .locals 3
    .param p1, "name"    # Ljava/lang/String;

    .line 279
    const/4 v0, 0x0

    if-nez p1, :cond_0

    move-object v1, v0

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    invoke-virtual {v1, p1}, Lnet/duceng/midi/StyFile;->getSection(Ljava/lang/String;)Lnet/duceng/midi/StySection;

    move-result-object v1

    .line 280
    .local v1, "s":Lnet/duceng/midi/StySection;
    :goto_0
    if-nez v1, :cond_2

    .line 281
    const/16 v2, 0x41

    invoke-direct {p0, v2}, Lnet/duceng/xmidi/util/StyleEngine;->mainFor(C)Ljava/lang/String;

    move-result-object v2

    .line 282
    .local v2, "m":Ljava/lang/String;
    if-eqz v2, :cond_1

    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    invoke-virtual {v0, v2}, Lnet/duceng/midi/StyFile;->getSection(Ljava/lang/String;)Lnet/duceng/midi/StySection;

    move-result-object v0

    :cond_1
    move-object v1, v0

    .line 284
    .end local v2    # "m":Ljava/lang/String;
    :cond_2
    if-nez v1, :cond_3

    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    invoke-virtual {v0}, Lnet/duceng/midi/StyFile;->getSections()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3

    .line 285
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->sty:Lnet/duceng/midi/StyFile;

    invoke-virtual {v0}, Lnet/duceng/midi/StyFile;->getSections()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lnet/duceng/midi/StySection;

    .line 287
    :cond_3
    return-object v1
.end method

.method private post(Ljava/lang/Runnable;)V
    .locals 1
    .param p1, "r"    # Ljava/lang/Runnable;

    .line 222
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->cmds:Ljava/util/concurrent/ConcurrentLinkedQueue;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentLinkedQueue;->add(Ljava/lang/Object;)Z

    .line 223
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->wake()V

    .line 224
    return-void
.end method

.method private resetAutomation()V
    .locals 9

    .line 400
    const/4 v0, 0x0

    .local v0, "ch":I
    :goto_0
    const/16 v1, 0x10

    if-ge v0, v1, :cond_1

    .line 401
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->pbTouched:[Z

    aget-boolean v1, v1, v0

    if-eqz v1, :cond_0

    .line 402
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->pbTouched:[Z

    const/4 v2, 0x0

    aput-boolean v2, v1, v0

    .line 403
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sink:Lnet/duceng/xmidi/util/StyleEngine$Sink;

    new-instance v8, Lnet/duceng/midi/EventChannel;

    int-to-byte v5, v0

    const/4 v6, 0x0

    const/16 v7, 0x40

    const/4 v3, 0x0

    const/16 v4, 0xe

    move-object v2, v8

    invoke-direct/range {v2 .. v7}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    invoke-interface {v1, v8}, Lnet/duceng/xmidi/util/StyleEngine$Sink;->send(Lnet/duceng/midi/EventChannel;)V

    .line 400
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 406
    .end local v0    # "ch":I
    :cond_1
    return-void
.end method

.method private resync()V
    .locals 26

    .line 581
    move-object/from16 v0, p0

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    .line 583
    .local v1, "nowNs":J
    iget-wide v3, v0, Lnet/duceng/xmidi/util/StyleEngine;->lastResyncNs:J

    sub-long v3, v1, v3

    const-wide/32 v5, 0xee6b280

    cmp-long v7, v3, v5

    if-gez v7, :cond_0

    const-wide v3, 0x3fe199999999999aL    # 0.55

    goto :goto_0

    :cond_0
    const-wide v3, 0x3fe999999999999aL    # 0.8

    .line 584
    .local v3, "velScale":D
    :goto_0
    iput-wide v1, v0, Lnet/duceng/xmidi/util/StyleEngine;->lastResyncNs:J

    .line 585
    iget-object v5, v0, Lnet/duceng/xmidi/util/StyleEngine;->sounding:[Z

    invoke-virtual {v5}, [Z->clone()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [Z

    .line 586
    .local v5, "old":[Z
    invoke-direct/range {p0 .. p0}, Lnet/duceng/xmidi/util/StyleEngine;->buildBar()Ljava/util/ArrayList;

    move-result-object v6

    iput-object v6, v0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    .line 587
    iget-wide v6, v0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    invoke-direct {v0, v6, v7}, Lnet/duceng/xmidi/util/StyleEngine;->firstIndexAfter(D)I

    move-result v6

    iput v6, v0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    .line 588
    const/16 v6, 0x800

    new-array v6, v6, [Z

    .line 589
    .local v6, "keep":[Z
    const/4 v7, 0x0

    .line 590
    .local v7, "fired":Z
    iget-object v8, v0, Lnet/duceng/xmidi/util/StyleEngine;->chordApplied:Lnet/duceng/xmidi/util/Chords$Chord;

    const/16 v10, 0x9

    if-eqz v8, :cond_9

    .line 591
    iget-object v8, v0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    .line 592
    .local v8, "size":I
    const/4 v12, 0x0

    .local v12, "i":I
    :goto_1
    iget v13, v0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    if-ge v12, v13, :cond_9

    if-ge v12, v8, :cond_9

    .line 593
    iget-object v13, v0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    invoke-virtual {v13, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lnet/duceng/midi/EventChannel;

    .line 594
    .local v13, "on":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v14

    if-ne v14, v10, :cond_8

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v14

    if-lez v14, :cond_8

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v14

    if-ne v14, v10, :cond_1

    .line 595
    goto/16 :goto_5

    .line 597
    :cond_1
    iget-object v14, v0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v15

    invoke-virtual {v14, v15}, Lnet/duceng/midi/StySection;->getRetriggerRule(I)I

    move-result v14

    if-nez v14, :cond_2

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v14

    invoke-static {v14}, Lnet/duceng/xmidi/util/StyleEngine;->xmSustains(I)Z

    move-result v14

    if-nez v14, :cond_2

    .line 598
    goto/16 :goto_5

    .line 601
    :cond_2
    const/4 v14, 0x0

    .line 602
    .local v14, "open":Z
    add-int/lit8 v15, v12, 0x1

    .local v15, "j":I
    :goto_2
    if-ge v15, v8, :cond_6

    .line 603
    iget-object v9, v0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    invoke-virtual {v9, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/midi/EventChannel;

    .line 604
    .local v9, "off":Lnet/duceng/midi/EventChannel;
    invoke-virtual {v9}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v11

    const/16 v10, 0x8

    if-eq v11, v10, :cond_3

    invoke-virtual {v9}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v10

    const/16 v11, 0x9

    if-ne v10, v11, :cond_5

    invoke-virtual {v9}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v10

    if-nez v10, :cond_5

    .line 605
    :cond_3
    invoke-virtual {v9}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v10

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v11

    if-ne v10, v11, :cond_5

    invoke-virtual {v9}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v10

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v11

    if-ne v10, v11, :cond_5

    .line 606
    iget v10, v0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    if-lt v15, v10, :cond_4

    const/4 v10, 0x1

    goto :goto_3

    :cond_4
    const/4 v10, 0x0

    :goto_3
    move v14, v10

    .line 607
    goto :goto_4

    .line 602
    .end local v9    # "off":Lnet/duceng/midi/EventChannel;
    :cond_5
    add-int/lit8 v15, v15, 0x1

    const/16 v10, 0x9

    goto :goto_2

    .line 610
    .end local v15    # "j":I
    :cond_6
    const/4 v14, 0x1

    :goto_4
    if-nez v14, :cond_7

    .line 611
    goto :goto_5

    .line 613
    :cond_7
    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getChannel()B

    move-result v9

    and-int/lit8 v9, v9, 0xf

    shl-int/lit8 v9, v9, 0x7

    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v10

    and-int/lit8 v10, v10, 0x7f

    or-int/2addr v9, v10

    .line 614
    .local v9, "k":I
    const/4 v10, 0x1

    aput-boolean v10, v6, v9

    .line 615
    aget-boolean v10, v5, v9

    if-nez v10, :cond_8

    .line 616
    invoke-virtual {v13}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v10

    int-to-double v10, v10

    mul-double v10, v10, v3

    invoke-static {v10, v11}, Ljava/lang/Math;->round(D)J

    move-result-wide v10

    long-to-int v11, v10

    invoke-virtual {v13, v11}, Lnet/duceng/midi/EventChannel;->withVelocity(I)Lnet/duceng/midi/EventChannel;

    move-result-object v10

    invoke-direct {v0, v10}, Lnet/duceng/xmidi/util/StyleEngine;->fire(Lnet/duceng/midi/EventChannel;)V

    .line 617
    const/4 v7, 0x1

    .line 592
    .end local v9    # "k":I
    .end local v13    # "on":Lnet/duceng/midi/EventChannel;
    .end local v14    # "open":Z
    :cond_8
    :goto_5
    add-int/lit8 v12, v12, 0x1

    const/16 v10, 0x9

    goto/16 :goto_1

    .line 621
    .end local v8    # "size":I
    .end local v12    # "i":I
    :cond_9
    iget-object v8, v0, Lnet/duceng/xmidi/util/StyleEngine;->lateOffs:Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    const/4 v9, 0x1

    sub-int/2addr v8, v9

    .local v8, "i":I
    :goto_6
    const/4 v10, 0x2

    if-ltz v8, :cond_b

    .line 622
    iget-object v11, v0, Lnet/duceng/xmidi/util/StyleEngine;->lateOffs:Ljava/util/ArrayList;

    invoke-virtual {v11, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, [J

    .line 623
    .local v11, "o":[J
    aget-wide v12, v11, v9

    long-to-int v9, v12

    shl-int/lit8 v9, v9, 0x7

    aget-wide v12, v11, v10

    long-to-int v10, v12

    or-int/2addr v9, v10

    aget-boolean v9, v6, v9

    if-eqz v9, :cond_a

    .line 624
    iget-object v9, v0, Lnet/duceng/xmidi/util/StyleEngine;->lateOffs:Ljava/util/ArrayList;

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 621
    .end local v11    # "o":[J
    :cond_a
    add-int/lit8 v8, v8, -0x1

    const/4 v9, 0x1

    goto :goto_6

    .line 627
    .end local v8    # "i":I
    :cond_b
    const/4 v8, 0x0

    .local v8, "ch":I
    :goto_7
    const/16 v9, 0x10

    if-ge v8, v9, :cond_10

    .line 628
    const/16 v9, 0x9

    if-ne v8, v9, :cond_c

    .line 629
    move-wide/from16 v17, v3

    move-object/from16 v19, v5

    const/4 v9, 0x2

    const/4 v14, 0x1

    const/16 v16, 0x0

    goto/16 :goto_a

    .line 631
    :cond_c
    const/4 v11, 0x0

    .local v11, "n":I
    :goto_8
    const/16 v12, 0x80

    if-ge v11, v12, :cond_f

    .line 632
    shl-int/lit8 v12, v8, 0x7

    or-int/2addr v12, v11

    .line 633
    .local v12, "k2":I
    aget-boolean v13, v5, v12

    if-eqz v13, :cond_e

    aget-boolean v13, v6, v12

    if-nez v13, :cond_e

    .line 634
    if-eqz v7, :cond_d

    .line 636
    iget-object v13, v0, Lnet/duceng/xmidi/util/StyleEngine;->lateOffs:Ljava/util/ArrayList;

    const-wide/32 v14, 0x2160ec0

    add-long/2addr v14, v1

    int-to-long v9, v8

    move-wide/from16 v17, v3

    .end local v3    # "velScale":D
    .local v17, "velScale":D
    int-to-long v3, v11

    move-object/from16 v19, v5

    .end local v5    # "old":[Z
    .local v19, "old":[Z
    const/4 v5, 0x4

    new-array v5, v5, [J

    const/16 v16, 0x0

    aput-wide v14, v5, v16

    const/4 v14, 0x1

    aput-wide v9, v5, v14

    const/4 v9, 0x2

    aput-wide v3, v5, v9

    const/4 v3, 0x3

    aput-wide v1, v5, v3

    invoke-virtual {v13, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_9

    .line 638
    .end local v17    # "velScale":D
    .end local v19    # "old":[Z
    .restart local v3    # "velScale":D
    .restart local v5    # "old":[Z
    :cond_d
    move-wide/from16 v17, v3

    move-object/from16 v19, v5

    const/4 v9, 0x2

    const/4 v14, 0x1

    const/16 v16, 0x0

    .end local v3    # "velScale":D
    .end local v5    # "old":[Z
    .restart local v17    # "velScale":D
    .restart local v19    # "old":[Z
    iget-object v3, v0, Lnet/duceng/xmidi/util/StyleEngine;->sounding:[Z

    aput-boolean v16, v3, v12

    .line 639
    iget-object v3, v0, Lnet/duceng/xmidi/util/StyleEngine;->sink:Lnet/duceng/xmidi/util/StyleEngine$Sink;

    new-instance v4, Lnet/duceng/midi/EventChannel;

    int-to-byte v5, v8

    int-to-byte v10, v11

    const/16 v25, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x8

    move-object/from16 v20, v4

    move/from16 v23, v5

    move/from16 v24, v10

    invoke-direct/range {v20 .. v25}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    invoke-interface {v3, v4}, Lnet/duceng/xmidi/util/StyleEngine$Sink;->send(Lnet/duceng/midi/EventChannel;)V

    goto :goto_9

    .line 633
    .end local v17    # "velScale":D
    .end local v19    # "old":[Z
    .restart local v3    # "velScale":D
    .restart local v5    # "old":[Z
    :cond_e
    move-wide/from16 v17, v3

    move-object/from16 v19, v5

    const/4 v9, 0x2

    const/4 v14, 0x1

    const/16 v16, 0x0

    .line 631
    .end local v3    # "velScale":D
    .end local v5    # "old":[Z
    .end local v12    # "k2":I
    .restart local v17    # "velScale":D
    .restart local v19    # "old":[Z
    :goto_9
    add-int/lit8 v11, v11, 0x1

    move-wide/from16 v3, v17

    move-object/from16 v5, v19

    const/16 v9, 0x9

    const/4 v10, 0x2

    goto :goto_8

    .end local v17    # "velScale":D
    .end local v19    # "old":[Z
    .restart local v3    # "velScale":D
    .restart local v5    # "old":[Z
    :cond_f
    move-wide/from16 v17, v3

    move-object/from16 v19, v5

    const/4 v9, 0x2

    const/4 v14, 0x1

    const/16 v16, 0x0

    .line 627
    .end local v3    # "velScale":D
    .end local v5    # "old":[Z
    .end local v11    # "n":I
    .restart local v17    # "velScale":D
    .restart local v19    # "old":[Z
    :goto_a
    add-int/lit8 v8, v8, 0x1

    move-wide/from16 v3, v17

    move-object/from16 v5, v19

    const/4 v10, 0x2

    goto/16 :goto_7

    .line 644
    .end local v8    # "ch":I
    .end local v17    # "velScale":D
    .end local v19    # "old":[Z
    .restart local v3    # "velScale":D
    .restart local v5    # "old":[Z
    :cond_10
    return-void
.end method

.method private sendChanged(Ljava/util/Map;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lnet/duceng/midi/EventChannel;",
            ">;)V"
        }
    .end annotation

    .line 447
    .local p1, "m":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Lnet/duceng/midi/EventChannel;>;"
    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 448
    .local v1, "en":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Lnet/duceng/midi/EventChannel;>;"
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastSent:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    .line 449
    .local v2, "old":Ljava/lang/Integer;
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/EventChannel;

    invoke-static {v3}, Lnet/duceng/xmidi/util/StyleEngine;->valueOf(Lnet/duceng/midi/EventChannel;)I

    move-result v3

    .line 450
    .local v3, "v":I
    if-eqz v2, :cond_0

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v4

    if-eq v4, v3, :cond_1

    .line 451
    :cond_0
    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->lastSent:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 452
    iget-object v4, p0, Lnet/duceng/xmidi/util/StyleEngine;->sink:Lnet/duceng/xmidi/util/StyleEngine$Sink;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/midi/EventChannel;

    invoke-interface {v4, v5}, Lnet/duceng/xmidi/util/StyleEngine$Sink;->send(Lnet/duceng/midi/EventChannel;)V

    .line 454
    .end local v1    # "en":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/String;Lnet/duceng/midi/EventChannel;>;"
    .end local v2    # "old":Ljava/lang/Integer;
    .end local v3    # "v":I
    :cond_1
    goto :goto_0

    .line 455
    :cond_2
    return-void
.end method

.method private silenceMelodic()V
    .locals 11

    .line 763
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->lateOffs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 764
    const/4 v0, 0x0

    .local v0, "ch":I
    :goto_0
    const/16 v1, 0x10

    if-ge v0, v1, :cond_3

    .line 765
    const/16 v1, 0x9

    if-ne v0, v1, :cond_0

    .line 766
    goto :goto_2

    .line 768
    :cond_0
    const/4 v1, 0x0

    .local v1, "n":I
    :goto_1
    const/16 v2, 0x80

    if-ge v1, v2, :cond_2

    .line 769
    shl-int/lit8 v2, v0, 0x7

    or-int/2addr v2, v1

    .line 770
    .local v2, "k":I
    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->sounding:[Z

    aget-boolean v3, v3, v2

    if-eqz v3, :cond_1

    .line 771
    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->sounding:[Z

    const/4 v4, 0x0

    aput-boolean v4, v3, v2

    .line 772
    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->sink:Lnet/duceng/xmidi/util/StyleEngine$Sink;

    new-instance v10, Lnet/duceng/midi/EventChannel;

    int-to-byte v7, v0

    int-to-byte v8, v1

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/16 v6, 0x8

    move-object v4, v10

    invoke-direct/range {v4 .. v9}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    invoke-interface {v3, v10}, Lnet/duceng/xmidi/util/StyleEngine$Sink;->send(Lnet/duceng/midi/EventChannel;)V

    .line 768
    .end local v2    # "k":I
    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 764
    .end local v1    # "n":I
    :cond_2
    :goto_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 776
    .end local v0    # "ch":I
    :cond_3
    return-void
.end method

.method private static valueOf(Lnet/duceng/midi/EventChannel;)I
    .locals 2
    .param p0, "e"    # Lnet/duceng/midi/EventChannel;

    .line 169
    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getType()B

    move-result v0

    const/16 v1, 0xc

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getValue1()B

    move-result v0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->getValue2()B

    move-result v0

    :goto_0
    return v0
.end method

.method private wake()V
    .locals 1

    .line 227
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->thread:Ljava/lang/Thread;

    .line 228
    .local v0, "t":Ljava/lang/Thread;
    if-eqz v0, :cond_0

    .line 229
    invoke-static {v0}, Ljava/util/concurrent/locks/LockSupport;->unpark(Ljava/lang/Thread;)V

    .line 231
    :cond_0
    return-void
.end method


# virtual methods
.method public isMetronomeOn()Z
    .locals 1

    .line 161
    iget-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroOn:Z

    return v0
.end method

.method public isRunning()Z
    .locals 1

    .line 117
    iget-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->running:Z

    return v0
.end method

.method public requestSection(Ljava/lang/String;)V
    .locals 1
    .param p1, "name"    # Ljava/lang/String;

    .line 197
    new-instance v0, Lnet/duceng/xmidi/util/StyleEngine$3;

    invoke-direct {v0, p0, p1}, Lnet/duceng/xmidi/util/StyleEngine$3;-><init>(Lnet/duceng/xmidi/util/StyleEngine;Ljava/lang/String;)V

    invoke-direct {p0, v0}, Lnet/duceng/xmidi/util/StyleEngine;->post(Ljava/lang/Runnable;)V

    .line 203
    return-void
.end method

.method public run()V
    .locals 14

    .line 294
    const/4 v0, 0x0

    :try_start_0
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    .line 295
    .local v1, "last":J
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->drain()V

    .line 296
    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->startName:Ljava/lang/String;

    invoke-direct {p0, v3}, Lnet/duceng/xmidi/util/StyleEngine;->begin(Ljava/lang/String;)V

    .line 297
    :goto_0
    iget-boolean v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->running:Z

    if-eqz v3, :cond_6

    iget-object v3, p0, Lnet/duceng/xmidi/util/StyleEngine;->section:Lnet/duceng/midi/StySection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    if-eqz v3, :cond_6

    .line 299
    :try_start_1
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->drain()V

    .line 300
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v3

    .line 301
    .local v3, "now":J
    iget-object v5, p0, Lnet/duceng/xmidi/util/StyleEngine;->host:Lnet/duceng/xmidi/util/StyleEngine$Host;

    invoke-interface {v5}, Lnet/duceng/xmidi/util/StyleEngine$Host;->mpqn()I

    move-result v5

    .line 302
    .local v5, "mpqn":I
    if-gtz v5, :cond_0

    .line 303
    const v5, 0x7a120

    .line 305
    :cond_0
    iget-wide v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    sub-long v8, v3, v1

    long-to-double v8, v8

    iget v10, p0, Lnet/duceng/xmidi/util/StyleEngine;->res:I

    int-to-double v10, v10

    mul-double v8, v8, v10

    int-to-double v10, v5

    const-wide v12, 0x408f400000000000L    # 1000.0

    mul-double v10, v10, v12

    div-double/2addr v8, v10

    add-double/2addr v6, v8

    iput-wide v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    .line 306
    move-wide v1, v3

    .line 307
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->fireDue()V

    .line 308
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->fireMetronome()V

    .line 309
    invoke-direct {p0, v3, v4}, Lnet/duceng/xmidi/util/StyleEngine;->fireLateOffs(J)V

    .line 310
    iget-wide v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    iget v8, p0, Lnet/duceng/xmidi/util/StyleEngine;->barTicks:I

    int-to-double v8, v8

    cmpl-double v10, v6, v8

    if-ltz v10, :cond_1

    .line 311
    iget-wide v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    iget v8, p0, Lnet/duceng/xmidi/util/StyleEngine;->barTicks:I

    int-to-double v8, v8

    sub-double/2addr v6, v8

    iput-wide v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    .line 312
    const-wide/16 v6, 0x0

    iput-wide v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->nextBeatTick:D

    .line 313
    iput v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->beatCount:I

    .line 314
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->advanceBar()V

    .line 315
    goto :goto_0

    .line 317
    :cond_1
    iget v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    iget-object v7, p0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_2

    iget-object v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->bar:Ljava/util/ArrayList;

    iget v7, p0, Lnet/duceng/xmidi/util/StyleEngine;->cursor:I

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/midi/EventChannel;

    invoke-virtual {v6}, Lnet/duceng/midi/EventChannel;->getTick()I

    move-result v6

    int-to-double v6, v6

    goto :goto_1

    :cond_2
    iget v6, p0, Lnet/duceng/xmidi/util/StyleEngine;->barTicks:I

    int-to-double v6, v6

    .line 318
    .local v6, "next":D
    :goto_1
    iget v8, p0, Lnet/duceng/xmidi/util/StyleEngine;->barTicks:I

    int-to-double v8, v8

    cmpl-double v10, v6, v8

    if-lez v10, :cond_3

    .line 319
    iget v8, p0, Lnet/duceng/xmidi/util/StyleEngine;->barTicks:I

    int-to-double v6, v8

    .line 321
    :cond_3
    iget-wide v8, p0, Lnet/duceng/xmidi/util/StyleEngine;->tickPos:D

    sub-double v8, v6, v8

    int-to-double v10, v5

    mul-double v8, v8, v10

    mul-double v8, v8, v12

    iget v10, p0, Lnet/duceng/xmidi/util/StyleEngine;->res:I

    int-to-double v10, v10

    div-double/2addr v8, v10

    double-to-long v8, v8

    .line 322
    .local v8, "ns":J
    const-wide/16 v10, 0x4e20

    cmp-long v12, v8, v10

    if-gez v12, :cond_4

    .line 323
    const-wide/16 v8, 0x4e20

    .line 325
    :cond_4
    const-wide/32 v10, 0x4c4b40

    cmp-long v12, v8, v10

    if-lez v12, :cond_5

    .line 326
    const-wide/32 v8, 0x4c4b40

    .line 328
    :cond_5
    invoke-static {v8, v9}, Ljava/util/concurrent/locks/LockSupport;->parkNanos(J)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .end local v3    # "now":J
    .end local v5    # "mpqn":I
    .end local v6    # "next":D
    .end local v8    # "ns":J
    goto :goto_2

    .line 329
    :catchall_0
    move-exception v3

    .line 330
    .local v3, "t":Ljava/lang/Throwable;
    :try_start_2
    sget-object v4, Ljava/lang/System;->err:Ljava/io/PrintStream;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "StyleEngine: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 331
    iput-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->running:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 332
    .end local v3    # "t":Ljava/lang/Throwable;
    :goto_2
    goto/16 :goto_0

    .line 335
    .end local v1    # "last":J
    :cond_6
    iput-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->running:Z

    .line 337
    :try_start_3
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->resetAutomation()V

    .line 338
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sink:Lnet/duceng/xmidi/util/StyleEngine$Sink;

    invoke-interface {v1}, Lnet/duceng/xmidi/util/StyleEngine$Sink;->silence()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 341
    goto :goto_3

    .line 339
    :catchall_1
    move-exception v1

    .line 342
    :goto_3
    iget-object v1, p0, Lnet/duceng/xmidi/util/StyleEngine;->sounding:[Z

    invoke-static {v1, v0}, Ljava/util/Arrays;->fill([ZZ)V

    .line 343
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->lateOffs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 344
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->listener:Lnet/duceng/xmidi/util/StyleEngine$Listener;

    .line 345
    .local v0, "l":Lnet/duceng/xmidi/util/StyleEngine$Listener;
    if-eqz v0, :cond_7

    .line 346
    invoke-interface {v0}, Lnet/duceng/xmidi/util/StyleEngine$Listener;->onStopped()V

    .line 348
    .end local v0    # "l":Lnet/duceng/xmidi/util/StyleEngine$Listener;
    :cond_7
    nop

    .line 349
    return-void

    .line 335
    :catchall_2
    move-exception v1

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->running:Z

    .line 337
    :try_start_4
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->resetAutomation()V

    .line 338
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->sink:Lnet/duceng/xmidi/util/StyleEngine$Sink;

    invoke-interface {v2}, Lnet/duceng/xmidi/util/StyleEngine$Sink;->silence()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 341
    goto :goto_4

    .line 339
    :catchall_3
    move-exception v2

    .line 342
    :goto_4
    iget-object v2, p0, Lnet/duceng/xmidi/util/StyleEngine;->sounding:[Z

    invoke-static {v2, v0}, Ljava/util/Arrays;->fill([ZZ)V

    .line 343
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->lateOffs:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 344
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->listener:Lnet/duceng/xmidi/util/StyleEngine$Listener;

    .line 345
    .restart local v0    # "l":Lnet/duceng/xmidi/util/StyleEngine$Listener;
    if-eqz v0, :cond_8

    .line 346
    invoke-interface {v0}, Lnet/duceng/xmidi/util/StyleEngine$Listener;->onStopped()V

    .line 348
    .end local v0    # "l":Lnet/duceng/xmidi/util/StyleEngine$Listener;
    :cond_8
    throw v1
.end method

.method public setBaseSetup(Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lnet/duceng/midi/EventChannel;",
            ">;)V"
        }
    .end annotation

    .line 139
    .local p1, "events":Ljava/util/List;, "Ljava/util/List<Lnet/duceng/midi/EventChannel;>;"
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 140
    .local v0, "copy":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    new-instance v1, Lnet/duceng/xmidi/util/StyleEngine$1;

    invoke-direct {v1, p0, v0}, Lnet/duceng/xmidi/util/StyleEngine$1;-><init>(Lnet/duceng/xmidi/util/StyleEngine;Ljava/util/ArrayList;)V

    invoke-direct {p0, v1}, Lnet/duceng/xmidi/util/StyleEngine;->post(Ljava/lang/Runnable;)V

    .line 151
    return-void
.end method

.method public setChord(Lnet/duceng/xmidi/util/Chords$Chord;)V
    .locals 1
    .param p1, "c"    # Lnet/duceng/xmidi/util/Chords$Chord;

    .line 187
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine;->chordV:Lnet/duceng/xmidi/util/Chords$Chord;

    .line 188
    new-instance v0, Lnet/duceng/xmidi/util/StyleEngine$2;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/util/StyleEngine$2;-><init>(Lnet/duceng/xmidi/util/StyleEngine;)V

    invoke-direct {p0, v0}, Lnet/duceng/xmidi/util/StyleEngine;->post(Ljava/lang/Runnable;)V

    .line 194
    return-void
.end method

.method public setListener(Lnet/duceng/xmidi/util/StyleEngine$Listener;)V
    .locals 0
    .param p1, "l"    # Lnet/duceng/xmidi/util/StyleEngine$Listener;

    .line 113
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine;->listener:Lnet/duceng/xmidi/util/StyleEngine$Listener;

    .line 114
    return-void
.end method

.method public setMetronome(ZIII)V
    .locals 0
    .param p1, "on"    # Z
    .param p2, "accentNote"    # I
    .param p3, "note"    # I
    .param p4, "vel"    # I

    .line 154
    iput p2, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroNoteAccent:I

    .line 155
    iput p3, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroNote:I

    .line 156
    iput p4, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroVel:I

    .line 157
    iput-boolean p1, p0, Lnet/duceng/xmidi/util/StyleEngine;->metroOn:Z

    .line 158
    return-void
.end method

.method public declared-synchronized start(Ljava/lang/String;)V
    .locals 2
    .param p1, "sectionName"    # Ljava/lang/String;

    monitor-enter p0

    .line 121
    :try_start_0
    iget-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->running:Z

    if-eqz v0, :cond_0

    .line 122
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/util/StyleEngine;->requestSection(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 123
    monitor-exit p0

    return-void

    .line 125
    .end local p0    # "this":Lnet/duceng/xmidi/util/StyleEngine;
    :cond_0
    :try_start_1
    iput-object p1, p0, Lnet/duceng/xmidi/util/StyleEngine;->startName:Ljava/lang/String;

    .line 126
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->running:Z

    .line 127
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->factory:Ljava/util/concurrent/ThreadFactory;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->factory:Ljava/util/concurrent/ThreadFactory;

    invoke-interface {v0, p0}, Ljava/util/concurrent/ThreadFactory;->newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;

    move-result-object v0

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/Thread;

    const-string v1, "StyleEngine"

    invoke-direct {v0, p0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 128
    .local v0, "t":Ljava/lang/Thread;
    :goto_0
    iput-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->thread:Ljava/lang/Thread;

    .line 129
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 130
    monitor-exit p0

    return-void

    .line 120
    .end local v0    # "t":Ljava/lang/Thread;
    .end local p1    # "sectionName":Ljava/lang/String;
    :catchall_0
    move-exception p1

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

.method public stop()V
    .locals 1

    .line 133
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->running:Z

    .line 134
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->wake()V

    .line 135
    return-void
.end method

.method public stopAndWait(J)V
    .locals 3
    .param p1, "ms"    # J

    .line 174
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->running:Z

    .line 175
    iget-object v0, p0, Lnet/duceng/xmidi/util/StyleEngine;->thread:Ljava/lang/Thread;

    .line 176
    .local v0, "t":Ljava/lang/Thread;
    invoke-direct {p0}, Lnet/duceng/xmidi/util/StyleEngine;->wake()V

    .line 177
    if-eqz v0, :cond_0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    if-eq v0, v1, :cond_0

    .line 179
    :try_start_0
    invoke-virtual {v0, p1, p2}, Ljava/lang/Thread;->join(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 182
    goto :goto_0

    .line 180
    :catch_0
    move-exception v1

    .line 181
    .local v1, "e":Ljava/lang/InterruptedException;
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    .line 184
    .end local v1    # "e":Ljava/lang/InterruptedException;
    :cond_0
    :goto_0
    return-void
.end method

.method public sync()V
    .locals 1

    .line 207
    new-instance v0, Lnet/duceng/xmidi/util/StyleEngine$4;

    invoke-direct {v0, p0}, Lnet/duceng/xmidi/util/StyleEngine$4;-><init>(Lnet/duceng/xmidi/util/StyleEngine;)V

    invoke-direct {p0, v0}, Lnet/duceng/xmidi/util/StyleEngine;->post(Ljava/lang/Runnable;)V

    .line 219
    return-void
.end method

# Instrumentos que se sostienen (organos, bajos, cuerdas, metales, cañas, pads): al cambiar de
# acorde sus notas largas se vuelven a tocar con el acorde nuevo aunque la regla del estilo diga "stop".
.method static xmSustains(I)Z
    .locals 3

    invoke-static {p0}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetBank(I)I

    move-result v0

    const/16 v1, 0x80

    if-eq v0, v1, :xm_no

    invoke-static {p0}, Lnet/duceng/xsynth/XSynth;->midiPlayerGetPreset(I)I

    move-result v0

    const/16 v1, 0x10

    if-lt v0, v1, :xm_no

    const/16 v1, 0x18

    if-lt v0, v1, :xm_yes

    const/16 v1, 0x20

    if-lt v0, v1, :xm_no

    const/16 v1, 0x28

    if-lt v0, v1, :xm_yes

    const/16 v1, 0x2d

    if-lt v0, v1, :xm_yes

    const/16 v1, 0x30

    if-lt v0, v1, :xm_no

    const/16 v1, 0x37

    if-lt v0, v1, :xm_yes

    const/16 v1, 0x38

    if-lt v0, v1, :xm_no

    const/16 v1, 0x60

    if-lt v0, v1, :xm_yes

    :xm_no
    const/4 v0, 0x0

    return v0

    :xm_yes
    const/4 v0, 0x1

    return v0
.end method
