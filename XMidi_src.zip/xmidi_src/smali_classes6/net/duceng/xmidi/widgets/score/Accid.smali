.class public final enum Lnet/duceng/xmidi/widgets/score/Accid;
.super Ljava/lang/Enum;
.source "Accid.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lnet/duceng/xmidi/widgets/score/Accid;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lnet/duceng/xmidi/widgets/score/Accid;

.field public static final enum Flat:Lnet/duceng/xmidi/widgets/score/Accid;

.field public static final enum Natural:Lnet/duceng/xmidi/widgets/score/Accid;

.field public static final enum None:Lnet/duceng/xmidi/widgets/score/Accid;

.field public static final enum Sharp:Lnet/duceng/xmidi/widgets/score/Accid;


# direct methods
.method private static synthetic $values()[Lnet/duceng/xmidi/widgets/score/Accid;
    .locals 3

    .line 4
    const/4 v0, 0x4

    new-array v0, v0, [Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v2, 0x1

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v2, 0x2

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v2, 0x3

    aput-object v1, v0, v2

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 5
    new-instance v0, Lnet/duceng/xmidi/widgets/score/Accid;

    const-string v1, "None"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/Accid;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    .line 6
    new-instance v0, Lnet/duceng/xmidi/widgets/score/Accid;

    const-string v1, "Sharp"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/Accid;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    .line 7
    new-instance v0, Lnet/duceng/xmidi/widgets/score/Accid;

    const-string v1, "Flat"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/Accid;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    .line 8
    new-instance v0, Lnet/duceng/xmidi/widgets/score/Accid;

    const-string v1, "Natural"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/Accid;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    .line 4
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/Accid;->$values()[Lnet/duceng/xmidi/widgets/score/Accid;

    move-result-object v0

    sput-object v0, Lnet/duceng/xmidi/widgets/score/Accid;->$VALUES:[Lnet/duceng/xmidi/widgets/score/Accid;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 4
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lnet/duceng/xmidi/widgets/score/Accid;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .line 4
    const-class v0, Lnet/duceng/xmidi/widgets/score/Accid;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/widgets/score/Accid;

    return-object v0
.end method

.method public static values()[Lnet/duceng/xmidi/widgets/score/Accid;
    .locals 1

    .line 4
    sget-object v0, Lnet/duceng/xmidi/widgets/score/Accid;->$VALUES:[Lnet/duceng/xmidi/widgets/score/Accid;

    invoke-virtual {v0}, [Lnet/duceng/xmidi/widgets/score/Accid;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lnet/duceng/xmidi/widgets/score/Accid;

    return-object v0
.end method

.method public static valuesCustom()[Lnet/duceng/xmidi/widgets/score/Accid;
    .locals 4

    .line 12
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/Accid;->values()[Lnet/duceng/xmidi/widgets/score/Accid;

    move-result-object v0

    .line 13
    .local v0, "accidArrValuesCustom":[Lnet/duceng/xmidi/widgets/score/Accid;
    array-length v1, v0

    .line 14
    .local v1, "length":I
    new-array v2, v1, [Lnet/duceng/xmidi/widgets/score/Accid;

    .line 15
    .local v2, "accidArr":[Lnet/duceng/xmidi/widgets/score/Accid;
    const/4 v3, 0x0

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 16
    return-object v2
.end method
