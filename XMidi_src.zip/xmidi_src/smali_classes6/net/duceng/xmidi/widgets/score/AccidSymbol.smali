.class public Lnet/duceng/xmidi/widgets/score/AccidSymbol;
.super Ljava/lang/Object;
.source "AccidSymbol.java"

# interfaces
.implements Lnet/duceng/xmidi/widgets/score/MusicSymbol;


# instance fields
.field private accid:Lnet/duceng/xmidi/widgets/score/Accid;

.field private clef:Lnet/duceng/xmidi/widgets/score/Clef;

.field private whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

.field private width:I


# direct methods
.method public constructor <init>(Lnet/duceng/xmidi/widgets/score/Accid;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/Clef;)V
    .locals 1
    .param p1, "accid"    # Lnet/duceng/xmidi/widgets/score/Accid;
    .param p2, "note"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .param p3, "clef"    # Lnet/duceng/xmidi/widgets/score/Clef;

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getMinWidth()I

    move-result v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->width:I

    .line 15
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    .line 16
    iput-object p2, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 17
    iput-object p3, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    .line 18
    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 4
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 72
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getMinWidth()I

    move-result v1

    sub-int/2addr v0, v1

    int-to-float v0, v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 73
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-static {v0}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Top(Lnet/duceng/xmidi/widgets/score/Clef;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v0, v2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v0

    mul-int/lit8 v0, v0, 0x8

    div-int/lit8 v0, v0, 0x2

    add-int/2addr v0, p3

    .line 74
    .local v0, "ynote":I
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v2, v3, :cond_0

    .line 75
    invoke-virtual {p0, p1, p2, v0}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->drawSharp(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    goto :goto_0

    .line 76
    :cond_0
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v2, v3, :cond_1

    .line 77
    invoke-virtual {p0, p1, p2, v0}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->drawFlat(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    goto :goto_0

    .line 78
    :cond_1
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v2, v3, :cond_2

    .line 79
    invoke-virtual {p0, p1, p2, v0}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->drawNatural(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    .line 81
    :cond_2
    :goto_0
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getWidth()I

    move-result v2

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getMinWidth()I

    move-result v3

    sub-int/2addr v2, v3

    neg-int v2, v2

    int-to-float v2, v2

    invoke-virtual {p1, v2, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 82
    return-void
.end method

.method public drawFlat(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 11
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ynote"    # I

    .line 100
    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 101
    add-int/lit8 v1, p3, -0x8

    add-int/lit8 v1, v1, -0x4

    int-to-float v4, v1

    add-int/lit8 v1, p3, 0x8

    int-to-float v6, v1

    const/high16 v3, 0x3f800000    # 1.0f

    const/high16 v5, 0x3f800000    # 1.0f

    move-object v2, p1

    move-object v7, p2

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 102
    new-instance v1, Landroid/graphics/Path;

    invoke-direct {v1}, Landroid/graphics/Path;-><init>()V

    .line 103
    .local v1, "bezierPath":Landroid/graphics/Path;
    add-int/lit8 v2, p3, 0x1

    int-to-float v2, v2

    invoke-virtual {v1, v0, v2}, Landroid/graphics/Path;->moveTo(FF)V

    .line 104
    add-int/lit8 v2, p3, -0x3

    int-to-float v4, v2

    add-int/lit8 v2, p3, 0x2

    int-to-float v6, v2

    add-int/lit8 v2, p3, 0x7

    add-int/lit8 v2, v2, 0x1

    add-int/lit8 v2, v2, 0x1

    int-to-float v8, v2

    const/high16 v3, 0x40800000    # 4.0f

    const/high16 v5, 0x41000000    # 8.0f

    const/high16 v7, 0x3f800000    # 1.0f

    move-object v2, v1

    invoke-virtual/range {v2 .. v8}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 105
    invoke-virtual {p1, v1, p2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 106
    new-instance v2, Landroid/graphics/Path;

    invoke-direct {v2}, Landroid/graphics/Path;-><init>()V

    .line 107
    .local v2, "bezierPath2":Landroid/graphics/Path;
    add-int/lit8 v3, p3, 0x1

    int-to-float v3, v3

    invoke-virtual {v2, v0, v3}, Landroid/graphics/Path;->moveTo(FF)V

    .line 108
    add-int/lit8 v3, p3, -0x3

    int-to-float v5, v3

    add-int/lit8 v3, p3, 0x2

    add-int/lit8 v3, v3, -0x1

    int-to-float v7, v3

    add-int/lit8 v3, p3, 0x7

    add-int/lit8 v3, v3, 0x1

    add-int/lit8 v3, v3, 0x1

    int-to-float v9, v3

    const/high16 v4, 0x40800000    # 4.0f

    const/high16 v6, 0x41100000    # 9.0f

    const/high16 v8, 0x3f800000    # 1.0f

    move-object v3, v2

    invoke-virtual/range {v3 .. v9}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 109
    invoke-virtual {p1, v2, p2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 110
    new-instance v3, Landroid/graphics/Path;

    invoke-direct {v3}, Landroid/graphics/Path;-><init>()V

    .line 111
    .local v3, "bezierPath3":Landroid/graphics/Path;
    add-int/lit8 v4, p3, 0x1

    int-to-float v4, v4

    invoke-virtual {v3, v0, v4}, Landroid/graphics/Path;->moveTo(FF)V

    .line 112
    add-int/lit8 v0, p3, -0x3

    int-to-float v6, v0

    add-int/lit8 v0, p3, 0x2

    add-int/lit8 v0, v0, -0x3

    int-to-float v8, v0

    add-int/lit8 v0, p3, 0x7

    add-int/lit8 v0, v0, 0x1

    add-int/lit8 v0, v0, 0x1

    int-to-float v10, v0

    const/high16 v5, 0x40800000    # 4.0f

    const/high16 v7, 0x41300000    # 11.0f

    const/high16 v9, 0x3f800000    # 1.0f

    move-object v4, v3

    invoke-virtual/range {v4 .. v10}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 113
    invoke-virtual {p1, v3, p2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 114
    return-void
.end method

.method public drawNatural(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 16
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ynote"    # I

    .line 117
    move-object/from16 v6, p2

    add-int/lit8 v0, p3, -0x7

    add-int/lit8 v7, v0, -0x1

    .line 118
    .local v7, "ystart":I
    add-int/lit8 v0, p3, 0x7

    add-int/lit8 v8, v0, 0x1

    .line 119
    .local v8, "yend":I
    const/high16 v9, 0x3f800000    # 1.0f

    invoke-virtual {v6, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 120
    int-to-float v2, v7

    const/high16 v3, 0x40400000    # 3.0f

    int-to-float v4, v8

    const/high16 v1, 0x40400000    # 3.0f

    move-object/from16 v0, p1

    move-object/from16 v5, p2

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 121
    const/16 v10, 0x9

    .line 122
    .local v10, "x":I
    add-int/lit8 v11, p3, -0x1

    .line 123
    .local v11, "ystart2":I
    add-int/lit8 v0, p3, 0xe

    add-int/lit8 v0, v0, 0x1

    add-int/lit8 v12, v0, -0x1

    .line 124
    .local v12, "yend2":I
    int-to-float v1, v10

    int-to-float v2, v11

    int-to-float v3, v10

    int-to-float v4, v12

    move-object/from16 v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 125
    const/16 v13, 0x9

    .line 126
    .local v13, "xend":I
    add-int/lit8 v14, p3, 0x1

    .line 127
    .local v14, "ystart3":I
    add-int/lit8 v0, v14, -0x1

    add-int/lit8 v15, v0, -0x1

    .line 128
    .local v15, "yend3":I
    const/high16 v0, 0x40400000    # 3.0f

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 129
    int-to-float v2, v14

    int-to-float v3, v13

    int-to-float v4, v15

    const/high16 v1, 0x40400000    # 3.0f

    move-object/from16 v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 130
    add-int/lit8 v0, v14, 0x7

    int-to-float v2, v0

    int-to-float v3, v13

    add-int/lit8 v0, v15, 0x7

    int-to-float v4, v0

    move-object/from16 v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 131
    invoke-virtual {v6, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 132
    return-void
.end method

.method public drawSharp(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 13
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ynote"    # I

    .line 85
    move-object v6, p2

    add-int/lit8 v7, p3, -0x8

    .line 86
    .local v7, "ystart":I
    add-int/lit8 v8, p3, 0x10

    .line 87
    .local v8, "yend":I
    const/high16 v9, 0x3f800000    # 1.0f

    invoke-virtual {p2, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 88
    add-int/lit8 v0, v7, 0x2

    int-to-float v2, v0

    const/high16 v3, 0x40800000    # 4.0f

    int-to-float v4, v8

    const/high16 v1, 0x40800000    # 4.0f

    move-object v0, p1

    move-object v5, p2

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 89
    const/16 v10, 0x8

    .line 90
    .local v10, "x":I
    int-to-float v1, v10

    int-to-float v2, v7

    int-to-float v3, v10

    add-int/lit8 v0, v8, -0x2

    int-to-float v4, v0

    move-object v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 91
    add-int/lit8 v11, p3, 0x1

    .line 92
    .local v11, "ystart2":I
    add-int/lit8 v0, v11, -0x1

    add-int/lit8 v12, v0, -0x1

    .line 93
    .local v12, "yend2":I
    const/high16 v0, 0x40400000    # 3.0f

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 94
    int-to-float v2, v11

    const/high16 v3, 0x41200000    # 10.0f

    int-to-float v4, v12

    const/high16 v1, 0x40000000    # 2.0f

    move-object v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 95
    add-int/lit8 v0, v11, 0x7

    int-to-float v2, v0

    add-int/lit8 v0, v12, 0x7

    int-to-float v4, v0

    move-object v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 96
    invoke-virtual {p2, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 97
    return-void
.end method

.method public getAboveStaff()I
    .locals 3

    .line 46
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-static {v0}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Top(Lnet/duceng/xmidi/widgets/score/Clef;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v0

    mul-int/lit8 v0, v0, 0x8

    div-int/lit8 v0, v0, 0x2

    .line 47
    .local v0, "dist":I
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    if-eq v1, v2, :cond_1

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v1, v2, :cond_0

    goto :goto_0

    .line 49
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v1, v2, :cond_2

    .line 50
    add-int/lit8 v0, v0, -0xc

    goto :goto_1

    .line 48
    :cond_1
    :goto_0
    add-int/lit8 v0, v0, -0x8

    .line 52
    :cond_2
    :goto_1
    if-gez v0, :cond_3

    .line 53
    neg-int v1, v0

    return v1

    .line 55
    :cond_3
    const/4 v1, 0x0

    return v1
.end method

.method public getBelowStaff()I
    .locals 3

    .line 60
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-static {v0}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Bottom(Lnet/duceng/xmidi/widgets/score/Clef;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v0

    mul-int/lit8 v0, v0, 0x8

    div-int/lit8 v0, v0, 0x2

    add-int/lit8 v0, v0, 0x8

    .line 61
    .local v0, "dist":I
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    if-eq v1, v2, :cond_0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v1, v2, :cond_1

    .line 62
    :cond_0
    add-int/lit8 v0, v0, 0x8

    .line 64
    :cond_1
    if-lez v0, :cond_2

    .line 65
    return v0

    .line 67
    :cond_2
    const/4 v1, 0x0

    return v1
.end method

.method public getMinWidth()I
    .locals 1

    .line 31
    const/16 v0, 0xc

    return v0
.end method

.method public getNote()Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .locals 1

    .line 21
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    return-object v0
.end method

.method public getStartTime()I
    .locals 1

    .line 26
    const/4 v0, -0x1

    return v0
.end method

.method public getWidth()I
    .locals 1

    .line 36
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->width:I

    return v0
.end method

.method public setWidth(I)V
    .locals 0
    .param p1, "value"    # I

    .line 41
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->width:I

    .line 42
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 6

    .line 135
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    iget v3, p0, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->width:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x4

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    aput-object v0, v4, v5

    const/4 v0, 0x1

    aput-object v1, v4, v0

    const/4 v0, 0x2

    aput-object v2, v4, v0

    const/4 v0, 0x3

    aput-object v3, v4, v0

    const-string v0, "AccidSymbol accid={0} whitenote={1} clef={2} width={3}"

    invoke-static {v0, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
