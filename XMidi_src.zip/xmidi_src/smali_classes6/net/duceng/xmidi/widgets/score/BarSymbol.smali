.class public Lnet/duceng/xmidi/widgets/score/BarSymbol;
.super Ljava/lang/Object;
.source "BarSymbol.java"

# interfaces
.implements Lnet/duceng/xmidi/widgets/score/MusicSymbol;


# instance fields
.field private starttime:I

.field private width:I


# direct methods
.method public constructor <init>(I)V
    .locals 1
    .param p1, "starttime"    # I

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/BarSymbol;->getMinWidth()I

    move-result v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/BarSymbol;->width:I

    .line 12
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/BarSymbol;->starttime:I

    .line 13
    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 8
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 47
    add-int/lit8 v0, p3, 0x1c

    add-int/lit8 v0, v0, 0x4

    .line 48
    .local v0, "yend":I
    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 49
    int-to-float v4, p3

    const/high16 v5, 0x40a00000    # 5.0f

    int-to-float v6, v0

    const/high16 v3, 0x40a00000    # 5.0f

    move-object v2, p1

    move-object v7, p2

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 50
    return-void
.end method

.method public getAboveStaff()I
    .locals 1

    .line 37
    const/4 v0, 0x0

    return v0
.end method

.method public getBelowStaff()I
    .locals 1

    .line 42
    const/4 v0, 0x0

    return v0
.end method

.method public getMinWidth()I
    .locals 1

    .line 22
    const/16 v0, 0xe

    return v0
.end method

.method public getStartTime()I
    .locals 1

    .line 17
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/BarSymbol;->starttime:I

    return v0
.end method

.method public getWidth()I
    .locals 1

    .line 27
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/BarSymbol;->width:I

    return v0
.end method

.method public setWidth(I)V
    .locals 0
    .param p1, "value"    # I

    .line 32
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/BarSymbol;->width:I

    .line 33
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 53
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/BarSymbol;->starttime:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/BarSymbol;->width:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object v0, v2, v3

    const/4 v0, 0x1

    aput-object v1, v2, v0

    const-string v0, "BarSymbol starttime=%1$s width=%2$s"

    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
