.class public Lnet/duceng/xmidi/widgets/score/BlankSymbol;
.super Ljava/lang/Object;
.source "BlankSymbol.java"

# interfaces
.implements Lnet/duceng/xmidi/widgets/score/MusicSymbol;


# instance fields
.field private starttime:I

.field private width:I


# direct methods
.method public constructor <init>(II)V
    .locals 0
    .param p1, "starttime"    # I
    .param p2, "width"    # I

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/BlankSymbol;->starttime:I

    .line 13
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/BlankSymbol;->width:I

    .line 14
    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 0
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 48
    return-void
.end method

.method public getAboveStaff()I
    .locals 1

    .line 38
    const/4 v0, 0x0

    return v0
.end method

.method public getBelowStaff()I
    .locals 1

    .line 43
    const/4 v0, 0x0

    return v0
.end method

.method public getMinWidth()I
    .locals 1

    .line 23
    const/4 v0, 0x0

    return v0
.end method

.method public getStartTime()I
    .locals 1

    .line 18
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/BlankSymbol;->starttime:I

    return v0
.end method

.method public getWidth()I
    .locals 1

    .line 28
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/BlankSymbol;->width:I

    return v0
.end method

.method public setWidth(I)V
    .locals 0
    .param p1, "value"    # I

    .line 33
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/BlankSymbol;->width:I

    .line 34
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 51
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/BlankSymbol;->starttime:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/BlankSymbol;->width:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object v0, v2, v3

    const/4 v0, 0x1

    aput-object v1, v2, v0

    const-string v0, "BlankSymbol starttime=%1$s width=%2$s"

    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
