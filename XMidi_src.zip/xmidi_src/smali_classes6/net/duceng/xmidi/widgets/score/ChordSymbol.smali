.class public Lnet/duceng/xmidi/widgets/score/ChordSymbol;
.super Ljava/lang/Object;
.source "ChordSymbol.java"

# interfaces
.implements Lnet/duceng/xmidi/widgets/score/MusicSymbol;


# instance fields
.field private accidsymbols:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

.field private clef:Lnet/duceng/xmidi/widgets/score/Clef;

.field private endtime:I

.field private hastwostems:Z

.field private musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

.field private notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

.field private starttime:I

.field private stem1:Lnet/duceng/xmidi/widgets/score/Stem;

.field private stem2:Lnet/duceng/xmidi/widgets/score/Stem;

.field private width:I


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;Lnet/duceng/xmidi/widgets/score/Clef;Lnet/duceng/xmidi/widgets/MusicScore;)V
    .locals 18
    .param p2, "key"    # Lnet/duceng/xmidi/widgets/score/MidiKey;
    .param p3, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .param p4, "c"    # Lnet/duceng/xmidi/widgets/score/Clef;
    .param p5, "score"    # Lnet/duceng/xmidi/widgets/MusicScore;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Note;",
            ">;",
            "Lnet/duceng/xmidi/widgets/score/MidiKey;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            "Lnet/duceng/xmidi/widgets/score/Clef;",
            "Lnet/duceng/xmidi/widgets/MusicScore;",
            ")V"
        }
    .end annotation

    .line 22
    .local p1, "midinotes":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;"
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    .line 23
    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->size()I

    move-result v2

    .line 24
    .local v2, "len":I
    const/4 v3, 0x0

    iput-boolean v3, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->hastwostems:Z

    .line 25
    move-object/from16 v4, p4

    iput-object v4, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    .line 26
    move-object/from16 v5, p5

    iput-object v5, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    .line 27
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/Note;->getStartTick()I

    move-result v6

    iput v6, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->starttime:I

    .line 28
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/Note;->getEndTick()I

    move-result v6

    iput v6, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->endtime:I

    .line 29
    const/4 v6, 0x0

    .local v6, "i":I
    :goto_0
    const/4 v7, 0x1

    if-ge v6, v2, :cond_2

    .line 30
    if-le v6, v7, :cond_1

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v7}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v7

    add-int/lit8 v8, v6, -0x1

    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v8}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v8

    if-lt v7, v8, :cond_0

    goto :goto_1

    .line 31
    :cond_0
    new-instance v3, Ljava/lang/IllegalArgumentException;

    invoke-direct {v3}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v3

    .line 33
    :cond_1
    :goto_1
    iget v7, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->endtime:I

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v8}, Lnet/duceng/xmidi/widgets/score/Note;->getEndTick()I

    move-result v8

    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    move-result v7

    iput v7, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->endtime:I

    .line 29
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    .line 35
    .end local v6    # "i":I
    :cond_2
    invoke-static/range {p1 .. p3}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->createNoteData(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;)[Lnet/duceng/xmidi/widgets/score/NoteData;

    move-result-object v6

    iput-object v6, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    .line 36
    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-static {v6, v8}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->CreateAccidSymbols([Lnet/duceng/xmidi/widgets/score/NoteData;Lnet/duceng/xmidi/widgets/score/Clef;)[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    move-result-object v6

    iput-object v6, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->accidsymbols:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    .line 37
    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    aget-object v6, v6, v3

    iget-object v6, v6, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 38
    .local v6, "dur1":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    move-object v8, v6

    .line 39
    .local v8, "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    const/4 v9, -0x1

    .line 40
    .local v9, "change":I
    const/4 v10, 0x0

    .local v10, "i2":I
    :goto_2
    iget-object v11, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    array-length v11, v11

    if-ge v10, v11, :cond_4

    .line 41
    iget-object v11, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    aget-object v11, v11, v10

    iget-object v8, v11, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 42
    if-eq v6, v8, :cond_3

    .line 43
    move v9, v10

    .line 44
    move-object v15, v8

    move v14, v9

    goto :goto_3

    .line 40
    :cond_3
    add-int/lit8 v10, v10, 0x1

    goto :goto_2

    :cond_4
    move-object v15, v8

    move v14, v9

    .line 47
    .end local v8    # "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .end local v9    # "change":I
    .end local v10    # "i2":I
    .local v14, "change":I
    .local v15, "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    :goto_3
    const/4 v13, 0x0

    if-eq v6, v15, :cond_5

    .line 48
    iput-boolean v7, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->hastwostems:Z

    .line 49
    new-instance v12, Lnet/duceng/xmidi/widgets/score/Stem;

    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    aget-object v8, v8, v3

    iget-object v9, v8, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    add-int/lit8 v10, v14, -0x1

    aget-object v8, v8, v10

    iget-object v10, v8, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    invoke-static {v8, v3, v14}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->NotesOverlap([Lnet/duceng/xmidi/widgets/score/NoteData;II)Z

    move-result v3

    const/16 v16, 0x2

    move-object v8, v12

    move-object v11, v6

    move-object v7, v12

    move/from16 v12, v16

    move-object v1, v13

    move v13, v3

    invoke-direct/range {v8 .. v13}, Lnet/duceng/xmidi/widgets/score/Stem;-><init>(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/NoteDuration;IZ)V

    iput-object v7, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    .line 50
    new-instance v3, Lnet/duceng/xmidi/widgets/score/Stem;

    iget-object v7, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    aget-object v7, v7, v14

    iget-object v12, v7, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    iget-object v7, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    array-length v8, v8

    const/4 v9, 0x1

    sub-int/2addr v8, v9

    aget-object v7, v7, v8

    iget-object v13, v7, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    iget-object v7, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    array-length v8, v8

    invoke-static {v7, v14, v8}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->NotesOverlap([Lnet/duceng/xmidi/widgets/score/NoteData;II)Z

    move-result v16

    const/4 v7, 0x1

    move-object v11, v3

    move/from16 v17, v14

    .end local v14    # "change":I
    .local v17, "change":I
    move-object v14, v15

    move-object v10, v15

    .end local v15    # "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .local v10, "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    move v15, v7

    invoke-direct/range {v11 .. v16}, Lnet/duceng/xmidi/widgets/score/Stem;-><init>(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/NoteDuration;IZ)V

    iput-object v3, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    move-object v3, v10

    goto :goto_4

    .line 52
    .end local v10    # "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .end local v17    # "change":I
    .restart local v14    # "change":I
    .restart local v15    # "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    :cond_5
    move-object v1, v13

    move/from16 v17, v14

    move-object v10, v15

    .end local v14    # "change":I
    .end local v15    # "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .restart local v10    # "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .restart local v17    # "change":I
    iget-object v7, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    aget-object v7, v7, v3

    iget-object v7, v7, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    iget-object v9, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    array-length v9, v9

    const/4 v11, 0x1

    sub-int/2addr v9, v11

    aget-object v8, v8, v9

    iget-object v8, v8, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    iget-object v9, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-static {v7, v8, v9}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->StemDirection(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/Clef;)I

    move-result v7

    .line 53
    .local v7, "direction":I
    new-instance v14, Lnet/duceng/xmidi/widgets/score/Stem;

    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    aget-object v8, v8, v3

    iget-object v9, v8, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    iget-object v11, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    array-length v11, v11

    const/4 v12, 0x1

    sub-int/2addr v11, v12

    aget-object v8, v8, v11

    iget-object v11, v8, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    iget-object v12, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    array-length v12, v12

    invoke-static {v8, v3, v12}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->NotesOverlap([Lnet/duceng/xmidi/widgets/score/NoteData;II)Z

    move-result v13

    move-object v8, v14

    move-object v3, v10

    .end local v10    # "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .local v3, "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    move-object v10, v11

    move-object v11, v6

    move v12, v7

    invoke-direct/range {v8 .. v13}, Lnet/duceng/xmidi/widgets/score/Stem;-><init>(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/NoteDuration;IZ)V

    iput-object v14, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    .line 54
    iput-object v1, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    .line 56
    .end local v7    # "direction":I
    :goto_4
    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v6, v7, :cond_6

    .line 57
    iput-object v1, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    .line 59
    :cond_6
    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v3, v7, :cond_7

    .line 60
    iput-object v1, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    .line 62
    :cond_7
    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getMinWidth()I

    move-result v1

    iput v1, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->width:I

    .line 63
    return-void
.end method

.method static BringStemsCloser([Lnet/duceng/xmidi/widgets/score/ChordSymbol;)V
    .locals 6
    .param p0, "chords"    # [Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    .line 557
    const/4 v0, 0x0

    aget-object v0, p0, v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v0

    .line 558
    .local v0, "firstStem":Lnet/duceng/xmidi/widgets/score/Stem;
    const/4 v1, 0x1

    aget-object v2, p0, v1

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v2

    .line 559
    .local v2, "lastStem":Lnet/duceng/xmidi/widgets/score/Stem;
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getDuration()Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v3

    sget-object v4, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/4 v5, 0x2

    if-ne v3, v4, :cond_1

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getDuration()Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v3

    sget-object v4, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v3, v4, :cond_1

    .line 560
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getDirection()I

    move-result v3

    if-ne v3, v1, :cond_0

    .line 561
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v3

    invoke-virtual {v3, v5}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v3

    invoke-virtual {v0, v3}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    goto :goto_0

    .line 563
    :cond_0
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v3

    const/4 v4, -0x2

    invoke-virtual {v3, v4}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v3

    invoke-virtual {v0, v3}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 566
    :cond_1
    :goto_0
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v3

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v4

    invoke-virtual {v3, v4}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Math;->abs(I)I

    move-result v3

    .line 567
    .local v3, "distance":I
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getDirection()I

    move-result v4

    if-ne v4, v1, :cond_3

    .line 568
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v4

    invoke-static {v1, v4}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Max(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v4

    if-ne v1, v4, :cond_2

    .line 569
    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    div-int/lit8 v4, v3, 0x2

    invoke-virtual {v1, v4}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    invoke-virtual {v2, v1}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 570
    return-void

    .line 572
    :cond_2
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    div-int/lit8 v4, v3, 0x2

    invoke-virtual {v1, v4}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 573
    return-void

    .line 576
    :cond_3
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v4

    invoke-static {v1, v4}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Min(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v4

    if-ne v1, v4, :cond_4

    .line 577
    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    neg-int v4, v3

    div-int/2addr v4, v5

    invoke-virtual {v1, v4}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    invoke-virtual {v2, v1}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    goto :goto_1

    .line 579
    :cond_4
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    neg-int v4, v3

    div-int/2addr v4, v5

    invoke-virtual {v1, v4}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 581
    :goto_1
    return-void
.end method

.method public static CanCreateBeam([Lnet/duceng/xmidi/widgets/score/ChordSymbol;Lnet/duceng/xmidi/widgets/score/MidiTime;Z)Z
    .locals 17
    .param p0, "chords"    # [Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    .param p1, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .param p2, "startQuarter"    # Z

    .line 430
    move-object/from16 v0, p0

    array-length v1, v0

    .line 431
    .local v1, "numChords":I
    const/4 v2, 0x0

    aget-object v3, v0, v2

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v3

    .line 432
    .local v3, "firstStem":Lnet/duceng/xmidi/widgets/score/Stem;
    array-length v4, v0

    const/4 v5, 0x1

    sub-int/2addr v4, v5

    aget-object v4, v0, v4

    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v4

    .line 433
    .local v4, "lastStem":Lnet/duceng/xmidi/widgets/score/Stem;
    if-eqz v3, :cond_2a

    if-nez v4, :cond_0

    goto/16 :goto_e

    .line 436
    :cond_0
    aget-object v6, v0, v2

    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStartTime()I

    move-result v6

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getMeasure()I

    move-result v7

    div-int/2addr v6, v7

    .line 437
    .local v6, "measure":I
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Stem;->getDuration()Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v7

    .line 438
    .local v7, "dur":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Stem;->getDuration()Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v8

    .line 439
    .local v8, "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    const/4 v9, 0x0

    .line 440
    .local v9, "dotted8_to_16":Z
    array-length v10, v0

    const/4 v11, 0x2

    if-ne v10, v11, :cond_1

    sget-object v10, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v7, v10, :cond_1

    sget-object v10, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v8, v10, :cond_1

    .line 441
    const/4 v9, 0x1

    .line 443
    :cond_1
    sget-object v10, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v10, :cond_29

    sget-object v10, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v10, :cond_29

    sget-object v10, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v10, :cond_29

    sget-object v10, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v10, :cond_29

    sget-object v10, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedQuarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v10, :cond_29

    sget-object v10, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v7, v10, :cond_2

    if-nez v9, :cond_2

    goto/16 :goto_d

    .line 446
    :cond_2
    const/16 v10, 0x8

    const/4 v12, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x6

    if-ne v1, v14, :cond_a

    .line 447
    sget-object v11, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v11, :cond_3

    .line 448
    return v2

    .line 450
    :cond_3
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v11

    if-ne v11, v12, :cond_4

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getDenominator()I

    move-result v11

    if-eq v11, v13, :cond_6

    :cond_4
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v11

    if-ne v11, v14, :cond_5

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getDenominator()I

    move-result v11

    if-eq v11, v10, :cond_6

    :cond_5
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v10

    if-ne v10, v14, :cond_7

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getDenominator()I

    move-result v10

    if-ne v10, v13, :cond_7

    :cond_6
    const/4 v10, 0x1

    goto :goto_0

    :cond_7
    const/4 v10, 0x0

    .line 451
    .local v10, "correctTime":Z
    :goto_0
    if-nez v10, :cond_8

    .line 452
    return v2

    .line 454
    :cond_8
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v11

    if-ne v11, v14, :cond_9

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getDenominator()I

    move-result v11

    if-ne v11, v13, :cond_9

    .line 455
    aget-object v11, v0, v2

    invoke-virtual {v11}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStartTime()I

    move-result v11

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v13

    mul-int/lit8 v13, v13, 0x3

    rem-int/2addr v11, v13

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v12

    div-int/2addr v12, v14

    if-le v11, v12, :cond_9

    .line 456
    return v2

    .line 459
    .end local v10    # "correctTime":Z
    :cond_9
    goto/16 :goto_7

    :cond_a
    if-ne v1, v13, :cond_12

    .line 460
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v15

    if-ne v15, v12, :cond_b

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getDenominator()I

    move-result v12

    if-ne v12, v10, :cond_b

    .line 461
    return v2

    .line 463
    :cond_b
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v12

    if-eq v12, v11, :cond_d

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v12

    if-eq v12, v13, :cond_d

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v12

    if-ne v12, v10, :cond_c

    goto :goto_1

    :cond_c
    const/4 v10, 0x0

    goto :goto_2

    :cond_d
    :goto_1
    const/4 v10, 0x1

    .line 464
    .local v10, "correctTime2":Z
    :goto_2
    if-nez v10, :cond_e

    sget-object v12, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v12, :cond_e

    .line 465
    return v2

    .line 467
    :cond_e
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v12

    .line 468
    .local v12, "beat":I
    sget-object v13, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v7, v13, :cond_f

    .line 469
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v13

    mul-int/lit8 v12, v13, 0x2

    goto :goto_3

    .line 470
    :cond_f
    sget-object v13, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v7, v13, :cond_10

    .line 471
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v13

    div-int/lit8 v12, v13, 0x2

    .line 473
    :cond_10
    :goto_3
    aget-object v11, v0, v2

    invoke-virtual {v11}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStartTime()I

    move-result v11

    rem-int/2addr v11, v12

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v13

    div-int/2addr v13, v14

    if-le v11, v13, :cond_11

    .line 474
    return v2

    .line 476
    .end local v10    # "correctTime2":Z
    .end local v12    # "beat":I
    :cond_11
    goto :goto_7

    :cond_12
    if-ne v1, v12, :cond_18

    .line 477
    sget-object v13, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Triplet:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/16 v15, 0xc

    if-eq v7, v13, :cond_14

    sget-object v13, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v7, v13, :cond_13

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v13

    if-ne v13, v15, :cond_13

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getDenominator()I

    move-result v13

    if-ne v13, v10, :cond_13

    goto :goto_4

    :cond_13
    const/4 v13, 0x0

    goto :goto_5

    :cond_14
    :goto_4
    const/4 v13, 0x1

    .line 478
    .local v13, "valid":Z
    :goto_5
    if-nez v13, :cond_15

    .line 479
    return v2

    .line 481
    :cond_15
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v16

    .line 482
    .local v16, "beat2":I
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getNumerator()I

    move-result v5

    if-ne v5, v15, :cond_16

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getDenominator()I

    move-result v5

    if-ne v5, v10, :cond_16

    .line 483
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v5

    div-int/2addr v5, v11

    mul-int/lit8 v16, v5, 0x3

    .line 485
    :cond_16
    aget-object v5, v0, v2

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStartTime()I

    move-result v5

    rem-int v5, v5, v16

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v10

    div-int/2addr v10, v14

    if-le v5, v10, :cond_17

    .line 486
    return v2

    .line 485
    .end local v13    # "valid":Z
    .end local v16    # "beat2":I
    :cond_17
    goto :goto_6

    .line 488
    :cond_18
    if-ne v1, v11, :cond_19

    if-eqz p2, :cond_19

    .line 489
    aget-object v5, v0, v2

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStartTime()I

    move-result v5

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v10

    rem-int/2addr v5, v10

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getResolution()I

    move-result v10

    div-int/2addr v10, v14

    if-le v5, v10, :cond_1a

    .line 490
    return v2

    .line 488
    :cond_19
    :goto_6
    nop

    .line 493
    :cond_1a
    :goto_7
    array-length v5, v0

    const/4 v10, 0x0

    :goto_8
    if-ge v10, v5, :cond_20

    aget-object v11, v0, v10

    .line 494
    .local v11, "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {v11}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStartTime()I

    move-result v12

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getMeasure()I

    move-result v13

    div-int/2addr v12, v13

    if-ne v12, v6, :cond_1f

    invoke-virtual {v11}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v12

    if-nez v12, :cond_1b

    goto :goto_9

    .line 497
    :cond_1b
    invoke-virtual {v11}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v12

    invoke-virtual {v12}, Lnet/duceng/xmidi/widgets/score/Stem;->getDuration()Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v12

    if-eq v12, v7, :cond_1c

    if-eqz v9, :cond_1d

    :cond_1c
    invoke-virtual {v11}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v12

    invoke-virtual {v12}, Lnet/duceng/xmidi/widgets/score/Stem;->IsBeam()Z

    move-result v12

    if-eqz v12, :cond_1e

    .line 498
    :cond_1d
    return v2

    .line 493
    .end local v11    # "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    :cond_1e
    add-int/lit8 v10, v10, 0x1

    goto :goto_8

    .line 495
    .restart local v11    # "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    :cond_1f
    :goto_9
    return v2

    .line 501
    .end local v11    # "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    :cond_20
    const/4 v5, 0x0

    .line 502
    .local v5, "hasTwoStems":Z
    const/4 v10, 0x1

    .line 503
    .local v10, "direction":I
    array-length v11, v0

    const/4 v12, 0x0

    :goto_a
    if-ge v12, v11, :cond_23

    aget-object v13, v0, v12

    .line 504
    .local v13, "chord2":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {v13}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getHasTwoStems()Z

    move-result v14

    if-eqz v14, :cond_22

    .line 505
    if-eqz v5, :cond_21

    invoke-virtual {v13}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v14

    invoke-virtual {v14}, Lnet/duceng/xmidi/widgets/score/Stem;->getDirection()I

    move-result v14

    if-eq v14, v10, :cond_21

    .line 506
    return v2

    .line 508
    :cond_21
    const/4 v5, 0x1

    .line 509
    invoke-virtual {v13}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v14

    invoke-virtual {v14}, Lnet/duceng/xmidi/widgets/score/Stem;->getDirection()I

    move-result v10

    .line 503
    .end local v13    # "chord2":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    :cond_22
    add-int/lit8 v12, v12, 0x1

    goto :goto_a

    .line 512
    :cond_23
    if-nez v5, :cond_26

    .line 513
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Stem;->getDirection()I

    move-result v11

    const/4 v12, 0x1

    if-ne v11, v12, :cond_24

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Stem;->getTop()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v11

    goto :goto_b

    :cond_24
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Stem;->getBottom()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v11

    .line 514
    .local v11, "note1":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :goto_b
    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Stem;->getDirection()I

    move-result v13

    if-ne v13, v12, :cond_25

    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Stem;->getTop()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v12

    goto :goto_c

    :cond_25
    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Stem;->getBottom()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v12

    .line 515
    .local v12, "note2":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :goto_c
    aget-object v13, v0, v2

    invoke-virtual {v13}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getClef()Lnet/duceng/xmidi/widgets/score/Clef;

    move-result-object v13

    invoke-static {v11, v12, v13}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->StemDirection(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/Clef;)I

    move-result v10

    .line 517
    .end local v11    # "note1":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .end local v12    # "note2":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :cond_26
    const/16 v11, 0xb

    const/4 v12, 0x1

    if-ne v10, v12, :cond_27

    .line 518
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Stem;->getTop()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v12

    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Stem;->getTop()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v13

    invoke-virtual {v12, v13}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v12

    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v12

    if-lt v12, v11, :cond_28

    .line 519
    return v2

    .line 521
    :cond_27
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Stem;->getBottom()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v12

    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Stem;->getBottom()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v13

    invoke-virtual {v12, v13}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v12

    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v12

    if-lt v12, v11, :cond_28

    .line 522
    return v2

    .line 524
    :cond_28
    const/4 v2, 0x1

    return v2

    .line 444
    .end local v5    # "hasTwoStems":Z
    .end local v10    # "direction":I
    :cond_29
    :goto_d
    return v2

    .line 434
    .end local v6    # "measure":I
    .end local v7    # "dur":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .end local v8    # "dur2":Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .end local v9    # "dotted8_to_16":Z
    :cond_2a
    :goto_e
    return v2
.end method

.method private static CreateAccidSymbols([Lnet/duceng/xmidi/widgets/score/NoteData;Lnet/duceng/xmidi/widgets/score/Clef;)[Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    .locals 9
    .param p0, "notedata"    # [Lnet/duceng/xmidi/widgets/score/NoteData;
    .param p1, "clef"    # Lnet/duceng/xmidi/widgets/score/Clef;

    .line 90
    const/4 v0, 0x0

    .line 91
    .local v0, "count":I
    array-length v1, p0

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_1

    aget-object v4, p0, v3

    .line 92
    .local v4, "noteData":Lnet/duceng/xmidi/widgets/score/NoteData;
    iget-object v5, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v6, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    if-eq v5, v6, :cond_0

    .line 93
    add-int/lit8 v0, v0, 0x1

    .line 91
    .end local v4    # "noteData":Lnet/duceng/xmidi/widgets/score/NoteData;
    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 96
    :cond_1
    new-array v1, v0, [Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    .line 97
    .local v1, "accidsymbols":[Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    const/4 v3, 0x0

    .line 98
    .local v3, "i":I
    array-length v4, p0

    :goto_1
    if-ge v2, v4, :cond_3

    aget-object v5, p0, v2

    .line 99
    .local v5, "n":Lnet/duceng/xmidi/widgets/score/NoteData;
    iget-object v6, v5, Lnet/duceng/xmidi/widgets/score/NoteData;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v7, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    if-eq v6, v7, :cond_2

    .line 100
    new-instance v6, Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    iget-object v7, v5, Lnet/duceng/xmidi/widgets/score/NoteData;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    iget-object v8, v5, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v6, v7, v8, p1}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;-><init>(Lnet/duceng/xmidi/widgets/score/Accid;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/Clef;)V

    aput-object v6, v1, v3

    .line 101
    add-int/lit8 v3, v3, 0x1

    .line 98
    .end local v5    # "n":Lnet/duceng/xmidi/widgets/score/NoteData;
    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 104
    :cond_3
    return-object v1
.end method

.method public static CreateBeam([Lnet/duceng/xmidi/widgets/score/ChordSymbol;I)V
    .locals 9
    .param p0, "chords"    # [Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    .param p1, "spacing"    # I

    .line 528
    const/4 v0, 0x0

    aget-object v1, p0, v0

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v1

    .line 529
    .local v1, "firstStem":Lnet/duceng/xmidi/widgets/score/Stem;
    array-length v2, p0

    const/4 v3, 0x1

    sub-int/2addr v2, v3

    aget-object v2, p0, v2

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v2

    .line 530
    .local v2, "lastStem":Lnet/duceng/xmidi/widgets/score/Stem;
    const/4 v4, -0x1

    .line 531
    .local v4, "newdirection":I
    array-length v5, p0

    const/4 v6, 0x0

    :goto_0
    if-ge v6, v5, :cond_1

    aget-object v7, p0, v6

    .line 532
    .local v7, "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {v7}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getHasTwoStems()Z

    move-result v8

    if-eqz v8, :cond_0

    .line 533
    invoke-virtual {v7}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v5

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Stem;->getDirection()I

    move-result v4

    .line 534
    goto :goto_1

    .line 531
    .end local v7    # "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    :cond_0
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    .line 537
    :cond_1
    :goto_1
    const/4 v5, -0x1

    if-ne v4, v5, :cond_4

    .line 538
    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getDirection()I

    move-result v5

    if-ne v5, v3, :cond_2

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getTop()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v5

    goto :goto_2

    :cond_2
    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getBottom()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v5

    .line 539
    .local v5, "note1":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :goto_2
    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getDirection()I

    move-result v6

    if-ne v6, v3, :cond_3

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getTop()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v6

    goto :goto_3

    :cond_3
    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getBottom()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v6

    .line 540
    .local v6, "note2":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :goto_3
    aget-object v7, p0, v0

    invoke-virtual {v7}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getClef()Lnet/duceng/xmidi/widgets/score/Clef;

    move-result-object v7

    invoke-static {v5, v6, v7}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->StemDirection(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/Clef;)I

    move-result v4

    .line 542
    .end local v5    # "note1":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .end local v6    # "note2":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :cond_4
    array-length v5, p0

    :goto_4
    if-ge v0, v5, :cond_5

    aget-object v6, p0, v0

    .line 543
    .local v6, "chordSymbol":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v7

    invoke-virtual {v7, v4}, Lnet/duceng/xmidi/widgets/score/Stem;->setDirection(I)V

    .line 542
    .end local v6    # "chordSymbol":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    .line 545
    :cond_5
    array-length v0, p0

    const/4 v5, 0x2

    if-ne v0, v5, :cond_6

    .line 546
    invoke-static {p0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->BringStemsCloser([Lnet/duceng/xmidi/widgets/score/ChordSymbol;)V

    goto :goto_5

    .line 548
    :cond_6
    invoke-static {p0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->LineUpStemEnds([Lnet/duceng/xmidi/widgets/score/ChordSymbol;)V

    .line 550
    :goto_5
    invoke-virtual {v1, v2, p1}, Lnet/duceng/xmidi/widgets/score/Stem;->SetPair(Lnet/duceng/xmidi/widgets/score/Stem;I)V

    .line 551
    const/4 v0, 0x1

    .local v0, "i":I
    :goto_6
    array-length v5, p0

    if-ge v0, v5, :cond_7

    .line 552
    aget-object v5, p0, v0

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v5

    invoke-virtual {v5, v3}, Lnet/duceng/xmidi/widgets/score/Stem;->setReceiver(Z)V

    .line 551
    add-int/lit8 v0, v0, 0x1

    goto :goto_6

    .line 554
    .end local v0    # "i":I
    :cond_7
    return-void
.end method

.method private Letter(ILnet/duceng/xmidi/widgets/score/WhiteNote;)Ljava/lang/String;
    .locals 3
    .param p1, "notenumber"    # I
    .param p2, "whitenote"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 267
    invoke-static {p1}, Lnet/duceng/xmidi/widgets/score/NoteScale;->FromNumber(I)I

    move-result v0

    .line 268
    .local v0, "notescale":I
    packed-switch v0, :pswitch_data_0

    .line 309
    const-string v1, ""

    return-object v1

    .line 304
    :pswitch_0
    invoke-virtual {p2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->getLetter()I

    move-result v1

    const/4 v2, 0x6

    if-ne v1, v2, :cond_0

    .line 305
    const-string v1, "G#"

    return-object v1

    .line 307
    :cond_0
    const-string v1, "Ab"

    return-object v1

    .line 302
    :pswitch_1
    const-string v1, "G"

    return-object v1

    .line 297
    :pswitch_2
    invoke-virtual {p2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->getLetter()I

    move-result v1

    const/4 v2, 0x5

    if-ne v1, v2, :cond_1

    .line 298
    const-string v1, "F#"

    return-object v1

    .line 300
    :cond_1
    const-string v1, "Gb"

    return-object v1

    .line 295
    :pswitch_3
    const-string v1, "F"

    return-object v1

    .line 293
    :pswitch_4
    const-string v1, "E"

    return-object v1

    .line 288
    :pswitch_5
    invoke-virtual {p2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->getLetter()I

    move-result v1

    const/4 v2, 0x3

    if-ne v1, v2, :cond_2

    .line 289
    const-string v1, "D#"

    return-object v1

    .line 291
    :cond_2
    const-string v1, "Eb"

    return-object v1

    .line 286
    :pswitch_6
    const-string v1, "D"

    return-object v1

    .line 281
    :pswitch_7
    invoke-virtual {p2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->getLetter()I

    move-result v1

    const/4 v2, 0x2

    if-ne v1, v2, :cond_3

    .line 282
    const-string v1, "C#"

    return-object v1

    .line 284
    :cond_3
    const-string v1, "Db"

    return-object v1

    .line 279
    :pswitch_8
    const-string v1, "C"

    return-object v1

    .line 277
    :pswitch_9
    const-string v1, "B"

    return-object v1

    .line 272
    :pswitch_a
    invoke-virtual {p2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->getLetter()I

    move-result v1

    if-nez v1, :cond_4

    .line 273
    const-string v1, "A#"

    return-object v1

    .line 275
    :cond_4
    const-string v1, "Bb"

    return-object v1

    .line 270
    :pswitch_b
    const-string v1, "A"

    return-object v1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method static LineUpStemEnds([Lnet/duceng/xmidi/widgets/score/ChordSymbol;)V
    .locals 11
    .param p0, "chords"    # [Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    .line 584
    const/4 v0, 0x0

    .line 585
    .local v0, "i":I
    const/4 v1, 0x0

    aget-object v1, p0, v1

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v1

    .line 586
    .local v1, "firstStem":Lnet/duceng/xmidi/widgets/score/Stem;
    array-length v2, p0

    const/4 v3, 0x1

    sub-int/2addr v2, v3

    aget-object v2, p0, v2

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v2

    .line 587
    .local v2, "lastStem":Lnet/duceng/xmidi/widgets/score/Stem;
    aget-object v4, p0, v3

    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v4

    .line 588
    .local v4, "middleStem":Lnet/duceng/xmidi/widgets/score/Stem;
    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getDirection()I

    move-result v5

    const/4 v6, 0x2

    if-ne v5, v3, :cond_3

    .line 589
    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v5

    .line 590
    .local v5, "top":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    array-length v7, p0

    .line 591
    .local v7, "length":I
    :goto_0
    if-ge v0, v7, :cond_0

    .line 592
    aget-object v8, p0, v0

    .line 593
    .local v8, "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {v8}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v9

    invoke-virtual {v9}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v9

    invoke-static {v5, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Max(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v5

    .line 594
    nop

    .end local v8    # "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    add-int/lit8 v0, v0, 0x1

    .line 595
    goto :goto_0

    .line 596
    :cond_0
    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v8

    const/4 v9, -0x2

    const/4 v10, -0x1

    if-ne v5, v8, :cond_1

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v8

    invoke-virtual {v5, v8}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v8

    if-lt v8, v6, :cond_1

    .line 597
    invoke-virtual {v1, v5}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 598
    invoke-virtual {v5, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v6

    invoke-virtual {v4, v6}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 599
    invoke-virtual {v5, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v6

    invoke-virtual {v2, v6}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    goto :goto_1

    .line 600
    :cond_1
    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v8

    if-ne v5, v8, :cond_2

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v8

    invoke-virtual {v5, v8}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v8

    if-lt v8, v6, :cond_2

    .line 601
    invoke-virtual {v5, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v6

    invoke-virtual {v1, v6}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 602
    invoke-virtual {v5, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v6

    invoke-virtual {v4, v6}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 603
    invoke-virtual {v2, v5}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    goto :goto_1

    .line 605
    :cond_2
    invoke-virtual {v1, v5}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 606
    invoke-virtual {v4, v5}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 607
    invoke-virtual {v2, v5}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 609
    .end local v5    # "top":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .end local v7    # "length":I
    :goto_1
    goto :goto_3

    .line 610
    :cond_3
    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v5

    .line 611
    .local v5, "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    array-length v7, p0

    .line 612
    .local v7, "length2":I
    :goto_2
    if-ge v0, v7, :cond_4

    .line 613
    aget-object v8, p0, v0

    .line 614
    .local v8, "chord2":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {v8}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v9

    invoke-virtual {v9}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v9

    invoke-static {v5, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Min(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v5

    .line 615
    nop

    .end local v8    # "chord2":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    add-int/lit8 v0, v0, 0x1

    .line 616
    goto :goto_2

    .line 617
    :cond_4
    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v8

    if-ne v5, v8, :cond_5

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v8

    invoke-virtual {v8, v5}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v8

    if-lt v8, v6, :cond_5

    .line 618
    invoke-virtual {v5, v3}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v8

    invoke-virtual {v4, v8}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 619
    invoke-virtual {v5, v6}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v6

    invoke-virtual {v2, v6}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    goto :goto_3

    .line 620
    :cond_5
    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v8

    if-ne v5, v8, :cond_6

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v8

    invoke-virtual {v8, v5}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v8

    if-lt v8, v6, :cond_6

    .line 621
    invoke-virtual {v5, v3}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v8

    invoke-virtual {v4, v8}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 622
    invoke-virtual {v5, v6}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v6

    invoke-virtual {v1, v6}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    goto :goto_3

    .line 624
    :cond_6
    invoke-virtual {v1, v5}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 625
    invoke-virtual {v4, v5}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 626
    invoke-virtual {v2, v5}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 629
    .end local v5    # "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .end local v7    # "length2":I
    :goto_3
    const/4 v5, 0x1

    .local v5, "i2":I
    :goto_4
    array-length v6, p0

    sub-int/2addr v6, v3

    if-ge v5, v6, :cond_7

    .line 630
    aget-object v6, p0, v5

    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v6

    .line 631
    .local v6, "stem":Lnet/duceng/xmidi/widgets/score/Stem;
    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v7

    invoke-virtual {v6, v7}, Lnet/duceng/xmidi/widgets/score/Stem;->setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 629
    .end local v6    # "stem":Lnet/duceng/xmidi/widgets/score/Stem;
    add-int/lit8 v5, v5, 0x1

    goto :goto_4

    .line 633
    .end local v5    # "i2":I
    :cond_7
    return-void
.end method

.method private NoteName(ILnet/duceng/xmidi/widgets/score/WhiteNote;)Ljava/lang/String;
    .locals 15
    .param p1, "notenumber"    # I
    .param p2, "whitenote"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 228
    move-object v0, p0

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/MusicScore;->getShowNoteLetters()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_0

    .line 229
    invoke-direct/range {p0 .. p2}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->Letter(ILnet/duceng/xmidi/widgets/score/WhiteNote;)Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 231
    :cond_0
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/MusicScore;->getShowNoteLetters()I

    move-result v1

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    .line 232
    const-string v13, "So"

    const-string v14, "Si"

    const-string v3, "La"

    const-string v4, "Li"

    const-string v5, "Ti"

    const-string v6, "Do"

    const-string v7, "Di"

    const-string v8, "Re"

    const-string v9, "Ri"

    const-string v10, "Mi"

    const-string v11, "Fa"

    const-string v12, "Fi"

    filled-new-array/range {v3 .. v14}, [Ljava/lang/String;

    move-result-object v1

    .line 233
    .local v1, "fixedDoReMi":[Ljava/lang/String;
    invoke-static/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/NoteScale;->FromNumber(I)I

    move-result v2

    .line 234
    .local v2, "notescale":I
    aget-object v3, v1, v2

    return-object v3

    .line 236
    .end local v1    # "fixedDoReMi":[Ljava/lang/String;
    .end local v2    # "notescale":I
    :cond_1
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/MusicScore;->getShowNoteLetters()I

    move-result v1

    const/4 v2, 0x3

    if-ne v1, v2, :cond_3

    .line 237
    const-string v13, "So"

    const-string v14, "Si"

    const-string v3, "La"

    const-string v4, "Li"

    const-string v5, "Ti"

    const-string v6, "Do"

    const-string v7, "Di"

    const-string v8, "Re"

    const-string v9, "Ri"

    const-string v10, "Mi"

    const-string v11, "Fa"

    const-string v12, "Fi"

    filled-new-array/range {v3 .. v14}, [Ljava/lang/String;

    move-result-object v1

    .line 238
    .local v1, "fixedDoReMi2":[Ljava/lang/String;
    iget-object v2, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/MusicScore;->getMainKey()Lnet/duceng/xmidi/widgets/score/MidiKey;

    move-result-object v2

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/MidiKey;->Notescale()I

    move-result v2

    .line 239
    .local v2, "mainscale":I
    rsub-int/lit8 v3, v2, 0x3

    .line 240
    .local v3, "diff":I
    add-int v4, p1, v3

    .line 241
    .local v4, "notenumber2":I
    if-gez v4, :cond_2

    .line 242
    add-int/lit8 v4, v4, 0xc

    .line 244
    :cond_2
    invoke-static {v4}, Lnet/duceng/xmidi/widgets/score/NoteScale;->FromNumber(I)I

    move-result v5

    .line 245
    .local v5, "notescale2":I
    aget-object v6, v1, v5

    return-object v6

    .line 247
    .end local v1    # "fixedDoReMi2":[Ljava/lang/String;
    .end local v2    # "mainscale":I
    .end local v3    # "diff":I
    .end local v4    # "notenumber2":I
    .end local v5    # "notescale2":I
    :cond_3
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/MusicScore;->getShowNoteLetters()I

    move-result v1

    const/4 v2, 0x4

    if-ne v1, v2, :cond_4

    .line 248
    const-string v13, "8"

    const-string v14, "9"

    const-string v3, "10"

    const-string v4, "11"

    const-string v5, "12"

    const-string v6, "1"

    const-string v7, "2"

    const-string v8, "3"

    const-string v9, "4"

    const-string v10, "5"

    const-string v11, "6"

    const-string v12, "7"

    filled-new-array/range {v3 .. v14}, [Ljava/lang/String;

    move-result-object v1

    .line 249
    .local v1, "num":[Ljava/lang/String;
    invoke-static/range {p1 .. p1}, Lnet/duceng/xmidi/widgets/score/NoteScale;->FromNumber(I)I

    move-result v2

    .line 250
    .local v2, "notescale3":I
    aget-object v3, v1, v2

    return-object v3

    .line 252
    .end local v1    # "num":[Ljava/lang/String;
    .end local v2    # "notescale3":I
    :cond_4
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/MusicScore;->getShowNoteLetters()I

    move-result v1

    const/4 v2, 0x5

    if-ne v1, v2, :cond_6

    .line 253
    const-string v13, "8"

    const-string v14, "9"

    const-string v3, "10"

    const-string v4, "11"

    const-string v5, "12"

    const-string v6, "1"

    const-string v7, "2"

    const-string v8, "3"

    const-string v9, "4"

    const-string v10, "5"

    const-string v11, "6"

    const-string v12, "7"

    filled-new-array/range {v3 .. v14}, [Ljava/lang/String;

    move-result-object v1

    .line 254
    .local v1, "num2":[Ljava/lang/String;
    iget-object v2, v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/MusicScore;->getMainKey()Lnet/duceng/xmidi/widgets/score/MidiKey;

    move-result-object v2

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/MidiKey;->Notescale()I

    move-result v2

    .line 255
    .local v2, "mainscale2":I
    rsub-int/lit8 v3, v2, 0x3

    .line 256
    .local v3, "diff2":I
    add-int v4, p1, v3

    .line 257
    .local v4, "notenumber3":I
    if-gez v4, :cond_5

    .line 258
    add-int/lit8 v4, v4, 0xc

    .line 260
    :cond_5
    invoke-static {v4}, Lnet/duceng/xmidi/widgets/score/NoteScale;->FromNumber(I)I

    move-result v5

    .line 261
    .local v5, "notescale4":I
    aget-object v6, v1, v5

    return-object v6

    .line 263
    .end local v1    # "num2":[Ljava/lang/String;
    .end local v2    # "mainscale2":I
    .end local v3    # "diff2":I
    .end local v4    # "notenumber3":I
    .end local v5    # "notescale4":I
    :cond_6
    const-string v1, ""

    return-object v1
.end method

.method private static NotesOverlap([Lnet/duceng/xmidi/widgets/score/NoteData;II)Z
    .locals 2
    .param p0, "notedata"    # [Lnet/duceng/xmidi/widgets/score/NoteData;
    .param p1, "start"    # I
    .param p2, "end"    # I

    .line 119
    move v0, p1

    .local v0, "i":I
    :goto_0
    if-ge v0, p2, :cond_1

    .line 120
    aget-object v1, p0, v0

    iget-boolean v1, v1, Lnet/duceng/xmidi/widgets/score/NoteData;->leftside:Z

    if-nez v1, :cond_0

    .line 121
    const/4 v1, 0x1

    return v1

    .line 119
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 124
    .end local v0    # "i":I
    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method private static StemDirection(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/Clef;)I
    .locals 4
    .param p0, "bottom"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .param p1, "top"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .param p2, "clef"    # Lnet/duceng/xmidi/widgets/score/Clef;

    .line 109
    sget-object v0, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    const/4 v1, 0x1

    if-ne p2, v0, :cond_0

    .line 110
    new-instance v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    .local v0, "middle":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    goto :goto_0

    .line 112
    .end local v0    # "middle":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :cond_0
    new-instance v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    const/4 v2, 0x3

    invoke-direct {v0, v2, v2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    .line 114
    .restart local v0    # "middle":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :goto_0
    invoke-virtual {v0, p0}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v2

    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v3

    add-int/2addr v2, v3

    .line 115
    .local v2, "dist":I
    if-ltz v2, :cond_1

    goto :goto_1

    :cond_1
    const/4 v1, 0x2

    :goto_1
    return v1
.end method

.method private static createNoteData(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;)[Lnet/duceng/xmidi/widgets/score/NoteData;
    .locals 9
    .param p1, "key"    # Lnet/duceng/xmidi/widgets/score/MidiKey;
    .param p2, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Note;",
            ">;",
            "Lnet/duceng/xmidi/widgets/score/MidiKey;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            ")[",
            "Lnet/duceng/xmidi/widgets/score/NoteData;"
        }
    .end annotation

    .line 66
    .local p0, "midinotes":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;"
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    .line 67
    .local v0, "len":I
    new-array v1, v0, [Lnet/duceng/xmidi/widgets/score/NoteData;

    .line 68
    .local v1, "notedata":[Lnet/duceng/xmidi/widgets/score/NoteData;
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    if-ge v2, v0, :cond_2

    .line 69
    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/Note;

    .line 70
    .local v3, "midi":Lnet/duceng/xmidi/widgets/score/Note;
    new-instance v4, Lnet/duceng/xmidi/widgets/score/NoteData;

    invoke-direct {v4}, Lnet/duceng/xmidi/widgets/score/NoteData;-><init>()V

    aput-object v4, v1, v2

    .line 71
    aget-object v4, v1, v2

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v5

    iput v5, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->number:I

    .line 72
    aget-object v4, v1, v2

    const/4 v5, 0x1

    iput-boolean v5, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->leftside:Z

    .line 73
    aget-object v4, v1, v2

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v6

    invoke-virtual {p1, v6}, Lnet/duceng/xmidi/widgets/score/MidiKey;->GetWhiteNote(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v6

    iput-object v6, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 74
    aget-object v4, v1, v2

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Note;->getEndTick()I

    move-result v6

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Note;->getStartTick()I

    move-result v7

    sub-int/2addr v6, v7

    invoke-virtual {p2, v6}, Lnet/duceng/xmidi/widgets/score/MidiTime;->GetNoteDuration(I)Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v6

    iput-object v6, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 75
    aget-object v4, v1, v2

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v6

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Note;->getStartTick()I

    move-result v7

    invoke-virtual {p2}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getMeasure()I

    move-result v8

    div-int/2addr v7, v8

    invoke-virtual {p1, v6, v7}, Lnet/duceng/xmidi/widgets/score/MidiKey;->GetAccidental(II)Lnet/duceng/xmidi/widgets/score/Accid;

    move-result-object v6

    iput-object v6, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->accid:Lnet/duceng/xmidi/widgets/score/Accid;

    .line 76
    if-lez v2, :cond_1

    aget-object v4, v1, v2

    iget-object v4, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    add-int/lit8 v6, v2, -0x1

    aget-object v6, v1, v6

    iget-object v6, v6, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v4, v6}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v4

    if-ne v4, v5, :cond_1

    .line 77
    add-int/lit8 v4, v2, -0x1

    aget-object v4, v1, v4

    iget-boolean v4, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->leftside:Z

    if-eqz v4, :cond_0

    .line 78
    aget-object v4, v1, v2

    const/4 v5, 0x0

    iput-boolean v5, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->leftside:Z

    goto :goto_1

    .line 80
    :cond_0
    aget-object v4, v1, v2

    iput-boolean v5, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->leftside:Z

    goto :goto_1

    .line 83
    :cond_1
    aget-object v4, v1, v2

    iput-boolean v5, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->leftside:Z

    .line 68
    .end local v3    # "midi":Lnet/duceng/xmidi/widgets/score/Note;
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 86
    .end local v2    # "i":I
    :cond_2
    return-object v1
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 5
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 315
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 316
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getMinWidth()I

    move-result v1

    sub-int/2addr v0, v1

    int-to-float v0, v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 317
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-static {v0}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Top(Lnet/duceng/xmidi/widgets/score/Clef;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    .line 318
    .local v0, "topstaff":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    invoke-virtual {p0, p1, p2, p3}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->drawAccid(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)I

    move-result v2

    .line 319
    .local v2, "xpos":I
    int-to-float v3, v2

    invoke-virtual {p1, v3, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 320
    invoke-virtual {p0, p1, p2, p3, v0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->drawNotes(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 321
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    if-eqz v3, :cond_0

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/MusicScore;->getShowNoteLetters()I

    move-result v3

    if-eqz v3, :cond_0

    .line 322
    invoke-virtual {p0, p1, p2, p3, v0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->drawNoteLetters(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 324
    :cond_0
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    if-eqz v3, :cond_1

    .line 325
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    invoke-virtual {v3, p1, p2, p3, v0}, Lnet/duceng/xmidi/widgets/score/Stem;->draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 327
    :cond_1
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    if-eqz v3, :cond_2

    .line 328
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    invoke-virtual {v3, p1, p2, p3, v0}, Lnet/duceng/xmidi/widgets/score/Stem;->draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 330
    :cond_2
    neg-int v3, v2

    int-to-float v3, v3

    invoke-virtual {p1, v3, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 331
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getWidth()I

    move-result v3

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getMinWidth()I

    move-result v4

    sub-int/2addr v3, v4

    neg-int v3, v3

    int-to-float v3, v3

    invoke-virtual {p1, v3, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 332
    return-void
.end method

.method public drawAccid(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)I
    .locals 8
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 335
    const/4 v0, 0x0

    .line 336
    .local v0, "xpos":I
    const/4 v1, 0x0

    .line 337
    .local v1, "prev":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->accidsymbols:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    array-length v3, v2

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v3, :cond_1

    aget-object v5, v2, v4

    .line 338
    .local v5, "symbol":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    if-eqz v1, :cond_0

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getNote()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v6

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getNote()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v7

    invoke-virtual {v6, v7}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v6

    const/4 v7, 0x6

    if-ge v6, v7, :cond_0

    .line 339
    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getWidth()I

    move-result v6

    add-int/2addr v0, v6

    .line 341
    :cond_0
    int-to-float v6, v0

    const/4 v7, 0x0

    invoke-virtual {p1, v6, v7}, Landroid/graphics/Canvas;->translate(FF)V

    .line 342
    invoke-virtual {v5, p1, p2, p3}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    .line 343
    neg-int v6, v0

    int-to-float v6, v6

    invoke-virtual {p1, v6, v7}, Landroid/graphics/Canvas;->translate(FF)V

    .line 344
    move-object v1, v5

    .line 337
    .end local v5    # "symbol":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 346
    :cond_1
    if-eqz v1, :cond_2

    .line 347
    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getWidth()I

    move-result v2

    add-int/2addr v2, v0

    return v2

    .line 349
    :cond_2
    return v0
.end method

.method public drawNoteLetters(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V
    .locals 10
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I
    .param p4, "topstaff"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 415
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    array-length v1, v1

    const/4 v2, 0x0

    invoke-static {v0, v2, v1}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->NotesOverlap([Lnet/duceng/xmidi/widgets/score/NoteData;II)Z

    move-result v0

    .line 416
    .local v0, "overlap":Z
    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 417
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    array-length v3, v1

    :goto_0
    if-ge v2, v3, :cond_3

    aget-object v4, v1, v2

    .line 418
    .local v4, "note":Lnet/duceng/xmidi/widgets/score/NoteData;
    iget-boolean v5, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->leftside:Z

    if-eqz v5, :cond_2

    .line 419
    iget-object v5, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {p4, v5}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    div-int/lit8 v5, v5, 0x2

    add-int/2addr v5, p3

    .line 420
    .local v5, "ynote":I
    const/16 v6, 0xf

    .line 421
    .local v6, "xnote":I
    iget-object v7, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v8, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v8, :cond_0

    iget-object v7, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v8, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedQuarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v8, :cond_0

    iget-object v7, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v8, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v8, :cond_0

    if-eqz v0, :cond_1

    .line 422
    :cond_0
    const/16 v6, 0x14

    .line 424
    :cond_1
    iget v7, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->number:I

    iget-object v8, v4, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {p0, v7, v8}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->NoteName(ILnet/duceng/xmidi/widgets/score/WhiteNote;)Ljava/lang/String;

    move-result-object v7

    int-to-float v8, v6

    add-int/lit8 v9, v5, 0x4

    int-to-float v9, v9

    invoke-virtual {p1, v7, v8, v9, p2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 417
    .end local v4    # "note":Lnet/duceng/xmidi/widgets/score/NoteData;
    .end local v5    # "ynote":I
    .end local v6    # "xnote":I
    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 427
    :cond_3
    return-void
.end method

.method public drawNotes(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V
    .locals 25
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I
    .param p4, "topstaff"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 353
    move-object/from16 v6, p1

    move-object/from16 v7, p2

    move-object/from16 v8, p4

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {v7, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 354
    move-object/from16 v9, p0

    iget-object v10, v9, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    .line 355
    .local v10, "noteDataArr":[Lnet/duceng/xmidi/widgets/score/NoteData;
    array-length v11, v10

    .line 356
    .local v11, "length":I
    const/4 v0, 0x0

    move v12, v0

    .line 358
    .local v12, "i":I
    :goto_0
    move v13, v12

    .line 359
    .local v13, "i2":I
    if-ge v13, v11, :cond_9

    .line 360
    aget-object v14, v10, v13

    .line 361
    .local v14, "note":Lnet/duceng/xmidi/widgets/score/NoteData;
    iget-object v0, v14, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v8, v0}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v0

    mul-int/lit8 v0, v0, 0x8

    const/4 v15, 0x2

    div-int/2addr v0, v15

    add-int v16, p3, v0

    .line 362
    .local v16, "ynote":I
    const/4 v0, 0x1

    .line 363
    .local v0, "xnote":I
    iget-boolean v1, v14, Lnet/duceng/xmidi/widgets/score/NoteData;->leftside:Z

    if-nez v1, :cond_0

    .line 364
    const/16 v0, 0xb

    move/from16 v17, v0

    goto :goto_1

    .line 363
    :cond_0
    move/from16 v17, v0

    .line 366
    .end local v0    # "xnote":I
    .local v17, "xnote":I
    :goto_1
    add-int/lit8 v0, v17, 0x5

    const/4 v5, 0x1

    add-int/2addr v0, v5

    int-to-float v0, v0

    add-int/lit8 v1, v16, -0x1

    add-int/lit8 v1, v1, 0x4

    int-to-float v1, v1

    invoke-virtual {v6, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 367
    const/high16 v0, -0x3dcc0000    # -45.0f

    invoke-virtual {v6, v0}, Landroid/graphics/Canvas;->rotate(F)V

    .line 368
    iget-object v0, v14, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/high16 v2, -0x3f800000    # -4.0f

    const/high16 v3, 0x40400000    # 3.0f

    const/high16 v4, 0x40a00000    # 5.0f

    const/high16 v15, -0x3f600000    # -5.0f

    if-eq v0, v1, :cond_2

    iget-object v0, v14, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v0, v1, :cond_2

    iget-object v0, v14, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v0, v1, :cond_1

    goto :goto_2

    .line 376
    :cond_1
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 377
    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0, v15, v2, v4, v3}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 378
    .local v0, "rect4":Landroid/graphics/RectF;
    invoke-virtual {v6, v0, v7}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 379
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    goto :goto_3

    .line 369
    .end local v0    # "rect4":Landroid/graphics/RectF;
    :cond_2
    :goto_2
    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0, v15, v2, v4, v3}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 370
    .local v0, "rect":Landroid/graphics/RectF;
    invoke-virtual {v6, v0, v7}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 371
    new-instance v1, Landroid/graphics/RectF;

    const/high16 v2, -0x3fc00000    # -3.0f

    invoke-direct {v1, v15, v2, v4, v3}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 372
    .local v1, "rect2":Landroid/graphics/RectF;
    invoke-virtual {v6, v1, v7}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 373
    new-instance v3, Landroid/graphics/RectF;

    const/high16 v5, 0x40000000    # 2.0f

    invoke-direct {v3, v15, v2, v4, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    move-object v2, v3

    .line 374
    .local v2, "rect3":Landroid/graphics/RectF;
    invoke-virtual {v6, v2, v7}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 375
    .end local v0    # "rect":Landroid/graphics/RectF;
    .end local v1    # "rect2":Landroid/graphics/RectF;
    .end local v2    # "rect3":Landroid/graphics/RectF;
    nop

    .line 381
    :goto_3
    const/high16 v0, 0x42340000    # 45.0f

    invoke-virtual {v6, v0}, Landroid/graphics/Canvas;->rotate(F)V

    .line 382
    add-int/lit8 v0, v17, 0x5

    const/4 v1, 0x1

    add-int/2addr v0, v1

    neg-int v0, v0

    int-to-float v0, v0

    add-int/lit8 v1, v16, -0x1

    add-int/lit8 v1, v1, 0x4

    neg-int v1, v1

    int-to-float v1, v1

    invoke-virtual {v6, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 383
    iget-object v0, v14, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v0, v1, :cond_3

    iget-object v0, v14, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedQuarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v0, v1, :cond_3

    iget-object v0, v14, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v0, v1, :cond_4

    .line 384
    :cond_3
    new-instance v0, Landroid/graphics/RectF;

    add-int/lit8 v1, v17, 0xa

    const/4 v2, 0x2

    add-int/2addr v1, v2

    int-to-float v1, v1

    add-int/lit8 v3, v16, 0x2

    int-to-float v3, v3

    add-int/lit8 v4, v17, 0xa

    add-int/2addr v4, v2

    add-int/lit8 v4, v4, 0x4

    int-to-float v2, v4

    add-int/lit8 v4, v16, 0x2

    add-int/lit8 v4, v4, 0x4

    int-to-float v4, v4

    invoke-direct {v0, v1, v3, v2, v4}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 385
    .local v0, "rect5":Landroid/graphics/RectF;
    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 386
    invoke-virtual {v6, v0, v7}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 387
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 389
    .end local v0    # "rect5":Landroid/graphics/RectF;
    :cond_4
    const/4 v0, 0x1

    invoke-virtual {v8, v0}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v15

    .line 390
    .local v15, "top":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    iget-object v0, v14, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v0, v15}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v5

    .line 391
    .local v5, "dist":I
    add-int/lit8 v0, p3, -0x1

    .line 392
    .local v0, "y":I
    const/4 v1, 0x2

    if-lt v5, v1, :cond_6

    .line 393
    const/4 v1, 0x2

    move v4, v1

    .local v4, "i3":I
    :goto_4
    if-gt v4, v5, :cond_5

    .line 394
    add-int/lit8 v3, v0, -0x8

    .line 395
    .end local v0    # "y":I
    .local v3, "y":I
    add-int/lit8 v0, v17, -0x1

    int-to-float v1, v0

    int-to-float v2, v3

    add-int/lit8 v0, v17, 0xa

    const/16 v19, 0x1

    add-int/lit8 v0, v0, 0x1

    int-to-float v0, v0

    move/from16 v20, v4

    .end local v4    # "i3":I
    .local v20, "i3":I
    int-to-float v4, v3

    move/from16 v21, v0

    move-object/from16 v0, p1

    move/from16 v22, v3

    .end local v3    # "y":I
    .local v22, "y":I
    move/from16 v3, v21

    move/from16 v19, v5

    const/16 v21, 0x1

    .end local v5    # "dist":I
    .local v19, "dist":I
    move-object/from16 v5, p2

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 393
    add-int/lit8 v4, v20, 0x2

    move/from16 v5, v19

    move/from16 v0, v22

    .end local v20    # "i3":I
    .restart local v4    # "i3":I
    goto :goto_4

    .end local v19    # "dist":I
    .end local v22    # "y":I
    .restart local v0    # "y":I
    .restart local v5    # "dist":I
    :cond_5
    move/from16 v20, v4

    move/from16 v19, v5

    const/16 v21, 0x1

    .end local v4    # "i3":I
    .end local v5    # "dist":I
    .restart local v19    # "dist":I
    .restart local v20    # "i3":I
    move/from16 v20, v0

    goto :goto_5

    .line 392
    .end local v19    # "dist":I
    .end local v20    # "i3":I
    .restart local v5    # "dist":I
    :cond_6
    move/from16 v19, v5

    const/16 v21, 0x1

    .end local v5    # "dist":I
    .restart local v19    # "dist":I
    move/from16 v20, v0

    .line 398
    .end local v0    # "y":I
    .local v20, "y":I
    :goto_5
    const/4 v0, -0x8

    invoke-virtual {v15, v0}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v5

    .line 399
    .local v5, "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    add-int/lit8 v0, p3, 0x20

    add-int/lit8 v0, v0, -0x1

    .line 400
    .local v0, "y2":I
    iget-object v1, v14, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v5, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v4

    .line 401
    .local v4, "dist2":I
    const/4 v1, 0x2

    if-lt v4, v1, :cond_8

    .line 402
    const/4 v1, 0x2

    move v3, v1

    .local v3, "i4":I
    :goto_6
    if-gt v3, v4, :cond_7

    .line 403
    add-int/lit8 v2, v0, 0x8

    .line 404
    .end local v0    # "y2":I
    .local v2, "y2":I
    add-int/lit8 v0, v17, -0x1

    int-to-float v1, v0

    int-to-float v0, v2

    add-int/lit8 v18, v17, 0xa

    move/from16 v22, v0

    add-int/lit8 v0, v18, 0x1

    int-to-float v0, v0

    move/from16 v18, v4

    .end local v4    # "dist2":I
    .local v18, "dist2":I
    int-to-float v4, v2

    move/from16 v23, v0

    move-object/from16 v0, p1

    move/from16 v24, v2

    .end local v2    # "y2":I
    .local v24, "y2":I
    move/from16 v2, v22

    move/from16 v22, v3

    .end local v3    # "i4":I
    .local v22, "i4":I
    move/from16 v3, v23

    move-object/from16 v23, v5

    .end local v5    # "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .local v23, "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    move-object/from16 v5, p2

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 402
    add-int/lit8 v3, v22, 0x2

    move/from16 v4, v18

    move-object/from16 v5, v23

    move/from16 v0, v24

    .end local v22    # "i4":I
    .restart local v3    # "i4":I
    goto :goto_6

    .end local v18    # "dist2":I
    .end local v23    # "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .end local v24    # "y2":I
    .restart local v0    # "y2":I
    .restart local v4    # "dist2":I
    .restart local v5    # "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :cond_7
    move/from16 v22, v3

    move/from16 v18, v4

    move-object/from16 v23, v5

    .end local v3    # "i4":I
    .end local v4    # "dist2":I
    .end local v5    # "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .restart local v18    # "dist2":I
    .restart local v22    # "i4":I
    .restart local v23    # "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    goto :goto_7

    .line 401
    .end local v18    # "dist2":I
    .end local v22    # "i4":I
    .end local v23    # "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .restart local v4    # "dist2":I
    .restart local v5    # "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :cond_8
    move/from16 v18, v4

    move-object/from16 v23, v5

    .line 407
    .end local v4    # "dist2":I
    .end local v5    # "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .restart local v18    # "dist2":I
    .restart local v23    # "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :goto_7
    add-int/lit8 v12, v13, 0x1

    .line 408
    .end local v0    # "y2":I
    .end local v14    # "note":Lnet/duceng/xmidi/widgets/score/NoteData;
    .end local v15    # "top":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .end local v16    # "ynote":I
    .end local v17    # "xnote":I
    .end local v18    # "dist2":I
    .end local v19    # "dist":I
    .end local v20    # "y":I
    .end local v23    # "bottom":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    nop

    .line 411
    .end local v13    # "i2":I
    goto/16 :goto_0

    .line 409
    .restart local v13    # "i2":I
    :cond_9
    return-void
.end method

.method public getAboveStaff()I
    .locals 8

    .line 185
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    array-length v1, v1

    add-int/lit8 v1, v1, -0x1

    aget-object v0, v0, v1

    iget-object v0, v0, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 186
    .local v0, "topnote":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    if-eqz v1, :cond_0

    .line 187
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    invoke-static {v0, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Max(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    .line 189
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    if-eqz v1, :cond_1

    .line 190
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    invoke-static {v0, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Max(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    .line 192
    :cond_1
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-static {v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Top(Lnet/duceng/xmidi/widgets/score/Clef;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v1

    mul-int/lit8 v1, v1, 0x8

    div-int/lit8 v1, v1, 0x2

    .line 193
    .local v1, "dist":I
    const/4 v2, 0x0

    .line 194
    .local v2, "result":I
    if-lez v1, :cond_2

    .line 195
    move v2, v1

    .line 197
    :cond_2
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->accidsymbols:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    array-length v4, v3

    const/4 v5, 0x0

    :goto_0
    if-ge v5, v4, :cond_4

    aget-object v6, v3, v5

    .line 198
    .local v6, "symbol":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getAboveStaff()I

    move-result v7

    if-le v7, v2, :cond_3

    .line 199
    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getAboveStaff()I

    move-result v2

    .line 197
    .end local v6    # "symbol":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    :cond_3
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 202
    :cond_4
    return v2
.end method

.method public getBelowStaff()I
    .locals 8

    .line 207
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    iget-object v0, v0, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 208
    .local v0, "bottomnote":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    if-eqz v2, :cond_0

    .line 209
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v2

    invoke-static {v0, v2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Min(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    .line 211
    :cond_0
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    if-eqz v2, :cond_1

    .line 212
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v2

    invoke-static {v0, v2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Min(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    .line 214
    :cond_1
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-static {v2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Bottom(Lnet/duceng/xmidi/widgets/score/Clef;)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v2

    invoke-virtual {v2, v0}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v2

    mul-int/lit8 v2, v2, 0x8

    div-int/lit8 v2, v2, 0x2

    .line 215
    .local v2, "dist":I
    const/4 v3, 0x0

    .line 216
    .local v3, "result":I
    if-lez v2, :cond_2

    .line 217
    move v3, v2

    .line 219
    :cond_2
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->accidsymbols:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    array-length v5, v4

    :goto_0
    if-ge v1, v5, :cond_4

    aget-object v6, v4, v1

    .line 220
    .local v6, "symbol":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getBelowStaff()I

    move-result v7

    if-le v7, v3, :cond_3

    .line 221
    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getBelowStaff()I

    move-result v3

    .line 219
    .end local v6    # "symbol":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 224
    :cond_4
    return v3
.end method

.method public getClef()Lnet/duceng/xmidi/widgets/score/Clef;
    .locals 1

    .line 137
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    return-object v0
.end method

.method public getEndTime()I
    .locals 1

    .line 133
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->endtime:I

    return v0
.end method

.method public getHasTwoStems()Z
    .locals 1

    .line 141
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->hastwostems:Z

    return v0
.end method

.method public getMinWidth()I
    .locals 6

    .line 166
    const/16 v0, 0x10

    .line 167
    .local v0, "result":I
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->accidsymbols:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    array-length v1, v1

    if-lez v1, :cond_2

    .line 168
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->accidsymbols:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    const/4 v2, 0x0

    aget-object v1, v1, v2

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getMinWidth()I

    move-result v1

    add-int/lit8 v1, v1, 0x10

    .line 169
    .end local v0    # "result":I
    .local v1, "result":I
    const/4 v0, 0x1

    .local v0, "i":I
    :goto_0
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->accidsymbols:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    array-length v2, v2

    if-ge v0, v2, :cond_1

    .line 170
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->accidsymbols:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    aget-object v2, v2, v0

    .line 171
    .local v2, "accid":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->accidsymbols:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    add-int/lit8 v4, v0, -0x1

    aget-object v3, v3, v4

    .line 172
    .local v3, "prev":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getNote()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v4

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getNote()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v5

    invoke-virtual {v4, v5}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v4

    const/4 v5, 0x6

    if-ge v4, v5, :cond_0

    .line 173
    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getMinWidth()I

    move-result v4

    add-int/2addr v1, v4

    .line 169
    .end local v2    # "accid":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    .end local v3    # "prev":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    move v0, v1

    .line 177
    .end local v1    # "result":I
    .local v0, "result":I
    :cond_2
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    if-eqz v1, :cond_3

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->musicScore:Lnet/duceng/xmidi/widgets/MusicScore;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/MusicScore;->getShowNoteLetters()I

    move-result v1

    if-eqz v1, :cond_3

    .line 178
    add-int/lit8 v1, v0, 0x8

    return v1

    .line 180
    :cond_3
    return v0
.end method

.method public getStartTime()I
    .locals 1

    .line 129
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->starttime:I

    return v0
.end method

.method public getStem()Lnet/duceng/xmidi/widgets/score/Stem;
    .locals 2

    .line 145
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    if-nez v0, :cond_0

    .line 146
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    return-object v0

    .line 148
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/Stem;->getDuration()Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->getDuration()Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v1

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    if-lt v0, v1, :cond_1

    .line 149
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    return-object v0

    .line 151
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    return-object v0
.end method

.method public getWidth()I
    .locals 1

    .line 156
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->width:I

    return v0
.end method

.method public setWidth(I)V
    .locals 0
    .param p1, "value"    # I

    .line 161
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->width:I

    .line 162
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 15

    .line 636
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStartTime()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getEndTime()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getWidth()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iget-boolean v4, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->hastwostems:Z

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v5, 0x5

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v6, 0x0

    aput-object v0, v5, v6

    const/4 v0, 0x1

    aput-object v1, v5, v0

    const/4 v1, 0x2

    aput-object v2, v5, v1

    const/4 v2, 0x3

    aput-object v3, v5, v2

    const/4 v3, 0x4

    aput-object v4, v5, v3

    const-string v3, "ChordSymbol clef=%1$s start=%2$s end=%3$s width=%4$s hastwostems=%5$s "

    invoke-static {v3, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .line 637
    .local v3, "result":Ljava/lang/String;
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->accidsymbols:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    array-length v5, v4

    const/4 v7, 0x0

    :goto_0
    const-string v8, " "

    if-ge v7, v5, :cond_0

    aget-object v9, v4, v7

    .line 638
    .local v9, "symbol":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v9}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 637
    .end local v9    # "symbol":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    .line 640
    :cond_0
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->notedata:[Lnet/duceng/xmidi/widgets/score/NoteData;

    array-length v5, v4

    const/4 v7, 0x0

    :goto_1
    if-ge v7, v5, :cond_1

    aget-object v9, v4, v7

    .line 641
    .local v9, "note":Lnet/duceng/xmidi/widgets/score/NoteData;
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    iget-object v11, v9, Lnet/duceng/xmidi/widgets/score/NoteData;->whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    iget-object v12, v9, Lnet/duceng/xmidi/widgets/score/NoteData;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    iget-boolean v13, v9, Lnet/duceng/xmidi/widgets/score/NoteData;->leftside:Z

    invoke-static {v13}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v13

    new-array v14, v2, [Ljava/lang/Object;

    aput-object v11, v14, v6

    aput-object v12, v14, v0

    aput-object v13, v14, v1

    const-string v11, "Note whitenote=%1$s duration=%2$s leftside=%3$s "

    invoke-static {v11, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 640
    .end local v9    # "note":Lnet/duceng/xmidi/widgets/score/NoteData;
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 643
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    if-eqz v0, :cond_2

    .line 644
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem1:Lnet/duceng/xmidi/widgets/score/Stem;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 646
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    if-eqz v0, :cond_3

    .line 647
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->stem2:Lnet/duceng/xmidi/widgets/score/Stem;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/Stem;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 649
    :cond_3
    return-object v3
.end method
