.class public final enum Lnet/duceng/xmidi/widgets/score/Clef;
.super Ljava/lang/Enum;
.source "Clef.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lnet/duceng/xmidi/widgets/score/Clef;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lnet/duceng/xmidi/widgets/score/Clef;

.field public static final enum Bass:Lnet/duceng/xmidi/widgets/score/Clef;

.field public static final enum Treble:Lnet/duceng/xmidi/widgets/score/Clef;


# direct methods
.method private static synthetic $values()[Lnet/duceng/xmidi/widgets/score/Clef;
    .locals 3

    .line 4
    const/4 v0, 0x2

    new-array v0, v0, [Lnet/duceng/xmidi/widgets/score/Clef;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/Clef;->Bass:Lnet/duceng/xmidi/widgets/score/Clef;

    const/4 v2, 0x1

    aput-object v1, v0, v2

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 5
    new-instance v0, Lnet/duceng/xmidi/widgets/score/Clef;

    const-string v1, "Treble"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/Clef;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    .line 6
    new-instance v0, Lnet/duceng/xmidi/widgets/score/Clef;

    const-string v1, "Bass"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/Clef;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/Clef;->Bass:Lnet/duceng/xmidi/widgets/score/Clef;

    .line 4
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/Clef;->$values()[Lnet/duceng/xmidi/widgets/score/Clef;

    move-result-object v0

    sput-object v0, Lnet/duceng/xmidi/widgets/score/Clef;->$VALUES:[Lnet/duceng/xmidi/widgets/score/Clef;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 4
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lnet/duceng/xmidi/widgets/score/Clef;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .line 4
    const-class v0, Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/widgets/score/Clef;

    return-object v0
.end method

.method public static values()[Lnet/duceng/xmidi/widgets/score/Clef;
    .locals 1

    .line 4
    sget-object v0, Lnet/duceng/xmidi/widgets/score/Clef;->$VALUES:[Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-virtual {v0}, [Lnet/duceng/xmidi/widgets/score/Clef;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lnet/duceng/xmidi/widgets/score/Clef;

    return-object v0
.end method

.method public static valuesCustom()[Lnet/duceng/xmidi/widgets/score/Clef;
    .locals 4

    .line 10
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/Clef;->values()[Lnet/duceng/xmidi/widgets/score/Clef;

    move-result-object v0

    .line 11
    .local v0, "clefArrValuesCustom":[Lnet/duceng/xmidi/widgets/score/Clef;
    array-length v1, v0

    .line 12
    .local v1, "length":I
    new-array v2, v1, [Lnet/duceng/xmidi/widgets/score/Clef;

    .line 13
    .local v2, "clefArr":[Lnet/duceng/xmidi/widgets/score/Clef;
    const/4 v3, 0x0

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 14
    return-object v2
.end method
