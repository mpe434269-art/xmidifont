.class public Lnet/duceng/xmidi/widgets/score/ClefMeasures;
.super Ljava/lang/Object;
.source "ClefMeasures.java"


# instance fields
.field private clefs:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Clef;",
            ">;"
        }
    .end annotation
.end field

.field private measure:I


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;I)V
    .locals 8
    .param p2, "measurelen"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Note;",
            ">;I)V"
        }
    .end annotation

    .line 10
    .local p1, "notes":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->measure:I

    .line 12
    invoke-static {p1}, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->mainClef(Ljava/util/ArrayList;)Lnet/duceng/xmidi/widgets/score/Clef;

    move-result-object v0

    .line 13
    .local v0, "mainclef":Lnet/duceng/xmidi/widgets/score/Clef;
    move v1, p2

    .line 14
    .local v1, "nextmeasure":I
    const/4 v2, 0x0

    .line 15
    .local v2, "pos":I
    move-object v3, v0

    .line 16
    .local v3, "clef":Lnet/duceng/xmidi/widgets/score/Clef;
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->clefs:Ljava/util/ArrayList;

    .line 17
    :goto_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v2, v4, :cond_5

    .line 18
    const/4 v4, 0x0

    .line 19
    .local v4, "sumnotes":I
    const/4 v5, 0x0

    .line 20
    .local v5, "notecount":I
    :goto_1
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v6

    if-ge v2, v6, :cond_0

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/Note;->getStartTick()I

    move-result v6

    if-ge v6, v1, :cond_0

    .line 21
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v6

    add-int/2addr v4, v6

    .line 22
    add-int/lit8 v5, v5, 0x1

    .line 23
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 25
    :cond_0
    if-nez v5, :cond_1

    const/4 v6, 0x1

    goto :goto_2

    :cond_1
    move v6, v5

    :goto_2
    div-int v6, v4, v6

    .line 26
    .local v6, "avgnote":I
    if-eqz v6, :cond_4

    .line 27
    sget-object v7, Lnet/duceng/xmidi/widgets/score/WhiteNote;->BottomTreble:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v7}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->getNumber()I

    move-result v7

    if-lt v6, v7, :cond_2

    .line 28
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    goto :goto_3

    .line 29
    :cond_2
    sget-object v7, Lnet/duceng/xmidi/widgets/score/WhiteNote;->TopBass:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v7}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->getNumber()I

    move-result v7

    if-gt v6, v7, :cond_3

    .line 30
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Clef;->Bass:Lnet/duceng/xmidi/widgets/score/Clef;

    goto :goto_3

    .line 32
    :cond_3
    move-object v3, v0

    .line 35
    :cond_4
    :goto_3
    iget-object v7, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->clefs:Ljava/util/ArrayList;

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    add-int/2addr v1, p2

    .line 37
    .end local v4    # "sumnotes":I
    .end local v5    # "notecount":I
    .end local v6    # "avgnote":I
    goto :goto_0

    .line 38
    :cond_5
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->clefs:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 39
    return-void
.end method

.method public constructor <init>(Ljava/util/ArrayList;ILnet/duceng/xmidi/widgets/score/Clef;)V
    .locals 7
    .param p2, "measurelen"    # I
    .param p3, "mainclef"    # Lnet/duceng/xmidi/widgets/score/Clef;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Note;",
            ">;I",
            "Lnet/duceng/xmidi/widgets/score/Clef;",
            ")V"
        }
    .end annotation

    .line 41
    .local p1, "notes":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 42
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->measure:I

    .line 43
    move v0, p2

    .line 44
    .local v0, "nextmeasure":I
    const/4 v1, 0x0

    .line 45
    .local v1, "pos":I
    move-object v2, p3

    .line 46
    .local v2, "clef":Lnet/duceng/xmidi/widgets/score/Clef;
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->clefs:Ljava/util/ArrayList;

    .line 47
    :goto_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_5

    .line 48
    const/4 v3, 0x0

    .line 49
    .local v3, "sumnotes":I
    const/4 v4, 0x0

    .line 50
    .local v4, "notecount":I
    :goto_1
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v1, v5, :cond_0

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Note;->getStartTick()I

    move-result v5

    if-ge v5, v0, :cond_0

    .line 51
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {v5}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v5

    add-int/2addr v3, v5

    .line 52
    add-int/lit8 v4, v4, 0x1

    .line 53
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 55
    :cond_0
    if-nez v4, :cond_1

    const/4 v5, 0x1

    goto :goto_2

    :cond_1
    move v5, v4

    :goto_2
    div-int v5, v3, v5

    .line 56
    .local v5, "avgnote":I
    if-eqz v5, :cond_4

    .line 57
    sget-object v6, Lnet/duceng/xmidi/widgets/score/WhiteNote;->BottomTreble:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->getNumber()I

    move-result v6

    if-lt v5, v6, :cond_2

    .line 58
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    goto :goto_3

    .line 59
    :cond_2
    sget-object v6, Lnet/duceng/xmidi/widgets/score/WhiteNote;->TopBass:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->getNumber()I

    move-result v6

    if-gt v5, v6, :cond_3

    .line 60
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Clef;->Bass:Lnet/duceng/xmidi/widgets/score/Clef;

    goto :goto_3

    .line 62
    :cond_3
    move-object v2, p3

    .line 65
    :cond_4
    :goto_3
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->clefs:Ljava/util/ArrayList;

    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 66
    add-int/2addr v0, p2

    .line 67
    .end local v3    # "sumnotes":I
    .end local v4    # "notecount":I
    .end local v5    # "avgnote":I
    goto :goto_0

    .line 68
    :cond_5
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->clefs:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 69
    return-void
.end method

.method private static mainClef(Ljava/util/ArrayList;)Lnet/duceng/xmidi/widgets/score/Clef;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Note;",
            ">;)",
            "Lnet/duceng/xmidi/widgets/score/Clef;"
        }
    .end annotation

    .line 76
    .local p0, "notes":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;"
    sget-object v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->MiddleC:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->getNumber()I

    move-result v0

    .line 77
    .local v0, "middleC":I
    const/4 v1, 0x0

    .line 78
    .local v1, "total":I
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/Note;

    .line 79
    .local v3, "m":Lnet/duceng/xmidi/widgets/score/Note;
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v4

    add-int/2addr v1, v4

    .line 80
    .end local v3    # "m":Lnet/duceng/xmidi/widgets/score/Note;
    goto :goto_0

    .line 81
    :cond_0
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-nez v2, :cond_1

    .line 82
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    return-object v2

    .line 84
    :cond_1
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v2

    div-int v2, v1, v2

    if-lt v2, v0, :cond_2

    .line 85
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    return-object v2

    .line 87
    :cond_2
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Clef;->Bass:Lnet/duceng/xmidi/widgets/score/Clef;

    return-object v2
.end method


# virtual methods
.method public getClef(I)Lnet/duceng/xmidi/widgets/score/Clef;
    .locals 2
    .param p1, "starttime"    # I

    .line 72
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->measure:I

    div-int v0, p1, v0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->clefs:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lt v0, v1, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->clefs:Ljava/util/ArrayList;

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->clefs:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->clefs:Ljava/util/ArrayList;

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/ClefMeasures;->measure:I

    div-int v1, p1, v1

    :goto_0
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/widgets/score/Clef;

    return-object v0
.end method
