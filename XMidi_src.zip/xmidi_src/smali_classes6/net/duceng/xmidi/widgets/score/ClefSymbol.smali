.class public Lnet/duceng/xmidi/widgets/score/ClefSymbol;
.super Ljava/lang/Object;
.source "ClefSymbol.java"

# interfaces
.implements Lnet/duceng/xmidi/widgets/score/MusicSymbol;


# static fields
.field private static bass:Landroid/graphics/Bitmap;

.field public static treble:Landroid/graphics/Bitmap;


# instance fields
.field private clef:Lnet/duceng/xmidi/widgets/score/Clef;

.field private smallsize:Z

.field private starttime:I

.field private width:I


# direct methods
.method public constructor <init>(Lnet/duceng/xmidi/widgets/score/Clef;IZ)V
    .locals 2
    .param p1, "clef"    # Lnet/duceng/xmidi/widgets/score/Clef;
    .param p2, "starttime"    # I
    .param p3, "small"    # Z

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    sget-object v0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->treble:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    sget-object v0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->bass:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    .line 25
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    .line 26
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->starttime:I

    .line 27
    iput-boolean p3, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->smallsize:Z

    .line 28
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->getMinWidth()I

    move-result v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->width:I

    .line 29
    return-void

    .line 23
    :cond_0
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "ClefSymbol.LoadImages(Context) will be call first!"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static LoadImages(Landroid/content/Context;)V
    .locals 2
    .param p0, "context"    # Landroid/content/Context;

    .line 32
    sget-object v0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->treble:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    sget-object v0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->bass:Landroid/graphics/Bitmap;

    if-nez v0, :cond_1

    .line 33
    :cond_0
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    .line 34
    .local v0, "res":Landroid/content/res/Resources;
    const v1, 0x7f030062

    invoke-static {v0, v1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v1

    sput-object v1, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->treble:Landroid/graphics/Bitmap;

    .line 35
    const/high16 v1, 0x7f030000

    invoke-static {v0, v1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v1

    sput-object v1, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->bass:Landroid/graphics/Bitmap;

    .line 37
    .end local v0    # "res":Landroid/content/res/Resources;
    :cond_1
    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 10
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 79
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->getMinWidth()I

    move-result v1

    sub-int/2addr v0, v1

    int-to-float v0, v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 80
    move v0, p3

    .line 81
    .local v0, "y":I
    const/4 v2, 0x1

    invoke-virtual {p2, v2}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 82
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    sget-object v3, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    if-ne v2, v3, :cond_1

    .line 83
    sget-object v2, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->treble:Landroid/graphics/Bitmap;

    .line 84
    .local v2, "image":Landroid/graphics/Bitmap;
    iget-boolean v3, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->smallsize:Z

    if-eqz v3, :cond_0

    .line 85
    const/16 v3, 0x29

    .local v3, "height":I
    goto :goto_0

    .line 87
    .end local v3    # "height":I
    :cond_0
    const/16 v3, 0x36

    .line 88
    .restart local v3    # "height":I
    add-int/lit8 v0, p3, -0xc

    goto :goto_0

    .line 91
    .end local v2    # "image":Landroid/graphics/Bitmap;
    .end local v3    # "height":I
    :cond_1
    sget-object v2, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->bass:Landroid/graphics/Bitmap;

    .line 92
    .restart local v2    # "image":Landroid/graphics/Bitmap;
    iget-boolean v3, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->smallsize:Z

    if-eqz v3, :cond_2

    .line 93
    const/16 v3, 0x15

    .restart local v3    # "height":I
    goto :goto_0

    .line 95
    .end local v3    # "height":I
    :cond_2
    const/16 v3, 0x19

    .line 98
    .restart local v3    # "height":I
    :goto_0
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v4

    mul-int v4, v4, v3

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    div-int/2addr v4, v5

    .line 99
    .local v4, "imgwidth":I
    new-instance v5, Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v6

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v7

    const/4 v8, 0x0

    invoke-direct {v5, v8, v8, v6, v7}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 100
    .local v5, "src":Landroid/graphics/Rect;
    new-instance v6, Landroid/graphics/Rect;

    add-int/lit8 v7, v4, 0x0

    add-int v9, v0, v3

    invoke-direct {v6, v8, v0, v7, v9}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 101
    .local v6, "dest":Landroid/graphics/Rect;
    invoke-virtual {p1, v2, v5, v6, p2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 102
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->getWidth()I

    move-result v7

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->getMinWidth()I

    move-result v8

    sub-int/2addr v7, v8

    neg-int v7, v7

    int-to-float v7, v7

    invoke-virtual {p1, v7, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 103
    return-void
.end method

.method public getAboveStaff()I
    .locals 2

    .line 61
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    if-ne v0, v1, :cond_1

    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->smallsize:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/16 v0, 0x10

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x0

    :goto_1
    return v0
.end method

.method public getBelowStaff()I
    .locals 2

    .line 66
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    if-ne v0, v1, :cond_0

    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->smallsize:Z

    if-nez v0, :cond_0

    .line 67
    const/16 v0, 0x10

    return v0

    .line 69
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    if-ne v0, v1, :cond_1

    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->smallsize:Z

    if-eqz v0, :cond_1

    .line 70
    const/16 v0, 0x8

    return v0

    .line 72
    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public getMinWidth()I
    .locals 1

    .line 46
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->smallsize:Z

    if-eqz v0, :cond_0

    const/16 v0, 0x14

    goto :goto_0

    :cond_0
    const/16 v0, 0x1e

    :goto_0
    return v0
.end method

.method public getStartTime()I
    .locals 1

    .line 41
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->starttime:I

    return v0
.end method

.method public getWidth()I
    .locals 1

    .line 51
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->width:I

    return v0
.end method

.method public setWidth(I)V
    .locals 0
    .param p1, "value"    # I

    .line 56
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->width:I

    .line 57
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    .line 106
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->clef:Lnet/duceng/xmidi/widgets/score/Clef;

    iget-boolean v1, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->smallsize:Z

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->width:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v3, 0x3

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object v0, v3, v4

    const/4 v0, 0x1

    aput-object v1, v3, v0

    const/4 v0, 0x2

    aput-object v2, v3, v0

    const-string v0, "ClefSymbol clef=%1$s small=%2$s width=%3$s"

    invoke-static {v0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
