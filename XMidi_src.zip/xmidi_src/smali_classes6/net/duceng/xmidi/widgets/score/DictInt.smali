.class public Lnet/duceng/xmidi/widgets/score/DictInt;
.super Ljava/lang/Object;
.source "DictInt.java"


# instance fields
.field private keys:[I

.field private lastpos:I

.field private size:I

.field private values:[I


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->size:I

    .line 6
    iput v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    .line 7
    const/16 v0, 0x17

    new-array v1, v0, [I

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    .line 8
    new-array v0, v0, [I

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->values:[I

    return-void
.end method

.method private resize()V
    .locals 5

    .line 11
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    array-length v0, v0

    mul-int/lit8 v0, v0, 0x2

    .line 12
    .local v0, "newcapacity":I
    new-array v1, v0, [I

    .line 13
    .local v1, "newkeys":[I
    new-array v2, v0, [I

    .line 14
    .local v2, "newvalues":[I
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    array-length v4, v4

    if-ge v3, v4, :cond_0

    .line 15
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    aget v4, v4, v3

    aput v4, v1, v3

    .line 16
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->values:[I

    aget v4, v4, v3

    aput v4, v2, v3

    .line 14
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 18
    .end local v3    # "i":I
    :cond_0
    iput-object v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    .line 19
    iput-object v2, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->values:[I

    .line 20
    return-void
.end method


# virtual methods
.method public add(II)V
    .locals 4
    .param p1, "key"    # I
    .param p2, "value"    # I

    .line 23
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->size:I

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    array-length v1, v1

    if-ne v0, v1, :cond_0

    .line 24
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/score/DictInt;->resize()V

    .line 26
    :cond_0
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->size:I

    add-int/lit8 v0, v0, -0x1

    .line 27
    .local v0, "pos":I
    :goto_0
    if-ltz v0, :cond_1

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    aget v1, v1, v0

    if-ge p1, v1, :cond_1

    .line 28
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    add-int/lit8 v2, v0, 0x1

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    aget v3, v3, v0

    aput v3, v1, v2

    .line 29
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->values:[I

    add-int/lit8 v2, v0, 0x1

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->values:[I

    aget v3, v3, v0

    aput v3, v1, v2

    .line 30
    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    .line 32
    :cond_1
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    add-int/lit8 v2, v0, 0x1

    aput p1, v1, v2

    .line 33
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->values:[I

    add-int/lit8 v2, v0, 0x1

    aput p2, v1, v2

    .line 34
    iget v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->size:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->size:I

    .line 35
    return-void
.end method

.method public contains(I)Z
    .locals 4
    .param p1, "key"    # I

    .line 47
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->size:I

    const/4 v1, 0x0

    if-nez v0, :cond_0

    .line 48
    return v1

    .line 50
    :cond_0
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    if-ltz v0, :cond_1

    iget v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->size:I

    if-ge v0, v2, :cond_1

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    aget v0, v0, v2

    if-ge p1, v0, :cond_2

    .line 51
    :cond_1
    iput v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    .line 53
    :cond_2
    :goto_0
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->size:I

    const/4 v3, 0x1

    if-ge v0, v2, :cond_3

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    aget v0, v0, v2

    if-le p1, v0, :cond_3

    .line 54
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    add-int/2addr v0, v3

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    goto :goto_0

    .line 56
    :cond_3
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->size:I

    if-ge v0, v2, :cond_4

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    aget v0, v0, v2

    if-ne p1, v0, :cond_4

    const/4 v1, 0x1

    :cond_4
    return v1
.end method

.method count()I
    .locals 1

    .line 67
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->size:I

    return v0
.end method

.method get(I)I
    .locals 2
    .param p1, "key"    # I

    .line 60
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/widgets/score/DictInt;->contains(I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 61
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->values:[I

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    aget v0, v0, v1

    return v0

    .line 63
    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method getKey(I)I
    .locals 1
    .param p1, "index"    # I

    .line 71
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    aget v0, v0, p1

    return v0
.end method

.method public set(II)V
    .locals 2
    .param p1, "key"    # I
    .param p2, "value"    # I

    .line 38
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/widgets/score/DictInt;->contains(I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 39
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->keys:[I

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    aput p1, v0, v1

    .line 40
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->values:[I

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/DictInt;->lastpos:I

    aput p2, v0, v1

    goto :goto_0

    .line 42
    :cond_0
    invoke-virtual {p0, p1, p2}, Lnet/duceng/xmidi/widgets/score/DictInt;->add(II)V

    .line 44
    :goto_0
    return-void
.end method
