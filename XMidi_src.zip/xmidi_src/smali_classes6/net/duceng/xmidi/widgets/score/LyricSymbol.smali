.class public Lnet/duceng/xmidi/widgets/score/LyricSymbol;
.super Ljava/lang/Object;
.source "LyricSymbol.java"


# instance fields
.field private starttime:I

.field private text:Ljava/lang/String;

.field private x:I


# direct methods
.method public constructor <init>(ILjava/lang/String;)V
    .locals 0
    .param p1, "starttime"    # I
    .param p2, "text"    # Ljava/lang/String;

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->starttime:I

    .line 11
    iput-object p2, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->text:Ljava/lang/String;

    .line 12
    return-void
.end method


# virtual methods
.method public getMinWidth()I
    .locals 4

    .line 39
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->text:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    int-to-float v0, v0

    const v1, 0x40d55555

    mul-float v0, v0, v1

    .line 40
    .local v0, "width":F
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->text:Ljava/lang/String;

    const-string v2, "i"

    invoke-virtual {v1, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    const v2, 0x40555555

    if-ltz v1, :cond_0

    .line 41
    sub-float/2addr v0, v2

    .line 43
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->text:Ljava/lang/String;

    const-string v3, "j"

    invoke-virtual {v1, v3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    if-ltz v1, :cond_1

    .line 44
    sub-float/2addr v0, v2

    .line 46
    :cond_1
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->text:Ljava/lang/String;

    const-string v3, "l"

    invoke-virtual {v1, v3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    if-ltz v1, :cond_2

    .line 47
    sub-float/2addr v0, v2

    .line 49
    :cond_2
    float-to-int v1, v0

    return v1
.end method

.method public getStartTime()I
    .locals 1

    .line 15
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->starttime:I

    return v0
.end method

.method public getText()Ljava/lang/String;
    .locals 1

    .line 23
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->text:Ljava/lang/String;

    return-object v0
.end method

.method public getX()I
    .locals 1

    .line 31
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->x:I

    return v0
.end method

.method public setStartTime(I)V
    .locals 0
    .param p1, "value"    # I

    .line 19
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->starttime:I

    .line 20
    return-void
.end method

.method public setText(Ljava/lang/String;)V
    .locals 0
    .param p1, "value"    # Ljava/lang/String;

    .line 27
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->text:Ljava/lang/String;

    .line 28
    return-void
.end method

.method public setX(I)V
    .locals 0
    .param p1, "value"    # I

    .line 35
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->x:I

    .line 36
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    .line 53
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->starttime:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->x:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->text:Ljava/lang/String;

    const/4 v3, 0x3

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object v0, v3, v4

    const/4 v0, 0x1

    aput-object v1, v3, v0

    const/4 v0, 0x2

    aput-object v2, v3, v0

    const-string v0, "Lyric start={0} x={1} text={2}"

    invoke-static {v0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
