.class public Lnet/duceng/xmidi/widgets/score/MidiKey;
.super Ljava/lang/Object;
.source "MidiKey.java"


# static fields
.field public static final A:I = 0x3

.field public static final Aflat:I = 0x4

.field public static final B:I = 0x5

.field public static final Bflat:I = 0x2

.field public static final C:I = 0x0

.field public static final D:I = 0x2

.field public static final Dflat:I = 0x5

.field public static final E:I = 0x4

.field public static final Eflat:I = 0x3

.field public static final F:I = 0x1

.field public static final G:I = 0x1

.field public static final Gflat:I = 0x6

.field private static flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

.field private static sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;


# instance fields
.field private bass:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

.field private keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

.field private num_flats:I

.field private num_sharps:I

.field private prevmeasure:I

.field private treble:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;


# direct methods
.method public constructor <init>(I)V
    .locals 5
    .param p1, "notescale"    # I

    .line 40
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 41
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    .line 42
    iput v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    .line 43
    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    packed-switch p1, :pswitch_data_0

    .line 80
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v0

    .line 77
    :pswitch_0
    iput v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    .line 78
    goto :goto_0

    .line 74
    :pswitch_1
    iput v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    .line 75
    goto :goto_0

    .line 71
    :pswitch_2
    const/4 v0, 0x6

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    .line 72
    goto :goto_0

    .line 68
    :pswitch_3
    iput v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    .line 69
    goto :goto_0

    .line 65
    :pswitch_4
    iput v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    .line 66
    goto :goto_0

    .line 62
    :pswitch_5
    iput v4, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    .line 63
    goto :goto_0

    .line 59
    :pswitch_6
    iput v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    .line 60
    goto :goto_0

    .line 56
    :pswitch_7
    iput v2, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    .line 57
    goto :goto_0

    .line 54
    :pswitch_8
    goto :goto_0

    .line 51
    :pswitch_9
    iput v2, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    .line 52
    goto :goto_0

    .line 48
    :pswitch_a
    iput v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    .line 49
    goto :goto_0

    .line 45
    :pswitch_b
    iput v4, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    .line 46
    nop

    .line 82
    :goto_0
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/MidiKey;->CreateAccidentalMaps()V

    .line 83
    const/16 v0, 0xa0

    new-array v0, v0, [Lnet/duceng/xmidi/widgets/score/Accid;

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    .line 84
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/score/MidiKey;->ResetKeyMap()V

    .line 85
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/score/MidiKey;->CreateSymbols()V

    .line 86
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(II)V
    .locals 1
    .param p1, "num_sharps"    # I
    .param p2, "num_flats"    # I

    .line 28
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 29
    if-lez p1, :cond_1

    if-gtz p2, :cond_0

    goto :goto_0

    .line 30
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v0

    .line 32
    :cond_1
    :goto_0
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    .line 33
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    .line 34
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/MidiKey;->CreateAccidentalMaps()V

    .line 35
    const/16 v0, 0xa0

    new-array v0, v0, [Lnet/duceng/xmidi/widgets/score/Accid;

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    .line 36
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/score/MidiKey;->ResetKeyMap()V

    .line 37
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/score/MidiKey;->CreateSymbols()V

    .line 38
    return-void
.end method

.method private static CreateAccidentalMaps()V
    .locals 26

    .line 89
    sget-object v0, Lnet/duceng/xmidi/widgets/score/MidiKey;->sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    if-nez v0, :cond_1

    .line 90
    const/16 v0, 0x8

    new-array v1, v0, [[Lnet/duceng/xmidi/widgets/score/Accid;

    sput-object v1, Lnet/duceng/xmidi/widgets/score/MidiKey;->sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    .line 91
    new-array v1, v0, [[Lnet/duceng/xmidi/widgets/score/Accid;

    sput-object v1, Lnet/duceng/xmidi/widgets/score/MidiKey;->flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    .line 92
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    if-ge v1, v0, :cond_0

    .line 93
    sget-object v2, Lnet/duceng/xmidi/widgets/score/MidiKey;->sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    const/16 v3, 0xc

    new-array v4, v3, [Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v4, v2, v1

    .line 94
    sget-object v2, Lnet/duceng/xmidi/widgets/score/MidiKey;->flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    new-array v3, v3, [Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v3, v2, v1

    .line 92
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 96
    .end local v1    # "i":I
    :cond_0
    sget-object v1, Lnet/duceng/xmidi/widgets/score/MidiKey;->sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v2, 0x0

    aget-object v1, v1, v2

    .line 97
    .local v1, "map":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v3, v1, v2

    .line 98
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v4, 0x1

    aput-object v3, v1, v4

    .line 99
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v5, 0x2

    aput-object v3, v1, v5

    .line 100
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v6, 0x3

    aput-object v3, v1, v6

    .line 101
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v7, 0x4

    aput-object v3, v1, v7

    .line 102
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v8, 0x5

    aput-object v3, v1, v8

    .line 103
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v9, 0x6

    aput-object v3, v1, v9

    .line 104
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    const/4 v10, 0x7

    aput-object v3, v1, v10

    .line 105
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v3, v1, v0

    .line 106
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    const/16 v11, 0x9

    aput-object v3, v1, v11

    .line 107
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    const/16 v12, 0xa

    aput-object v3, v1, v12

    .line 108
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    const/16 v13, 0xb

    aput-object v3, v1, v13

    .line 109
    sget-object v3, Lnet/duceng/xmidi/widgets/score/MidiKey;->sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v3, v3, v4

    .line 110
    .local v3, "map2":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v2

    .line 111
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v4

    .line 112
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v5

    .line 113
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v6

    .line 114
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v7

    .line 115
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v8

    .line 116
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v9

    .line 117
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v10

    .line 118
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v0

    .line 119
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v11

    .line 120
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v12

    .line 121
    sget-object v14, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v14, v3, v13

    .line 122
    sget-object v14, Lnet/duceng/xmidi/widgets/score/MidiKey;->sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v14, v14, v5

    .line 123
    .local v14, "map3":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v2

    .line 124
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v4

    .line 125
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v5

    .line 126
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v6

    .line 127
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v7

    .line 128
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v8

    .line 129
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v9

    .line 130
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v10

    .line 131
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v0

    .line 132
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v11

    .line 133
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v12

    .line 134
    sget-object v15, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v15, v14, v13

    .line 135
    sget-object v15, Lnet/duceng/xmidi/widgets/score/MidiKey;->sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v15, v15, v6

    .line 136
    .local v15, "map4":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v2

    .line 137
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v4

    .line 138
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v5

    .line 139
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v6

    .line 140
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v7

    .line 141
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v8

    .line 142
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v9

    .line 143
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v10

    .line 144
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v0

    .line 145
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v11

    .line 146
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v12

    .line 147
    sget-object v16, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v16, v15, v13

    .line 148
    sget-object v16, Lnet/duceng/xmidi/widgets/score/MidiKey;->sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v16, v16, v7

    .line 149
    .local v16, "map5":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v2

    .line 150
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v4

    .line 151
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v5

    .line 152
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v6

    .line 153
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v7

    .line 154
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v8

    .line 155
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v9

    .line 156
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v10

    .line 157
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v0

    .line 158
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v11

    .line 159
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v12

    .line 160
    sget-object v17, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v17, v16, v13

    .line 161
    sget-object v17, Lnet/duceng/xmidi/widgets/score/MidiKey;->sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v17, v17, v8

    .line 162
    .local v17, "map6":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v2

    .line 163
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v4

    .line 164
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v5

    .line 165
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v6

    .line 166
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v7

    .line 167
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v8

    .line 168
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v9

    .line 169
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v10

    .line 170
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v0

    .line 171
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v11

    .line 172
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v12

    .line 173
    sget-object v18, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v18, v17, v13

    .line 174
    sget-object v18, Lnet/duceng/xmidi/widgets/score/MidiKey;->flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v18, v18, v2

    .line 175
    .local v18, "map7":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v2

    .line 176
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v4

    .line 177
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v5

    .line 178
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v6

    .line 179
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v7

    .line 180
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v8

    .line 181
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v9

    .line 182
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v10

    .line 183
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v0

    .line 184
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v11

    .line 185
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v12

    .line 186
    sget-object v19, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v19, v18, v13

    .line 187
    sget-object v19, Lnet/duceng/xmidi/widgets/score/MidiKey;->flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v19, v19, v4

    .line 188
    .local v19, "map8":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v2

    .line 189
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v4

    .line 190
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v5

    .line 191
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v6

    .line 192
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v7

    .line 193
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v8

    .line 194
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v9

    .line 195
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v10

    .line 196
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v0

    .line 197
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v11

    .line 198
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v12

    .line 199
    sget-object v20, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v20, v19, v13

    .line 200
    sget-object v20, Lnet/duceng/xmidi/widgets/score/MidiKey;->flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v20, v20, v5

    .line 201
    .local v20, "map9":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v2

    .line 202
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v4

    .line 203
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v5

    .line 204
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v6

    .line 205
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v7

    .line 206
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v8

    .line 207
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v9

    .line 208
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v10

    .line 209
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v0

    .line 210
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v11

    .line 211
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v12

    .line 212
    sget-object v21, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v21, v20, v13

    .line 213
    sget-object v21, Lnet/duceng/xmidi/widgets/score/MidiKey;->flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v21, v21, v6

    .line 214
    .local v21, "map10":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v2

    .line 215
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v4

    .line 216
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v5

    .line 217
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v6

    .line 218
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v7

    .line 219
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v8

    .line 220
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v9

    .line 221
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v10

    .line 222
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v0

    .line 223
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v11

    .line 224
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v12

    .line 225
    sget-object v22, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v22, v21, v13

    .line 226
    sget-object v22, Lnet/duceng/xmidi/widgets/score/MidiKey;->flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v22, v22, v7

    .line 227
    .local v22, "map11":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v2

    .line 228
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v4

    .line 229
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v5

    .line 230
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v6

    .line 231
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v7

    .line 232
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v8

    .line 233
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v9

    .line 234
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v10

    .line 235
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v0

    .line 236
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v11

    .line 237
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v12

    .line 238
    sget-object v23, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v23, v22, v13

    .line 239
    sget-object v23, Lnet/duceng/xmidi/widgets/score/MidiKey;->flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v23, v23, v8

    .line 240
    .local v23, "map12":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v2

    .line 241
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v4

    .line 242
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v5

    .line 243
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v6

    .line 244
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v7

    .line 245
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v8

    .line 246
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v9

    .line 247
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v10

    .line 248
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v0

    .line 249
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v11

    .line 250
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v12

    .line 251
    sget-object v24, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v24, v23, v13

    .line 252
    sget-object v24, Lnet/duceng/xmidi/widgets/score/MidiKey;->flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v24, v24, v9

    .line 253
    .local v24, "map13":[Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v25, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v25, v24, v2

    .line 254
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v2, v24, v4

    .line 255
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v2, v24, v5

    .line 256
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v2, v24, v6

    .line 257
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v2, v24, v7

    .line 258
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v2, v24, v8

    .line 259
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v2, v24, v9

    .line 260
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v2, v24, v10

    .line 261
    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v2, v24, v0

    .line 262
    sget-object v0, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v0, v24, v11

    .line 263
    sget-object v0, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v0, v24, v12

    .line 264
    sget-object v0, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v0, v24, v13

    .line 266
    .end local v1    # "map":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v3    # "map2":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v14    # "map3":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v15    # "map4":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v16    # "map5":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v17    # "map6":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v18    # "map7":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v19    # "map8":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v20    # "map9":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v21    # "map10":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v22    # "map11":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v23    # "map12":[Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v24    # "map13":[Lnet/duceng/xmidi/widgets/score/Accid;
    :cond_1
    return-void
.end method

.method private CreateSymbols()V
    .locals 12

    .line 282
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 283
    .local v0, "count":I
    new-array v1, v0, [Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->treble:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    .line 284
    new-array v1, v0, [Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    iput-object v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->bass:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    .line 285
    if-eqz v0, :cond_3

    .line 286
    const/4 v1, 0x0

    .line 287
    .local v1, "treblenotes":[Lnet/duceng/xmidi/widgets/score/WhiteNote;
    const/4 v2, 0x0

    .line 288
    .local v2, "bassnotes":[Lnet/duceng/xmidi/widgets/score/WhiteNote;
    iget v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-lez v3, :cond_0

    .line 289
    new-array v3, v7, [Lnet/duceng/xmidi/widgets/score/WhiteNote;

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v9, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v5

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v6, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v4

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v7, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v6

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v10, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v10

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v5, v7}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v8

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v8, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v9

    move-object v1, v3

    .line 290
    new-array v3, v7, [Lnet/duceng/xmidi/widgets/score/WhiteNote;

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v9, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v5

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v6, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v4

    new-instance v4, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v4, v7, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v4, v3, v6

    new-instance v4, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v4, v10, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v4, v3, v10

    new-instance v4, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v4, v5, v8}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v4, v3, v8

    new-instance v4, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v4, v8, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v4, v3, v9

    move-object v2, v3

    goto :goto_0

    .line 291
    :cond_0
    iget v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    if-lez v3, :cond_1

    .line 292
    new-array v3, v7, [Lnet/duceng/xmidi/widgets/score/WhiteNote;

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v4, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v5

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v8, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v4

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v5, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v6

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v10, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v10

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v7, v8}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v8

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v6, v9}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v9

    move-object v1, v3

    .line 293
    new-array v3, v7, [Lnet/duceng/xmidi/widgets/score/WhiteNote;

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v4, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v5

    new-instance v11, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v11, v8, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v11, v3, v4

    new-instance v4, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v4, v5, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v4, v3, v6

    new-instance v4, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v4, v10, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v4, v3, v10

    new-instance v4, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v4, v7, v6}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v4, v3, v8

    new-instance v4, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v4, v6, v10}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    aput-object v4, v3, v9

    move-object v2, v3

    .line 295
    :cond_1
    :goto_0
    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    .line 296
    .local v3, "accid":Lnet/duceng/xmidi/widgets/score/Accid;
    iget v4, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    if-lez v4, :cond_2

    .line 297
    sget-object v4, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    .local v4, "a":Lnet/duceng/xmidi/widgets/score/Accid;
    goto :goto_1

    .line 299
    .end local v4    # "a":Lnet/duceng/xmidi/widgets/score/Accid;
    :cond_2
    sget-object v4, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    .line 301
    .restart local v4    # "a":Lnet/duceng/xmidi/widgets/score/Accid;
    :goto_1
    const/4 v5, 0x0

    .local v5, "i":I
    :goto_2
    if-ge v5, v0, :cond_3

    .line 302
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->treble:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    new-instance v7, Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    aget-object v8, v1, v5

    sget-object v9, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-direct {v7, v4, v8, v9}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;-><init>(Lnet/duceng/xmidi/widgets/score/Accid;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/Clef;)V

    aput-object v7, v6, v5

    .line 303
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->bass:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    new-instance v7, Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    aget-object v8, v2, v5

    sget-object v9, Lnet/duceng/xmidi/widgets/score/Clef;->Bass:Lnet/duceng/xmidi/widgets/score/Clef;

    invoke-direct {v7, v4, v8, v9}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;-><init>(Lnet/duceng/xmidi/widgets/score/Accid;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/Clef;)V

    aput-object v7, v6, v5

    .line 301
    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    .line 306
    .end local v1    # "treblenotes":[Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .end local v2    # "bassnotes":[Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .end local v3    # "accid":Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v4    # "a":Lnet/duceng/xmidi/widgets/score/Accid;
    .end local v5    # "i":I
    :cond_3
    return-void
.end method

.method public static KeyToString(I)Ljava/lang/String;
    .locals 1
    .param p0, "notescale"    # I

    .line 447
    packed-switch p0, :pswitch_data_0

    .line 473
    const-string v0, ""

    return-object v0

    .line 471
    :pswitch_0
    const-string v0, "A-flat major"

    return-object v0

    .line 469
    :pswitch_1
    const-string v0, "G major"

    return-object v0

    .line 467
    :pswitch_2
    const-string v0, "G-flat major"

    return-object v0

    .line 465
    :pswitch_3
    const-string v0, "F major"

    return-object v0

    .line 463
    :pswitch_4
    const-string v0, "E major"

    return-object v0

    .line 461
    :pswitch_5
    const-string v0, "E-flat major"

    return-object v0

    .line 459
    :pswitch_6
    const-string v0, "D major"

    return-object v0

    .line 457
    :pswitch_7
    const-string v0, "D-flat major"

    return-object v0

    .line 455
    :pswitch_8
    const-string v0, "C major"

    return-object v0

    .line 453
    :pswitch_9
    const-string v0, "B major"

    return-object v0

    .line 451
    :pswitch_a
    const-string v0, "B-flat major"

    return-object v0

    .line 449
    :pswitch_b
    const-string v0, "A major"

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private ResetKeyMap()V
    .locals 4

    .line 270
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    if-lez v0, :cond_0

    .line 271
    sget-object v0, Lnet/duceng/xmidi/widgets/score/MidiKey;->flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    aget-object v0, v0, v1

    .local v0, "key":[Lnet/duceng/xmidi/widgets/score/Accid;
    goto :goto_0

    .line 273
    .end local v0    # "key":[Lnet/duceng/xmidi/widgets/score/Accid;
    :cond_0
    sget-object v0, Lnet/duceng/xmidi/widgets/score/MidiKey;->sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    aget-object v0, v0, v1

    .line 275
    .restart local v0    # "key":[Lnet/duceng/xmidi/widgets/score/Accid;
    :goto_0
    const/4 v1, 0x0

    .local v1, "notenumber":I
    :goto_1
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    array-length v2, v2

    if-ge v1, v2, :cond_1

    .line 276
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    invoke-static {v1}, Lnet/duceng/xmidi/widgets/score/NoteScale;->FromNumber(I)I

    move-result v3

    aget-object v3, v0, v3

    aput-object v3, v2, v1

    .line 275
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 278
    .end local v1    # "notenumber":I
    :cond_1
    return-void
.end method

.method public static guess(Ljava/util/ArrayList;)Lnet/duceng/xmidi/widgets/score/MidiKey;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/Note;",
            ">;>;)",
            "Lnet/duceng/xmidi/widgets/score/MidiKey;"
        }
    .end annotation

    .line 392
    .local p0, "tracks":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;>;"
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/MidiKey;->CreateAccidentalMaps()V

    .line 393
    const/16 v0, 0xc

    new-array v1, v0, [I

    .line 394
    .local v1, "notecount":[I
    const/4 v2, 0x0

    .line 395
    .local v2, "smallest_accid_count":I
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/ArrayList;

    .line 396
    .local v4, "t":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;"
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/Note;

    .line 397
    .local v6, "n":Lnet/duceng/xmidi/widgets/score/Note;
    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v7

    add-int/lit8 v7, v7, 0x3

    rem-int/2addr v7, v0

    .line 398
    .local v7, "notescale":I
    aget v8, v1, v7

    add-int/lit8 v8, v8, 0x1

    aput v8, v1, v7

    .line 399
    nop

    .end local v6    # "n":Lnet/duceng/xmidi/widgets/score/Note;
    .end local v7    # "notescale":I
    add-int/lit8 v2, v2, 0x1

    .line 400
    goto :goto_1

    .line 401
    .end local v4    # "t":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/Note;>;"
    :cond_0
    goto :goto_0

    .line 402
    :cond_1
    const/4 v3, 0x0

    .line 403
    .local v3, "bestkey":I
    const/4 v4, 0x1

    .line 404
    .local v4, "is_best_sharp":Z
    const/4 v5, 0x0

    .local v5, "key":I
    :goto_2
    const/4 v6, 0x6

    if-ge v5, v6, :cond_5

    .line 405
    const/4 v6, 0x0

    .line 406
    .local v6, "accid_count":I
    const/4 v7, 0x0

    .local v7, "n2":I
    :goto_3
    if-ge v7, v0, :cond_3

    .line 407
    sget-object v8, Lnet/duceng/xmidi/widgets/score/MidiKey;->sharpkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v8, v8, v5

    aget-object v8, v8, v7

    sget-object v9, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    if-eq v8, v9, :cond_2

    .line 408
    aget v8, v1, v7

    add-int/2addr v6, v8

    .line 406
    :cond_2
    add-int/lit8 v7, v7, 0x1

    goto :goto_3

    .line 411
    .end local v7    # "n2":I
    :cond_3
    if-ge v6, v2, :cond_4

    .line 412
    move v2, v6

    .line 413
    move v3, v5

    .line 414
    const/4 v4, 0x1

    .line 404
    .end local v6    # "accid_count":I
    :cond_4
    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    .line 417
    .end local v5    # "key":I
    :cond_5
    const/4 v5, 0x0

    .local v5, "key2":I
    :goto_4
    const/4 v6, 0x7

    if-ge v5, v6, :cond_9

    .line 418
    const/4 v6, 0x0

    .line 419
    .local v6, "accid_count2":I
    const/4 v7, 0x0

    .local v7, "n3":I
    :goto_5
    if-ge v7, v0, :cond_7

    .line 420
    sget-object v8, Lnet/duceng/xmidi/widgets/score/MidiKey;->flatkeys:[[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v8, v8, v5

    aget-object v8, v8, v7

    sget-object v9, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    if-eq v8, v9, :cond_6

    .line 421
    aget v8, v1, v7

    add-int/2addr v6, v8

    .line 419
    :cond_6
    add-int/lit8 v7, v7, 0x1

    goto :goto_5

    .line 424
    .end local v7    # "n3":I
    :cond_7
    if-ge v6, v2, :cond_8

    .line 425
    move v2, v6

    .line 426
    move v3, v5

    .line 427
    const/4 v4, 0x0

    .line 417
    .end local v6    # "accid_count2":I
    :cond_8
    add-int/lit8 v5, v5, 0x1

    goto :goto_4

    .line 430
    .end local v5    # "key2":I
    :cond_9
    const/4 v0, 0x0

    if-eqz v4, :cond_a

    .line 431
    new-instance v5, Lnet/duceng/xmidi/widgets/score/MidiKey;

    invoke-direct {v5, v3, v0}, Lnet/duceng/xmidi/widgets/score/MidiKey;-><init>(II)V

    return-object v5

    .line 433
    :cond_a
    new-instance v5, Lnet/duceng/xmidi/widgets/score/MidiKey;

    invoke-direct {v5, v0, v3}, Lnet/duceng/xmidi/widgets/score/MidiKey;-><init>(II)V

    return-object v5
.end method


# virtual methods
.method public GetAccidental(II)Lnet/duceng/xmidi/widgets/score/Accid;
    .locals 6
    .param p1, "notenumber"    # I
    .param p2, "measure"    # I

    .line 313
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->prevmeasure:I

    if-eq p2, v0, :cond_0

    .line 314
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/score/MidiKey;->ResetKeyMap()V

    .line 315
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->prevmeasure:I

    .line 317
    :cond_0
    const/4 v0, 0x1

    if-le p1, v0, :cond_9

    const/16 v0, 0x7f

    if-lt p1, v0, :cond_1

    goto/16 :goto_0

    .line 320
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v0, v0, p1

    .line 321
    .local v0, "result":Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v1, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v0, v1, :cond_2

    .line 322
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v2, v1, p1

    .line 323
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v2, p1, -0x1

    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v3, v1, v2

    .line 324
    return-object v0

    .line 326
    :cond_2
    sget-object v1, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v0, v1, :cond_3

    .line 327
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v2, v1, p1

    .line 328
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v2, p1, 0x1

    sget-object v3, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v3, v1, v2

    .line 329
    return-object v0

    .line 331
    :cond_3
    sget-object v1, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v0, v1, :cond_8

    .line 332
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v2, v1, p1

    .line 333
    add-int/lit8 v1, p1, 0x1

    invoke-static {v1}, Lnet/duceng/xmidi/widgets/score/NoteScale;->FromNumber(I)I

    move-result v1

    .line 334
    .local v1, "nextkey":I
    add-int/lit8 v2, p1, -0x1

    invoke-static {v2}, Lnet/duceng/xmidi/widgets/score/NoteScale;->FromNumber(I)I

    move-result v2

    .line 335
    .local v2, "prevkey":I
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v4, p1, -0x1

    aget-object v3, v3, v4

    sget-object v4, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v3, v4, :cond_5

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v4, p1, 0x1

    aget-object v3, v3, v4

    sget-object v4, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v3, v4, :cond_5

    invoke-static {v1}, Lnet/duceng/xmidi/widgets/score/NoteScale;->IsBlackKey(I)Z

    move-result v3

    if-eqz v3, :cond_5

    invoke-static {v2}, Lnet/duceng/xmidi/widgets/score/NoteScale;->IsBlackKey(I)Z

    move-result v3

    if-eqz v3, :cond_5

    .line 336
    iget v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    if-nez v3, :cond_4

    .line 337
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v4, p1, 0x1

    sget-object v5, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v5, v3, v4

    .line 338
    return-object v0

    .line 340
    :cond_4
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v4, p1, -0x1

    sget-object v5, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v5, v3, v4

    .line 341
    return-object v0

    .line 343
    :cond_5
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v4, p1, -0x1

    aget-object v3, v3, v4

    sget-object v4, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v3, v4, :cond_6

    invoke-static {v2}, Lnet/duceng/xmidi/widgets/score/NoteScale;->IsBlackKey(I)Z

    move-result v3

    if-eqz v3, :cond_6

    .line 344
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v4, p1, -0x1

    sget-object v5, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v5, v3, v4

    .line 345
    return-object v0

    .line 347
    :cond_6
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v4, p1, 0x1

    aget-object v3, v3, v4

    sget-object v4, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v3, v4, :cond_7

    invoke-static {v1}, Lnet/duceng/xmidi/widgets/score/NoteScale;->IsBlackKey(I)Z

    move-result v3

    if-eqz v3, :cond_7

    .line 348
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v4, p1, 0x1

    sget-object v5, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    aput-object v5, v3, v4

    .line 349
    return-object v0

    .line 351
    :cond_7
    return-object v0

    .line 353
    .end local v1    # "nextkey":I
    .end local v2    # "prevkey":I
    :cond_8
    return-object v0

    .line 318
    .end local v0    # "result":Lnet/duceng/xmidi/widgets/score/Accid;
    :cond_9
    :goto_0
    sget-object v0, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    return-object v0
.end method

.method public GetSymbols(Lnet/duceng/xmidi/widgets/score/Clef;)[Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    .locals 1
    .param p1, "clef"    # Lnet/duceng/xmidi/widgets/score/Clef;

    .line 309
    sget-object v0, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    if-ne p1, v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->treble:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->bass:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    :goto_0
    return-object v0
.end method

.method public GetWhiteNote(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .locals 9
    .param p1, "notenumber"    # I

    .line 357
    invoke-static {p1}, Lnet/duceng/xmidi/widgets/score/NoteScale;->FromNumber(I)I

    move-result v0

    .line 358
    .local v0, "notescale":I
    add-int/lit8 v1, p1, 0x3

    const/16 v2, 0xc

    div-int/2addr v1, v2

    const/4 v3, 0x1

    sub-int/2addr v1, v3

    .line 359
    .local v1, "octave":I
    const/4 v4, 0x0

    .line 360
    .local v4, "letter":I
    new-array v5, v2, [I

    fill-array-data v5, :array_0

    .line 361
    .local v5, "whole_sharps":[I
    new-array v2, v2, [I

    fill-array-data v2, :array_1

    .line 362
    .local v2, "whole_flats":[I
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    aget-object v6, v6, p1

    .line 363
    .local v6, "accid":Lnet/duceng/xmidi/widgets/score/Accid;
    sget-object v7, Lnet/duceng/xmidi/widgets/score/Accid;->Flat:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v6, v7, :cond_0

    .line 364
    aget v4, v2, v0

    goto :goto_2

    .line 365
    :cond_0
    sget-object v7, Lnet/duceng/xmidi/widgets/score/Accid;->Sharp:Lnet/duceng/xmidi/widgets/score/Accid;

    if-eq v6, v7, :cond_5

    sget-object v7, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v6, v7, :cond_1

    goto :goto_1

    .line 367
    :cond_1
    sget-object v7, Lnet/duceng/xmidi/widgets/score/Accid;->None:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v6, v7, :cond_6

    .line 368
    aget v4, v5, v0

    .line 369
    invoke-static {v0}, Lnet/duceng/xmidi/widgets/score/NoteScale;->IsBlackKey(I)Z

    move-result v7

    if-eqz v7, :cond_6

    .line 370
    iget-object v7, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v8, p1, -0x1

    aget-object v7, v7, v8

    sget-object v8, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v7, v8, :cond_3

    iget-object v7, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v8, p1, 0x1

    aget-object v7, v7, v8

    sget-object v8, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v7, v8, :cond_3

    .line 371
    iget v7, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    if-lez v7, :cond_2

    aget v7, v2, v0

    goto :goto_0

    :cond_2
    aget v7, v5, v0

    :goto_0
    move v4, v7

    goto :goto_2

    .line 372
    :cond_3
    iget-object v7, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v8, p1, -0x1

    aget-object v7, v7, v8

    sget-object v8, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v7, v8, :cond_4

    .line 373
    aget v4, v5, v0

    goto :goto_2

    .line 374
    :cond_4
    iget-object v7, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->keymap:[Lnet/duceng/xmidi/widgets/score/Accid;

    add-int/lit8 v8, p1, 0x1

    aget-object v7, v7, v8

    sget-object v8, Lnet/duceng/xmidi/widgets/score/Accid;->Natural:Lnet/duceng/xmidi/widgets/score/Accid;

    if-ne v7, v8, :cond_6

    .line 375
    aget v4, v2, v0

    goto :goto_2

    .line 366
    :cond_5
    :goto_1
    aget v4, v5, v0

    .line 379
    :cond_6
    :goto_2
    iget v7, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    const/4 v8, 0x6

    if-ne v7, v8, :cond_7

    const/4 v7, 0x2

    if-ne v0, v7, :cond_7

    .line 380
    const/4 v4, 0x2

    .line 382
    :cond_7
    iget v7, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    if-ne v7, v8, :cond_8

    if-ne v0, v3, :cond_8

    .line 383
    const/4 v4, 0x1

    .line 385
    :cond_8
    iget v3, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    if-lez v3, :cond_9

    const/16 v3, 0xb

    if-ne v0, v3, :cond_9

    .line 386
    add-int/lit8 v1, v1, 0x1

    .line 388
    :cond_9
    new-instance v3, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v3, v4, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    return-object v3

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x1
        0x2
        0x2
        0x3
        0x3
        0x4
        0x5
        0x5
        0x6
        0x6
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x1
        0x1
        0x2
        0x3
        0x3
        0x4
        0x4
        0x5
        0x6
        0x6
        0x0
    .end array-data
.end method

.method public Notescale()I
    .locals 3

    .line 441
    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    .line 442
    .local v0, "flatmajor":[I
    const/16 v1, 0xa

    new-array v1, v1, [I

    fill-array-data v1, :array_1

    .line 443
    .local v1, "sharpmajor":[I
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    if-lez v2, :cond_0

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    aget v2, v0, v2

    goto :goto_0

    :cond_0
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    aget v2, v1, v2

    :goto_0
    return v2

    :array_0
    .array-data 4
        0x3
        0x8
        0x1
        0x6
        0xb
        0x4
        0x9
        0x2
    .end array-data

    :array_1
    .array-data 4
        0x3
        0xa
        0x5
        0x0
        0x7
        0x2
        0x9
        0x4
        0xb
        0x6
    .end array-data
.end method

.method public equals(Lnet/duceng/xmidi/widgets/score/MidiKey;)Z
    .locals 2
    .param p1, "k"    # Lnet/duceng/xmidi/widgets/score/MidiKey;

    .line 437
    iget v0, p1, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_sharps:I

    if-ne v0, v1, :cond_0

    iget v0, p1, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/MidiKey;->num_flats:I

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 1

    .line 478
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/MidiKey;->Notescale()I

    move-result v0

    invoke-static {v0}, Lnet/duceng/xmidi/widgets/score/MidiKey;->KeyToString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
