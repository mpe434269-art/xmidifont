.class public Lnet/duceng/xmidi/widgets/score/MidiTime;
.super Ljava/lang/Object;
.source "MidiTime.java"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration:[I


# instance fields
.field private denominator:I

.field private measure:I

.field private mpqn:I

.field private numerator:I

.field private resolution:I


# direct methods
.method static $SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration()[I
    .locals 3

    .line 15
    sget-object v0, Lnet/duceng/xmidi/widgets/score/MidiTime;->$SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration:[I

    .line 16
    .local v0, "iArr":[I
    if-nez v0, :cond_0

    .line 17
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->valuesCustom()[Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v1

    array-length v1, v1

    new-array v0, v1, [I

    .line 19
    :try_start_0
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x5

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    .line 21
    goto :goto_0

    .line 20
    :catch_0
    move-exception v1

    .line 23
    :goto_0
    :try_start_1
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/16 v2, 0x9

    aput v2, v0, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    .line 25
    goto :goto_1

    .line 24
    :catch_1
    move-exception v1

    .line 27
    :goto_1
    :try_start_2
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedQuarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x7

    aput v2, v0, v1
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    .line 29
    goto :goto_2

    .line 28
    :catch_2
    move-exception v1

    .line 31
    :goto_2
    :try_start_3
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    .line 33
    goto :goto_3

    .line 32
    :catch_3
    move-exception v1

    .line 35
    :goto_3
    :try_start_4
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/16 v2, 0x8

    aput v2, v0, v1
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    .line 37
    goto :goto_4

    .line 36
    :catch_4
    move-exception v1

    .line 39
    :goto_4
    :try_start_5
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x6

    aput v2, v0, v1
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    .line 41
    goto :goto_5

    .line 40
    :catch_5
    move-exception v1

    .line 43
    :goto_5
    :try_start_6
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    .line 45
    goto :goto_6

    .line 44
    :catch_6
    move-exception v1

    .line 47
    :goto_6
    :try_start_7
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_7} :catch_7

    .line 49
    goto :goto_7

    .line 48
    :catch_7
    move-exception v1

    .line 51
    :goto_7
    :try_start_8
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Triplet:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_8
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_8} :catch_8

    .line 53
    goto :goto_8

    .line 52
    :catch_8
    move-exception v1

    .line 55
    :goto_8
    :try_start_9
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v1

    const/16 v2, 0xa

    aput v2, v0, v1
    :try_end_9
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_9} :catch_9

    .line 57
    goto :goto_9

    .line 56
    :catch_9
    move-exception v1

    .line 58
    :goto_9
    sput-object v0, Lnet/duceng/xmidi/widgets/score/MidiTime;->$SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration:[I

    .line 60
    :cond_0
    return-object v0
.end method

.method public constructor <init>(IIII)V
    .locals 2
    .param p1, "numerator"    # I
    .param p2, "denominator"    # I
    .param p3, "resolution"    # I
    .param p4, "mpqn"    # I

    .line 83
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 85
    if-lez p1, :cond_2

    if-lez p2, :cond_2

    if-lez p3, :cond_2

    .line 88
    const/4 v0, 0x5

    const/4 v1, 0x4

    if-ne p1, v0, :cond_0

    const/4 v0, 0x4

    goto :goto_0

    :cond_0
    move v0, p1

    :goto_0
    move p1, v0

    .line 89
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->numerator:I

    .line 90
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->denominator:I

    .line 91
    iput p3, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->resolution:I

    .line 92
    iput p4, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->mpqn:I

    .line 93
    if-ge p2, v1, :cond_1

    .line 94
    mul-int/lit8 v0, p3, 0x2

    .local v0, "beat":I
    goto :goto_1

    .line 96
    .end local v0    # "beat":I
    :cond_1
    div-int/lit8 v0, p2, 0x4

    div-int v0, p3, v0

    .line 98
    .restart local v0    # "beat":I
    :goto_1
    mul-int v1, p1, v0

    iput v1, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->measure:I

    .line 99
    return-void

    .line 86
    .end local v0    # "beat":I
    :cond_2
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Invalid time signature"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static GetStemDuration(Lnet/duceng/xmidi/widgets/score/NoteDuration;)Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .locals 1
    .param p0, "dur"    # Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 138
    sget-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne p0, v0, :cond_0

    .line 139
    sget-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v0

    .line 141
    :cond_0
    sget-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedQuarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne p0, v0, :cond_1

    .line 142
    sget-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v0

    .line 144
    :cond_1
    sget-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne p0, v0, :cond_2

    .line 145
    sget-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v0

    .line 147
    :cond_2
    return-object p0
.end method


# virtual methods
.method public DurationToTime(Lnet/duceng/xmidi/widgets/score/NoteDuration;)I
    .locals 4
    .param p1, "dur"    # Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 151
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->resolution:I

    div-int/lit8 v0, v0, 0x2

    .line 152
    .local v0, "eighth":I
    div-int/lit8 v1, v0, 0x2

    .line 153
    .local v1, "sixteenth":I
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/MidiTime;->$SWITCH_TABLE$net$duceng$xmidi$widgets$score$NoteDuration()[I

    move-result-object v2

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ordinal()I

    move-result v3

    aget v2, v2, v3

    packed-switch v2, :pswitch_data_0

    .line 175
    const/4 v2, 0x0

    return v2

    .line 173
    :pswitch_0
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->resolution:I

    mul-int/lit8 v2, v2, 0x4

    return v2

    .line 171
    :pswitch_1
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->resolution:I

    mul-int/lit8 v2, v2, 0x3

    return v2

    .line 169
    :pswitch_2
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->resolution:I

    mul-int/lit8 v2, v2, 0x2

    return v2

    .line 167
    :pswitch_3
    mul-int/lit8 v2, v0, 0x3

    return v2

    .line 165
    :pswitch_4
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->resolution:I

    return v2

    .line 163
    :pswitch_5
    mul-int/lit8 v2, v1, 0x3

    return v2

    .line 161
    :pswitch_6
    return v0

    .line 159
    :pswitch_7
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->resolution:I

    div-int/lit8 v2, v2, 0x3

    return v2

    .line 157
    :pswitch_8
    return v1

    .line 155
    :pswitch_9
    div-int/lit8 v2, v1, 0x2

    return v2

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public GetMeasure(I)I
    .locals 1
    .param p1, "time"    # I

    .line 102
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->measure:I

    div-int v0, p1, v0

    return v0
.end method

.method public GetNoteDuration(I)Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .locals 2
    .param p1, "duration"    # I

    .line 106
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->resolution:I

    mul-int/lit8 v0, v0, 0x4

    .line 107
    .local v0, "whole":I
    mul-int/lit8 v1, v0, 0x1c

    div-int/lit8 v1, v1, 0x20

    if-lt p1, v1, :cond_0

    .line 108
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v1

    .line 110
    :cond_0
    mul-int/lit8 v1, v0, 0x14

    div-int/lit8 v1, v1, 0x20

    if-lt p1, v1, :cond_1

    .line 111
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v1

    .line 113
    :cond_1
    mul-int/lit8 v1, v0, 0xe

    div-int/lit8 v1, v1, 0x20

    if-lt p1, v1, :cond_2

    .line 114
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v1

    .line 116
    :cond_2
    mul-int/lit8 v1, v0, 0xa

    div-int/lit8 v1, v1, 0x20

    if-lt p1, v1, :cond_3

    .line 117
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedQuarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v1

    .line 119
    :cond_3
    mul-int/lit8 v1, v0, 0x7

    div-int/lit8 v1, v1, 0x20

    if-lt p1, v1, :cond_4

    .line 120
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v1

    .line 122
    :cond_4
    mul-int/lit8 v1, v0, 0x5

    div-int/lit8 v1, v1, 0x20

    if-lt p1, v1, :cond_5

    .line 123
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v1

    .line 125
    :cond_5
    mul-int/lit8 v1, v0, 0x6

    div-int/lit8 v1, v1, 0x40

    if-lt p1, v1, :cond_6

    .line 126
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v1

    .line 128
    :cond_6
    mul-int/lit8 v1, v0, 0x5

    div-int/lit8 v1, v1, 0x40

    if-lt p1, v1, :cond_7

    .line 129
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Triplet:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v1

    .line 131
    :cond_7
    mul-int/lit8 v1, v0, 0x3

    div-int/lit8 v1, v1, 0x40

    if-lt p1, v1, :cond_8

    .line 132
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v1

    .line 134
    :cond_8
    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v1
.end method

.method public getDenominator()I
    .locals 1

    .line 68
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->denominator:I

    return v0
.end method

.method public getMeasure()I
    .locals 1

    .line 80
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->measure:I

    return v0
.end method

.method public getMpqn()I
    .locals 1

    .line 76
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->mpqn:I

    return v0
.end method

.method public getNumerator()I
    .locals 1

    .line 64
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->numerator:I

    return v0
.end method

.method public getResolution()I
    .locals 1

    .line 72
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->resolution:I

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 6

    .line 180
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->numerator:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->denominator:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->resolution:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget v3, p0, Lnet/duceng/xmidi/widgets/score/MidiTime;->mpqn:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x4

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v5, 0x0

    aput-object v0, v4, v5

    const/4 v0, 0x1

    aput-object v1, v4, v0

    const/4 v0, 0x2

    aput-object v2, v4, v0

    const/4 v0, 0x3

    aput-object v3, v4, v0

    const-string v0, "TimeSignature=%1$s/%2$s quarter=%3$s tempo=%4$s"

    invoke-static {v0, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
