.class public interface abstract Lnet/duceng/xmidi/widgets/score/MusicSymbol;
.super Ljava/lang/Object;
.source "MusicSymbol.java"


# virtual methods
.method public abstract draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
.end method

.method public abstract getAboveStaff()I
.end method

.method public abstract getBelowStaff()I
.end method

.method public abstract getMinWidth()I
.end method

.method public abstract getStartTime()I
.end method

.method public abstract getWidth()I
.end method

.method public abstract setWidth(I)V
.end method
