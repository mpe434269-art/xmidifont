.class public Lnet/duceng/xmidi/widgets/score/Note;
.super Ljava/lang/Object;
.source "Note.java"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lnet/duceng/xmidi/widgets/score/Note;",
        ">;"
    }
.end annotation


# instance fields
.field private channel:B

.field private duration:I

.field private key:B

.field private tick:I


# direct methods
.method public constructor <init>(IIBB)V
    .locals 0
    .param p1, "t"    # I
    .param p2, "d"    # I
    .param p3, "c"    # B
    .param p4, "k"    # B

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/Note;->tick:I

    .line 12
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/Note;->duration:I

    .line 13
    iput-byte p3, p0, Lnet/duceng/xmidi/widgets/score/Note;->channel:B

    .line 14
    iput-byte p4, p0, Lnet/duceng/xmidi/widgets/score/Note;->key:B

    .line 15
    return-void
.end method


# virtual methods
.method public Clone()Lnet/duceng/xmidi/widgets/score/Note;
    .locals 5

    .line 71
    new-instance v0, Lnet/duceng/xmidi/widgets/score/Note;

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/Note;->tick:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/Note;->duration:I

    iget-byte v3, p0, Lnet/duceng/xmidi/widgets/score/Note;->channel:B

    iget-byte v4, p0, Lnet/duceng/xmidi/widgets/score/Note;->key:B

    invoke-direct {v0, v1, v2, v3, v4}, Lnet/duceng/xmidi/widgets/score/Note;-><init>(IIBB)V

    return-object v0
.end method

.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .locals 0

    .line 4
    check-cast p1, Lnet/duceng/xmidi/widgets/score/Note;

    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/widgets/score/Note;->compareTo(Lnet/duceng/xmidi/widgets/score/Note;)I

    move-result p1

    return p1
.end method

.method public compareTo(Lnet/duceng/xmidi/widgets/score/Note;)I
    .locals 4
    .param p1, "other"    # Lnet/duceng/xmidi/widgets/score/Note;

    .line 55
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->tick:I

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/Note;->getStartTick()I

    move-result v1

    const/4 v2, -0x1

    const/4 v3, 0x1

    if-eq v0, v1, :cond_1

    .line 56
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->tick:I

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/Note;->getStartTick()I

    move-result v1

    if-ge v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    :goto_0
    return v2

    .line 58
    :cond_1
    iget-byte v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->key:B

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v1

    if-eq v0, v1, :cond_3

    .line 59
    iget-byte v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->key:B

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/Note;->getKey()B

    move-result v1

    if-lt v0, v1, :cond_2

    const/4 v2, 0x1

    :cond_2
    return v2

    .line 61
    :cond_3
    iget-byte v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->channel:B

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/Note;->getChannel()B

    move-result v1

    if-eq v0, v1, :cond_5

    .line 62
    iget-byte v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->channel:B

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/Note;->getChannel()B

    move-result v1

    if-lt v0, v1, :cond_4

    const/4 v2, 0x1

    :cond_4
    return v2

    .line 64
    :cond_5
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->duration:I

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/Note;->getDuration()I

    move-result v1

    if-eq v0, v1, :cond_7

    .line 65
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->duration:I

    invoke-virtual {p1}, Lnet/duceng/xmidi/widgets/score/Note;->getDuration()I

    move-result v1

    if-lt v0, v1, :cond_6

    const/4 v2, 0x1

    :cond_6
    return v2

    .line 67
    :cond_7
    const/4 v0, 0x0

    return v0
.end method

.method public getChannel()B
    .locals 1

    .line 38
    iget-byte v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->channel:B

    return v0
.end method

.method public getDuration()I
    .locals 1

    .line 26
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->duration:I

    return v0
.end method

.method public getEndTick()I
    .locals 2

    .line 34
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->tick:I

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/Note;->duration:I

    add-int/2addr v0, v1

    return v0
.end method

.method public getKey()B
    .locals 1

    .line 46
    iget-byte v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->key:B

    return v0
.end method

.method public getStartTick()I
    .locals 1

    .line 18
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Note;->tick:I

    return v0
.end method

.method public setChannel(B)V
    .locals 0
    .param p1, "value"    # B

    .line 42
    iput-byte p1, p0, Lnet/duceng/xmidi/widgets/score/Note;->channel:B

    .line 43
    return-void
.end method

.method public setDuration(I)V
    .locals 0
    .param p1, "value"    # I

    .line 30
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/Note;->duration:I

    .line 31
    return-void
.end method

.method public setKey(B)V
    .locals 0
    .param p1, "value"    # B

    .line 50
    iput-byte p1, p0, Lnet/duceng/xmidi/widgets/score/Note;->key:B

    .line 51
    return-void
.end method

.method public setStartTick(I)V
    .locals 0
    .param p1, "value"    # I

    .line 22
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/Note;->tick:I

    .line 23
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 12

    .line 75
    const-string v10, "G"

    const-string v11, "G#"

    const-string v0, "A"

    const-string v1, "A#"

    const-string v2, "B"

    const-string v3, "C"

    const-string v4, "C#"

    const-string v5, "D"

    const-string v6, "D#"

    const-string v7, "E"

    const-string v8, "F"

    const-string v9, "F#"

    filled-new-array/range {v0 .. v11}, [Ljava/lang/String;

    move-result-object v0

    .line 76
    .local v0, "scale":[Ljava/lang/String;
    iget-byte v1, p0, Lnet/duceng/xmidi/widgets/score/Note;->channel:B

    invoke-static {v1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v1

    iget-byte v2, p0, Lnet/duceng/xmidi/widgets/score/Note;->key:B

    invoke-static {v2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v2

    iget-byte v3, p0, Lnet/duceng/xmidi/widgets/score/Note;->key:B

    const/4 v4, 0x3

    add-int/2addr v3, v4

    rem-int/lit8 v3, v3, 0xc

    aget-object v3, v0, v3

    iget v5, p0, Lnet/duceng/xmidi/widgets/score/Note;->tick:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iget v6, p0, Lnet/duceng/xmidi/widgets/score/Note;->duration:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v7, 0x5

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v8, 0x0

    aput-object v1, v7, v8

    const/4 v1, 0x1

    aput-object v2, v7, v1

    const/4 v1, 0x2

    aput-object v3, v7, v1

    aput-object v5, v7, v4

    const/4 v1, 0x4

    aput-object v6, v7, v1

    const-string v1, "MidiNote channel=%1$s number=%2$s %3$s start=%4$s duration=%5$s"

    invoke-static {v1, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method
