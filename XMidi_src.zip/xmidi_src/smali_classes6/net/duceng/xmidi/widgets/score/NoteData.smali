.class public Lnet/duceng/xmidi/widgets/score/NoteData;
.super Ljava/lang/Object;
.source "NoteData.java"


# instance fields
.field public accid:Lnet/duceng/xmidi/widgets/score/Accid;

.field public duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field public leftside:Z

.field public number:I

.field public whitenote:Lnet/duceng/xmidi/widgets/score/WhiteNote;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
