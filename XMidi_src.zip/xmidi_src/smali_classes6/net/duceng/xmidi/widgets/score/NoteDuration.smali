.class public final enum Lnet/duceng/xmidi/widgets/score/NoteDuration;
.super Ljava/lang/Enum;
.source "NoteDuration.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lnet/duceng/xmidi/widgets/score/NoteDuration;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field public static final enum DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field public static final enum DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field public static final enum DottedQuarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field public static final enum Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field public static final enum Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field public static final enum Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field public static final enum Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field public static final enum ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field public static final enum Triplet:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field public static final enum Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;


# direct methods
.method private static synthetic $values()[Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .locals 3

    .line 4
    const/16 v0, 0xa

    new-array v0, v0, [Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/4 v2, 0x1

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Triplet:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/4 v2, 0x2

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/4 v2, 0x3

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/4 v2, 0x4

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/4 v2, 0x5

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedQuarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/4 v2, 0x6

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/4 v2, 0x7

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/16 v2, 0x8

    aput-object v1, v0, v2

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const/16 v2, 0x9

    aput-object v1, v0, v2

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 5
    new-instance v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const-string v1, "ThirtySecond"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/NoteDuration;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 6
    new-instance v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const-string v1, "Sixteenth"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/NoteDuration;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 7
    new-instance v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const-string v1, "Triplet"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/NoteDuration;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Triplet:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 8
    new-instance v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const-string v1, "Eighth"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/NoteDuration;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 9
    new-instance v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const-string v1, "DottedEighth"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/NoteDuration;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 10
    new-instance v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const-string v1, "Quarter"

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/NoteDuration;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 11
    new-instance v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const-string v1, "DottedQuarter"

    const/4 v2, 0x6

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/NoteDuration;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedQuarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 12
    new-instance v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const-string v1, "Half"

    const/4 v2, 0x7

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/NoteDuration;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 13
    new-instance v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const-string v1, "DottedHalf"

    const/16 v2, 0x8

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/NoteDuration;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 14
    new-instance v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    const-string v1, "Whole"

    const/16 v2, 0x9

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/NoteDuration;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 4
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->$values()[Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v0

    sput-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->$VALUES:[Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 4
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .line 4
    const-class v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v0
.end method

.method public static values()[Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .locals 1

    .line 4
    sget-object v0, Lnet/duceng/xmidi/widgets/score/NoteDuration;->$VALUES:[Lnet/duceng/xmidi/widgets/score/NoteDuration;

    invoke-virtual {v0}, [Lnet/duceng/xmidi/widgets/score/NoteDuration;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v0
.end method

.method public static valuesCustom()[Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .locals 4

    .line 18
    invoke-static {}, Lnet/duceng/xmidi/widgets/score/NoteDuration;->values()[Lnet/duceng/xmidi/widgets/score/NoteDuration;

    move-result-object v0

    .line 19
    .local v0, "noteDurationArrValuesCustom":[Lnet/duceng/xmidi/widgets/score/NoteDuration;
    array-length v1, v0

    .line 20
    .local v1, "length":I
    new-array v2, v1, [Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 21
    .local v2, "noteDurationArr":[Lnet/duceng/xmidi/widgets/score/NoteDuration;
    const/4 v3, 0x0

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 22
    return-object v2
.end method
