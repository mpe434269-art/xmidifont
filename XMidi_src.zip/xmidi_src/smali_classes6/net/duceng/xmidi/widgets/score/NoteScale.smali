.class public Lnet/duceng/xmidi/widgets/score/NoteScale;
.super Ljava/lang/Object;
.source "NoteScale.java"


# static fields
.field public static final A:I = 0x0

.field public static final Aflat:I = 0xb

.field public static final Asharp:I = 0x1

.field public static final B:I = 0x2

.field public static final Bflat:I = 0x1

.field public static final C:I = 0x3

.field public static final Csharp:I = 0x4

.field public static final D:I = 0x5

.field public static final Dflat:I = 0x4

.field public static final Dsharp:I = 0x6

.field public static final E:I = 0x7

.field public static final Eflat:I = 0x6

.field public static final F:I = 0x8

.field public static final Fsharp:I = 0x9

.field public static final G:I = 0xa

.field public static final Gflat:I = 0x9

.field public static final Gsharp:I = 0xb


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static FromNumber(I)I
    .locals 1
    .param p0, "number"    # I

    .line 28
    add-int/lit8 v0, p0, 0x3

    rem-int/lit8 v0, v0, 0xc

    return v0
.end method

.method public static IsBlackKey(I)Z
    .locals 2
    .param p0, "notescale"    # I

    .line 32
    const/4 v0, 0x1

    if-eq p0, v0, :cond_1

    const/4 v1, 0x4

    if-eq p0, v1, :cond_1

    const/4 v1, 0x6

    if-eq p0, v1, :cond_1

    const/16 v1, 0x9

    if-eq p0, v1, :cond_1

    const/16 v1, 0xb

    if-ne p0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :cond_1
    :goto_0
    return v0
.end method

.method public static ToNumber(II)I
    .locals 2
    .param p0, "notescale"    # I
    .param p1, "octave"    # I

    .line 24
    add-int/lit8 v0, p0, 0x9

    mul-int/lit8 v1, p1, 0xc

    add-int/2addr v0, v1

    return v0
.end method
