.class public Lnet/duceng/xmidi/widgets/score/RestSymbol;
.super Ljava/lang/Object;
.source "RestSymbol.java"

# interfaces
.implements Lnet/duceng/xmidi/widgets/score/MusicSymbol;


# instance fields
.field private duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field private starttime:I

.field private width:I


# direct methods
.method public constructor <init>(ILnet/duceng/xmidi/widgets/score/NoteDuration;)V
    .locals 1
    .param p1, "start"    # I
    .param p2, "dur"    # Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/RestSymbol;->getMinWidth()I

    move-result v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->width:I

    .line 14
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->starttime:I

    .line 15
    iput-object p2, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 16
    return-void
.end method


# virtual methods
.method public DrawEighth(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 9
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 98
    add-int/lit8 v0, p3, 0x8

    add-int/lit8 v0, v0, -0x1

    .line 99
    .local v0, "y":I
    new-instance v1, Landroid/graphics/RectF;

    add-int/lit8 v2, v0, 0x1

    int-to-float v2, v2

    add-int/lit8 v3, v0, 0x1

    add-int/lit8 v3, v3, 0x7

    add-int/lit8 v3, v3, -0x1

    int-to-float v3, v3

    const/4 v4, 0x0

    const/high16 v5, 0x40c00000    # 6.0f

    invoke-direct {v1, v4, v2, v5, v3}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 100
    .local v1, "rect":Landroid/graphics/RectF;
    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 101
    invoke-virtual {p1, v1, p2}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 102
    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 103
    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {p2, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 104
    add-int/lit8 v2, v0, 0x7

    add-int/lit8 v2, v2, -0x1

    int-to-float v5, v2

    add-int/lit8 v2, v0, 0x3

    int-to-float v7, v2

    const/high16 v4, 0x40000000    # 2.0f

    const/high16 v6, 0x41200000    # 10.0f

    move-object v3, p1

    move-object v8, p2

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 105
    add-int/lit8 v2, v0, 0x3

    int-to-float v5, v2

    add-int/lit8 v2, v0, 0x10

    int-to-float v7, v2

    const/high16 v4, 0x41200000    # 10.0f

    const/high16 v6, 0x40a00000    # 5.0f

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 106
    return-void
.end method

.method public DrawHalf(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 8
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 73
    add-int/lit8 v0, p3, 0x8

    add-int/lit8 v0, v0, 0x4

    .line 74
    .local v0, "y":I
    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 75
    int-to-float v4, v0

    add-int/lit8 v1, v0, 0x4

    int-to-float v6, v1

    const/4 v3, 0x0

    const/high16 v5, 0x41200000    # 10.0f

    move-object v2, p1

    move-object v7, p2

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 76
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 77
    return-void
.end method

.method public DrawQuarter(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 13
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 80
    move-object v6, p2

    sget-object v0, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 81
    add-int/lit8 v7, p3, 0x4

    .line 82
    .local v7, "y":I
    const/4 v8, 0x7

    .line 83
    .local v8, "xend":I
    const/high16 v9, 0x3f800000    # 1.0f

    invoke-virtual {p2, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 84
    int-to-float v2, v7

    add-int/lit8 v0, v7, 0x8

    add-int/lit8 v0, v0, -0x1

    int-to-float v4, v0

    const/high16 v1, 0x40000000    # 2.0f

    const/high16 v3, 0x40c00000    # 6.0f

    move-object v0, p1

    move-object v5, p2

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 85
    const/high16 v10, 0x40400000    # 3.0f

    invoke-virtual {p2, v10}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 86
    add-int/lit8 v0, p3, 0x8

    add-int/lit8 v11, v0, 0x1

    .line 87
    .local v11, "y2":I
    int-to-float v2, v11

    add-int/lit8 v0, v11, 0x8

    int-to-float v4, v0

    const/high16 v1, 0x40a00000    # 5.0f

    const/high16 v3, 0x40000000    # 2.0f

    move-object v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 88
    invoke-virtual {p2, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 89
    add-int/lit8 v0, p3, 0x10

    add-int/lit8 v12, v0, -0x1

    .line 90
    .local v12, "y3":I
    int-to-float v2, v12

    add-int/lit8 v0, v12, 0x8

    int-to-float v4, v0

    const/4 v1, 0x0

    const/high16 v3, 0x41100000    # 9.0f

    move-object v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 91
    invoke-virtual {p2, v10}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 92
    int-to-float v1, v8

    add-int/lit8 v0, v12, 0x6

    int-to-float v2, v0

    add-int/lit8 v0, v12, 0x6

    int-to-float v4, v0

    const/high16 v3, 0x3f800000    # 1.0f

    move-object v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 93
    invoke-virtual {p2, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 94
    add-int/lit8 v0, v12, 0x5

    add-int/lit8 v0, v0, 0x1

    int-to-float v2, v0

    add-int/lit8 v0, v12, 0xc

    int-to-float v4, v0

    const/4 v1, 0x0

    const/high16 v3, 0x40c00000    # 6.0f

    move-object v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 95
    return-void
.end method

.method public DrawWhole(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 8
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 66
    add-int/lit8 v0, p3, 0x8

    .line 67
    .local v0, "y":I
    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 68
    int-to-float v4, v0

    add-int/lit8 v1, v0, 0x4

    int-to-float v6, v1

    const/4 v3, 0x0

    const/high16 v5, 0x41200000    # 10.0f

    move-object v2, p1

    move-object v7, p2

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 69
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 70
    return-void
.end method

.method public draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 3
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 50
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/RestSymbol;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/RestSymbol;->getMinWidth()I

    move-result v1

    sub-int/2addr v0, v1

    int-to-float v0, v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 51
    const/high16 v0, 0x40800000    # 4.0f

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 52
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v0, v2, :cond_0

    .line 53
    invoke-virtual {p0, p1, p2, p3}, Lnet/duceng/xmidi/widgets/score/RestSymbol;->DrawWhole(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    goto :goto_0

    .line 54
    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v0, v2, :cond_1

    .line 55
    invoke-virtual {p0, p1, p2, p3}, Lnet/duceng/xmidi/widgets/score/RestSymbol;->DrawHalf(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    goto :goto_0

    .line 56
    :cond_1
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v0, v2, :cond_2

    .line 57
    invoke-virtual {p0, p1, p2, p3}, Lnet/duceng/xmidi/widgets/score/RestSymbol;->DrawQuarter(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    goto :goto_0

    .line 58
    :cond_2
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v0, v2, :cond_3

    .line 59
    invoke-virtual {p0, p1, p2, p3}, Lnet/duceng/xmidi/widgets/score/RestSymbol;->DrawEighth(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    .line 61
    :cond_3
    :goto_0
    const/high16 v0, -0x3f800000    # -4.0f

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 62
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/RestSymbol;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/RestSymbol;->getMinWidth()I

    move-result v2

    sub-int/2addr v0, v2

    neg-int v0, v0

    int-to-float v0, v0

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 63
    return-void
.end method

.method public getAboveStaff()I
    .locals 1

    .line 40
    const/4 v0, 0x0

    return v0
.end method

.method public getBelowStaff()I
    .locals 1

    .line 45
    const/4 v0, 0x0

    return v0
.end method

.method public getMinWidth()I
    .locals 1

    .line 35
    const/16 v0, 0x14

    return v0
.end method

.method public getStartTime()I
    .locals 1

    .line 20
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->starttime:I

    return v0
.end method

.method public getWidth()I
    .locals 1

    .line 25
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->width:I

    return v0
.end method

.method public setWidth(I)V
    .locals 0
    .param p1, "value"    # I

    .line 30
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->width:I

    .line 31
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    .line 109
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->starttime:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/RestSymbol;->width:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v3, 0x3

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object v0, v3, v4

    const/4 v0, 0x1

    aput-object v1, v3, v0

    const/4 v0, 0x2

    aput-object v2, v3, v0

    const-string v0, "RestSymbol starttime=%1$s duration=%2$s width=%3$s"

    invoke-static {v0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
