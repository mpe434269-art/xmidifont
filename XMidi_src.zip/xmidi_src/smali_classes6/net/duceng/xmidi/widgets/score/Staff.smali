.class public Lnet/duceng/xmidi/widgets/score/Staff;
.super Ljava/lang/Object;
.source "Staff.java"


# instance fields
.field private clefsym:Lnet/duceng/xmidi/widgets/score/ClefSymbol;

.field private endtime:I

.field private height:I

.field private keys:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

.field private keysigWidth:I

.field private lyrics:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/LyricSymbol;",
            ">;"
        }
    .end annotation
.end field

.field private measureLength:I

.field private showMeasures:Z

.field private starttime:I

.field private symbols:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;"
        }
    .end annotation
.end field

.field private totaltracks:I

.field private tracknum:I

.field private width:I

.field private ytop:I


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Lnet/duceng/xmidi/widgets/score/MidiKey;Lnet/duceng/xmidi/widgets/score/MidiTime;ZZII)V
    .locals 3
    .param p2, "key"    # Lnet/duceng/xmidi/widgets/score/MidiKey;
    .param p3, "time"    # Lnet/duceng/xmidi/widgets/score/MidiTime;
    .param p4, "showMeasures"    # Z
    .param p5, "scrollVert"    # Z
    .param p6, "tracknum"    # I
    .param p7, "totaltracks"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;",
            "Lnet/duceng/xmidi/widgets/score/MidiKey;",
            "Lnet/duceng/xmidi/widgets/score/MidiTime;",
            "ZZII)V"
        }
    .end annotation

    .line 28
    .local p1, "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 29
    invoke-static {p2}, Lnet/duceng/xmidi/widgets/MusicScore;->KeySignatureWidth(Lnet/duceng/xmidi/widgets/score/MidiKey;)I

    move-result v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keysigWidth:I

    .line 30
    iput p6, p0, Lnet/duceng/xmidi/widgets/score/Staff;->tracknum:I

    .line 31
    iput p7, p0, Lnet/duceng/xmidi/widgets/score/Staff;->totaltracks:I

    .line 32
    const/4 v0, 0x0

    if-eqz p4, :cond_0

    if-nez p6, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    iput-boolean v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->showMeasures:Z

    .line 33
    invoke-virtual {p3}, Lnet/duceng/xmidi/widgets/score/MidiTime;->getMeasure()I

    move-result v1

    iput v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->measureLength:I

    .line 34
    invoke-direct {p0, p1}, Lnet/duceng/xmidi/widgets/score/Staff;->findClef(Ljava/util/ArrayList;)Lnet/duceng/xmidi/widgets/score/Clef;

    move-result-object v1

    .line 35
    .local v1, "clef":Lnet/duceng/xmidi/widgets/score/Clef;
    new-instance v2, Lnet/duceng/xmidi/widgets/score/ClefSymbol;

    invoke-direct {v2, v1, v0, v0}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;-><init>(Lnet/duceng/xmidi/widgets/score/Clef;IZ)V

    iput-object v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->clefsym:Lnet/duceng/xmidi/widgets/score/ClefSymbol;

    .line 36
    invoke-virtual {p2, v1}, Lnet/duceng/xmidi/widgets/score/MidiKey;->GetSymbols(Lnet/duceng/xmidi/widgets/score/Clef;)[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keys:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    .line 37
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    .line 38
    invoke-direct {p0, p5}, Lnet/duceng/xmidi/widgets/score/Staff;->CalculateWidth(Z)V

    .line 39
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/Staff;->CalculateHeight()V

    .line 40
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/score/Staff;->CalculateStartEndTime()V

    .line 41
    invoke-direct {p0}, Lnet/duceng/xmidi/widgets/score/Staff;->FullJustify()V

    .line 42
    return-void
.end method

.method public constructor <init>(Lnet/duceng/xmidi/widgets/score/Clef;II)V
    .locals 3
    .param p1, "clef"    # Lnet/duceng/xmidi/widgets/score/Clef;
    .param p2, "tracknum"    # I
    .param p3, "totaltracks"    # I

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 45
    new-instance v0, Lnet/duceng/xmidi/widgets/score/MidiKey;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Lnet/duceng/xmidi/widgets/score/MidiKey;-><init>(I)V

    .line 46
    .local v0, "key":Lnet/duceng/xmidi/widgets/score/MidiKey;
    invoke-static {v0}, Lnet/duceng/xmidi/widgets/MusicScore;->KeySignatureWidth(Lnet/duceng/xmidi/widgets/score/MidiKey;)I

    move-result v1

    iput v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keysigWidth:I

    .line 47
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->tracknum:I

    .line 48
    iput p3, p0, Lnet/duceng/xmidi/widgets/score/Staff;->totaltracks:I

    .line 49
    const/4 v1, 0x0

    iput-boolean v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->showMeasures:Z

    .line 50
    const/16 v2, 0x78

    iput v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->measureLength:I

    .line 51
    new-instance v2, Lnet/duceng/xmidi/widgets/score/ClefSymbol;

    invoke-direct {v2, p1, v1, v1}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;-><init>(Lnet/duceng/xmidi/widgets/score/Clef;IZ)V

    iput-object v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->clefsym:Lnet/duceng/xmidi/widgets/score/ClefSymbol;

    .line 52
    invoke-virtual {v0, p1}, Lnet/duceng/xmidi/widgets/score/MidiKey;->GetSymbols(Lnet/duceng/xmidi/widgets/score/Clef;)[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    move-result-object v2

    iput-object v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keys:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    .line 53
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    .line 54
    const/16 v2, 0x320

    iput v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    .line 55
    const/16 v2, 0x18

    iput v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    .line 56
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    add-int/lit8 v2, v2, 0x28

    add-int/lit8 v2, v2, 0x10

    iput v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->height:I

    .line 57
    iput v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    .line 58
    iput v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->starttime:I

    .line 59
    return-void
.end method

.method private CalculateStartEndTime()V
    .locals 5

    .line 127
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    .line 128
    iput v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->starttime:I

    .line 129
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-eqz v1, :cond_2

    .line 130
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v0}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->starttime:I

    .line 131
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 132
    .local v1, "m":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    invoke-interface {v1}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v3

    if-ge v2, v3, :cond_0

    .line 133
    invoke-interface {v1}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v2

    iput v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    .line 135
    :cond_0
    instance-of v2, v1, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    if-eqz v2, :cond_1

    .line 136
    move-object v2, v1

    check-cast v2, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    .line 137
    .local v2, "c":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    iget v3, p0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getEndTime()I

    move-result v4

    if-ge v3, v4, :cond_1

    .line 138
    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getEndTime()I

    move-result v3

    iput v3, p0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    .line 141
    .end local v1    # "m":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .end local v2    # "c":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    :cond_1
    goto :goto_0

    .line 143
    :cond_2
    return-void
.end method

.method private CalculateWidth(Z)V
    .locals 4
    .param p1, "scrollVert"    # Z

    .line 115
    if-eqz p1, :cond_0

    .line 116
    const/16 v0, 0x320

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    .line 117
    return-void

    .line 119
    :cond_0
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keysigWidth:I

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    .line 120
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 121
    .local v1, "s":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    invoke-interface {v1}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v3

    add-int/2addr v2, v3

    iput v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    .line 122
    .end local v1    # "s":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    goto :goto_0

    .line 123
    :cond_1
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    add-int/lit8 v0, v0, 0x8

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    .line 124
    return-void
.end method

.method private FullJustify()V
    .locals 8

    .line 146
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    const/16 v1, 0x320

    if-ne v0, v1, :cond_6

    .line 147
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keysigWidth:I

    .line 148
    .local v0, "totalwidth":I
    const/4 v1, 0x0

    .line 149
    .local v1, "totalsymbols":I
    const/4 v2, 0x0

    .line 150
    .local v2, "i":I
    :goto_0
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_2

    .line 151
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v3

    .line 152
    .local v3, "start":I
    add-int/lit8 v1, v1, 0x1

    .line 153
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v4}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v4

    .line 155
    .local v4, "width":I
    :goto_1
    add-int/2addr v0, v4

    .line 156
    add-int/lit8 v2, v2, 0x1

    .line 157
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v2, v5, :cond_1

    iget-object v5, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v5}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v5

    if-eq v5, v3, :cond_0

    .line 158
    goto :goto_2

    .line 160
    :cond_0
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v5}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v4

    goto :goto_1

    .line 163
    .end local v3    # "start":I
    .end local v4    # "width":I
    :cond_1
    :goto_2
    goto :goto_0

    .line 164
    :cond_2
    rsub-int v3, v0, 0x320

    add-int/lit8 v3, v3, -0x1

    div-int/2addr v3, v1

    .line 165
    .local v3, "extrawidth":I
    const/16 v4, 0x10

    if-le v3, v4, :cond_3

    .line 166
    const/16 v3, 0x10

    .line 168
    :cond_3
    const/4 v4, 0x0

    .line 169
    .local v4, "i2":I
    :goto_3
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v4, v5, :cond_6

    .line 170
    iget-object v5, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v5}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v5

    .line 171
    .local v5, "start2":I
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v6}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v6

    add-int/2addr v6, v3

    .line 172
    .local v6, "newwidth":I
    iget-object v7, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v7, v6}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->setWidth(I)V

    .line 174
    :cond_4
    add-int/lit8 v4, v4, 0x1

    .line 175
    iget-object v7, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-lt v4, v7, :cond_5

    .line 176
    goto :goto_4

    .line 178
    :cond_5
    iget-object v7, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v7}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v7

    if-eq v7, v5, :cond_4

    .line 179
    .end local v5    # "start2":I
    .end local v6    # "newwidth":I
    :goto_4
    goto :goto_3

    .line 181
    .end local v0    # "totalwidth":I
    .end local v1    # "totalsymbols":I
    .end local v2    # "i":I
    .end local v3    # "extrawidth":I
    .end local v4    # "i2":I
    :cond_6
    return-void
.end method

.method private drawEndLines(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V
    .locals 9
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;

    .line 242
    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 243
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->tracknum:I

    if-nez v0, :cond_0

    .line 244
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    add-int/lit8 v0, v0, -0x1

    .local v0, "ystart":I
    goto :goto_0

    .line 246
    .end local v0    # "ystart":I
    :cond_0
    const/4 v0, 0x0

    .line 248
    .restart local v0    # "ystart":I
    :goto_0
    iget v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->tracknum:I

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->totaltracks:I

    add-int/lit8 v2, v2, -0x1

    if-ne v1, v2, :cond_1

    .line 249
    iget v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    add-int/lit8 v1, v1, 0x20

    .local v1, "yend":I
    goto :goto_1

    .line 251
    .end local v1    # "yend":I
    :cond_1
    iget v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->height:I

    .line 253
    .restart local v1    # "yend":I
    :goto_1
    int-to-float v4, v0

    const/high16 v5, 0x40800000    # 4.0f

    int-to-float v6, v1

    const/high16 v3, 0x40800000    # 4.0f

    move-object v2, p1

    move-object v7, p2

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 254
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    add-int/lit8 v2, v2, -0x4

    int-to-float v4, v2

    int-to-float v5, v0

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    add-int/lit8 v2, v2, -0x4

    int-to-float v6, v2

    int-to-float v7, v1

    move-object v3, p1

    move-object v8, p2

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 255
    return-void
.end method

.method private drawHorizLines(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V
    .locals 9
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;

    .line 231
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    add-int/lit8 v0, v0, -0x1

    .line 232
    .local v0, "y":I
    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 233
    const/4 v1, 0x1

    .local v1, "line":I
    :goto_0
    const/4 v2, 0x5

    if-gt v1, v2, :cond_0

    .line 234
    int-to-float v5, v0

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    add-int/lit8 v2, v2, -0x4

    int-to-float v6, v2

    int-to-float v7, v0

    const/high16 v4, 0x40800000    # 4.0f

    move-object v3, p1

    move-object v8, p2

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 235
    add-int/lit8 v0, v0, 0x8

    .line 233
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 237
    .end local v1    # "line":I
    :cond_0
    return-void
.end method

.method private drawLyrics(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V
    .locals 7
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;

    .line 211
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keysigWidth:I

    .line 212
    .local v0, "xpos":I
    iget v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->height:I

    add-int/lit8 v1, v1, -0xc

    .line 213
    .local v1, "ypos":I
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->lyrics:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/LyricSymbol;

    .line 214
    .local v3, "lyric":Lnet/duceng/xmidi/widgets/score/LyricSymbol;
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->getText()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->getX()I

    move-result v5

    add-int/2addr v5, v0

    int-to-float v5, v5

    int-to-float v6, v1

    invoke-virtual {p1, v4, v5, v6, p2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 215
    .end local v3    # "lyric":Lnet/duceng/xmidi/widgets/score/LyricSymbol;
    goto :goto_0

    .line 216
    :cond_0
    return-void
.end method

.method private drawMeasureNumbers(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V
    .locals 8
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;

    .line 219
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keysigWidth:I

    .line 220
    .local v0, "xpos":I
    iget v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    add-int/lit8 v1, v1, -0x18

    .line 221
    .local v1, "ypos":I
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 222
    .local v3, "s":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    instance-of v4, v3, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    if-eqz v4, :cond_0

    .line 223
    invoke-interface {v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v4

    iget v5, p0, Lnet/duceng/xmidi/widgets/score/Staff;->measureLength:I

    div-int/2addr v4, v5

    add-int/lit8 v4, v4, 0x1

    .line 224
    .local v4, "measure":I
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    add-int/lit8 v6, v0, 0x5

    int-to-float v6, v6

    int-to-float v7, v1

    invoke-virtual {p1, v5, v6, v7, p2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 226
    .end local v4    # "measure":I
    :cond_0
    invoke-interface {v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v4

    add-int/2addr v0, v4

    .line 227
    .end local v3    # "s":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    goto :goto_0

    .line 228
    :cond_1
    return-void
.end method

.method private findClef(Ljava/util/ArrayList;)Lnet/duceng/xmidi/widgets/score/Clef;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;)",
            "Lnet/duceng/xmidi/widgets/score/Clef;"
        }
    .end annotation

    .line 86
    .local p1, "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 87
    .local v1, "m":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    instance-of v2, v1, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    if-eqz v2, :cond_0

    .line 88
    move-object v0, v1

    check-cast v0, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    .line 89
    .local v0, "c":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getClef()Lnet/duceng/xmidi/widgets/score/Clef;

    move-result-object v2

    return-object v2

    .line 91
    .end local v0    # "c":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    .end local v1    # "m":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    :cond_0
    goto :goto_0

    .line 92
    :cond_1
    sget-object v0, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    return-object v0
.end method


# virtual methods
.method public CalculateHeight()V
    .locals 5

    .line 96
    const/4 v0, 0x0

    .line 97
    .local v0, "above":I
    const/4 v1, 0x0

    .line 98
    .local v1, "below":I
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 99
    .local v3, "s":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    invoke-interface {v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getAboveStaff()I

    move-result v4

    invoke-static {v0, v4}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 100
    invoke-interface {v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getBelowStaff()I

    move-result v4

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 101
    .end local v3    # "s":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    goto :goto_0

    .line 102
    :cond_0
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->clefsym:Lnet/duceng/xmidi/widgets/score/ClefSymbol;

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->getAboveStaff()I

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 103
    .local v2, "above2":I
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/Staff;->clefsym:Lnet/duceng/xmidi/widgets/score/ClefSymbol;

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->getBelowStaff()I

    move-result v3

    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    .line 104
    .local v3, "below2":I
    iget-boolean v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->showMeasures:Z

    if-eqz v4, :cond_1

    .line 105
    const/16 v4, 0x18

    invoke-static {v2, v4}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 107
    :cond_1
    add-int/lit8 v4, v2, 0x8

    iput v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    .line 108
    iget v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    add-int/lit8 v4, v4, 0x28

    add-int/2addr v4, v3

    iput v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->height:I

    .line 109
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->lyrics:Ljava/util/ArrayList;

    if-eqz v4, :cond_2

    .line 110
    iget v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->height:I

    add-int/lit8 v4, v4, 0xc

    iput v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->height:I

    .line 112
    :cond_2
    return-void
.end method

.method public PulseTimeForPoint(Landroid/graphics/Point;)I
    .locals 6
    .param p1, "point"    # Landroid/graphics/Point;

    .line 289
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keysigWidth:I

    .line 290
    .local v0, "xpos":I
    iget v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->starttime:I

    .line 291
    .local v1, "pulseTime":I
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 292
    .local v3, "sym":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    invoke-interface {v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v1

    .line 293
    iget v4, p1, Landroid/graphics/Point;->x:I

    invoke-interface {v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v5

    add-int/2addr v5, v0

    if-gt v4, v5, :cond_0

    .line 294
    return v1

    .line 296
    :cond_0
    invoke-interface {v3}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v4

    add-int/2addr v0, v4

    .line 297
    .end local v3    # "sym":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    goto :goto_0

    .line 298
    :cond_1
    return v1
.end method

.method public addLyrics(Ljava/util/ArrayList;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/LyricSymbol;",
            ">;)V"
        }
    .end annotation

    .line 184
    .local p1, "tracklyrics":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/LyricSymbol;>;"
    if-eqz p1, :cond_5

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-eqz v0, :cond_5

    .line 185
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->lyrics:Ljava/util/ArrayList;

    .line 186
    const/4 v0, 0x0

    .line 187
    .local v0, "xpos":I
    const/4 v1, 0x0

    .line 188
    .local v1, "symbolindex":I
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/LyricSymbol;

    .line 189
    .local v3, "lyric":Lnet/duceng/xmidi/widgets/score/LyricSymbol;
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->getStartTime()I

    move-result v4

    iget v5, p0, Lnet/duceng/xmidi/widgets/score/Staff;->starttime:I

    if-lt v4, v5, :cond_3

    .line 190
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->getStartTime()I

    move-result v4

    iget v5, p0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    if-le v4, v5, :cond_0

    .line 191
    goto :goto_2

    .line 193
    :cond_0
    :goto_1
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v1, v4, :cond_1

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v4}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v4

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->getStartTime()I

    move-result v5

    if-ge v4, v5, :cond_1

    .line 194
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v4}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v4

    add-int/2addr v0, v4

    .line 195
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 197
    :cond_1
    invoke-virtual {v3, v0}, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->setX(I)V

    .line 198
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v1, v4, :cond_2

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    instance-of v4, v4, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    if-eqz v4, :cond_2

    .line 199
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->getX()I

    move-result v4

    add-int/lit8 v4, v4, 0xa

    invoke-virtual {v3, v4}, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->setX(I)V

    .line 201
    :cond_2
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->lyrics:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 203
    .end local v3    # "lyric":Lnet/duceng/xmidi/widgets/score/LyricSymbol;
    :cond_3
    goto :goto_0

    .line 204
    :cond_4
    :goto_2
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->lyrics:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-nez v2, :cond_5

    .line 205
    const/4 v2, 0x0

    iput-object v2, p0, Lnet/duceng/xmidi/widgets/score/Staff;->lyrics:Ljava/util/ArrayList;

    .line 208
    .end local v0    # "xpos":I
    .end local v1    # "symbolindex":I
    :cond_5
    return-void
.end method

.method public draw(Landroid/graphics/Canvas;Landroid/graphics/Rect;Landroid/graphics/Paint;)V
    .locals 8
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "clip"    # Landroid/graphics/Rect;
    .param p3, "paint"    # Landroid/graphics/Paint;

    .line 258
    const/high16 v0, -0x1000000

    invoke-virtual {p3, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 259
    const/high16 v1, 0x41100000    # 9.0f

    const/4 v2, 0x0

    invoke-virtual {p1, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 260
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->clefsym:Lnet/duceng/xmidi/widgets/score/ClefSymbol;

    iget v3, p0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    invoke-virtual {v1, p1, p3, v3}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    .line 261
    const/high16 v1, -0x3ef00000    # -9.0f

    invoke-virtual {p1, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 262
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->clefsym:Lnet/duceng/xmidi/widgets/score/ClefSymbol;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->getWidth()I

    move-result v1

    add-int/lit8 v1, v1, 0x9

    .line 263
    .local v1, "xpos":I
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keys:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    array-length v4, v3

    const/4 v5, 0x0

    :goto_0
    if-ge v5, v4, :cond_0

    aget-object v6, v3, v5

    .line 264
    .local v6, "a":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    int-to-float v7, v1

    invoke-virtual {p1, v7, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 265
    iget v7, p0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    invoke-virtual {v6, p1, p3, v7}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    .line 266
    neg-int v7, v1

    int-to-float v7, v7

    invoke-virtual {p1, v7, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 267
    invoke-virtual {v6}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->getWidth()I

    move-result v7

    add-int/2addr v1, v7

    .line 263
    .end local v6    # "a":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 269
    :cond_0
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 270
    .local v4, "s":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    iget v5, p2, Landroid/graphics/Rect;->left:I

    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    move-result v6

    add-int/2addr v5, v6

    add-int/lit8 v5, v5, 0x32

    if-gt v1, v5, :cond_1

    invoke-interface {v4}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v5

    add-int/2addr v5, v1

    add-int/lit8 v5, v5, 0x32

    iget v6, p2, Landroid/graphics/Rect;->left:I

    if-lt v5, v6, :cond_1

    .line 271
    int-to-float v5, v1

    invoke-virtual {p1, v5, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 272
    iget v5, p0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    invoke-interface {v4, p1, p3, v5}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    .line 273
    neg-int v5, v1

    int-to-float v5, v5

    invoke-virtual {p1, v5, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 275
    :cond_1
    invoke-interface {v4}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v5

    add-int/2addr v1, v5

    .line 276
    .end local v4    # "s":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    goto :goto_1

    .line 277
    :cond_2
    invoke-virtual {p3, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 278
    invoke-direct {p0, p1, p3}, Lnet/duceng/xmidi/widgets/score/Staff;->drawHorizLines(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V

    .line 279
    invoke-direct {p0, p1, p3}, Lnet/duceng/xmidi/widgets/score/Staff;->drawEndLines(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V

    .line 280
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->showMeasures:Z

    if-eqz v0, :cond_3

    .line 281
    invoke-direct {p0, p1, p3}, Lnet/duceng/xmidi/widgets/score/Staff;->drawMeasureNumbers(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V

    .line 283
    :cond_3
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->lyrics:Ljava/util/ArrayList;

    if-eqz v0, :cond_4

    .line 284
    invoke-direct {p0, p1, p3}, Lnet/duceng/xmidi/widgets/score/Staff;->drawLyrics(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V

    .line 286
    :cond_4
    return-void
.end method

.method public getEndTime()I
    .locals 1

    .line 78
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    return v0
.end method

.method public getHeight()I
    .locals 1

    .line 66
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->height:I

    return v0
.end method

.method public getStartTime()I
    .locals 1

    .line 74
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->starttime:I

    return v0
.end method

.method public getTrack()I
    .locals 1

    .line 70
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->tracknum:I

    return v0
.end method

.method public getWidth()I
    .locals 1

    .line 62
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Staff;->width:I

    return v0
.end method

.method public setEndTime(I)V
    .locals 0
    .param p1, "value"    # I

    .line 82
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    .line 83
    return-void
.end method

.method public shadeNotes(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIII)I
    .locals 24
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "shade"    # I
    .param p4, "currentPulseTime"    # I
    .param p5, "prevPulseTime"    # I
    .param p6, "x_shade"    # I

    .line 304
    move-object/from16 v0, p0

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    move/from16 v9, p4

    move/from16 v10, p5

    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->starttime:I

    if-gt v1, v10, :cond_0

    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    if-ge v1, v10, :cond_1

    :cond_0
    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->starttime:I

    if-gt v1, v9, :cond_11

    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    if-ge v1, v9, :cond_1

    goto/16 :goto_6

    .line 307
    :cond_1
    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->keysigWidth:I

    .line 308
    .local v1, "xpos":I
    const/4 v2, 0x0

    .line 309
    .local v2, "prevChord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    const/4 v3, 0x0

    .line 310
    .local v3, "prev_xpos":I
    const/4 v4, 0x0

    move/from16 v11, p6

    move v12, v1

    move-object v13, v2

    move v14, v3

    move v15, v4

    .end local v1    # "xpos":I
    .end local v2    # "prevChord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    .end local v3    # "prev_xpos":I
    .end local p6    # "x_shade":I
    .local v11, "x_shade":I
    .local v12, "xpos":I
    .local v13, "prevChord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    .local v14, "prev_xpos":I
    .local v15, "i":I
    :goto_0
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v15, v1, :cond_10

    .line 311
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v1, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v6, v1

    check-cast v6, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 312
    .local v6, "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    instance-of v1, v6, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    if-eqz v1, :cond_2

    .line 313
    invoke-interface {v6}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v1

    move-object v10, v6

    .local v1, "width":I
    goto/16 :goto_5

    .line 315
    .end local v1    # "width":I
    :cond_2
    invoke-interface {v6}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v5

    .line 316
    .local v5, "start":I
    add-int/lit8 v1, v15, 0x2

    iget-object v2, v0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_3

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    add-int/lit8 v2, v15, 0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    instance-of v1, v1, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    if-eqz v1, :cond_3

    .line 317
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    add-int/lit8 v2, v15, 0x2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v1}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v1

    move v4, v1

    .local v1, "end":I
    goto :goto_1

    .line 318
    .end local v1    # "end":I
    :cond_3
    add-int/lit8 v1, v15, 0x1

    iget-object v2, v0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    .line 319
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    add-int/lit8 v2, v15, 0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    invoke-interface {v1}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v1

    move v4, v1

    .restart local v1    # "end":I
    goto :goto_1

    .line 321
    .end local v1    # "end":I
    :cond_4
    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->endtime:I

    move v4, v1

    .line 323
    .local v4, "end":I
    :goto_1
    if-le v5, v10, :cond_6

    if-le v5, v9, :cond_6

    .line 324
    if-nez v11, :cond_5

    .line 325
    move v11, v12

    .line 327
    :cond_5
    return v11

    .line 329
    :cond_6
    if-gt v5, v9, :cond_7

    if-ge v9, v4, :cond_7

    if-gt v5, v10, :cond_7

    if-ge v10, v4, :cond_7

    .line 330
    return v12

    .line 332
    :cond_7
    const/16 v16, 0x0

    .line 333
    .local v16, "redrawLines":Z
    const/high16 v3, -0x1000000

    if-gt v5, v10, :cond_8

    if-ge v10, v4, :cond_8

    .line 334
    add-int/lit8 v1, v12, -0x2

    int-to-float v1, v1

    const/high16 v2, -0x40000000    # -2.0f

    invoke-virtual {v7, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 335
    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 336
    const/4 v1, -0x1

    invoke-virtual {v8, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 337
    invoke-interface {v6}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v1

    add-int/lit8 v1, v1, 0x4

    int-to-float v2, v1

    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v1

    add-int/lit8 v1, v1, 0x4

    int-to-float v1, v1

    const/16 v17, 0x0

    const/16 v18, 0x0

    move/from16 v19, v1

    move-object/from16 v1, p1

    move/from16 v20, v2

    const/4 v10, 0x0

    move/from16 v2, v17

    const/high16 v10, -0x1000000

    move/from16 v3, v18

    move/from16 v21, v4

    .end local v4    # "end":I
    .local v21, "end":I
    move/from16 v4, v20

    move/from16 v22, v5

    .end local v5    # "start":I
    .local v22, "start":I
    move/from16 v5, v19

    move-object/from16 v23, v6

    .end local v6    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .local v23, "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    move-object/from16 v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 338
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 339
    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setColor(I)V

    .line 340
    add-int/lit8 v1, v12, -0x2

    neg-int v1, v1

    int-to-float v1, v1

    const/high16 v2, 0x40000000    # 2.0f

    invoke-virtual {v7, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 341
    int-to-float v1, v12

    const/4 v2, 0x0

    invoke-virtual {v7, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 342
    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    move-object/from16 v6, v23

    .end local v23    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .restart local v6    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    invoke-interface {v6, v7, v8, v1}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    .line 343
    neg-int v1, v12

    int-to-float v1, v1

    invoke-virtual {v7, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 344
    const/16 v16, 0x1

    goto :goto_2

    .line 333
    .end local v21    # "end":I
    .end local v22    # "start":I
    .restart local v4    # "end":I
    .restart local v5    # "start":I
    :cond_8
    move/from16 v21, v4

    move/from16 v22, v5

    const/high16 v10, -0x1000000

    .line 346
    .end local v4    # "end":I
    .end local v5    # "start":I
    .restart local v21    # "end":I
    .restart local v22    # "start":I
    :goto_2
    move/from16 v5, v22

    .end local v22    # "start":I
    .restart local v5    # "start":I
    if-gt v5, v9, :cond_a

    move/from16 v4, v21

    .end local v21    # "end":I
    .restart local v4    # "end":I
    if-ge v9, v4, :cond_9

    .line 347
    move v11, v12

    .line 348
    int-to-float v1, v12

    const/4 v2, 0x0

    invoke-virtual {v7, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 349
    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 350
    invoke-virtual/range {p2 .. p3}, Landroid/graphics/Paint;->setColor(I)V

    .line 351
    invoke-interface {v6}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v1

    int-to-float v3, v1

    invoke-virtual/range {p0 .. p0}, Lnet/duceng/xmidi/widgets/score/Staff;->getHeight()I

    move-result v1

    int-to-float v2, v1

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object/from16 v1, p1

    move/from16 v19, v2

    move/from16 v2, v17

    move/from16 v17, v3

    move/from16 v3, v18

    move/from16 v18, v4

    .end local v4    # "end":I
    .local v18, "end":I
    move/from16 v4, v17

    move/from16 v17, v5

    .end local v5    # "start":I
    .local v17, "start":I
    move/from16 v5, v19

    move-object v10, v6

    .end local v6    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .local v10, "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    move-object/from16 v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 352
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 353
    const/high16 v1, -0x10000

    invoke-virtual {v8, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 354
    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    invoke-interface {v10, v7, v8, v1}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    .line 355
    neg-int v1, v12

    int-to-float v1, v1

    const/4 v2, 0x0

    invoke-virtual {v7, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 356
    const/16 v16, 0x1

    goto :goto_3

    .line 346
    .end local v10    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .end local v17    # "start":I
    .end local v18    # "end":I
    .restart local v4    # "end":I
    .restart local v5    # "start":I
    .restart local v6    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    :cond_9
    move/from16 v18, v4

    move/from16 v17, v5

    move-object v10, v6

    .end local v4    # "end":I
    .end local v5    # "start":I
    .end local v6    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .restart local v10    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .restart local v17    # "start":I
    .restart local v18    # "end":I
    goto :goto_3

    .end local v10    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .end local v17    # "start":I
    .end local v18    # "end":I
    .restart local v5    # "start":I
    .restart local v6    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .restart local v21    # "end":I
    :cond_a
    move/from16 v17, v5

    move-object v10, v6

    move/from16 v18, v21

    .line 358
    .end local v5    # "start":I
    .end local v6    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .end local v21    # "end":I
    .restart local v10    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .restart local v17    # "start":I
    .restart local v18    # "end":I
    :goto_3
    if-eqz v16, :cond_e

    .line 359
    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    add-int/lit8 v1, v1, -0x1

    .line 360
    .local v1, "y":I
    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 361
    const/high16 v2, -0x1000000

    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 362
    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 363
    add-int/lit8 v2, v12, -0x2

    int-to-float v2, v2

    const/4 v3, 0x0

    invoke-virtual {v7, v2, v3}, Landroid/graphics/Canvas;->translate(FF)V

    .line 364
    const/4 v2, 0x1

    move v6, v1

    move v5, v2

    .end local v1    # "y":I
    .local v5, "line":I
    .local v6, "y":I
    :goto_4
    const/4 v1, 0x5

    if-gt v5, v1, :cond_b

    .line 365
    int-to-float v3, v6

    invoke-interface {v10}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v1

    add-int/lit8 v1, v1, 0x4

    int-to-float v4, v1

    int-to-float v2, v6

    const/16 v19, 0x0

    move-object/from16 v1, p1

    move/from16 v20, v2

    move/from16 v2, v19

    move/from16 v19, v5

    .end local v5    # "line":I
    .local v19, "line":I
    move/from16 v5, v20

    move/from16 v20, v6

    .end local v6    # "y":I
    .local v20, "y":I
    move-object/from16 v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 366
    add-int/lit8 v6, v20, 0x8

    .line 364
    .end local v20    # "y":I
    .restart local v6    # "y":I
    add-int/lit8 v5, v19, 0x1

    .end local v19    # "line":I
    .restart local v5    # "line":I
    goto :goto_4

    :cond_b
    move/from16 v19, v5

    move/from16 v20, v6

    .line 368
    .end local v5    # "line":I
    .end local v6    # "y":I
    .restart local v20    # "y":I
    add-int/lit8 v1, v12, -0x2

    neg-int v1, v1

    int-to-float v1, v1

    const/4 v2, 0x0

    invoke-virtual {v7, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 369
    if-eqz v13, :cond_c

    .line 370
    int-to-float v1, v14

    invoke-virtual {v7, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 371
    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->ytop:I

    invoke-virtual {v13, v7, v8, v1}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V

    .line 372
    neg-int v1, v14

    int-to-float v1, v1

    invoke-virtual {v7, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 374
    :cond_c
    iget-boolean v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->showMeasures:Z

    if-eqz v1, :cond_d

    .line 375
    invoke-direct/range {p0 .. p2}, Lnet/duceng/xmidi/widgets/score/Staff;->drawMeasureNumbers(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V

    .line 377
    :cond_d
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Staff;->lyrics:Ljava/util/ArrayList;

    if-eqz v1, :cond_e

    .line 378
    invoke-direct/range {p0 .. p2}, Lnet/duceng/xmidi/widgets/score/Staff;->drawLyrics(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V

    .line 381
    .end local v20    # "y":I
    :cond_e
    instance-of v1, v10, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    if-eqz v1, :cond_f

    .line 382
    move-object v1, v10

    check-cast v1, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    .line 383
    .local v1, "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v2

    if-eqz v2, :cond_f

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/ChordSymbol;->getStem()Lnet/duceng/xmidi/widgets/score/Stem;

    move-result-object v2

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/Stem;->getReceiver()Z

    move-result v2

    if-nez v2, :cond_f

    .line 384
    move-object v13, v10

    check-cast v13, Lnet/duceng/xmidi/widgets/score/ChordSymbol;

    .line 385
    move v14, v12

    .line 388
    .end local v1    # "chord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    :cond_f
    invoke-interface {v10}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getWidth()I

    move-result v1

    .line 390
    .end local v16    # "redrawLines":Z
    .end local v17    # "start":I
    .end local v18    # "end":I
    .local v1, "width":I
    :goto_5
    add-int/2addr v12, v1

    .line 310
    .end local v10    # "curr":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    add-int/lit8 v15, v15, 0x1

    move/from16 v10, p5

    goto/16 :goto_0

    .line 392
    .end local v1    # "width":I
    .end local v15    # "i":I
    :cond_10
    return v11

    .line 305
    .end local v11    # "x_shade":I
    .end local v12    # "xpos":I
    .end local v13    # "prevChord":Lnet/duceng/xmidi/widgets/score/ChordSymbol;
    .end local v14    # "prev_xpos":I
    .restart local p6    # "x_shade":I
    :cond_11
    :goto_6
    return p6
.end method

.method public toString()Ljava/lang/String;
    .locals 11

    .line 396
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Staff clef="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/Staff;->clefsym:Lnet/duceng/xmidi/widgets/score/ClefSymbol;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/ClefSymbol;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 397
    .local v0, "result":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "  Keys:\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 398
    .local v2, "result2":Ljava/lang/String;
    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keys:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    array-length v4, v3

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_0
    const-string v7, "    "

    if-ge v6, v4, :cond_0

    aget-object v8, v3, v6

    .line 399
    .local v8, "a":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v8}, Lnet/duceng/xmidi/widgets/score/AccidSymbol;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 398
    .end local v8    # "a":Lnet/duceng/xmidi/widgets/score/AccidSymbol;
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    .line 401
    :cond_0
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "  Symbols:\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 402
    .local v3, "result3":Ljava/lang/String;
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->keys:[Lnet/duceng/xmidi/widgets/score/AccidSymbol;

    array-length v6, v4

    :goto_1
    if-ge v5, v6, :cond_1

    aget-object v8, v4, v5

    .line 403
    .local v8, "s":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 402
    .end local v8    # "s":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 405
    :cond_1
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Staff;->symbols:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 406
    .local v5, "m":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 407
    .end local v5    # "m":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    goto :goto_2

    .line 408
    :cond_2
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, "End Staff\n"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method
