.class public Lnet/duceng/xmidi/widgets/score/Stem;
.super Ljava/lang/Object;
.source "Stem.java"


# static fields
.field public static final Down:I = 0x2

.field public static final LeftSide:I = 0x1

.field public static final RightSide:I = 0x2

.field public static final Up:I = 0x1


# instance fields
.field private bottom:Lnet/duceng/xmidi/widgets/score/WhiteNote;

.field private direction:I

.field private duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

.field private end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

.field private notesoverlap:Z

.field private pair:Lnet/duceng/xmidi/widgets/score/Stem;

.field private receiver_in_pair:Z

.field private side:I

.field private top:Lnet/duceng/xmidi/widgets/score/WhiteNote;

.field private width_to_pair:I


# direct methods
.method public constructor <init>(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/NoteDuration;IZ)V
    .locals 2
    .param p1, "bottom"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .param p2, "top"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .param p3, "duration"    # Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .param p4, "direction"    # I
    .param p5, "overlap"    # Z

    .line 60
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 61
    iput-object p2, p0, Lnet/duceng/xmidi/widgets/score/Stem;->top:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 62
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->bottom:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 63
    iput-object p3, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    .line 64
    iput p4, p0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    .line 65
    iput-boolean p5, p0, Lnet/duceng/xmidi/widgets/score/Stem;->notesoverlap:Z

    .line 66
    const/4 v0, 0x1

    if-eq p4, v0, :cond_1

    iget-boolean v1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->notesoverlap:Z

    if-eqz v1, :cond_0

    goto :goto_0

    .line 69
    :cond_0
    iput v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    goto :goto_1

    .line 67
    :cond_1
    :goto_0
    const/4 v0, 0x2

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    .line 71
    :goto_1
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/Stem;->CalculateEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 72
    const/4 v0, 0x0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->pair:Lnet/duceng/xmidi/widgets/score/Stem;

    .line 73
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->width_to_pair:I

    .line 74
    iput-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->receiver_in_pair:Z

    .line 75
    return-void
.end method

.method private drawCurvyStem(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V
    .locals 16
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I
    .param p4, "topstaff"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 159
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p4

    const/high16 v4, 0x40000000    # 2.0f

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 160
    iget v4, v0, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    const/4 v5, 0x1

    if-ne v4, v5, :cond_0

    .line 161
    const/4 v4, 0x2

    .local v4, "xstart":I
    goto :goto_0

    .line 163
    .end local v4    # "xstart":I
    :cond_0
    const/16 v4, 0xb

    .line 165
    .restart local v4    # "xstart":I
    :goto_0
    iget v6, v0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    const/4 v7, 0x2

    if-ne v6, v5, :cond_5

    .line 166
    iget-object v5, v0, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v3, v5}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    div-int/2addr v5, v7

    add-int v5, p3, v5

    .line 167
    .local v5, "ystem":I
    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v6, v7, :cond_1

    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v6, v7, :cond_1

    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Triplet:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v6, v7, :cond_1

    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v6, v7, :cond_1

    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v6, v7, :cond_2

    .line 168
    :cond_1
    new-instance v6, Landroid/graphics/Path;

    invoke-direct {v6}, Landroid/graphics/Path;-><init>()V

    .line 169
    .local v6, "bezierPath":Landroid/graphics/Path;
    int-to-float v7, v4

    int-to-float v8, v5

    invoke-virtual {v6, v7, v8}, Landroid/graphics/Path;->moveTo(FF)V

    .line 170
    int-to-float v8, v4

    add-int/lit8 v7, v5, 0xa

    int-to-float v9, v7

    add-int/lit8 v7, v4, 0xe

    int-to-float v10, v7

    add-int/lit8 v7, v5, 0x10

    int-to-float v11, v7

    add-int/lit8 v7, v4, 0x3

    int-to-float v12, v7

    add-int/lit8 v7, v5, 0x18

    int-to-float v13, v7

    move-object v7, v6

    invoke-virtual/range {v7 .. v13}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 171
    invoke-virtual {v1, v6, v2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 173
    .end local v6    # "bezierPath":Landroid/graphics/Path;
    :cond_2
    add-int/lit8 v6, v5, 0x8

    .line 174
    .local v6, "ystem2":I
    iget-object v7, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v8, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v8, :cond_3

    iget-object v7, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v8, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v7, v8, :cond_4

    .line 175
    :cond_3
    new-instance v7, Landroid/graphics/Path;

    invoke-direct {v7}, Landroid/graphics/Path;-><init>()V

    .line 176
    .local v7, "bezierPath2":Landroid/graphics/Path;
    int-to-float v8, v4

    int-to-float v9, v6

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    .line 177
    int-to-float v9, v4

    add-int/lit8 v8, v6, 0xa

    int-to-float v10, v8

    add-int/lit8 v8, v4, 0xe

    int-to-float v11, v8

    add-int/lit8 v8, v6, 0x10

    int-to-float v12, v8

    add-int/lit8 v8, v4, 0x3

    int-to-float v13, v8

    add-int/lit8 v8, v6, 0x18

    int-to-float v14, v8

    move-object v8, v7

    invoke-virtual/range {v8 .. v14}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 178
    invoke-virtual {v1, v7, v2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 180
    .end local v7    # "bezierPath2":Landroid/graphics/Path;
    :cond_4
    add-int/lit8 v7, v6, 0x8

    .line 181
    .local v7, "ystem3":I
    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v9, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v8, v9, :cond_a

    .line 182
    new-instance v8, Landroid/graphics/Path;

    invoke-direct {v8}, Landroid/graphics/Path;-><init>()V

    .line 183
    .local v8, "bezierPath3":Landroid/graphics/Path;
    int-to-float v9, v4

    int-to-float v10, v7

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->moveTo(FF)V

    .line 184
    int-to-float v10, v4

    add-int/lit8 v9, v7, 0xa

    int-to-float v11, v9

    add-int/lit8 v9, v4, 0xe

    int-to-float v12, v9

    add-int/lit8 v9, v7, 0x10

    int-to-float v13, v9

    add-int/lit8 v9, v4, 0x3

    int-to-float v14, v9

    add-int/lit8 v9, v7, 0x18

    int-to-float v15, v9

    move-object v9, v8

    invoke-virtual/range {v9 .. v15}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 185
    invoke-virtual {v1, v8, v2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    goto/16 :goto_1

    .line 187
    .end local v5    # "ystem":I
    .end local v6    # "ystem2":I
    .end local v7    # "ystem3":I
    .end local v8    # "bezierPath3":Landroid/graphics/Path;
    :cond_5
    iget v5, v0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    if-ne v5, v7, :cond_a

    .line 188
    iget-object v5, v0, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v3, v5}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v5

    mul-int/lit8 v5, v5, 0x8

    div-int/2addr v5, v7

    add-int v5, v5, p3

    add-int/lit8 v5, v5, 0x8

    .line 189
    .local v5, "ystem4":I
    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v6, v7, :cond_6

    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v6, v7, :cond_6

    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Triplet:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v6, v7, :cond_6

    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v6, v7, :cond_6

    iget-object v6, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v7, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v6, v7, :cond_7

    .line 190
    :cond_6
    new-instance v6, Landroid/graphics/Path;

    invoke-direct {v6}, Landroid/graphics/Path;-><init>()V

    .line 191
    .local v6, "bezierPath4":Landroid/graphics/Path;
    int-to-float v7, v4

    int-to-float v8, v5

    invoke-virtual {v6, v7, v8}, Landroid/graphics/Path;->moveTo(FF)V

    .line 192
    int-to-float v8, v4

    add-int/lit8 v7, v5, -0x7

    int-to-float v9, v7

    add-int/lit8 v7, v4, 0xe

    int-to-float v10, v7

    add-int/lit8 v7, v5, -0x10

    int-to-float v11, v7

    add-int/lit8 v7, v4, 0x7

    int-to-float v12, v7

    add-int/lit8 v7, v5, -0x10

    add-int/lit8 v7, v7, -0x3

    int-to-float v13, v7

    move-object v7, v6

    invoke-virtual/range {v7 .. v13}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 193
    invoke-virtual {v1, v6, v2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 195
    .end local v6    # "bezierPath4":Landroid/graphics/Path;
    :cond_7
    add-int/lit8 v6, v5, -0x8

    .line 196
    .local v6, "ystem5":I
    iget-object v7, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v8, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v7, v8, :cond_8

    iget-object v7, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v8, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v7, v8, :cond_9

    .line 197
    :cond_8
    new-instance v7, Landroid/graphics/Path;

    invoke-direct {v7}, Landroid/graphics/Path;-><init>()V

    .line 198
    .local v7, "bezierPath5":Landroid/graphics/Path;
    int-to-float v8, v4

    int-to-float v9, v6

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    .line 199
    int-to-float v9, v4

    add-int/lit8 v8, v6, -0x7

    int-to-float v10, v8

    add-int/lit8 v8, v4, 0xe

    int-to-float v11, v8

    add-int/lit8 v8, v6, -0x10

    int-to-float v12, v8

    add-int/lit8 v8, v4, 0x7

    int-to-float v13, v8

    add-int/lit8 v8, v6, -0x10

    add-int/lit8 v8, v8, -0x3

    int-to-float v14, v8

    move-object v8, v7

    invoke-virtual/range {v8 .. v14}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 200
    invoke-virtual {v1, v7, v2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 202
    .end local v7    # "bezierPath5":Landroid/graphics/Path;
    :cond_9
    add-int/lit8 v7, v6, -0x8

    .line 203
    .local v7, "ystem6":I
    iget-object v8, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v9, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v8, v9, :cond_b

    .line 204
    new-instance v8, Landroid/graphics/Path;

    invoke-direct {v8}, Landroid/graphics/Path;-><init>()V

    .line 205
    .local v8, "bezierPath6":Landroid/graphics/Path;
    int-to-float v9, v4

    int-to-float v10, v7

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Path;->moveTo(FF)V

    .line 206
    int-to-float v10, v4

    add-int/lit8 v9, v7, -0x7

    int-to-float v11, v9

    add-int/lit8 v9, v4, 0xe

    int-to-float v12, v9

    add-int/lit8 v9, v7, -0x10

    int-to-float v13, v9

    add-int/lit8 v9, v4, 0x7

    int-to-float v14, v9

    add-int/lit8 v9, v7, -0x10

    add-int/lit8 v9, v9, -0x3

    int-to-float v15, v9

    move-object v9, v8

    invoke-virtual/range {v9 .. v15}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 207
    invoke-virtual {v1, v8, v2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    goto :goto_2

    .line 187
    .end local v5    # "ystem4":I
    .end local v6    # "ystem5":I
    .end local v7    # "ystem6":I
    .end local v8    # "bezierPath6":Landroid/graphics/Path;
    :cond_a
    :goto_1
    nop

    .line 210
    :cond_b
    :goto_2
    const/high16 v5, 0x3f800000    # 1.0f

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 211
    return-void
.end method

.method private drawHorizBarStem(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V
    .locals 20
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I
    .param p4, "topstaff"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 214
    move-object/from16 v0, p0

    move-object/from16 v7, p2

    move-object/from16 v8, p4

    const/high16 v1, 0x40800000    # 4.0f

    invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 215
    sget-object v1, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 216
    const/4 v1, 0x0

    .line 217
    .local v1, "xstart":I
    const/4 v2, 0x0

    .line 218
    .local v2, "xstart2":I
    iget v3, v0, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-ne v3, v5, :cond_0

    .line 219
    const/4 v1, 0x2

    move v9, v1

    goto :goto_0

    .line 220
    :cond_0
    iget v3, v0, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    if-ne v3, v4, :cond_1

    .line 221
    const/16 v1, 0xb

    move v9, v1

    goto :goto_0

    .line 220
    :cond_1
    move v9, v1

    .line 223
    .end local v1    # "xstart":I
    .local v9, "xstart":I
    :goto_0
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->pair:Lnet/duceng/xmidi/widgets/score/Stem;

    iget v1, v1, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    if-ne v1, v5, :cond_2

    .line 224
    const/4 v2, 0x2

    move v10, v2

    goto :goto_1

    .line 225
    :cond_2
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->pair:Lnet/duceng/xmidi/widgets/score/Stem;

    iget v1, v1, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    if-ne v1, v4, :cond_3

    .line 226
    const/16 v2, 0xb

    move v10, v2

    goto :goto_1

    .line 225
    :cond_3
    move v10, v2

    .line 228
    .end local v2    # "xstart2":I
    .local v10, "xstart2":I
    :goto_1
    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    const-wide/high16 v11, 0x3ff0000000000000L    # 1.0

    if-ne v1, v5, :cond_a

    .line 229
    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->width_to_pair:I

    add-int v13, v1, v10

    .line 230
    .local v13, "xend":I
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v8, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v1

    mul-int/lit8 v1, v1, 0x8

    div-int/2addr v1, v4

    add-int v14, p3, v1

    .line 231
    .local v14, "ystart":I
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->pair:Lnet/duceng/xmidi/widgets/score/Stem;

    iget-object v1, v1, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v8, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v1

    mul-int/lit8 v1, v1, 0x8

    div-int/2addr v1, v4

    add-int v15, p3, v1

    .line 232
    .local v15, "yend":I
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v1, v2, :cond_4

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v1, v2, :cond_4

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Triplet:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v1, v2, :cond_4

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v1, v2, :cond_4

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v2, :cond_5

    .line 233
    :cond_4
    int-to-float v2, v9

    int-to-float v3, v14

    int-to-float v4, v13

    int-to-float v5, v15

    move-object/from16 v1, p1

    move-object/from16 v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 235
    :cond_5
    add-int/lit8 v6, v14, 0x8

    .line 236
    .local v6, "ystart2":I
    add-int/lit8 v5, v15, 0x8

    .line 237
    .local v5, "yend2":I
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v2, :cond_6

    .line 238
    add-int/lit8 v4, v13, -0x8

    .line 239
    .local v4, "x":I
    sub-int v1, v5, v6

    int-to-double v1, v1

    mul-double v1, v1, v11

    sub-int v3, v13, v9

    int-to-double v11, v3

    div-double v11, v1, v11

    .line 240
    .local v11, "slope":D
    sub-int v1, v4, v13

    int-to-double v1, v1

    mul-double v1, v1, v11

    move-wide/from16 v16, v11

    .end local v11    # "slope":D
    .local v16, "slope":D
    int-to-double v11, v5

    add-double/2addr v1, v11

    double-to-int v11, v1

    .line 241
    .local v11, "y":I
    int-to-float v2, v4

    int-to-float v3, v11

    int-to-float v12, v13

    int-to-float v1, v5

    move/from16 v18, v1

    move-object/from16 v1, p1

    move/from16 v19, v4

    .end local v4    # "x":I
    .local v19, "x":I
    move v4, v12

    move v12, v5

    .end local v5    # "yend2":I
    .local v12, "yend2":I
    move/from16 v5, v18

    move/from16 v18, v11

    move v11, v6

    .end local v6    # "ystart2":I
    .local v11, "ystart2":I
    .local v18, "y":I
    move-object/from16 v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_2

    .line 237
    .end local v11    # "ystart2":I
    .end local v12    # "yend2":I
    .end local v16    # "slope":D
    .end local v18    # "y":I
    .end local v19    # "x":I
    .restart local v5    # "yend2":I
    .restart local v6    # "ystart2":I
    :cond_6
    move v12, v5

    move v11, v6

    .line 243
    .end local v5    # "yend2":I
    .end local v6    # "ystart2":I
    .restart local v11    # "ystart2":I
    .restart local v12    # "yend2":I
    :goto_2
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v1, v2, :cond_7

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v2, :cond_8

    .line 244
    :cond_7
    int-to-float v2, v9

    int-to-float v3, v11

    int-to-float v4, v13

    int-to-float v5, v12

    move-object/from16 v1, p1

    move-object/from16 v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 246
    :cond_8
    add-int/lit8 v6, v11, 0x8

    .line 247
    .local v6, "ystart3":I
    add-int/lit8 v5, v12, 0x8

    .line 248
    .local v5, "yend3":I
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v2, :cond_9

    .line 249
    int-to-float v2, v9

    int-to-float v3, v6

    int-to-float v4, v13

    int-to-float v1, v5

    move/from16 v16, v1

    move-object/from16 v1, p1

    move/from16 v17, v5

    .end local v5    # "yend3":I
    .local v17, "yend3":I
    move/from16 v5, v16

    move/from16 v16, v6

    .end local v6    # "ystart3":I
    .local v16, "ystart3":I
    move-object/from16 v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_3

    .line 248
    .end local v16    # "ystart3":I
    .end local v17    # "yend3":I
    .restart local v5    # "yend3":I
    .restart local v6    # "ystart3":I
    :cond_9
    move/from16 v17, v5

    move/from16 v16, v6

    .line 251
    .end local v5    # "yend3":I
    .end local v6    # "ystart3":I
    .end local v11    # "ystart2":I
    .end local v12    # "yend2":I
    .end local v13    # "xend":I
    .end local v14    # "ystart":I
    .end local v15    # "yend":I
    :goto_3
    move/from16 v16, v10

    goto/16 :goto_5

    .line 252
    :cond_a
    iget v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->width_to_pair:I

    add-int v13, v1, v10

    .line 253
    .local v13, "xend2":I
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v8, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v1

    mul-int/lit8 v1, v1, 0x8

    div-int/2addr v1, v4

    add-int v1, v1, p3

    add-int/lit8 v14, v1, 0x8

    .line 254
    .local v14, "ystart4":I
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->pair:Lnet/duceng/xmidi/widgets/score/Stem;

    iget-object v1, v1, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v8, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v1

    mul-int/lit8 v1, v1, 0x8

    div-int/2addr v1, v4

    add-int v1, v1, p3

    add-int/lit8 v15, v1, 0x8

    .line 255
    .local v15, "yend4":I
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Eighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v1, v2, :cond_b

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v1, v2, :cond_b

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Triplet:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v1, v2, :cond_b

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v1, v2, :cond_b

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v2, :cond_c

    .line 256
    :cond_b
    int-to-float v2, v9

    int-to-float v3, v14

    int-to-float v4, v13

    int-to-float v5, v15

    move-object/from16 v1, p1

    move-object/from16 v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 258
    :cond_c
    add-int/lit8 v6, v14, -0x8

    .line 259
    .local v6, "ystart5":I
    add-int/lit8 v5, v15, -0x8

    .line 260
    .local v5, "yend5":I
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedEighth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v2, :cond_d

    .line 261
    add-int/lit8 v4, v13, -0x8

    .line 262
    .local v4, "x2":I
    sub-int v1, v5, v6

    int-to-double v1, v1

    mul-double v1, v1, v11

    sub-int v3, v13, v9

    int-to-double v11, v3

    div-double v11, v1, v11

    .line 263
    .local v11, "slope2":D
    sub-int v1, v4, v13

    int-to-double v1, v1

    mul-double v1, v1, v11

    move/from16 v16, v10

    move-wide/from16 v17, v11

    .end local v10    # "xstart2":I
    .end local v11    # "slope2":D
    .local v16, "xstart2":I
    .local v17, "slope2":D
    int-to-double v10, v5

    add-double/2addr v1, v10

    double-to-int v10, v1

    .line 264
    .local v10, "y2":I
    int-to-float v2, v4

    int-to-float v3, v10

    int-to-float v11, v13

    int-to-float v12, v5

    move-object/from16 v1, p1

    move/from16 v19, v4

    .end local v4    # "x2":I
    .local v19, "x2":I
    move v4, v11

    move v11, v5

    .end local v5    # "yend5":I
    .local v11, "yend5":I
    move v5, v12

    move v12, v6

    .end local v6    # "ystart5":I
    .local v12, "ystart5":I
    move-object/from16 v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_4

    .line 260
    .end local v11    # "yend5":I
    .end local v12    # "ystart5":I
    .end local v16    # "xstart2":I
    .end local v17    # "slope2":D
    .end local v19    # "x2":I
    .restart local v5    # "yend5":I
    .restart local v6    # "ystart5":I
    .local v10, "xstart2":I
    :cond_d
    move v11, v5

    move v12, v6

    move/from16 v16, v10

    .line 266
    .end local v5    # "yend5":I
    .end local v6    # "ystart5":I
    .end local v10    # "xstart2":I
    .restart local v11    # "yend5":I
    .restart local v12    # "ystart5":I
    .restart local v16    # "xstart2":I
    :goto_4
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v1, v2, :cond_e

    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v2, :cond_f

    .line 267
    :cond_e
    int-to-float v2, v9

    int-to-float v3, v12

    int-to-float v4, v13

    int-to-float v5, v11

    move-object/from16 v1, p1

    move-object/from16 v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 269
    :cond_f
    add-int/lit8 v10, v12, -0x8

    .line 270
    .local v10, "ystart6":I
    add-int/lit8 v6, v11, -0x8

    .line 271
    .local v6, "yend6":I
    iget-object v1, v0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v2, :cond_10

    .line 272
    int-to-float v2, v9

    int-to-float v3, v10

    int-to-float v4, v13

    int-to-float v5, v6

    move-object/from16 v1, p1

    move/from16 v17, v6

    .end local v6    # "yend6":I
    .local v17, "yend6":I
    move-object/from16 v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_5

    .line 271
    .end local v17    # "yend6":I
    .restart local v6    # "yend6":I
    :cond_10
    move/from16 v17, v6

    .line 275
    .end local v6    # "yend6":I
    .end local v10    # "ystart6":I
    .end local v11    # "yend5":I
    .end local v12    # "ystart5":I
    .end local v13    # "xend2":I
    .end local v14    # "ystart4":I
    .end local v15    # "yend4":I
    :goto_5
    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 276
    return-void
.end method

.method private drawVerticalLine(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V
    .locals 11
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I
    .param p4, "topstaff"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 136
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 137
    const/4 v0, 0x2

    .local v0, "xstart":I
    goto :goto_0

    .line 139
    .end local v0    # "xstart":I
    :cond_0
    const/16 v0, 0xb

    .line 141
    .restart local v0    # "xstart":I
    :goto_0
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    const/4 v3, 0x2

    if-ne v2, v1, :cond_1

    .line 142
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->bottom:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {p4, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v1

    mul-int/lit8 v1, v1, 0x8

    div-int/2addr v1, v3

    add-int/2addr v1, p3

    add-int/2addr v1, v3

    .line 143
    .local v1, "y2":I
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {p4, v2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v2

    mul-int/lit8 v2, v2, 0x8

    div-int/2addr v2, v3

    add-int/2addr v2, p3

    .line 144
    .local v2, "ystem":I
    int-to-float v4, v0

    int-to-float v5, v1

    int-to-float v6, v0

    int-to-float v7, v2

    move-object v3, p1

    move-object v8, p2

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .end local v1    # "y2":I
    .end local v2    # "ystem":I
    goto :goto_2

    .line 145
    :cond_1
    iget v2, p0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    if-ne v2, v3, :cond_3

    .line 146
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/Stem;->top:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {p4, v2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v2

    mul-int/lit8 v2, v2, 0x8

    div-int/2addr v2, v3

    add-int/2addr v2, p3

    add-int/lit8 v2, v2, 0x6

    .line 147
    .local v2, "y3":I
    iget v4, p0, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    if-ne v4, v1, :cond_2

    .line 148
    add-int/lit8 v1, v2, -0x2

    .local v1, "y1":I
    goto :goto_1

    .line 150
    .end local v1    # "y1":I
    :cond_2
    add-int/lit8 v1, v2, -0x4

    .line 152
    .restart local v1    # "y1":I
    :goto_1
    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {p4, v4}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v4

    mul-int/lit8 v4, v4, 0x8

    div-int/2addr v4, v3

    add-int/2addr v4, p3

    add-int/lit8 v4, v4, 0x8

    .line 153
    .local v4, "ystem2":I
    int-to-float v6, v0

    int-to-float v7, v1

    int-to-float v8, v0

    int-to-float v9, v4

    move-object v5, p1

    move-object v10, p2

    invoke-virtual/range {v5 .. v10}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_3

    .line 145
    .end local v1    # "y1":I
    .end local v2    # "y3":I
    .end local v4    # "ystem2":I
    :cond_3
    :goto_2
    nop

    .line 155
    :goto_3
    return-void
.end method


# virtual methods
.method public CalculateEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .locals 4

    .line 78
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-ne v0, v1, :cond_2

    .line 79
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->top:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    const/4 v1, 0x6

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    .line 80
    .local v0, "w":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v3, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v3, :cond_0

    .line 81
    invoke-virtual {v0, v2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    return-object v1

    .line 83
    :cond_0
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v2, :cond_1

    .line 84
    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    return-object v1

    .line 86
    :cond_1
    return-object v0

    .line 88
    .end local v0    # "w":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :cond_2
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    if-ne v0, v2, :cond_5

    .line 89
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->bottom:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    const/4 v1, -0x6

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    .line 90
    .local v0, "w2":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Sixteenth:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v2, :cond_3

    .line 91
    const/4 v1, -0x2

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    return-object v1

    .line 93
    :cond_3
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v2, Lnet/duceng/xmidi/widgets/score/NoteDuration;->ThirtySecond:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-ne v1, v2, :cond_4

    .line 94
    const/4 v1, -0x4

    invoke-virtual {v0, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v1

    return-object v1

    .line 96
    :cond_4
    return-object v0

    .line 98
    .end local v0    # "w2":Lnet/duceng/xmidi/widgets/score/WhiteNote;
    :cond_5
    const/4 v0, 0x0

    return-object v0
.end method

.method public ChangeDirection(I)V
    .locals 2
    .param p1, "newdirection"    # I

    .line 102
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    .line 103
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->notesoverlap:Z

    if-eqz v0, :cond_0

    goto :goto_0

    .line 106
    :cond_0
    iput v1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    goto :goto_1

    .line 104
    :cond_1
    :goto_0
    const/4 v0, 0x2

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    .line 108
    :goto_1
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/Stem;->CalculateEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;

    move-result-object v0

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 109
    return-void
.end method

.method public IsBeam()Z
    .locals 1

    .line 117
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->receiver_in_pair:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->pair:Lnet/duceng/xmidi/widgets/score/Stem;

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method public SetPair(Lnet/duceng/xmidi/widgets/score/Stem;I)V
    .locals 0
    .param p1, "pair"    # Lnet/duceng/xmidi/widgets/score/Stem;
    .param p2, "width_to_pair"    # I

    .line 112
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->pair:Lnet/duceng/xmidi/widgets/score/Stem;

    .line 113
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/Stem;->width_to_pair:I

    .line 114
    return-void
.end method

.method public draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V
    .locals 2
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I
    .param p4, "topstaff"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 121
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Whole:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v0, v1, :cond_1

    .line 122
    invoke-direct {p0, p1, p2, p3, p4}, Lnet/duceng/xmidi/widgets/score/Stem;->drawVerticalLine(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 123
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Quarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedQuarter:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->Half:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    sget-object v1, Lnet/duceng/xmidi/widgets/score/NoteDuration;->DottedHalf:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    if-eq v0, v1, :cond_1

    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->receiver_in_pair:Z

    if-nez v0, :cond_1

    .line 124
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->pair:Lnet/duceng/xmidi/widgets/score/Stem;

    if-eqz v0, :cond_0

    .line 125
    invoke-direct {p0, p1, p2, p3, p4}, Lnet/duceng/xmidi/widgets/score/Stem;->drawHorizBarStem(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V

    goto :goto_0

    .line 127
    :cond_0
    invoke-direct {p0, p1, p2, p3, p4}, Lnet/duceng/xmidi/widgets/score/Stem;->drawCurvyStem(Landroid/graphics/Canvas;Landroid/graphics/Paint;ILnet/duceng/xmidi/widgets/score/WhiteNote;)V

    .line 131
    :cond_1
    :goto_0
    return-void
.end method

.method public getBottom()Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .locals 1

    .line 41
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->bottom:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    return-object v0
.end method

.method public getDirection()I
    .locals 1

    .line 25
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    return v0
.end method

.method public getDuration()Lnet/duceng/xmidi/widgets/score/NoteDuration;
    .locals 1

    .line 33
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    return-object v0
.end method

.method public getEnd()Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .locals 1

    .line 45
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    return-object v0
.end method

.method public getReceiver()Z
    .locals 1

    .line 53
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->receiver_in_pair:Z

    return v0
.end method

.method public getTop()Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .locals 1

    .line 37
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->top:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    return-object v0
.end method

.method public setDirection(I)V
    .locals 0
    .param p1, "value"    # I

    .line 29
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/widgets/score/Stem;->ChangeDirection(I)V

    .line 30
    return-void
.end method

.method public setEnd(Lnet/duceng/xmidi/widgets/score/WhiteNote;)V
    .locals 0
    .param p1, "value"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 49
    iput-object p1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 50
    return-void
.end method

.method public setReceiver(Z)V
    .locals 0
    .param p1, "value"    # Z

    .line 57
    iput-boolean p1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->receiver_in_pair:Z

    .line 58
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 11

    .line 279
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/Stem;->duration:Lnet/duceng/xmidi/widgets/score/NoteDuration;

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/Stem;->direction:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/Stem;->top:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->toString()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lnet/duceng/xmidi/widgets/score/Stem;->bottom:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lnet/duceng/xmidi/widgets/score/Stem;->end:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {v4}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->toString()Ljava/lang/String;

    move-result-object v4

    iget-boolean v5, p0, Lnet/duceng/xmidi/widgets/score/Stem;->notesoverlap:Z

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    iget v6, p0, Lnet/duceng/xmidi/widgets/score/Stem;->side:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    iget v7, p0, Lnet/duceng/xmidi/widgets/score/Stem;->width_to_pair:I

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    iget-boolean v8, p0, Lnet/duceng/xmidi/widgets/score/Stem;->receiver_in_pair:Z

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    const/16 v9, 0x9

    new-array v9, v9, [Ljava/lang/Object;

    const/4 v10, 0x0

    aput-object v0, v9, v10

    const/4 v0, 0x1

    aput-object v1, v9, v0

    const/4 v0, 0x2

    aput-object v2, v9, v0

    const/4 v0, 0x3

    aput-object v3, v9, v0

    const/4 v0, 0x4

    aput-object v4, v9, v0

    const/4 v0, 0x5

    aput-object v5, v9, v0

    const/4 v0, 0x6

    aput-object v6, v9, v0

    const/4 v0, 0x7

    aput-object v7, v9, v0

    const/16 v0, 0x8

    aput-object v8, v9, v0

    const-string v0, "Stem duration=%1$s direction=%2$s top=%3$s bottom=%4$s end=%5$s overlap=%6$s side=%7$s width_to_pair=%8$s receiver_in_pair=%9$s"

    invoke-static {v0, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
