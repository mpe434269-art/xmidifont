.class public Lnet/duceng/xmidi/widgets/score/SymbolWidths;
.super Ljava/lang/Object;
.source "SymbolWidths.java"


# instance fields
.field private maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

.field private starttimes:[I

.field private widths:[Lnet/duceng/xmidi/widgets/score/DictInt;


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;>;",
            "Ljava/util/ArrayList<",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/LyricSymbol;",
            ">;>;)V"
        }
    .end annotation

    .line 12
    .local p1, "tracks":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;>;"
    .local p2, "tracklyrics":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/LyricSymbol;>;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    new-array v0, v0, [Lnet/duceng/xmidi/widgets/score/DictInt;

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->widths:[Lnet/duceng/xmidi/widgets/score/DictInt;

    .line 14
    const/4 v0, 0x0

    .local v0, "track":I
    :goto_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    .line 15
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->widths:[Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/ArrayList;

    invoke-static {v2}, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->GetTrackWidths(Ljava/util/ArrayList;)Lnet/duceng/xmidi/widgets/score/DictInt;

    move-result-object v2

    aput-object v2, v1, v0

    .line 14
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 17
    .end local v0    # "track":I
    :cond_0
    new-instance v0, Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-direct {v0}, Lnet/duceng/xmidi/widgets/score/DictInt;-><init>()V

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    .line 18
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->widths:[Lnet/duceng/xmidi/widgets/score/DictInt;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_1
    if-ge v2, v1, :cond_4

    aget-object v3, v0, v2

    .line 19
    .local v3, "dict":Lnet/duceng/xmidi/widgets/score/DictInt;
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_2
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/DictInt;->count()I

    move-result v5

    if-ge v4, v5, :cond_3

    .line 20
    invoke-virtual {v3, v4}, Lnet/duceng/xmidi/widgets/score/DictInt;->getKey(I)I

    move-result v5

    .line 21
    .local v5, "time":I
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {v6, v5}, Lnet/duceng/xmidi/widgets/score/DictInt;->contains(I)Z

    move-result v6

    if-eqz v6, :cond_1

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {v6, v5}, Lnet/duceng/xmidi/widgets/score/DictInt;->get(I)I

    move-result v6

    invoke-virtual {v3, v5}, Lnet/duceng/xmidi/widgets/score/DictInt;->get(I)I

    move-result v7

    if-ge v6, v7, :cond_2

    .line 22
    :cond_1
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {v3, v5}, Lnet/duceng/xmidi/widgets/score/DictInt;->get(I)I

    move-result v7

    invoke-virtual {v6, v5, v7}, Lnet/duceng/xmidi/widgets/score/DictInt;->set(II)V

    .line 19
    .end local v5    # "time":I
    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    .line 18
    .end local v3    # "dict":Lnet/duceng/xmidi/widgets/score/DictInt;
    .end local v4    # "i":I
    :cond_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 26
    :cond_4
    if-eqz p2, :cond_8

    .line 27
    invoke-virtual {p2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    .line 28
    .local v1, "lyrics":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/LyricSymbol;>;"
    if-eqz v1, :cond_7

    .line 29
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_7

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/xmidi/widgets/score/LyricSymbol;

    .line 30
    .local v3, "lyric":Lnet/duceng/xmidi/widgets/score/LyricSymbol;
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->getMinWidth()I

    move-result v4

    .line 31
    .local v4, "width":I
    invoke-virtual {v3}, Lnet/duceng/xmidi/widgets/score/LyricSymbol;->getStartTime()I

    move-result v5

    .line 32
    .local v5, "time2":I
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {v6, v5}, Lnet/duceng/xmidi/widgets/score/DictInt;->contains(I)Z

    move-result v6

    if-eqz v6, :cond_5

    iget-object v6, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {v6, v5}, Lnet/duceng/xmidi/widgets/score/DictInt;->get(I)I

    move-result v6

    if-ge v6, v4, :cond_6

    .line 33
    :cond_5
    iget-object v6, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {v6, v5, v4}, Lnet/duceng/xmidi/widgets/score/DictInt;->set(II)V

    .line 35
    .end local v3    # "lyric":Lnet/duceng/xmidi/widgets/score/LyricSymbol;
    .end local v4    # "width":I
    .end local v5    # "time2":I
    :cond_6
    goto :goto_4

    .line 37
    .end local v1    # "lyrics":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/LyricSymbol;>;"
    :cond_7
    goto :goto_3

    .line 39
    :cond_8
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {v0}, Lnet/duceng/xmidi/widgets/score/DictInt;->count()I

    move-result v0

    new-array v0, v0, [I

    iput-object v0, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->starttimes:[I

    .line 40
    const/4 v0, 0x0

    .local v0, "i2":I
    :goto_5
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {v1}, Lnet/duceng/xmidi/widgets/score/DictInt;->count()I

    move-result v1

    if-ge v0, v1, :cond_9

    .line 41
    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {v1, v0}, Lnet/duceng/xmidi/widgets/score/DictInt;->getKey(I)I

    move-result v1

    .line 42
    .local v1, "key":I
    iget-object v2, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->starttimes:[I

    aput v1, v2, v0

    .line 40
    .end local v1    # "key":I
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    .line 44
    .end local v0    # "i2":I
    :cond_9
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->starttimes:[I

    invoke-static {v0}, Ljava/util/Arrays;->sort([I)V

    .line 45
    return-void
.end method

.method private static GetTrackWidths(Ljava/util/ArrayList;)Lnet/duceng/xmidi/widgets/score/DictInt;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/xmidi/widgets/score/MusicSymbol;",
            ">;)",
            "Lnet/duceng/xmidi/widgets/score/DictInt;"
        }
    .end annotation

    .line 48
    .local p0, "symbols":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/xmidi/widgets/score/MusicSymbol;>;"
    new-instance v0, Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-direct {v0}, Lnet/duceng/xmidi/widgets/score/DictInt;-><init>()V

    .line 49
    .local v0, "widths":Lnet/duceng/xmidi/widgets/score/DictInt;
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/xmidi/widgets/score/MusicSymbol;

    .line 50
    .local v2, "m":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    invoke-interface {v2}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getStartTime()I

    move-result v3

    .line 51
    .local v3, "start":I
    invoke-interface {v2}, Lnet/duceng/xmidi/widgets/score/MusicSymbol;->getMinWidth()I

    move-result v4

    .line 52
    .local v4, "w":I
    instance-of v5, v2, Lnet/duceng/xmidi/widgets/score/BarSymbol;

    if-nez v5, :cond_1

    .line 53
    invoke-virtual {v0, v3}, Lnet/duceng/xmidi/widgets/score/DictInt;->contains(I)Z

    move-result v5

    if-eqz v5, :cond_0

    .line 54
    invoke-virtual {v0, v3}, Lnet/duceng/xmidi/widgets/score/DictInt;->get(I)I

    move-result v5

    add-int/2addr v5, v4

    invoke-virtual {v0, v3, v5}, Lnet/duceng/xmidi/widgets/score/DictInt;->set(II)V

    goto :goto_1

    .line 56
    :cond_0
    invoke-virtual {v0, v3, v4}, Lnet/duceng/xmidi/widgets/score/DictInt;->set(II)V

    .line 59
    .end local v2    # "m":Lnet/duceng/xmidi/widgets/score/MusicSymbol;
    .end local v3    # "start":I
    .end local v4    # "w":I
    :cond_1
    :goto_1
    goto :goto_0

    .line 60
    :cond_2
    return-object v0
.end method


# virtual methods
.method public GetExtraWidth(II)I
    .locals 2
    .param p1, "track"    # I
    .param p2, "start"    # I

    .line 64
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->widths:[Lnet/duceng/xmidi/widgets/score/DictInt;

    aget-object v0, v0, p1

    invoke-virtual {v0, p2}, Lnet/duceng/xmidi/widgets/score/DictInt;->contains(I)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {v0, p2}, Lnet/duceng/xmidi/widgets/score/DictInt;->get(I)I

    move-result v0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->maxwidths:Lnet/duceng/xmidi/widgets/score/DictInt;

    invoke-virtual {v0, p2}, Lnet/duceng/xmidi/widgets/score/DictInt;->get(I)I

    move-result v0

    iget-object v1, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->widths:[Lnet/duceng/xmidi/widgets/score/DictInt;

    aget-object v1, v1, p1

    invoke-virtual {v1, p2}, Lnet/duceng/xmidi/widgets/score/DictInt;->get(I)I

    move-result v1

    sub-int/2addr v0, v1

    :goto_0
    return v0
.end method

.method public getStartTimes()[I
    .locals 1

    .line 68
    iget-object v0, p0, Lnet/duceng/xmidi/widgets/score/SymbolWidths;->starttimes:[I

    return-object v0
.end method
