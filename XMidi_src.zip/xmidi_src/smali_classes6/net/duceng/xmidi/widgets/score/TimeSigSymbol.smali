.class public Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;
.super Ljava/lang/Object;
.source "TimeSigSymbol.java"

# interfaces
.implements Lnet/duceng/xmidi/widgets/score/MusicSymbol;


# static fields
.field private static images:[Landroid/graphics/Bitmap;


# instance fields
.field private candraw:Z

.field private denominator:I

.field private numerator:I

.field private width:I


# direct methods
.method public constructor <init>(II)V
    .locals 2
    .param p1, "numer"    # I
    .param p2, "denom"    # I

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    sget-object v0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    if-eqz v0, :cond_1

    .line 25
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->numerator:I

    .line 26
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->denominator:I

    .line 27
    if-ltz p1, :cond_0

    sget-object v0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    array-length v0, v0

    if-ge p1, v0, :cond_0

    sget-object v0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    aget-object v0, v0, p1

    if-eqz v0, :cond_0

    if-ltz p2, :cond_0

    sget-object v0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    array-length v0, v0

    if-ge p2, v0, :cond_0

    sget-object v0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    aget-object v0, v0, p1

    if-eqz v0, :cond_0

    .line 28
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->candraw:Z

    goto :goto_0

    .line 30
    :cond_0
    const/4 v0, 0x0

    iput-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->candraw:Z

    .line 32
    :goto_0
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->getMinWidth()I

    move-result v0

    iput v0, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->width:I

    .line 33
    return-void

    .line 23
    :cond_1
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "TimeSigSymbol.LoadImages(Context) will be call first!"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static LoadImages(Landroid/content/Context;)V
    .locals 4
    .param p0, "context"    # Landroid/content/Context;

    .line 36
    sget-object v0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    if-nez v0, :cond_0

    .line 37
    const/16 v0, 0xd

    new-array v0, v0, [Landroid/graphics/Bitmap;

    sput-object v0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    .line 38
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    .line 39
    .local v0, "res":Landroid/content/res/Resources;
    sget-object v1, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    const v2, 0x7f030050

    invoke-static {v0, v2}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v3, 0x2

    aput-object v2, v1, v3

    .line 40
    sget-object v1, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    const v2, 0x7f030051

    invoke-static {v0, v2}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v3, 0x3

    aput-object v2, v1, v3

    .line 41
    sget-object v1, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    const v2, 0x7f030052

    invoke-static {v0, v2}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v3, 0x4

    aput-object v2, v1, v3

    .line 42
    sget-object v1, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    const v2, 0x7f030054

    invoke-static {v0, v2}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v3, 0x6

    aput-object v2, v1, v3

    .line 43
    sget-object v1, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    const v2, 0x7f030056

    invoke-static {v0, v2}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v2

    const/16 v3, 0x8

    aput-object v2, v1, v3

    .line 44
    sget-object v1, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    const v2, 0x7f030057

    invoke-static {v0, v2}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v2

    const/16 v3, 0x9

    aput-object v2, v1, v3

    .line 45
    sget-object v1, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    const v2, 0x7f03004f

    invoke-static {v0, v2}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v2

    const/16 v3, 0xc

    aput-object v2, v1, v3

    .line 47
    .end local v0    # "res":Landroid/content/res/Resources;
    :cond_0
    return-void
.end method

.method public static textAsBitmap(Ljava/lang/String;FI)Landroid/graphics/Bitmap;
    .locals 5
    .param p0, "text"    # Ljava/lang/String;
    .param p1, "textSize"    # F
    .param p2, "textColor"    # I

    .line 50
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    .line 51
    .local v0, "paint":Landroid/graphics/Paint;
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 52
    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 53
    sget-object v1, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 54
    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 55
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 56
    sget-object v1, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 57
    invoke-virtual {v0}, Landroid/graphics/Paint;->ascent()F

    move-result v1

    neg-float v1, v1

    const/high16 v2, 0x3f000000    # 0.5f

    add-float/2addr v1, v2

    float-to-int v1, v1

    int-to-float v1, v1

    .line 58
    .local v1, "baseline":F
    const/16 v2, 0x30

    sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v2, v2, v3}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 59
    .local v2, "image":Landroid/graphics/Bitmap;
    new-instance v3, Landroid/graphics/Canvas;

    invoke-direct {v3, v2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 60
    .local v3, "canvas":Landroid/graphics/Canvas;
    const/4 v4, 0x0

    invoke-virtual {v3, p0, v4, v1, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 61
    return-object v2
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;Landroid/graphics/Paint;I)V
    .locals 12
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "paint"    # Landroid/graphics/Paint;
    .param p3, "ytop"    # I

    .line 99
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->candraw:Z

    if-eqz v0, :cond_0

    .line 100
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->getMinWidth()I

    move-result v1

    sub-int/2addr v0, v1

    int-to-float v0, v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 101
    sget-object v0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->numerator:I

    aget-object v0, v0, v2

    .line 102
    .local v0, "numer":Landroid/graphics/Bitmap;
    sget-object v2, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    iget v3, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->denominator:I

    aget-object v2, v2, v3

    .line 103
    .local v2, "denom":Landroid/graphics/Bitmap;
    add-int/lit8 v3, p3, -0x1

    .line 104
    .local v3, "ytop2":I
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v4

    mul-int/lit8 v4, v4, 0x10

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    div-int/2addr v4, v5

    .line 105
    .local v4, "imgwidth":I
    new-instance v5, Landroid/graphics/Rect;

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v6

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v7

    const/4 v8, 0x0

    invoke-direct {v5, v8, v8, v6, v7}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 106
    .local v5, "src":Landroid/graphics/Rect;
    new-instance v6, Landroid/graphics/Rect;

    add-int/lit8 v7, v3, 0x10

    invoke-direct {v6, v8, v3, v4, v7}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 107
    .local v6, "dest":Landroid/graphics/Rect;
    invoke-virtual {p1, v0, v5, v6, p2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 108
    new-instance v7, Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v9

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v10

    invoke-direct {v7, v8, v8, v9, v10}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 109
    .local v7, "src2":Landroid/graphics/Rect;
    new-instance v9, Landroid/graphics/Rect;

    add-int/lit8 v10, v3, 0x10

    add-int/lit8 v11, v3, 0x10

    add-int/lit8 v11, v11, 0x10

    invoke-direct {v9, v8, v10, v4, v11}, Landroid/graphics/Rect;-><init>(IIII)V

    move-object v8, v9

    .line 110
    .local v8, "dest2":Landroid/graphics/Rect;
    invoke-virtual {p1, v2, v7, v8, p2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 111
    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->getWidth()I

    move-result v9

    invoke-virtual {p0}, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->getMinWidth()I

    move-result v10

    sub-int/2addr v9, v10

    neg-int v9, v9

    int-to-float v9, v9

    invoke-virtual {p1, v9, v1}, Landroid/graphics/Canvas;->translate(FF)V

    .line 113
    .end local v0    # "numer":Landroid/graphics/Bitmap;
    .end local v2    # "denom":Landroid/graphics/Bitmap;
    .end local v3    # "ytop2":I
    .end local v4    # "imgwidth":I
    .end local v5    # "src":Landroid/graphics/Rect;
    .end local v6    # "dest":Landroid/graphics/Rect;
    .end local v7    # "src2":Landroid/graphics/Rect;
    .end local v8    # "dest2":Landroid/graphics/Rect;
    :cond_0
    return-void
.end method

.method public getAboveStaff()I
    .locals 1

    .line 89
    const/4 v0, 0x0

    return v0
.end method

.method public getBelowStaff()I
    .locals 1

    .line 94
    const/4 v0, 0x0

    return v0
.end method

.method public getMinWidth()I
    .locals 3

    .line 71
    iget-boolean v0, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->candraw:Z

    if-eqz v0, :cond_0

    .line 72
    sget-object v0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    const/4 v1, 0x2

    aget-object v0, v0, v1

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    mul-int/lit8 v0, v0, 0x8

    mul-int/lit8 v0, v0, 0x2

    sget-object v2, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->images:[Landroid/graphics/Bitmap;

    aget-object v1, v2, v1

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    div-int/2addr v0, v1

    return v0

    .line 74
    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public getStartTime()I
    .locals 1

    .line 66
    const/4 v0, -0x1

    return v0
.end method

.method public getWidth()I
    .locals 1

    .line 79
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->width:I

    return v0
.end method

.method public setWidth(I)V
    .locals 0
    .param p1, "value"    # I

    .line 84
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->width:I

    .line 85
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 116
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->numerator:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/TimeSigSymbol;->denominator:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v3, 0x0

    aput-object v0, v2, v3

    const/4 v0, 0x1

    aput-object v1, v2, v0

    const-string v0, "TimeSigSymbol numerator=%1$s denominator=%2$s"

    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
