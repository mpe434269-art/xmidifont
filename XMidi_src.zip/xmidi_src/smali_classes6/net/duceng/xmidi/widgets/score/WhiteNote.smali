.class public Lnet/duceng/xmidi/widgets/score/WhiteNote;
.super Ljava/lang/Object;
.source "WhiteNote.java"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lnet/duceng/xmidi/widgets/score/WhiteNote;",
        ">;"
    }
.end annotation


# static fields
.field public static final A:I = 0x0

.field public static final B:I = 0x1

.field public static BottomBass:Lnet/duceng/xmidi/widgets/score/WhiteNote; = null

.field public static BottomTreble:Lnet/duceng/xmidi/widgets/score/WhiteNote; = null

.field public static final C:I = 0x2

.field public static final D:I = 0x3

.field public static final E:I = 0x4

.field public static final F:I = 0x5

.field public static final G:I = 0x6

.field public static MiddleC:Lnet/duceng/xmidi/widgets/score/WhiteNote;

.field public static TopBass:Lnet/duceng/xmidi/widgets/score/WhiteNote;

.field public static TopTreble:Lnet/duceng/xmidi/widgets/score/WhiteNote;


# instance fields
.field private letter:I

.field private octave:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 16
    new-instance v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->TopTreble:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 17
    new-instance v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-direct {v0, v2, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->BottomTreble:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 18
    new-instance v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0, v2, v3}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->TopBass:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 19
    new-instance v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    const/4 v2, 0x0

    invoke-direct {v0, v2, v3}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->BottomBass:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 20
    new-instance v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    const/4 v2, 0x2

    invoke-direct {v0, v2, v1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    sput-object v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->MiddleC:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    return-void
.end method

.method public constructor <init>(II)V
    .locals 1
    .param p1, "letter"    # I
    .param p2, "octave"    # I

    .line 30
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 31
    if-ltz p1, :cond_0

    const/4 v0, 0x6

    if-gt p1, v0, :cond_0

    .line 34
    iput p1, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->letter:I

    .line 35
    iput p2, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->octave:I

    .line 36
    return-void

    .line 32
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v0
.end method

.method public static Bottom(Lnet/duceng/xmidi/widgets/score/Clef;)Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .locals 1
    .param p0, "clef"    # Lnet/duceng/xmidi/widgets/score/Clef;

    .line 99
    sget-object v0, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    if-ne p0, v0, :cond_0

    sget-object v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->BottomTreble:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    goto :goto_0

    :cond_0
    sget-object v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->BottomBass:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    :goto_0
    return-object v0
.end method

.method public static Max(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .locals 1
    .param p0, "x"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .param p1, "y"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 87
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v0

    if-lez v0, :cond_0

    move-object v0, p0

    goto :goto_0

    :cond_0
    move-object v0, p1

    :goto_0
    return-object v0
.end method

.method public static Min(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .locals 1
    .param p0, "x"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .param p1, "y"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 91
    invoke-virtual {p0, p1}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v0

    if-gez v0, :cond_0

    move-object v0, p0

    goto :goto_0

    :cond_0
    move-object v0, p1

    :goto_0
    return-object v0
.end method

.method public static Top(Lnet/duceng/xmidi/widgets/score/Clef;)Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .locals 1
    .param p0, "clef"    # Lnet/duceng/xmidi/widgets/score/Clef;

    .line 95
    sget-object v0, Lnet/duceng/xmidi/widgets/score/Clef;->Treble:Lnet/duceng/xmidi/widgets/score/Clef;

    if-ne p0, v0, :cond_0

    sget-object v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->TopTreble:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    goto :goto_0

    :cond_0
    sget-object v0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->TopBass:Lnet/duceng/xmidi/widgets/score/WhiteNote;

    :goto_0
    return-object v0
.end method


# virtual methods
.method public Add(I)Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .locals 4
    .param p1, "amount"    # I

    .line 43
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->octave:I

    mul-int/lit8 v0, v0, 0x7

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->letter:I

    add-int/2addr v0, v1

    add-int/2addr v0, p1

    .line 44
    .local v0, "num":I
    if-gez v0, :cond_0

    .line 45
    const/4 v0, 0x0

    .line 47
    :cond_0
    new-instance v1, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    rem-int/lit8 v2, v0, 0x7

    div-int/lit8 v3, v0, 0x7

    invoke-direct {v1, v2, v3}, Lnet/duceng/xmidi/widgets/score/WhiteNote;-><init>(II)V

    return-object v1
.end method

.method public Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I
    .locals 3
    .param p1, "w"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 39
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->octave:I

    iget v1, p1, Lnet/duceng/xmidi/widgets/score/WhiteNote;->octave:I

    sub-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x7

    iget v1, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->letter:I

    iget v2, p1, Lnet/duceng/xmidi/widgets/score/WhiteNote;->letter:I

    sub-int/2addr v1, v2

    add-int/2addr v0, v1

    return v0
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    .line 6
    check-cast p1, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    check-cast p2, Lnet/duceng/xmidi/widgets/score/WhiteNote;

    invoke-virtual {p0, p1, p2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->compare(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result p1

    return p1
.end method

.method public compare(Lnet/duceng/xmidi/widgets/score/WhiteNote;Lnet/duceng/xmidi/widgets/score/WhiteNote;)I
    .locals 1
    .param p1, "x"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;
    .param p2, "y"    # Lnet/duceng/xmidi/widgets/score/WhiteNote;

    .line 83
    invoke-virtual {p1, p2}, Lnet/duceng/xmidi/widgets/score/WhiteNote;->Dist(Lnet/duceng/xmidi/widgets/score/WhiteNote;)I

    move-result v0

    return v0
.end method

.method public getLetter()I
    .locals 1

    .line 23
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->letter:I

    return v0
.end method

.method public getNumber()I
    .locals 2

    .line 52
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->letter:I

    packed-switch v0, :pswitch_data_0

    .line 75
    const/4 v0, 0x0

    .local v0, "offset":I
    goto :goto_0

    .line 72
    .end local v0    # "offset":I
    :pswitch_0
    const/16 v0, 0xa

    .line 73
    .restart local v0    # "offset":I
    goto :goto_0

    .line 69
    .end local v0    # "offset":I
    :pswitch_1
    const/16 v0, 0x8

    .line 70
    .restart local v0    # "offset":I
    goto :goto_0

    .line 66
    .end local v0    # "offset":I
    :pswitch_2
    const/4 v0, 0x7

    .line 67
    .restart local v0    # "offset":I
    goto :goto_0

    .line 63
    .end local v0    # "offset":I
    :pswitch_3
    const/4 v0, 0x5

    .line 64
    .restart local v0    # "offset":I
    goto :goto_0

    .line 60
    .end local v0    # "offset":I
    :pswitch_4
    const/4 v0, 0x3

    .line 61
    .restart local v0    # "offset":I
    goto :goto_0

    .line 57
    .end local v0    # "offset":I
    :pswitch_5
    const/4 v0, 0x2

    .line 58
    .restart local v0    # "offset":I
    goto :goto_0

    .line 54
    .end local v0    # "offset":I
    :pswitch_6
    const/4 v0, 0x0

    .line 55
    .restart local v0    # "offset":I
    nop

    .line 78
    :goto_0
    iget v1, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->octave:I

    invoke-static {v0, v1}, Lnet/duceng/xmidi/widgets/score/NoteScale;->ToNumber(II)I

    move-result v1

    return v1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public getOctave()I
    .locals 1

    .line 27
    iget v0, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->octave:I

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 7

    .line 103
    const-string v5, "F"

    const-string v6, "G"

    const-string v0, "A"

    const-string v1, "B"

    const-string v2, "C"

    const-string v3, "D"

    const-string v4, "E"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v0

    .line 104
    .local v0, "s":[Ljava/lang/String;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->letter:I

    aget-object v2, v0, v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p0, Lnet/duceng/xmidi/widgets/score/WhiteNote;->octave:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method
