.class public Lnet/duceng/midi/EventChannel;
.super Lnet/duceng/midi/MidiEvent;
.source "EventChannel.java"


# static fields
.field public static final CHANNEL_AFTERTOUCH:B = 0xdt

.field public static final CONTROLLER:B = 0xbt

.field public static final NOTE_AFTERTOUCH:B = 0xat

.field public static final NOTE_OFF:B = 0x8t

.field public static final NOTE_ON:B = 0x9t

.field public static final PITCH_BEND:B = 0xet

.field public static final PROGRAM_CHANGE:B = 0xct


# instance fields
.field public carry:B

.field protected channel:B

.field protected type:B

.field protected value1:B

.field protected value2:B


# direct methods
.method public constructor <init>(IBBBB)V
    .locals 7
    .param p1, "t"    # I
    .param p2, "tp"    # B
    .param p3, "ch"    # B
    .param p4, "v1"    # B
    .param p5, "v2"    # B

    .line 31
    const/4 v2, 0x0

    move-object v0, p0

    move v1, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move v6, p5

    invoke-direct/range {v0 .. v6}, Lnet/duceng/midi/EventChannel;-><init>(IIBBBB)V

    .line 32
    return-void
.end method

.method protected constructor <init>(IIBBBB)V
    .locals 1
    .param p1, "t"    # I
    .param p2, "d"    # I
    .param p3, "tp"    # B
    .param p4, "ch"    # B
    .param p5, "v1"    # B
    .param p6, "v2"    # B

    .line 23
    invoke-direct {p0, p1, p2}, Lnet/duceng/midi/MidiEvent;-><init>(II)V

    .line 17
    const/4 v0, 0x0

    iput-byte v0, p0, Lnet/duceng/midi/EventChannel;->carry:B

    .line 24
    iput-byte p3, p0, Lnet/duceng/midi/EventChannel;->type:B

    .line 25
    iput-byte p4, p0, Lnet/duceng/midi/EventChannel;->channel:B

    .line 26
    iput-byte p5, p0, Lnet/duceng/midi/EventChannel;->value1:B

    .line 27
    iput-byte p6, p0, Lnet/duceng/midi/EventChannel;->value2:B

    .line 28
    return-void
.end method


# virtual methods
.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    .line 7
    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->clone()Lnet/duceng/midi/EventChannel;

    move-result-object v0

    return-object v0
.end method

.method public clone()Lnet/duceng/midi/EventChannel;
    .locals 8

    .line 119
    new-instance v7, Lnet/duceng/midi/EventChannel;

    iget v1, p0, Lnet/duceng/midi/EventChannel;->tick:I

    iget v2, p0, Lnet/duceng/midi/EventChannel;->delta:I

    iget-byte v3, p0, Lnet/duceng/midi/EventChannel;->type:B

    iget-byte v4, p0, Lnet/duceng/midi/EventChannel;->channel:B

    iget-byte v5, p0, Lnet/duceng/midi/EventChannel;->value1:B

    iget-byte v6, p0, Lnet/duceng/midi/EventChannel;->value2:B

    move-object v0, v7

    invoke-direct/range {v0 .. v6}, Lnet/duceng/midi/EventChannel;-><init>(IIBBBB)V

    .line 120
    .local v0, "c":Lnet/duceng/midi/EventChannel;
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->carry:B

    iput-byte v1, v0, Lnet/duceng/midi/EventChannel;->carry:B

    .line 121
    return-object v0
.end method

.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .locals 0

    .line 7
    check-cast p1, Lnet/duceng/midi/MidiEvent;

    invoke-virtual {p0, p1}, Lnet/duceng/midi/EventChannel;->compareTo(Lnet/duceng/midi/MidiEvent;)I

    move-result p1

    return p1
.end method

.method public compareTo(Lnet/duceng/midi/MidiEvent;)I
    .locals 5
    .param p1, "other"    # Lnet/duceng/midi/MidiEvent;

    .line 85
    iget v0, p0, Lnet/duceng/midi/EventChannel;->tick:I

    iget v1, p1, Lnet/duceng/midi/MidiEvent;->tick:I

    const/4 v2, -0x1

    const/4 v3, 0x1

    if-eq v0, v1, :cond_1

    .line 86
    iget v0, p0, Lnet/duceng/midi/EventChannel;->tick:I

    iget v1, p1, Lnet/duceng/midi/MidiEvent;->tick:I

    if-ge v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    :goto_0
    return v2

    .line 88
    :cond_1
    iget v0, p0, Lnet/duceng/midi/EventChannel;->delta:I

    iget v1, p1, Lnet/duceng/midi/MidiEvent;->delta:I

    if-eq v0, v1, :cond_3

    .line 89
    iget v0, p0, Lnet/duceng/midi/EventChannel;->delta:I

    iget v1, p1, Lnet/duceng/midi/MidiEvent;->delta:I

    if-lt v0, v1, :cond_2

    goto :goto_1

    :cond_2
    const/4 v2, 0x1

    :goto_1
    return v2

    .line 91
    :cond_3
    instance-of v0, p1, Lnet/duceng/midi/EventChannel;

    if-nez v0, :cond_4

    .line 92
    return v3

    .line 94
    :cond_4
    move-object v0, p1

    check-cast v0, Lnet/duceng/midi/EventChannel;

    .line 95
    .local v0, "o":Lnet/duceng/midi/EventChannel;
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->type:B

    iget-byte v4, v0, Lnet/duceng/midi/EventChannel;->type:B

    if-eq v1, v4, :cond_5

    .line 96
    return v3

    .line 98
    :cond_5
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->channel:B

    iget-byte v4, v0, Lnet/duceng/midi/EventChannel;->channel:B

    if-eq v1, v4, :cond_7

    .line 99
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->channel:B

    iget-byte v4, v0, Lnet/duceng/midi/EventChannel;->channel:B

    if-lt v1, v4, :cond_6

    const/4 v2, 0x1

    :cond_6
    return v2

    .line 101
    :cond_7
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->value1:B

    iget-byte v4, v0, Lnet/duceng/midi/EventChannel;->value1:B

    if-eq v1, v4, :cond_9

    .line 102
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->value1:B

    iget-byte v4, v0, Lnet/duceng/midi/EventChannel;->value1:B

    if-lt v1, v4, :cond_8

    const/4 v2, 0x1

    :cond_8
    return v2

    .line 104
    :cond_9
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->value2:B

    iget-byte v4, v0, Lnet/duceng/midi/EventChannel;->value2:B

    if-eq v1, v4, :cond_b

    .line 105
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->value2:B

    iget-byte v4, v0, Lnet/duceng/midi/EventChannel;->value2:B

    if-lt v1, v4, :cond_a

    const/4 v2, 0x1

    :cond_a
    return v2

    .line 107
    :cond_b
    const/4 v1, 0x0

    return v1
.end method

.method public getChannel()B
    .locals 1

    .line 43
    iget-byte v0, p0, Lnet/duceng/midi/EventChannel;->channel:B

    return v0
.end method

.method public getSize()I
    .locals 3

    .line 68
    invoke-super {p0}, Lnet/duceng/midi/MidiEvent;->getSize()I

    move-result v0

    .line 69
    .local v0, "size":I
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v2, 0xc

    if-eq v1, v2, :cond_1

    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v2, 0xd

    if-ne v1, v2, :cond_0

    goto :goto_0

    :cond_0
    add-int/lit8 v1, v0, 0x3

    goto :goto_1

    :cond_1
    :goto_0
    add-int/lit8 v1, v0, 0x2

    :goto_1
    return v1
.end method

.method public getType()B
    .locals 1

    .line 35
    iget-byte v0, p0, Lnet/duceng/midi/EventChannel;->type:B

    return v0
.end method

.method public getValue1()B
    .locals 1

    .line 51
    iget-byte v0, p0, Lnet/duceng/midi/EventChannel;->value1:B

    return v0
.end method

.method public getValue2()B
    .locals 1

    .line 59
    iget-byte v0, p0, Lnet/duceng/midi/EventChannel;->value2:B

    return v0
.end method

.method public setChannel(B)V
    .locals 0
    .param p1, "c"    # B

    .line 47
    iput-byte p1, p0, Lnet/duceng/midi/EventChannel;->channel:B

    .line 48
    return-void
.end method

.method public setType(B)V
    .locals 0
    .param p1, "t"    # B

    .line 39
    iput-byte p1, p0, Lnet/duceng/midi/EventChannel;->type:B

    .line 40
    return-void
.end method

.method public setValue1(B)V
    .locals 0
    .param p1, "v1"    # B

    .line 55
    iput-byte p1, p0, Lnet/duceng/midi/EventChannel;->value1:B

    .line 56
    return-void
.end method

.method public setValue2(B)V
    .locals 0
    .param p1, "v2"    # B

    .line 63
    iput-byte p1, p0, Lnet/duceng/midi/EventChannel;->value2:B

    .line 64
    return-void
.end method

.method public withVelocity(I)Lnet/duceng/midi/EventChannel;
    .locals 3
    .param p1, "vel"    # I

    .line 113
    invoke-virtual {p0}, Lnet/duceng/midi/EventChannel;->clone()Lnet/duceng/midi/EventChannel;

    move-result-object v0

    .line 114
    .local v0, "c":Lnet/duceng/midi/EventChannel;
    const/16 v1, 0x7f

    invoke-static {v1, p1}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v2, 0x1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    int-to-byte v1, v1

    iput-byte v1, v0, Lnet/duceng/midi/EventChannel;->value2:B

    .line 115
    return-object v0
.end method

.method public write(Ljava/io/OutputStream;)V
    .locals 3
    .param p1, "out"    # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 74
    invoke-super {p0, p1}, Lnet/duceng/midi/MidiEvent;->write(Ljava/io/OutputStream;)V

    .line 75
    iget-byte v0, p0, Lnet/duceng/midi/EventChannel;->type:B

    shl-int/lit8 v0, v0, 0x4

    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->channel:B

    add-int/2addr v0, v1

    .line 76
    .local v0, "code":I
    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write(I)V

    .line 77
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->value1:B

    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write(I)V

    .line 78
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v2, 0xc

    if-eq v1, v2, :cond_0

    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v2, 0xd

    if-eq v1, v2, :cond_0

    .line 79
    iget-byte v1, p0, Lnet/duceng/midi/EventChannel;->value2:B

    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write(I)V

    .line 81
    :cond_0
    return-void
.end method
