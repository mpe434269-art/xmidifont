.class public Lnet/duceng/midi/EventMeta;
.super Lnet/duceng/midi/MidiEvent;
.source "EventMeta.java"


# static fields
.field public static final COPYRIGHT_NOTICE:S = 0x2s

.field public static final CUE_POINT:S = 0x7s

.field public static final END_OF_TRACK:S = 0x2fs

.field public static final INSTRUMENT_NAME:S = 0x4s

.field public static final KEY_SIGNATURE:S = 0x59s

.field public static final LYRICS:S = 0x5s

.field public static final MARKER:S = 0x6s

.field public static final MIDI_CHANNEL_PREFIX:S = 0x20s

.field public static final SEQUENCER_SPECIFIC:S = 0x7fs

.field public static final SEQUENCE_NUMBER:S = 0x0s

.field public static final SMPTE_OFFSET:S = 0x54s

.field public static final TEMPO:S = 0x51s

.field public static final TEXT_EVENT:S = 0x1s

.field public static final TIME_SIGNATURE:S = 0x58s

.field public static final TRACK_NAME:S = 0x3s


# instance fields
.field protected length:I

.field protected type:S

.field protected value:[B


# direct methods
.method protected constructor <init>(IIS[B)V
    .locals 1
    .param p1, "t"    # I
    .param p2, "d"    # I
    .param p3, "tp"    # S
    .param p4, "v"    # [B

    .line 28
    invoke-direct {p0, p1, p2}, Lnet/duceng/midi/MidiEvent;-><init>(II)V

    .line 29
    iput-short p3, p0, Lnet/duceng/midi/EventMeta;->type:S

    .line 30
    iput-object p4, p0, Lnet/duceng/midi/EventMeta;->value:[B

    .line 31
    array-length v0, p4

    iput v0, p0, Lnet/duceng/midi/EventMeta;->length:I

    .line 32
    return-void
.end method


# virtual methods
.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .locals 0

    .line 7
    check-cast p1, Lnet/duceng/midi/MidiEvent;

    invoke-virtual {p0, p1}, Lnet/duceng/midi/EventMeta;->compareTo(Lnet/duceng/midi/MidiEvent;)I

    move-result p1

    return p1
.end method

.method public compareTo(Lnet/duceng/midi/MidiEvent;)I
    .locals 5
    .param p1, "other"    # Lnet/duceng/midi/MidiEvent;

    .line 72
    iget v0, p0, Lnet/duceng/midi/EventMeta;->tick:I

    invoke-virtual {p1}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v1

    const/4 v2, -0x1

    const/4 v3, 0x1

    if-eq v0, v1, :cond_1

    .line 73
    iget v0, p0, Lnet/duceng/midi/EventMeta;->tick:I

    invoke-virtual {p1}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v1

    if-lt v0, v1, :cond_0

    const/4 v2, 0x1

    :cond_0
    return v2

    .line 75
    :cond_1
    iget v0, p0, Lnet/duceng/midi/EventMeta;->delta:I

    iget v1, p1, Lnet/duceng/midi/MidiEvent;->delta:I

    if-eq v0, v1, :cond_3

    .line 76
    iget v0, p0, Lnet/duceng/midi/EventMeta;->delta:I

    iget v1, p1, Lnet/duceng/midi/MidiEvent;->delta:I

    if-lt v0, v1, :cond_2

    goto :goto_0

    :cond_2
    const/4 v2, 0x1

    :goto_0
    return v2

    .line 78
    :cond_3
    instance-of v0, p1, Lnet/duceng/midi/EventMeta;

    if-nez v0, :cond_4

    .line 79
    return v3

    .line 81
    :cond_4
    move-object v0, p1

    check-cast v0, Lnet/duceng/midi/EventMeta;

    .line 82
    .local v0, "o":Lnet/duceng/midi/EventMeta;
    iget-short v1, p0, Lnet/duceng/midi/EventMeta;->type:S

    iget-short v4, v0, Lnet/duceng/midi/EventMeta;->type:S

    if-eq v1, v4, :cond_6

    .line 83
    iget-short v1, p0, Lnet/duceng/midi/EventMeta;->type:S

    iget-short v4, v0, Lnet/duceng/midi/EventMeta;->type:S

    if-lt v1, v4, :cond_5

    goto :goto_1

    :cond_5
    const/4 v2, 0x1

    :goto_1
    return v2

    .line 85
    :cond_6
    new-instance v1, Ljava/lang/String;

    iget-object v2, p0, Lnet/duceng/midi/EventMeta;->value:[B

    invoke-direct {v1, v2}, Ljava/lang/String;-><init>([B)V

    .line 86
    .local v1, "curr":Ljava/lang/String;
    new-instance v2, Ljava/lang/String;

    move-object v3, p1

    check-cast v3, Lnet/duceng/midi/EventMeta;

    iget-object v3, v3, Lnet/duceng/midi/EventMeta;->value:[B

    invoke-direct {v2, v3}, Ljava/lang/String;-><init>([B)V

    .line 87
    .local v2, "comp":Ljava/lang/String;
    invoke-virtual {v1, v2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v3

    return v3
.end method

.method public getLength()I
    .locals 1

    .line 43
    iget v0, p0, Lnet/duceng/midi/EventMeta;->length:I

    return v0
.end method

.method public getSize()I
    .locals 3

    .line 57
    invoke-super {p0}, Lnet/duceng/midi/MidiEvent;->getSize()I

    move-result v0

    .line 58
    .local v0, "size":I
    iget v1, p0, Lnet/duceng/midi/EventMeta;->length:I

    invoke-static {v1}, Lnet/duceng/midi/MidiUtil;->vintToBytes(I)[B

    move-result-object v1

    array-length v1, v1

    add-int/2addr v1, v0

    add-int/lit8 v1, v1, 0x2

    iget v2, p0, Lnet/duceng/midi/EventMeta;->length:I

    add-int/2addr v1, v2

    return v1
.end method

.method public getType()S
    .locals 1

    .line 35
    iget-short v0, p0, Lnet/duceng/midi/EventMeta;->type:S

    return v0
.end method

.method public getValue()[B
    .locals 1

    .line 47
    iget-object v0, p0, Lnet/duceng/midi/EventMeta;->value:[B

    return-object v0
.end method

.method public setType(S)V
    .locals 0
    .param p1, "t"    # S

    .line 39
    iput-short p1, p0, Lnet/duceng/midi/EventMeta;->type:S

    .line 40
    return-void
.end method

.method public setValue([B)V
    .locals 1
    .param p1, "v"    # [B

    .line 51
    iput-object p1, p0, Lnet/duceng/midi/EventMeta;->value:[B

    .line 52
    array-length v0, p1

    iput v0, p0, Lnet/duceng/midi/EventMeta;->length:I

    .line 53
    return-void
.end method

.method public write(Ljava/io/OutputStream;)V
    .locals 1
    .param p1, "out"    # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 63
    invoke-super {p0, p1}, Lnet/duceng/midi/MidiEvent;->write(Ljava/io/OutputStream;)V

    .line 64
    const/16 v0, 0xff

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write(I)V

    .line 65
    iget-short v0, p0, Lnet/duceng/midi/EventMeta;->type:S

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write(I)V

    .line 66
    iget v0, p0, Lnet/duceng/midi/EventMeta;->length:I

    invoke-static {v0}, Lnet/duceng/midi/MidiUtil;->vintToBytes(I)[B

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 67
    iget-object v0, p0, Lnet/duceng/midi/EventMeta;->value:[B

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 68
    return-void
.end method
