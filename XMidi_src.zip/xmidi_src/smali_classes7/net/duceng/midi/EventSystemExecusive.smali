.class public Lnet/duceng/midi/EventSystemExecusive;
.super Lnet/duceng/midi/MidiEvent;
.source "EventSystemExecusive.java"


# instance fields
.field protected length:I

.field protected type:S

.field protected value:[B


# direct methods
.method protected constructor <init>(IIS[B)V
    .locals 1
    .param p1, "t"    # I
    .param p2, "d"    # I
    .param p3, "tp"    # S
    .param p4, "v"    # [B

    .line 13
    invoke-direct {p0, p1, p2}, Lnet/duceng/midi/MidiEvent;-><init>(II)V

    .line 14
    const/16 v0, 0xf0

    if-eq p3, v0, :cond_0

    const/16 v0, 0xf7

    if-eq p3, v0, :cond_0

    .line 15
    const/16 p3, 0xf0

    .line 17
    :cond_0
    iput-short p3, p0, Lnet/duceng/midi/EventSystemExecusive;->type:S

    .line 18
    iput-object p4, p0, Lnet/duceng/midi/EventSystemExecusive;->value:[B

    .line 19
    array-length v0, p4

    iput v0, p0, Lnet/duceng/midi/EventSystemExecusive;->length:I

    .line 20
    return-void
.end method


# virtual methods
.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .locals 0

    .line 7
    check-cast p1, Lnet/duceng/midi/MidiEvent;

    invoke-virtual {p0, p1}, Lnet/duceng/midi/EventSystemExecusive;->compareTo(Lnet/duceng/midi/MidiEvent;)I

    move-result p1

    return p1
.end method

.method public compareTo(Lnet/duceng/midi/MidiEvent;)I
    .locals 4
    .param p1, "other"    # Lnet/duceng/midi/MidiEvent;

    .line 59
    iget v0, p0, Lnet/duceng/midi/EventSystemExecusive;->tick:I

    invoke-virtual {p1}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v1

    const/4 v2, -0x1

    const/4 v3, 0x1

    if-eq v0, v1, :cond_1

    .line 60
    iget v0, p0, Lnet/duceng/midi/EventSystemExecusive;->tick:I

    invoke-virtual {p1}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v1

    if-lt v0, v1, :cond_0

    const/4 v2, 0x1

    :cond_0
    return v2

    .line 62
    :cond_1
    iget v0, p0, Lnet/duceng/midi/EventSystemExecusive;->delta:I

    iget v1, p1, Lnet/duceng/midi/MidiEvent;->delta:I

    if-eq v0, v1, :cond_3

    .line 63
    iget v0, p0, Lnet/duceng/midi/EventSystemExecusive;->delta:I

    iget v1, p1, Lnet/duceng/midi/MidiEvent;->delta:I

    if-lt v0, v1, :cond_2

    goto :goto_0

    :cond_2
    const/4 v2, 0x1

    :goto_0
    return v2

    .line 65
    :cond_3
    instance-of v0, p1, Lnet/duceng/midi/EventSystemExecusive;

    if-nez v0, :cond_4

    .line 66
    return v3

    .line 68
    :cond_4
    new-instance v0, Ljava/lang/String;

    iget-object v1, p0, Lnet/duceng/midi/EventSystemExecusive;->value:[B

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([B)V

    .line 69
    .local v0, "curr":Ljava/lang/String;
    new-instance v1, Ljava/lang/String;

    move-object v2, p1

    check-cast v2, Lnet/duceng/midi/EventSystemExecusive;

    iget-object v2, v2, Lnet/duceng/midi/EventSystemExecusive;->value:[B

    invoke-direct {v1, v2}, Ljava/lang/String;-><init>([B)V

    .line 70
    .local v1, "comp":Ljava/lang/String;
    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v2

    return v2
.end method

.method public getLength()I
    .locals 1

    .line 31
    iget v0, p0, Lnet/duceng/midi/EventSystemExecusive;->length:I

    return v0
.end method

.method public getSize()I
    .locals 3

    .line 45
    invoke-super {p0}, Lnet/duceng/midi/MidiEvent;->getSize()I

    move-result v0

    .line 46
    .local v0, "size":I
    iget v1, p0, Lnet/duceng/midi/EventSystemExecusive;->length:I

    invoke-static {v1}, Lnet/duceng/midi/MidiUtil;->vintToBytes(I)[B

    move-result-object v1

    array-length v1, v1

    add-int/2addr v1, v0

    add-int/lit8 v1, v1, 0x1

    iget v2, p0, Lnet/duceng/midi/EventSystemExecusive;->length:I

    add-int/2addr v1, v2

    return v1
.end method

.method public getType()S
    .locals 1

    .line 23
    iget-short v0, p0, Lnet/duceng/midi/EventSystemExecusive;->type:S

    return v0
.end method

.method public getValue()[B
    .locals 1

    .line 35
    iget-object v0, p0, Lnet/duceng/midi/EventSystemExecusive;->value:[B

    return-object v0
.end method

.method public setType(S)V
    .locals 0
    .param p1, "t"    # S

    .line 27
    iput-short p1, p0, Lnet/duceng/midi/EventSystemExecusive;->type:S

    .line 28
    return-void
.end method

.method public setValue([B)V
    .locals 1
    .param p1, "v"    # [B

    .line 39
    iput-object p1, p0, Lnet/duceng/midi/EventSystemExecusive;->value:[B

    .line 40
    array-length v0, p1

    iput v0, p0, Lnet/duceng/midi/EventSystemExecusive;->length:I

    .line 41
    return-void
.end method

.method public write(Ljava/io/OutputStream;)V
    .locals 1
    .param p1, "out"    # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 51
    invoke-super {p0, p1}, Lnet/duceng/midi/MidiEvent;->write(Ljava/io/OutputStream;)V

    .line 52
    iget-short v0, p0, Lnet/duceng/midi/EventSystemExecusive;->type:S

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write(I)V

    .line 53
    iget v0, p0, Lnet/duceng/midi/EventSystemExecusive;->length:I

    invoke-static {v0}, Lnet/duceng/midi/MidiUtil;->vintToBytes(I)[B

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 54
    iget-object v0, p0, Lnet/duceng/midi/EventSystemExecusive;->value:[B

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 55
    return-void
.end method
