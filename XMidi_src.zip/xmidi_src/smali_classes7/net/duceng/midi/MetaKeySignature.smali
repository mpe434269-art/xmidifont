.class public Lnet/duceng/midi/MetaKeySignature;
.super Lnet/duceng/midi/EventMeta;
.source "MetaKeySignature.java"


# static fields
.field public static final SCALE_MAJOR:B = 0x0t

.field public static final SCALE_MINOR:B = 0x1t


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 9
    const/4 v0, 0x2

    new-array v0, v0, [B

    const/4 v1, 0x0

    const/16 v2, 0x59

    invoke-direct {p0, v1, v1, v2, v0}, Lnet/duceng/midi/EventMeta;-><init>(IIS[B)V

    .line 10
    return-void
.end method

.method protected constructor <init>(II[B)V
    .locals 1
    .param p1, "t"    # I
    .param p2, "d"    # I
    .param p3, "v"    # [B

    .line 13
    const/16 v0, 0x59

    invoke-direct {p0, p1, p2, v0, p3}, Lnet/duceng/midi/EventMeta;-><init>(IIS[B)V

    .line 14
    return-void
.end method


# virtual methods
.method public getKey()B
    .locals 2

    .line 17
    iget-object v0, p0, Lnet/duceng/midi/MetaKeySignature;->value:[B

    const/4 v1, 0x0

    aget-byte v0, v0, v1

    return v0
.end method

.method public getScale()B
    .locals 2

    .line 25
    iget-object v0, p0, Lnet/duceng/midi/MetaKeySignature;->value:[B

    const/4 v1, 0x1

    aget-byte v0, v0, v1

    return v0
.end method

.method public setKey(B)V
    .locals 2
    .param p1, "k"    # B

    .line 21
    iget-object v0, p0, Lnet/duceng/midi/MetaKeySignature;->value:[B

    const/4 v1, 0x0

    aput-byte p1, v0, v1

    .line 22
    return-void
.end method

.method public setScale(B)V
    .locals 2
    .param p1, "s"    # B

    .line 29
    iget-object v0, p0, Lnet/duceng/midi/MetaKeySignature;->value:[B

    const/4 v1, 0x1

    aput-byte p1, v0, v1

    .line 30
    return-void
.end method
