.class public Lnet/duceng/midi/MetaTempo;
.super Lnet/duceng/midi/EventMeta;
.source "MetaTempo.java"


# static fields
.field public static final DEFAULT_BPM:I = 0x78

.field public static final DEFAULT_MPQN:I = 0x7a120


# instance fields
.field private bpm:I

.field private mpqn:I


# direct methods
.method public constructor <init>()V
    .locals 4

    .line 11
    const/4 v0, 0x3

    const v1, 0x7a120

    invoke-static {v1, v0}, Lnet/duceng/midi/MidiUtil;->intToBytes(II)[B

    move-result-object v0

    const/4 v2, 0x0

    const/16 v3, 0x51

    invoke-direct {p0, v2, v2, v3, v0}, Lnet/duceng/midi/EventMeta;-><init>(IIS[B)V

    .line 12
    const/16 v0, 0x78

    iput v0, p0, Lnet/duceng/midi/MetaTempo;->bpm:I

    .line 13
    iput v1, p0, Lnet/duceng/midi/MetaTempo;->mpqn:I

    .line 14
    return-void
.end method

.method protected constructor <init>(II[B)V
    .locals 3
    .param p1, "t"    # I
    .param p2, "d"    # I
    .param p3, "v"    # [B

    .line 17
    const/16 v0, 0x51

    invoke-direct {p0, p1, p2, v0, p3}, Lnet/duceng/midi/EventMeta;-><init>(IIS[B)V

    .line 18
    iget-object v0, p0, Lnet/duceng/midi/MetaTempo;->value:[B

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0, v1, v2}, Lnet/duceng/midi/MidiUtil;->bytesToInt([BII)I

    move-result v0

    iput v0, p0, Lnet/duceng/midi/MetaTempo;->mpqn:I

    .line 19
    const v0, 0x3938700

    iget v1, p0, Lnet/duceng/midi/MetaTempo;->mpqn:I

    div-int/2addr v0, v1

    iput v0, p0, Lnet/duceng/midi/MetaTempo;->bpm:I

    .line 20
    return-void
.end method


# virtual methods
.method public getBpm()I
    .locals 1

    .line 36
    iget v0, p0, Lnet/duceng/midi/MetaTempo;->bpm:I

    return v0
.end method

.method public getMpqn()I
    .locals 1

    .line 23
    iget v0, p0, Lnet/duceng/midi/MetaTempo;->mpqn:I

    return v0
.end method

.method public setBpm(I)V
    .locals 1
    .param p1, "b"    # I

    .line 40
    const v0, 0x3938700

    div-int/2addr v0, p1

    invoke-virtual {p0, v0}, Lnet/duceng/midi/MetaTempo;->setMpqn(I)V

    .line 41
    return-void
.end method

.method public setMpqn(I)V
    .locals 5
    .param p1, "m"    # I

    .line 27
    iput p1, p0, Lnet/duceng/midi/MetaTempo;->mpqn:I

    .line 28
    const v0, 0x3938700

    iget v1, p0, Lnet/duceng/midi/MetaTempo;->mpqn:I

    div-int/2addr v0, v1

    iput v0, p0, Lnet/duceng/midi/MetaTempo;->bpm:I

    .line 29
    iget v0, p0, Lnet/duceng/midi/MetaTempo;->mpqn:I

    const/4 v1, 0x3

    invoke-static {v0, v1}, Lnet/duceng/midi/MidiUtil;->intToBytes(II)[B

    move-result-object v0

    .line 30
    .local v0, "buffer":[B
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    if-ge v2, v1, :cond_0

    .line 31
    iget-object v3, p0, Lnet/duceng/midi/MetaTempo;->value:[B

    aget-byte v4, v0, v2

    aput-byte v4, v3, v2

    .line 30
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 33
    .end local v2    # "i":I
    :cond_0
    return-void
.end method
