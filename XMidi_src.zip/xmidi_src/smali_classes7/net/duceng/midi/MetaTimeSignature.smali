.class public Lnet/duceng/midi/MetaTimeSignature;
.super Lnet/duceng/midi/EventMeta;
.source "MetaTimeSignature.java"


# static fields
.field public static final DEFAULT_DENOMINATOR:B = 0x2t

.field public static final DEFAULT_DIVISION:B = 0x8t

.field public static final DEFAULT_METER:B = 0x18t

.field public static final DEFAULT_NUMERATOR:B = 0x4t


# direct methods
.method public constructor <init>()V
    .locals 4

    .line 11
    const/4 v0, 0x4

    new-array v1, v0, [B

    const/4 v2, 0x0

    const/16 v3, 0x58

    invoke-direct {p0, v2, v2, v3, v1}, Lnet/duceng/midi/EventMeta;-><init>(IIS[B)V

    .line 12
    iget-object v1, p0, Lnet/duceng/midi/MetaTimeSignature;->value:[B

    aput-byte v0, v1, v2

    .line 13
    iget-object v0, p0, Lnet/duceng/midi/MetaTimeSignature;->value:[B

    const/4 v1, 0x1

    const/4 v2, 0x2

    aput-byte v2, v0, v1

    .line 14
    iget-object v0, p0, Lnet/duceng/midi/MetaTimeSignature;->value:[B

    const/16 v1, 0x18

    aput-byte v1, v0, v2

    .line 15
    iget-object v0, p0, Lnet/duceng/midi/MetaTimeSignature;->value:[B

    const/4 v1, 0x3

    const/16 v2, 0x8

    aput-byte v2, v0, v1

    .line 16
    return-void
.end method

.method protected constructor <init>(II[B)V
    .locals 1
    .param p1, "t"    # I
    .param p2, "d"    # I
    .param p3, "v"    # [B

    .line 19
    const/16 v0, 0x58

    invoke-direct {p0, p1, p2, v0, p3}, Lnet/duceng/midi/EventMeta;-><init>(IIS[B)V

    .line 20
    return-void
.end method


# virtual methods
.method public getDenominator()B
    .locals 2

    .line 31
    iget-object v0, p0, Lnet/duceng/midi/MetaTimeSignature;->value:[B

    const/4 v1, 0x1

    aget-byte v0, v0, v1

    return v0
.end method

.method public getDivision()B
    .locals 2

    .line 43
    iget-object v0, p0, Lnet/duceng/midi/MetaTimeSignature;->value:[B

    const/4 v1, 0x3

    aget-byte v0, v0, v1

    return v0
.end method

.method public getMeter()B
    .locals 2

    .line 39
    iget-object v0, p0, Lnet/duceng/midi/MetaTimeSignature;->value:[B

    const/4 v1, 0x2

    aget-byte v0, v0, v1

    return v0
.end method

.method public getNumerator()B
    .locals 2

    .line 23
    iget-object v0, p0, Lnet/duceng/midi/MetaTimeSignature;->value:[B

    const/4 v1, 0x0

    aget-byte v0, v0, v1

    return v0
.end method

.method public setDenominator(B)V
    .locals 2
    .param p1, "d"    # B

    .line 35
    iget-object v0, p0, Lnet/duceng/midi/MetaTimeSignature;->value:[B

    const/4 v1, 0x1

    aput-byte p1, v0, v1

    .line 36
    return-void
.end method

.method public setNumerator(B)V
    .locals 2
    .param p1, "n"    # B

    .line 27
    iget-object v0, p0, Lnet/duceng/midi/MetaTimeSignature;->value:[B

    const/4 v1, 0x0

    aput-byte p1, v0, v1

    .line 28
    return-void
.end method
