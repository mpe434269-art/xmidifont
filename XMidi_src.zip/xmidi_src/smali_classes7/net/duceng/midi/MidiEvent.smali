.class public abstract Lnet/duceng/midi/MidiEvent;
.super Ljava/lang/Object;
.source "MidiEvent.java"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lnet/duceng/midi/MidiEvent;",
        ">;"
    }
.end annotation


# static fields
.field private static lastId:I


# instance fields
.field protected delta:I

.field protected tick:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 10
    const/4 v0, -0x1

    sput v0, Lnet/duceng/midi/MidiEvent;->lastId:I

    return-void
.end method

.method public constructor <init>(II)V
    .locals 0
    .param p1, "t"    # I
    .param p2, "d"    # I

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    iput p1, p0, Lnet/duceng/midi/MidiEvent;->tick:I

    .line 16
    iput p2, p0, Lnet/duceng/midi/MidiEvent;->delta:I

    .line 17
    return-void
.end method

.method public static final parse(IILjava/io/InputStream;)Lnet/duceng/midi/MidiEvent;
    .locals 13
    .param p0, "tick"    # I
    .param p1, "delta"    # I
    .param p2, "in"    # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 44
    const/4 v0, 0x1

    invoke-virtual {p2, v0}, Ljava/io/InputStream;->mark(I)V

    .line 45
    invoke-virtual {p2}, Ljava/io/InputStream;->read()I

    move-result v0

    .line 46
    .local v0, "id":I
    const/16 v1, 0x7f

    const/16 v2, 0x80

    if-gt v0, v1, :cond_0

    sget v1, Lnet/duceng/midi/MidiEvent;->lastId:I

    if-lt v1, v2, :cond_0

    .line 47
    invoke-virtual {p2}, Ljava/io/InputStream;->reset()V

    .line 48
    sget v0, Lnet/duceng/midi/MidiEvent;->lastId:I

    .line 50
    :cond_0
    if-lt v0, v2, :cond_2

    const/16 v1, 0xef

    if-gt v0, v1, :cond_2

    .line 51
    shr-int/lit8 v1, v0, 0x4

    int-to-byte v1, v1

    .line 52
    .local v1, "type":B
    and-int/lit8 v2, v0, 0xf

    int-to-byte v9, v2

    .line 53
    .local v9, "channel":B
    invoke-virtual {p2}, Ljava/io/InputStream;->read()I

    move-result v2

    int-to-byte v10, v2

    .line 54
    .local v10, "v1":B
    const/4 v2, 0x0

    .line 55
    .local v2, "v2":B
    const/16 v3, 0xc

    if-eq v1, v3, :cond_1

    const/16 v3, 0xd

    if-eq v1, v3, :cond_1

    .line 56
    invoke-virtual {p2}, Ljava/io/InputStream;->read()I

    move-result v3

    int-to-byte v2, v3

    move v11, v2

    goto :goto_0

    .line 58
    :cond_1
    move v11, v2

    .end local v2    # "v2":B
    .local v11, "v2":B
    :goto_0
    sput v0, Lnet/duceng/midi/MidiEvent;->lastId:I

    .line 59
    new-instance v12, Lnet/duceng/midi/EventChannel;

    move-object v2, v12

    move v3, p0

    move v4, p1

    move v5, v1

    move v6, v9

    move v7, v10

    move v8, v11

    invoke-direct/range {v2 .. v8}, Lnet/duceng/midi/EventChannel;-><init>(IIBBBB)V

    return-object v12

    .line 61
    .end local v1    # "type":B
    .end local v9    # "channel":B
    .end local v10    # "v1":B
    .end local v11    # "v2":B
    :cond_2
    const/16 v1, 0xff

    if-ne v0, v1, :cond_6

    .line 62
    invoke-virtual {p2}, Ljava/io/InputStream;->read()I

    move-result v1

    int-to-short v1, v1

    .line 63
    .local v1, "type2":S
    invoke-static {p2}, Lnet/duceng/midi/MidiUtil;->readVInt(Ljava/io/InputStream;)I

    move-result v2

    .line 64
    .local v2, "size":I
    new-array v3, v2, [B

    .line 65
    .local v3, "buff":[B
    invoke-static {p2, v3}, Lnet/duceng/midi/MidiUtil;->readFully(Ljava/io/InputStream;[B)I

    .line 66
    sput v0, Lnet/duceng/midi/MidiEvent;->lastId:I

    .line 67
    const/16 v4, 0x51

    if-ne v1, v4, :cond_3

    .line 68
    new-instance v4, Lnet/duceng/midi/MetaTempo;

    invoke-direct {v4, p0, p1, v3}, Lnet/duceng/midi/MetaTempo;-><init>(II[B)V

    return-object v4

    .line 70
    :cond_3
    const/16 v4, 0x59

    if-ne v1, v4, :cond_4

    .line 71
    new-instance v4, Lnet/duceng/midi/MetaKeySignature;

    invoke-direct {v4, p0, p1, v3}, Lnet/duceng/midi/MetaKeySignature;-><init>(II[B)V

    return-object v4

    .line 73
    :cond_4
    const/16 v4, 0x58

    if-ne v1, v4, :cond_5

    .line 74
    new-instance v4, Lnet/duceng/midi/MetaTimeSignature;

    invoke-direct {v4, p0, p1, v3}, Lnet/duceng/midi/MetaTimeSignature;-><init>(II[B)V

    return-object v4

    .line 76
    :cond_5
    new-instance v4, Lnet/duceng/midi/EventMeta;

    invoke-direct {v4, p0, p1, v1, v3}, Lnet/duceng/midi/EventMeta;-><init>(IIS[B)V

    return-object v4

    .line 78
    .end local v1    # "type2":S
    .end local v2    # "size":I
    .end local v3    # "buff":[B
    :cond_6
    const/16 v1, 0xf0

    if-eq v0, v1, :cond_8

    const/16 v1, 0xf7

    if-ne v0, v1, :cond_7

    goto :goto_1

    .line 85
    :cond_7
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Unable to read event, skipping: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "MidiEvent"

    invoke-static {v2, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 86
    const/4 v1, 0x0

    return-object v1

    .line 79
    :cond_8
    :goto_1
    invoke-static {p2}, Lnet/duceng/midi/MidiUtil;->readVInt(Ljava/io/InputStream;)I

    move-result v1

    .line 80
    .local v1, "size2":I
    new-array v2, v1, [B

    .line 81
    .local v2, "buff2":[B
    invoke-static {p2, v2}, Lnet/duceng/midi/MidiUtil;->readFully(Ljava/io/InputStream;[B)I

    .line 82
    sput v0, Lnet/duceng/midi/MidiEvent;->lastId:I

    .line 83
    new-instance v3, Lnet/duceng/midi/EventSystemExecusive;

    int-to-short v4, v0

    invoke-direct {v3, p0, p1, v4, v2}, Lnet/duceng/midi/EventSystemExecusive;-><init>(IIS[B)V

    return-object v3
.end method


# virtual methods
.method public getDelta()I
    .locals 1

    .line 28
    iget v0, p0, Lnet/duceng/midi/MidiEvent;->delta:I

    return v0
.end method

.method protected getSize()I
    .locals 1

    .line 36
    iget v0, p0, Lnet/duceng/midi/MidiEvent;->delta:I

    invoke-static {v0}, Lnet/duceng/midi/MidiUtil;->vintToBytes(I)[B

    move-result-object v0

    array-length v0, v0

    return v0
.end method

.method public getTick()I
    .locals 1

    .line 20
    iget v0, p0, Lnet/duceng/midi/MidiEvent;->tick:I

    return v0
.end method

.method public setDelta(I)V
    .locals 0
    .param p1, "d"    # I

    .line 32
    iput p1, p0, Lnet/duceng/midi/MidiEvent;->delta:I

    .line 33
    return-void
.end method

.method public setTick(I)V
    .locals 0
    .param p1, "t"    # I

    .line 24
    iput p1, p0, Lnet/duceng/midi/MidiEvent;->tick:I

    .line 25
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 90
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p0, Lnet/duceng/midi/MidiEvent;->tick:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lnet/duceng/midi/MidiEvent;->delta:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "): "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public write(Ljava/io/OutputStream;)V
    .locals 1
    .param p1, "out"    # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 40
    iget v0, p0, Lnet/duceng/midi/MidiEvent;->delta:I

    invoke-static {v0}, Lnet/duceng/midi/MidiUtil;->vintToBytes(I)[B

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 41
    return-void
.end method
