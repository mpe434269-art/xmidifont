.class public Lnet/duceng/midi/MidiFile;
.super Ljava/lang/Object;
.source "MidiFile.java"


# static fields
.field public static final DEFAULT_RESOLUTION:I = 0x1e0

.field public static final HEAD:Ljava/lang/String; = "MThd"


# instance fields
.field private count:I

.field private keySignature:Lnet/duceng/midi/MetaKeySignature;

.field private resolution:I

.field private tempo:Lnet/duceng/midi/MetaTempo;

.field private timeSignature:Lnet/duceng/midi/MetaTimeSignature;

.field private tracks:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/MidiTrack;",
            ">;"
        }
    .end annotation
.end field

.field private type:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 22
    const/16 v0, 0x1e0

    invoke-direct {p0, v0}, Lnet/duceng/midi/MidiFile;-><init>(I)V

    .line 23
    return-void
.end method

.method public constructor <init>(I)V
    .locals 1
    .param p1, "r"    # I

    .line 26
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-direct {p0, p1, v0}, Lnet/duceng/midi/MidiFile;-><init>(ILjava/util/ArrayList;)V

    .line 27
    return-void
.end method

.method public constructor <init>(ILjava/util/ArrayList;)V
    .locals 2
    .param p1, "r"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/MidiTrack;",
            ">;)V"
        }
    .end annotation

    .line 29
    .local p2, "t":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiTrack;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 30
    const/4 v0, 0x0

    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->tempo:Lnet/duceng/midi/MetaTempo;

    .line 31
    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->keySignature:Lnet/duceng/midi/MetaKeySignature;

    .line 32
    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    .line 33
    if-gez p1, :cond_0

    const/16 v0, 0x1e0

    goto :goto_0

    :cond_0
    move v0, p1

    :goto_0
    iput v0, p0, Lnet/duceng/midi/MidiFile;->resolution:I

    .line 34
    if-nez p2, :cond_1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    goto :goto_1

    :cond_1
    move-object v0, p2

    :goto_1
    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    .line 35
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iput v0, p0, Lnet/duceng/midi/MidiFile;->count:I

    .line 36
    iget v0, p0, Lnet/duceng/midi/MidiFile;->count:I

    const/4 v1, 0x1

    if-gt v0, v1, :cond_2

    const/4 v1, 0x0

    :cond_2
    iput v1, p0, Lnet/duceng/midi/MidiFile;->type:I

    .line 37
    return-void
.end method

.method public constructor <init>(Ljava/io/InputStream;)V
    .locals 8
    .param p1, "is"    # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 39
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 40
    const/4 v0, 0x0

    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->tempo:Lnet/duceng/midi/MetaTempo;

    .line 41
    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->keySignature:Lnet/duceng/midi/MetaKeySignature;

    .line 42
    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    .line 43
    new-instance v0, Ljava/io/BufferedInputStream;

    invoke-direct {v0, p1}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    .line 44
    .local v0, "in":Ljava/io/BufferedInputStream;
    const/16 v1, 0xe

    new-array v1, v1, [B

    .line 45
    .local v1, "buffer":[B
    invoke-virtual {v0, v1}, Ljava/io/BufferedInputStream;->read([B)I

    .line 46
    new-instance v2, Ljava/lang/String;

    const/4 v3, 0x4

    const-string v4, "US-ASCII"

    const/4 v5, 0x0

    invoke-direct {v2, v1, v5, v3, v4}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    .line 47
    .local v2, "head":Ljava/lang/String;
    const-string v3, "MThd"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    .line 48
    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v4, "File identifier not MThd. Exiting"

    invoke-virtual {v3, v4}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 49
    iput v5, p0, Lnet/duceng/midi/MidiFile;->type:I

    .line 50
    iput v5, p0, Lnet/duceng/midi/MidiFile;->count:I

    .line 51
    const/16 v3, 0x1e0

    iput v3, p0, Lnet/duceng/midi/MidiFile;->resolution:I

    .line 52
    return-void

    .line 54
    :cond_0
    const/16 v3, 0x8

    const/4 v4, 0x2

    invoke-static {v1, v3, v4}, Lnet/duceng/midi/MidiUtil;->bytesToInt([BII)I

    move-result v3

    iput v3, p0, Lnet/duceng/midi/MidiFile;->type:I

    .line 55
    const/16 v3, 0xa

    invoke-static {v1, v3, v4}, Lnet/duceng/midi/MidiUtil;->bytesToInt([BII)I

    move-result v3

    iput v3, p0, Lnet/duceng/midi/MidiFile;->count:I

    .line 56
    const/16 v3, 0xc

    invoke-static {v1, v3, v4}, Lnet/duceng/midi/MidiUtil;->bytesToInt([BII)I

    move-result v3

    iput v3, p0, Lnet/duceng/midi/MidiFile;->resolution:I

    .line 57
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    .line 58
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    iget v4, p0, Lnet/duceng/midi/MidiFile;->count:I

    if-ge v3, v4, :cond_1

    .line 59
    iget-object v4, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    new-instance v5, Lnet/duceng/midi/MidiTrack;

    invoke-direct {v5, v0}, Lnet/duceng/midi/MidiTrack;-><init>(Ljava/io/InputStream;)V

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 60
    sget-object v4, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "T: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " CH: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/midi/MidiTrack;

    invoke-virtual {v6}, Lnet/duceng/midi/MidiTrack;->getChannel()B

    move-result v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " PRG: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/midi/MidiTrack;

    invoke-virtual {v6}, Lnet/duceng/midi/MidiTrack;->getProgram()B

    move-result v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " CTLS: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/midi/MidiTrack;

    invoke-virtual {v6}, Lnet/duceng/midi/MidiTrack;->getControls()Landroid/util/SparseIntArray;

    move-result-object v6

    invoke-virtual {v6}, Landroid/util/SparseIntArray;->size()I

    move-result v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " COUNT: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v7, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lnet/duceng/midi/MidiTrack;

    iget-object v7, v7, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v7}, Ljava/util/TreeSet;->size()I

    move-result v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lnet/duceng/midi/MidiTrack;

    invoke-virtual {v6}, Lnet/duceng/midi/MidiTrack;->getCount()I

    move-result v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 58
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    .line 62
    .end local v3    # "i":I
    :cond_1
    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Track size: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 63
    return-void
.end method


# virtual methods
.method public addTrack(Lnet/duceng/midi/MidiTrack;)V
    .locals 2
    .param p1, "t"    # Lnet/duceng/midi/MidiTrack;

    .line 110
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 111
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iput v0, p0, Lnet/duceng/midi/MidiFile;->count:I

    .line 112
    iget v0, p0, Lnet/duceng/midi/MidiFile;->count:I

    const/4 v1, 0x1

    if-gt v0, v1, :cond_0

    const/4 v1, 0x0

    :cond_0
    iput v1, p0, Lnet/duceng/midi/MidiFile;->type:I

    .line 113
    return-void
.end method

.method public getCount()I
    .locals 1

    .line 81
    iget v0, p0, Lnet/duceng/midi/MidiFile;->count:I

    return v0
.end method

.method public getKeySignature()Lnet/duceng/midi/MetaKeySignature;
    .locals 5

    .line 151
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->keySignature:Lnet/duceng/midi/MetaKeySignature;

    if-eqz v0, :cond_0

    .line 152
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->keySignature:Lnet/duceng/midi/MetaKeySignature;

    return-object v0

    .line 154
    :cond_0
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/MidiTrack;

    .line 155
    .local v1, "t":Lnet/duceng/midi/MidiTrack;
    invoke-virtual {v1}, Lnet/duceng/midi/MidiTrack;->getEvents()Ljava/util/TreeSet;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/MidiEvent;

    .line 156
    .local v3, "e":Lnet/duceng/midi/MidiEvent;
    instance-of v4, v3, Lnet/duceng/midi/MetaKeySignature;

    if-eqz v4, :cond_1

    .line 157
    move-object v0, v3

    check-cast v0, Lnet/duceng/midi/MetaKeySignature;

    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->keySignature:Lnet/duceng/midi/MetaKeySignature;

    .line 158
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->keySignature:Lnet/duceng/midi/MetaKeySignature;

    return-object v0

    .line 160
    .end local v3    # "e":Lnet/duceng/midi/MidiEvent;
    :cond_1
    goto :goto_1

    .line 161
    .end local v1    # "t":Lnet/duceng/midi/MidiTrack;
    :cond_2
    goto :goto_0

    .line 162
    :cond_3
    new-instance v0, Lnet/duceng/midi/MetaKeySignature;

    invoke-direct {v0}, Lnet/duceng/midi/MetaKeySignature;-><init>()V

    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->keySignature:Lnet/duceng/midi/MetaKeySignature;

    .line 163
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->keySignature:Lnet/duceng/midi/MetaKeySignature;

    return-object v0
.end method

.method public getResolution()I
    .locals 1

    .line 91
    iget v0, p0, Lnet/duceng/midi/MidiFile;->resolution:I

    return v0
.end method

.method public getTempo()Lnet/duceng/midi/MetaTempo;
    .locals 5

    .line 135
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tempo:Lnet/duceng/midi/MetaTempo;

    if-eqz v0, :cond_0

    .line 136
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tempo:Lnet/duceng/midi/MetaTempo;

    return-object v0

    .line 138
    :cond_0
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/MidiTrack;

    .line 139
    .local v1, "t":Lnet/duceng/midi/MidiTrack;
    invoke-virtual {v1}, Lnet/duceng/midi/MidiTrack;->getEvents()Ljava/util/TreeSet;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/MidiEvent;

    .line 140
    .local v3, "e":Lnet/duceng/midi/MidiEvent;
    instance-of v4, v3, Lnet/duceng/midi/MetaTempo;

    if-eqz v4, :cond_1

    .line 141
    move-object v0, v3

    check-cast v0, Lnet/duceng/midi/MetaTempo;

    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->tempo:Lnet/duceng/midi/MetaTempo;

    .line 142
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tempo:Lnet/duceng/midi/MetaTempo;

    return-object v0

    .line 144
    .end local v3    # "e":Lnet/duceng/midi/MidiEvent;
    :cond_1
    goto :goto_1

    .line 145
    .end local v1    # "t":Lnet/duceng/midi/MidiTrack;
    :cond_2
    goto :goto_0

    .line 146
    :cond_3
    new-instance v0, Lnet/duceng/midi/MetaTempo;

    invoke-direct {v0}, Lnet/duceng/midi/MetaTempo;-><init>()V

    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->tempo:Lnet/duceng/midi/MetaTempo;

    .line 147
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tempo:Lnet/duceng/midi/MetaTempo;

    return-object v0
.end method

.method public getTicks()J
    .locals 7

    .line 95
    const-wide/16 v0, 0x0

    .line 96
    .local v0, "length":J
    iget-object v2, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/MidiTrack;

    .line 97
    .local v3, "T":Lnet/duceng/midi/MidiTrack;
    invoke-virtual {v3}, Lnet/duceng/midi/MidiTrack;->getLastTicks()I

    move-result v4

    int-to-long v4, v4

    .line 98
    .local v4, "l":J
    cmp-long v6, v4, v0

    if-lez v6, :cond_0

    .line 99
    move-wide v0, v4

    .line 101
    .end local v3    # "T":Lnet/duceng/midi/MidiTrack;
    .end local v4    # "l":J
    :cond_0
    goto :goto_0

    .line 102
    :cond_1
    return-wide v0
.end method

.method public getTimeSignature()Lnet/duceng/midi/MetaTimeSignature;
    .locals 5

    .line 167
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    if-eqz v0, :cond_0

    .line 168
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    return-object v0

    .line 170
    :cond_0
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/MidiTrack;

    .line 171
    .local v1, "t":Lnet/duceng/midi/MidiTrack;
    invoke-virtual {v1}, Lnet/duceng/midi/MidiTrack;->getEvents()Ljava/util/TreeSet;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/MidiEvent;

    .line 172
    .local v3, "e":Lnet/duceng/midi/MidiEvent;
    instance-of v4, v3, Lnet/duceng/midi/MetaTimeSignature;

    if-eqz v4, :cond_1

    .line 173
    move-object v0, v3

    check-cast v0, Lnet/duceng/midi/MetaTimeSignature;

    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    .line 174
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    return-object v0

    .line 176
    .end local v3    # "e":Lnet/duceng/midi/MidiEvent;
    :cond_1
    goto :goto_1

    .line 177
    .end local v1    # "t":Lnet/duceng/midi/MidiTrack;
    :cond_2
    goto :goto_0

    .line 178
    :cond_3
    new-instance v0, Lnet/duceng/midi/MetaTimeSignature;

    invoke-direct {v0}, Lnet/duceng/midi/MetaTimeSignature;-><init>()V

    iput-object v0, p0, Lnet/duceng/midi/MidiFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    .line 179
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    return-object v0
.end method

.method public getTracks()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/MidiTrack;",
            ">;"
        }
    .end annotation

    .line 106
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    return-object v0
.end method

.method public getType()I
    .locals 1

    .line 77
    iget v0, p0, Lnet/duceng/midi/MidiFile;->type:I

    return v0
.end method

.method public removeTrack(I)V
    .locals 2
    .param p1, "pos"    # I

    .line 116
    if-ltz p1, :cond_1

    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_1

    .line 117
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 118
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iput v0, p0, Lnet/duceng/midi/MidiFile;->count:I

    .line 119
    iget v0, p0, Lnet/duceng/midi/MidiFile;->count:I

    const/4 v1, 0x1

    if-gt v0, v1, :cond_0

    const/4 v1, 0x0

    :cond_0
    iput v1, p0, Lnet/duceng/midi/MidiFile;->type:I

    .line 121
    :cond_1
    return-void
.end method

.method public setResolution(I)V
    .locals 0
    .param p1, "res"    # I

    .line 85
    if-ltz p1, :cond_0

    .line 86
    iput p1, p0, Lnet/duceng/midi/MidiFile;->resolution:I

    .line 88
    :cond_0
    return-void
.end method

.method public setType(I)V
    .locals 2
    .param p1, "t"    # I

    .line 66
    if-gez p1, :cond_0

    .line 67
    const/4 p1, 0x0

    goto :goto_0

    .line 68
    :cond_0
    const/4 v0, 0x2

    if-le p1, v0, :cond_1

    .line 69
    const/4 p1, 0x1

    goto :goto_0

    .line 70
    :cond_1
    if-nez p1, :cond_2

    iget v0, p0, Lnet/duceng/midi/MidiFile;->count:I

    const/4 v1, 0x1

    if-le v0, v1, :cond_2

    .line 71
    const/4 p1, 0x1

    .line 73
    :cond_2
    :goto_0
    iput p1, p0, Lnet/duceng/midi/MidiFile;->type:I

    .line 74
    return-void
.end method

.method public write(Ljava/io/OutputStream;)V
    .locals 2
    .param p1, "out"    # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 124
    const-string v0, "MThd"

    const-string v1, "US-ASCII"

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 125
    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {v0, v1}, Lnet/duceng/midi/MidiUtil;->intToBytes(II)[B

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 126
    iget v0, p0, Lnet/duceng/midi/MidiFile;->type:I

    const/4 v1, 0x2

    invoke-static {v0, v1}, Lnet/duceng/midi/MidiUtil;->intToBytes(II)[B

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 127
    iget v0, p0, Lnet/duceng/midi/MidiFile;->count:I

    invoke-static {v0, v1}, Lnet/duceng/midi/MidiUtil;->intToBytes(II)[B

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 128
    iget v0, p0, Lnet/duceng/midi/MidiFile;->resolution:I

    invoke-static {v0, v1}, Lnet/duceng/midi/MidiUtil;->intToBytes(II)[B

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 129
    iget-object v0, p0, Lnet/duceng/midi/MidiFile;->tracks:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/MidiTrack;

    .line 130
    .local v1, "t":Lnet/duceng/midi/MidiTrack;
    invoke-virtual {v1, p1}, Lnet/duceng/midi/MidiTrack;->write(Ljava/io/OutputStream;)V

    .line 131
    .end local v1    # "t":Lnet/duceng/midi/MidiTrack;
    goto :goto_0

    .line 132
    :cond_0
    return-void
.end method
