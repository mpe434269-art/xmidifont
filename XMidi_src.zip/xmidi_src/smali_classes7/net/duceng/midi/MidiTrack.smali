.class public Lnet/duceng/midi/MidiTrack;
.super Ljava/lang/Object;
.source "MidiTrack.java"


# static fields
.field public static final ID:Ljava/lang/String; = "MTrk"


# instance fields
.field protected channel:B

.field private closed:Z

.field protected controls:Landroid/util/SparseIntArray;

.field protected events:Ljava/util/TreeSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/TreeSet<",
            "Lnet/duceng/midi/MidiEvent;",
            ">;"
        }
    .end annotation
.end field

.field protected program:B

.field private recalculating:Z

.field private size:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/midi/MidiTrack;->size:I

    .line 23
    iput-boolean v0, p0, Lnet/duceng/midi/MidiTrack;->closed:Z

    .line 24
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/midi/MidiTrack;->recalculating:Z

    .line 25
    const/4 v0, -0x1

    iput-byte v0, p0, Lnet/duceng/midi/MidiTrack;->program:B

    .line 26
    iput-byte v0, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    .line 27
    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    iput-object v0, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    .line 28
    new-instance v0, Ljava/util/TreeSet;

    invoke-direct {v0}, Ljava/util/TreeSet;-><init>()V

    iput-object v0, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    .line 29
    return-void
.end method

.method public constructor <init>(Ljava/io/InputStream;)V
    .locals 11
    .param p1, "in"    # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 32
    invoke-direct {p0}, Lnet/duceng/midi/MidiTrack;-><init>()V

    .line 33
    const/4 v0, 0x4

    new-array v1, v0, [B

    .line 34
    .local v1, "buffer":[B
    const/4 v2, 0x0

    invoke-virtual {p1, v1, v2, v0}, Ljava/io/InputStream;->read([BII)I

    .line 35
    new-instance v3, Ljava/lang/String;

    const-string v4, "US-ASCII"

    invoke-direct {v3, v1, v2, v0, v4}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    .line 36
    .local v3, "id":Ljava/lang/String;
    const-string v4, "MTrk"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_8

    .line 39
    invoke-virtual {p1, v1, v2, v0}, Ljava/io/InputStream;->read([BII)I

    .line 40
    invoke-static {v1, v2, v0}, Lnet/duceng/midi/MidiUtil;->bytesToInt([BII)I

    move-result v0

    iput v0, p0, Lnet/duceng/midi/MidiTrack;->size:I

    .line 41
    const/4 v0, 0x0

    .line 42
    .local v0, "totalTicks":I
    const/4 v2, -0x1

    .line 43
    .local v2, "firstTick":I
    const/4 v4, 0x0

    .line 45
    .local v4, "noteSeen":Z
    :goto_0
    invoke-static {p1}, Lnet/duceng/midi/MidiUtil;->readVInt(Ljava/io/InputStream;)I

    move-result v5

    .line 46
    .local v5, "delta":I
    add-int/2addr v0, v5

    .line 47
    invoke-static {v0, v5, p1}, Lnet/duceng/midi/MidiEvent;->parse(IILjava/io/InputStream;)Lnet/duceng/midi/MidiEvent;

    move-result-object v6

    .line 48
    .local v6, "E":Lnet/duceng/midi/MidiEvent;
    if-nez v6, :cond_0

    .line 49
    sget-object v7, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v8, "Event skipped!"

    invoke-virtual {v7, v8}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto/16 :goto_4

    .line 51
    :cond_0
    instance-of v7, v6, Lnet/duceng/midi/EventMeta;

    if-eqz v7, :cond_2

    move-object v7, v6

    check-cast v7, Lnet/duceng/midi/EventMeta;

    invoke-virtual {v7}, Lnet/duceng/midi/EventMeta;->getType()S

    move-result v7

    const/16 v8, 0x2f

    if-ne v7, v8, :cond_2

    .line 52
    nop

    .line 74
    .end local v5    # "delta":I
    .end local v6    # "E":Lnet/duceng/midi/MidiEvent;
    if-lez v2, :cond_1

    iget-object v5, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v5}, Ljava/util/TreeSet;->size()I

    move-result v5

    if-lez v5, :cond_1

    .line 75
    iget-object v5, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v5}, Ljava/util/TreeSet;->first()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/midi/MidiEvent;

    iget v6, v5, Lnet/duceng/midi/MidiEvent;->delta:I

    add-int/2addr v6, v2

    iput v6, v5, Lnet/duceng/midi/MidiEvent;->delta:I

    .line 77
    :cond_1
    return-void

    .line 54
    .restart local v5    # "delta":I
    .restart local v6    # "E":Lnet/duceng/midi/MidiEvent;
    :cond_2
    const/4 v7, -0x1

    if-ne v2, v7, :cond_3

    iget v8, v6, Lnet/duceng/midi/MidiEvent;->tick:I

    goto :goto_1

    :cond_3
    move v8, v2

    :goto_1
    move v2, v8

    .line 55
    instance-of v8, v6, Lnet/duceng/midi/EventChannel;

    if-eqz v8, :cond_7

    .line 56
    move-object v8, v6

    check-cast v8, Lnet/duceng/midi/EventChannel;

    .line 57
    .local v8, "ec":Lnet/duceng/midi/EventChannel;
    iget-byte v9, v8, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v10, 0x8

    if-eq v9, v10, :cond_6

    iget-byte v9, v8, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v10, 0x9

    if-ne v9, v10, :cond_4

    goto :goto_2

    .line 62
    :cond_4
    if-nez v4, :cond_7

    .line 63
    iget-byte v7, v8, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v9, 0xc

    if-ne v7, v9, :cond_5

    .line 64
    iget-byte v7, v8, Lnet/duceng/midi/EventChannel;->channel:B

    iput-byte v7, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    .line 65
    iget-byte v7, v8, Lnet/duceng/midi/EventChannel;->value1:B

    iput-byte v7, p0, Lnet/duceng/midi/MidiTrack;->program:B

    goto :goto_3

    .line 66
    :cond_5
    iget-byte v7, v8, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v9, 0xb

    if-ne v7, v9, :cond_7

    .line 67
    iget-object v7, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    iget-byte v9, v8, Lnet/duceng/midi/EventChannel;->value1:B

    iget-byte v10, v8, Lnet/duceng/midi/EventChannel;->value2:B

    invoke-virtual {v7, v9, v10}, Landroid/util/SparseIntArray;->put(II)V

    goto :goto_3

    .line 58
    :cond_6
    :goto_2
    const/4 v4, 0x1

    .line 59
    iget-byte v9, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    if-ne v9, v7, :cond_7

    .line 60
    iget-byte v7, v8, Lnet/duceng/midi/EventChannel;->channel:B

    iput-byte v7, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    .line 71
    .end local v8    # "ec":Lnet/duceng/midi/EventChannel;
    :cond_7
    :goto_3
    iget-object v7, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v7, v6}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    .line 73
    .end local v5    # "delta":I
    .end local v6    # "E":Lnet/duceng/midi/MidiEvent;
    :goto_4
    goto/16 :goto_0

    .line 37
    .end local v0    # "totalTicks":I
    .end local v2    # "firstTick":I
    .end local v4    # "noteSeen":Z
    :cond_8
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v2, "Track id did not match MTrk!"

    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private recalculate()V
    .locals 5

    .line 141
    iget-byte v0, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    const/4 v1, -0x1

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    const/4 v0, 0x3

    :goto_0
    iput v0, p0, Lnet/duceng/midi/MidiTrack;->size:I

    .line 142
    iget v0, p0, Lnet/duceng/midi/MidiTrack;->size:I

    iget-object v1, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    invoke-virtual {v1}, Landroid/util/SparseIntArray;->size()I

    move-result v1

    mul-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    iput v0, p0, Lnet/duceng/midi/MidiTrack;->size:I

    .line 143
    iget-object v0, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v0}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/MidiEvent;

    .line 144
    .local v1, "e":Lnet/duceng/midi/MidiEvent;
    iget v3, p0, Lnet/duceng/midi/MidiTrack;->size:I

    invoke-virtual {v1}, Lnet/duceng/midi/MidiEvent;->getSize()I

    move-result v4

    add-int/2addr v3, v4

    iput v3, p0, Lnet/duceng/midi/MidiTrack;->size:I

    .line 145
    .end local v1    # "e":Lnet/duceng/midi/MidiEvent;
    goto :goto_1

    .line 146
    :cond_1
    iput-boolean v2, p0, Lnet/duceng/midi/MidiTrack;->recalculating:Z

    .line 147
    return-void
.end method


# virtual methods
.method public close()V
    .locals 5

    .line 217
    const/4 v0, 0x0

    .line 218
    .local v0, "lastTick":I
    iget-object v1, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v1}, Ljava/util/TreeSet;->size()I

    move-result v1

    if-lez v1, :cond_0

    .line 219
    iget-object v1, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v1}, Ljava/util/TreeSet;->last()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/MidiEvent;

    .line 220
    .local v1, "last":Lnet/duceng/midi/MidiEvent;
    invoke-virtual {v1}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v2

    add-int/lit8 v0, v2, 0x1

    .line 222
    .end local v1    # "last":Lnet/duceng/midi/MidiEvent;
    :cond_0
    const/4 v1, 0x0

    new-array v2, v1, [B

    .line 223
    .local v2, "buff":[B
    new-instance v3, Lnet/duceng/midi/EventMeta;

    const/16 v4, 0x2f

    invoke-direct {v3, v0, v1, v4, v2}, Lnet/duceng/midi/EventMeta;-><init>(IIS[B)V

    move-object v1, v3

    .line 224
    .local v1, "eot":Lnet/duceng/midi/EventMeta;
    invoke-virtual {p0, v1}, Lnet/duceng/midi/MidiTrack;->insert(Lnet/duceng/midi/MidiEvent;)V

    .line 225
    return-void
.end method

.method public getChannel()B
    .locals 1

    .line 80
    iget-byte v0, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    return v0
.end method

.method public getControl(B)B
    .locals 1
    .param p1, "t"    # B

    .line 108
    iget-object v0, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseIntArray;->indexOfKey(I)I

    move-result v0

    if-ltz v0, :cond_0

    .line 109
    iget-object v0, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseIntArray;->get(I)I

    move-result v0

    int-to-byte v0, v0

    return v0

    .line 111
    :cond_0
    const/4 v0, -0x1

    return v0
.end method

.method public getControls()Landroid/util/SparseIntArray;
    .locals 1

    .line 122
    iget-object v0, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    return-object v0
.end method

.method public getCount()I
    .locals 2

    .line 130
    iget-byte v0, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    :goto_0
    iget-object v1, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    invoke-virtual {v1}, Landroid/util/SparseIntArray;->size()I

    move-result v1

    add-int/2addr v0, v1

    iget-object v1, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v1}, Ljava/util/TreeSet;->size()I

    move-result v1

    add-int/2addr v0, v1

    return v0
.end method

.method public getEvents()Ljava/util/TreeSet;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/TreeSet<",
            "Lnet/duceng/midi/MidiEvent;",
            ">;"
        }
    .end annotation

    .line 126
    iget-object v0, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    return-object v0
.end method

.method public getLastTicks()I
    .locals 1

    .line 150
    iget-object v0, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v0}, Ljava/util/TreeSet;->size()I

    move-result v0

    if-nez v0, :cond_0

    .line 151
    const/4 v0, 0x0

    return v0

    .line 153
    :cond_0
    iget-object v0, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v0}, Ljava/util/TreeSet;->last()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/midi/MidiEvent;

    invoke-virtual {v0}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v0

    return v0
.end method

.method public getProgram()B
    .locals 1

    .line 97
    iget-byte v0, p0, Lnet/duceng/midi/MidiTrack;->program:B

    return v0
.end method

.method public getSize()I
    .locals 1

    .line 134
    iget-boolean v0, p0, Lnet/duceng/midi/MidiTrack;->recalculating:Z

    if-eqz v0, :cond_0

    .line 135
    invoke-direct {p0}, Lnet/duceng/midi/MidiTrack;->recalculate()V

    .line 137
    :cond_0
    iget v0, p0, Lnet/duceng/midi/MidiTrack;->size:I

    return v0
.end method

.method public insert(Lnet/duceng/midi/MidiEvent;)V
    .locals 5
    .param p1, "e"    # Lnet/duceng/midi/MidiEvent;

    .line 157
    if-eqz p1, :cond_4

    .line 158
    iget-boolean v0, p0, Lnet/duceng/midi/MidiTrack;->closed:Z

    if-nez v0, :cond_3

    .line 161
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/midi/MidiTrack;->recalculating:Z

    .line 162
    iget-object v1, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v1, p1}, Ljava/util/TreeSet;->floor(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/MidiEvent;

    .line 163
    .local v1, "prev":Lnet/duceng/midi/MidiEvent;
    iget-object v2, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v2, p1}, Ljava/util/TreeSet;->ceiling(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/midi/MidiEvent;

    .line 164
    .local v2, "next":Lnet/duceng/midi/MidiEvent;
    iget-object v3, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v3, p1}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    .line 165
    if-eqz v1, :cond_0

    .line 166
    invoke-virtual {p1}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v3

    invoke-virtual {v1}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v4

    sub-int/2addr v3, v4

    invoke-virtual {p1, v3}, Lnet/duceng/midi/MidiEvent;->setDelta(I)V

    goto :goto_0

    .line 168
    :cond_0
    invoke-virtual {p1}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v3

    invoke-virtual {p1, v3}, Lnet/duceng/midi/MidiEvent;->setDelta(I)V

    .line 170
    :goto_0
    if-eqz v2, :cond_1

    .line 171
    invoke-virtual {v2}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v3

    invoke-virtual {p1}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v4

    sub-int/2addr v3, v4

    invoke-virtual {v2, v3}, Lnet/duceng/midi/MidiEvent;->setDelta(I)V

    .line 173
    :cond_1
    instance-of v3, p1, Lnet/duceng/midi/EventMeta;

    if-eqz v3, :cond_4

    move-object v3, p1

    check-cast v3, Lnet/duceng/midi/EventMeta;

    invoke-virtual {v3}, Lnet/duceng/midi/EventMeta;->getType()S

    move-result v3

    const/16 v4, 0x2f

    if-ne v3, v4, :cond_4

    .line 174
    if-nez v2, :cond_2

    .line 177
    iput-boolean v0, p0, Lnet/duceng/midi/MidiTrack;->closed:Z

    goto :goto_1

    .line 175
    :cond_2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v3, "Attempting to insert END_OF_TRACK before an existing event. Use close() when finished with MidiTrack."

    invoke-direct {v0, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 159
    .end local v1    # "prev":Lnet/duceng/midi/MidiEvent;
    .end local v2    # "next":Lnet/duceng/midi/MidiEvent;
    :cond_3
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Error: Cannot add an event to a closed track."

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 180
    :cond_4
    :goto_1
    return-void
.end method

.method public remove(Lnet/duceng/midi/MidiEvent;)Z
    .locals 7
    .param p1, "e"    # Lnet/duceng/midi/MidiEvent;

    .line 184
    iget-object v0, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v0}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 185
    .local v0, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Lnet/duceng/midi/MidiEvent;>;"
    const/4 v1, 0x0

    .line 186
    .local v1, "prev":Lnet/duceng/midi/MidiEvent;
    const/4 v2, 0x0

    .line 188
    .local v2, "curr":Lnet/duceng/midi/MidiEvent;
    :goto_0
    const/4 v3, 0x0

    .line 189
    .local v3, "next":Lnet/duceng/midi/MidiEvent;
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_0

    .line 190
    goto :goto_1

    .line 192
    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/midi/MidiEvent;

    .line 193
    .local v4, "next2":Lnet/duceng/midi/MidiEvent;
    move-object v3, v4

    .line 194
    invoke-virtual {p1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_4

    .line 195
    nop

    .line 200
    .end local v4    # "next2":Lnet/duceng/midi/MidiEvent;
    :goto_1
    const/4 v4, 0x1

    if-nez v3, :cond_1

    .line 201
    iput-boolean v4, p0, Lnet/duceng/midi/MidiTrack;->recalculating:Z

    .line 202
    iget-object v4, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v4, v2}, Ljava/util/TreeSet;->remove(Ljava/lang/Object;)Z

    move-result v4

    return v4

    .line 204
    :cond_1
    iget-object v5, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v5, v2}, Ljava/util/TreeSet;->remove(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_2

    .line 205
    const/4 v4, 0x0

    return v4

    .line 207
    :cond_2
    if-eqz v1, :cond_3

    .line 208
    invoke-virtual {v3}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v5

    invoke-virtual {v1}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v6

    sub-int/2addr v5, v6

    invoke-virtual {v3, v5}, Lnet/duceng/midi/MidiEvent;->setDelta(I)V

    goto :goto_2

    .line 210
    :cond_3
    invoke-virtual {v3}, Lnet/duceng/midi/MidiEvent;->getTick()I

    move-result v5

    invoke-virtual {v3, v5}, Lnet/duceng/midi/MidiEvent;->setDelta(I)V

    .line 212
    :goto_2
    iput-boolean v4, p0, Lnet/duceng/midi/MidiTrack;->recalculating:Z

    .line 213
    return v4

    .line 197
    .restart local v4    # "next2":Lnet/duceng/midi/MidiEvent;
    :cond_4
    move-object v1, v2

    .line 198
    move-object v2, v3

    .line 199
    .end local v4    # "next2":Lnet/duceng/midi/MidiEvent;
    goto :goto_0
.end method

.method public setChannel(B)V
    .locals 3
    .param p1, "c"    # B

    .line 84
    iget-byte v0, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    .line 85
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/midi/MidiTrack;->recalculating:Z

    .line 87
    :cond_0
    iput-byte p1, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    .line 88
    iget-object v0, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v0}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/MidiEvent;

    .line 89
    .local v1, "e":Lnet/duceng/midi/MidiEvent;
    instance-of v2, v1, Lnet/duceng/midi/EventChannel;

    if-eqz v2, :cond_1

    .line 90
    move-object v2, v1

    check-cast v2, Lnet/duceng/midi/EventChannel;

    .line 91
    .local v2, "ec":Lnet/duceng/midi/EventChannel;
    iput-byte p1, v2, Lnet/duceng/midi/EventChannel;->channel:B

    .line 93
    .end local v1    # "e":Lnet/duceng/midi/MidiEvent;
    .end local v2    # "ec":Lnet/duceng/midi/EventChannel;
    :cond_1
    goto :goto_0

    .line 94
    :cond_2
    return-void
.end method

.method public setControl(BB)V
    .locals 1
    .param p1, "t"    # B
    .param p2, "v"    # B

    .line 115
    iget-object v0, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseIntArray;->indexOfKey(I)I

    move-result v0

    if-gez v0, :cond_0

    .line 116
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/midi/MidiTrack;->recalculating:Z

    .line 118
    :cond_0
    iget-object v0, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    invoke-virtual {v0, p1, p2}, Landroid/util/SparseIntArray;->put(II)V

    .line 119
    return-void
.end method

.method public setProgram(B)V
    .locals 2
    .param p1, "p"    # B

    .line 101
    iget-byte v0, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    .line 102
    const/4 v0, 0x1

    iput-boolean v0, p0, Lnet/duceng/midi/MidiTrack;->recalculating:Z

    .line 104
    :cond_0
    iput-byte p1, p0, Lnet/duceng/midi/MidiTrack;->program:B

    .line 105
    return-void
.end method

.method public write(Ljava/io/OutputStream;)V
    .locals 7
    .param p1, "out"    # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 228
    iget-boolean v0, p0, Lnet/duceng/midi/MidiTrack;->closed:Z

    if-nez v0, :cond_0

    .line 229
    invoke-virtual {p0}, Lnet/duceng/midi/MidiTrack;->close()V

    .line 231
    :cond_0
    iget-boolean v0, p0, Lnet/duceng/midi/MidiTrack;->recalculating:Z

    if-eqz v0, :cond_1

    .line 232
    invoke-direct {p0}, Lnet/duceng/midi/MidiTrack;->recalculate()V

    .line 234
    :cond_1
    const-string v0, "MTrk"

    const-string v1, "US-ASCII"

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 235
    iget v0, p0, Lnet/duceng/midi/MidiTrack;->size:I

    const/4 v1, 0x4

    invoke-static {v0, v1}, Lnet/duceng/midi/MidiUtil;->intToBytes(II)[B

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 236
    new-instance v0, Lnet/duceng/midi/EventChannel;

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/16 v3, 0xc

    const/4 v4, 0x0

    move-object v1, v0

    invoke-direct/range {v1 .. v6}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    .line 237
    .local v0, "ec":Lnet/duceng/midi/EventChannel;
    iget-byte v1, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    const/4 v2, -0x1

    if-eq v1, v2, :cond_2

    .line 238
    const/16 v1, 0xc

    invoke-virtual {v0, v1}, Lnet/duceng/midi/EventChannel;->setType(B)V

    .line 239
    iget-byte v1, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    invoke-virtual {v0, v1}, Lnet/duceng/midi/EventChannel;->setChannel(B)V

    .line 240
    iget-byte v1, p0, Lnet/duceng/midi/MidiTrack;->program:B

    invoke-virtual {v0, v1}, Lnet/duceng/midi/EventChannel;->setValue1(B)V

    .line 241
    invoke-virtual {v0, p1}, Lnet/duceng/midi/EventChannel;->write(Ljava/io/OutputStream;)V

    .line 243
    :cond_2
    const/16 v1, 0xb

    invoke-virtual {v0, v1}, Lnet/duceng/midi/EventChannel;->setType(B)V

    .line 244
    iget-byte v1, p0, Lnet/duceng/midi/MidiTrack;->channel:B

    invoke-virtual {v0, v1}, Lnet/duceng/midi/EventChannel;->setChannel(B)V

    .line 245
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    iget-object v2, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    invoke-virtual {v2}, Landroid/util/SparseIntArray;->size()I

    move-result v2

    if-ge v1, v2, :cond_3

    .line 246
    iget-object v2, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    invoke-virtual {v2, v1}, Landroid/util/SparseIntArray;->keyAt(I)I

    move-result v2

    int-to-byte v2, v2

    invoke-virtual {v0, v2}, Lnet/duceng/midi/EventChannel;->setValue1(B)V

    .line 247
    iget-object v2, p0, Lnet/duceng/midi/MidiTrack;->controls:Landroid/util/SparseIntArray;

    invoke-virtual {v2, v1}, Landroid/util/SparseIntArray;->valueAt(I)I

    move-result v2

    int-to-byte v2, v2

    invoke-virtual {v0, v2}, Lnet/duceng/midi/EventChannel;->setValue2(B)V

    .line 248
    invoke-virtual {v0, p1}, Lnet/duceng/midi/EventChannel;->write(Ljava/io/OutputStream;)V

    .line 245
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 250
    .end local v1    # "i":I
    :cond_3
    iget-object v1, p0, Lnet/duceng/midi/MidiTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v1}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/midi/MidiEvent;

    .line 251
    .local v2, "e":Lnet/duceng/midi/MidiEvent;
    invoke-virtual {v2, p1}, Lnet/duceng/midi/MidiEvent;->write(Ljava/io/OutputStream;)V

    .line 252
    .end local v2    # "e":Lnet/duceng/midi/MidiEvent;
    goto :goto_1

    .line 253
    :cond_4
    return-void
.end method
