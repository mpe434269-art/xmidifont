.class public Lnet/duceng/midi/MidiUtil;
.super Ljava/lang/Object;
.source "MidiUtil.java"


# static fields
.field private static final HEX:Ljava/lang/String; = "0123456789ABCDEF"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static bpmToMpqn(I)I
    .locals 1
    .param p0, "bpm"    # I

    .line 19
    const v0, 0x3938700

    div-int/2addr v0, p0

    return v0
.end method

.method public static byteToHex(B)Ljava/lang/String;
    .locals 5
    .param p0, "b"    # B

    .line 149
    and-int/lit16 v0, p0, 0xf0

    shr-int/lit8 v0, v0, 0x4

    .line 150
    .local v0, "high":I
    and-int/lit8 v1, p0, 0xf

    .line 151
    .local v1, "low":I
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "0123456789ABCDEF"

    invoke-virtual {v3, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method public static bytesEqual([B[BII)Z
    .locals 3
    .param p0, "buf1"    # [B
    .param p1, "buf2"    # [B
    .param p2, "off"    # I
    .param p3, "len"    # I

    .line 132
    move v0, p2

    .local v0, "i":I
    :goto_0
    add-int v1, p2, p3

    if-ge v0, v1, :cond_2

    .line 133
    array-length v1, p0

    if-ge v0, v1, :cond_1

    array-length v1, p1

    if-ge v0, v1, :cond_1

    aget-byte v1, p0, v0

    aget-byte v2, p1, v0

    if-eq v1, v2, :cond_0

    goto :goto_1

    .line 132
    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 134
    :cond_1
    :goto_1
    const/4 v1, 0x0

    return v1

    .line 137
    .end local v0    # "i":I
    :cond_2
    const/4 v0, 0x1

    return v0
.end method

.method public static bytesToHex([B)Ljava/lang/String;
    .locals 6
    .param p0, "b"    # [B

    .line 155
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 156
    .local v0, "sb":Ljava/lang/StringBuilder;
    array-length v1, p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-byte v3, p0, v2

    .line 157
    .local v3, "b2":B
    invoke-static {v3}, Lnet/duceng/midi/MidiUtil;->byteToHex(B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 156
    .end local v3    # "b2":B
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 159
    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public static bytesToInt([BII)I
    .locals 4
    .param p0, "buff"    # [B
    .param p1, "off"    # I
    .param p2, "len"    # I

    .line 53
    const/4 v0, 0x0

    .line 54
    .local v0, "num":I
    const/4 v1, 0x0

    .line 55
    .local v1, "shift":I
    add-int v2, p1, p2

    add-int/lit8 v2, v2, -0x1

    .local v2, "i":I
    :goto_0
    if-lt v2, p1, :cond_0

    .line 56
    aget-byte v3, p0, v2

    and-int/lit16 v3, v3, 0xff

    shl-int/2addr v3, v1

    add-int/2addr v0, v3

    .line 57
    add-int/lit8 v1, v1, 0x8

    .line 55
    add-int/lit8 v2, v2, -0x1

    goto :goto_0

    .line 59
    .end local v2    # "i":I
    :cond_0
    return v0
.end method

.method public static extractBytes([BII)[B
    .locals 3
    .param p0, "buffer"    # [B
    .param p1, "off"    # I
    .param p2, "len"    # I

    .line 141
    new-array v0, p2, [B

    .line 142
    .local v0, "ret":[B
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    if-ge v1, p2, :cond_0

    .line 143
    add-int v2, p1, v1

    aget-byte v2, p0, v2

    aput-byte v2, v0, v1

    .line 142
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 145
    .end local v1    # "i":I
    :cond_0
    return-object v0
.end method

.method public static intToBytes(I)[B
    .locals 6
    .param p0, "val"    # I

    .line 27
    shr-int/lit8 v0, p0, 0x18

    and-int/lit16 v0, v0, 0xff

    int-to-byte v0, v0

    shr-int/lit8 v1, p0, 0x10

    and-int/lit16 v1, v1, 0xff

    int-to-byte v1, v1

    shr-int/lit8 v2, p0, 0x8

    and-int/lit16 v2, v2, 0xff

    int-to-byte v2, v2

    and-int/lit16 v3, p0, 0xff

    int-to-byte v3, v3

    const/4 v4, 0x4

    new-array v4, v4, [B

    const/4 v5, 0x0

    aput-byte v0, v4, v5

    const/4 v0, 0x1

    aput-byte v1, v4, v0

    const/4 v0, 0x2

    aput-byte v2, v4, v0

    const/4 v0, 0x3

    aput-byte v3, v4, v0

    move-object v0, v4

    .line 28
    .local v0, "buff":[B
    return-object v0
.end method

.method public static intToBytes(II)[B
    .locals 5
    .param p0, "val"    # I
    .param p1, "byteCount"    # I

    .line 118
    new-array v0, p1, [B

    .line 119
    .local v0, "buffer":[B
    new-array v1, p1, [I

    .line 120
    .local v1, "ints":[I
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    if-ge v2, p1, :cond_1

    .line 121
    and-int/lit16 v3, p0, 0xff

    aput v3, v1, v2

    .line 122
    sub-int v3, p1, v2

    add-int/lit8 v3, v3, -0x1

    aget v4, v1, v2

    int-to-byte v4, v4

    aput-byte v4, v0, v3

    .line 123
    shr-int/lit8 p0, p0, 0x8

    .line 124
    if-nez p0, :cond_0

    .line 125
    goto :goto_1

    .line 120
    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 128
    .end local v2    # "i":I
    :cond_1
    :goto_1
    return-object v0
.end method

.method public static mpqnToBpm(I)I
    .locals 1
    .param p0, "mpqn"    # I

    .line 23
    const v0, 0x3938700

    div-int/2addr v0, p0

    return v0
.end method

.method public static msToTicks(III)I
    .locals 4
    .param p0, "ms"    # I
    .param p1, "mpqn"    # I
    .param p2, "resolution"    # I

    .line 15
    int-to-long v0, p0

    const-wide/16 v2, 0x3e8

    mul-long v0, v0, v2

    int-to-long v2, p2

    mul-long v0, v0, v2

    int-to-long v2, p1

    div-long/2addr v0, v2

    long-to-int v1, v0

    return v1
.end method

.method public static readFully(Ljava/io/InputStream;[B)I
    .locals 2
    .param p0, "in"    # Ljava/io/InputStream;
    .param p1, "buf"    # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 64
    const/4 v0, 0x0

    .line 65
    .local v0, "off":I
    :goto_0
    array-length v1, p1

    if-ge v0, v1, :cond_1

    .line 66
    array-length v1, p1

    sub-int/2addr v1, v0

    invoke-virtual {p0, p1, v0, v1}, Ljava/io/InputStream;->read([BII)I

    move-result v1

    .line 67
    .local v1, "n":I
    if-gtz v1, :cond_0

    .line 68
    goto :goto_1

    .line 70
    :cond_0
    add-int/2addr v0, v1

    .line 71
    .end local v1    # "n":I
    goto :goto_0

    .line 72
    :cond_1
    :goto_1
    return v0
.end method

.method public static readInt(Ljava/io/InputStream;)I
    .locals 6
    .param p0, "in"    # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 82
    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    move-result v0

    .line 83
    .local v0, "byte1":I
    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    move-result v1

    .line 84
    .local v1, "byte2":I
    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    move-result v2

    .line 85
    .local v2, "byte3":I
    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    move-result v3

    .line 86
    .local v3, "byte4":I
    shl-int/lit8 v4, v0, 0x18

    shl-int/lit8 v5, v1, 0x10

    or-int/2addr v4, v5

    shl-int/lit8 v5, v2, 0x8

    or-int/2addr v4, v5

    or-int/2addr v4, v3

    return v4
.end method

.method public static readString(Ljava/io/InputStream;I)Ljava/lang/String;
    .locals 2
    .param p0, "in"    # Ljava/io/InputStream;
    .param p1, "size"    # I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 76
    new-array v0, p1, [B

    .line 77
    .local v0, "buffer":[B
    invoke-virtual {p0, v0}, Ljava/io/InputStream;->read([B)I

    .line 78
    new-instance v1, Ljava/lang/String;

    invoke-direct {v1, v0}, Ljava/lang/String;-><init>([B)V

    return-object v1
.end method

.method public static readVInt(Ljava/io/InputStream;)I
    .locals 9
    .param p0, "in"    # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 90
    const/4 v0, 0x4

    new-array v1, v0, [I

    .line 91
    .local v1, "ints":[I
    const/4 v2, 0x1

    .line 92
    .local v2, "mSizeInBytes":I
    const/4 v3, 0x0

    .line 93
    .local v3, "mValue":I
    const/4 v4, 0x0

    .line 94
    .local v4, "shift":I
    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    move-result v5

    .line 95
    .local v5, "b":I
    :goto_0
    if-gt v2, v0, :cond_2

    .line 96
    and-int/lit16 v6, v5, 0x80

    if-lez v6, :cond_0

    const/4 v6, 0x1

    goto :goto_1

    :cond_0
    const/4 v6, 0x0

    .line 97
    .local v6, "variable":Z
    :goto_1
    if-nez v6, :cond_1

    .line 98
    add-int/lit8 v0, v2, -0x1

    and-int/lit8 v7, v5, 0x7f

    aput v7, v1, v0

    .line 99
    goto :goto_2

    .line 101
    :cond_1
    add-int/lit8 v7, v2, -0x1

    and-int/lit8 v8, v5, 0x7f

    aput v8, v1, v7

    .line 102
    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    move-result v5

    .line 103
    nop

    .end local v6    # "variable":Z
    add-int/lit8 v2, v2, 0x1

    .line 104
    goto :goto_0

    .line 105
    :cond_2
    :goto_2
    const/4 v0, 0x1

    .local v0, "i":I
    :goto_3
    if-ge v0, v2, :cond_3

    .line 106
    add-int/lit8 v4, v4, 0x7

    .line 105
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    .line 108
    .end local v0    # "i":I
    :cond_3
    new-array v0, v2, [B

    .line 109
    .local v0, "mBytes":[B
    const/4 v6, 0x0

    .local v6, "i2":I
    :goto_4
    if-ge v6, v2, :cond_4

    .line 110
    aget v7, v1, v6

    int-to-byte v7, v7

    aput-byte v7, v0, v6

    .line 111
    aget v7, v1, v6

    shl-int/2addr v7, v4

    add-int/2addr v3, v7

    .line 112
    add-int/lit8 v4, v4, -0x7

    .line 109
    add-int/lit8 v6, v6, 0x1

    goto :goto_4

    .line 114
    .end local v6    # "i2":I
    :cond_4
    return v3
.end method

.method public static ticksToMs(III)I
    .locals 4
    .param p0, "ticks"    # I
    .param p1, "mpqn"    # I
    .param p2, "resolution"    # I

    .line 11
    int-to-long v0, p0

    int-to-long v2, p1

    mul-long v0, v0, v2

    const-wide/16 v2, 0x3e8

    div-long/2addr v0, v2

    int-to-long v2, p2

    div-long/2addr v0, v2

    long-to-int v1, v0

    return v1
.end method

.method public static vintToBytes(I)[B
    .locals 12
    .param p0, "val"    # I

    .line 32
    shr-int/lit8 v0, p0, 0x15

    and-int/lit8 v0, v0, 0x7f

    int-to-byte v0, v0

    .line 33
    .local v0, "b1":B
    shr-int/lit8 v1, p0, 0xe

    and-int/lit8 v1, v1, 0x7f

    int-to-byte v1, v1

    .line 34
    .local v1, "b2":B
    shr-int/lit8 v2, p0, 0x7

    and-int/lit8 v2, v2, 0x7f

    int-to-byte v2, v2

    .line 35
    .local v2, "b3":B
    and-int/lit8 v3, p0, 0x7f

    int-to-byte v3, v3

    .line 36
    .local v3, "b4":B
    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-lez v0, :cond_0

    .line 37
    or-int/lit16 v8, v0, 0x80

    int-to-byte v8, v8

    or-int/lit16 v9, v1, 0x80

    int-to-byte v9, v9

    or-int/lit16 v10, v2, 0x80

    int-to-byte v10, v10

    const/4 v11, 0x4

    new-array v11, v11, [B

    aput-byte v8, v11, v7

    aput-byte v9, v11, v6

    aput-byte v10, v11, v5

    aput-byte v3, v11, v4

    move-object v4, v11

    .line 38
    .local v4, "buff":[B
    return-object v4

    .line 40
    .end local v4    # "buff":[B
    :cond_0
    if-lez v1, :cond_1

    .line 41
    or-int/lit16 v8, v1, 0x80

    int-to-byte v8, v8

    or-int/lit16 v9, v2, 0x80

    int-to-byte v9, v9

    new-array v4, v4, [B

    aput-byte v8, v4, v7

    aput-byte v9, v4, v6

    aput-byte v3, v4, v5

    .line 42
    .local v4, "buff2":[B
    return-object v4

    .line 44
    .end local v4    # "buff2":[B
    :cond_1
    if-lez v2, :cond_2

    .line 45
    or-int/lit16 v4, v2, 0x80

    int-to-byte v4, v4

    new-array v5, v5, [B

    aput-byte v4, v5, v7

    aput-byte v3, v5, v6

    move-object v4, v5

    .line 46
    .local v4, "buff3":[B
    return-object v4

    .line 48
    .end local v4    # "buff3":[B
    :cond_2
    new-array v4, v6, [B

    aput-byte v3, v4, v7

    .line 49
    .local v4, "buff4":[B
    return-object v4
.end method
