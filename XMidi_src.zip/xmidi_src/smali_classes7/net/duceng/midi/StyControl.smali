.class public Lnet/duceng/midi/StyControl;
.super Ljava/lang/Object;
.source "StyControl.java"


# static fields
.field protected static final Bass:B = 0x3t

.field protected static final Bypass:B = 0x0t

.field protected static final Chord:B = 0x2t

.field private static DEFAULT:Lnet/duceng/midi/StyControl; = null

.field protected static final HarmonicMinor:B = 0x5t

.field protected static final MelodicMinor:B = 0x4t

.field protected static final Melody:B = 0x1t

.field protected static final RootFix:B = 0x1t

.field protected static final RootTran:B


# instance fields
.field protected chord:B

.field protected chordMute:[B

.field protected destination:B

.field protected editable:B

.field protected highLimit:B

.field protected highkey:B

.field protected lowLimit:B

.field protected name:Ljava/lang/String;

.field protected noteMute:[B

.field protected noteRule:B

.field protected noteTable:B

.field protected ntt:B

.field protected retriggerRule:B

.field protected root:B

.field protected source:B


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 8
    const/4 v0, 0x0

    sput-object v0, Lnet/duceng/midi/StyControl;->DEFAULT:Lnet/duceng/midi/StyControl;

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    .line 71
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 72
    const/4 v0, 0x2

    new-array v1, v0, [B

    iput-object v1, p0, Lnet/duceng/midi/StyControl;->noteMute:[B

    .line 73
    const/4 v1, 0x5

    new-array v1, v1, [B

    iput-object v1, p0, Lnet/duceng/midi/StyControl;->chordMute:[B

    .line 74
    const/4 v1, -0x1

    iput-byte v1, p0, Lnet/duceng/midi/StyControl;->source:B

    .line 75
    iput-byte v1, p0, Lnet/duceng/midi/StyControl;->destination:B

    .line 76
    const-string v2, "DEFAULT"

    iput-object v2, p0, Lnet/duceng/midi/StyControl;->name:Ljava/lang/String;

    .line 77
    const/4 v2, 0x0

    iput-byte v2, p0, Lnet/duceng/midi/StyControl;->root:B

    .line 78
    iput-byte v0, p0, Lnet/duceng/midi/StyControl;->chord:B

    .line 79
    iput-byte v1, p0, Lnet/duceng/midi/StyControl;->noteRule:B

    .line 80
    iput-byte v1, p0, Lnet/duceng/midi/StyControl;->noteTable:B

    .line 81
    const/16 v0, 0xb

    iput-byte v0, p0, Lnet/duceng/midi/StyControl;->highkey:B

    .line 82
    iput-byte v2, p0, Lnet/duceng/midi/StyControl;->lowLimit:B

    .line 83
    const/16 v0, 0x7f

    iput-byte v0, p0, Lnet/duceng/midi/StyControl;->highLimit:B

    .line 84
    iput-byte v1, p0, Lnet/duceng/midi/StyControl;->retriggerRule:B

    .line 85
    return-void
.end method

.method public constructor <init>([B)V
    .locals 4
    .param p1, "data"    # [B

    .line 30
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 31
    const/4 v0, 0x2

    new-array v0, v0, [B

    iput-object v0, p0, Lnet/duceng/midi/StyControl;->noteMute:[B

    .line 32
    const/4 v0, 0x5

    new-array v0, v0, [B

    iput-object v0, p0, Lnet/duceng/midi/StyControl;->chordMute:[B

    .line 33
    const/4 v0, 0x0

    aget-byte v1, p1, v0

    iput-byte v1, p0, Lnet/duceng/midi/StyControl;->source:B

    .line 34
    new-instance v1, Ljava/lang/String;

    const/4 v2, 0x1

    const/16 v3, 0x8

    invoke-direct {v1, p1, v2, v3}, Ljava/lang/String;-><init>([BII)V

    iput-object v1, p0, Lnet/duceng/midi/StyControl;->name:Ljava/lang/String;

    .line 35
    const/16 v1, 0x9

    aget-byte v1, p1, v1

    iput-byte v1, p0, Lnet/duceng/midi/StyControl;->destination:B

    .line 36
    const/16 v1, 0xa

    aget-byte v1, p1, v1

    iput-byte v1, p0, Lnet/duceng/midi/StyControl;->editable:B

    .line 37
    iget-object v1, p0, Lnet/duceng/midi/StyControl;->noteMute:[B

    iget-object v2, p0, Lnet/duceng/midi/StyControl;->noteMute:[B

    array-length v2, v2

    const/16 v3, 0xb

    invoke-static {p1, v3, v1, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 38
    iget-object v1, p0, Lnet/duceng/midi/StyControl;->chordMute:[B

    iget-object v2, p0, Lnet/duceng/midi/StyControl;->chordMute:[B

    array-length v2, v2

    const/16 v3, 0xd

    invoke-static {p1, v3, v1, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 39
    const/16 v0, 0x12

    aget-byte v0, p1, v0

    iput-byte v0, p0, Lnet/duceng/midi/StyControl;->root:B

    .line 40
    const/16 v0, 0x13

    aget-byte v0, p1, v0

    iput-byte v0, p0, Lnet/duceng/midi/StyControl;->chord:B

    .line 41
    const/16 v0, 0x14

    aget-byte v0, p1, v0

    iput-byte v0, p0, Lnet/duceng/midi/StyControl;->noteRule:B

    .line 42
    const/16 v0, 0x15

    aget-byte v0, p1, v0

    iput-byte v0, p0, Lnet/duceng/midi/StyControl;->noteTable:B

    .line 43
    const/16 v0, 0x16

    aget-byte v0, p1, v0

    iput-byte v0, p0, Lnet/duceng/midi/StyControl;->highkey:B

    .line 44
    const/16 v0, 0x17

    aget-byte v0, p1, v0

    iput-byte v0, p0, Lnet/duceng/midi/StyControl;->lowLimit:B

    .line 45
    const/16 v0, 0x18

    aget-byte v0, p1, v0

    iput-byte v0, p0, Lnet/duceng/midi/StyControl;->highLimit:B

    .line 46
    const/16 v0, 0x19

    aget-byte v0, p1, v0

    iput-byte v0, p0, Lnet/duceng/midi/StyControl;->retriggerRule:B

    .line 47
    return-void
.end method

.method public static defaultFor(I)Lnet/duceng/midi/StyControl;
    .locals 10
    .param p0, "ch"    # I

    .line 51
    const/16 v0, 0x1b

    new-array v0, v0, [B

    .line 52
    .local v0, "d":[B
    int-to-byte v1, p0

    const/4 v2, 0x0

    aput-byte v1, v0, v2

    .line 53
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Ch"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "     "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    .line 54
    .local v1, "nm":[B
    const/4 v3, 0x1

    const/16 v4, 0x8

    invoke-static {v1, v2, v0, v3, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 55
    int-to-byte v5, p0

    const/16 v6, 0x9

    aput-byte v5, v0, v6

    .line 56
    const/16 v5, 0xa

    aput-byte v3, v0, v5

    .line 57
    const/16 v7, 0xb

    const/16 v8, 0xf

    aput-byte v8, v0, v7

    .line 58
    const/16 v7, 0xc

    const/4 v9, -0x1

    aput-byte v9, v0, v7

    .line 59
    const/16 v7, 0x12

    aput-byte v2, v0, v7

    .line 60
    const/16 v7, 0x13

    const/4 v9, 0x2

    aput-byte v9, v0, v7

    .line 61
    if-eq p0, v4, :cond_1

    if-ne p0, v6, :cond_0

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v4, 0x1

    .line 62
    .local v4, "rhythm":Z
    :goto_1
    if-eqz v4, :cond_2

    const/4 v6, 0x1

    goto :goto_2

    :cond_2
    const/4 v6, 0x0

    :goto_2
    int-to-byte v6, v6

    const/16 v7, 0x14

    aput-byte v6, v0, v7

    .line 63
    if-eqz v4, :cond_3

    const/4 v9, 0x0

    goto :goto_3

    :cond_3
    if-ne p0, v5, :cond_4

    const/4 v9, 0x3

    goto :goto_3

    :cond_4
    const/16 v6, 0xe

    if-eq p0, v6, :cond_5

    if-ne p0, v8, :cond_6

    :cond_5
    const/4 v9, 0x1

    :cond_6
    :goto_3
    int-to-byte v6, v9

    const/16 v7, 0x15

    aput-byte v6, v0, v7

    .line 64
    if-eqz v4, :cond_7

    const/4 v6, 0x6

    goto :goto_4

    :cond_7
    const/4 v6, 0x7

    :goto_4
    int-to-byte v6, v6

    const/16 v7, 0x16

    aput-byte v6, v0, v7

    .line 65
    if-ne p0, v5, :cond_8

    const/16 v2, 0x1c

    :cond_8
    int-to-byte v2, v2

    const/16 v5, 0x17

    aput-byte v2, v0, v5

    .line 66
    const/16 v2, 0x18

    const/16 v5, 0x7f

    aput-byte v5, v0, v2

    .line 67
    const/16 v2, 0x19

    aput-byte v3, v0, v2

    .line 68
    new-instance v2, Lnet/duceng/midi/StyControl;

    invoke-direct {v2, v0}, Lnet/duceng/midi/StyControl;-><init>([B)V

    return-object v2
.end method

.method protected static getDefault()Lnet/duceng/midi/StyControl;
    .locals 1

    .line 88
    sget-object v0, Lnet/duceng/midi/StyControl;->DEFAULT:Lnet/duceng/midi/StyControl;

    if-nez v0, :cond_0

    .line 89
    new-instance v0, Lnet/duceng/midi/StyControl;

    invoke-direct {v0}, Lnet/duceng/midi/StyControl;-><init>()V

    sput-object v0, Lnet/duceng/midi/StyControl;->DEFAULT:Lnet/duceng/midi/StyControl;

    .line 91
    :cond_0
    sget-object v0, Lnet/duceng/midi/StyControl;->DEFAULT:Lnet/duceng/midi/StyControl;

    return-object v0
.end method
