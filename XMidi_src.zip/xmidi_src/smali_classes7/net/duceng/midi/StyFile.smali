.class public Lnet/duceng/midi/StyFile;
.super Ljava/lang/Object;
.source "StyFile.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lnet/duceng/midi/StyFile$CompratorSection;
    }
.end annotation


# static fields
.field public static final HEAD:Ljava/lang/String; = "MThd"


# instance fields
.field private count:I

.field private head:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/MidiEvent;",
            ">;"
        }
    .end annotation
.end field

.field private identifier:Ljava/lang/String;

.field private resolution:I

.field private sections:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lnet/duceng/midi/StySection;",
            ">;"
        }
    .end annotation
.end field

.field private sint:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/MidiEvent;",
            ">;"
        }
    .end annotation
.end field

.field private tempo:Lnet/duceng/midi/MetaTempo;

.field private timeSignature:Lnet/duceng/midi/MetaTimeSignature;

.field private track:Lnet/duceng/midi/StyTrack;

.field private type:I


# direct methods
.method public constructor <init>(Ljava/io/InputStream;)V
    .locals 20
    .param p1, "is"    # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 98
    move-object/from16 v1, p0

    const-string v2, "XMidi"

    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    .line 22
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, v1, Lnet/duceng/midi/StyFile;->head:Ljava/util/ArrayList;

    .line 23
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, v1, Lnet/duceng/midi/StyFile;->sint:Ljava/util/ArrayList;

    .line 24
    new-instance v0, Ljava/util/TreeMap;

    new-instance v3, Lnet/duceng/midi/StyFile$CompratorSection;

    const/4 v4, 0x0

    invoke-direct {v3, v4}, Lnet/duceng/midi/StyFile$CompratorSection;-><init>(Lnet/duceng/midi/StyFile$CompratorSection;)V

    invoke-direct {v0, v3}, Ljava/util/TreeMap;-><init>(Ljava/util/Comparator;)V

    iput-object v0, v1, Lnet/duceng/midi/StyFile;->sections:Ljava/util/Map;

    .line 99
    iput-object v4, v1, Lnet/duceng/midi/StyFile;->identifier:Ljava/lang/String;

    .line 100
    invoke-static/range {p1 .. p1}, Lnet/duceng/midi/StyFile;->readAll(Ljava/io/InputStream;)[B

    move-result-object v3

    invoke-static {v3}, Lnet/duceng/xsynth/XSynth;->adaptSafe([B)[B

    move-result-object v3

    .line 101
    .local v3, "all":[B
    array-length v0, v3

    const/16 v4, 0x16

    if-lt v0, v4, :cond_13

    const/4 v0, 0x0

    const/4 v4, 0x4

    invoke-static {v3, v0, v4}, Lnet/duceng/midi/StyFile;->ascii([BII)Ljava/lang/String;

    move-result-object v0

    const-string v5, "MThd"

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_13

    .line 104
    invoke-static {v3, v4}, Lnet/duceng/midi/StyFile;->u32([BI)I

    move-result v0

    const/4 v5, 0x6

    invoke-static {v5, v0}, Ljava/lang/Math;->max(II)I

    move-result v6

    .line 105
    .local v6, "headLen":I
    const/16 v0, 0x8

    const/4 v7, 0x2

    invoke-static {v3, v0, v7}, Lnet/duceng/midi/MidiUtil;->bytesToInt([BII)I

    move-result v0

    iput v0, v1, Lnet/duceng/midi/StyFile;->type:I

    .line 106
    const/16 v0, 0xa

    invoke-static {v3, v0, v7}, Lnet/duceng/midi/MidiUtil;->bytesToInt([BII)I

    move-result v0

    iput v0, v1, Lnet/duceng/midi/StyFile;->count:I

    .line 107
    const/16 v0, 0xc

    invoke-static {v3, v0, v7}, Lnet/duceng/midi/MidiUtil;->bytesToInt([BII)I

    move-result v0

    iput v0, v1, Lnet/duceng/midi/StyFile;->resolution:I

    .line 108
    iget v0, v1, Lnet/duceng/midi/StyFile;->type:I

    const/4 v7, 0x1

    if-gt v0, v7, :cond_12

    iget v0, v1, Lnet/duceng/midi/StyFile;->count:I

    if-lt v0, v7, :cond_12

    iget v0, v1, Lnet/duceng/midi/StyFile;->resolution:I

    if-lez v0, :cond_12

    .line 111
    add-int/lit8 v8, v6, 0x8

    .line 112
    .local v8, "trackPos":I
    new-instance v0, Ljava/io/ByteArrayInputStream;

    array-length v9, v3

    sub-int/2addr v9, v8

    invoke-direct {v0, v3, v8, v9}, Ljava/io/ByteArrayInputStream;-><init>([BII)V

    move-object v9, v0

    .line 113
    .local v9, "in":Ljava/io/ByteArrayInputStream;
    new-instance v0, Lnet/duceng/midi/StyTrack;

    invoke-direct {v0, v9}, Lnet/duceng/midi/StyTrack;-><init>(Ljava/io/InputStream;)V

    iput-object v0, v1, Lnet/duceng/midi/StyFile;->track:Lnet/duceng/midi/StyTrack;

    .line 114
    array-length v0, v3

    invoke-virtual {v9}, Ljava/io/ByteArrayInputStream;->available()I

    move-result v10

    sub-int v10, v0, v10

    .line 115
    .local v10, "parsedEnd":I
    add-int/lit8 v0, v8, 0x8

    iget-object v11, v1, Lnet/duceng/midi/StyFile;->track:Lnet/duceng/midi/StyTrack;

    invoke-virtual {v11}, Lnet/duceng/midi/StyTrack;->getSize()I

    move-result v11

    add-int/2addr v11, v0

    .line 116
    .local v11, "declaredEnd":I
    move v0, v10

    .line 117
    .local v0, "chunkStart":I
    if-lt v11, v10, :cond_0

    add-int/lit8 v12, v11, 0x8

    array-length v13, v3

    if-gt v12, v13, :cond_0

    invoke-static {v3, v11, v4}, Lnet/duceng/midi/StyFile;->ascii([BII)Ljava/lang/String;

    move-result-object v12

    const-string v13, "[A-Za-z0-9 ]{4}"

    invoke-virtual {v12, v13}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_0

    .line 118
    move v0, v11

    move v12, v0

    goto :goto_0

    .line 120
    :cond_0
    move v12, v0

    .end local v0    # "chunkStart":I
    .local v12, "chunkStart":I
    :goto_0
    const/4 v0, 0x0

    .line 121
    .local v0, "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    const/4 v13, 0x0

    .line 122
    .local v13, "tick":I
    iget-object v14, v1, Lnet/duceng/midi/StyFile;->track:Lnet/duceng/midi/StyTrack;

    iget-object v14, v14, Lnet/duceng/midi/StyTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v14}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v14

    move v15, v13

    move-object v13, v0

    .end local v0    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .local v13, "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .local v15, "tick":I
    :goto_1
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/midi/MidiEvent;

    .line 123
    .local v0, "e":Lnet/duceng/midi/MidiEvent;
    instance-of v7, v0, Lnet/duceng/midi/EventMeta;

    if-eqz v7, :cond_4

    move-object v7, v0

    check-cast v7, Lnet/duceng/midi/EventMeta;

    iget-short v7, v7, Lnet/duceng/midi/EventMeta;->type:S

    if-ne v7, v5, :cond_4

    .line 124
    new-instance v7, Ljava/lang/String;

    move-object v5, v0

    check-cast v5, Lnet/duceng/midi/EventMeta;

    iget-object v5, v5, Lnet/duceng/midi/EventMeta;->value:[B

    invoke-direct {v7, v5}, Ljava/lang/String;-><init>([B)V

    invoke-static {v7}, Lnet/duceng/midi/StyFile;->cleanName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 125
    .local v5, "mark":Ljava/lang/String;
    const-string v7, "SFF.*"

    invoke-virtual {v5, v7}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    .line 126
    iput-object v5, v1, Lnet/duceng/midi/StyFile;->identifier:Ljava/lang/String;

    .line 127
    iget-object v7, v1, Lnet/duceng/midi/StyFile;->head:Ljava/util/ArrayList;

    .end local v13    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .local v7, "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    goto :goto_2

    .line 128
    .end local v7    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v13    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    :cond_1
    const-string v7, "SInt"

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    .line 129
    iget-object v7, v1, Lnet/duceng/midi/StyFile;->sint:Ljava/util/ArrayList;

    .end local v13    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v7    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    goto :goto_2

    .line 130
    .end local v7    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v13    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    :cond_2
    invoke-static {v5}, Lnet/duceng/midi/StyFile;->isSectionName(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3

    .line 131
    new-instance v7, Lnet/duceng/midi/StySection;

    invoke-direct {v7, v5}, Lnet/duceng/midi/StySection;-><init>(Ljava/lang/String;)V

    .line 132
    .local v7, "s":Lnet/duceng/midi/StySection;
    iget-object v4, v1, Lnet/duceng/midi/StyFile;->sections:Ljava/util/Map;

    invoke-interface {v4, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 133
    invoke-virtual {v7}, Lnet/duceng/midi/StySection;->getEvents()Ljava/util/ArrayList;

    move-result-object v7

    .line 134
    .end local v13    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .local v7, "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    goto :goto_2

    .line 135
    .end local v7    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v13    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    :cond_3
    const/4 v7, 0x0

    .line 137
    .end local v13    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v7    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    :goto_2
    const/4 v4, 0x0

    .line 138
    .end local v5    # "mark":Ljava/lang/String;
    .end local v15    # "tick":I
    .local v4, "tick":I
    move v15, v4

    move-object v13, v7

    goto :goto_3

    .end local v4    # "tick":I
    .end local v7    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v13    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .restart local v15    # "tick":I
    :cond_4
    if-eqz v13, :cond_5

    .line 139
    iget v4, v0, Lnet/duceng/midi/MidiEvent;->delta:I

    add-int/2addr v15, v4

    .line 140
    iput v15, v0, Lnet/duceng/midi/MidiEvent;->tick:I

    .line 141
    invoke-virtual {v13, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 143
    .end local v0    # "e":Lnet/duceng/midi/MidiEvent;
    :cond_5
    :goto_3
    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v7, 0x1

    goto :goto_1

    .line 146
    :cond_6
    move v0, v12

    .line 147
    .local v0, "p":I
    :goto_4
    add-int/lit8 v4, v0, 0x8

    :try_start_0
    array-length v5, v3

    if-gt v4, v5, :cond_a

    .line 148
    const/4 v4, 0x4

    invoke-static {v3, v0, v4}, Lnet/duceng/midi/StyFile;->ascii([BII)Ljava/lang/String;

    move-result-object v5

    .line 149
    .local v5, "tag":Ljava/lang/String;
    add-int/lit8 v7, v0, 0x4

    invoke-static {v3, v7}, Lnet/duceng/midi/StyFile;->u32([BI)I

    move-result v7
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_1

    .line 150
    .local v7, "size":I
    if-ltz v7, :cond_7

    add-int/lit8 v14, v0, 0x8

    move-object/from16 v17, v5

    .end local v5    # "tag":Ljava/lang/String;
    .local v17, "tag":Ljava/lang/String;
    int-to-long v4, v14

    move v14, v8

    move-object/from16 v18, v9

    .end local v8    # "trackPos":I
    .end local v9    # "in":Ljava/io/ByteArrayInputStream;
    .local v14, "trackPos":I
    .local v18, "in":Ljava/io/ByteArrayInputStream;
    int-to-long v8, v7

    add-long/2addr v4, v8

    :try_start_1
    array-length v8, v3

    int-to-long v8, v8

    cmp-long v19, v4, v8

    if-lez v19, :cond_8

    goto :goto_5

    .end local v14    # "trackPos":I
    .end local v17    # "tag":Ljava/lang/String;
    .end local v18    # "in":Ljava/io/ByteArrayInputStream;
    .restart local v5    # "tag":Ljava/lang/String;
    .restart local v8    # "trackPos":I
    .restart local v9    # "in":Ljava/io/ByteArrayInputStream;
    :cond_7
    move-object/from16 v17, v5

    move v14, v8

    move-object/from16 v18, v9

    .line 151
    .end local v5    # "tag":Ljava/lang/String;
    .end local v8    # "trackPos":I
    .end local v9    # "in":Ljava/io/ByteArrayInputStream;
    .restart local v14    # "trackPos":I
    .restart local v17    # "tag":Ljava/lang/String;
    .restart local v18    # "in":Ljava/io/ByteArrayInputStream;
    :goto_5
    array-length v4, v3

    add-int/lit8 v5, v0, 0x8

    sub-int v7, v4, v5

    .line 153
    :cond_8
    const-string v4, "CASM"

    move-object/from16 v5, v17

    .end local v17    # "tag":Ljava/lang/String;
    .restart local v5    # "tag":Ljava/lang/String;
    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_9

    .line 154
    add-int/lit8 v4, v0, 0x8

    add-int/lit8 v8, v0, 0x8

    add-int/2addr v8, v7

    invoke-direct {v1, v3, v4, v8}, Lnet/duceng/midi/StyFile;->parseCasm([BII)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    .line 156
    :cond_9
    add-int/lit8 v4, v7, 0x8

    add-int/2addr v0, v4

    .line 157
    .end local v5    # "tag":Ljava/lang/String;
    .end local v7    # "size":I
    move v8, v14

    move-object/from16 v9, v18

    goto :goto_4

    .line 158
    .end local v0    # "p":I
    :catch_0
    move-exception v0

    goto :goto_6

    .line 147
    .end local v14    # "trackPos":I
    .end local v18    # "in":Ljava/io/ByteArrayInputStream;
    .restart local v0    # "p":I
    .restart local v8    # "trackPos":I
    .restart local v9    # "in":Ljava/io/ByteArrayInputStream;
    :cond_a
    move v14, v8

    move-object/from16 v18, v9

    .line 160
    .end local v0    # "p":I
    .end local v8    # "trackPos":I
    .end local v9    # "in":Ljava/io/ByteArrayInputStream;
    .restart local v14    # "trackPos":I
    .restart local v18    # "in":Ljava/io/ByteArrayInputStream;
    goto :goto_7

    .line 158
    .end local v14    # "trackPos":I
    .end local v18    # "in":Ljava/io/ByteArrayInputStream;
    .restart local v8    # "trackPos":I
    .restart local v9    # "in":Ljava/io/ByteArrayInputStream;
    :catch_1
    move-exception v0

    move v14, v8

    move-object/from16 v18, v9

    .line 159
    .end local v8    # "trackPos":I
    .end local v9    # "in":Ljava/io/ByteArrayInputStream;
    .local v0, "e":Ljava/lang/RuntimeException;
    .restart local v14    # "trackPos":I
    .restart local v18    # "in":Ljava/io/ByteArrayInputStream;
    :goto_6
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "CASM ilegible, se usan tablas por defecto: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 162
    .end local v0    # "e":Ljava/lang/RuntimeException;
    :goto_7
    iget-object v0, v1, Lnet/duceng/midi/StyFile;->sections:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_10

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/midi/StySection;

    .line 163
    .local v4, "ss":Lnet/duceng/midi/StySection;
    invoke-virtual {v4}, Lnet/duceng/midi/StySection;->getControls()Landroid/util/SparseArray;

    move-result-object v5

    invoke-virtual {v5}, Landroid/util/SparseArray;->size()I

    move-result v5

    if-nez v5, :cond_e

    .line 164
    const/16 v5, 0x10

    new-array v7, v5, [Z

    .line 165
    .local v7, "used":[Z
    invoke-virtual {v4}, Lnet/duceng/midi/StySection;->getEvents()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_9
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_c

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/midi/MidiEvent;

    .line 166
    .local v9, "e":Lnet/duceng/midi/MidiEvent;
    instance-of v5, v9, Lnet/duceng/midi/EventChannel;

    if-eqz v5, :cond_b

    .line 167
    move-object v5, v9

    check-cast v5, Lnet/duceng/midi/EventChannel;

    iget-byte v5, v5, Lnet/duceng/midi/EventChannel;->channel:B

    and-int/lit8 v5, v5, 0xf

    const/16 v16, 0x1

    aput-boolean v16, v7, v5

    goto :goto_a

    .line 166
    :cond_b
    const/16 v16, 0x1

    .line 169
    .end local v9    # "e":Lnet/duceng/midi/MidiEvent;
    :goto_a
    const/16 v5, 0x10

    goto :goto_9

    .line 170
    :cond_c
    const/16 v16, 0x1

    const/16 v5, 0x8

    .local v5, "ch":I
    :goto_b
    const/16 v8, 0x10

    if-ge v5, v8, :cond_f

    .line 171
    aget-boolean v9, v7, v5

    if-eqz v9, :cond_d

    .line 172
    invoke-virtual {v4}, Lnet/duceng/midi/StySection;->getControls()Landroid/util/SparseArray;

    move-result-object v9

    invoke-static {v5}, Lnet/duceng/midi/StyControl;->defaultFor(I)Lnet/duceng/midi/StyControl;

    move-result-object v8

    invoke-virtual {v9, v5, v8}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 170
    :cond_d
    add-int/lit8 v5, v5, 0x1

    goto :goto_b

    .line 163
    .end local v5    # "ch":I
    .end local v7    # "used":[Z
    :cond_e
    const/16 v16, 0x1

    .line 176
    .end local v4    # "ss":Lnet/duceng/midi/StySection;
    :cond_f
    goto :goto_8

    .line 177
    :cond_10
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Load StyFile, resolution:"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Lnet/duceng/midi/StyFile;->getResolution()I

    move-result v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, " tempo:"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Lnet/duceng/midi/StyFile;->getTempo()Lnet/duceng/midi/MetaTempo;

    move-result-object v4

    invoke-virtual {v4}, Lnet/duceng/midi/MetaTempo;->getBpm()I

    move-result v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, " identifier:"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v4, v1, Lnet/duceng/midi/StyFile;->identifier:Ljava/lang/String;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, " sections:"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v4, v1, Lnet/duceng/midi/StyFile;->sections:Ljava/util/Map;

    invoke-interface {v4}, Ljava/util/Map;->size()I

    move-result v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 178
    iget-object v0, v1, Lnet/duceng/midi/StyFile;->sections:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_11

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/midi/StySection;

    .line 179
    .local v2, "ss3":Lnet/duceng/midi/StySection;
    invoke-virtual {v2, v1}, Lnet/duceng/midi/StySection;->init(Lnet/duceng/midi/StyFile;)V

    .line 180
    .end local v2    # "ss3":Lnet/duceng/midi/StySection;
    goto :goto_c

    .line 181
    :cond_11
    return-void

    .line 109
    .end local v10    # "parsedEnd":I
    .end local v11    # "declaredEnd":I
    .end local v12    # "chunkStart":I
    .end local v13    # "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/MidiEvent;>;"
    .end local v14    # "trackPos":I
    .end local v15    # "tick":I
    .end local v18    # "in":Ljava/io/ByteArrayInputStream;
    :cond_12
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v2, "This File is not YAMAHA sty. Exiting"

    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 102
    .end local v6    # "headLen":I
    :cond_13
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v2, "File identifier not MThd. Exiting"

    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private static ascii([BII)Ljava/lang/String;
    .locals 4
    .param p0, "b"    # [B
    .param p1, "p"    # I
    .param p2, "n"    # I

    .line 72
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 73
    .local v0, "sb":Ljava/lang/StringBuilder;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    if-ge v1, p2, :cond_0

    add-int v2, p1, v1

    array-length v3, p0

    if-ge v2, v3, :cond_0

    .line 74
    add-int v2, p1, v1

    aget-byte v2, p0, v2

    and-int/lit16 v2, v2, 0xff

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 73
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 76
    .end local v1    # "i":I
    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method private static cleanName(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p0, "raw"    # Ljava/lang/String;

    .line 81
    const-string v0, "\u0000"

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static isSectionName(Ljava/lang/String;)Z
    .locals 1
    .param p0, "m"    # Ljava/lang/String;

    .line 85
    const-string v0, "Main.*"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "Intro.*"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "Fill In.*"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "Ending.*"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "Break.*"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method private parseCasm([BII)V
    .locals 8
    .param p1, "b"    # [B
    .param p2, "start"    # I
    .param p3, "end"    # I

    .line 184
    move v0, p2

    .line 185
    .local v0, "p":I
    :goto_0
    add-int/lit8 v1, v0, 0x8

    if-gt v1, p3, :cond_3

    .line 186
    const/4 v1, 0x4

    invoke-static {p1, v0, v1}, Lnet/duceng/midi/StyFile;->ascii([BII)Ljava/lang/String;

    move-result-object v1

    .line 187
    .local v1, "tag":Ljava/lang/String;
    add-int/lit8 v2, v0, 0x4

    invoke-static {p1, v2}, Lnet/duceng/midi/StyFile;->u32([BI)I

    move-result v2

    .line 188
    .local v2, "size":I
    if-ltz v2, :cond_1

    int-to-long v3, v0

    const-wide/16 v5, 0x8

    add-long/2addr v3, v5

    int-to-long v5, v2

    add-long/2addr v3, v5

    int-to-long v5, p3

    cmp-long v7, v3, v5

    if-lez v7, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v3, v0, 0x8

    add-int/2addr v3, v2

    goto :goto_2

    :cond_1
    :goto_1
    move v3, p3

    .line 189
    .local v3, "bodyEnd":I
    :goto_2
    const-string v4, "CSEG"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    .line 190
    add-int/lit8 v4, v0, 0x8

    invoke-direct {p0, p1, v4, v3}, Lnet/duceng/midi/StyFile;->parseCseg([BII)V

    .line 192
    :cond_2
    move v0, v3

    .line 193
    .end local v1    # "tag":Ljava/lang/String;
    .end local v2    # "size":I
    .end local v3    # "bodyEnd":I
    goto :goto_0

    .line 194
    :cond_3
    return-void
.end method

.method private parseCseg([BII)V
    .locals 17
    .param p1, "b"    # [B
    .param p2, "start"    # I
    .param p3, "end"    # I

    .line 197
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 198
    .local v3, "names":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 199
    .local v4, "ctabs":Ljava/util/ArrayList;, "Ljava/util/ArrayList<[B>;"
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 200
    .local v5, "ctb2s":Ljava/util/ArrayList;, "Ljava/util/ArrayList<[B>;"
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 201
    .local v6, "cntts":Ljava/util/ArrayList;, "Ljava/util/ArrayList<[B>;"
    move/from16 v7, p2

    .line 202
    .local v7, "q":I
    :goto_0
    add-int/lit8 v8, v7, 0x8

    const/4 v9, 0x0

    if-gt v8, v2, :cond_7

    .line 203
    const/4 v8, 0x4

    invoke-static {v1, v7, v8}, Lnet/duceng/midi/StyFile;->ascii([BII)Ljava/lang/String;

    move-result-object v8

    .line 204
    .local v8, "tag":Ljava/lang/String;
    add-int/lit8 v10, v7, 0x4

    invoke-static {v1, v10}, Lnet/duceng/midi/StyFile;->u32([BI)I

    move-result v10

    .line 205
    .local v10, "size":I
    if-ltz v10, :cond_1

    int-to-long v11, v7

    const-wide/16 v13, 0x8

    add-long/2addr v11, v13

    int-to-long v13, v10

    add-long/2addr v11, v13

    int-to-long v13, v2

    cmp-long v15, v11, v13

    if-lez v15, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v11, v7, 0x8

    add-int/2addr v11, v10

    goto :goto_2

    :cond_1
    :goto_1
    move v11, v2

    .line 206
    .local v11, "bodyEnd":I
    :goto_2
    add-int/lit8 v12, v7, 0x8

    invoke-static {v1, v12, v11}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v12

    .line 207
    .local v12, "data":[B
    const-string v13, "Sdec"

    invoke-virtual {v8, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_3

    .line 208
    array-length v13, v12

    invoke-static {v12, v9, v13}, Lnet/duceng/midi/StyFile;->ascii([BII)Ljava/lang/String;

    move-result-object v13

    const-string v14, ","

    invoke-virtual {v13, v14}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v13

    array-length v14, v13

    :goto_3
    if-ge v9, v14, :cond_6

    aget-object v15, v13, v9

    .line 209
    .local v15, "n":Ljava/lang/String;
    invoke-static {v15}, Lnet/duceng/midi/StyFile;->cleanName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 210
    .local v1, "cn":Ljava/lang/String;
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v16

    if-lez v16, :cond_2

    .line 211
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 208
    .end local v1    # "cn":Ljava/lang/String;
    .end local v15    # "n":Ljava/lang/String;
    :cond_2
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v1, p1

    goto :goto_3

    .line 214
    :cond_3
    const-string v1, "Ctab"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/16 v9, 0x1b

    const/16 v13, 0x1a

    if-eqz v1, :cond_4

    array-length v1, v12

    if-lt v1, v13, :cond_4

    .line 215
    array-length v1, v12

    invoke-static {v9, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v12, v1}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4

    .line 216
    :cond_4
    const-string v1, "Ctb2"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    array-length v1, v12

    if-lt v1, v13, :cond_5

    .line 217
    array-length v1, v12

    invoke-static {v9, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v12, v1}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4

    .line 218
    :cond_5
    const-string v1, "Cntt"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6

    array-length v1, v12

    const/4 v9, 0x2

    if-lt v1, v9, :cond_6

    .line 219
    invoke-virtual {v6, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 221
    :cond_6
    :goto_4
    move v7, v11

    .line 222
    .end local v8    # "tag":Ljava/lang/String;
    .end local v10    # "size":I
    .end local v11    # "bodyEnd":I
    .end local v12    # "data":[B
    move-object/from16 v1, p1

    goto/16 :goto_0

    .line 223
    :cond_7
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 224
    .local v1, "targets":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/StySection;>;"
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_5
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_9

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .line 225
    .local v10, "n":Ljava/lang/String;
    iget-object v11, v0, Lnet/duceng/midi/StyFile;->sections:Ljava/util/Map;

    invoke-interface {v11, v10}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_8

    .line 226
    iget-object v11, v0, Lnet/duceng/midi/StyFile;->sections:Ljava/util/Map;

    invoke-interface {v11, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lnet/duceng/midi/StySection;

    invoke-virtual {v1, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 228
    .end local v10    # "n":Ljava/lang/String;
    :cond_8
    goto :goto_5

    .line 229
    :cond_9
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_a

    .line 230
    return-void

    .line 232
    :cond_a
    new-instance v8, Landroid/util/SparseArray;

    invoke-direct {v8}, Landroid/util/SparseArray;-><init>()V

    .line 233
    .local v8, "map":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lnet/duceng/midi/StyControl;>;"
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_6
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_b

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, [B

    .line 234
    .local v11, "t":[B
    new-instance v12, Lnet/duceng/midi/StyControl;

    invoke-direct {v12, v11}, Lnet/duceng/midi/StyControl;-><init>([B)V

    .line 235
    .local v12, "sc":Lnet/duceng/midi/StyControl;
    iget-byte v13, v12, Lnet/duceng/midi/StyControl;->source:B

    invoke-virtual {v8, v13, v12}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 236
    .end local v11    # "t":[B
    .end local v12    # "sc":Lnet/duceng/midi/StyControl;
    goto :goto_6

    .line 237
    :cond_b
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_7
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_d

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, [B

    .line 238
    .local v11, "t2":[B
    new-instance v12, Lnet/duceng/midi/StyControl;

    invoke-direct {v12, v11}, Lnet/duceng/midi/StyControl;-><init>([B)V

    .line 239
    .local v12, "sc2":Lnet/duceng/midi/StyControl;
    iget-byte v13, v12, Lnet/duceng/midi/StyControl;->source:B

    invoke-virtual {v8, v13}, Landroid/util/SparseArray;->indexOfKey(I)I

    move-result v13

    if-gez v13, :cond_c

    .line 240
    iget-byte v13, v12, Lnet/duceng/midi/StyControl;->source:B

    invoke-virtual {v8, v13, v12}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 242
    .end local v11    # "t2":[B
    .end local v12    # "sc2":Lnet/duceng/midi/StyControl;
    :cond_c
    goto :goto_7

    .line 243
    :cond_d
    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_8
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_f

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, [B

    .line 244
    .local v11, "c":[B
    aget-byte v12, v11, v9

    invoke-virtual {v8, v12}, Landroid/util/SparseArray;->indexOfKey(I)I

    move-result v12

    if-ltz v12, :cond_e

    .line 245
    aget-byte v12, v11, v9

    invoke-virtual {v8, v12}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lnet/duceng/midi/StyControl;

    const/4 v13, 0x1

    aget-byte v13, v11, v13

    iput-byte v13, v12, Lnet/duceng/midi/StyControl;->ntt:B

    .line 247
    .end local v11    # "c":[B
    :cond_e
    goto :goto_8

    .line 248
    :cond_f
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_9
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_11

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lnet/duceng/midi/StySection;

    .line 249
    .local v10, "s":Lnet/duceng/midi/StySection;
    const/4 v11, 0x0

    .local v11, "i":I
    :goto_a
    invoke-virtual {v8}, Landroid/util/SparseArray;->size()I

    move-result v12

    if-ge v11, v12, :cond_10

    .line 250
    invoke-virtual {v10}, Lnet/duceng/midi/StySection;->getControls()Landroid/util/SparseArray;

    move-result-object v12

    invoke-virtual {v8, v11}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v13

    invoke-virtual {v8, v11}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lnet/duceng/midi/StyControl;

    invoke-virtual {v12, v13, v14}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 249
    add-int/lit8 v11, v11, 0x1

    goto :goto_a

    .line 252
    .end local v10    # "s":Lnet/duceng/midi/StySection;
    .end local v11    # "i":I
    :cond_10
    goto :goto_9

    .line 253
    :cond_11
    return-void
.end method

.method private static readAll(Ljava/io/InputStream;)[B
    .locals 4
    .param p0, "is"    # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 89
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 90
    .local v0, "bo":Ljava/io/ByteArrayOutputStream;
    const v1, 0x8000

    new-array v1, v1, [B

    .line 92
    .local v1, "buf":[B
    :goto_0
    invoke-virtual {p0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2

    move v3, v2

    .local v3, "n":I
    if-lez v2, :cond_0

    .line 93
    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_0

    .line 95
    :cond_0
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    return-object v2
.end method

.method private static u32([BI)I
    .locals 2
    .param p0, "b"    # [B
    .param p1, "p"    # I

    .line 68
    aget-byte v0, p0, p1

    and-int/lit16 v0, v0, 0xff

    shl-int/lit8 v0, v0, 0x18

    add-int/lit8 v1, p1, 0x1

    aget-byte v1, p0, v1

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x10

    or-int/2addr v0, v1

    add-int/lit8 v1, p1, 0x2

    aget-byte v1, p0, v1

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x8

    or-int/2addr v0, v1

    add-int/lit8 v1, p1, 0x3

    aget-byte v1, p0, v1

    and-int/lit16 v1, v1, 0xff

    or-int/2addr v0, v1

    return v0
.end method


# virtual methods
.method public containsSection(Ljava/lang/String;)Z
    .locals 1
    .param p1, "key"    # Ljava/lang/String;

    .line 334
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->sections:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public getBarTicks()I
    .locals 5

    .line 257
    invoke-virtual {p0}, Lnet/duceng/midi/StyFile;->getTimeSignature()Lnet/duceng/midi/MetaTimeSignature;

    move-result-object v0

    .line 258
    .local v0, "ts":Lnet/duceng/midi/MetaTimeSignature;
    invoke-virtual {v0}, Lnet/duceng/midi/MetaTimeSignature;->getNumerator()B

    move-result v1

    const/4 v2, 0x1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 259
    .local v1, "num":I
    const/4 v3, 0x6

    invoke-virtual {v0}, Lnet/duceng/midi/MetaTimeSignature;->getDenominator()B

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v3

    const/4 v4, 0x0

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    shl-int v3, v2, v3

    .line 260
    .local v3, "den":I
    iget v4, p0, Lnet/duceng/midi/StyFile;->resolution:I

    mul-int/lit8 v4, v4, 0x4

    mul-int v4, v4, v1

    div-int/2addr v4, v3

    invoke-static {v2, v4}, Ljava/lang/Math;->max(II)I

    move-result v2

    return v2
.end method

.method public getBeatTicks()I
    .locals 3

    .line 265
    invoke-virtual {p0}, Lnet/duceng/midi/StyFile;->getTimeSignature()Lnet/duceng/midi/MetaTimeSignature;

    move-result-object v0

    invoke-virtual {v0}, Lnet/duceng/midi/MetaTimeSignature;->getDenominator()B

    move-result v0

    const/4 v1, 0x6

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v1, 0x1

    shl-int v0, v1, v0

    .line 266
    .local v0, "den":I
    iget v2, p0, Lnet/duceng/midi/StyFile;->resolution:I

    mul-int/lit8 v2, v2, 0x4

    div-int/2addr v2, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    return v1
.end method

.method public getCount()I
    .locals 1

    .line 274
    iget v0, p0, Lnet/duceng/midi/StyFile;->count:I

    return v0
.end method

.method public getHead()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/MidiEvent;",
            ">;"
        }
    .end annotation

    .line 318
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->head:Ljava/util/ArrayList;

    return-object v0
.end method

.method public getIdentifier()Ljava/lang/String;
    .locals 1

    .line 314
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->identifier:Ljava/lang/String;

    return-object v0
.end method

.method public getResolution()I
    .locals 1

    .line 278
    iget v0, p0, Lnet/duceng/midi/StyFile;->resolution:I

    return v0
.end method

.method public getSection(Ljava/lang/String;)Lnet/duceng/midi/StySection;
    .locals 1
    .param p1, "key"    # Ljava/lang/String;

    .line 330
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->sections:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/midi/StySection;

    return-object v0
.end method

.method public getSections()Ljava/util/Map;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lnet/duceng/midi/StySection;",
            ">;"
        }
    .end annotation

    .line 326
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->sections:Ljava/util/Map;

    return-object v0
.end method

.method public getSint()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/MidiEvent;",
            ">;"
        }
    .end annotation

    .line 322
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->sint:Ljava/util/ArrayList;

    return-object v0
.end method

.method public getTempo()Lnet/duceng/midi/MetaTempo;
    .locals 3

    .line 282
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->tempo:Lnet/duceng/midi/MetaTempo;

    if-eqz v0, :cond_0

    .line 283
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->tempo:Lnet/duceng/midi/MetaTempo;

    return-object v0

    .line 285
    :cond_0
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->track:Lnet/duceng/midi/StyTrack;

    invoke-virtual {v0}, Lnet/duceng/midi/StyTrack;->getEvents()Ljava/util/TreeSet;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/MidiEvent;

    .line 286
    .local v1, "e":Lnet/duceng/midi/MidiEvent;
    instance-of v2, v1, Lnet/duceng/midi/MetaTempo;

    if-eqz v2, :cond_1

    .line 287
    move-object v0, v1

    check-cast v0, Lnet/duceng/midi/MetaTempo;

    iput-object v0, p0, Lnet/duceng/midi/StyFile;->tempo:Lnet/duceng/midi/MetaTempo;

    .line 288
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->tempo:Lnet/duceng/midi/MetaTempo;

    return-object v0

    .line 290
    .end local v1    # "e":Lnet/duceng/midi/MidiEvent;
    :cond_1
    goto :goto_0

    .line 291
    :cond_2
    new-instance v0, Lnet/duceng/midi/MetaTempo;

    invoke-direct {v0}, Lnet/duceng/midi/MetaTempo;-><init>()V

    iput-object v0, p0, Lnet/duceng/midi/StyFile;->tempo:Lnet/duceng/midi/MetaTempo;

    .line 292
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->tempo:Lnet/duceng/midi/MetaTempo;

    return-object v0
.end method

.method public getTimeSignature()Lnet/duceng/midi/MetaTimeSignature;
    .locals 3

    .line 296
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    if-eqz v0, :cond_0

    .line 297
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    return-object v0

    .line 299
    :cond_0
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->track:Lnet/duceng/midi/StyTrack;

    invoke-virtual {v0}, Lnet/duceng/midi/StyTrack;->getEvents()Ljava/util/TreeSet;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lnet/duceng/midi/MidiEvent;

    .line 300
    .local v1, "e":Lnet/duceng/midi/MidiEvent;
    instance-of v2, v1, Lnet/duceng/midi/MetaTimeSignature;

    if-eqz v2, :cond_1

    .line 301
    move-object v0, v1

    check-cast v0, Lnet/duceng/midi/MetaTimeSignature;

    iput-object v0, p0, Lnet/duceng/midi/StyFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    .line 302
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    return-object v0

    .line 304
    .end local v1    # "e":Lnet/duceng/midi/MidiEvent;
    :cond_1
    goto :goto_0

    .line 305
    :cond_2
    new-instance v0, Lnet/duceng/midi/MetaTimeSignature;

    invoke-direct {v0}, Lnet/duceng/midi/MetaTimeSignature;-><init>()V

    iput-object v0, p0, Lnet/duceng/midi/StyFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    .line 306
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->timeSignature:Lnet/duceng/midi/MetaTimeSignature;

    return-object v0
.end method

.method public getTrack()Lnet/duceng/midi/StyTrack;
    .locals 1

    .line 310
    iget-object v0, p0, Lnet/duceng/midi/StyFile;->track:Lnet/duceng/midi/StyTrack;

    return-object v0
.end method

.method public getType()I
    .locals 1

    .line 270
    iget v0, p0, Lnet/duceng/midi/StyFile;->type:I

    return v0
.end method
