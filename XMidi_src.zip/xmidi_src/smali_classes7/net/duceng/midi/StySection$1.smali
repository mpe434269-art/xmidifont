.class Lnet/duceng/midi/StySection$1;
.super Ljava/lang/Object;
.source "StySection.java"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnet/duceng/midi/StySection;->getEvents(ILnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/ArrayList;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lnet/duceng/midi/EventChannel;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lnet/duceng/midi/StySection;


# direct methods
.method constructor <init>(Lnet/duceng/midi/StySection;)V
    .locals 0
    .param p1, "this$0"    # Lnet/duceng/midi/StySection;

    .line 360
    iput-object p1, p0, Lnet/duceng/midi/StySection$1;->this$0:Lnet/duceng/midi/StySection;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    .line 360
    check-cast p1, Lnet/duceng/midi/EventChannel;

    check-cast p2, Lnet/duceng/midi/EventChannel;

    invoke-virtual {p0, p1, p2}, Lnet/duceng/midi/StySection$1;->compare(Lnet/duceng/midi/EventChannel;Lnet/duceng/midi/EventChannel;)I

    move-result p1

    return p1
.end method

.method public compare(Lnet/duceng/midi/EventChannel;Lnet/duceng/midi/EventChannel;)I
    .locals 6
    .param p1, "x"    # Lnet/duceng/midi/EventChannel;
    .param p2, "y"    # Lnet/duceng/midi/EventChannel;

    .line 363
    iget v0, p1, Lnet/duceng/midi/EventChannel;->tick:I

    iget v1, p2, Lnet/duceng/midi/EventChannel;->tick:I

    const/4 v2, 0x1

    if-eq v0, v1, :cond_1

    .line 364
    iget v0, p1, Lnet/duceng/midi/EventChannel;->tick:I

    iget v1, p2, Lnet/duceng/midi/EventChannel;->tick:I

    if-ge v0, v1, :cond_0

    const/4 v2, -0x1

    :cond_0
    return v2

    .line 366
    :cond_1
    iget-byte v0, p1, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v1, 0x9

    const/4 v3, 0x0

    const/16 v4, 0x8

    if-eq v0, v4, :cond_3

    iget-byte v0, p1, Lnet/duceng/midi/EventChannel;->type:B

    if-ne v0, v1, :cond_2

    iget-byte v0, p1, Lnet/duceng/midi/EventChannel;->value2:B

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    const/4 v0, 0x1

    goto :goto_1

    :cond_3
    :goto_0
    const/4 v0, 0x0

    .line 367
    .local v0, "rx":I
    :goto_1
    iget-byte v5, p2, Lnet/duceng/midi/EventChannel;->type:B

    if-eq v5, v4, :cond_4

    iget-byte v4, p2, Lnet/duceng/midi/EventChannel;->type:B

    if-ne v4, v1, :cond_5

    iget-byte v1, p2, Lnet/duceng/midi/EventChannel;->value2:B

    if-nez v1, :cond_5

    :cond_4
    const/4 v2, 0x0

    :cond_5
    move v1, v2

    .line 368
    .local v1, "ry":I
    sub-int v2, v0, v1

    return v2
.end method
