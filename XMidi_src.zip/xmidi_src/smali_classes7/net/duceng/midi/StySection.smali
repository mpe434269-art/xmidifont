.class public Lnet/duceng/midi/StySection;
.super Ljava/lang/Object;
.source "StySection.java"


# static fields
.field public static final Bass:B = 0xat

.field public static final Chord1:B = 0xbt

.field public static final Chord2:B = 0xct

.field public static final Pad:B = 0xdt

.field public static final Phrase1:B = 0xet

.field public static final Phrase2:B = 0xft

.field public static final RhythmMain:B = 0x9t

.field public static final RhythmSub:B = 0x8t

.field private static final SCALE_DORIAN:[B

.field private static final SCALE_HARMIN:[B

.field private static final SCALE_MAJOR:[B

.field private static final SCALE_MELMIN:[B

.field private static final SCALE_MIXO:[B


# instance fields
.field private bars:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/util/TreeSet<",
            "Lnet/duceng/midi/EventChannel;",
            ">;>;"
        }
    .end annotation
.end field

.field private controls:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lnet/duceng/midi/StyControl;",
            ">;"
        }
    .end annotation
.end field

.field private events:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/MidiEvent;",
            ">;"
        }
    .end annotation
.end field

.field private name:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 142
    const/4 v0, 0x7

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    sput-object v1, Lnet/duceng/midi/StySection;->SCALE_MAJOR:[B

    .line 143
    new-array v1, v0, [B

    fill-array-data v1, :array_1

    sput-object v1, Lnet/duceng/midi/StySection;->SCALE_DORIAN:[B

    .line 144
    new-array v1, v0, [B

    fill-array-data v1, :array_2

    sput-object v1, Lnet/duceng/midi/StySection;->SCALE_MIXO:[B

    .line 145
    new-array v1, v0, [B

    fill-array-data v1, :array_3

    sput-object v1, Lnet/duceng/midi/StySection;->SCALE_MELMIN:[B

    .line 146
    new-array v0, v0, [B

    fill-array-data v0, :array_4

    sput-object v0, Lnet/duceng/midi/StySection;->SCALE_HARMIN:[B

    return-void

    nop

    :array_0
    .array-data 1
        0x0t
        0x2t
        0x4t
        0x5t
        0x7t
        0x9t
        0xbt
    .end array-data

    :array_1
    .array-data 1
        0x0t
        0x2t
        0x3t
        0x5t
        0x7t
        0x9t
        0xat
    .end array-data

    :array_2
    .array-data 1
        0x0t
        0x2t
        0x4t
        0x5t
        0x7t
        0x9t
        0xat
    .end array-data

    :array_3
    .array-data 1
        0x0t
        0x2t
        0x3t
        0x5t
        0x7t
        0x9t
        0xbt
    .end array-data

    :array_4
    .array-data 1
        0x0t
        0x2t
        0x3t
        0x5t
        0x7t
        0x8t
        0xbt
    .end array-data
.end method

.method protected constructor <init>(Ljava/lang/String;)V
    .locals 1
    .param p1, "n"    # Ljava/lang/String;

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/midi/StySection;->events:Ljava/util/ArrayList;

    .line 21
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Lnet/duceng/midi/StySection;->controls:Landroid/util/SparseArray;

    .line 22
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lnet/duceng/midi/StySection;->bars:Ljava/util/ArrayList;

    .line 25
    iput-object p1, p0, Lnet/duceng/midi/StySection;->name:Ljava/lang/String;

    .line 26
    return-void
.end method

.method private static contains([BI)Z
    .locals 4
    .param p0, "a"    # [B
    .param p1, "v"    # I

    .line 164
    array-length v0, p0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_1

    aget-byte v3, p0, v2

    .line 165
    .local v3, "b":B
    if-ne v3, p1, :cond_0

    .line 166
    const/4 v0, 0x1

    return v0

    .line 164
    .end local v3    # "b":B
    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 169
    :cond_1
    return v1
.end method

.method public static isRhythmChannel(I)Z
    .locals 1
    .param p0, "ch"    # I

    .line 150
    const/16 v0, 0x8

    if-eq p0, v0, :cond_1

    const/16 v0, 0x9

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method private static isSetupEvent(Lnet/duceng/midi/EventChannel;)Z
    .locals 2
    .param p0, "e"    # Lnet/duceng/midi/EventChannel;

    .line 277
    iget-byte v0, p0, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v1, 0xb

    if-eq v0, v1, :cond_0

    iget-byte v0, p0, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v1, 0xc

    if-ne v0, v1, :cond_1

    :cond_0
    iget v0, p0, Lnet/duceng/midi/EventChannel;->tick:I

    const/4 v1, 0x2

    if-gt v0, v1, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private static scaleFor(IZZ)[B
    .locals 1
    .param p0, "ntt"    # I
    .param p1, "minorFamily"    # Z
    .param p2, "dominant"    # Z

    .line 173
    if-eqz p1, :cond_2

    .line 174
    const/4 v0, 0x4

    if-ne p0, v0, :cond_0

    .line 175
    sget-object v0, Lnet/duceng/midi/StySection;->SCALE_MELMIN:[B

    return-object v0

    .line 177
    :cond_0
    const/4 v0, 0x5

    if-ne p0, v0, :cond_1

    sget-object v0, Lnet/duceng/midi/StySection;->SCALE_HARMIN:[B

    goto :goto_0

    :cond_1
    sget-object v0, Lnet/duceng/midi/StySection;->SCALE_DORIAN:[B

    :goto_0
    return-object v0

    .line 179
    :cond_2
    if-eqz p2, :cond_3

    sget-object v0, Lnet/duceng/midi/StySection;->SCALE_MIXO:[B

    goto :goto_1

    :cond_3
    sget-object v0, Lnet/duceng/midi/StySection;->SCALE_MAJOR:[B

    :goto_1
    return-object v0
.end method

.method private static sourceIsDominant(I)Z
    .locals 1
    .param p0, "chordType"    # I

    .line 187
    const/16 v0, 0x13

    if-lt p0, v0, :cond_0

    const/16 v0, 0x1b

    if-gt p0, v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private static sourceIsMinor(I)Z
    .locals 1
    .param p0, "chordType"    # I

    .line 183
    const/16 v0, 0x8

    if-lt p0, v0, :cond_0

    const/16 v0, 0x12

    if-gt p0, v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method static transposeNote(ILnet/duceng/midi/StyControl;Lnet/duceng/xmidi/util/Chords$Chord;)I
    .locals 20
    .param p0, "note"    # I
    .param p1, "sc"    # Lnet/duceng/midi/StyControl;
    .param p2, "chord"    # Lnet/duceng/xmidi/util/Chords$Chord;

    .line 192
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    iget-byte v2, v0, Lnet/duceng/midi/StyControl;->chord:B

    const/4 v3, 0x2

    if-ltz v2, :cond_0

    iget-byte v2, v0, Lnet/duceng/midi/StyControl;->chord:B

    sget-object v4, Lnet/duceng/xmidi/util/Chords;->CBASES:[[B

    array-length v4, v4

    if-ge v2, v4, :cond_0

    iget-byte v2, v0, Lnet/duceng/midi/StyControl;->chord:B

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    .line 193
    .local v2, "srcChordIdx":I
    :goto_0
    sget-object v4, Lnet/duceng/xmidi/util/Chords;->CBASES:[[B

    aget-object v4, v4, v2

    .line 194
    .local v4, "srcTones":[B
    iget-object v5, v1, Lnet/duceng/xmidi/util/Chords$Chord;->chords:[B

    const/4 v6, 0x0

    if-eqz v5, :cond_1

    iget-object v5, v1, Lnet/duceng/xmidi/util/Chords$Chord;->chords:[B

    goto :goto_1

    :cond_1
    sget-object v5, Lnet/duceng/xmidi/util/Chords;->CBASES:[[B

    aget-object v5, v5, v6

    .line 195
    .local v5, "tgtTones":[B
    :goto_1
    iget v7, v1, Lnet/duceng/xmidi/util/Chords$Chord;->id:I

    const/16 v8, 0xc

    div-int/2addr v7, v8

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-eq v7, v10, :cond_3

    iget v7, v1, Lnet/duceng/xmidi/util/Chords$Chord;->id:I

    div-int/2addr v7, v8

    if-ne v7, v9, :cond_2

    goto :goto_2

    :cond_2
    const/4 v7, 0x0

    goto :goto_3

    :cond_3
    :goto_2
    const/4 v7, 0x1

    .line 196
    .local v7, "tgtMinor":Z
    :goto_3
    iget v11, v1, Lnet/duceng/xmidi/util/Chords$Chord;->id:I

    div-int/2addr v11, v8

    if-ne v11, v3, :cond_4

    const/4 v11, 0x1

    goto :goto_4

    :cond_4
    const/4 v11, 0x0

    .line 197
    .local v11, "tgtDominant":Z
    :goto_4
    iget-byte v12, v0, Lnet/duceng/midi/StyControl;->root:B

    and-int/lit16 v12, v12, 0xff

    .line 198
    .local v12, "srcRoot":I
    const/16 v13, 0xb

    if-le v12, v13, :cond_5

    .line 199
    const/4 v12, 0x0

    .line 201
    :cond_5
    iget-byte v13, v1, Lnet/duceng/xmidi/util/Chords$Chord;->root:B

    .line 204
    .local v13, "tgtRoot":I
    sub-int v14, v13, v12

    rem-int/2addr v14, v8

    add-int/2addr v14, v8

    rem-int/2addr v14, v8

    .line 205
    .local v14, "shift":I
    iget-byte v15, v0, Lnet/duceng/midi/StyControl;->noteRule:B

    const/4 v6, 0x6

    if-ne v15, v10, :cond_6

    .line 206
    if-le v14, v6, :cond_7

    .line 207
    add-int/lit8 v14, v14, -0xc

    goto :goto_5

    .line 210
    :cond_6
    iget-byte v15, v0, Lnet/duceng/midi/StyControl;->highkey:B

    if-le v14, v15, :cond_7

    .line 211
    add-int/lit8 v14, v14, -0xc

    .line 216
    :cond_7
    :goto_5
    const/4 v15, 0x0

    .line 217
    .local v15, "delta":I
    iget-byte v6, v0, Lnet/duceng/midi/StyControl;->noteTable:B

    if-eqz v6, :cond_14

    .line 218
    sub-int v6, p0, v12

    rem-int/2addr v6, v8

    add-int/2addr v6, v8

    rem-int/2addr v6, v8

    .line 219
    .local v6, "rel":I
    const/16 v17, -0x1

    .line 220
    .local v17, "idx":I
    const/16 v18, 0x0

    move/from16 v10, v18

    .local v10, "i":I
    :goto_6
    array-length v9, v4

    if-ge v10, v9, :cond_a

    .line 221
    aget-byte v9, v4, v10

    rem-int/2addr v9, v8

    if-ne v9, v6, :cond_9

    if-ltz v17, :cond_8

    aget-byte v9, v4, v10

    if-ge v9, v8, :cond_9

    .line 222
    :cond_8
    move/from16 v17, v10

    .line 223
    aget-byte v9, v4, v10

    if-ge v9, v8, :cond_9

    .line 224
    move/from16 v8, v17

    goto :goto_7

    .line 220
    :cond_9
    add-int/lit8 v10, v10, 0x1

    const/4 v9, 0x3

    goto :goto_6

    :cond_a
    move/from16 v8, v17

    .line 228
    .end local v10    # "i":I
    .end local v17    # "idx":I
    .local v8, "idx":I
    :goto_7
    iget-byte v9, v0, Lnet/duceng/midi/StyControl;->noteTable:B

    if-eq v9, v3, :cond_c

    iget-byte v3, v0, Lnet/duceng/midi/StyControl;->noteTable:B

    const/4 v9, 0x3

    if-ne v3, v9, :cond_b

    goto :goto_8

    :cond_b
    const/4 v3, 0x0

    goto :goto_9

    :cond_c
    :goto_8
    const/4 v3, 0x1

    .line 229
    .local v3, "chordTable":Z
    :goto_9
    if-ltz v8, :cond_11

    if-nez v3, :cond_d

    iget-byte v9, v0, Lnet/duceng/midi/StyControl;->noteTable:B

    const/4 v10, 0x1

    if-lt v9, v10, :cond_11

    goto :goto_a

    :cond_d
    const/4 v10, 0x1

    .line 230
    :goto_a
    array-length v9, v5

    sub-int/2addr v9, v10

    invoke-static {v8, v9}, Ljava/lang/Math;->min(II)I

    move-result v9

    aget-byte v9, v5, v9

    .line 231
    .local v9, "t":I
    array-length v10, v5

    if-lt v8, v10, :cond_e

    .line 232
    add-int/lit8 v9, v9, 0xc

    .line 234
    :cond_e
    aget-byte v10, v4, v8

    .line 235
    .local v10, "s":I
    sub-int v15, v9, v10

    .line 237
    :goto_b
    const/4 v1, 0x6

    if-le v15, v1, :cond_f

    .line 238
    add-int/lit8 v15, v15, -0xc

    move-object/from16 v1, p2

    goto :goto_b

    .line 240
    :cond_f
    :goto_c
    const/4 v1, -0x6

    if-ge v15, v1, :cond_10

    .line 241
    add-int/lit8 v15, v15, 0xc

    goto :goto_c

    .line 243
    .end local v9    # "t":I
    .end local v10    # "s":I
    :cond_10
    move/from16 v16, v2

    goto :goto_e

    .line 244
    :cond_11
    invoke-static {v2}, Lnet/duceng/midi/StySection;->sourceIsMinor(I)Z

    move-result v1

    invoke-static {v2}, Lnet/duceng/midi/StySection;->sourceIsDominant(I)Z

    move-result v9

    const/4 v10, 0x1

    invoke-static {v10, v1, v9}, Lnet/duceng/midi/StySection;->scaleFor(IZZ)[B

    move-result-object v1

    .line 245
    .local v1, "srcScale":[B
    iget-byte v9, v0, Lnet/duceng/midi/StyControl;->noteTable:B

    invoke-static {v9, v7, v11}, Lnet/duceng/midi/StySection;->scaleFor(IZZ)[B

    move-result-object v9

    .line 246
    .local v9, "tgtScale":[B
    const/4 v10, -0x1

    .line 247
    .local v10, "deg":I
    const/16 v16, 0x0

    move/from16 v19, v16

    move/from16 v16, v2

    move/from16 v2, v19

    .local v2, "i":I
    .local v16, "srcChordIdx":I
    :goto_d
    move/from16 v17, v3

    .end local v3    # "chordTable":Z
    .local v17, "chordTable":Z
    array-length v3, v1

    if-ge v2, v3, :cond_13

    .line 248
    aget-byte v3, v1, v2

    if-gt v3, v6, :cond_12

    .line 249
    move v3, v2

    move v10, v3

    .line 247
    :cond_12
    add-int/lit8 v2, v2, 0x1

    move/from16 v3, v17

    goto :goto_d

    .line 252
    .end local v2    # "i":I
    :cond_13
    if-ltz v10, :cond_15

    .line 253
    aget-byte v2, v9, v10

    aget-byte v3, v1, v10

    sub-int v15, v2, v3

    goto :goto_e

    .line 217
    .end local v1    # "srcScale":[B
    .end local v6    # "rel":I
    .end local v8    # "idx":I
    .end local v9    # "tgtScale":[B
    .end local v10    # "deg":I
    .end local v16    # "srcChordIdx":I
    .end local v17    # "chordTable":Z
    .local v2, "srcChordIdx":I
    :cond_14
    move/from16 v16, v2

    .line 258
    .end local v2    # "srcChordIdx":I
    .restart local v16    # "srcChordIdx":I
    :cond_15
    :goto_e
    add-int v1, p0, v14

    add-int/2addr v1, v15

    .line 260
    .local v1, "out":I
    iget-byte v2, v0, Lnet/duceng/midi/StyControl;->lowLimit:B

    and-int/lit16 v2, v2, 0xff

    .line 261
    .local v2, "lo":I
    iget-byte v3, v0, Lnet/duceng/midi/StyControl;->highLimit:B

    and-int/lit16 v3, v3, 0xff

    .line 262
    .local v3, "hi":I
    const/16 v6, 0x7f

    if-le v3, v6, :cond_16

    .line 263
    const/16 v3, 0x7f

    .line 265
    :cond_16
    add-int/lit8 v8, v2, 0xb

    if-lt v3, v8, :cond_18

    .line 266
    :goto_f
    if-le v1, v3, :cond_17

    .line 267
    add-int/lit8 v1, v1, -0xc

    goto :goto_f

    .line 269
    :cond_17
    :goto_10
    if-ge v1, v2, :cond_18

    .line 270
    add-int/lit8 v1, v1, 0xc

    goto :goto_10

    .line 273
    :cond_18
    invoke-static {v6, v1}, Ljava/lang/Math;->min(II)I

    move-result v6

    const/4 v8, 0x0

    invoke-static {v8, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    return v6
.end method


# virtual methods
.method public getBarTicks(Lnet/duceng/midi/StyFile;)I
    .locals 1
    .param p1, "sf"    # Lnet/duceng/midi/StyFile;

    .line 160
    invoke-virtual {p1}, Lnet/duceng/midi/StyFile;->getBarTicks()I

    move-result v0

    return v0
.end method

.method protected getControls()Landroid/util/SparseArray;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroid/util/SparseArray<",
            "Lnet/duceng/midi/StyControl;",
            ">;"
        }
    .end annotation

    .line 37
    iget-object v0, p0, Lnet/duceng/midi/StySection;->controls:Landroid/util/SparseArray;

    return-object v0
.end method

.method protected getEvents()Ljava/util/ArrayList;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/MidiEvent;",
            ">;"
        }
    .end annotation

    .line 33
    iget-object v0, p0, Lnet/duceng/midi/StySection;->events:Ljava/util/ArrayList;

    return-object v0
.end method

.method public getEvents(I)Ljava/util/ArrayList;
    .locals 1
    .param p1, "idx"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/EventChannel;",
            ">;"
        }
    .end annotation

    .line 133
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lnet/duceng/midi/StySection;->getEvents(ILnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/ArrayList;

    move-result-object v0

    return-object v0
.end method

.method public getEvents(ILnet/duceng/xmidi/util/Chords$Chord;)Ljava/util/ArrayList;
    .locals 8
    .param p1, "idx"    # I
    .param p2, "chord"    # Lnet/duceng/xmidi/util/Chords$Chord;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lnet/duceng/xmidi/util/Chords$Chord;",
            ")",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/EventChannel;",
            ">;"
        }
    .end annotation

    .line 326
    iget-object v0, p0, Lnet/duceng/midi/StySection;->bars:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    if-gt p1, v0, :cond_0

    if-gez p1, :cond_1

    .line 327
    :cond_0
    const/4 p1, 0x0

    .line 329
    :cond_1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 330
    .local v0, "bar":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    iget-object v1, p0, Lnet/duceng/midi/StySection;->bars:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_2

    .line 331
    return-object v0

    .line 333
    :cond_2
    iget-object v1, p0, Lnet/duceng/midi/StySection;->bars:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/TreeSet;

    invoke-virtual {v1}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_3
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_c

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lnet/duceng/midi/EventChannel;

    .line 334
    .local v2, "e":Lnet/duceng/midi/EventChannel;
    iget-object v3, p0, Lnet/duceng/midi/StySection;->controls:Landroid/util/SparseArray;

    iget-byte v4, v2, Lnet/duceng/midi/EventChannel;->channel:B

    invoke-virtual {v3, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lnet/duceng/midi/StyControl;

    .line 335
    .local v3, "sc":Lnet/duceng/midi/StyControl;
    if-nez v3, :cond_4

    .line 336
    goto :goto_0

    .line 338
    :cond_4
    if-nez p1, :cond_5

    invoke-static {v2}, Lnet/duceng/midi/StySection;->isSetupEvent(Lnet/duceng/midi/EventChannel;)Z

    move-result v4

    if-eqz v4, :cond_5

    .line 339
    goto :goto_0

    .line 342
    :cond_5
    iget-byte v4, v2, Lnet/duceng/midi/EventChannel;->channel:B

    invoke-static {v4}, Lnet/duceng/midi/StySection;->isRhythmChannel(I)Z

    move-result v4

    const/16 v5, 0x8

    const/16 v6, 0x9

    if-nez v4, :cond_a

    iget-byte v4, v3, Lnet/duceng/midi/StyControl;->destination:B

    if-ne v4, v6, :cond_6

    goto :goto_1

    .line 350
    :cond_6
    if-nez p2, :cond_7

    .line 351
    goto :goto_0

    .line 353
    :cond_7
    invoke-static {v2, v3, p2}, Lnet/duceng/midi/StySection;->xmPlays(Lnet/duceng/midi/EventChannel;Lnet/duceng/midi/StyControl;Lnet/duceng/xmidi/util/Chords$Chord;)Z

    move-result v4

    if-eqz v4, :goto_0

    invoke-virtual {v2}, Lnet/duceng/midi/EventChannel;->clone()Lnet/duceng/midi/EventChannel;

    move-result-object v4

    .line 354
    .local v4, "ec2":Lnet/duceng/midi/EventChannel;
    iget-byte v7, v3, Lnet/duceng/midi/StyControl;->destination:B

    iput-byte v7, v4, Lnet/duceng/midi/EventChannel;->channel:B

    .line 355
    iget-byte v7, v2, Lnet/duceng/midi/EventChannel;->type:B

    if-eq v7, v5, :cond_8

    iget-byte v5, v2, Lnet/duceng/midi/EventChannel;->type:B

    if-ne v5, v6, :cond_9

    .line 356
    :cond_8
    iget-byte v5, v2, Lnet/duceng/midi/EventChannel;->value1:B

    invoke-static {v5, v3, p2}, Lnet/duceng/midi/StySection;->transposeNote(ILnet/duceng/midi/StyControl;Lnet/duceng/xmidi/util/Chords$Chord;)I

    move-result v5

    int-to-byte v5, v5

    iput-byte v5, v4, Lnet/duceng/midi/EventChannel;->value1:B

    .line 358
    :cond_9
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 359
    .end local v2    # "e":Lnet/duceng/midi/EventChannel;
    .end local v3    # "sc":Lnet/duceng/midi/StyControl;
    .end local v4    # "ec2":Lnet/duceng/midi/EventChannel;
    goto :goto_0

    .line 343
    .restart local v2    # "e":Lnet/duceng/midi/EventChannel;
    .restart local v3    # "sc":Lnet/duceng/midi/StyControl;
    :cond_a
    :goto_1
    iget-byte v4, v2, Lnet/duceng/midi/EventChannel;->type:B

    if-eq v4, v5, :cond_b

    iget-byte v4, v2, Lnet/duceng/midi/EventChannel;->type:B

    if-ne v4, v6, :cond_3

    .line 344
    :cond_b
    invoke-virtual {v2}, Lnet/duceng/midi/EventChannel;->clone()Lnet/duceng/midi/EventChannel;

    move-result-object v4

    .line 345
    .local v4, "ec":Lnet/duceng/midi/EventChannel;
    iput-byte v6, v4, Lnet/duceng/midi/EventChannel;->channel:B

    .line 346
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 347
    .end local v4    # "ec":Lnet/duceng/midi/EventChannel;
    goto :goto_0

    .line 360
    .end local v2    # "e":Lnet/duceng/midi/EventChannel;
    .end local v3    # "sc":Lnet/duceng/midi/StyControl;
    :cond_c
    new-instance v1, Lnet/duceng/midi/StySection$1;

    invoke-direct {v1, p0}, Lnet/duceng/midi/StySection$1;-><init>(Lnet/duceng/midi/StySection;)V

    invoke-static {v0, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 371
    return-object v0
.end method

.method public getLastTick()I
    .locals 2

    .line 45
    iget-object v0, p0, Lnet/duceng/midi/StySection;->events:Ljava/util/ArrayList;

    iget-object v1, p0, Lnet/duceng/midi/StySection;->events:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/midi/MidiEvent;

    iget v0, v0, Lnet/duceng/midi/MidiEvent;->tick:I

    return v0
.end method

.method public getName()Ljava/lang/String;
    .locals 1

    .line 29
    iget-object v0, p0, Lnet/duceng/midi/StySection;->name:Ljava/lang/String;

    return-object v0
.end method

.method public getRetriggerRule(I)I
    .locals 2
    .param p1, "channel"    # I

    .line 155
    iget-object v0, p0, Lnet/duceng/midi/StySection;->controls:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lnet/duceng/midi/StyControl;

    .line 156
    .local v0, "sc":Lnet/duceng/midi/StyControl;
    if-nez v0, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    iget-byte v1, v0, Lnet/duceng/midi/StyControl;->retriggerRule:B

    :goto_0
    return v1
.end method

.method public getSetupEvents()Ljava/util/ArrayList;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lnet/duceng/midi/EventChannel;",
            ">;"
        }
    .end annotation

    .line 286
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 287
    .local v0, "banks":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 288
    .local v1, "progs":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 289
    .local v2, "ctrls":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    iget-object v3, p0, Lnet/duceng/midi/StySection;->bars:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    .line 290
    return-object v0

    .line 292
    :cond_0
    iget-object v3, p0, Lnet/duceng/midi/StySection;->bars:Ljava/util/ArrayList;

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/TreeSet;

    invoke-virtual {v3}, Ljava/util/TreeSet;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_b

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lnet/duceng/midi/EventChannel;

    .line 293
    .local v4, "e":Lnet/duceng/midi/EventChannel;
    invoke-static {v4}, Lnet/duceng/midi/StySection;->isSetupEvent(Lnet/duceng/midi/EventChannel;)Z

    move-result v5

    if-nez v5, :cond_2

    .line 294
    goto :goto_0

    .line 296
    :cond_2
    iget-object v5, p0, Lnet/duceng/midi/StySection;->controls:Landroid/util/SparseArray;

    iget-byte v6, v4, Lnet/duceng/midi/EventChannel;->channel:B

    invoke-virtual {v5, v6}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/midi/StyControl;

    .line 297
    .local v5, "sc":Lnet/duceng/midi/StyControl;
    if-nez v5, :cond_3

    .line 298
    goto :goto_0

    .line 300
    :cond_3
    iget-byte v6, v4, Lnet/duceng/midi/EventChannel;->channel:B

    invoke-static {v6}, Lnet/duceng/midi/StySection;->isRhythmChannel(I)Z

    move-result v6

    const/16 v7, 0xc

    const/16 v8, 0x9

    if-nez v6, :cond_a

    iget-byte v6, v5, Lnet/duceng/midi/StyControl;->destination:B

    if-ne v6, v8, :cond_4

    goto :goto_3

    .line 308
    :cond_4
    invoke-virtual {v4}, Lnet/duceng/midi/EventChannel;->clone()Lnet/duceng/midi/EventChannel;

    move-result-object v6

    .line 309
    .local v6, "ec":Lnet/duceng/midi/EventChannel;
    iget-byte v8, v5, Lnet/duceng/midi/StyControl;->destination:B

    iput-byte v8, v6, Lnet/duceng/midi/EventChannel;->channel:B

    .line 310
    iget-byte v8, v4, Lnet/duceng/midi/EventChannel;->type:B

    if-ne v8, v7, :cond_5

    .line 311
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 312
    :cond_5
    iget-byte v7, v4, Lnet/duceng/midi/EventChannel;->value1:B

    if-eqz v7, :cond_7

    iget-byte v7, v4, Lnet/duceng/midi/EventChannel;->value1:B

    const/16 v8, 0x20

    if-ne v7, v8, :cond_6

    goto :goto_1

    .line 317
    :cond_6
    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 313
    :cond_7
    :goto_1
    iget-byte v7, v4, Lnet/duceng/midi/EventChannel;->value1:B

    if-nez v7, :cond_8

    iget-byte v7, v4, Lnet/duceng/midi/EventChannel;->value2:B

    const/16 v8, 0x7f

    if-eq v7, v8, :cond_9

    .line 314
    :cond_8
    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 319
    .end local v4    # "e":Lnet/duceng/midi/EventChannel;
    .end local v5    # "sc":Lnet/duceng/midi/StyControl;
    .end local v6    # "ec":Lnet/duceng/midi/EventChannel;
    :cond_9
    :goto_2
    goto :goto_0

    .line 301
    .restart local v4    # "e":Lnet/duceng/midi/EventChannel;
    .restart local v5    # "sc":Lnet/duceng/midi/StyControl;
    :cond_a
    :goto_3
    iget-byte v6, v4, Lnet/duceng/midi/EventChannel;->type:B

    if-ne v6, v7, :cond_1

    iget-byte v6, v4, Lnet/duceng/midi/EventChannel;->channel:B

    if-ne v6, v8, :cond_1

    .line 302
    invoke-virtual {v4}, Lnet/duceng/midi/EventChannel;->clone()Lnet/duceng/midi/EventChannel;

    move-result-object v6

    .line 303
    .local v6, "d":Lnet/duceng/midi/EventChannel;
    iput-byte v8, v6, Lnet/duceng/midi/EventChannel;->channel:B

    .line 304
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 305
    .end local v6    # "d":Lnet/duceng/midi/EventChannel;
    goto :goto_0

    .line 320
    .end local v4    # "e":Lnet/duceng/midi/EventChannel;
    .end local v5    # "sc":Lnet/duceng/midi/StyControl;
    :cond_b
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 321
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 322
    return-object v0
.end method

.method protected init(Lnet/duceng/midi/StyFile;)V
    .locals 24
    .param p1, "sf"    # Lnet/duceng/midi/StyFile;

    .line 49
    move-object/from16 v0, p0

    invoke-virtual/range {p1 .. p1}, Lnet/duceng/midi/StyFile;->getResolution()I

    move-result v1

    .line 50
    .local v1, "res":I
    invoke-virtual/range {p1 .. p1}, Lnet/duceng/midi/StyFile;->getBarTicks()I

    move-result v2

    .line 51
    .local v2, "barTick":I
    const/4 v3, 0x0

    .line 52
    .local v3, "maxTick":I
    iget-object v4, v0, Lnet/duceng/midi/StySection;->events:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/midi/MidiEvent;

    .line 53
    .local v5, "e":Lnet/duceng/midi/MidiEvent;
    instance-of v6, v5, Lnet/duceng/midi/EventChannel;

    if-eqz v6, :cond_0

    iget v6, v5, Lnet/duceng/midi/MidiEvent;->tick:I

    if-le v6, v3, :cond_0

    .line 54
    iget v3, v5, Lnet/duceng/midi/MidiEvent;->tick:I

    .line 56
    .end local v5    # "e":Lnet/duceng/midi/MidiEvent;
    :cond_0
    goto :goto_0

    .line 58
    :cond_1
    add-int v4, v3, v2

    const/4 v5, 0x1

    sub-int/2addr v4, v5

    div-int/2addr v4, v2

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    .line 59
    .local v4, "nBars":I
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 60
    .local v6, "i_bars":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;>;"
    const/4 v7, 0x0

    .local v7, "i":I
    :goto_1
    if-ge v7, v4, :cond_2

    .line 61
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 60
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 63
    .end local v7    # "i":I
    :cond_2
    iget-object v7, v0, Lnet/duceng/midi/StySection;->events:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    const/4 v9, 0x0

    const/16 v10, 0x9

    const/16 v11, 0x8

    if-eqz v8, :cond_8

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lnet/duceng/midi/MidiEvent;

    .line 64
    .local v8, "e2":Lnet/duceng/midi/MidiEvent;
    instance-of v12, v8, Lnet/duceng/midi/EventChannel;

    if-nez v12, :cond_3

    .line 65
    goto :goto_2

    .line 67
    :cond_3
    move-object v12, v8

    check-cast v12, Lnet/duceng/midi/EventChannel;

    .line 68
    .local v12, "ec":Lnet/duceng/midi/EventChannel;
    iget-byte v13, v12, Lnet/duceng/midi/EventChannel;->type:B

    if-eq v13, v11, :cond_5

    iget-byte v11, v12, Lnet/duceng/midi/EventChannel;->type:B

    if-ne v11, v10, :cond_4

    iget-byte v10, v12, Lnet/duceng/midi/EventChannel;->value2:B

    if-nez v10, :cond_4

    goto :goto_3

    :cond_4
    const/4 v10, 0x0

    goto :goto_4

    :cond_5
    :goto_3
    const/4 v10, 0x1

    .line 69
    .local v10, "isOff":Z
    :goto_4
    iget v11, v12, Lnet/duceng/midi/EventChannel;->tick:I

    if-eqz v10, :cond_6

    sub-int/2addr v11, v5

    div-int/2addr v11, v2

    invoke-static {v9, v11}, Ljava/lang/Math;->max(II)I

    move-result v11

    goto :goto_5

    :cond_6
    div-int/2addr v11, v2

    .line 70
    .local v11, "bi":I
    :goto_5
    add-int/lit8 v13, v4, -0x1

    if-le v11, v13, :cond_7

    .line 71
    add-int/lit8 v11, v4, -0x1

    .line 73
    :cond_7
    add-int/lit8 v13, v2, -0x1

    iget v14, v12, Lnet/duceng/midi/EventChannel;->tick:I

    mul-int v15, v11, v2

    sub-int/2addr v14, v15

    invoke-static {v13, v14}, Ljava/lang/Math;->min(II)I

    move-result v13

    invoke-static {v9, v13}, Ljava/lang/Math;->max(II)I

    move-result v9

    iput v9, v12, Lnet/duceng/midi/EventChannel;->tick:I

    .line 74
    invoke-virtual {v6, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/ArrayList;

    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 75
    .end local v8    # "e2":Lnet/duceng/midi/MidiEvent;
    .end local v10    # "isOff":Z
    .end local v11    # "bi":I
    .end local v12    # "ec":Lnet/duceng/midi/EventChannel;
    goto :goto_2

    .line 76
    :cond_8
    const/4 v7, 0x0

    .local v7, "idxBar":I
    :goto_6
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v7, v8, :cond_14

    .line 77
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/ArrayList;

    .line 78
    .local v8, "barNow":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    new-instance v12, Ljava/util/TreeSet;

    invoke-direct {v12}, Ljava/util/TreeSet;-><init>()V

    .line 79
    .local v12, "nbar":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/EventChannel;>;"
    const/4 v13, 0x0

    .line 80
    .local v13, "idxNow":I
    :goto_7
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v14

    if-ge v13, v14, :cond_10

    .line 81
    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lnet/duceng/midi/EventChannel;

    .line 82
    .local v14, "on":Lnet/duceng/midi/EventChannel;
    iget-byte v15, v14, Lnet/duceng/midi/EventChannel;->type:B

    if-ne v15, v10, :cond_f

    iget-byte v15, v14, Lnet/duceng/midi/EventChannel;->value2:B

    if-lez v15, :cond_f

    .line 83
    const/4 v15, 0x0

    .line 84
    .local v15, "find":Z
    add-int/lit8 v16, v13, 0x1

    move/from16 v9, v16

    .local v9, "idxFind":I
    :goto_8
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v9, v5, :cond_c

    .line 85
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lnet/duceng/midi/EventChannel;

    .line 86
    .local v5, "off":Lnet/duceng/midi/EventChannel;
    iget-byte v10, v5, Lnet/duceng/midi/EventChannel;->type:B

    if-eq v10, v11, :cond_9

    iget-byte v10, v5, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v11, 0x9

    if-ne v10, v11, :cond_b

    iget-byte v10, v5, Lnet/duceng/midi/EventChannel;->value2:B

    if-nez v10, :cond_b

    :cond_9
    iget-byte v10, v5, Lnet/duceng/midi/EventChannel;->channel:B

    iget-byte v11, v14, Lnet/duceng/midi/EventChannel;->channel:B

    if-ne v10, v11, :cond_b

    iget-byte v10, v5, Lnet/duceng/midi/EventChannel;->value1:B

    iget-byte v11, v14, Lnet/duceng/midi/EventChannel;->value1:B

    if-ne v10, v11, :cond_b

    .line 87
    iget v10, v5, Lnet/duceng/midi/EventChannel;->tick:I

    iget v11, v14, Lnet/duceng/midi/EventChannel;->tick:I

    sub-int/2addr v10, v11

    div-int/lit8 v11, v1, 0x10

    if-ge v10, v11, :cond_a

    .line 88
    add-int/lit8 v10, v2, -0x1

    iget v11, v14, Lnet/duceng/midi/EventChannel;->tick:I

    div-int/lit8 v17, v1, 0x8

    add-int v11, v11, v17

    const/16 v16, 0x1

    add-int/lit8 v11, v11, -0x1

    invoke-static {v10, v11}, Ljava/lang/Math;->min(II)I

    move-result v10

    iput v10, v5, Lnet/duceng/midi/EventChannel;->tick:I

    .line 90
    :cond_a
    const/4 v15, 0x1

    .line 91
    const/16 v10, 0x8

    iput-byte v10, v5, Lnet/duceng/midi/EventChannel;->type:B

    .line 92
    invoke-virtual {v12, v14}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    .line 93
    invoke-virtual {v12, v5}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    .line 94
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 95
    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 96
    add-int/lit8 v13, v13, -0x1

    .line 97
    goto :goto_9

    .line 84
    .end local v5    # "off":Lnet/duceng/midi/EventChannel;
    :cond_b
    add-int/lit8 v9, v9, 0x1

    const/4 v5, 0x1

    const/16 v10, 0x9

    const/16 v11, 0x8

    goto :goto_8

    .line 100
    .end local v9    # "idxFind":I
    :cond_c
    :goto_9
    if-nez v15, :cond_e

    .line 102
    new-instance v5, Lnet/duceng/midi/EventChannel;

    add-int/lit8 v18, v2, -0x1

    iget-byte v9, v14, Lnet/duceng/midi/EventChannel;->channel:B

    iget-byte v10, v14, Lnet/duceng/midi/EventChannel;->value1:B

    const/16 v22, 0x0

    const/16 v19, 0x8

    move-object/from16 v17, v5

    move/from16 v20, v9

    move/from16 v21, v10

    invoke-direct/range {v17 .. v22}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    .line 103
    .local v5, "ecoff":Lnet/duceng/midi/EventChannel;
    const/4 v9, 0x1

    iput-byte v9, v5, Lnet/duceng/midi/EventChannel;->carry:B

    .line 104
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v10

    sub-int/2addr v10, v9

    if-ge v7, v10, :cond_d

    .line 105
    new-instance v9, Lnet/duceng/midi/EventChannel;

    iget-byte v10, v14, Lnet/duceng/midi/EventChannel;->channel:B

    iget-byte v11, v14, Lnet/duceng/midi/EventChannel;->value1:B

    move/from16 v23, v1

    .end local v1    # "res":I
    .local v23, "res":I
    iget-byte v1, v14, Lnet/duceng/midi/EventChannel;->value2:B

    const/16 v18, 0x0

    const/16 v19, 0x9

    move-object/from16 v17, v9

    move/from16 v20, v10

    move/from16 v21, v11

    move/from16 v22, v1

    invoke-direct/range {v17 .. v22}, Lnet/duceng/midi/EventChannel;-><init>(IBBBB)V

    move-object v1, v9

    .line 106
    .local v1, "econ":Lnet/duceng/midi/EventChannel;
    const/4 v9, 0x2

    iput-byte v9, v1, Lnet/duceng/midi/EventChannel;->carry:B

    .line 107
    add-int/lit8 v9, v7, 0x1

    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/ArrayList;

    const/4 v10, 0x0

    invoke-virtual {v9, v10, v1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    goto :goto_a

    .line 104
    .end local v23    # "res":I
    .local v1, "res":I
    :cond_d
    move/from16 v23, v1

    const/4 v10, 0x0

    .line 109
    .end local v1    # "res":I
    .restart local v23    # "res":I
    :goto_a
    invoke-virtual {v12, v14}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    .line 110
    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 111
    add-int/lit8 v13, v13, -0x1

    .line 112
    invoke-virtual {v12, v5}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    goto :goto_b

    .line 100
    .end local v5    # "ecoff":Lnet/duceng/midi/EventChannel;
    .end local v23    # "res":I
    .restart local v1    # "res":I
    :cond_e
    move/from16 v23, v1

    const/4 v10, 0x0

    .end local v1    # "res":I
    .restart local v23    # "res":I
    goto :goto_b

    .line 82
    .end local v15    # "find":Z
    .end local v23    # "res":I
    .restart local v1    # "res":I
    :cond_f
    move/from16 v23, v1

    const/4 v10, 0x0

    .line 115
    .end local v1    # "res":I
    .restart local v23    # "res":I
    :goto_b
    const/4 v1, 0x1

    .end local v14    # "on":Lnet/duceng/midi/EventChannel;
    add-int/2addr v13, v1

    .line 116
    move/from16 v1, v23

    const/4 v5, 0x1

    const/4 v9, 0x0

    const/16 v10, 0x9

    const/16 v11, 0x8

    goto/16 :goto_7

    .line 118
    .end local v23    # "res":I
    .restart local v1    # "res":I
    :cond_10
    move/from16 v23, v1

    const/4 v1, 0x1

    const/4 v10, 0x0

    .end local v1    # "res":I
    .restart local v23    # "res":I
    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_c
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_13

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lnet/duceng/midi/EventChannel;

    .line 119
    .local v9, "rest":Lnet/duceng/midi/EventChannel;
    iget-byte v11, v9, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v14, 0x9

    if-eq v11, v14, :cond_11

    iget-byte v11, v9, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v15, 0x8

    if-eq v11, v15, :cond_12

    .line 120
    invoke-virtual {v12, v9}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    goto :goto_d

    .line 119
    :cond_11
    const/16 v15, 0x8

    .line 122
    .end local v9    # "rest":Lnet/duceng/midi/EventChannel;
    :cond_12
    :goto_d
    goto :goto_c

    .line 123
    :cond_13
    const/16 v14, 0x9

    const/16 v15, 0x8

    iget-object v5, v0, Lnet/duceng/midi/StySection;->bars:Ljava/util/ArrayList;

    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 76
    .end local v8    # "barNow":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lnet/duceng/midi/EventChannel;>;"
    .end local v12    # "nbar":Ljava/util/TreeSet;, "Ljava/util/TreeSet<Lnet/duceng/midi/EventChannel;>;"
    .end local v13    # "idxNow":I
    add-int/lit8 v7, v7, 0x1

    move/from16 v1, v23

    const/4 v5, 0x1

    const/4 v9, 0x0

    const/16 v10, 0x9

    const/16 v11, 0x8

    goto/16 :goto_6

    .end local v23    # "res":I
    .restart local v1    # "res":I
    :cond_14
    move/from16 v23, v1

    .line 125
    .end local v1    # "res":I
    .end local v7    # "idxBar":I
    .restart local v23    # "res":I
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Section:"

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v5, v0, Lnet/duceng/midi/StySection;->name:Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v5, " bars: "

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v5, v0, Lnet/duceng/midi/StySection;->bars:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v5, "XMidi"

    invoke-static {v5, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 126
    return-void
.end method

.method protected setControls(Landroid/util/SparseArray;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/util/SparseArray<",
            "Lnet/duceng/midi/StyControl;",
            ">;)V"
        }
    .end annotation

    .line 41
    .local p1, "sc":Landroid/util/SparseArray;, "Landroid/util/SparseArray<Lnet/duceng/midi/StyControl;>;"
    iput-object p1, p0, Lnet/duceng/midi/StySection;->controls:Landroid/util/SparseArray;

    .line 42
    return-void
.end method

.method public sizeBars()I
    .locals 1

    .line 129
    iget-object v0, p0, Lnet/duceng/midi/StySection;->bars:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

# Respeta las reglas del CASM de Yamaha: cada canal solo suena con ciertos tipos de acorde
# ("chord-play") y ciertas notas raiz ("note-play"). Solo se filtran las notas que empiezan;
# los apagados y los controles pasan siempre para no dejar notas colgadas.
.method static xmPlays(Lnet/duceng/midi/EventChannel;Lnet/duceng/midi/StyControl;Lnet/duceng/xmidi/util/Chords$Chord;)Z
    .locals 9

    iget-byte v0, p0, Lnet/duceng/midi/EventChannel;->type:B

    const/16 v1, 0x9

    if-ne v0, v1, :xm_true

    iget-byte v0, p0, Lnet/duceng/midi/EventChannel;->value2:B

    if-lez v0, :xm_true

    if-eqz p1, :xm_true

    if-eqz p2, :xm_true

    iget-object v2, p1, Lnet/duceng/midi/StyControl;->noteMute:[B

    const/4 v3, 0x0

    aget-byte v4, v2, v3

    and-int/lit8 v4, v4, 0xf

    shl-int/lit8 v4, v4, 0x8

    const/4 v3, 0x1

    aget-byte v5, v2, v3

    and-int/lit16 v5, v5, 0xff

    or-int/2addr v4, v5

    if-eqz v4, :xm_chords

    const/16 v5, 0xfff

    if-eq v4, v5, :xm_chords

    iget-byte v5, p2, Lnet/duceng/xmidi/util/Chords$Chord;->root:B

    shr-int v6, v4, v5

    and-int/lit8 v6, v6, 0x1

    if-eqz v6, :xm_false

    :xm_chords
    iget-object v2, p1, Lnet/duceng/midi/StyControl;->chordMute:[B

    const/4 v3, 0x1

    aget-byte v4, v2, v3

    and-int/lit16 v4, v4, 0xff

    shl-int/lit8 v4, v4, 0x18

    const/4 v3, 0x2

    aget-byte v5, v2, v3

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x10

    or-int/2addr v4, v5

    const/4 v3, 0x3

    aget-byte v5, v2, v3

    and-int/lit16 v5, v5, 0xff

    shl-int/lit8 v5, v5, 0x8

    or-int/2addr v4, v5

    const/4 v3, 0x4

    aget-byte v5, v2, v3

    and-int/lit16 v5, v5, 0xff

    or-int/2addr v4, v5

    const v5, 0x3fffffff

    and-int v6, v4, v5

    if-eqz v6, :xm_true

    iget v7, p2, Lnet/duceng/xmidi/util/Chords$Chord;->id:I

    div-int/lit8 v7, v7, 0xc

    const/4 v8, 0x2

    if-ne v7, v8, :xm_notdom

    const v8, 0x2ff80000

    goto :xm_check

    :xm_notdom
    const/4 v8, 0x0

    if-ne v7, v8, :xm_minor

    const v8, 0x100000ff

    goto :xm_check

    :xm_minor
    const v8, 0x7ff00

    :xm_check
    and-int/2addr v4, v8

    if-eqz v4, :xm_false

    :xm_true
    const/4 v0, 0x1

    return v0

    :xm_false
    const/4 v0, 0x0

    return v0
.end method
