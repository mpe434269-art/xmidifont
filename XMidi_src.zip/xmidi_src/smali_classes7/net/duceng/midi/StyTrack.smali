.class public Lnet/duceng/midi/StyTrack;
.super Ljava/lang/Object;
.source "StyTrack.java"


# static fields
.field public static final ID:Ljava/lang/String; = "MTrk"


# instance fields
.field protected events:Ljava/util/TreeSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/TreeSet<",
            "Lnet/duceng/midi/MidiEvent;",
            ">;"
        }
    .end annotation
.end field

.field private size:I


# direct methods
.method public constructor <init>(Ljava/io/InputStream;)V
    .locals 7
    .param p1, "in"    # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    new-instance v0, Ljava/util/TreeSet;

    invoke-direct {v0}, Ljava/util/TreeSet;-><init>()V

    iput-object v0, p0, Lnet/duceng/midi/StyTrack;->events:Ljava/util/TreeSet;

    .line 14
    const/4 v0, 0x0

    iput v0, p0, Lnet/duceng/midi/StyTrack;->size:I

    .line 15
    const/4 v1, 0x4

    new-array v2, v1, [B

    .line 16
    .local v2, "buffer":[B
    invoke-virtual {p1, v2, v0, v1}, Ljava/io/InputStream;->read([BII)I

    .line 17
    new-instance v3, Ljava/lang/String;

    const-string v4, "US-ASCII"

    invoke-direct {v3, v2, v0, v1, v4}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    .line 18
    .local v3, "id":Ljava/lang/String;
    const-string v4, "MTrk"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4

    .line 21
    invoke-virtual {p1, v2, v0, v1}, Ljava/io/InputStream;->read([BII)I

    .line 22
    invoke-static {v2, v0, v1}, Lnet/duceng/midi/MidiUtil;->bytesToInt([BII)I

    move-result v0

    iput v0, p0, Lnet/duceng/midi/StyTrack;->size:I

    .line 23
    const/4 v0, 0x0

    .line 24
    .local v0, "totalTicks":I
    :goto_0
    invoke-virtual {p1}, Ljava/io/InputStream;->available()I

    move-result v1

    if-lez v1, :cond_3

    .line 25
    invoke-static {p1}, Lnet/duceng/midi/MidiUtil;->readVInt(Ljava/io/InputStream;)I

    move-result v1

    .line 26
    .local v1, "delta":I
    add-int/2addr v0, v1

    .line 27
    invoke-static {v0, v1, p1}, Lnet/duceng/midi/MidiEvent;->parse(IILjava/io/InputStream;)Lnet/duceng/midi/MidiEvent;

    move-result-object v4

    .line 28
    .local v4, "E":Lnet/duceng/midi/MidiEvent;
    if-nez v4, :cond_0

    .line 29
    sget-object v5, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v6, "Event skipped!"

    invoke-virtual {v5, v6}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto :goto_2

    .line 30
    :cond_0
    instance-of v5, v4, Lnet/duceng/midi/EventMeta;

    if-eqz v5, :cond_2

    move-object v5, v4

    check-cast v5, Lnet/duceng/midi/EventMeta;

    invoke-virtual {v5}, Lnet/duceng/midi/EventMeta;->getType()S

    move-result v5

    const/16 v6, 0x2f

    if-eq v5, v6, :cond_1

    goto :goto_1

    .line 33
    :cond_1
    return-void

    .line 31
    :cond_2
    :goto_1
    iget-object v5, p0, Lnet/duceng/midi/StyTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v5, v4}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    .line 35
    .end local v1    # "delta":I
    .end local v4    # "E":Lnet/duceng/midi/MidiEvent;
    :goto_2
    goto :goto_0

    .line 36
    :cond_3
    return-void

    .line 19
    .end local v0    # "totalTicks":I
    :cond_4
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Track id did not match MTrk!"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public getCount()I
    .locals 1

    .line 43
    iget-object v0, p0, Lnet/duceng/midi/StyTrack;->events:Ljava/util/TreeSet;

    invoke-virtual {v0}, Ljava/util/TreeSet;->size()I

    move-result v0

    return v0
.end method

.method public getEvents()Ljava/util/TreeSet;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/TreeSet<",
            "Lnet/duceng/midi/MidiEvent;",
            ">;"
        }
    .end annotation

    .line 39
    iget-object v0, p0, Lnet/duceng/midi/StyTrack;->events:Ljava/util/TreeSet;

    return-object v0
.end method

.method public getSize()I
    .locals 1

    .line 47
    iget v0, p0, Lnet/duceng/midi/StyTrack;->size:I

    return v0
.end method
